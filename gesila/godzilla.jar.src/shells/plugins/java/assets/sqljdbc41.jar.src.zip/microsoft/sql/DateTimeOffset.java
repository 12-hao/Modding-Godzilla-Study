/*     */ package microsoft.sql;
/*     */ 
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.Serializable;
/*     */ import java.math.BigDecimal;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class DateTimeOffset
/*     */   implements Serializable, Comparable<DateTimeOffset>
/*     */ {
/*     */   private static final long serialVersionUID = 541973748553014280L;
/*     */   private final long utcMillis;
/*     */   private final int nanos;
/*     */   private final int minutesOffset;
/*     */   private static final int NANOS_MIN = 0;
/*     */   private static final int NANOS_MAX = 999999999;
/*     */   private static final int SS_NANOS_MAX = 9999999;
/*     */   private static final int MINUTES_OFFSET_MIN = -840;
/*     */   private static final int MINUTES_OFFSET_MAX = 840;
/*     */   private static final int HUNDRED_NANOS_PER_SECOND = 10000000;
/*     */   
/*     */   private DateTimeOffset(Timestamp paramTimestamp, int paramInt) {
/*  39 */     if (paramInt < -840 || paramInt > 840)
/*  40 */       throw new IllegalArgumentException(); 
/*  41 */     this.minutesOffset = paramInt;
/*     */ 
/*     */     
/*  44 */     int i = paramTimestamp.getNanos();
/*  45 */     if (i < 0 || i > 999999999) {
/*  46 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  54 */     int j = (i + 50) / 100;
/*  55 */     this.nanos = 100 * j % 10000000;
/*  56 */     this.utcMillis = paramTimestamp.getTime() - (paramTimestamp.getNanos() / 1000000) + (1000 * j / 10000000);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  62 */     assert this.minutesOffset >= -840 && this.minutesOffset <= 840 : "minutesOffset: " + this.minutesOffset;
/*  63 */     assert this.nanos >= 0 && this.nanos <= 999999999 : "nanos: " + this.nanos;
/*  64 */     assert 0 == this.nanos % 100 : "nanos: " + this.nanos;
/*  65 */     assert 0L == this.utcMillis % 1000L : "utcMillis: " + this.utcMillis;
/*     */   }
/*     */ 
/*     */   
/*     */   public static DateTimeOffset valueOf(Timestamp paramTimestamp, int paramInt) {
/*  70 */     return new DateTimeOffset(paramTimestamp, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DateTimeOffset valueOf(Timestamp paramTimestamp, Calendar paramCalendar) {
/*  78 */     paramCalendar.setTimeInMillis(paramTimestamp.getTime());
/*     */     
/*  80 */     return new DateTimeOffset(paramTimestamp, (paramCalendar.get(15) + paramCalendar.get(16)) / 60000);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  89 */   private String formattedValue = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String toString() {
/*  95 */     String str = this.formattedValue;
/*  96 */     if (null == str) {
/*     */ 
/*     */       
/*  99 */       String str1 = (this.minutesOffset < 0) ? String.format(Locale.US, "-%1$02d:%2$02d", new Object[] { Integer.valueOf(-this.minutesOffset / 60), Integer.valueOf(-this.minutesOffset % 60) }) : String.format(Locale.US, "+%1$02d:%2$02d", new Object[] { Integer.valueOf(this.minutesOffset / 60), Integer.valueOf(this.minutesOffset % 60) });
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 116 */       Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("GMT" + str1), Locale.US);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 121 */       calendar.setTimeInMillis(this.utcMillis);
/*     */ 
/*     */ 
/*     */       
/* 125 */       assert this.nanos >= 0 && this.nanos <= 999999999;
/*     */ 
/*     */       
/* 128 */       this.formattedValue = str = (0 == this.nanos) ? String.format(Locale.US, "%1$tF %1$tT %2$s", new Object[] { calendar, str1 }) : String.format(Locale.US, "%1$tF %1$tT.%2$s %3$s", new Object[] { calendar, BigDecimal.valueOf(this.nanos, 9).stripTrailingZeros().toPlainString().substring(2), str1 });
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 153 */     if (this == paramObject) {
/* 154 */       return true;
/*     */     }
/*     */     
/* 157 */     if (!(paramObject instanceof DateTimeOffset)) {
/* 158 */       return false;
/*     */     }
/*     */     
/* 161 */     DateTimeOffset dateTimeOffset = (DateTimeOffset)paramObject;
/* 162 */     return (this.utcMillis == dateTimeOffset.utcMillis && this.nanos == dateTimeOffset.nanos && this.minutesOffset == dateTimeOffset.minutesOffset);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 174 */     assert 0L == this.utcMillis % 1000L;
/* 175 */     long l = this.utcMillis / 1000L;
/*     */     
/* 177 */     int i = 571;
/* 178 */     i = 2011 * i + (int)l;
/* 179 */     i = 3217 * i + (int)(l / 60L * 60L * 24L * 365L);
/*     */ 
/*     */     
/* 182 */     i = 3919 * i + this.nanos / 100000;
/* 183 */     i = 4463 * i + this.nanos / 1000;
/* 184 */     i = 5227 * i + this.nanos;
/*     */ 
/*     */ 
/*     */     
/* 188 */     i = 6689 * i + this.minutesOffset;
/* 189 */     i = 7577 * i + this.minutesOffset / 60;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Timestamp getTimestamp() {
/* 206 */     Timestamp timestamp = new Timestamp(this.utcMillis);
/* 207 */     timestamp.setNanos(this.nanos);
/* 208 */     return timestamp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMinutesOffset() {
/* 218 */     return this.minutesOffset;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compareTo(DateTimeOffset paramDateTimeOffset) {
/* 239 */     assert this.nanos >= 0;
/* 240 */     assert paramDateTimeOffset.nanos >= 0;
/*     */     
/* 242 */     return (this.utcMillis > paramDateTimeOffset.utcMillis) ? 1 : ((this.utcMillis < paramDateTimeOffset.utcMillis) ? -1 : (this.nanos - paramDateTimeOffset.nanos));
/*     */   }
/*     */ 
/*     */   
/*     */   private static class SerializationProxy
/*     */     implements Serializable
/*     */   {
/*     */     private final long utcMillis;
/*     */     
/*     */     private final int nanos;
/*     */     private final int minutesOffset;
/*     */     private static final long serialVersionUID = 664661379547314226L;
/*     */     
/*     */     SerializationProxy(DateTimeOffset param1DateTimeOffset) {
/* 256 */       this.utcMillis = param1DateTimeOffset.utcMillis;
/* 257 */       this.nanos = param1DateTimeOffset.nanos;
/* 258 */       this.minutesOffset = param1DateTimeOffset.minutesOffset;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Object readResolve() {
/* 265 */       Timestamp timestamp = new Timestamp(this.utcMillis);
/* 266 */       timestamp.setNanos(this.nanos);
/* 267 */       return new DateTimeOffset(timestamp, this.minutesOffset);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private Object writeReplace() {
/* 273 */     return new SerializationProxy(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws InvalidObjectException {
/* 284 */     throw new InvalidObjectException("");
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/microsoft/sql/DateTimeOffset.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */