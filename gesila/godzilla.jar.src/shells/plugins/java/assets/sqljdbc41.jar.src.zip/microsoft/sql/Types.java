package microsoft.sql;

public final class Types {
  public static final int DATETIMEOFFSET = -155;
  
  public static final int STRUCTURED = -153;
  
  public static final int DATETIME = -151;
  
  public static final int SMALLDATETIME = -150;
  
  public static final int MONEY = -148;
  
  public static final int SMALLMONEY = -146;
  
  public static final int GUID = -145;
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/microsoft/sql/Types.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */