/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.util.Vector;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CekTableEntry
/*     */ {
/*  46 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.AE");
/*     */   
/*     */   Vector<EncryptionKeyInfo> columnEncryptionKeyValues;
/*     */   
/*     */   int ordinal;
/*     */   int databaseId;
/*     */   int cekId;
/*     */   int cekVersion;
/*     */   byte[] cekMdVersion;
/*     */   
/*     */   Vector<EncryptionKeyInfo> getColumnEncryptionKeyValues() {
/*  57 */     return this.columnEncryptionKeyValues;
/*     */   }
/*     */   
/*     */   int getOrdinal() {
/*  61 */     return this.ordinal;
/*     */   }
/*     */   
/*     */   int getDatabaseId() {
/*  65 */     return this.databaseId;
/*     */   }
/*     */   
/*     */   int getCekId() {
/*  69 */     return this.cekId;
/*     */   }
/*     */   
/*     */   int getCekVersion() {
/*  73 */     return this.cekVersion;
/*     */   }
/*     */   
/*     */   byte[] getCekMdVersion() {
/*  77 */     return this.cekMdVersion;
/*     */   }
/*     */ 
/*     */   
/*     */   CekTableEntry(int paramInt) {
/*  82 */     this.ordinal = paramInt;
/*  83 */     this.databaseId = 0;
/*  84 */     this.cekId = 0;
/*  85 */     this.cekVersion = 0;
/*  86 */     this.cekMdVersion = null;
/*  87 */     this.columnEncryptionKeyValues = new Vector<>();
/*     */   }
/*     */   
/*     */   int getSize() {
/*  91 */     return this.columnEncryptionKeyValues.size();
/*     */   }
/*     */ 
/*     */   
/*     */   void add(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfbyte2, String paramString1, String paramString2, String paramString3) {
/*  96 */     assert null != this.columnEncryptionKeyValues : "columnEncryptionKeyValues should already be initialized.";
/*     */     
/*  98 */     if (aeLogger.isLoggable(Level.FINE)) {
/*  99 */       aeLogger.fine("Retrieving CEK values");
/*     */     }
/*     */     
/* 102 */     EncryptionKeyInfo encryptionKeyInfo = new EncryptionKeyInfo(paramArrayOfbyte1, paramInt1, paramInt2, paramInt3, paramArrayOfbyte2, paramString1, paramString2, paramString3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     this.columnEncryptionKeyValues.add(encryptionKeyInfo);
/*     */     
/* 113 */     if (0 == this.databaseId) {
/* 114 */       this.databaseId = paramInt1;
/* 115 */       this.cekId = paramInt2;
/* 116 */       this.cekVersion = paramInt3;
/* 117 */       this.cekMdVersion = paramArrayOfbyte2;
/*     */     } else {
/*     */       
/* 120 */       assert this.databaseId == paramInt1;
/* 121 */       assert this.cekId == paramInt2;
/* 122 */       assert this.cekVersion == paramInt3;
/* 123 */       assert null != this.cekMdVersion && null != paramArrayOfbyte2 && this.cekMdVersion.length == paramArrayOfbyte2.length;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/CekTableEntry.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */