/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.Signature;
/*     */ import java.security.cert.X509Certificate;
/*     */ import java.text.MessageFormat;
/*     */ import javax.crypto.Cipher;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class KeyStoreProviderCommon
/*     */ {
/*     */   static final String rsaEncryptionAlgorithmWithOAEP = "RSA_OAEP";
/*  40 */   static byte[] version = new byte[] { 1 };
/*     */ 
/*     */   
/*     */   static void validateEncryptionAlgorithm(String paramString, boolean paramBoolean) throws SQLServerException {
/*  44 */     String str = paramBoolean ? "R_NullKeyEncryptionAlgorithm" : "R_NullKeyEncryptionAlgorithmInternal";
/*  45 */     if (null == paramString)
/*     */     {
/*     */       
/*  48 */       throw new SQLServerException(null, SQLServerException.getErrString(str), null, 0, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  57 */     str = paramBoolean ? "R_InvalidKeyEncryptionAlgorithm" : "R_InvalidKeyEncryptionAlgorithmInternal";
/*  58 */     if (!"RSA_OAEP".equalsIgnoreCase(paramString.trim())) {
/*     */ 
/*     */       
/*  61 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString(str));
/*     */       
/*  63 */       Object[] arrayOfObject = { paramString, "RSA_OAEP" };
/*  64 */       throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void validateNonEmptyMasterKeyPath(String paramString) throws SQLServerException {
/*  71 */     if (null == paramString || paramString.trim().length() == 0)
/*     */     {
/*  73 */       throw new SQLServerException(null, SQLServerException.getErrString("R_InvalidMasterKeyDetails"), null, 0, false);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte, CertificateDetails paramCertificateDetails) throws SQLServerException {
/*  88 */     if (null == paramArrayOfbyte)
/*     */     {
/*  90 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullEncryptedColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  98 */     if (0 == paramArrayOfbyte.length)
/*     */     {
/* 100 */       throw new SQLServerException(null, SQLServerException.getErrString("R_EmptyEncryptedColumnEncryptionKey"), null, 0, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 109 */     validateEncryptionAlgorithm(paramString2, false);
/*     */     
/* 111 */     int i = version.length;
/* 112 */     short s1 = convertTwoBytesToShort(paramArrayOfbyte, i);
/*     */     
/* 114 */     i += 2;
/*     */ 
/*     */     
/* 117 */     short s2 = convertTwoBytesToShort(paramArrayOfbyte, i);
/*     */ 
/*     */     
/* 120 */     i += 2;
/*     */     
/* 122 */     i += s1;
/*     */     
/* 124 */     int j = paramArrayOfbyte.length - i - s2;
/*     */ 
/*     */ 
/*     */     
/* 128 */     byte[] arrayOfByte1 = new byte[s2];
/* 129 */     System.arraycopy(paramArrayOfbyte, i, arrayOfByte1, 0, s2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 135 */     i += s2;
/*     */     
/* 137 */     byte[] arrayOfByte2 = new byte[j];
/* 138 */     System.arraycopy(paramArrayOfbyte, i, arrayOfByte2, 0, j);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 147 */     byte[] arrayOfByte3 = new byte[paramArrayOfbyte.length - arrayOfByte2.length];
/*     */     
/* 149 */     System.arraycopy(paramArrayOfbyte, 0, arrayOfByte3, 0, paramArrayOfbyte.length - arrayOfByte2.length);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 156 */     if (!verifyRSASignature(arrayOfByte3, arrayOfByte2, paramCertificateDetails.certificate, paramString1)) {
/*     */       
/* 158 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidCertificateSignature"));
/*     */       
/* 160 */       Object[] arrayOfObject = { paramString1 };
/* 161 */       throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */     } 
/*     */     
/* 164 */     return decryptRSAOAEP(arrayOfByte1, paramCertificateDetails);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] decryptRSAOAEP(byte[] paramArrayOfbyte, CertificateDetails paramCertificateDetails) throws SQLServerException {
/* 172 */     byte[] arrayOfByte = null;
/*     */     
/*     */     try {
/* 175 */       Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
/* 176 */       cipher.init(2, paramCertificateDetails.privateKey);
/* 177 */       cipher.update(paramArrayOfbyte);
/* 178 */       arrayOfByte = cipher.doFinal();
/*     */     }
/* 180 */     catch (InvalidKeyException|java.security.NoSuchAlgorithmException|javax.crypto.NoSuchPaddingException|javax.crypto.IllegalBlockSizeException|javax.crypto.BadPaddingException invalidKeyException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 186 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CEKDecryptionFailed"));
/*     */       
/* 188 */       Object[] arrayOfObject = { invalidKeyException.getMessage() };
/* 189 */       throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */     } 
/*     */     
/* 192 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean verifyRSASignature(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, X509Certificate paramX509Certificate, String paramString) throws SQLServerException {
/* 199 */     boolean bool = false;
/*     */     
/*     */     try {
/* 202 */       Signature signature = Signature.getInstance("SHA256withRSA");
/* 203 */       signature.initVerify(paramX509Certificate.getPublicKey());
/* 204 */       signature.update(paramArrayOfbyte1);
/* 205 */       bool = signature.verify(paramArrayOfbyte2);
/*     */     }
/* 207 */     catch (InvalidKeyException|java.security.NoSuchAlgorithmException|java.security.SignatureException invalidKeyException) {
/*     */ 
/*     */ 
/*     */       
/* 211 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidCertificateSignature"));
/* 212 */       Object[] arrayOfObject = { paramString };
/* 213 */       throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */     } 
/*     */     
/* 216 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static short convertTwoBytesToShort(byte[] paramArrayOfbyte, int paramInt) throws SQLServerException {
/* 223 */     short s = -1;
/* 224 */     if (paramInt + 1 >= paramArrayOfbyte.length)
/*     */     {
/* 226 */       throw new SQLServerException(null, SQLServerException.getErrString("R_ByteToShortConversion"), null, 0, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     ByteBuffer byteBuffer = ByteBuffer.allocate(2);
/* 234 */     byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
/* 235 */     byteBuffer.put(paramArrayOfbyte[paramInt]);
/* 236 */     byteBuffer.put(paramArrayOfbyte[paramInt + 1]);
/* 237 */     s = byteBuffer.getShort(0);
/* 238 */     return s;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/KeyStoreProviderCommon.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */