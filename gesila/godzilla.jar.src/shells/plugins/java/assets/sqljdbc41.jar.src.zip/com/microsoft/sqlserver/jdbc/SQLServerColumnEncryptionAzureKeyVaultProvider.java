/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import com.microsoft.azure.keyvault.KeyVaultClient;
/*     */ import com.microsoft.azure.keyvault.KeyVaultClientImpl;
/*     */ import com.microsoft.azure.keyvault.models.KeyBundle;
/*     */ import com.microsoft.azure.keyvault.models.KeyOperationResult;
/*     */ import com.microsoft.windowsazure.credentials.CloudCredentials;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.ByteOrder;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import org.apache.http.impl.client.HttpClientBuilder;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerColumnEncryptionAzureKeyVaultProvider
/*     */   extends SQLServerColumnEncryptionKeyStoreProvider
/*     */ {
/*  39 */   String name = "AZURE_KEY_VAULT";
/*     */   
/*  41 */   private final String azureKeyVaultDomainName = "vault.azure.net";
/*     */   
/*  43 */   private final String rsaEncryptionAlgorithmWithOAEPForAKV = "RSA-OAEP";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  48 */   private final byte[] firstVersion = new byte[] { 1 };
/*     */ 
/*     */   
/*     */   private KeyVaultClient keyVaultClient;
/*     */   
/*     */   private KeyVaultCredential credential;
/*     */ 
/*     */   
/*     */   public void setName(String paramString) {
/*  57 */     this.name = paramString;
/*     */   }
/*     */ 
/*     */   
/*     */   public String getName() {
/*  62 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerColumnEncryptionAzureKeyVaultProvider(SQLServerKeyVaultAuthenticationCallback paramSQLServerKeyVaultAuthenticationCallback, ExecutorService paramExecutorService) throws SQLServerException {
/*  73 */     if (null == paramSQLServerKeyVaultAuthenticationCallback) {
/*  74 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_NullValue"));
/*  75 */       Object[] arrayOfObject = { "SQLServerKeyVaultAuthenticationCallback" };
/*  76 */       throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*     */     } 
/*  78 */     this.credential = new KeyVaultCredential(paramSQLServerKeyVaultAuthenticationCallback);
/*  79 */     HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
/*  80 */     this.keyVaultClient = (KeyVaultClient)new KeyVaultClientImpl(httpClientBuilder, paramExecutorService, (CloudCredentials)this.credential);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] decryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
/*  97 */     ValidateNonEmptyAKVPath(paramString1);
/*     */     
/*  99 */     if (null == paramArrayOfbyte)
/*     */     {
/* 101 */       throw new SQLServerException(SQLServerException.getErrString("R_NullEncryptedColumnEncryptionKey"), null);
/*     */     }
/*     */     
/* 104 */     if (0 == paramArrayOfbyte.length)
/*     */     {
/* 106 */       throw new SQLServerException(SQLServerException.getErrString("R_EmptyEncryptedColumnEncryptionKey"), null);
/*     */     }
/*     */ 
/*     */     
/* 110 */     paramString2 = validateEncryptionAlgorithm(paramString2);
/*     */ 
/*     */     
/* 113 */     int i = getAKVKeySize(paramString1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 123 */     if (paramArrayOfbyte[0] != this.firstVersion[0]) {
/*     */       
/* 125 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidEcryptionAlgorithmVersion"));
/* 126 */       Object[] arrayOfObject = { String.format("%02X ", new Object[] { Byte.valueOf(paramArrayOfbyte[0]) }), String.format("%02X ", new Object[] { Byte.valueOf(this.firstVersion[0]) }) };
/* 127 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 131 */     int j = this.firstVersion.length;
/* 132 */     short s1 = convertTwoBytesToShort(paramArrayOfbyte, j);
/*     */     
/* 134 */     j += 2;
/*     */ 
/*     */     
/* 137 */     short s2 = convertTwoBytesToShort(paramArrayOfbyte, j);
/* 138 */     j += 2;
/*     */ 
/*     */ 
/*     */     
/* 142 */     j += s1;
/*     */ 
/*     */     
/* 145 */     if (s2 != i) {
/*     */       
/* 147 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVKeyLengthError"));
/* 148 */       Object[] arrayOfObject = { Short.valueOf(s2), Integer.valueOf(i), paramString1 };
/* 149 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 153 */     int k = paramArrayOfbyte.length - j - s2;
/*     */     
/* 155 */     if (k != i) {
/*     */       
/* 157 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVSignatureLengthError"));
/* 158 */       Object[] arrayOfObject = { Integer.valueOf(k), Integer.valueOf(i), paramString1 };
/* 159 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 163 */     byte[] arrayOfByte1 = new byte[s2];
/* 164 */     System.arraycopy(paramArrayOfbyte, j, arrayOfByte1, 0, s2);
/* 165 */     j += s2;
/*     */ 
/*     */     
/* 168 */     byte[] arrayOfByte2 = new byte[k];
/* 169 */     System.arraycopy(paramArrayOfbyte, j, arrayOfByte2, 0, k);
/*     */ 
/*     */     
/* 172 */     byte[] arrayOfByte3 = new byte[paramArrayOfbyte.length - arrayOfByte2.length];
/*     */     
/* 174 */     System.arraycopy(paramArrayOfbyte, 0, arrayOfByte3, 0, paramArrayOfbyte.length - arrayOfByte2.length);
/*     */ 
/*     */     
/* 177 */     MessageDigest messageDigest = null;
/*     */     try {
/* 179 */       messageDigest = MessageDigest.getInstance("SHA-256");
/* 180 */     } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
/* 181 */       throw new SQLServerException(SQLServerException.getErrString("R_NoSHA256Algorithm"), null);
/*     */     } 
/* 183 */     messageDigest.update(arrayOfByte3);
/* 184 */     byte[] arrayOfByte4 = messageDigest.digest();
/*     */     
/* 186 */     if (null == arrayOfByte4)
/*     */     {
/* 188 */       throw new SQLServerException(SQLServerException.getErrString("R_HashNull"), null);
/*     */     }
/*     */ 
/*     */     
/* 192 */     if (!AzureKeyVaultVerifySignature(arrayOfByte4, arrayOfByte2, paramString1)) {
/*     */       
/* 194 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_CEKSignatureNotMatchCMK"));
/* 195 */       Object[] arrayOfObject = { paramString1 };
/* 196 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 200 */     return AzureKeyVaultUnWrap(paramString1, paramString2, arrayOfByte1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private short convertTwoBytesToShort(byte[] paramArrayOfbyte, int paramInt) throws SQLServerException {
/* 208 */     short s = -1;
/* 209 */     if (paramInt + 1 >= paramArrayOfbyte.length)
/*     */     {
/* 211 */       throw new SQLServerException(null, SQLServerException.getErrString("R_ByteToShortConversion"), null, 0, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 218 */     ByteBuffer byteBuffer = ByteBuffer.allocate(2);
/* 219 */     byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
/* 220 */     byteBuffer.put(paramArrayOfbyte[paramInt]);
/* 221 */     byteBuffer.put(paramArrayOfbyte[paramInt + 1]);
/* 222 */     s = byteBuffer.getShort(0);
/* 223 */     return s;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] encryptColumnEncryptionKey(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
/* 241 */     ValidateNonEmptyAKVPath(paramString1);
/*     */     
/* 243 */     if (null == paramArrayOfbyte)
/*     */     {
/* 245 */       throw new SQLServerException(SQLServerException.getErrString("R_NullColumnEncryptionKey"), null);
/*     */     }
/*     */     
/* 248 */     if (0 == paramArrayOfbyte.length)
/*     */     {
/* 250 */       throw new SQLServerException(SQLServerException.getErrString("R_EmptyCEK"), null);
/*     */     }
/*     */ 
/*     */     
/* 254 */     paramString2 = validateEncryptionAlgorithm(paramString2);
/*     */ 
/*     */     
/* 257 */     int i = getAKVKeySize(paramString1);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 264 */     byte[] arrayOfByte1 = { this.firstVersion[0] };
/*     */ 
/*     */     
/* 267 */     byte[] arrayOfByte2 = null;
/*     */     try {
/* 269 */       arrayOfByte2 = paramString1.toLowerCase().getBytes("UTF-16LE");
/* 270 */     } catch (UnsupportedEncodingException unsupportedEncodingException) {
/* 271 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*     */       
/* 273 */       Object[] arrayOfObject = { "UTF-16LE" };
/* 274 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */     
/* 277 */     byte[] arrayOfByte3 = new byte[2];
/* 278 */     arrayOfByte3[0] = (byte)((short)arrayOfByte2.length & 0xFF);
/* 279 */     arrayOfByte3[1] = (byte)((short)arrayOfByte2.length >> 8 & 0xFF);
/*     */ 
/*     */     
/* 282 */     byte[] arrayOfByte4 = AzureKeyVaultWrap(paramString1, paramString2, paramArrayOfbyte);
/*     */     
/* 284 */     byte[] arrayOfByte5 = new byte[2];
/* 285 */     arrayOfByte5[0] = (byte)((short)arrayOfByte4.length & 0xFF);
/* 286 */     arrayOfByte5[1] = (byte)((short)arrayOfByte4.length >> 8 & 0xFF);
/*     */     
/* 288 */     if (arrayOfByte4.length != i)
/*     */     {
/* 290 */       throw new SQLServerException(SQLServerException.getErrString("R_CipherTextLengthNotMatchRSASize"), null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 295 */     byte[] arrayOfByte6 = new byte[arrayOfByte1.length + arrayOfByte3.length + arrayOfByte5.length + arrayOfByte2.length + arrayOfByte4.length];
/* 296 */     int j = arrayOfByte1.length;
/* 297 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte6, 0, arrayOfByte1.length);
/*     */     
/* 299 */     System.arraycopy(arrayOfByte3, 0, arrayOfByte6, j, arrayOfByte3.length);
/* 300 */     j += arrayOfByte3.length;
/*     */     
/* 302 */     System.arraycopy(arrayOfByte5, 0, arrayOfByte6, j, arrayOfByte5.length);
/* 303 */     j += arrayOfByte5.length;
/*     */     
/* 305 */     System.arraycopy(arrayOfByte2, 0, arrayOfByte6, j, arrayOfByte2.length);
/* 306 */     j += arrayOfByte2.length;
/*     */     
/* 308 */     System.arraycopy(arrayOfByte4, 0, arrayOfByte6, j, arrayOfByte4.length);
/*     */     
/* 310 */     MessageDigest messageDigest = null;
/*     */     try {
/* 312 */       messageDigest = MessageDigest.getInstance("SHA-256");
/* 313 */     } catch (NoSuchAlgorithmException noSuchAlgorithmException) {
/* 314 */       throw new SQLServerException(SQLServerException.getErrString("R_NoSHA256Algorithm"), null);
/*     */     } 
/* 316 */     messageDigest.update(arrayOfByte6);
/* 317 */     byte[] arrayOfByte7 = messageDigest.digest();
/*     */ 
/*     */     
/* 320 */     byte[] arrayOfByte8 = null;
/* 321 */     arrayOfByte8 = AzureKeyVaultSignHashedData(arrayOfByte7, paramString1);
/*     */     
/* 323 */     if (arrayOfByte8.length != i)
/*     */     {
/* 325 */       throw new SQLServerException(SQLServerException.getErrString("R_SignedHashLengthError"), null);
/*     */     }
/*     */     
/* 328 */     if (!AzureKeyVaultVerifySignature(arrayOfByte7, arrayOfByte8, paramString1))
/*     */     {
/* 330 */       throw new SQLServerException(SQLServerException.getErrString("R_InvalidSignatureComputed"), null);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 335 */     int k = arrayOfByte1.length + arrayOfByte5.length + arrayOfByte3.length + arrayOfByte4.length + arrayOfByte2.length + arrayOfByte8.length;
/* 336 */     byte[] arrayOfByte9 = new byte[k];
/*     */ 
/*     */     
/* 339 */     int m = 0;
/* 340 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte9, m, arrayOfByte1.length);
/* 341 */     m += arrayOfByte1.length;
/*     */ 
/*     */     
/* 344 */     System.arraycopy(arrayOfByte3, 0, arrayOfByte9, m, arrayOfByte3.length);
/* 345 */     m += arrayOfByte3.length;
/*     */ 
/*     */     
/* 348 */     System.arraycopy(arrayOfByte5, 0, arrayOfByte9, m, arrayOfByte5.length);
/* 349 */     m += arrayOfByte5.length;
/*     */ 
/*     */     
/* 352 */     System.arraycopy(arrayOfByte2, 0, arrayOfByte9, m, arrayOfByte2.length);
/* 353 */     m += arrayOfByte2.length;
/*     */ 
/*     */     
/* 356 */     System.arraycopy(arrayOfByte4, 0, arrayOfByte9, m, arrayOfByte4.length);
/* 357 */     m += arrayOfByte4.length;
/*     */ 
/*     */     
/* 360 */     System.arraycopy(arrayOfByte8, 0, arrayOfByte9, m, arrayOfByte8.length);
/*     */     
/* 362 */     return arrayOfByte9;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String validateEncryptionAlgorithm(String paramString) throws SQLServerException {
/* 375 */     if (null == paramString)
/*     */     {
/* 377 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullKeyEncryptionAlgorithm"), null, 0, false);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 386 */     if (paramString.equalsIgnoreCase("RSA_OAEP"))
/*     */     {
/* 388 */       paramString = "RSA-OAEP";
/*     */     }
/*     */     
/* 391 */     if (!"RSA-OAEP".equalsIgnoreCase(paramString.trim())) {
/*     */       
/* 393 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidKeyEncryptionAlgorithm"));
/*     */       
/* 395 */       Object[] arrayOfObject = { paramString, "RSA-OAEP" };
/* 396 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 400 */     return paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ValidateNonEmptyAKVPath(String paramString) throws SQLServerException {
/* 412 */     if (null == paramString || paramString.trim().isEmpty()) {
/*     */       
/* 414 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVPathNull"));
/* 415 */       Object[] arrayOfObject = { paramString };
/* 416 */       throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 420 */     URI uRI = null;
/*     */     try {
/* 422 */       uRI = new URI(paramString);
/* 423 */     } catch (URISyntaxException uRISyntaxException) {
/* 424 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVURLInvalid"));
/* 425 */       Object[] arrayOfObject = { paramString };
/* 426 */       throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 431 */     if (!uRI.getHost().toLowerCase().endsWith("vault.azure.net")) {
/*     */       
/* 433 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_AKVMasterKeyPathInvalid"));
/* 434 */       Object[] arrayOfObject = { paramString };
/* 435 */       throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] AzureKeyVaultWrap(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
/* 451 */     if (null == paramArrayOfbyte)
/*     */     {
/* 453 */       throw new SQLServerException(SQLServerException.getErrString("R_CEKNull"), null);
/*     */     }
/*     */     
/* 456 */     KeyOperationResult keyOperationResult = null;
/*     */     try {
/* 458 */       keyOperationResult = this.keyVaultClient.wrapKeyAsync(paramString1, paramString2, paramArrayOfbyte).get();
/* 459 */     } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
/* 460 */       throw new SQLServerException(SQLServerException.getErrString("R_EncryptCEKError"), null);
/*     */     } 
/* 462 */     return keyOperationResult.getResult();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] AzureKeyVaultUnWrap(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws SQLServerException {
/*     */     KeyOperationResult keyOperationResult;
/* 476 */     if (null == paramArrayOfbyte)
/*     */     {
/* 478 */       throw new SQLServerException(SQLServerException.getErrString("R_EncryptedCEKNull"), null);
/*     */     }
/*     */     
/* 481 */     if (0 == paramArrayOfbyte.length)
/*     */     {
/* 483 */       throw new SQLServerException(SQLServerException.getErrString("R_EmptyEncryptedCEK"), null);
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/* 488 */       keyOperationResult = this.keyVaultClient.unwrapKeyAsync(paramString1, paramString2, paramArrayOfbyte).get();
/* 489 */     } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
/* 490 */       throw new SQLServerException(SQLServerException.getErrString("R_DecryptCEKError"), null);
/*     */     } 
/* 492 */     return keyOperationResult.getResult();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] AzureKeyVaultSignHashedData(byte[] paramArrayOfbyte, String paramString) throws SQLServerException {
/* 505 */     assert null != paramArrayOfbyte && 0 != paramArrayOfbyte.length;
/*     */     
/* 507 */     KeyOperationResult keyOperationResult = null;
/*     */     try {
/* 509 */       keyOperationResult = this.keyVaultClient.signAsync(paramString, "RS256", paramArrayOfbyte).get();
/* 510 */     } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
/* 511 */       throw new SQLServerException(SQLServerException.getErrString("R_GenerateSignature"), null);
/*     */     } 
/* 513 */     return keyOperationResult.getResult();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean AzureKeyVaultVerifySignature(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, String paramString) throws SQLServerException {
/* 527 */     assert null != paramArrayOfbyte1 && 0 != paramArrayOfbyte1.length;
/* 528 */     assert null != paramArrayOfbyte2 && 0 != paramArrayOfbyte2.length;
/*     */     
/* 530 */     boolean bool = false;
/*     */     try {
/* 532 */       bool = ((Boolean)this.keyVaultClient.verifyAsync(paramString, "RS256", paramArrayOfbyte1, paramArrayOfbyte2).get()).booleanValue();
/* 533 */     } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
/* 534 */       throw new SQLServerException(SQLServerException.getErrString("R_VerifySignature"), null);
/*     */     } 
/*     */     
/* 537 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getAKVKeySize(String paramString) throws SQLServerException {
/* 550 */     KeyBundle keyBundle = null;
/*     */     try {
/* 552 */       keyBundle = this.keyVaultClient.getKeyAsync(paramString).get();
/* 553 */     } catch (InterruptedException|java.util.concurrent.ExecutionException interruptedException) {
/* 554 */       throw new SQLServerException(SQLServerException.getErrString("R_GetAKVKeySize"), null);
/*     */     } 
/*     */     
/* 557 */     if (!keyBundle.getKey().getKty().equalsIgnoreCase("RSA") && !keyBundle.getKey().getKty().equalsIgnoreCase("RSA-HSM")) {
/*     */ 
/*     */       
/* 560 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_NonRSAKey"));
/* 561 */       Object[] arrayOfObject = { keyBundle.getKey().getKty() };
/* 562 */       throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */     
/* 565 */     return (keyBundle.getKey().getN()).length;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerColumnEncryptionAzureKeyVaultProvider.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */