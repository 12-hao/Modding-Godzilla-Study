/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.Locale;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class Parameter
/*      */ {
/*      */   private TypeInfo typeInfo;
/*   28 */   CryptoMetadata cryptoMeta = null;
/*   29 */   TypeInfo getTypeInfo() { return this.typeInfo; } final CryptoMetadata getCryptoMetadata() {
/*   30 */     return this.cryptoMeta;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean shouldHonorAEForParameter = false;
/*      */   private boolean userProvidesPrecision = false;
/*      */   private boolean userProvidesScale = false;
/*   37 */   private String typeDefinition = null;
/*      */   
/*      */   boolean renewDefinition = false;
/*      */   
/*   41 */   private JDBCType jdbcTypeSetByUser = null;
/*      */ 
/*      */   
/*   44 */   private int valueLength = 0;
/*      */   private boolean forceEncryption = false;
/*      */   int scale;
/*      */   private int outScale;
/*      */   private String name;
/*      */   private DTV getterDTV;
/*      */   private DTV registeredOutDTV;
/*      */   private DTV setterDTV;
/*      */   private DTV inputDTV;
/*      */   
/*      */   boolean isOutput() {
/*   55 */     return (null != this.registeredOutDTV);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   JDBCType getJdbcType() throws SQLServerException {
/*   62 */     return (null != this.inputDTV) ? this.inputDTV.getJdbcType() : JDBCType.UNKNOWN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static JDBCType getSSPAUJDBCType(JDBCType paramJDBCType) {
/*   71 */     switch (paramJDBCType) {
/*      */       case CHAR:
/*   73 */         return JDBCType.NCHAR;
/*   74 */       case VARCHAR: return JDBCType.NVARCHAR;
/*   75 */       case LONGVARCHAR: return JDBCType.LONGNVARCHAR;
/*   76 */       case CLOB: return JDBCType.NCLOB;
/*   77 */     }  return paramJDBCType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerForOutput(JDBCType paramJDBCType, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/*   87 */     if (JDBCType.DATETIMEOFFSET == paramJDBCType && !paramSQLServerConnection.isKatmaiOrLater())
/*      */     {
/*   89 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  100 */     if (paramSQLServerConnection.sendStringParametersAsUnicode()) {
/*      */ 
/*      */       
/*  103 */       if (this.shouldHonorAEForParameter)
/*      */       {
/*  105 */         setJdbcTypeSetByUser(paramJDBCType);
/*      */       }
/*      */       
/*  108 */       paramJDBCType = getSSPAUJDBCType(paramJDBCType);
/*      */     } 
/*      */     
/*  111 */     this.registeredOutDTV = new DTV();
/*  112 */     this.registeredOutDTV.setJdbcType(paramJDBCType);
/*      */     
/*  114 */     if (null == this.setterDTV) {
/*  115 */       this.inputDTV = this.registeredOutDTV;
/*      */     }
/*  117 */     resetOutputValue();
/*      */   }
/*      */   Parameter(boolean paramBoolean) {
/*  120 */     this.scale = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  125 */     this.outScale = 4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  167 */     this.registeredOutDTV = null;
/*  168 */     this.setterDTV = null;
/*  169 */     this.inputDTV = null;
/*      */     this.shouldHonorAEForParameter = paramBoolean;
/*      */   }
/*      */   
/*      */   int getOutScale() {
/*      */     return this.outScale;
/*      */   }
/*      */   
/*      */   void setOutScale(int paramInt) {
/*      */     this.outScale = paramInt;
/*      */     this.userProvidesScale = true;
/*      */   }
/*      */   
/*      */   final Parameter cloneForBatch() {
/*  183 */     Parameter parameter = new Parameter(this.shouldHonorAEForParameter);
/*  184 */     parameter.typeInfo = this.typeInfo;
/*  185 */     parameter.typeDefinition = this.typeDefinition;
/*  186 */     parameter.outScale = this.outScale;
/*  187 */     parameter.name = this.name;
/*  188 */     parameter.getterDTV = this.getterDTV;
/*  189 */     parameter.registeredOutDTV = this.registeredOutDTV;
/*  190 */     parameter.setterDTV = this.setterDTV;
/*  191 */     parameter.inputDTV = this.inputDTV;
/*  192 */     parameter.cryptoMeta = this.cryptoMeta;
/*  193 */     parameter.jdbcTypeSetByUser = this.jdbcTypeSetByUser;
/*  194 */     parameter.valueLength = this.valueLength;
/*  195 */     parameter.userProvidesPrecision = this.userProvidesPrecision;
/*  196 */     parameter.userProvidesScale = this.userProvidesScale;
/*  197 */     return parameter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void skipValue(TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException {
/*  205 */     if (null == this.getterDTV) {
/*  206 */       this.getterDTV = new DTV();
/*      */     }
/*  208 */     deriveTypeInfo(paramTDSReader);
/*      */     
/*  210 */     this.getterDTV.skipValue(this.typeInfo, paramTDSReader, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void skipRetValStatus(TDSReader paramTDSReader) throws SQLServerException {
/*  219 */     StreamRetValue streamRetValue = new StreamRetValue();
/*  220 */     streamRetValue.setFromTDS(paramTDSReader);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void clearInputValue() {
/*  226 */     this.setterDTV = null;
/*  227 */     this.inputDTV = this.registeredOutDTV;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetOutputValue() {
/*  234 */     this.getterDTV = null;
/*  235 */     this.typeInfo = null;
/*      */   }
/*      */ 
/*      */   
/*      */   void deriveTypeInfo(TDSReader paramTDSReader) throws SQLServerException {
/*  240 */     if (null == this.typeInfo) {
/*      */       
/*  242 */       this.typeInfo = TypeInfo.getInstance(paramTDSReader, true);
/*      */       
/*  244 */       if (this.shouldHonorAEForParameter && this.typeInfo.isEncrypted()) {
/*      */ 
/*      */ 
/*      */         
/*  248 */         CekTableEntry cekTableEntry = this.cryptoMeta.getCekTableEntry();
/*  249 */         this.cryptoMeta = (new StreamRetValue()).getCryptoMetadata(paramTDSReader);
/*  250 */         this.cryptoMeta.setCekTableEntry(cekTableEntry);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void setFromReturnStatus(int paramInt, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/*  257 */     if (null == this.getterDTV) {
/*  258 */       this.getterDTV = new DTV();
/*      */     }
/*  260 */     this.getterDTV.setValue(null, JDBCType.INTEGER, new Integer(paramInt), JavaType.INTEGER, null, null, null, paramSQLServerConnection, getForceEncryption());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setValue(JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger1, Integer paramInteger2, SQLServerConnection paramSQLServerConnection, boolean paramBoolean, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting, int paramInt, String paramString1, String paramString2) throws SQLServerException {
/*  278 */     if (this.shouldHonorAEForParameter) {
/*      */       
/*  280 */       this.userProvidesPrecision = false;
/*  281 */       this.userProvidesScale = false;
/*      */       
/*  283 */       if (null != paramInteger1) {
/*  284 */         this.userProvidesPrecision = true;
/*      */       }
/*      */       
/*  287 */       if (null != paramInteger2) {
/*  288 */         this.userProvidesScale = true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  295 */       if (!isOutput() && 
/*  296 */         JavaType.SHORT == paramJavaType && (JDBCType.TINYINT == paramJDBCType || JDBCType.SMALLINT == paramJDBCType))
/*      */       {
/*      */         
/*  299 */         if (((Short)paramObject).shortValue() >= 0 && ((Short)paramObject).shortValue() <= 255) {
/*  300 */           paramObject = Byte.valueOf(((Short)paramObject).byteValue());
/*  301 */           paramJavaType = JavaType.of(paramObject);
/*  302 */           paramJDBCType = paramJavaType.getJDBCType(SSType.UNKNOWN, paramJDBCType);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  308 */         else if (JDBCType.TINYINT == paramJDBCType) {
/*      */ 
/*      */           
/*  311 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/*  312 */           Object[] arrayOfObject = { paramJavaType.toString().toLowerCase(Locale.ENGLISH), paramJDBCType.toString().toLowerCase(Locale.ENGLISH) };
/*  313 */           throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  321 */     if (true == paramBoolean && false == Util.shouldHonorAEForParameters(paramSQLServerStatementColumnEncryptionSetting, paramSQLServerConnection)) {
/*      */       
/*  323 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAEFalse"));
/*  324 */       Object[] arrayOfObject = { Integer.valueOf(paramInt), paramString1 };
/*  325 */       SQLServerException.makeFromDriverError(paramSQLServerConnection, this, messageFormat.format(arrayOfObject), null, true);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  330 */     if ((JDBCType.DATETIMEOFFSET == paramJDBCType || JavaType.DATETIMEOFFSET == paramJavaType) && !paramSQLServerConnection.isKatmaiOrLater())
/*      */     {
/*      */       
/*  333 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  340 */     if (JavaType.TVP == paramJavaType) {
/*      */       
/*  342 */       TVP tVP = null;
/*  343 */       if (null == paramObject) {
/*      */         
/*  345 */         tVP = new TVP(paramString2);
/*      */       }
/*  347 */       else if (paramObject instanceof SQLServerDataTable) {
/*      */         
/*  349 */         tVP = new TVP(paramString2, (SQLServerDataTable)paramObject);
/*      */       }
/*  351 */       else if (paramObject instanceof ResultSet) {
/*      */ 
/*      */ 
/*      */         
/*  355 */         if (paramSQLServerConnection.getSelectMethod().equalsIgnoreCase("cursor") && paramObject instanceof SQLServerResultSet) {
/*      */           
/*  357 */           SQLServerStatement sQLServerStatement = (SQLServerStatement)((SQLServerResultSet)paramObject).getStatement();
/*      */           
/*  359 */           if (paramSQLServerConnection.equals(sQLServerStatement.connection)) {
/*      */             
/*  361 */             if (Locale.getDefault().getLanguage() == Locale.ENGLISH.getLanguage())
/*      */             {
/*  363 */               throw new SQLServerException(SQLServerException.getErrString("R_invalidServerCursorForTVP"), null);
/*      */             }
/*      */ 
/*      */ 
/*      */             
/*  368 */             throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), null, 0, null);
/*      */           } 
/*      */         } 
/*      */         
/*  372 */         tVP = new TVP(paramString2, (ResultSet)paramObject);
/*      */       }
/*  374 */       else if (paramObject instanceof ISQLServerDataRecord) {
/*      */         
/*  376 */         tVP = new TVP(paramString2, (ISQLServerDataRecord)paramObject);
/*      */       }
/*      */       else {
/*      */         
/*  380 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPInvalidValue"));
/*  381 */         Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/*  382 */         throw new SQLServerException(messageFormat.format(arrayOfObject), null);
/*      */       } 
/*      */ 
/*      */       
/*  386 */       if (!tVP.isNull() && 0 == tVP.getTVPColumnCount())
/*      */       {
/*  388 */         throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
/*      */       }
/*      */ 
/*      */       
/*  392 */       this.name = tVP.getTVPName();
/*      */       
/*  394 */       paramObject = tVP;
/*      */     } 
/*      */ 
/*      */     
/*  398 */     if (this.shouldHonorAEForParameter) {
/*      */       
/*  400 */       setForceEncryption(paramBoolean);
/*      */ 
/*      */       
/*  403 */       if (!isOutput() || this.jdbcTypeSetByUser == null) {
/*  404 */         setJdbcTypeSetByUser(paramJDBCType);
/*      */       }
/*      */ 
/*      */       
/*  408 */       if ((!paramJDBCType.isTextual() && !paramJDBCType.isBinary()) || !isOutput() || this.valueLength == 0) {
/*  409 */         this.valueLength = Util.getValueLengthBaseOnJavaType(paramObject, paramJavaType, paramInteger1, paramInteger2, paramJDBCType);
/*      */       }
/*      */       
/*  412 */       if (null != paramInteger2) {
/*  413 */         this.outScale = paramInteger2.intValue();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  421 */     if (paramSQLServerConnection.sendStringParametersAsUnicode() && (JavaType.STRING == paramJavaType || JavaType.READER == paramJavaType || JavaType.CLOB == paramJavaType))
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  426 */       paramJDBCType = getSSPAUJDBCType(paramJDBCType);
/*      */     }
/*      */     
/*  429 */     DTV dTV = new DTV();
/*  430 */     dTV.setValue(paramSQLServerConnection.getDatabaseCollation(), paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger2, paramSQLServerConnection, paramBoolean);
/*  431 */     this.inputDTV = this.setterDTV = dTV;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isNull() {
/*  436 */     if (null != this.getterDTV) {
/*  437 */       return this.getterDTV.isNull();
/*      */     }
/*  439 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   boolean isValueGotten() {
/*  444 */     return (null != this.getterDTV);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   Object getValue(JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TDSReader paramTDSReader) throws SQLServerException {
/*  450 */     if (null == this.getterDTV) {
/*  451 */       this.getterDTV = new DTV();
/*      */     }
/*  453 */     deriveTypeInfo(paramTDSReader);
/*      */ 
/*      */     
/*  456 */     return this.getterDTV.getValue(paramJDBCType, this.outScale, paramInputStreamGetterArgs, paramCalendar, this.typeInfo, this.cryptoMeta, paramTDSReader);
/*      */   }
/*      */ 
/*      */   
/*      */   int getInt(TDSReader paramTDSReader) throws SQLServerException {
/*  461 */     Integer integer = (Integer)getValue(JDBCType.INTEGER, null, null, paramTDSReader);
/*  462 */     return (null != integer) ? integer.intValue() : 0;
/*      */   }
/*      */ 
/*      */   
/*      */   final class GetTypeDefinitionOp
/*      */     extends DTVExecuteOp
/*      */   {
/*      */     private static final String NVARCHAR_MAX = "nvarchar(max)";
/*      */     
/*      */     private static final String NVARCHAR_4K = "nvarchar(4000)";
/*      */     
/*      */     private static final String NTEXT = "ntext";
/*      */     
/*      */     private static final String VARCHAR_MAX = "varchar(max)";
/*      */     
/*      */     private static final String VARCHAR_8K = "varchar(8000)";
/*      */     
/*      */     private static final String TEXT = "text";
/*      */     
/*      */     private static final String VARBINARY_MAX = "varbinary(max)";
/*      */     
/*      */     private static final String VARBINARY_8K = "varbinary(8000)";
/*      */     private static final String IMAGE = "image";
/*      */     private final Parameter param;
/*      */     private final SQLServerConnection con;
/*      */     
/*      */     GetTypeDefinitionOp(Parameter param1Parameter1, SQLServerConnection param1SQLServerConnection) {
/*  489 */       this.param = param1Parameter1;
/*  490 */       this.con = param1SQLServerConnection;
/*      */     }
/*      */     
/*      */     private void setTypeDefinition(DTV param1DTV) {
/*      */       Integer integer;
/*  495 */       switch (param1DTV.getJdbcType()) {
/*      */         
/*      */         case TINYINT:
/*  498 */           this.param.typeDefinition = SSType.TINYINT.toString();
/*      */           return;
/*      */         
/*      */         case SMALLINT:
/*  502 */           this.param.typeDefinition = SSType.SMALLINT.toString();
/*      */           return;
/*      */         
/*      */         case INTEGER:
/*  506 */           this.param.typeDefinition = SSType.INTEGER.toString();
/*      */           return;
/*      */         
/*      */         case BIGINT:
/*  510 */           this.param.typeDefinition = SSType.BIGINT.toString();
/*      */           return;
/*      */ 
/*      */         
/*      */         case REAL:
/*  515 */           if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  525 */             this.param.typeDefinition = SSType.REAL.toString();
/*      */             return;
/*      */           } 
/*      */         case FLOAT:
/*      */         case DOUBLE:
/*  530 */           this.param.typeDefinition = SSType.FLOAT.toString();
/*      */           return;
/*      */ 
/*      */         
/*      */         case DECIMAL:
/*      */         case NUMERIC:
/*  536 */           if (Parameter.this.scale > 38) {
/*  537 */             Parameter.this.scale = 38;
/*      */           }
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  543 */           integer = param1DTV.getScale();
/*  544 */           if (null != integer && Parameter.this.scale < integer.intValue()) {
/*  545 */             Parameter.this.scale = integer.intValue();
/*      */           }
/*  547 */           if (this.param.isOutput() && Parameter.this.scale < this.param.getOutScale()) {
/*  548 */             Parameter.this.scale = this.param.getOutScale();
/*      */           }
/*  550 */           if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  560 */             if (0 == Parameter.this.valueLength) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  567 */               if (!Parameter.this.isOutput()) {
/*  568 */                 this.param.typeDefinition = "decimal(18, " + Parameter.this.scale + ")";
/*      */               
/*      */               }
/*      */             }
/*  572 */             else if (18 >= Parameter.this.valueLength) {
/*  573 */               this.param.typeDefinition = "decimal(18," + Parameter.this.scale + ")";
/*      */               
/*  575 */               if (18 < Parameter.this.valueLength + Parameter.this.scale) {
/*  576 */                 this.param.typeDefinition = "decimal(" + (18 + Parameter.this.scale) + "," + Parameter.this.scale + ")";
/*      */               }
/*      */             } else {
/*      */               
/*  580 */               this.param.typeDefinition = "decimal(38," + Parameter.this.scale + ")";
/*      */             } 
/*      */ 
/*      */             
/*  584 */             if (Parameter.this.isOutput()) {
/*  585 */               this.param.typeDefinition = "decimal(38, " + Parameter.this.scale + ")";
/*      */             }
/*      */             
/*  588 */             if (Parameter.this.userProvidesPrecision) {
/*  589 */               this.param.typeDefinition = "decimal(" + Parameter.this.valueLength + "," + Parameter.this.scale + ")";
/*      */             }
/*      */           } else {
/*      */             
/*  593 */             this.param.typeDefinition = "decimal(38," + Parameter.this.scale + ")";
/*      */           } 
/*      */           return;
/*      */         
/*      */         case MONEY:
/*  598 */           this.param.typeDefinition = SSType.MONEY.toString();
/*      */           return;
/*      */         case SMALLMONEY:
/*  601 */           this.param.typeDefinition = SSType.SMALLMONEY.toString();
/*      */           return;
/*      */         case BIT:
/*      */         case BOOLEAN:
/*  605 */           this.param.typeDefinition = SSType.BIT.toString();
/*      */           return;
/*      */         
/*      */         case LONGVARBINARY:
/*      */         case BLOB:
/*  610 */           this.param.typeDefinition = "varbinary(max)";
/*      */           return;
/*      */ 
/*      */         
/*      */         case BINARY:
/*      */         case VARBINARY:
/*  616 */           if ("varbinary(max)" != this.param.typeDefinition && "image" != this.param.typeDefinition)
/*      */           {
/*  618 */             if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  628 */               if (0 == Parameter.this.valueLength) {
/*  629 */                 this.param.typeDefinition = "varbinary";
/*      */               } else {
/*      */                 
/*  632 */                 this.param.typeDefinition = "varbinary(" + Parameter.this.valueLength + ")";
/*      */               } 
/*      */               
/*  635 */               if (JDBCType.LONGVARBINARY == Parameter.this.jdbcTypeSetByUser) {
/*  636 */                 this.param.typeDefinition = "varbinary(max)";
/*      */               }
/*      */             } else {
/*      */               
/*  640 */               this.param.typeDefinition = "varbinary(8000)";
/*      */             } 
/*      */           }
/*      */           return;
/*      */         case DATE:
/*  645 */           this.param.typeDefinition = this.con.isKatmaiOrLater() ? SSType.DATE.toString() : SSType.DATETIME.toString();
/*      */           return;
/*      */         
/*      */         case TIME:
/*  649 */           if (this.param.shouldHonorAEForParameter && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  660 */             if (Parameter.this.userProvidesScale) {
/*  661 */               this.param.typeDefinition = SSType.TIME.toString() + "(" + Parameter.this.outScale + ")";
/*      */             } else {
/*      */               
/*  664 */               this.param.typeDefinition = this.param.typeDefinition = SSType.TIME.toString() + "(" + Parameter.this.valueLength + ")";
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/*  669 */             this.param.typeDefinition = this.con.getSendTimeAsDatetime() ? SSType.DATETIME.toString() : SSType.TIME.toString();
/*      */           } 
/*      */           return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case TIMESTAMP:
/*  679 */           if (this.param.shouldHonorAEForParameter && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  688 */             if (Parameter.this.userProvidesScale) {
/*  689 */               this.param.typeDefinition = this.con.isKatmaiOrLater() ? (SSType.DATETIME2.toString() + "(" + Parameter.this.outScale + ")") : SSType.DATETIME.toString();
/*      */             }
/*      */             else {
/*      */               
/*  693 */               this.param.typeDefinition = this.con.isKatmaiOrLater() ? (SSType.DATETIME2.toString() + "(" + Parameter.this.valueLength + ")") : SSType.DATETIME.toString();
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/*  698 */             this.param.typeDefinition = this.con.isKatmaiOrLater() ? SSType.DATETIME2.toString() : SSType.DATETIME.toString();
/*      */           } 
/*      */           return;
/*      */ 
/*      */ 
/*      */         
/*      */         case DATETIME:
/*  705 */           this.param.typeDefinition = SSType.DATETIME.toString();
/*      */           
/*  707 */           if (!this.param.shouldHonorAEForParameter) {
/*      */ 
/*      */             
/*  710 */             if (this.param.isOutput()) {
/*  711 */               this.param.typeDefinition = SSType.DATETIME2.toString() + "(" + Parameter.this.outScale + ")";
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */           
/*      */           }
/*  718 */           else if (null == this.param.getCryptoMetadata() && this.param.renewDefinition && 
/*  719 */             this.param.isOutput()) {
/*  720 */             this.param.typeDefinition = SSType.DATETIME2.toString() + "(" + Parameter.this.outScale + ")";
/*      */           } 
/*      */           return;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case SMALLDATETIME:
/*  728 */           this.param.typeDefinition = SSType.SMALLDATETIME.toString();
/*      */           return;
/*      */         
/*      */         case TIME_WITH_TIMEZONE:
/*      */         case TIMESTAMP_WITH_TIMEZONE:
/*      */         case DATETIMEOFFSET:
/*  734 */           if (this.param.shouldHonorAEForParameter && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  743 */             if (Parameter.this.userProvidesScale) {
/*  744 */               this.param.typeDefinition = SSType.DATETIMEOFFSET.toString() + "(" + Parameter.this.outScale + ")";
/*      */             } else {
/*      */               
/*  747 */               this.param.typeDefinition = SSType.DATETIMEOFFSET.toString() + "(" + Parameter.this.valueLength + ")";
/*      */             } 
/*      */           } else {
/*      */             
/*  751 */             this.param.typeDefinition = SSType.DATETIMEOFFSET.toString();
/*      */           } 
/*      */           return;
/*      */         
/*      */         case LONGVARCHAR:
/*      */         case CLOB:
/*  757 */           this.param.typeDefinition = "varchar(max)";
/*      */           return;
/*      */ 
/*      */         
/*      */         case CHAR:
/*      */         case VARCHAR:
/*  763 */           if ("varchar(max)" != this.param.typeDefinition && "text" != this.param.typeDefinition)
/*      */           {
/*      */ 
/*      */             
/*  767 */             if (this.param.shouldHonorAEForParameter && null != Parameter.this.jdbcTypeSetByUser && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  777 */               if (0 == Parameter.this.valueLength) {
/*  778 */                 this.param.typeDefinition = "varchar";
/*      */               } else {
/*      */                 
/*  781 */                 this.param.typeDefinition = "varchar(" + Parameter.this.valueLength + ")";
/*      */                 
/*  783 */                 if (8000 <= Parameter.this.valueLength) {
/*  784 */                   this.param.typeDefinition = "varchar(max)";
/*      */                 }
/*      */               } 
/*      */             } else {
/*      */               
/*  789 */               this.param.typeDefinition = "varchar(8000)";
/*      */             }  } 
/*      */           return;
/*      */         case LONGNVARCHAR:
/*  793 */           if (this.param.shouldHonorAEForParameter && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  802 */             if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.VARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.CHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.LONGVARCHAR)) {
/*      */               
/*  804 */               if (0 == Parameter.this.valueLength) {
/*  805 */                 this.param.typeDefinition = "varchar";
/*      */               }
/*  807 */               else if (8000 < Parameter.this.valueLength) {
/*  808 */                 this.param.typeDefinition = "varchar(max)";
/*      */               } else {
/*      */                 
/*  811 */                 this.param.typeDefinition = "varchar(" + Parameter.this.valueLength + ")";
/*      */               } 
/*      */               
/*  814 */               if (Parameter.this.jdbcTypeSetByUser == JDBCType.LONGVARCHAR) {
/*  815 */                 this.param.typeDefinition = "varchar(max)";
/*      */               }
/*      */             }
/*  818 */             else if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.NVARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.LONGNVARCHAR)) {
/*      */               
/*  820 */               if (0 == Parameter.this.valueLength) {
/*  821 */                 this.param.typeDefinition = "nvarchar";
/*      */               }
/*  823 */               else if (4000 < Parameter.this.valueLength) {
/*  824 */                 this.param.typeDefinition = "nvarchar(max)";
/*      */               } else {
/*      */                 
/*  827 */                 this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
/*      */               } 
/*      */               
/*  830 */               if (Parameter.this.jdbcTypeSetByUser == JDBCType.LONGNVARCHAR) {
/*  831 */                 this.param.typeDefinition = "nvarchar(max)";
/*      */               
/*      */               }
/*      */             }
/*  835 */             else if (0 == Parameter.this.valueLength) {
/*  836 */               this.param.typeDefinition = "nvarchar";
/*      */             } else {
/*      */               
/*  839 */               this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
/*      */               
/*  841 */               if (8000 <= Parameter.this.valueLength) {
/*  842 */                 this.param.typeDefinition = "nvarchar(max)";
/*      */               }
/*      */             }
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  849 */             this.param.typeDefinition = "nvarchar(max)";
/*      */           } 
/*      */           return;
/*      */ 
/*      */         
/*      */         case NCLOB:
/*  855 */           this.param.typeDefinition = "nvarchar(max)";
/*      */           return;
/*      */ 
/*      */         
/*      */         case NCHAR:
/*      */         case NVARCHAR:
/*  861 */           if ("nvarchar(max)" != this.param.typeDefinition && "ntext" != this.param.typeDefinition)
/*      */           {
/*      */             
/*  864 */             if (this.param.shouldHonorAEForParameter && (null != this.param.getCryptoMetadata() || !this.param.renewDefinition)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  873 */               if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.VARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.CHAR || JDBCType.LONGVARCHAR == Parameter.this.jdbcTypeSetByUser)) {
/*      */ 
/*      */                 
/*  876 */                 if (0 == Parameter.this.valueLength) {
/*  877 */                   this.param.typeDefinition = "varchar";
/*      */                 } else {
/*      */                   
/*  880 */                   this.param.typeDefinition = "varchar(" + Parameter.this.valueLength + ")";
/*      */                   
/*  882 */                   if (8000 <= Parameter.this.valueLength) {
/*  883 */                     this.param.typeDefinition = "varchar(max)";
/*      */                   }
/*      */                 } 
/*      */                 
/*  887 */                 if (JDBCType.LONGVARCHAR == Parameter.this.jdbcTypeSetByUser) {
/*  888 */                   this.param.typeDefinition = "varchar(max)";
/*      */                 }
/*      */               }
/*  891 */               else if (null != Parameter.this.jdbcTypeSetByUser && (Parameter.this.jdbcTypeSetByUser == JDBCType.NVARCHAR || Parameter.this.jdbcTypeSetByUser == JDBCType.NCHAR || JDBCType.LONGNVARCHAR == Parameter.this.jdbcTypeSetByUser)) {
/*      */ 
/*      */                 
/*  894 */                 if (0 == Parameter.this.valueLength) {
/*  895 */                   this.param.typeDefinition = "nvarchar";
/*      */                 } else {
/*      */                   
/*  898 */                   this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
/*      */                   
/*  900 */                   if (8000 <= Parameter.this.valueLength) {
/*  901 */                     this.param.typeDefinition = "nvarchar(max)";
/*      */                   }
/*      */                 } 
/*      */                 
/*  905 */                 if (JDBCType.LONGNVARCHAR == Parameter.this.jdbcTypeSetByUser) {
/*  906 */                   this.param.typeDefinition = "nvarchar(max)";
/*      */                 
/*      */                 }
/*      */               }
/*  910 */               else if (0 == Parameter.this.valueLength) {
/*  911 */                 this.param.typeDefinition = "nvarchar";
/*      */               } else {
/*      */                 
/*  914 */                 this.param.typeDefinition = "nvarchar(" + Parameter.this.valueLength + ")";
/*      */                 
/*  916 */                 if (8000 <= Parameter.this.valueLength) {
/*  917 */                   this.param.typeDefinition = "nvarchar(max)";
/*      */                 }
/*      */               }
/*      */             
/*      */             }
/*      */             else {
/*      */               
/*  924 */               this.param.typeDefinition = "nvarchar(4000)";
/*      */             }  }  return;
/*      */         case SQLXML:
/*  927 */           this.param.typeDefinition = SSType.XML.toString();
/*      */           return;
/*      */ 
/*      */         
/*      */         case TVP:
/*  932 */           this.param.typeDefinition = "[" + this.param.name + "] READONLY";
/*      */           return;
/*      */ 
/*      */         
/*      */         case GUID:
/*  937 */           this.param.typeDefinition = SSType.GUID.toString();
/*      */           return;
/*      */       } 
/*      */       
/*  941 */       assert false : "Unexpected JDBC type " + param1DTV.getJdbcType();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, String param1String) throws SQLServerException {
/*  948 */       if (null != param1String && param1String.length() > 4000) {
/*  949 */         param1DTV.setJdbcType(JDBCType.LONGNVARCHAR);
/*      */       }
/*  951 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Clob param1Clob) throws SQLServerException {
/*  956 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Byte param1Byte) throws SQLServerException {
/*  961 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Integer param1Integer) throws SQLServerException {
/*  966 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Time param1Time) throws SQLServerException {
/*  971 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
/*  976 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Timestamp param1Timestamp) throws SQLServerException {
/*  981 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
/*  986 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Calendar param1Calendar) throws SQLServerException {
/*  991 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, LocalDate param1LocalDate) throws SQLServerException {
/*  996 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, LocalTime param1LocalTime) throws SQLServerException {
/* 1001 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, LocalDateTime param1LocalDateTime) throws SQLServerException {
/* 1006 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, OffsetTime param1OffsetTime) throws SQLServerException {
/* 1011 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, OffsetDateTime param1OffsetDateTime) throws SQLServerException {
/* 1016 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, DateTimeOffset param1DateTimeOffset) throws SQLServerException {
/* 1021 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Float param1Float) throws SQLServerException {
/* 1026 */       Parameter.this.scale = 4;
/* 1027 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Double param1Double) throws SQLServerException {
/* 1032 */       Parameter.this.scale = 4;
/* 1033 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, BigDecimal param1BigDecimal) throws SQLServerException {
/* 1038 */       if (null != param1BigDecimal) {
/*      */         
/* 1040 */         Parameter.this.scale = param1BigDecimal.scale();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1047 */         if (Parameter.this.scale < 0) {
/* 1048 */           Parameter.this.scale = 0;
/*      */         }
/*      */       } 
/* 1051 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Long param1Long) throws SQLServerException {
/* 1056 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, BigInteger param1BigInteger) throws SQLServerException {
/* 1061 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Short param1Short) throws SQLServerException {
/* 1066 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Boolean param1Boolean) throws SQLServerException {
/* 1071 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, byte[] param1ArrayOfbyte) throws SQLServerException {
/* 1076 */       if (null != param1ArrayOfbyte && param1ArrayOfbyte.length > 8000) {
/* 1077 */         param1DTV.setJdbcType(param1DTV.getJdbcType().isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*      */       }
/* 1079 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Blob param1Blob) throws SQLServerException {
/* 1084 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, InputStream param1InputStream) throws SQLServerException {
/* 1089 */       StreamSetterArgs streamSetterArgs = param1DTV.getStreamSetterArgs();
/*      */       
/* 1091 */       JDBCType jDBCType = param1DTV.getJdbcType();
/*      */ 
/*      */       
/* 1094 */       if (JDBCType.CHAR == jDBCType || JDBCType.VARCHAR == jDBCType || JDBCType.BINARY == jDBCType || JDBCType.VARBINARY == jDBCType)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1100 */         if (streamSetterArgs.getLength() > 8000L) {
/* 1101 */           param1DTV.setJdbcType(jDBCType.isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*      */ 
/*      */         
/*      */         }
/* 1105 */         else if (-1L == streamSetterArgs.getLength()) {
/*      */           
/* 1107 */           byte[] arrayOfByte = new byte[8001];
/* 1108 */           BufferedInputStream bufferedInputStream = new BufferedInputStream(param1InputStream, arrayOfByte.length);
/*      */           
/* 1110 */           int i = 0;
/*      */ 
/*      */           
/*      */           try {
/* 1114 */             bufferedInputStream.mark(arrayOfByte.length);
/*      */             
/* 1116 */             i = bufferedInputStream.read(arrayOfByte, 0, arrayOfByte.length);
/*      */             
/* 1118 */             if (-1 == i) {
/* 1119 */               i = 0;
/*      */             }
/* 1121 */             bufferedInputStream.reset();
/*      */           }
/* 1123 */           catch (IOException iOException) {
/*      */             
/* 1125 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1126 */             Object[] arrayOfObject = { iOException.toString() };
/* 1127 */             SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
/*      */           } 
/*      */           
/* 1130 */           param1DTV.setValue(bufferedInputStream, JavaType.INPUTSTREAM);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1136 */           if (i > 8000) {
/* 1137 */             param1DTV.setJdbcType(jDBCType.isBinary() ? JDBCType.LONGVARBINARY : JDBCType.LONGVARCHAR);
/*      */           } else {
/* 1139 */             streamSetterArgs.setLength(i);
/*      */           } 
/*      */         } 
/*      */       }
/* 1143 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Reader param1Reader) throws SQLServerException {
/* 1149 */       if (JDBCType.NCHAR == param1DTV.getJdbcType() || JDBCType.NVARCHAR == param1DTV.getJdbcType()) {
/*      */         
/* 1151 */         StreamSetterArgs streamSetterArgs = param1DTV.getStreamSetterArgs();
/*      */ 
/*      */         
/* 1154 */         if (streamSetterArgs.getLength() > 4000L) {
/* 1155 */           param1DTV.setJdbcType(JDBCType.LONGNVARCHAR);
/*      */ 
/*      */         
/*      */         }
/* 1159 */         else if (-1L == streamSetterArgs.getLength()) {
/*      */           
/* 1161 */           char[] arrayOfChar = new char[4001];
/* 1162 */           BufferedReader bufferedReader = new BufferedReader(param1Reader, arrayOfChar.length);
/*      */           
/* 1164 */           int i = 0;
/*      */ 
/*      */           
/*      */           try {
/* 1168 */             bufferedReader.mark(arrayOfChar.length);
/*      */             
/* 1170 */             i = bufferedReader.read(arrayOfChar, 0, arrayOfChar.length);
/*      */             
/* 1172 */             if (-1 == i) {
/* 1173 */               i = 0;
/*      */             }
/* 1175 */             bufferedReader.reset();
/*      */           }
/* 1177 */           catch (IOException iOException) {
/*      */             
/* 1179 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 1180 */             Object[] arrayOfObject = { iOException.toString() };
/* 1181 */             SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
/*      */           } 
/*      */           
/* 1184 */           param1DTV.setValue(bufferedReader, JavaType.READER);
/*      */           
/* 1186 */           if (i > 4000) {
/* 1187 */             param1DTV.setJdbcType(JDBCType.LONGNVARCHAR);
/*      */           } else {
/* 1189 */             streamSetterArgs.setLength(i);
/*      */           } 
/*      */         } 
/*      */       } 
/* 1193 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */     
/*      */     void execute(DTV param1DTV, SQLServerSQLXML param1SQLServerSQLXML) throws SQLServerException {
/* 1197 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, TVP param1TVP) throws SQLServerException {
/* 1202 */       setTypeDefinition(param1DTV);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getTypeDefinition(SQLServerConnection paramSQLServerConnection, TDSReader paramTDSReader) throws SQLServerException {
/* 1213 */     if (null == this.inputDTV) {
/* 1214 */       return null;
/*      */     }
/* 1216 */     this.inputDTV.executeOp(new GetTypeDefinitionOp(this, paramSQLServerConnection));
/* 1217 */     return this.typeDefinition;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void sendByRPC(TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/* 1224 */     assert null != this.inputDTV : "Parameter was neither set nor registered";
/*      */ 
/*      */     
/*      */     try {
/* 1228 */       this.inputDTV.sendCryptoMetaData(this.cryptoMeta, paramTDSWriter);
/* 1229 */       this.inputDTV.jdbcTypeSetByUser(getJdbcTypeSetByUser(), getValueLength());
/* 1230 */       this.inputDTV.sendByRPC(this.name, null, paramSQLServerConnection.getDatabaseCollation(), this.valueLength, isOutput() ? this.outScale : this.scale, isOutput(), paramTDSWriter, paramSQLServerConnection);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1243 */       this.inputDTV.sendCryptoMetaData(null, paramTDSWriter);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1254 */     if (JavaType.INPUTSTREAM == this.inputDTV.getJavaType() || JavaType.READER == this.inputDTV.getJavaType())
/*      */     {
/*      */       
/* 1257 */       this.inputDTV = this.setterDTV = null; } 
/*      */   }
/*      */   
/*      */   JDBCType getJdbcTypeSetByUser() {
/* 1261 */     return this.jdbcTypeSetByUser;
/*      */   }
/*      */   void setJdbcTypeSetByUser(JDBCType paramJDBCType) {
/* 1264 */     this.jdbcTypeSetByUser = paramJDBCType;
/*      */   }
/*      */   int getValueLength() {
/* 1267 */     return this.valueLength;
/*      */   }
/*      */   void setValueLength(int paramInt) {
/* 1270 */     this.valueLength = paramInt;
/* 1271 */     this.userProvidesPrecision = true;
/*      */   }
/*      */   boolean getForceEncryption() {
/* 1274 */     return this.forceEncryption;
/*      */   }
/*      */   void setForceEncryption(boolean paramBoolean) {
/* 1277 */     this.forceEncryption = paramBoolean;
/*      */   }
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/Parameter.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */