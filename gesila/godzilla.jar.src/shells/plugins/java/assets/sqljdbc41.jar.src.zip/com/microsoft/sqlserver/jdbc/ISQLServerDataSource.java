package com.microsoft.sqlserver.jdbc;

import javax.sql.CommonDataSource;

public interface ISQLServerDataSource extends CommonDataSource {
  void setApplicationIntent(String paramString);
  
  String getApplicationIntent();
  
  void setApplicationName(String paramString);
  
  String getApplicationName();
  
  void setDatabaseName(String paramString);
  
  String getDatabaseName();
  
  void setInstanceName(String paramString);
  
  String getInstanceName();
  
  void setIntegratedSecurity(boolean paramBoolean);
  
  void setLastUpdateCount(boolean paramBoolean);
  
  boolean getLastUpdateCount();
  
  void setEncrypt(boolean paramBoolean);
  
  boolean getEncrypt();
  
  void setTrustServerCertificate(boolean paramBoolean);
  
  boolean getTrustServerCertificate();
  
  void setTrustStore(String paramString);
  
  String getTrustStore();
  
  void setTrustStorePassword(String paramString);
  
  void setHostNameInCertificate(String paramString);
  
  String getHostNameInCertificate();
  
  void setLockTimeout(int paramInt);
  
  int getLockTimeout();
  
  void setPassword(String paramString);
  
  void setPortNumber(int paramInt);
  
  int getPortNumber();
  
  void setSelectMethod(String paramString);
  
  String getSelectMethod();
  
  void setResponseBuffering(String paramString);
  
  String getResponseBuffering();
  
  void setSendTimeAsDatetime(boolean paramBoolean);
  
  boolean getSendTimeAsDatetime();
  
  void setSendStringParametersAsUnicode(boolean paramBoolean);
  
  boolean getSendStringParametersAsUnicode();
  
  void setServerName(String paramString);
  
  String getServerName();
  
  void setFailoverPartner(String paramString);
  
  String getFailoverPartner();
  
  void setMultiSubnetFailover(boolean paramBoolean);
  
  boolean getMultiSubnetFailover();
  
  void setUser(String paramString);
  
  String getUser();
  
  void setWorkstationID(String paramString);
  
  String getWorkstationID();
  
  void setXopenStates(boolean paramBoolean);
  
  boolean getXopenStates();
  
  void setURL(String paramString);
  
  String getURL();
  
  void setDescription(String paramString);
  
  String getDescription();
  
  void setPacketSize(int paramInt);
  
  int getPacketSize();
  
  void setAuthenticationScheme(String paramString);
  
  void setServerSpn(String paramString);
  
  String getServerSpn();
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ISQLServerDataSource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */