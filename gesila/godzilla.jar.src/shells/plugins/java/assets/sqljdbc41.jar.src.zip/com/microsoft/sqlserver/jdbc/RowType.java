/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum RowType
/*    */ {
/* 18 */   ROW,
/* 19 */   NBCROW,
/* 20 */   UNKNOWN;
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/RowType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */