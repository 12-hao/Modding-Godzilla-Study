/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SQLServerBulkCopyOptions
/*     */ {
/*  86 */   private int batchSize = 0;
/*  87 */   private int bulkCopyTimeout = 60;
/*     */   
/*     */   private boolean checkConstraints = false;
/*     */   
/*     */   private boolean fireTriggers = false;
/*     */   
/*     */   private boolean keepIdentity = false;
/*     */   
/*     */   private boolean keepNulls = false;
/*     */   
/*     */   private boolean tableLock = false;
/*     */   
/*     */   private boolean useInternalTransaction = false;
/*     */   
/*     */   private boolean allowEncryptedValueModifications = false;
/*     */   
/*     */   public int getBatchSize() {
/* 104 */     return this.batchSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBatchSize(int paramInt) throws SQLServerException {
/* 115 */     if (paramInt >= 0) {
/*     */       
/* 117 */       this.batchSize = paramInt;
/*     */     }
/*     */     else {
/*     */       
/* 121 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidNegativeArg"));
/* 122 */       Object[] arrayOfObject = { "batchSize" };
/* 123 */       SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getBulkCopyTimeout() {
/* 134 */     return this.bulkCopyTimeout;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setBulkCopyTimeout(int paramInt) throws SQLServerException {
/* 145 */     if (paramInt >= 0) {
/*     */       
/* 147 */       this.bulkCopyTimeout = paramInt;
/*     */     }
/*     */     else {
/*     */       
/* 151 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidNegativeArg"));
/* 152 */       Object[] arrayOfObject = { "timeout" };
/* 153 */       SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isKeepIdentity() {
/* 164 */     return this.keepIdentity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeepIdentity(boolean paramBoolean) {
/* 174 */     this.keepIdentity = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isKeepNulls() {
/* 185 */     return this.keepNulls;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setKeepNulls(boolean paramBoolean) {
/* 196 */     this.keepNulls = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isTableLock() {
/* 206 */     return this.tableLock;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTableLock(boolean paramBoolean) {
/* 216 */     this.tableLock = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isUseInternalTransaction() {
/* 226 */     return this.useInternalTransaction;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUseInternalTransaction(boolean paramBoolean) {
/* 236 */     this.useInternalTransaction = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCheckConstraints() {
/* 246 */     return this.checkConstraints;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCheckConstraints(boolean paramBoolean) {
/* 256 */     this.checkConstraints = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isFireTriggers() {
/* 266 */     return this.fireTriggers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFireTriggers(boolean paramBoolean) {
/* 276 */     this.fireTriggers = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isAllowEncryptedValueModifications() {
/* 281 */     return this.allowEncryptedValueModifications;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAllowEncryptedValueModifications(boolean paramBoolean) {
/* 286 */     this.allowEncryptedValueModifications = paramBoolean;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerBulkCopyOptions.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */