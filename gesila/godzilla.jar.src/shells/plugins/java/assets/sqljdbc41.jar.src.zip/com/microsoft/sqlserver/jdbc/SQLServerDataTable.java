/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ import java.util.UUID;
/*     */ import microsoft.sql.DateTimeOffset;
/*     */ 
/*     */ public final class SQLServerDataTable {
/*  14 */   int rowCount = 0;
/*  15 */   int columnCount = 0;
/*  16 */   Map<Integer, SQLServerDataColumn> columnMetadata = null;
/*  17 */   Map<Integer, Object[]> rows = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLServerDataTable() throws SQLServerException {
/*  26 */     this.columnMetadata = new LinkedHashMap<>();
/*  27 */     this.rows = (Map)new HashMap<>();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void clear() {
/*  32 */     this.rowCount = 0;
/*  33 */     this.columnCount = 0;
/*  34 */     this.columnMetadata.clear();
/*  35 */     this.rows.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized Iterator<Map.Entry<Integer, Object[]>> getIterator() {
/*  40 */     if (null != this.rows && null != this.rows.entrySet())
/*     */     {
/*  42 */       return this.rows.entrySet().iterator();
/*     */     }
/*  44 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addColumnMetadata(String paramString, int paramInt) throws SQLServerException {
/*  51 */     Util.checkDuplicateColumnName(paramString, this.columnMetadata);
/*  52 */     this.columnMetadata.put(Integer.valueOf(this.columnCount++), new SQLServerDataColumn(paramString, paramInt));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addColumnMetadata(SQLServerDataColumn paramSQLServerDataColumn) throws SQLServerException {
/*  58 */     Util.checkDuplicateColumnName(paramSQLServerDataColumn.columnName, this.columnMetadata);
/*  59 */     this.columnMetadata.put(Integer.valueOf(this.columnCount++), paramSQLServerDataColumn);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addRow(Object... paramVarArgs) throws SQLServerException {
/*     */     try {
/*  72 */       int i = this.columnMetadata.size();
/*     */       
/*  74 */       if (null != paramVarArgs && paramVarArgs.length > i) {
/*     */         
/*  76 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_moreDataInRowThanColumnInTVP"));
/*  77 */         Object[] arrayOfObject1 = new Object[0];
/*  78 */         throw new SQLServerException(null, messageFormat.format(arrayOfObject1), null, 0, false);
/*     */       } 
/*     */       
/*  81 */       Iterator<Map.Entry> iterator = this.columnMetadata.entrySet().iterator();
/*  82 */       Object[] arrayOfObject = new Object[i];
/*  83 */       byte b = 0;
/*  84 */       while (iterator.hasNext()) {
/*     */         boolean bool1; byte b1; BigDecimal bigDecimal;
/*  86 */         Object object = null;
/*     */ 
/*     */ 
/*     */         
/*  90 */         if (null != paramVarArgs && b < paramVarArgs.length && null != paramVarArgs[b])
/*  91 */           object = (null == paramVarArgs[b]) ? null : paramVarArgs[b]; 
/*  92 */         b++;
/*  93 */         Map.Entry entry = iterator.next();
/*  94 */         SQLServerDataColumn sQLServerDataColumn = (SQLServerDataColumn)entry.getValue();
/*  95 */         JDBCType jDBCType = JDBCType.of(((SQLServerDataColumn)entry.getValue()).javaSqlType);
/*     */         
/*  97 */         boolean bool2 = false;
/*  98 */         switch (jDBCType) {
/*     */           
/*     */           case BIGINT:
/* 101 */             arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Long.valueOf(Long.parseLong(object.toString()));
/*     */             continue;
/*     */           
/*     */           case BIT:
/* 105 */             arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Boolean.valueOf(Boolean.parseBoolean(object.toString()));
/*     */             continue;
/*     */           
/*     */           case INTEGER:
/* 109 */             arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Integer.valueOf(Integer.parseInt(object.toString()));
/*     */             continue;
/*     */           
/*     */           case SMALLINT:
/*     */           case TINYINT:
/* 114 */             arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Short.valueOf(Short.parseShort(object.toString()));
/*     */             continue;
/*     */           
/*     */           case DECIMAL:
/*     */           case NUMERIC:
/* 119 */             bigDecimal = null;
/* 120 */             if (null != object) {
/*     */               
/* 122 */               bigDecimal = new BigDecimal(object.toString());
/* 123 */               if (bigDecimal.scale() > sQLServerDataColumn.scale) {
/*     */                 
/* 125 */                 sQLServerDataColumn.scale = bigDecimal.scale();
/* 126 */                 bool2 = true;
/*     */               } 
/* 128 */               if (bigDecimal.precision() > sQLServerDataColumn.precision) {
/*     */                 
/* 130 */                 sQLServerDataColumn.precision = bigDecimal.precision();
/* 131 */                 bool2 = true;
/*     */               } 
/* 133 */               if (bool2)
/* 134 */                 this.columnMetadata.put((Integer)entry.getKey(), sQLServerDataColumn); 
/*     */             } 
/* 136 */             arrayOfObject[((Integer)entry.getKey()).intValue()] = bigDecimal;
/*     */             continue;
/*     */           
/*     */           case DOUBLE:
/* 140 */             arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Double.valueOf(Double.parseDouble(object.toString()));
/*     */             continue;
/*     */           
/*     */           case FLOAT:
/*     */           case REAL:
/* 145 */             arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : Float.valueOf(Float.parseFloat(object.toString()));
/*     */             continue;
/*     */           
/*     */           case TIMESTAMP_WITH_TIMEZONE:
/*     */           case TIME_WITH_TIMEZONE:
/* 150 */             DriverJDBCVersion.checkSupportsJDBC42();
/*     */ 
/*     */ 
/*     */           
/*     */           case DATE:
/*     */           case TIME:
/*     */           case TIMESTAMP:
/*     */           case DATETIMEOFFSET:
/* 158 */             if (null == object) {
/* 159 */               arrayOfObject[((Integer)entry.getKey()).intValue()] = null; continue;
/*     */             } 
/* 161 */             if (object instanceof Date) {
/* 162 */               arrayOfObject[((Integer)entry.getKey()).intValue()] = ((Date)object).toString(); continue;
/* 163 */             }  if (object instanceof DateTimeOffset) {
/* 164 */               arrayOfObject[((Integer)entry.getKey()).intValue()] = ((DateTimeOffset)object).toString(); continue;
/* 165 */             }  if (object instanceof OffsetDateTime) {
/* 166 */               arrayOfObject[((Integer)entry.getKey()).intValue()] = ((OffsetDateTime)object).toString(); continue;
/* 167 */             }  if (object instanceof OffsetTime) {
/* 168 */               arrayOfObject[((Integer)entry.getKey()).intValue()] = ((OffsetTime)object).toString(); continue;
/*     */             } 
/* 170 */             arrayOfObject[((Integer)entry.getKey()).intValue()] = (null == object) ? null : object;
/*     */             continue;
/*     */           
/*     */           case BINARY:
/*     */           case VARBINARY:
/* 175 */             bool1 = (null == object) ? true : false;
/* 176 */             b1 = bool1 ? 0 : ((byte[])object).length;
/*     */             
/* 178 */             if (b1 > sQLServerDataColumn.precision) {
/*     */               
/* 180 */               sQLServerDataColumn.precision = b1;
/* 181 */               this.columnMetadata.put((Integer)entry.getKey(), sQLServerDataColumn);
/*     */             } 
/* 183 */             arrayOfObject[((Integer)entry.getKey()).intValue()] = bool1 ? null : object;
/*     */             continue;
/*     */ 
/*     */           
/*     */           case CHAR:
/* 188 */             if (object instanceof UUID && object != null) {
/* 189 */               object = ((UUID)object).toString();
/*     */             }
/*     */           
/*     */           case VARCHAR:
/*     */           case NCHAR:
/*     */           case NVARCHAR:
/* 195 */             bool1 = (null == object) ? true : false;
/* 196 */             b1 = bool1 ? 0 : (2 * ((String)object).length());
/*     */             
/* 198 */             if (b1 > sQLServerDataColumn.precision) {
/*     */               
/* 200 */               sQLServerDataColumn.precision = b1;
/* 201 */               this.columnMetadata.put((Integer)entry.getKey(), sQLServerDataColumn);
/*     */             } 
/* 203 */             arrayOfObject[((Integer)entry.getKey()).intValue()] = bool1 ? null : object;
/*     */             continue;
/*     */         } 
/*     */         
/* 207 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedDataTypeTVP"));
/* 208 */         Object[] arrayOfObject1 = { jDBCType };
/* 209 */         throw new SQLServerException(null, messageFormat.format(arrayOfObject1), null, 0, false);
/*     */       } 
/*     */       
/* 212 */       this.rows.put(Integer.valueOf(this.rowCount++), arrayOfObject);
/*     */     }
/* 214 */     catch (NumberFormatException numberFormatException) {
/*     */       
/* 216 */       throw new SQLServerException(SQLServerException.getErrString("R_TVPInvalidColumnValue"), numberFormatException);
/*     */     }
/* 218 */     catch (ClassCastException classCastException) {
/*     */       
/* 220 */       throw new SQLServerException(SQLServerException.getErrString("R_TVPInvalidColumnValue"), classCastException);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized Map<Integer, SQLServerDataColumn> getColumnMetadata() {
/* 227 */     return this.columnMetadata;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerDataTable.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */