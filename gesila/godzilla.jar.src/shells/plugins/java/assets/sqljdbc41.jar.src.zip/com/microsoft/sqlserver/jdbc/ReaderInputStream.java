/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.CharBuffer;
/*     */ import java.nio.charset.Charset;
/*     */ import java.nio.charset.IllegalCharsetNameException;
/*     */ import java.nio.charset.UnsupportedCharsetException;
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ReaderInputStream
/*     */   extends InputStream
/*     */ {
/*     */   private final Reader reader;
/*     */   private final Charset charset;
/*     */   private final long readerLength;
/*  35 */   private long readerCharsRead = 0L;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean atEndOfStream = false;
/*     */ 
/*     */   
/*  42 */   private CharBuffer rawChars = null;
/*     */ 
/*     */   
/*     */   private static final int MAX_CHAR_BUFFER_SIZE = 4000;
/*     */   
/*  47 */   private static final ByteBuffer EMPTY_BUFFER = ByteBuffer.allocate(0);
/*  48 */   private ByteBuffer encodedChars = EMPTY_BUFFER;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final byte[] oneByte;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/*  82 */     assert null != this.reader;
/*  83 */     assert null != this.encodedChars;
/*     */ 
/*     */     
/*  86 */     if (0L == this.readerLength) {
/*  87 */       return 0;
/*     */     }
/*     */     
/*  90 */     if (this.encodedChars.remaining() > 0) {
/*  91 */       return this.encodedChars.remaining();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  96 */     if (this.reader.ready()) {
/*  97 */       return 1;
/*     */     }
/*     */ 
/*     */     
/* 101 */     return 0;
/*     */   }
/*     */   
/* 104 */   ReaderInputStream(Reader paramReader, String paramString, long paramLong) throws UnsupportedEncodingException { this.oneByte = new byte[1]; assert paramReader != null; assert paramString != null; assert -1L == paramLong || paramLong >= 0L; this.reader = paramReader; try { this.charset = Charset.forName(paramString); }
/*     */     catch (IllegalCharsetNameException illegalCharsetNameException) { throw new UnsupportedEncodingException(illegalCharsetNameException.getMessage()); }
/*     */     catch (UnsupportedCharsetException unsupportedCharsetException) { throw new UnsupportedEncodingException(unsupportedCharsetException.getMessage()); }
/* 107 */      this.readerLength = paramLong; } public int read() throws IOException { return (-1 == readInternal(this.oneByte, 0, this.oneByte.length)) ? -1 : this.oneByte[0]; }
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] paramArrayOfbyte) throws IOException {
/* 112 */     return readInternal(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 117 */     return readInternal(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   private int readInternal(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 122 */     assert null != paramArrayOfbyte;
/* 123 */     assert 0 <= paramInt1 && paramInt1 <= paramArrayOfbyte.length;
/* 124 */     assert 0 <= paramInt2 && paramInt2 <= paramArrayOfbyte.length;
/* 125 */     assert paramInt1 <= paramArrayOfbyte.length - paramInt2;
/*     */     
/* 127 */     if (0 == paramInt2) {
/* 128 */       return 0;
/*     */     }
/* 130 */     int i = 0;
/* 131 */     while (i < paramInt2 && encodeChars()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 136 */       int j = this.encodedChars.remaining();
/* 137 */       if (j > paramInt2 - i) {
/* 138 */         j = paramInt2 - i;
/*     */       }
/*     */ 
/*     */       
/* 142 */       assert j > 0;
/*     */       
/* 144 */       this.encodedChars.get(paramArrayOfbyte, paramInt1 + i, j);
/* 145 */       i += j;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 150 */     return (0 == i && this.atEndOfStream) ? -1 : i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean encodeChars() throws IOException {
/* 164 */     if (this.atEndOfStream) {
/* 165 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 170 */     if (this.encodedChars.hasRemaining()) {
/* 171 */       return true;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     if (null == this.rawChars || !this.rawChars.hasRemaining()) {
/*     */       
/* 183 */       if (null == this.rawChars) {
/*     */ 
/*     */         
/* 186 */         this.rawChars = CharBuffer.allocate((-1L == this.readerLength || this.readerLength > 4000L) ? 4000 : Math.max((int)this.readerLength, 1));
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */         
/* 193 */         this.rawChars.clear();
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 204 */       while (this.rawChars.hasRemaining()) {
/*     */         
/* 206 */         int i = this.rawChars.position();
/* 207 */         int j = 0;
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 212 */           j = this.reader.read(this.rawChars);
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 217 */         catch (Exception exception) {
/*     */           
/* 219 */           String str = exception.getMessage();
/* 220 */           if (null == str)
/* 221 */             str = SQLServerException.getErrString("R_streamReadReturnedInvalidValue"); 
/* 222 */           IOException iOException = new IOException(str);
/* 223 */           iOException.initCause(exception);
/* 224 */           throw iOException;
/*     */         } 
/*     */         
/* 227 */         if (j < -1 || 0 == j) {
/* 228 */           throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
/*     */         }
/* 230 */         if (-1 == j) {
/*     */ 
/*     */           
/* 233 */           if (this.rawChars.position() != i) {
/* 234 */             throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
/*     */           }
/*     */           
/* 237 */           if (-1L != this.readerLength && 0L != this.readerLength - this.readerCharsRead) {
/*     */             
/* 239 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
/* 240 */             throw new IOException(messageFormat.format(new Object[] { Long.valueOf(this.readerLength), Long.valueOf(this.readerCharsRead) }));
/*     */           } 
/*     */ 
/*     */           
/* 244 */           if (0 == this.rawChars.position()) {
/*     */             
/* 246 */             this.rawChars = null;
/* 247 */             this.atEndOfStream = true;
/* 248 */             return false;
/*     */           } 
/*     */ 
/*     */           
/*     */           break;
/*     */         } 
/*     */         
/* 255 */         assert j > 0;
/*     */ 
/*     */         
/* 258 */         if (j != this.rawChars.position() - i) {
/* 259 */           throw new IOException(SQLServerException.getErrString("R_streamReadReturnedInvalidValue"));
/*     */         }
/*     */         
/* 262 */         if (-1L != this.readerLength && j > this.readerLength - this.readerCharsRead) {
/*     */           
/* 264 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
/* 265 */           throw new IOException(messageFormat.format(new Object[] { Long.valueOf(this.readerLength), Long.valueOf(this.readerCharsRead) }));
/*     */         } 
/*     */         
/* 268 */         this.readerCharsRead += j;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 273 */       this.rawChars.flip();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 279 */     if (!this.rawChars.hasRemaining()) {
/* 280 */       return false;
/*     */     }
/*     */     
/* 283 */     this.encodedChars = this.charset.encode(this.rawChars);
/* 284 */     return true;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ReaderInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */