/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PLPInputStream
/*     */   extends BaseInputStream
/*     */ {
/*     */   static final long PLP_NULL = -1L;
/*     */   static final long UNKNOWN_PLP_LEN = -2L;
/*     */   static final int PLP_TERMINATOR = 0;
/*  23 */   private static final byte[] EMPTY_PLP_BYTES = new byte[0];
/*     */   
/*     */   int payloadLength;
/*     */   
/*     */   private static final int PLP_EOS = -1;
/*     */   
/*     */   private int currentChunkRemain;
/*     */   
/*     */   private int markedChunkRemain;
/*     */   
/*  33 */   private int leftOverReadLimit = 0;
/*     */   
/*  35 */   private byte[] oneByteArray = new byte[1];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final boolean isNull(TDSReader paramTDSReader) throws SQLServerException {
/*  42 */     TDSReaderMark tDSReaderMark = paramTDSReader.mark();
/*     */     
/*     */     try {
/*  45 */       return (null == makeTempStream(paramTDSReader, false, (ServerDTVImpl)null));
/*     */     }
/*     */     finally {
/*     */       
/*  49 */       paramTDSReader.reset(tDSReaderMark);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final PLPInputStream makeTempStream(TDSReader paramTDSReader, boolean paramBoolean, ServerDTVImpl paramServerDTVImpl) throws SQLServerException {
/*  59 */     return makeStream(paramTDSReader, paramBoolean, paramBoolean, paramServerDTVImpl);
/*     */   }
/*     */ 
/*     */   
/*     */   static final PLPInputStream makeStream(TDSReader paramTDSReader, InputStreamGetterArgs paramInputStreamGetterArgs, ServerDTVImpl paramServerDTVImpl) throws SQLServerException {
/*  64 */     PLPInputStream pLPInputStream = makeStream(paramTDSReader, paramInputStreamGetterArgs.isAdaptive, paramInputStreamGetterArgs.isStreaming, paramServerDTVImpl);
/*  65 */     if (null != pLPInputStream)
/*  66 */       pLPInputStream.setLoggingInfo(paramInputStreamGetterArgs.logContext); 
/*  67 */     return pLPInputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static final PLPInputStream makeStream(TDSReader paramTDSReader, boolean paramBoolean1, boolean paramBoolean2, ServerDTVImpl paramServerDTVImpl) throws SQLServerException {
/*  73 */     long l = paramTDSReader.readLong();
/*     */ 
/*     */     
/*  76 */     if (-1L == l) {
/*  77 */       return null;
/*     */     }
/*  79 */     return new PLPInputStream(paramTDSReader, l, paramBoolean1, paramBoolean2, paramServerDTVImpl);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PLPInputStream(TDSReader paramTDSReader, long paramLong, boolean paramBoolean1, boolean paramBoolean2, ServerDTVImpl paramServerDTVImpl) throws SQLServerException {
/*  88 */     super(paramTDSReader, paramBoolean1, paramBoolean2, paramServerDTVImpl);
/*  89 */     this.payloadLength = (-2L != paramLong) ? (int)paramLong : -1;
/*  90 */     this.currentChunkRemain = this.markedChunkRemain = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes() throws SQLServerException {
/*     */     byte[] arrayOfByte;
/* 104 */     readBytesInternal((byte[])null, 0, 0);
/*     */     
/* 106 */     if (-1 == this.currentChunkRemain) {
/*     */       
/* 108 */       arrayOfByte = EMPTY_PLP_BYTES;
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 115 */       arrayOfByte = new byte[(-1 != this.payloadLength) ? this.payloadLength : this.currentChunkRemain];
/*     */       
/* 117 */       int i = 0;
/* 118 */       while (-1 != this.currentChunkRemain) {
/*     */ 
/*     */ 
/*     */         
/* 122 */         if (arrayOfByte.length == i) {
/*     */           
/* 124 */           byte[] arrayOfByte1 = new byte[i + this.currentChunkRemain];
/* 125 */           System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i);
/* 126 */           arrayOfByte = arrayOfByte1;
/*     */         } 
/*     */         
/* 129 */         i += readBytesInternal(arrayOfByte, i, this.currentChunkRemain);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 136 */       close();
/*     */     }
/* 138 */     catch (IOException iOException) {
/*     */       
/* 140 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, iOException.getMessage(), (String)null, true);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long skip(long paramLong) throws IOException {
/* 159 */     checkClosed();
/* 160 */     if (paramLong < 0L) return 0L; 
/* 161 */     if (paramLong > 2147483647L) {
/* 162 */       paramLong = 2147483647L;
/*     */     }
/* 164 */     long l = readBytes((byte[])null, 0, (int)paramLong);
/*     */ 
/*     */     
/* 167 */     if (-1L == l) {
/* 168 */       return 0L;
/*     */     }
/* 170 */     return l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int available() throws IOException {
/* 182 */     checkClosed();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 188 */       if (0 == this.currentChunkRemain) {
/* 189 */         readBytesInternal((byte[])null, 0, 0);
/*     */       }
/* 191 */       if (-1 == this.currentChunkRemain) {
/* 192 */         return 0;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 197 */       int i = this.tdsReader.available();
/* 198 */       if (i > this.currentChunkRemain) {
/* 199 */         i = this.currentChunkRemain;
/*     */       }
/* 201 */       return i;
/*     */     }
/* 203 */     catch (SQLServerException sQLServerException) {
/*     */       
/* 205 */       throw new IOException(sQLServerException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read() throws IOException {
/* 218 */     checkClosed();
/*     */     
/* 220 */     if (-1 != readBytes(this.oneByteArray, 0, 1))
/* 221 */       return this.oneByteArray[0] & 0xFF; 
/* 222 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] paramArrayOfbyte) throws IOException {
/* 234 */     if (null == paramArrayOfbyte) {
/* 235 */       throw new NullPointerException();
/*     */     }
/* 237 */     checkClosed();
/*     */     
/* 239 */     return readBytes(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 253 */     if (null == paramArrayOfbyte) {
/* 254 */       throw new NullPointerException();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 259 */     if (paramInt1 < 0 || paramInt2 < 0 || paramInt1 + paramInt2 > paramArrayOfbyte.length) {
/* 260 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 262 */     checkClosed();
/*     */     
/* 264 */     return readBytes(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int readBytes(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 280 */     if (0 == paramInt2) {
/* 281 */       return 0;
/*     */     }
/*     */     
/*     */     try {
/* 285 */       return readBytesInternal(paramArrayOfbyte, paramInt1, paramInt2);
/*     */     }
/* 287 */     catch (SQLServerException sQLServerException) {
/*     */       
/* 289 */       throw new IOException(sQLServerException.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int readBytesInternal(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLServerException {
/* 298 */     if (-1 == this.currentChunkRemain) {
/* 299 */       return -1;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 305 */     int i = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 311 */       if (0 == this.currentChunkRemain) {
/*     */         
/* 313 */         this.currentChunkRemain = (int)this.tdsReader.readUnsignedInt();
/* 314 */         assert this.currentChunkRemain >= 0;
/* 315 */         if (0 == this.currentChunkRemain) {
/*     */           
/* 317 */           this.currentChunkRemain = -1;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 322 */       if (i == paramInt2) {
/*     */         break;
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 328 */       int j = paramInt2 - i;
/* 329 */       if (j > this.currentChunkRemain) {
/* 330 */         j = this.currentChunkRemain;
/*     */       }
/*     */       
/* 333 */       if (null == paramArrayOfbyte) {
/* 334 */         this.tdsReader.skip(j);
/*     */       } else {
/* 336 */         this.tdsReader.readBytes(paramArrayOfbyte, paramInt1 + i, j);
/*     */       } 
/* 338 */       i += j;
/* 339 */       this.currentChunkRemain -= j;
/*     */     } 
/*     */     
/* 342 */     if (i > 0) {
/*     */       
/* 344 */       if (this.isReadLimitSet && this.leftOverReadLimit > 0) {
/*     */         
/* 346 */         this.leftOverReadLimit -= i;
/* 347 */         if (this.leftOverReadLimit < 0)
/* 348 */           clearCurrentMark(); 
/*     */       } 
/* 350 */       return i;
/*     */     } 
/*     */     
/* 353 */     if (-1 == this.currentChunkRemain) {
/* 354 */       return -1;
/*     */     }
/* 356 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void mark(int paramInt) {
/* 367 */     if (null != this.tdsReader && paramInt > 0) {
/*     */       
/* 369 */       this.currentMark = this.tdsReader.mark();
/* 370 */       this.markedChunkRemain = this.currentChunkRemain;
/* 371 */       this.leftOverReadLimit = paramInt;
/* 372 */       setReadLimit(paramInt);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 380 */     if (null == this.tdsReader) {
/*     */       return;
/*     */     }
/* 383 */     while (skip(this.tdsReader.getConnection().getTDSPacketSize()) != 0L);
/*     */ 
/*     */     
/* 386 */     closeHelper();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reset() throws IOException {
/* 395 */     resetHelper();
/* 396 */     this.leftOverReadLimit = this.readLimit;
/* 397 */     this.currentChunkRemain = this.markedChunkRemain;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/PLPInputStream.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */