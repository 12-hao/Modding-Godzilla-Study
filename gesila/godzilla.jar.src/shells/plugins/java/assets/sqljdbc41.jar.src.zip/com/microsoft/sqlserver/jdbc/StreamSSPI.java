/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamSSPI
/*    */   extends StreamPacket
/*    */ {
/*    */   byte[] sspiBlob;
/*    */   
/*    */   StreamSSPI() {
/* 16 */     super(237);
/*    */   }
/*    */ 
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
/* 21 */     if (237 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
/* 22 */     int i = paramTDSReader.readUnsignedShort();
/* 23 */     this.sspiBlob = new byte[i];
/* 24 */     paramTDSReader.readBytes(this.sspiBlob, 0, i);
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/StreamSSPI.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */