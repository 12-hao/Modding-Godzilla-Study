/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import javax.transaction.xa.Xid;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class XidImpl
/*    */   implements Xid
/*    */ {
/*    */   private final int formatId;
/*    */   private final byte[] gtrid;
/*    */   private final byte[] bqual;
/*    */   private final String traceID;
/*    */   
/*    */   public XidImpl(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/* 44 */     this.formatId = paramInt;
/* 45 */     this.gtrid = paramArrayOfbyte1;
/* 46 */     this.bqual = paramArrayOfbyte2;
/* 47 */     this.traceID = " XID:" + xidDisplay(this);
/*    */   }
/*    */   
/*    */   public byte[] getGlobalTransactionId() {
/* 51 */     return this.gtrid;
/*    */   }
/*    */   
/*    */   public byte[] getBranchQualifier() {
/* 55 */     return this.bqual;
/*    */   }
/*    */   
/*    */   public int getFormatId() {
/* 59 */     return this.formatId;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 63 */     return this.traceID;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   static String xidDisplay(Xid paramXid) {
/* 69 */     if (null == paramXid) return "(null)"; 
/* 70 */     StringBuilder stringBuilder = new StringBuilder(300);
/* 71 */     stringBuilder.append("formatId=");
/* 72 */     stringBuilder.append(paramXid.getFormatId());
/* 73 */     stringBuilder.append(" gtrid=");
/* 74 */     stringBuilder.append(Util.byteToHexDisplayString(paramXid.getGlobalTransactionId()));
/* 75 */     stringBuilder.append(" bqual=");
/* 76 */     stringBuilder.append(Util.byteToHexDisplayString(paramXid.getBranchQualifier()));
/* 77 */     return stringBuilder.toString();
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/XidImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */