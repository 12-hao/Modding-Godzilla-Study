/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum SQLServerStatementColumnEncryptionSetting
/*    */ {
/*  7 */   UseConnectionSetting,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 12 */   Enabled,
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 18 */   ResultSetOnly,
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 23 */   Disabled;
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerStatementColumnEncryptionSetting.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */