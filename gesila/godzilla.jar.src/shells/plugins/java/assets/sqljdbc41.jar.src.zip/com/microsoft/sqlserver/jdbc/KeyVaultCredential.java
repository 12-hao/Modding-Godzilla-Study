/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import com.microsoft.azure.keyvault.authentication.KeyVaultCredentials;
/*    */ import com.microsoft.windowsazure.core.pipeline.filter.ServiceRequestContext;
/*    */ import java.util.Map;
/*    */ import org.apache.http.Header;
/*    */ import org.apache.http.message.BasicHeader;
/*    */ 
/*    */ 
/*    */ class KeyVaultCredential
/*    */   extends KeyVaultCredentials
/*    */ {
/* 13 */   private final String accessTokenType = "Bearer";
/*    */   
/* 15 */   SQLServerKeyVaultAuthenticationCallback authenticationCallback = null;
/* 16 */   String clientId = null;
/* 17 */   String clientKey = null;
/* 18 */   String accessToken = null;
/*    */   
/*    */   KeyVaultCredential(SQLServerKeyVaultAuthenticationCallback paramSQLServerKeyVaultAuthenticationCallback) {
/* 21 */     this.authenticationCallback = paramSQLServerKeyVaultAuthenticationCallback;
/*    */   }
/*    */ 
/*    */   
/*    */   public Header doAuthenticate(ServiceRequestContext paramServiceRequestContext, Map<String, String> paramMap) {
/* 26 */     assert null != paramMap;
/*    */     
/* 28 */     String str1 = paramMap.get("authorization");
/* 29 */     String str2 = paramMap.get("resource");
/*    */     
/* 31 */     this.accessToken = this.authenticationCallback.getAccessToken(str1, str2, "");
/* 32 */     return (Header)new BasicHeader("Authorization", "Bearer " + this.accessToken);
/*    */   }
/*    */   
/*    */   void setAccessToken(String paramString) {
/* 36 */     this.accessToken = paramString;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/KeyVaultCredential.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */