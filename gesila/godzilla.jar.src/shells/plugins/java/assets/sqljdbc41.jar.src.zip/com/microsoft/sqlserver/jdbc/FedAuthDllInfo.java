/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class FedAuthDllInfo
/*    */ {
/* 10 */   byte[] accessTokenBytes = null;
/* 11 */   long expiresIn = 0L;
/*    */   
/*    */   FedAuthDllInfo(byte[] paramArrayOfbyte, long paramLong) {
/* 14 */     this.accessTokenBytes = paramArrayOfbyte;
/* 15 */     this.expiresIn = paramLong;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/FedAuthDllInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */