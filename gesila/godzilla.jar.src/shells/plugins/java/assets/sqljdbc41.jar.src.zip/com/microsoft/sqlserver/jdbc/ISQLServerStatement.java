package com.microsoft.sqlserver.jdbc;

import java.sql.Statement;

public interface ISQLServerStatement extends Statement {
  void setResponseBuffering(String paramString) throws SQLServerException;
  
  String getResponseBuffering() throws SQLServerException;
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ISQLServerStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */