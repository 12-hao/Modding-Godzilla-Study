/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class AppDTVImpl
/*      */   extends DTVImpl
/*      */ {
/* 2214 */   private JDBCType jdbcType = JDBCType.UNKNOWN;
/*      */   
/*      */   private Object value;
/*      */   private JavaType javaType;
/*      */   private StreamSetterArgs streamSetterArgs;
/*      */   private Calendar cal;
/*      */   private Integer scale;
/*      */   private boolean forceEncrypt;
/*      */   
/*      */   final void skipValue(TypeInfo paramTypeInfo, TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException {
/*      */     assert false;
/*      */   }
/*      */   
/*      */   final void initFromCompressedNull() {
/*      */     assert false;
/*      */   }
/*      */   
/*      */   final class SetValueOp
/*      */     extends DTVExecuteOp
/*      */   {
/*      */     private final SQLCollation collation;
/*      */     private final SQLServerConnection con;
/*      */     
/*      */     SetValueOp(SQLCollation param1SQLCollation, SQLServerConnection param1SQLServerConnection) {
/* 2238 */       this.collation = param1SQLCollation;
/* 2239 */       this.con = param1SQLServerConnection;
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, String param1String) throws SQLServerException {
/* 2244 */       JDBCType jDBCType = param1DTV.getJdbcType();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2253 */       if (JDBCType.DECIMAL == jDBCType || JDBCType.NUMERIC == jDBCType || JDBCType.MONEY == jDBCType || JDBCType.SMALLMONEY == jDBCType) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2258 */         assert null != param1String;
/*      */ 
/*      */         
/*      */         try {
/* 2262 */           param1DTV.setValue(new BigDecimal(param1String), JavaType.BIGDECIMAL);
/*      */         }
/* 2264 */         catch (NumberFormatException numberFormatException) {
/*      */           
/* 2266 */           DataTypes.throwConversionError("String", jDBCType.toString());
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 2274 */       else if (jDBCType.isBinary()) {
/*      */         
/* 2276 */         assert null != param1String;
/* 2277 */         param1DTV.setValue(ParameterUtils.HexToBin(param1String), JavaType.BYTEARRAY);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 2284 */       else if (null != this.collation && (JDBCType.CHAR == jDBCType || JDBCType.VARCHAR == jDBCType || JDBCType.LONGVARCHAR == jDBCType || JDBCType.CLOB == jDBCType)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2290 */         byte[] arrayOfByte = null;
/*      */         
/* 2292 */         if (null != param1String) {
/*      */           
/*      */           try {
/*      */             
/* 2296 */             arrayOfByte = param1String.getBytes(this.collation.getCharset());
/*      */           }
/* 2298 */           catch (UnsupportedEncodingException unsupportedEncodingException) {
/*      */             
/* 2300 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
/* 2301 */             Object[] arrayOfObject = { new String(unsupportedEncodingException.getMessage()) };
/* 2302 */             SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*      */           } 
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2311 */         param1DTV.setValue(arrayOfByte, JavaType.BYTEARRAY);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Clob param1Clob) throws SQLServerException {
/* 2318 */       assert null != param1Clob;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 2327 */         DataTypes.getCheckedLength(this.con, param1DTV.getJdbcType(), param1Clob.length(), false);
/*      */       }
/* 2329 */       catch (SQLException sQLException) {
/*      */         
/* 2331 */         SQLServerException.makeFromDriverError(this.con, null, sQLException.getMessage(), null, false);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, SQLServerSQLXML param1SQLServerSQLXML) throws SQLServerException {}
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Byte param1Byte) throws SQLServerException {}
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Integer param1Integer) throws SQLServerException {}
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Time param1Time) throws SQLServerException {
/* 2350 */       if (param1DTV.getJdbcType().isTextual()) {
/*      */         
/* 2352 */         assert param1Time != null : "value is null";
/* 2353 */         param1DTV.setValue(param1Time.toString(), JavaType.STRING);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
/* 2359 */       if (param1DTV.getJdbcType().isTextual()) {
/*      */         
/* 2361 */         assert param1Date != null : "value is null";
/* 2362 */         param1DTV.setValue(param1Date.toString(), JavaType.STRING);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Timestamp param1Timestamp) throws SQLServerException {
/* 2368 */       if (param1DTV.getJdbcType().isTextual()) {
/*      */         
/* 2370 */         assert param1Timestamp != null : "value is null";
/* 2371 */         param1DTV.setValue(param1Timestamp.toString(), JavaType.STRING);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Date param1Date) throws SQLServerException {
/* 2377 */       if (param1DTV.getJdbcType().isTextual()) {
/*      */         
/* 2379 */         assert param1Date != null : "value is null";
/* 2380 */         param1DTV.setValue(param1Date.toString(), JavaType.STRING);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, LocalDate param1LocalDate) throws SQLServerException {
/* 2386 */       if (param1DTV.getJdbcType().isTextual()) {
/*      */         
/* 2388 */         assert param1LocalDate != null : "value is null";
/* 2389 */         param1DTV.setValue(param1LocalDate.toString(), JavaType.STRING);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, LocalTime param1LocalTime) throws SQLServerException {
/* 2395 */       if (param1DTV.getJdbcType().isTextual()) {
/*      */         
/* 2397 */         assert param1LocalTime != null : "value is null";
/* 2398 */         param1DTV.setValue(param1LocalTime.toString(), JavaType.STRING);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, LocalDateTime param1LocalDateTime) throws SQLServerException {
/* 2404 */       if (param1DTV.getJdbcType().isTextual()) {
/*      */         
/* 2406 */         assert param1LocalDateTime != null : "value is null";
/* 2407 */         param1DTV.setValue(param1LocalDateTime.toString(), JavaType.STRING);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, OffsetTime param1OffsetTime) throws SQLServerException {
/* 2413 */       if (param1DTV.getJdbcType().isTextual()) {
/*      */         
/* 2415 */         assert param1OffsetTime != null : "value is null";
/* 2416 */         param1DTV.setValue(param1OffsetTime.toString(), JavaType.STRING);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, OffsetDateTime param1OffsetDateTime) throws SQLServerException {
/* 2422 */       if (param1DTV.getJdbcType().isTextual()) {
/*      */         
/* 2424 */         assert param1OffsetDateTime != null : "value is null";
/* 2425 */         param1DTV.setValue(param1OffsetDateTime.toString(), JavaType.STRING);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Calendar param1Calendar) throws SQLServerException {
/* 2431 */       if (param1DTV.getJdbcType().isTextual()) {
/*      */         
/* 2433 */         assert param1Calendar != null : "value is null";
/* 2434 */         param1DTV.setValue(param1Calendar.toString(), JavaType.STRING);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, DateTimeOffset param1DateTimeOffset) throws SQLServerException {
/* 2440 */       if (param1DTV.getJdbcType().isTextual()) {
/*      */         
/* 2442 */         assert param1DateTimeOffset != null : "value is null";
/* 2443 */         param1DTV.setValue(param1DateTimeOffset.toString(), JavaType.STRING);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, TVP param1TVP) throws SQLServerException {}
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Float param1Float) throws SQLServerException {}
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Double param1Double) throws SQLServerException {}
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, BigDecimal param1BigDecimal) throws SQLServerException {
/* 2462 */       if (null != param1BigDecimal) {
/*      */         
/* 2464 */         Integer integer = param1DTV.getScale();
/* 2465 */         if (null != integer && integer.intValue() != param1BigDecimal.scale()) {
/* 2466 */           param1BigDecimal = param1BigDecimal.setScale(integer.intValue(), 1);
/*      */         }
/*      */       } 
/* 2469 */       param1DTV.setValue(param1BigDecimal, JavaType.BIGDECIMAL);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Long param1Long) throws SQLServerException {}
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, BigInteger param1BigInteger) throws SQLServerException {}
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Short param1Short) throws SQLServerException {}
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Boolean param1Boolean) throws SQLServerException {}
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, byte[] param1ArrayOfbyte) throws SQLServerException {}
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Blob param1Blob) throws SQLServerException {
/* 2494 */       assert null != param1Blob;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 2503 */         DataTypes.getCheckedLength(this.con, param1DTV.getJdbcType(), param1Blob.length(), false);
/*      */       }
/* 2505 */       catch (SQLException sQLException) {
/*      */         
/* 2507 */         SQLServerException.makeFromDriverError(this.con, null, sQLException.getMessage(), null, false);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, InputStream param1InputStream) throws SQLServerException {
/* 2513 */       DataTypes.getCheckedLength(this.con, param1DTV.getJdbcType(), param1DTV.getStreamSetterArgs().getLength(), true);
/*      */ 
/*      */       
/* 2516 */       if (JDBCType.NCHAR == AppDTVImpl.this.jdbcType || JDBCType.NVARCHAR == AppDTVImpl.this.jdbcType || JDBCType.LONGNVARCHAR == AppDTVImpl.this.jdbcType) {
/*      */ 
/*      */ 
/*      */         
/* 2520 */         InputStreamReader inputStreamReader = null;
/*      */         
/*      */         try {
/* 2523 */           inputStreamReader = new InputStreamReader(param1InputStream, "US-ASCII");
/*      */         }
/* 2525 */         catch (UnsupportedEncodingException unsupportedEncodingException) {
/*      */           
/* 2527 */           throw new SQLServerException(null, unsupportedEncodingException.getMessage(), null, 0, true);
/*      */         } 
/*      */         
/* 2530 */         param1DTV.setValue(inputStreamReader, JavaType.READER);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2537 */         execute(param1DTV, inputStreamReader);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     void execute(DTV param1DTV, Reader param1Reader) throws SQLServerException {
/* 2544 */       assert null != param1Reader;
/*      */       
/* 2546 */       JDBCType jDBCType = param1DTV.getJdbcType();
/* 2547 */       long l = DataTypes.getCheckedLength(this.con, param1DTV.getJdbcType(), param1DTV.getStreamSetterArgs().getLength(), true);
/*      */       
/* 2549 */       if (jDBCType.isBinary()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2556 */         String str = DDC.convertReaderToString(param1Reader, (int)l);
/*      */ 
/*      */ 
/*      */         
/* 2560 */         if (-1L != l && str.length() != l) {
/*      */           
/* 2562 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_mismatchedStreamLength"));
/* 2563 */           Object[] arrayOfObject = { Long.valueOf(l), Integer.valueOf(str.length()) };
/* 2564 */           SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
/*      */         } 
/*      */         
/* 2567 */         param1DTV.setValue(str, JavaType.STRING);
/* 2568 */         execute(param1DTV, str);
/*      */ 
/*      */       
/*      */       }
/* 2572 */       else if (null != this.collation && (JDBCType.CHAR == jDBCType || JDBCType.VARCHAR == jDBCType || JDBCType.LONGVARCHAR == jDBCType || JDBCType.CLOB == jDBCType)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2578 */         ReaderInputStream readerInputStream = null;
/*      */ 
/*      */         
/*      */         try {
/* 2582 */           readerInputStream = new ReaderInputStream(param1Reader, this.collation.getCharset(), l);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 2587 */         catch (UnsupportedEncodingException unsupportedEncodingException) {
/*      */           
/* 2589 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_encodingErrorWritingTDS"));
/* 2590 */           Object[] arrayOfObject = { new String(unsupportedEncodingException.getMessage()) };
/* 2591 */           SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2599 */         param1DTV.setValue(readerInputStream, JavaType.INPUTSTREAM);
/*      */ 
/*      */         
/* 2602 */         param1DTV.setStreamSetterArgs(new StreamSetterArgs(StreamType.CHARACTER, -1L));
/* 2603 */         execute(param1DTV, readerInputStream);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setValue(DTV paramDTV, SQLCollation paramSQLCollation, JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger, SQLServerConnection paramSQLServerConnection, boolean paramBoolean) throws SQLServerException {
/* 2622 */     paramDTV.setValue(paramObject, paramJavaType);
/* 2623 */     paramDTV.setJdbcType(paramJDBCType);
/* 2624 */     paramDTV.setStreamSetterArgs(paramStreamSetterArgs);
/* 2625 */     paramDTV.setCalendar(paramCalendar);
/* 2626 */     paramDTV.setScale(paramInteger);
/* 2627 */     paramDTV.setForceEncrypt(paramBoolean);
/* 2628 */     paramDTV.executeOp(new SetValueOp(paramSQLCollation, paramSQLServerConnection));
/*      */   }
/*      */ 
/*      */   
/*      */   void setValue(Object paramObject, JavaType paramJavaType) {
/* 2633 */     this.value = paramObject;
/* 2634 */     this.javaType = paramJavaType;
/*      */   }
/*      */ 
/*      */   
/*      */   void setStreamSetterArgs(StreamSetterArgs paramStreamSetterArgs) {
/* 2639 */     this.streamSetterArgs = paramStreamSetterArgs;
/*      */   }
/*      */ 
/*      */   
/*      */   void setCalendar(Calendar paramCalendar) {
/* 2644 */     this.cal = paramCalendar;
/*      */   }
/*      */ 
/*      */   
/*      */   void setScale(Integer paramInteger) {
/* 2649 */     this.scale = paramInteger;
/*      */   }
/*      */ 
/*      */   
/*      */   void setForceEncrypt(boolean paramBoolean) {
/* 2654 */     this.forceEncrypt = paramBoolean;
/*      */   }
/*      */   
/* 2657 */   StreamSetterArgs getStreamSetterArgs() { return this.streamSetterArgs; }
/* 2658 */   Calendar getCalendar() { return this.cal; } Integer getScale() {
/* 2659 */     return this.scale;
/*      */   }
/*      */   
/*      */   boolean isNull() {
/* 2663 */     return (null == this.value);
/*      */   }
/*      */ 
/*      */   
/*      */   void setJdbcType(JDBCType paramJDBCType) {
/* 2668 */     this.jdbcType = paramJDBCType;
/*      */   }
/*      */ 
/*      */   
/*      */   JDBCType getJdbcType() {
/* 2673 */     return this.jdbcType;
/*      */   }
/*      */ 
/*      */   
/*      */   JavaType getJavaType() {
/* 2678 */     return this.javaType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getValue(DTV paramDTV, JDBCType paramJDBCType, int paramInt, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TypeInfo paramTypeInfo, CryptoMetadata paramCryptoMetadata, TDSReader paramTDSReader) throws SQLServerException {
/* 2691 */     if (this.jdbcType != paramJDBCType) {
/* 2692 */       DataTypes.throwConversionError(this.jdbcType.toString(), paramJDBCType.toString());
/*      */     }
/* 2694 */     return this.value;
/*      */   }
/*      */ 
/*      */   
/*      */   Object getSetterValue() {
/* 2699 */     return this.value;
/*      */   }
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/AppDTVImpl.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */