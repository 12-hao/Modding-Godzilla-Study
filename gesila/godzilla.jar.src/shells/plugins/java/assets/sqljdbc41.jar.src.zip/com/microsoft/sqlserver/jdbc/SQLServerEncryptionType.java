/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum SQLServerEncryptionType
/*    */ {
/* 11 */   Deterministic((byte)1),
/* 12 */   Randomized((byte)2),
/* 13 */   PlainText((byte)0);
/*    */   
/*    */   byte value;
/*    */   
/*    */   SQLServerEncryptionType(byte paramByte) {
/* 18 */     this.value = paramByte;
/*    */   }
/*    */ 
/*    */   
/*    */   byte getValue() {
/* 23 */     return this.value;
/*    */   }
/*    */ 
/*    */   
/*    */   static SQLServerEncryptionType of(byte paramByte) throws SQLServerException {
/* 28 */     for (SQLServerEncryptionType sQLServerEncryptionType : values()) {
/* 29 */       if (paramByte == sQLServerEncryptionType.value) {
/* 30 */         return sQLServerEncryptionType;
/*    */       }
/*    */     } 
/* 33 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownColumnEncryptionType"));
/* 34 */     Object[] arrayOfObject = { Byte.valueOf(paramByte) };
/* 35 */     SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, true);
/*    */ 
/*    */     
/* 38 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerEncryptionType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */