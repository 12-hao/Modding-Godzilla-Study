/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.logging.Level;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CacheClear
/*    */   implements Runnable
/*    */ {
/*    */   private String keylookupValue;
/* 19 */   private static Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.CacheClear");
/*    */ 
/*    */ 
/*    */   
/*    */   CacheClear(String paramString) {
/* 24 */     this.keylookupValue = paramString;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 31 */     synchronized (SQLServerSymmetricKeyCache.lock) {
/*    */       
/* 33 */       SQLServerSymmetricKeyCache sQLServerSymmetricKeyCache = SQLServerSymmetricKeyCache.getInstance();
/* 34 */       if (sQLServerSymmetricKeyCache.getCache().containsKey(this.keylookupValue)) {
/*    */         
/* 36 */         ((SQLServerSymmetricKey)sQLServerSymmetricKeyCache.getCache().get(this.keylookupValue)).zeroOutKey();
/* 37 */         sQLServerSymmetricKeyCache.getCache().remove(this.keylookupValue);
/* 38 */         if (aeLogger.isLoggable(Level.FINE))
/*    */         {
/* 40 */           aeLogger.fine("Removed encryption key from cache...");
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/CacheClear.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */