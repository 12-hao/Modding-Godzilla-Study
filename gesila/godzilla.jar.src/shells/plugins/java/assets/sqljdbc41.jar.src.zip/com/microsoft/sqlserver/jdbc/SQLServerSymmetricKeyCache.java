/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.ThreadFactory;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.bind.DatatypeConverter;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class SQLServerSymmetricKeyCache
/*     */ {
/*  53 */   static Object lock = new Object();
/*     */   private final ConcurrentHashMap<String, SQLServerSymmetricKey> cache;
/*  55 */   private static final SQLServerSymmetricKeyCache instance = new SQLServerSymmetricKeyCache();
/*  56 */   private static ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1, new ThreadFactory()
/*     */       {
/*     */ 
/*     */ 
/*     */         
/*     */         public Thread newThread(Runnable param1Runnable)
/*     */         {
/*  63 */           Thread thread = Executors.defaultThreadFactory().newThread(param1Runnable);
/*  64 */           thread.setDaemon(true);
/*  65 */           return thread;
/*     */         }
/*     */       });
/*     */ 
/*     */   
/*  70 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerSymmetricKeyCache");
/*     */ 
/*     */ 
/*     */   
/*     */   private SQLServerSymmetricKeyCache() {
/*  75 */     this.cache = new ConcurrentHashMap<>();
/*     */   }
/*     */ 
/*     */   
/*     */   static SQLServerSymmetricKeyCache getInstance() {
/*  80 */     return instance;
/*     */   }
/*     */ 
/*     */   
/*     */   ConcurrentHashMap<String, SQLServerSymmetricKey> getCache() {
/*  85 */     return this.cache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerSymmetricKey getKey(EncryptionKeyInfo paramEncryptionKeyInfo, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/*  96 */     SQLServerSymmetricKey sQLServerSymmetricKey = null;
/*  97 */     synchronized (lock) {
/*     */       
/*  99 */       String str1 = paramSQLServerConnection.getTrustedServerNameAE();
/* 100 */       assert null != str1 : "serverName should not be null in getKey.";
/*     */       
/* 102 */       StringBuffer stringBuffer = new StringBuffer(str1);
/* 103 */       String str2 = null;
/* 104 */       stringBuffer.append(":");
/*     */ 
/*     */       
/*     */       try {
/* 108 */         stringBuffer.append(DatatypeConverter.printBase64Binary((new String(paramEncryptionKeyInfo.encryptedKey, "UTF-8")).getBytes()));
/*     */       }
/* 110 */       catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */         
/* 112 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/* 113 */         Object[] arrayOfObject = { "UTF-8" };
/* 114 */         throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */       } 
/*     */       
/* 117 */       stringBuffer.append(":");
/* 118 */       stringBuffer.append(paramEncryptionKeyInfo.keyStoreName);
/* 119 */       str2 = stringBuffer.toString();
/* 120 */       stringBuffer.setLength(0);
/*     */       
/* 122 */       if (aeLogger.isLoggable(Level.FINE))
/*     */       {
/* 124 */         aeLogger.fine("Checking trusted master key path...");
/*     */       }
/* 126 */       Boolean[] arrayOfBoolean = new Boolean[1];
/* 127 */       List<String> list = SQLServerConnection.getColumnEncryptionTrustedMasterKeyPaths(str1, arrayOfBoolean);
/* 128 */       if (true == arrayOfBoolean[0].booleanValue())
/*     */       {
/* 130 */         if (null == list || 0 == list.size() || !list.contains(paramEncryptionKeyInfo.keyPath)) {
/* 131 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UntrustedKeyPath"));
/* 132 */           Object[] arrayOfObject = { paramEncryptionKeyInfo.keyPath, str1 };
/* 133 */           throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */         } 
/*     */       }
/*     */       
/* 137 */       if (aeLogger.isLoggable(Level.FINE))
/*     */       {
/* 139 */         aeLogger.fine("Checking Symmetric key cache...");
/*     */       }
/*     */ 
/*     */       
/* 143 */       if (!this.cache.containsKey(str2)) {
/*     */ 
/*     */         
/* 146 */         SQLServerColumnEncryptionKeyStoreProvider sQLServerColumnEncryptionKeyStoreProvider = paramSQLServerConnection.getSystemColumnEncryptionKeyStoreProvider(paramEncryptionKeyInfo.keyStoreName);
/*     */ 
/*     */         
/* 149 */         if (null == sQLServerColumnEncryptionKeyStoreProvider)
/*     */         {
/* 151 */           sQLServerColumnEncryptionKeyStoreProvider = SQLServerConnection.getGlobalSystemColumnEncryptionKeyStoreProvider(paramEncryptionKeyInfo.keyStoreName);
/*     */         }
/*     */ 
/*     */         
/* 155 */         if (null == sQLServerColumnEncryptionKeyStoreProvider)
/*     */         {
/* 157 */           sQLServerColumnEncryptionKeyStoreProvider = SQLServerConnection.getGlobalCustomColumnEncryptionKeyStoreProvider(paramEncryptionKeyInfo.keyStoreName);
/*     */         }
/*     */ 
/*     */         
/* 161 */         if (null == sQLServerColumnEncryptionKeyStoreProvider) {
/* 162 */           String str3 = paramSQLServerConnection.getAllSystemColumnEncryptionKeyStoreProviders();
/* 163 */           String str4 = SQLServerConnection.getAllGlobalCustomSystemColumnEncryptionKeyStoreProviders();
/* 164 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnrecognizedKeyStoreProviderName"));
/* 165 */           Object[] arrayOfObject = { paramEncryptionKeyInfo.keyStoreName, str3, str4 };
/* 166 */           throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */         } 
/*     */ 
/*     */         
/* 170 */         byte[] arrayOfByte = sQLServerColumnEncryptionKeyStoreProvider.decryptColumnEncryptionKey(paramEncryptionKeyInfo.keyPath, paramEncryptionKeyInfo.algorithmName, paramEncryptionKeyInfo.encryptedKey);
/* 171 */         sQLServerSymmetricKey = new SQLServerSymmetricKey(arrayOfByte);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 179 */         long l = SQLServerConnection.getColumnEncryptionKeyCacheTtl();
/* 180 */         if (0L != l)
/*     */         {
/* 182 */           this.cache.putIfAbsent(str2, sQLServerSymmetricKey);
/* 183 */           if (aeLogger.isLoggable(Level.FINE))
/*     */           {
/* 185 */             aeLogger.fine("Adding encryption key to cache...");
/*     */           }
/* 187 */           scheduler.schedule(new CacheClear(str2), l, TimeUnit.SECONDS);
/*     */         
/*     */         }
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 195 */         sQLServerSymmetricKey = this.cache.get(str2);
/*     */       } 
/*     */     } 
/* 198 */     return sQLServerSymmetricKey;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerSymmetricKeyCache.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */