/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ServerPortPlaceHolder
/*     */ {
/*     */   private final String serverName;
/*     */   private final int port;
/*     */   private final String instanceName;
/*     */   private final boolean checkLink;
/*     */   private final SQLServerConnectionSecurityManager securityManager;
/*     */   
/*     */   ServerPortPlaceHolder(String paramString1, int paramInt, String paramString2, boolean paramBoolean) {
/* 130 */     this.serverName = paramString1;
/* 131 */     this.port = paramInt;
/* 132 */     this.instanceName = paramString2;
/* 133 */     this.checkLink = paramBoolean;
/* 134 */     this.securityManager = new SQLServerConnectionSecurityManager(this.serverName, this.port);
/* 135 */     doSecurityCheck();
/*     */   }
/*     */   
/*     */   int getPortNumber() {
/* 139 */     return this.port;
/* 140 */   } String getServerName() { return this.serverName; } String getInstanceName() {
/* 141 */     return this.instanceName;
/*     */   }
/*     */   void doSecurityCheck() {
/* 144 */     this.securityManager.checkConnect();
/* 145 */     if (this.checkLink)
/* 146 */       this.securityManager.checkLink(); 
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ServerPortPlaceHolder.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */