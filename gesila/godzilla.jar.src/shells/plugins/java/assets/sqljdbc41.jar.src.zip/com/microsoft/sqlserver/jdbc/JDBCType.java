/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.text.MessageFormat;
/*      */ import java.util.EnumMap;
/*      */ import java.util.EnumSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ enum JDBCType
/*      */ {
/*  808 */   UNKNOWN(Category.UNKNOWN, 999, "java.lang.Object"),
/*  809 */   ARRAY(Category.UNKNOWN, 2003, "java.lang.Object"),
/*  810 */   BIGINT(Category.NUMERIC, -5, "java.lang.Long"),
/*  811 */   BINARY(Category.BINARY, -2, "[B"),
/*  812 */   BIT(Category.NUMERIC, -7, "java.lang.Boolean"),
/*  813 */   BLOB(Category.BLOB, 2004, "java.sql.Blob"),
/*  814 */   BOOLEAN(Category.NUMERIC, 16, "java.lang.Boolean"),
/*  815 */   CHAR(Category.CHARACTER, 1, "java.lang.String"),
/*  816 */   CLOB(Category.CLOB, 2005, "java.sql.Clob"),
/*  817 */   DATALINK(Category.UNKNOWN, 70, "java.lang.Object"),
/*  818 */   DATE(Category.DATE, 91, "java.sql.Date"),
/*  819 */   DATETIMEOFFSET(Category.DATETIMEOFFSET, -155, "microsoft.sql.DateTimeOffset"),
/*  820 */   DECIMAL(Category.NUMERIC, 3, "java.math.BigDecimal"),
/*  821 */   DISTINCT(Category.UNKNOWN, 2001, "java.lang.Object"),
/*  822 */   DOUBLE(Category.NUMERIC, 8, "java.lang.Double"),
/*  823 */   FLOAT(Category.NUMERIC, 6, "java.lang.Double"),
/*  824 */   INTEGER(Category.NUMERIC, 4, "java.lang.Integer"),
/*  825 */   JAVA_OBJECT(Category.UNKNOWN, 2000, "java.lang.Object"),
/*  826 */   LONGNVARCHAR(Category.LONG_NCHARACTER, -16, "java.lang.String"),
/*  827 */   LONGVARBINARY(Category.LONG_BINARY, -4, "[B"),
/*  828 */   LONGVARCHAR(Category.LONG_CHARACTER, -1, "java.lang.String"),
/*  829 */   NCHAR(Category.NCHARACTER, -15, "java.lang.String"),
/*  830 */   NCLOB(Category.NCLOB, 2011, "java.sql.NClob"),
/*  831 */   NULL(Category.UNKNOWN, 0, "java.lang.Object"),
/*  832 */   NUMERIC(Category.NUMERIC, 2, "java.math.BigDecimal"),
/*  833 */   NVARCHAR(Category.NCHARACTER, -9, "java.lang.String"),
/*  834 */   OTHER(Category.UNKNOWN, 1111, "java.lang.Object"),
/*  835 */   REAL(Category.NUMERIC, 7, "java.lang.Float"),
/*  836 */   REF(Category.UNKNOWN, 2006, "java.lang.Object"),
/*  837 */   ROWID(Category.UNKNOWN, -8, "java.lang.Object"),
/*  838 */   SMALLINT(Category.NUMERIC, 5, "java.lang.Short"),
/*  839 */   SQLXML(Category.SQLXML, 2009, "java.lang.Object"),
/*  840 */   STRUCT(Category.UNKNOWN, 2002, "java.lang.Object"),
/*  841 */   TIME(Category.TIME, 92, "java.sql.Time"),
/*  842 */   TIME_WITH_TIMEZONE(Category.TIME_WITH_TIMEZONE, 2013, "java.time.OffsetTime"),
/*      */   
/*  844 */   TIMESTAMP(Category.TIMESTAMP, 93, "java.sql.Timestamp"),
/*  845 */   TIMESTAMP_WITH_TIMEZONE(Category.TIMESTAMP_WITH_TIMEZONE, 2014, "java.time.OffsetDateTime"),
/*      */   
/*  847 */   TINYINT(Category.NUMERIC, -6, "java.lang.Short"),
/*  848 */   VARBINARY(Category.BINARY, -3, "[B"),
/*  849 */   VARCHAR(Category.CHARACTER, 12, "java.lang.String"),
/*  850 */   MONEY(Category.NUMERIC, -148, "java.math.BigDecimal"),
/*  851 */   SMALLMONEY(Category.NUMERIC, -146, "java.math.BigDecimal"),
/*  852 */   TVP(Category.TVP, -153, "java.lang.Object"),
/*  853 */   DATETIME(Category.TIMESTAMP, -151, "java.sql.Timestamp"),
/*  854 */   SMALLDATETIME(Category.TIMESTAMP, -150, "java.sql.Timestamp"),
/*  855 */   GUID(Category.CHARACTER, -145, "java.lang.String"); final Category category;
/*      */   private final int intValue;
/*      */   private final String className;
/*      */   
/*      */   final String className() {
/*  860 */     return this.className;
/*      */   }
/*      */   private static final EnumSet<JDBCType> signedTypes; private static final EnumSet<JDBCType> binaryTypes; private static final EnumSet<Category> textualCategories;
/*      */   JDBCType(Category paramCategory, int paramInt1, String paramString1) {
/*  864 */     this.category = paramCategory;
/*  865 */     this.intValue = paramInt1;
/*  866 */     this.className = paramString1;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getIntValue() {
/*  871 */     return this.intValue;
/*      */   }
/*      */   
/*      */   enum Category
/*      */   {
/*  876 */     CHARACTER,
/*  877 */     LONG_CHARACTER,
/*  878 */     CLOB,
/*  879 */     NCHARACTER,
/*  880 */     LONG_NCHARACTER,
/*  881 */     NCLOB,
/*  882 */     BINARY,
/*  883 */     LONG_BINARY,
/*  884 */     BLOB,
/*  885 */     NUMERIC,
/*  886 */     DATE,
/*  887 */     TIME,
/*  888 */     TIMESTAMP,
/*  889 */     TIME_WITH_TIMEZONE,
/*  890 */     TIMESTAMP_WITH_TIMEZONE,
/*  891 */     DATETIMEOFFSET,
/*  892 */     SQLXML,
/*  893 */     UNKNOWN,
/*  894 */     TVP,
/*  895 */     GUID;
/*      */   }
/*      */ 
/*      */   
/*      */   enum SetterConversion
/*      */   {
/*  901 */     CHARACTER((String)JDBCType.Category.CHARACTER, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.GUID
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/*  917 */     LONG_CHARACTER((String)JDBCType.Category.LONG_CHARACTER, EnumSet.of(JDBCType.Category.CHARACTER, new JDBCType.Category[] { JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/*  927 */     CLOB((String)JDBCType.Category.CLOB, EnumSet.of(JDBCType.Category.CLOB, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.LONG_NCHARACTER)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  934 */     NCHARACTER((String)JDBCType.Category.NCHARACTER, EnumSet.of(JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.NCLOB)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  941 */     LONG_NCHARACTER((String)JDBCType.Category.LONG_NCHARACTER, EnumSet.of(JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  947 */     NCLOB((String)JDBCType.Category.NCLOB, EnumSet.of(JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.NCLOB)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  953 */     BINARY((String)JDBCType.Category.BINARY, EnumSet.of(JDBCType.Category.NUMERIC, new JDBCType.Category[] { JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER, JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY, JDBCType.Category.BLOB, JDBCType.Category.GUID
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/*  969 */     LONG_BINARY((String)JDBCType.Category.LONG_BINARY, EnumSet.of(JDBCType.Category.BINARY, JDBCType.Category.LONG_BINARY)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  975 */     BLOB((String)JDBCType.Category.BLOB, EnumSet.of(JDBCType.Category.LONG_BINARY, JDBCType.Category.BLOB)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  981 */     NUMERIC((String)JDBCType.Category.NUMERIC, EnumSet.of(JDBCType.Category.NUMERIC, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  990 */     DATE((String)JDBCType.Category.DATE, EnumSet.of(JDBCType.Category.DATE, new JDBCType.Category[] { JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1001 */     TIME((String)JDBCType.Category.TIME, EnumSet.of(JDBCType.Category.TIME, new JDBCType.Category[] { JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1012 */     TIMESTAMP((String)JDBCType.Category.TIMESTAMP, EnumSet.of(JDBCType.Category.DATE, new JDBCType.Category[] { JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1024 */     TIME_WITH_TIMEZONE((String)JDBCType.Category.TIME_WITH_TIMEZONE, EnumSet.of(JDBCType.Category.TIME_WITH_TIMEZONE, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1033 */     TIMESTAMP_WITH_TIMEZONE((String)JDBCType.Category.TIMESTAMP_WITH_TIMEZONE, EnumSet.of(JDBCType.Category.TIMESTAMP_WITH_TIMEZONE, new JDBCType.Category[] { JDBCType.Category.TIME_WITH_TIMEZONE, JDBCType.Category.CHARACTER, JDBCType.Category.LONG_CHARACTER, JDBCType.Category.NCHARACTER, JDBCType.Category.LONG_NCHARACTER
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1043 */     DATETIMEOFFSET((String)JDBCType.Category.DATETIMEOFFSET, EnumSet.of(JDBCType.Category.DATE, JDBCType.Category.TIME, JDBCType.Category.TIMESTAMP, JDBCType.Category.DATETIMEOFFSET)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1051 */     SQLXML((String)JDBCType.Category.SQLXML, EnumSet.of(JDBCType.Category.SQLXML)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1056 */     TVP((String)JDBCType.Category.TVP, EnumSet.of(JDBCType.Category.TVP));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final JDBCType.Category from;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final EnumSet<JDBCType.Category> to;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1072 */     private static final EnumMap<JDBCType.Category, EnumSet<JDBCType.Category>> conversionMap = new EnumMap<>(JDBCType.Category.class); SetterConversion(JDBCType.Category param1Category, EnumSet<JDBCType.Category> param1EnumSet) {
/*      */       this.from = param1Category;
/*      */       this.to = param1EnumSet;
/*      */     }
/*      */     static {
/* 1077 */       for (JDBCType.Category category : JDBCType.Category.values()) {
/* 1078 */         conversionMap.put(category, EnumSet.noneOf(JDBCType.Category.class));
/*      */       }
/* 1080 */       for (SetterConversion setterConversion : values()) {
/* 1081 */         ((EnumSet<JDBCType.Category>)conversionMap.get(setterConversion.from)).addAll(setterConversion.to);
/*      */       }
/*      */     }
/*      */     
/*      */     static boolean converts(JDBCType param1JDBCType1, JDBCType param1JDBCType2) {
/* 1086 */       return ((EnumSet)conversionMap.get(param1JDBCType1.category)).contains(param1JDBCType2.category);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   boolean convertsTo(JDBCType paramJDBCType) {
/* 1092 */     return SetterConversion.converts(this, paramJDBCType);
/*      */   }
/*      */   
/*      */   enum UpdaterConversion
/*      */   {
/* 1097 */     CHARACTER((String)JDBCType.Category.CHARACTER, EnumSet.of(SSType.Category.NUMERIC, new SSType.Category[] { SSType.Category.DATE, SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT, SSType.Category.GUID, SSType.Category.TIMESTAMP
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1117 */     LONG_CHARACTER((String)JDBCType.Category.LONG_CHARACTER, EnumSet.of(SSType.Category.CHARACTER, new SSType.Category[] { SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1128 */     CLOB((String)JDBCType.Category.CLOB, EnumSet.of(SSType.Category.LONG_CHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1135 */     NCHARACTER((String)JDBCType.Category.NCHARACTER, EnumSet.of(SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1142 */     LONG_NCHARACTER((String)JDBCType.Category.LONG_NCHARACTER, EnumSet.of(SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1149 */     NCLOB((String)JDBCType.Category.NCLOB, EnumSet.of(SSType.Category.LONG_NCHARACTER, SSType.Category.XML)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1155 */     BINARY((String)JDBCType.Category.BINARY, EnumSet.of(SSType.Category.NUMERIC, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER, SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT, SSType.Category.TIMESTAMP, SSType.Category.GUID
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1171 */     LONG_BINARY((String)JDBCType.Category.LONG_BINARY, EnumSet.of(SSType.Category.XML, SSType.Category.BINARY, SSType.Category.LONG_BINARY, SSType.Category.UDT)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1179 */     BLOB((String)JDBCType.Category.BLOB, EnumSet.of(SSType.Category.LONG_BINARY, SSType.Category.XML)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1184 */     SQLXML((String)JDBCType.Category.SQLXML, EnumSet.of(SSType.Category.XML)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1189 */     NUMERIC((String)JDBCType.Category.NUMERIC, EnumSet.of(SSType.Category.NUMERIC, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1198 */     DATE((String)JDBCType.Category.DATE, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1210 */     TIME((String)JDBCType.Category.TIME, EnumSet.of(SSType.Category.TIME, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1222 */     TIMESTAMP((String)JDBCType.Category.TIMESTAMP, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1235 */     DATETIMEOFFSET((String)JDBCType.Category.DATETIMEOFFSET, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1248 */     TIME_WITH_TIMEZONE((String)JDBCType.Category.TIME_WITH_TIMEZONE, EnumSet.of(SSType.Category.TIME, new SSType.Category[] { SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         })),
/* 1260 */     TIMESTAMP_WITH_TIMEZONE((String)JDBCType.Category.TIMESTAMP_WITH_TIMEZONE, EnumSet.of(SSType.Category.DATE, new SSType.Category[] { SSType.Category.TIME, SSType.Category.DATETIME, SSType.Category.DATETIME2, SSType.Category.DATETIMEOFFSET, SSType.Category.CHARACTER, SSType.Category.LONG_CHARACTER, SSType.Category.NCHARACTER, SSType.Category.LONG_NCHARACTER }));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final JDBCType.Category from;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final EnumSet<SSType.Category> to;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1284 */     private static final EnumMap<JDBCType.Category, EnumSet<SSType.Category>> conversionMap = new EnumMap<>(JDBCType.Category.class); UpdaterConversion(JDBCType.Category param1Category, EnumSet<SSType.Category> param1EnumSet) {
/*      */       this.from = param1Category;
/*      */       this.to = param1EnumSet;
/*      */     }
/*      */     static {
/* 1289 */       for (JDBCType.Category category : JDBCType.Category.values()) {
/* 1290 */         conversionMap.put(category, EnumSet.noneOf(SSType.Category.class));
/*      */       }
/* 1292 */       for (UpdaterConversion updaterConversion : values()) {
/* 1293 */         ((EnumSet<SSType.Category>)conversionMap.get(updaterConversion.from)).addAll(updaterConversion.to);
/*      */       }
/*      */     }
/*      */     
/*      */     static boolean converts(JDBCType param1JDBCType, SSType param1SSType) {
/* 1298 */       return ((EnumSet)conversionMap.get(param1JDBCType.category)).contains(param1SSType.category);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   boolean convertsTo(SSType paramSSType) {
/* 1304 */     return UpdaterConversion.converts(this, paramSSType);
/*      */   }
/*      */ 
/*      */   
/*      */   static JDBCType of(int paramInt) throws SQLServerException {
/* 1309 */     for (JDBCType jDBCType : values()) {
/* 1310 */       if (jDBCType.intValue == paramInt)
/* 1311 */         return jDBCType; 
/*      */     } 
/* 1313 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unknownJDBCType"));
/* 1314 */     Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/* 1315 */     SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), null, true);
/* 1316 */     return UNKNOWN;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/* 1323 */     signedTypes = EnumSet.of(SMALLINT, new JDBCType[] { INTEGER, BIGINT, REAL, FLOAT, DOUBLE, DECIMAL, NUMERIC, MONEY, SMALLMONEY });
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1345 */     binaryTypes = EnumSet.of(BINARY, VARBINARY, LONGVARBINARY, BLOB);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1366 */     textualCategories = EnumSet.of(Category.CHARACTER, new Category[] { Category.LONG_CHARACTER, Category.CLOB, Category.NCHARACTER, Category.LONG_NCHARACTER, Category.NCLOB });
/*      */   }
/*      */   boolean isSigned() {
/*      */     return signedTypes.contains(this);
/*      */   }
/*      */   
/*      */   boolean isBinary() {
/*      */     return binaryTypes.contains(this);
/*      */   }
/*      */   
/*      */   boolean isTextual() {
/* 1377 */     return textualCategories.contains(this.category);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isUnsupported() {
/* 1387 */     return (Category.UNKNOWN == this.category);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int asJavaSqlType() {
/* 1398 */     if (Util.SYSTEM_SPEC_VERSION.equals("1.5")) {
/*      */       
/* 1400 */       switch (this) {
/*      */         case NCHAR:
/* 1402 */           return 1;
/* 1403 */         case NVARCHAR: return 12;
/* 1404 */         case LONGNVARCHAR: return -1;
/* 1405 */         case NCLOB: return 2005;
/* 1406 */         case ROWID: return 1111;
/* 1407 */         case SQLXML: return 12;
/* 1408 */       }  return this.intValue;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1413 */     return this.intValue;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   enum NormalizationAE
/*      */   {
/* 1422 */     CHARACTER_NORMALIZED_TO((String)JDBCType.CHAR, EnumSet.of(SSType.CHAR, SSType.VARCHAR, SSType.VARCHARMAX)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1429 */     VARCHARACTER_NORMALIZED_TO((String)JDBCType.VARCHAR, EnumSet.of(SSType.CHAR, SSType.VARCHAR, SSType.VARCHARMAX)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1436 */     LONGVARCHARACTER_NORMALIZED_TO((String)JDBCType.LONGVARCHAR, EnumSet.of(SSType.CHAR, SSType.VARCHAR, SSType.VARCHARMAX)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1443 */     NCHAR_NORMALIZED_TO((String)JDBCType.NCHAR, EnumSet.of(SSType.NCHAR, SSType.NVARCHAR, SSType.NVARCHARMAX)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1450 */     NVARCHAR_NORMALIZED_TO((String)JDBCType.NVARCHAR, EnumSet.of(SSType.NCHAR, SSType.NVARCHAR, SSType.NVARCHARMAX)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1457 */     LONGNVARCHAR_NORMALIZED_TO((String)JDBCType.LONGNVARCHAR, EnumSet.of(SSType.NCHAR, SSType.NVARCHAR, SSType.NVARCHARMAX)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1464 */     BIT_NORMALIZED_TO((String)JDBCType.BIT, EnumSet.of(SSType.BIT, SSType.TINYINT, SSType.SMALLINT, SSType.INTEGER, SSType.BIGINT)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1473 */     TINYINT_NORMALIZED_TO((String)JDBCType.TINYINT, EnumSet.of(SSType.TINYINT, SSType.SMALLINT, SSType.INTEGER, SSType.BIGINT)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1481 */     SMALLINT_NORMALIZED_TO((String)JDBCType.SMALLINT, EnumSet.of(SSType.SMALLINT, SSType.INTEGER, SSType.BIGINT)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1488 */     INTEGER_NORMALIZED_TO((String)JDBCType.INTEGER, EnumSet.of(SSType.INTEGER, SSType.BIGINT)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1494 */     BIGINT_NORMALIZED_TO((String)JDBCType.BIGINT, EnumSet.of(SSType.BIGINT)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1499 */     BINARY_NORMALIZED_TO((String)JDBCType.BINARY, EnumSet.of(SSType.BINARY, SSType.VARBINARY, SSType.VARBINARYMAX)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1506 */     VARBINARY_NORMALIZED_TO((String)JDBCType.VARBINARY, EnumSet.of(SSType.BINARY, SSType.VARBINARY, SSType.VARBINARYMAX)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1513 */     LONGVARBINARY_NORMALIZED_TO((String)JDBCType.LONGVARBINARY, EnumSet.of(SSType.BINARY, SSType.VARBINARY, SSType.VARBINARYMAX)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1520 */     FLOAT_NORMALIZED_TO((String)JDBCType.DOUBLE, EnumSet.of(SSType.FLOAT)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1525 */     REAL_NORMALIZED_TO((String)JDBCType.REAL, EnumSet.of(SSType.REAL)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1530 */     DECIMAL_NORMALIZED_TO((String)JDBCType.DECIMAL, EnumSet.of(SSType.DECIMAL, SSType.NUMERIC)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1536 */     SMALLMONEY_NORMALIZED_TO((String)JDBCType.SMALLMONEY, EnumSet.of(SSType.SMALLMONEY, SSType.MONEY)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1542 */     MONEY_NORMALIZED_TO((String)JDBCType.MONEY, EnumSet.of(SSType.MONEY)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1547 */     NUMERIC_NORMALIZED_TO((String)JDBCType.NUMERIC, EnumSet.of(SSType.DECIMAL, SSType.NUMERIC)),
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1553 */     DATE_NORMALIZED_TO((String)JDBCType.DATE, EnumSet.of(SSType.DATE)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1558 */     TIME_NORMALIZED_TO((String)JDBCType.TIME, EnumSet.of(SSType.TIME)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1563 */     DATETIME2_NORMALIZED_TO((String)JDBCType.TIMESTAMP, EnumSet.of(SSType.DATETIME2)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1568 */     DATETIMEOFFSET_NORMALIZED_TO((String)JDBCType.DATETIMEOFFSET, EnumSet.of(SSType.DATETIMEOFFSET)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1573 */     DATETIME_NORMALIZED_TO((String)JDBCType.DATETIME, EnumSet.of(SSType.DATETIME)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1578 */     SMALLDATETIME_NORMALIZED_TO((String)JDBCType.SMALLDATETIME, EnumSet.of(SSType.SMALLDATETIME)),
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1583 */     GUID_NORMALIZED_TO((String)JDBCType.GUID, EnumSet.of(SSType.GUID));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final JDBCType from;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final EnumSet<SSType> to;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1600 */     private static final EnumMap<JDBCType, EnumSet<SSType>> normalizationMapAE = new EnumMap<>(JDBCType.class); NormalizationAE(JDBCType param1JDBCType, EnumSet<SSType> param1EnumSet) {
/*      */       this.from = param1JDBCType;
/*      */       this.to = param1EnumSet;
/*      */     }
/*      */     static {
/* 1605 */       for (JDBCType jDBCType : JDBCType.values()) {
/* 1606 */         normalizationMapAE.put(jDBCType, EnumSet.noneOf(SSType.class));
/*      */       }
/* 1608 */       for (NormalizationAE normalizationAE : values()) {
/* 1609 */         ((EnumSet<SSType>)normalizationMapAE.get(normalizationAE.from)).addAll(normalizationAE.to);
/*      */       }
/*      */     }
/*      */     
/*      */     static boolean converts(JDBCType param1JDBCType, SSType param1SSType) {
/* 1614 */       return ((EnumSet)normalizationMapAE.get(param1JDBCType)).contains(param1SSType);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   boolean normalizationCheck(SSType paramSSType) {
/* 1620 */     return NormalizationAE.converts(this, paramSSType);
/*      */   }
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/JDBCType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */