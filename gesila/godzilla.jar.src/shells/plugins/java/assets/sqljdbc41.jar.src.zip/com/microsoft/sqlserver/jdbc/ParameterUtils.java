/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class ParameterUtils
/*     */ {
/*     */   static byte[] HexToBin(String paramString) throws SQLServerException {
/*  14 */     int i = paramString.length();
/*  15 */     char[] arrayOfChar = paramString.toCharArray();
/*  16 */     if (i % 2 != 0) {
/*  17 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_stringNotInHex"), null, false);
/*     */     }
/*  19 */     byte[] arrayOfByte = new byte[i / 2];
/*  20 */     for (byte b = 0; b < i / 2; b++)
/*     */     {
/*  22 */       arrayOfByte[b] = (byte)((CharToHex(arrayOfChar[2 * b]) << 4) + CharToHex(arrayOfChar[2 * b + 1]));
/*     */     }
/*  24 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte CharToHex(char paramChar) throws SQLServerException {
/*  32 */     byte b = 0;
/*  33 */     if (paramChar >= 'A' && paramChar <= 'F') {
/*     */       
/*  35 */       b = (byte)(paramChar - 65 + 10);
/*     */     }
/*  37 */     else if (paramChar >= 'a' && paramChar <= 'f') {
/*     */       
/*  39 */       b = (byte)(paramChar - 97 + 10);
/*     */     
/*     */     }
/*  42 */     else if (paramChar >= '0' && paramChar <= '9') {
/*     */       
/*  44 */       b = (byte)(paramChar - 48);
/*     */     }
/*     */     else {
/*     */       
/*  48 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_stringNotInHex"), null, false);
/*     */     } 
/*     */     
/*  51 */     return b;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static int scanSQLForChar(char paramChar, String paramString, int paramInt) {
/*  81 */     int i = paramString.length();
/*     */     
/*  83 */     while (paramInt < i) {
/*     */       char c1;
/*  85 */       switch (c1 = paramString.charAt(paramInt++))
/*     */       
/*     */       { case '/':
/*  88 */           if (paramInt == i) {
/*     */             continue;
/*     */           }
/*  91 */           if (paramString.charAt(paramInt) == '*') {
/*     */             
/*  93 */             while (++paramInt < i) {
/*     */               
/*  95 */               if (paramString.charAt(paramInt) == '*' && paramInt + 1 < i && paramString.charAt(paramInt + 1) == '/')
/*     */               {
/*     */ 
/*     */                 
/*  99 */                 paramInt += 2;
/*     */               }
/*     */             } 
/*     */             
/*     */             continue;
/*     */           } 
/* 105 */           if (paramString.charAt(paramInt) == '-') {
/*     */             continue;
/*     */           }
/*     */         
/*     */         case '-':
/* 110 */           if (paramString.charAt(paramInt) == '-') {
/*     */             
/* 112 */             label33: while (++paramInt < i) {
/*     */               
/* 114 */               if (paramString.charAt(paramInt) != '\n') { if (paramString.charAt(paramInt) == '\r')
/*     */                   break label33;  continue; }
/* 116 */                paramInt++;
/*     */             } 
/*     */             continue;
/*     */           } 
/*     */ 
/*     */ 
/*     */         
/*     */         default:
/* 124 */           if (paramChar == c1) {
/* 125 */             return paramInt - 1;
/*     */           }
/*     */           continue;
/*     */         case '[':
/* 129 */           c1 = ']'; break;
/*     */         case '"':
/*     */         case '\'':
/* 132 */           break; }  char c = c1;
/* 133 */       while (paramInt < i) {
/*     */         
/* 135 */         if (paramString.charAt(paramInt++) == c) {
/*     */           
/* 137 */           if (i == paramInt || paramString.charAt(paramInt) != c) {
/*     */             break;
/*     */           }
/* 140 */           paramInt++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 147 */     return i;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ParameterUtils.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */