/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.security.Key;
/*    */ import java.security.cert.X509Certificate;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class CertificateDetails
/*    */ {
/*    */   X509Certificate certificate;
/*    */   Key privateKey;
/*    */   
/*    */   CertificateDetails(X509Certificate paramX509Certificate, Key paramKey) {
/* 31 */     this.certificate = paramX509Certificate;
/* 32 */     this.privateKey = paramKey;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/CertificateDetails.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */