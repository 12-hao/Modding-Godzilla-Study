/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class Column
/*     */ {
/*     */   private TypeInfo typeInfo;
/*     */   private CryptoMetadata cryptoMetadata;
/*     */   private DTV updaterDTV;
/*     */   
/*     */   final TypeInfo getTypeInfo() {
/*  16 */     return this.typeInfo;
/*     */   }
/*  18 */   private final DTV getterDTV = new DTV();
/*     */ 
/*     */   
/*  21 */   private JDBCType jdbcTypeSetByUser = null; private String columnName;
/*     */   private String baseColumnName;
/*     */   private int tableNum;
/*  24 */   private int valueLength = 0; private int infoStatus; private SQLIdentifier tableName;
/*     */   ColumnFilter filter;
/*     */   
/*     */   final void setColumnName(String paramString) {
/*  28 */     this.columnName = paramString; } final String getColumnName() {
/*  29 */     return this.columnName;
/*     */   }
/*     */ 
/*     */   
/*     */   final void setBaseColumnName(String paramString)
/*     */   {
/*  35 */     this.baseColumnName = paramString; } final String getBaseColumnName() {
/*  36 */     return this.baseColumnName;
/*     */   }
/*     */   
/*  39 */   final void setTableNum(int paramInt) { this.tableNum = paramInt; } final int getTableNum() {
/*  40 */     return this.tableNum;
/*     */   }
/*     */   
/*  43 */   final void setInfoStatus(int paramInt) { this.infoStatus = paramInt; }
/*  44 */   final boolean hasDifferentName() { return (0 != (this.infoStatus & 0x20)); }
/*  45 */   final boolean isHidden() { return (0 != (this.infoStatus & 0x10)); }
/*  46 */   final boolean isKey() { return (0 != (this.infoStatus & 0x8)); } final boolean isExpression() {
/*  47 */     return (0 != (this.infoStatus & 0x4));
/*     */   }
/*     */   final boolean isUpdatable() {
/*  50 */     return (!isExpression() && !isHidden() && this.tableName.getObjectName().length() > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   final void setTableName(SQLIdentifier paramSQLIdentifier)
/*     */   {
/*  57 */     this.tableName = paramSQLIdentifier; } final SQLIdentifier getTableName() {
/*  58 */     return this.tableName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Column(TypeInfo paramTypeInfo, String paramString, SQLIdentifier paramSQLIdentifier, CryptoMetadata paramCryptoMetadata) {
/*  70 */     this.typeInfo = paramTypeInfo;
/*  71 */     this.columnName = paramString;
/*  72 */     this.baseColumnName = paramString;
/*  73 */     this.tableName = paramSQLIdentifier;
/*  74 */     this.cryptoMetadata = paramCryptoMetadata;
/*     */   }
/*     */   
/*     */   CryptoMetadata getCryptoMetadata() {
/*  78 */     return this.cryptoMetadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void clear() {
/*  86 */     this.getterDTV.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void skipValue(TDSReader paramTDSReader, boolean paramBoolean) throws SQLServerException {
/*  98 */     this.getterDTV.skipValue(this.typeInfo, paramTDSReader, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final void initFromCompressedNull() {
/* 106 */     this.getterDTV.initFromCompressedNull();
/*     */   }
/*     */ 
/*     */   
/*     */   void setFilter(ColumnFilter paramColumnFilter) {
/* 111 */     this.filter = paramColumnFilter;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isNull() {
/* 122 */     return this.getterDTV.isNull();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final boolean isInitialized() {
/* 133 */     return this.getterDTV.isInitialized();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getValue(JDBCType paramJDBCType, InputStreamGetterArgs paramInputStreamGetterArgs, Calendar paramCalendar, TDSReader paramTDSReader) throws SQLServerException {
/* 144 */     Object object = this.getterDTV.getValue(paramJDBCType, this.typeInfo.getScale(), paramInputStreamGetterArgs, paramCalendar, this.typeInfo, this.cryptoMetadata, paramTDSReader);
/* 145 */     return (null != this.filter) ? this.filter.apply(object, paramJDBCType) : object;
/*     */   }
/*     */ 
/*     */   
/*     */   int getInt(TDSReader paramTDSReader) throws SQLServerException {
/* 150 */     return ((Integer)getValue(JDBCType.INTEGER, null, null, paramTDSReader)).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void updateValue(JDBCType paramJDBCType, Object paramObject, JavaType paramJavaType, StreamSetterArgs paramStreamSetterArgs, Calendar paramCalendar, Integer paramInteger1, SQLServerConnection paramSQLServerConnection, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting, Integer paramInteger2, boolean paramBoolean, int paramInt) throws SQLServerException {
/* 166 */     SSType sSType = this.typeInfo.getSSType();
/*     */ 
/*     */     
/* 169 */     if (null != this.cryptoMetadata)
/*     */     {
/* 171 */       if (null != paramObject) {
/*     */         
/* 173 */         if (JDBCType.TINYINT == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() && paramJavaType == JavaType.SHORT) {
/* 174 */           if (paramObject instanceof Boolean) {
/* 175 */             if (true == ((Boolean)paramObject).booleanValue()) {
/* 176 */               paramObject = Integer.valueOf(1);
/*     */             } else {
/*     */               
/* 179 */               paramObject = Integer.valueOf(0);
/*     */             } 
/*     */           }
/* 182 */           String str = "" + paramObject;
/* 183 */           Short short_ = Short.valueOf(str);
/*     */           
/* 185 */           if (short_.shortValue() >= 0 && short_.shortValue() <= 255) {
/* 186 */             paramObject = Byte.valueOf(short_.byteValue());
/* 187 */             paramJavaType = JavaType.BYTE;
/* 188 */             paramJDBCType = JDBCType.TINYINT;
/*     */           }
/*     */         
/*     */         }
/*     */       
/* 193 */       } else if (paramJDBCType.isBinary()) {
/* 194 */         paramJDBCType = this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType();
/*     */       } 
/*     */     }
/*     */     
/* 198 */     if (null == paramInteger1 && null != this.cryptoMetadata) {
/* 199 */       paramInteger1 = Integer.valueOf(this.cryptoMetadata.getBaseTypeInfo().getScale());
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 204 */     if (null != this.cryptoMetadata && (JDBCType.CHAR == paramJDBCType || JDBCType.VARCHAR == paramJDBCType) && (
/* 205 */       JDBCType.NVARCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.NCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.LONGNVARCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType()))
/*     */     {
/*     */       
/* 208 */       paramJDBCType = this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType();
/*     */     }
/*     */ 
/*     */     
/* 212 */     if (Util.shouldHonorAEForParameters(paramSQLServerStatementColumnEncryptionSetting, paramSQLServerConnection)) {
/*     */       
/* 214 */       if (null == this.cryptoMetadata && true == paramBoolean) {
/* 215 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAETrue_UnencryptedColumnRS"));
/* 216 */         Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/*     */         
/* 218 */         throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 226 */       setJdbcTypeSetByUser(paramJDBCType);
/*     */       
/* 228 */       this.valueLength = Util.getValueLengthBaseOnJavaType(paramObject, paramJavaType, paramInteger2, paramInteger1, paramJDBCType);
/*     */ 
/*     */ 
/*     */       
/* 232 */       if (null != this.cryptoMetadata && (
/* 233 */         JDBCType.NCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.NVARCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType() || JDBCType.LONGNVARCHAR == this.cryptoMetadata.getBaseTypeInfo().getSSType().getJDBCType()))
/*     */       {
/*     */         
/* 236 */         this.valueLength *= 2;
/*     */ 
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 242 */     else if (true == paramBoolean) {
/* 243 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ForceEncryptionTrue_HonorAEFalseRS"));
/* 244 */       Object[] arrayOfObject = { Integer.valueOf(paramInt) };
/*     */       
/* 246 */       throw new SQLServerException(null, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     if (null != paramStreamSetterArgs) {
/*     */       
/* 257 */       if (!paramStreamSetterArgs.streamType.convertsTo(this.typeInfo)) {
/* 258 */         DataTypes.throwConversionError(paramStreamSetterArgs.streamType.toString(), sSType.toString());
/*     */       
/*     */       }
/*     */     }
/* 262 */     else if (null != this.cryptoMetadata) {
/*     */ 
/*     */       
/* 265 */       if (JDBCType.UNKNOWN == paramJDBCType && paramObject instanceof java.util.UUID) {
/*     */ 
/*     */         
/* 268 */         paramJavaType = JavaType.STRING;
/* 269 */         paramJDBCType = JDBCType.GUID;
/* 270 */         setJdbcTypeSetByUser(paramJDBCType);
/*     */       } 
/*     */       
/* 273 */       SSType sSType1 = this.cryptoMetadata.baseTypeInfo.getSSType();
/* 274 */       if (!paramJDBCType.convertsTo(sSType1)) {
/* 275 */         DataTypes.throwConversionError(paramJDBCType.toString(), sSType.toString());
/*     */       }
/* 277 */       JDBCType jDBCType = getJDBCTypeFromBaseSSType(sSType1, paramJDBCType);
/*     */ 
/*     */ 
/*     */       
/* 281 */       if (jDBCType != paramJDBCType)
/*     */       {
/* 283 */         setJdbcTypeSetByUser(jDBCType);
/* 284 */         paramJDBCType = jDBCType;
/* 285 */         this.valueLength = Util.getValueLengthBaseOnJavaType(paramObject, paramJavaType, paramInteger2, paramInteger1, paramJDBCType);
/*     */       
/*     */       }
/*     */     
/*     */     }
/* 290 */     else if (!paramJDBCType.convertsTo(sSType)) {
/* 291 */       DataTypes.throwConversionError(paramJDBCType.toString(), sSType.toString());
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 296 */     if ((JDBCType.DATETIMEOFFSET == paramJDBCType || JavaType.DATETIMEOFFSET == paramJavaType) && !paramSQLServerConnection.isKatmaiOrLater())
/*     */     {
/*     */       
/* 299 */       throw new SQLServerException(SQLServerException.getErrString("R_notSupported"), SQLState.DATA_EXCEPTION_NOT_SPECIFIC, DriverError.NOT_SET, null);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 310 */     if (null != this.cryptoMetadata && paramSQLServerConnection.sendStringParametersAsUnicode() && (JavaType.STRING == paramJavaType || JavaType.READER == paramJavaType || JavaType.CLOB == paramJavaType))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 315 */       paramJDBCType = getSSPAUJDBCType(paramJDBCType);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 328 */     if ((SSType.NCHAR == sSType || SSType.NVARCHAR == sSType || SSType.NVARCHARMAX == sSType || SSType.NTEXT == sSType || SSType.XML == sSType) && (JDBCType.CHAR == paramJDBCType || JDBCType.VARCHAR == paramJDBCType || JDBCType.LONGVARCHAR == paramJDBCType || JDBCType.CLOB == paramJDBCType)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 341 */       paramJDBCType = (JDBCType.CLOB == paramJDBCType) ? JDBCType.NCLOB : JDBCType.NVARCHAR;
/*     */ 
/*     */     
/*     */     }
/* 345 */     else if ((SSType.BINARY == sSType || SSType.VARBINARY == sSType || SSType.VARBINARYMAX == sSType || SSType.IMAGE == sSType || SSType.UDT == sSType) && (JDBCType.CHAR == paramJDBCType || JDBCType.VARCHAR == paramJDBCType || JDBCType.LONGVARCHAR == paramJDBCType)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 357 */       paramJDBCType = JDBCType.VARBINARY;
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 362 */     else if ((JDBCType.TIMESTAMP == paramJDBCType || JDBCType.DATE == paramJDBCType || JDBCType.TIME == paramJDBCType || JDBCType.DATETIMEOFFSET == paramJDBCType) && (SSType.CHAR == sSType || SSType.VARCHAR == sSType || SSType.VARCHARMAX == sSType || SSType.TEXT == sSType || SSType.NCHAR == sSType || SSType.NVARCHAR == sSType || SSType.NVARCHARMAX == sSType || SSType.NTEXT == sSType)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 380 */       paramJDBCType = JDBCType.NCHAR;
/*     */     } 
/*     */ 
/*     */     
/* 384 */     if (null == this.updaterDTV) {
/* 385 */       this.updaterDTV = new DTV();
/*     */     }
/*     */ 
/*     */     
/* 389 */     this.updaterDTV.setValue(this.typeInfo.getSQLCollation(), paramJDBCType, paramObject, paramJavaType, paramStreamSetterArgs, paramCalendar, paramInteger1, paramSQLServerConnection, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static JDBCType getSSPAUJDBCType(JDBCType paramJDBCType) {
/* 398 */     switch (paramJDBCType) {
/*     */       case CHAR:
/* 400 */         return JDBCType.NCHAR;
/* 401 */       case VARCHAR: return JDBCType.NVARCHAR;
/* 402 */       case LONGVARCHAR: return JDBCType.LONGNVARCHAR;
/* 403 */       case CLOB: return JDBCType.NCLOB;
/* 404 */     }  return paramJDBCType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static JDBCType getJDBCTypeFromBaseSSType(SSType paramSSType, JDBCType paramJDBCType) {
/* 410 */     switch (paramJDBCType) {
/*     */       
/*     */       case TIMESTAMP:
/* 413 */         if (SSType.DATETIME == paramSSType)
/* 414 */           return JDBCType.DATETIME; 
/* 415 */         if (SSType.SMALLDATETIME == paramSSType)
/* 416 */           return JDBCType.SMALLDATETIME; 
/* 417 */         return paramJDBCType;
/*     */       
/*     */       case NUMERIC:
/*     */       case DECIMAL:
/* 421 */         if (SSType.MONEY == paramSSType)
/* 422 */           return JDBCType.MONEY; 
/* 423 */         if (SSType.SMALLMONEY == paramSSType)
/* 424 */           return JDBCType.SMALLMONEY; 
/* 425 */         return paramJDBCType;
/*     */       
/*     */       case CHAR:
/* 428 */         if (SSType.GUID == paramSSType)
/* 429 */           return JDBCType.GUID; 
/*     */         break;
/*     */     } 
/* 432 */     return paramJDBCType;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean hasUpdates() {
/* 438 */     return (null != this.updaterDTV);
/*     */   }
/*     */ 
/*     */   
/*     */   void cancelUpdates() {
/* 443 */     this.updaterDTV = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void sendByRPC(TDSWriter paramTDSWriter, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/* 451 */     if (null == this.updaterDTV) {
/*     */       return;
/*     */     }
/*     */     try {
/* 455 */       this.updaterDTV.sendCryptoMetaData(this.cryptoMetadata, paramTDSWriter);
/* 456 */       this.updaterDTV.jdbcTypeSetByUser(getJdbcTypeSetByUser(), getValueLength());
/*     */ 
/*     */       
/* 459 */       this.updaterDTV.sendByRPC(this.baseColumnName, this.typeInfo, (null != this.cryptoMetadata) ? this.cryptoMetadata.getBaseTypeInfo().getSQLCollation() : this.typeInfo.getSQLCollation(), (null != this.cryptoMetadata) ? this.cryptoMetadata.getBaseTypeInfo().getPrecision() : this.typeInfo.getPrecision(), (null != this.cryptoMetadata) ? this.cryptoMetadata.getBaseTypeInfo().getScale() : this.typeInfo.getScale(), false, paramTDSWriter, paramSQLServerConnection);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 471 */       this.updaterDTV.sendCryptoMetaData(null, paramTDSWriter);
/*     */     } 
/*     */   }
/*     */   
/*     */   JDBCType getJdbcTypeSetByUser() {
/* 476 */     return this.jdbcTypeSetByUser;
/*     */   }
/*     */   void setJdbcTypeSetByUser(JDBCType paramJDBCType) {
/* 479 */     this.jdbcTypeSetByUser = paramJDBCType;
/*     */   }
/*     */   
/*     */   int getValueLength() {
/* 483 */     return this.valueLength;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/Column.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */