/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerXAResource
/*     */   implements XAResource
/*     */ {
/*     */   private int timeoutSeconds;
/*     */   static final int XA_START = 0;
/*     */   static final int XA_END = 1;
/*     */   static final int XA_PREPARE = 2;
/*     */   static final int XA_COMMIT = 3;
/*     */   static final int XA_ROLLBACK = 4;
/*     */   static final int XA_FORGET = 5;
/*     */   static final int XA_RECOVER = 6;
/*     */   static final int XA_PREPARE_EX = 7;
/*     */   static final int XA_ROLLBACK_EX = 8;
/*     */   static final int XA_FORGET_EX = 9;
/*     */   static final int XA_INIT = 10;
/*     */   private SQLServerConnection controlConnection;
/*     */   private SQLServerConnection con;
/*     */   private boolean serverInfoRetrieved;
/*     */   private String version;
/*     */   private String instanceName;
/*     */   private int ArchitectureMSSQL;
/*     */   private int ArchitectureOS;
/*     */   private static boolean xaInitDone;
/*     */   private static Integer xaInitLock;
/*     */   private String sResourceManagerId;
/*     */   private int enlistedTransactionCount;
/*     */   private final Logger xaLogger;
/* 145 */   private static int baseResourceID = 0;
/* 146 */   private int tightlyCoupled = 0;
/* 147 */   private int isTransacrionTimeoutSet = 0;
/*     */   
/*     */   public static final int SSTRANSTIGHTLYCPLD = 32768;
/* 150 */   private SQLServerCallableStatement[] xaStatements = new SQLServerCallableStatement[] { null, null, null, null, null, null, null, null, null, null };
/*     */   
/*     */   private final String traceID;
/*     */ 
/*     */   
/*     */   static {
/* 156 */     xaInitLock = new Integer(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 161 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   
/*     */   SQLServerXAResource(SQLServerConnection paramSQLServerConnection1, SQLServerConnection paramSQLServerConnection2, String paramString) {
/* 166 */     this.traceID = " XAResourceID:" + nextResourceID();
/*     */     
/* 168 */     this.xaLogger = SQLServerXADataSource.xaLogger;
/* 169 */     this.controlConnection = paramSQLServerConnection2;
/* 170 */     this.con = paramSQLServerConnection1;
/* 171 */     Properties properties = paramSQLServerConnection1.activeConnectionProperties;
/* 172 */     if (properties == null) {
/* 173 */       this.sResourceManagerId = "";
/*     */     } else {
/*     */       
/* 176 */       this.sResourceManagerId = properties.getProperty(SQLServerDriverStringProperty.SERVER_NAME.toString()) + "." + properties.getProperty(SQLServerDriverStringProperty.DATABASE_NAME.toString()) + "." + properties.getProperty(SQLServerDriverIntProperty.PORT_NUMBER.toString());
/*     */     } 
/*     */ 
/*     */     
/* 180 */     if (this.xaLogger.isLoggable(Level.FINE)) {
/* 181 */       this.xaLogger.fine(toString() + " created by (" + paramString + ")");
/*     */     }
/*     */     
/* 184 */     this.serverInfoRetrieved = false;
/* 185 */     this.version = "0";
/* 186 */     this.instanceName = "";
/* 187 */     this.ArchitectureMSSQL = 0;
/* 188 */     this.ArchitectureOS = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized SQLServerCallableStatement getXACallableStatementHandle(int paramInt) throws SQLServerException {
/* 194 */     assert paramInt >= 0 && paramInt <= 9;
/* 195 */     assert paramInt < this.xaStatements.length;
/* 196 */     if (null != this.xaStatements[paramInt]) {
/* 197 */       return this.xaStatements[paramInt];
/*     */     }
/* 199 */     CallableStatement callableStatement = null;
/*     */     
/* 201 */     switch (paramInt)
/*     */     
/*     */     { case 0:
/* 204 */         callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_start(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 238 */         this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement;
/* 239 */         return this.xaStatements[paramInt];case 1: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_end(?, ?, ?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 2: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_prepare(?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 3: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_commit(?, ?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 4: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_rollback(?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 5: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_forget(?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 6: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_recover(?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 7: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_prepare_ex(?, ?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 8: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_rollback_ex(?, ?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];case 9: callableStatement = this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_forget_ex(?, ?, ?, ?, ?, ?)}"); this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt]; }  assert false : "Bad handle request:" + paramInt; this.xaStatements[paramInt] = (SQLServerCallableStatement)callableStatement; return this.xaStatements[paramInt];
/*     */   }
/*     */   
/*     */   private synchronized void closeXAStatements() throws SQLServerException {
/* 243 */     for (byte b = 0; b < this.xaStatements.length; b++) {
/* 244 */       if (null != this.xaStatements[b]) {
/*     */         
/* 246 */         this.xaStatements[b].close();
/* 247 */         this.xaStatements[b] = null;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   final synchronized void close() throws SQLServerException {
/*     */     try {
/* 254 */       closeXAStatements();
/*     */     }
/* 256 */     catch (Exception exception) {
/*     */       
/* 258 */       if (this.xaLogger.isLoggable(Level.WARNING)) {
/* 259 */         this.xaLogger.warning(toString() + "Closing exception ignored: " + exception);
/*     */       }
/*     */     } 
/* 262 */     if (null != this.controlConnection) {
/* 263 */       this.controlConnection.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String flagsDisplay(int paramInt) {
/* 273 */     if (0 == paramInt) return "TMNOFLAGS";
/*     */ 
/*     */     
/* 276 */     StringBuilder stringBuilder = new StringBuilder(100);
/*     */     
/* 278 */     if (0 != (0x800000 & paramInt)) stringBuilder.append("TMENDRSCAN");
/*     */     
/* 280 */     if (0 != (0x20000000 & paramInt)) {
/*     */       
/* 282 */       if (stringBuilder.length() > 0) stringBuilder.append("|"); 
/* 283 */       stringBuilder.append("TMFAIL");
/*     */     } 
/* 285 */     if (0 != (0x200000 & paramInt)) {
/*     */       
/* 287 */       if (stringBuilder.length() > 0) stringBuilder.append("|"); 
/* 288 */       stringBuilder.append("TMJOIN");
/*     */     } 
/* 290 */     if (0 != (0x40000000 & paramInt)) {
/*     */       
/* 292 */       if (stringBuilder.length() > 0) stringBuilder.append("|"); 
/* 293 */       stringBuilder.append("TMONEPHASE");
/*     */     } 
/* 295 */     if (0 != (0x8000000 & paramInt)) {
/*     */       
/* 297 */       if (stringBuilder.length() > 0) stringBuilder.append("|"); 
/* 298 */       stringBuilder.append("TMRESUME");
/*     */     } 
/* 300 */     if (0 != (0x1000000 & paramInt)) {
/*     */       
/* 302 */       if (stringBuilder.length() > 0) stringBuilder.append("|"); 
/* 303 */       stringBuilder.append("TMSTARTRSCAN");
/*     */     } 
/* 305 */     if (0 != (0x4000000 & paramInt)) {
/*     */       
/* 307 */       if (stringBuilder.length() > 0) stringBuilder.append("|"); 
/* 308 */       stringBuilder.append("TMSUCCESS");
/*     */     } 
/* 310 */     if (0 != (0x2000000 & paramInt)) {
/*     */       
/* 312 */       if (stringBuilder.length() > 0) stringBuilder.append("|"); 
/* 313 */       stringBuilder.append("TMSUSPEND");
/*     */     } 
/*     */     
/* 316 */     if (0 != (0x8000 & paramInt)) {
/*     */       
/* 318 */       if (stringBuilder.length() > 0) stringBuilder.append("|"); 
/* 319 */       stringBuilder.append("SSTRANSTIGHTLYCPLD");
/*     */     } 
/* 321 */     return stringBuilder.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String cookieDisplay(byte[] paramArrayOfbyte) {
/* 327 */     return Util.byteToHexDisplayString(paramArrayOfbyte);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private String typeDisplay(int paramInt) {
/* 333 */     switch (paramInt) {
/*     */       case 0:
/* 335 */         return "XA_START";
/* 336 */       case 1: return "XA_END";
/* 337 */       case 2: return "XA_PREPARE";
/* 338 */       case 3: return "XA_COMMIT";
/* 339 */       case 4: return "XA_ROLLBACK";
/* 340 */       case 5: return "XA_FORGET";
/* 341 */       case 6: return "XA_RECOVER";
/* 342 */     }  return "UNKNOWN" + paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final XAReturnValue DTC_XA_Interface(int paramInt1, Xid paramXid, int paramInt2) throws XAException {
/* 351 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 352 */       this.xaLogger.finer(toString() + " Calling XA function for type:" + typeDisplay(paramInt1) + " flags:" + flagsDisplay(paramInt2) + " xid:" + XidImpl.xidDisplay(paramXid));
/*     */     }
/* 354 */     int i = 0;
/* 355 */     byte[] arrayOfByte1 = null;
/* 356 */     byte[] arrayOfByte2 = null;
/* 357 */     if (paramXid != null) {
/*     */       
/* 359 */       i = paramXid.getFormatId();
/* 360 */       arrayOfByte1 = paramXid.getGlobalTransactionId();
/* 361 */       arrayOfByte2 = paramXid.getBranchQualifier();
/*     */     } 
/*     */     
/* 364 */     String str = "DTC_XA_";
/* 365 */     byte b = 1;
/* 366 */     int j = 0;
/* 367 */     XAReturnValue xAReturnValue = new XAReturnValue();
/*     */     
/* 369 */     SQLServerCallableStatement sQLServerCallableStatement = null;
/*     */     
/*     */     try {
/* 372 */       synchronized (this) {
/*     */         
/* 374 */         if (this.controlConnection == null) {
/*     */           
/*     */           try {
/*     */             
/* 378 */             synchronized (xaInitLock) {
/*     */               
/* 380 */               if (!xaInitDone)
/*     */               {
/* 382 */                 SQLServerCallableStatement sQLServerCallableStatement1 = null;
/*     */                 
/* 384 */                 sQLServerCallableStatement1 = (SQLServerCallableStatement)this.controlConnection.prepareCall("{call master..xp_sqljdbc_xa_init_ex(?, ?,?)}");
/* 385 */                 sQLServerCallableStatement1.registerOutParameter(1, 4);
/* 386 */                 sQLServerCallableStatement1.registerOutParameter(2, 1);
/* 387 */                 sQLServerCallableStatement1.registerOutParameter(3, 1);
/*     */                 
/*     */                 try {
/* 390 */                   sQLServerCallableStatement1.execute();
/*     */                 }
/* 392 */                 catch (SQLServerException sQLServerException) {
/*     */ 
/*     */                   
/*     */                   try {
/* 396 */                     sQLServerCallableStatement1.close();
/*     */                     
/* 398 */                     this.controlConnection.close();
/*     */                   }
/* 400 */                   catch (SQLException sQLException) {
/*     */ 
/*     */                     
/* 403 */                     if (this.xaLogger.isLoggable(Level.FINER))
/* 404 */                       this.xaLogger.finer(toString() + " Ignoring exception when closing failed execution. exception:" + sQLException); 
/*     */                   } 
/* 406 */                   if (this.xaLogger.isLoggable(Level.FINER))
/* 407 */                     this.xaLogger.finer(toString() + " exception:" + sQLServerException); 
/* 408 */                   throw sQLServerException;
/*     */                 } 
/*     */ 
/*     */                 
/* 412 */                 int k = sQLServerCallableStatement1.getInt(1);
/* 413 */                 String str2 = sQLServerCallableStatement1.getString(2);
/* 414 */                 String str3 = sQLServerCallableStatement1.getString(3);
/* 415 */                 if (this.xaLogger.isLoggable(Level.FINE))
/* 416 */                   this.xaLogger.fine(toString() + " Server XA DLL version:" + str3); 
/* 417 */                 sQLServerCallableStatement1.close();
/* 418 */                 if (0 != k) {
/*     */                   
/* 420 */                   assert null != str2 && str2.length() > 1;
/* 421 */                   this.controlConnection.close();
/*     */                   
/* 423 */                   MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToInitializeXA"));
/* 424 */                   Object[] arrayOfObject = { String.valueOf(k), str2 };
/* 425 */                   XAException xAException = new XAException(messageFormat.format(arrayOfObject));
/* 426 */                   xAException.errorCode = k;
/* 427 */                   if (this.xaLogger.isLoggable(Level.FINER))
/* 428 */                     this.xaLogger.finer(toString() + " exception:" + xAException); 
/* 429 */                   throw xAException;
/*     */                 } 
/*     */                 
/* 432 */                 xaInitDone = true;
/*     */               }
/*     */             
/*     */             } 
/* 436 */           } catch (SQLServerException sQLServerException) {
/*     */             
/* 438 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToCreateXAConnection"));
/* 439 */             Object[] arrayOfObject = { new String(sQLServerException.getMessage()) };
/* 440 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 441 */               this.xaLogger.finer(toString() + " exception:" + messageFormat.format(arrayOfObject)); 
/* 442 */             SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
/*     */           } 
/*     */         }
/*     */       } 
/*     */       
/* 447 */       switch (paramInt1) {
/*     */         
/*     */         case 0:
/* 450 */           if (!this.serverInfoRetrieved) {
/*     */             
/*     */             try {
/* 453 */               this.serverInfoRetrieved = true;
/*     */               
/* 455 */               String str2 = "select convert(varchar(100), SERVERPROPERTY('Edition'))as edition,  convert(varchar(100), SERVERPROPERTY('InstanceName'))as instance, convert(varchar(100), SERVERPROPERTY('ProductVersion')) as version, SUBSTRING(@@VERSION, CHARINDEX('<', @@VERSION)+2, 2)";
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 460 */               Statement statement = this.controlConnection.createStatement();
/* 461 */               ResultSet resultSet = statement.executeQuery(str2);
/* 462 */               resultSet.next();
/*     */               
/* 464 */               String str3 = resultSet.getString(1);
/* 465 */               this.ArchitectureMSSQL = (null != str3 && str3.contains("(64-bit)")) ? 64 : 32;
/*     */ 
/*     */               
/* 468 */               this.instanceName = (resultSet.getString(2) == null) ? "MSSQLSERVER" : resultSet.getString(2);
/* 469 */               this.version = resultSet.getString(3);
/* 470 */               if (null == this.version) {
/*     */                 
/* 472 */                 this.version = "0";
/*     */               }
/* 474 */               else if (-1 != this.version.indexOf('.')) {
/*     */                 
/* 476 */                 this.version = this.version.substring(0, this.version.indexOf('.'));
/*     */               } 
/*     */ 
/*     */ 
/*     */               
/* 481 */               this.ArchitectureOS = Integer.parseInt(resultSet.getString(4));
/*     */               
/* 483 */               resultSet.close();
/* 484 */               statement.close();
/*     */ 
/*     */             
/*     */             }
/* 488 */             catch (Exception exception) {
/* 489 */               if (this.xaLogger.isLoggable(Level.WARNING)) {
/* 490 */                 this.xaLogger.warning(toString() + " Cannot retrieve server information: :" + exception.getMessage());
/*     */               }
/*     */             } 
/*     */           }
/* 494 */           str = "START:";
/* 495 */           sQLServerCallableStatement = getXACallableStatementHandle(0);
/* 496 */           sQLServerCallableStatement.registerOutParameter(b++, 4);
/* 497 */           sQLServerCallableStatement.registerOutParameter(b++, 1);
/* 498 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
/* 499 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
/* 500 */           sQLServerCallableStatement.setInt(b++, paramInt2);
/* 501 */           sQLServerCallableStatement.registerOutParameter(b++, -2);
/* 502 */           sQLServerCallableStatement.setInt(b++, this.timeoutSeconds);
/* 503 */           sQLServerCallableStatement.setInt(b++, i);
/* 504 */           sQLServerCallableStatement.registerOutParameter(b++, 1);
/* 505 */           sQLServerCallableStatement.setInt(b++, Integer.parseInt(this.version));
/* 506 */           sQLServerCallableStatement.setInt(b++, this.instanceName.length());
/* 507 */           sQLServerCallableStatement.setBytes(b++, this.instanceName.getBytes());
/* 508 */           sQLServerCallableStatement.setInt(b++, this.ArchitectureMSSQL);
/* 509 */           sQLServerCallableStatement.setInt(b++, this.ArchitectureOS);
/* 510 */           sQLServerCallableStatement.setInt(b++, this.isTransacrionTimeoutSet);
/* 511 */           sQLServerCallableStatement.registerOutParameter(b++, -2);
/*     */           break;
/*     */ 
/*     */         
/*     */         case 1:
/* 516 */           str = "END:";
/* 517 */           sQLServerCallableStatement = getXACallableStatementHandle(1);
/* 518 */           sQLServerCallableStatement.registerOutParameter(b++, 4);
/* 519 */           sQLServerCallableStatement.registerOutParameter(b++, 1);
/* 520 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
/* 521 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
/* 522 */           sQLServerCallableStatement.setInt(b++, paramInt2);
/* 523 */           sQLServerCallableStatement.setInt(b++, i);
/* 524 */           sQLServerCallableStatement.registerOutParameter(b++, -2);
/*     */           break;
/*     */         
/*     */         case 2:
/* 528 */           str = "PREPARE:";
/* 529 */           if ((0x8000 & paramInt2) == 32768) {
/* 530 */             sQLServerCallableStatement = getXACallableStatementHandle(7);
/*     */           } else {
/* 532 */             sQLServerCallableStatement = getXACallableStatementHandle(2);
/*     */           } 
/* 534 */           sQLServerCallableStatement.registerOutParameter(b++, 4);
/* 535 */           sQLServerCallableStatement.registerOutParameter(b++, 1);
/* 536 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
/* 537 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
/* 538 */           if ((0x8000 & paramInt2) == 32768)
/* 539 */             sQLServerCallableStatement.setInt(b++, paramInt2); 
/* 540 */           sQLServerCallableStatement.setInt(b++, i);
/*     */           break;
/*     */         
/*     */         case 3:
/* 544 */           str = "COMMIT:";
/* 545 */           sQLServerCallableStatement = getXACallableStatementHandle(3);
/* 546 */           sQLServerCallableStatement.registerOutParameter(b++, 4);
/* 547 */           sQLServerCallableStatement.registerOutParameter(b++, 1);
/* 548 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
/* 549 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
/* 550 */           sQLServerCallableStatement.setInt(b++, paramInt2);
/* 551 */           sQLServerCallableStatement.setInt(b++, i);
/*     */           break;
/*     */         
/*     */         case 4:
/* 555 */           str = "ROLLBACK:";
/* 556 */           if ((0x8000 & paramInt2) == 32768) {
/* 557 */             sQLServerCallableStatement = getXACallableStatementHandle(8);
/*     */           } else {
/* 559 */             sQLServerCallableStatement = getXACallableStatementHandle(4);
/*     */           } 
/* 561 */           sQLServerCallableStatement.registerOutParameter(b++, 4);
/* 562 */           sQLServerCallableStatement.registerOutParameter(b++, 1);
/* 563 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
/* 564 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
/* 565 */           if ((0x8000 & paramInt2) == 32768)
/* 566 */             sQLServerCallableStatement.setInt(b++, paramInt2); 
/* 567 */           sQLServerCallableStatement.setInt(b++, i);
/*     */           break;
/*     */         
/*     */         case 5:
/* 571 */           str = "FORGET:";
/* 572 */           if ((0x8000 & paramInt2) == 32768) {
/* 573 */             sQLServerCallableStatement = getXACallableStatementHandle(9);
/*     */           } else {
/* 575 */             sQLServerCallableStatement = getXACallableStatementHandle(5);
/* 576 */           }  sQLServerCallableStatement.registerOutParameter(b++, 4);
/* 577 */           sQLServerCallableStatement.registerOutParameter(b++, 1);
/* 578 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte1);
/* 579 */           sQLServerCallableStatement.setBytes(b++, arrayOfByte2);
/* 580 */           if ((0x8000 & paramInt2) == 32768)
/* 581 */             sQLServerCallableStatement.setInt(b++, paramInt2); 
/* 582 */           sQLServerCallableStatement.setInt(b++, i);
/*     */           break;
/*     */         
/*     */         case 6:
/* 586 */           str = "RECOVER:";
/* 587 */           sQLServerCallableStatement = getXACallableStatementHandle(6);
/* 588 */           sQLServerCallableStatement.registerOutParameter(b++, 4);
/* 589 */           sQLServerCallableStatement.registerOutParameter(b++, 1);
/* 590 */           sQLServerCallableStatement.setInt(b++, paramInt2);
/* 591 */           sQLServerCallableStatement.registerOutParameter(b++, -2);
/*     */           break;
/*     */         
/*     */         default:
/* 595 */           assert false : "Unknown execution type:" + paramInt1;
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 602 */       sQLServerCallableStatement.execute();
/* 603 */       j = sQLServerCallableStatement.getInt(1);
/* 604 */       String str1 = sQLServerCallableStatement.getString(2);
/* 605 */       if (paramInt1 == 0) {
/*     */         
/* 607 */         String str2 = sQLServerCallableStatement.getString(9);
/* 608 */         if (this.xaLogger.isLoggable(Level.FINE)) {
/*     */           
/* 610 */           this.xaLogger.fine(toString() + " Server XA DLL version:" + str2);
/* 611 */           if (null != sQLServerCallableStatement.getString(16)) {
/*     */             
/* 613 */             StringBuffer stringBuffer = new StringBuffer(sQLServerCallableStatement.getString(16));
/* 614 */             stringBuffer.insert(20, '-');
/* 615 */             stringBuffer.insert(16, '-');
/* 616 */             stringBuffer.insert(12, '-');
/* 617 */             stringBuffer.insert(8, '-');
/* 618 */             this.xaLogger.fine(toString() + " XID to UoW mapping for XA type:XA_START XID: " + XidImpl.xidDisplay(paramXid) + " UoW: " + stringBuffer.toString());
/*     */           } 
/*     */         } 
/*     */       } 
/* 622 */       if (paramInt1 == 1)
/*     */       {
/* 624 */         if (this.xaLogger.isLoggable(Level.FINE))
/*     */         {
/* 626 */           if (null != sQLServerCallableStatement.getString(7)) {
/*     */             
/* 628 */             StringBuffer stringBuffer = new StringBuffer(sQLServerCallableStatement.getString(7));
/* 629 */             stringBuffer.insert(20, '-');
/* 630 */             stringBuffer.insert(16, '-');
/* 631 */             stringBuffer.insert(12, '-');
/* 632 */             stringBuffer.insert(8, '-');
/* 633 */             this.xaLogger.fine(toString() + " XID to UoW mapping for XA type:XA_END XID: " + XidImpl.xidDisplay(paramXid) + " UoW: " + stringBuffer.toString());
/*     */           } 
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 639 */       if ((3 == j && 1 != paramInt1 && 2 != paramInt1) || (0 != j && 3 != j)) {
/*     */ 
/*     */         
/* 642 */         assert null != str1 && str1.length() > 1;
/* 643 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedFunctionXA"));
/* 644 */         Object[] arrayOfObject = { str, String.valueOf(j), str1 };
/* 645 */         XAException xAException = new XAException(messageFormat.format(arrayOfObject));
/* 646 */         xAException.errorCode = j;
/*     */         
/* 648 */         if (paramInt1 == 1 && -7 == j) {
/*     */           
/*     */           try {
/*     */             
/* 652 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 653 */               this.xaLogger.finer(toString() + " Begin un-enlist, enlisted count:" + this.enlistedTransactionCount); 
/* 654 */             this.con.JTAUnenlistConnection();
/* 655 */             this.enlistedTransactionCount--;
/* 656 */             if (this.xaLogger.isLoggable(Level.FINER)) {
/* 657 */               this.xaLogger.finer(toString() + " End un-enlist, enlisted count:" + this.enlistedTransactionCount);
/*     */             }
/* 659 */           } catch (SQLServerException sQLServerException) {
/*     */ 
/*     */             
/* 662 */             if (this.xaLogger.isLoggable(Level.FINER)) {
/* 663 */               this.xaLogger.finer(toString() + " Ignoring exception:" + sQLServerException);
/*     */             }
/*     */           } 
/*     */         }
/*     */         
/* 668 */         throw xAException;
/*     */       } 
/*     */ 
/*     */       
/* 672 */       if (paramInt1 == 0) {
/*     */ 
/*     */ 
/*     */         
/* 676 */         byte[] arrayOfByte = sQLServerCallableStatement.getBytes(6);
/* 677 */         if (arrayOfByte == null) {
/*     */           
/* 679 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noTransactionCookie"));
/* 680 */           Object[] arrayOfObject = { str };
/* 681 */           SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
/*     */         } else {
/*     */ 
/*     */           
/*     */           try {
/*     */ 
/*     */             
/* 688 */             if (this.xaLogger.isLoggable(Level.FINER))
/* 689 */               this.xaLogger.finer(toString() + " Begin enlisting, cookie:" + cookieDisplay(arrayOfByte) + " enlisted count:" + this.enlistedTransactionCount); 
/* 690 */             this.con.JTAEnlistConnection(arrayOfByte);
/* 691 */             this.enlistedTransactionCount++;
/* 692 */             if (this.xaLogger.isLoggable(Level.FINER)) {
/* 693 */               this.xaLogger.finer(toString() + " End enlisting, cookie:" + cookieDisplay(arrayOfByte) + " enlisted count:" + this.enlistedTransactionCount);
/*     */             }
/* 695 */           } catch (SQLServerException sQLServerException) {
/*     */             
/* 697 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToEnlist"));
/* 698 */             Object[] arrayOfObject = { sQLServerException.getMessage() };
/* 699 */             SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 704 */       if (paramInt1 == 1) {
/*     */         
/*     */         try {
/*     */           
/* 708 */           if (this.xaLogger.isLoggable(Level.FINER))
/* 709 */             this.xaLogger.finer(toString() + " Begin un-enlist, enlisted count:" + this.enlistedTransactionCount); 
/* 710 */           this.con.JTAUnenlistConnection();
/* 711 */           this.enlistedTransactionCount--;
/* 712 */           if (this.xaLogger.isLoggable(Level.FINER)) {
/* 713 */             this.xaLogger.finer(toString() + " End un-enlist, enlisted count:" + this.enlistedTransactionCount);
/*     */           }
/* 715 */         } catch (SQLServerException sQLServerException) {
/*     */           
/* 717 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToUnEnlist"));
/* 718 */           Object[] arrayOfObject = { sQLServerException.getMessage() };
/* 719 */           SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
/*     */         } 
/*     */       }
/* 722 */       if (paramInt1 == 6) {
/*     */         try
/*     */         {
/*     */ 
/*     */           
/* 727 */           xAReturnValue.bData = sQLServerCallableStatement.getBytes(4);
/*     */         }
/* 729 */         catch (SQLServerException sQLServerException)
/*     */         {
/* 731 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToReadRecoveryXIDs"));
/* 732 */           Object[] arrayOfObject = { sQLServerException.getMessage() };
/* 733 */           SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
/*     */         }
/*     */       
/*     */       }
/*     */     }
/* 738 */     catch (SQLServerException sQLServerException) {
/*     */       
/* 740 */       if (this.xaLogger.isLoggable(Level.FINER))
/* 741 */         this.xaLogger.finer(toString() + " exception:" + sQLServerException); 
/* 742 */       XAException xAException = new XAException(sQLServerException.toString());
/* 743 */       xAException.errorCode = -3;
/* 744 */       throw xAException;
/*     */     } 
/*     */     
/* 747 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 748 */       this.xaLogger.finer(toString() + " Status:" + j);
/*     */     }
/* 750 */     xAReturnValue.nStatus = j;
/* 751 */     return xAReturnValue;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void start(Xid paramXid, int paramInt) throws XAException {
/* 773 */     this.tightlyCoupled = paramInt & 0x8000;
/* 774 */     DTC_XA_Interface(0, paramXid, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void end(Xid paramXid, int paramInt) throws XAException {
/* 787 */     DTC_XA_Interface(1, paramXid, paramInt | this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int prepare(Xid paramXid) throws XAException {
/* 799 */     int i = 0;
/* 800 */     XAReturnValue xAReturnValue = DTC_XA_Interface(2, paramXid, this.tightlyCoupled);
/* 801 */     i = xAReturnValue.nStatus;
/*     */     
/* 803 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public void commit(Xid paramXid, boolean paramBoolean) throws XAException {
/* 808 */     DTC_XA_Interface(3, paramXid, (paramBoolean ? 1073741824 : 0) | this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */   
/*     */   public void rollback(Xid paramXid) throws XAException {
/* 813 */     DTC_XA_Interface(4, paramXid, this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */   
/*     */   public void forget(Xid paramXid) throws XAException {
/* 818 */     DTC_XA_Interface(5, paramXid, this.tightlyCoupled);
/*     */   }
/*     */ 
/*     */   
/*     */   public Xid[] recover(int paramInt) throws XAException {
/* 823 */     XAReturnValue xAReturnValue = DTC_XA_Interface(6, null, paramInt | this.tightlyCoupled);
/* 824 */     int i = 0;
/* 825 */     Vector<XidImpl> vector = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 836 */     if (null == xAReturnValue.bData) return (Xid[])new XidImpl[0];
/*     */     
/* 838 */     while (i < xAReturnValue.bData.length) {
/*     */       
/* 840 */       int j = 1;
/* 841 */       int k = 0; int m;
/* 842 */       for (m = 0; m < 4; m++) {
/*     */         
/* 844 */         int i1 = xAReturnValue.bData[i + m] & 0xFF;
/* 845 */         i1 *= j;
/* 846 */         k += i1;
/* 847 */         j *= 256;
/*     */       } 
/* 849 */       i += 4;
/* 850 */       m = xAReturnValue.bData[i++] & 0xFF;
/* 851 */       int n = xAReturnValue.bData[i++] & 0xFF;
/* 852 */       byte[] arrayOfByte1 = new byte[m];
/* 853 */       byte[] arrayOfByte2 = new byte[n];
/* 854 */       System.arraycopy(xAReturnValue.bData, i, arrayOfByte1, 0, m);
/* 855 */       i += m;
/* 856 */       System.arraycopy(xAReturnValue.bData, i, arrayOfByte2, 0, n);
/* 857 */       i += n;
/* 858 */       XidImpl xidImpl = new XidImpl(k, arrayOfByte1, arrayOfByte2);
/* 859 */       vector.add(xidImpl);
/*     */     } 
/* 861 */     XidImpl[] arrayOfXidImpl = new XidImpl[vector.size()];
/* 862 */     for (byte b = 0; b < vector.size(); b++) {
/*     */       
/* 864 */       arrayOfXidImpl[b] = vector.elementAt(b);
/* 865 */       if (this.xaLogger.isLoggable(Level.FINER))
/* 866 */         this.xaLogger.finer(toString() + arrayOfXidImpl[b].toString()); 
/*     */     } 
/* 868 */     return (Xid[])arrayOfXidImpl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSameRM(XAResource paramXAResource) throws XAException {
/* 875 */     if (this.xaLogger.isLoggable(Level.FINER)) {
/* 876 */       this.xaLogger.finer(toString() + " xares:" + paramXAResource);
/*     */     }
/*     */     
/* 879 */     if (!(paramXAResource instanceof SQLServerXAResource))
/* 880 */       return false; 
/* 881 */     SQLServerXAResource sQLServerXAResource = (SQLServerXAResource)paramXAResource;
/* 882 */     return sQLServerXAResource.sResourceManagerId.equals(this.sResourceManagerId);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setTransactionTimeout(int paramInt) throws XAException {
/* 889 */     this.isTransacrionTimeoutSet = 1;
/* 890 */     this.timeoutSeconds = paramInt;
/* 891 */     if (this.xaLogger.isLoggable(Level.FINER))
/* 892 */       this.xaLogger.finer(toString() + " TransactionTimeout:" + paramInt); 
/* 893 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int getTransactionTimeout() throws XAException {
/* 898 */     return this.timeoutSeconds;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized int nextResourceID() {
/* 904 */     baseResourceID++;
/* 905 */     return baseResourceID;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerXAResource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */