/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class ActivityCorrelator
/*    */ {
/* 12 */   private static ThreadLocal<ActivityId> ActivityIdTls = new ThreadLocal<ActivityId>()
/*    */     {
/*    */       protected ActivityId initialValue()
/*    */       {
/* 16 */         return new ActivityId();
/*    */       }
/*    */     };
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ActivityId getCurrent() {
/* 24 */     return ActivityIdTls.get();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   static ActivityId getNext() {
/* 36 */     ActivityId activityId = getCurrent();
/*    */ 
/*    */     
/* 39 */     activityId.Increment();
/*    */ 
/*    */     
/* 42 */     return activityId;
/*    */   }
/*    */ 
/*    */   
/*    */   static void setCurrentActivityIdSentFlag() {
/* 47 */     ActivityId activityId = getCurrent();
/* 48 */     activityId.setSentFlag();
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ActivityCorrelator.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */