package com.microsoft.sqlserver.jdbc;

abstract class SQLServerEncryptionAlgorithm {
  abstract byte[] encryptData(byte[] paramArrayOfbyte) throws SQLServerException;
  
  abstract byte[] decryptData(byte[] paramArrayOfbyte) throws SQLServerException;
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerEncryptionAlgorithm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */