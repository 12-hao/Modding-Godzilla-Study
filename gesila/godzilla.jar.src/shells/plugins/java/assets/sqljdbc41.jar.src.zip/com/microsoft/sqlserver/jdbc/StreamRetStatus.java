/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class StreamRetStatus
/*    */   extends StreamPacket
/*    */ {
/*    */   private int status;
/*    */   
/*    */   final int getStatus() {
/* 12 */     return this.status;
/*    */   }
/*    */   
/*    */   StreamRetStatus() {
/* 16 */     super(121);
/*    */   }
/*    */ 
/*    */   
/*    */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
/* 21 */     if (121 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError(); 
/* 22 */     this.status = paramTDSReader.readInt();
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/StreamRetStatus.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */