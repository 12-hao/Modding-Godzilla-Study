package com.microsoft.sqlserver.jdbc;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import microsoft.sql.DateTimeOffset;

public interface ISQLServerPreparedStatement extends PreparedStatement, ISQLServerStatement {
  void setDateTimeOffset(int paramInt, DateTimeOffset paramDateTimeOffset) throws SQLException;
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/ISQLServerPreparedStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */