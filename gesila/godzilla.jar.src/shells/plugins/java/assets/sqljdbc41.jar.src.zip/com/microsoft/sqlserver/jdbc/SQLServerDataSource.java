/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ import java.io.InvalidObjectException;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.Referenceable;
/*     */ import javax.naming.StringRefAddr;
/*     */ 
/*     */ public class SQLServerDataSource implements ISQLServerDataSource, DataSource, Serializable, Referenceable {
/*  18 */   static final Logger dsLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerDataSource");
/*  19 */   static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.DataSource");
/*     */   
/*     */   private final String loggingClassName;
/*     */   
/*     */   private boolean trustStorePasswordStripped = false;
/*     */   private static final long serialVersionUID = 654861379544314296L;
/*     */   private Properties connectionProps;
/*     */   private String dataSourceURL;
/*     */   private String dataSourceDescription;
/*  28 */   private static int baseDataSourceID = 0;
/*     */   private final String traceID;
/*     */   private transient PrintWriter logWriter;
/*     */   
/*     */   public SQLServerDataSource() {
/*  33 */     this.connectionProps = new Properties();
/*  34 */     int i = nextDataSourceID();
/*  35 */     String str = getClass().getName();
/*  36 */     this.traceID = str.substring(1 + str.lastIndexOf('.')) + ":" + i;
/*  37 */     this.loggingClassName = "com.microsoft.sqlserver.jdbc." + str.substring(1 + str.lastIndexOf('.')) + ":" + i;
/*     */   }
/*     */ 
/*     */   
/*     */   String getClassNameLogging() {
/*  42 */     return this.loggingClassName;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  46 */     return this.traceID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Connection getConnection() throws SQLServerException {
/*  53 */     loggerExternal.entering(getClassNameLogging(), "getConnection");
/*  54 */     SQLServerConnection sQLServerConnection = getConnectionInternal(null, null, null);
/*  55 */     loggerExternal.exiting(getClassNameLogging(), "getConnection", sQLServerConnection);
/*  56 */     return sQLServerConnection;
/*     */   }
/*     */   
/*     */   public Connection getConnection(String paramString1, String paramString2) throws SQLServerException {
/*  60 */     if (loggerExternal.isLoggable(Level.FINER))
/*  61 */       loggerExternal.entering(getClassNameLogging(), "getConnection", new Object[] { paramString1, "Password not traced" }); 
/*  62 */     SQLServerConnection sQLServerConnection = getConnectionInternal(paramString1, paramString2, null);
/*  63 */     loggerExternal.exiting(getClassNameLogging(), "getConnection", sQLServerConnection);
/*  64 */     return sQLServerConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLoginTimeout(int paramInt) {
/*  71 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), paramInt);
/*     */   }
/*     */   
/*     */   public int getLoginTimeout() {
/*  75 */     int i = SQLServerDriverIntProperty.LOGIN_TIMEOUT.getDefaultValue();
/*  76 */     int j = getIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOGIN_TIMEOUT.toString(), i);
/*     */     
/*  78 */     return (j == 0) ? i : j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogWriter(PrintWriter paramPrintWriter) {
/*  86 */     loggerExternal.entering(getClassNameLogging(), "setLogWriter", paramPrintWriter);
/*  87 */     this.logWriter = paramPrintWriter;
/*  88 */     loggerExternal.exiting(getClassNameLogging(), "setLogWriter");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getLogWriter() {
/*  94 */     loggerExternal.entering(getClassNameLogging(), "getLogWriter");
/*  95 */     loggerExternal.exiting(getClassNameLogging(), "getLogWriter", this.logWriter);
/*  96 */     return this.logWriter;
/*     */   }
/*     */ 
/*     */   
/*     */   public Logger getParentLogger() throws SQLFeatureNotSupportedException {
/* 101 */     DriverJDBCVersion.checkSupportsJDBC41();
/*     */ 
/*     */     
/* 104 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setApplicationName(String paramString) {
/* 113 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_NAME.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getApplicationName() {
/* 117 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_NAME.toString(), SQLServerDriverStringProperty.APPLICATION_NAME.getDefaultValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDatabaseName(String paramString) {
/* 124 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.DATABASE_NAME.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getDatabaseName() {
/* 128 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.DATABASE_NAME.toString(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setInstanceName(String paramString) {
/* 135 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.INSTANCE_NAME.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getInstanceName() {
/* 139 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.INSTANCE_NAME.toString(), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setIntegratedSecurity(boolean paramBoolean) {
/* 144 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.INTEGRATED_SECURITY.toString(), paramBoolean);
/*     */   }
/*     */   
/*     */   public void setAuthenticationScheme(String paramString) {
/* 148 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.AUTHENTICATION_SCHEME.toString(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAuthentication(String paramString) {
/* 153 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.AUTHENTICATION.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getAuthentication() {
/* 157 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.AUTHENTICATION.toString(), SQLServerDriverStringProperty.AUTHENTICATION.getDefaultValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setAccessToken(String paramString) {
/* 162 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.ACCESS_TOKEN.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getAccessToken() {
/* 166 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.ACCESS_TOKEN.toString(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setColumnEncryptionSetting(String paramString) {
/* 176 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getColumnEncryptionSetting() {
/* 180 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.COLUMN_ENCRYPTION.toString(), SQLServerDriverStringProperty.COLUMN_ENCRYPTION.getDefaultValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setKeyStoreAuthentication(String paramString) {
/* 185 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getKeyStoreAuthentication() {
/* 189 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.toString(), SQLServerDriverStringProperty.KEY_STORE_AUTHENTICATION.getDefaultValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setKeyStoreSecret(String paramString) {
/* 194 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_SECRET.toString(), paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setKeyStoreLocation(String paramString) {
/* 199 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getKeyStoreLocation() {
/* 203 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.KEY_STORE_LOCATION.toString(), SQLServerDriverStringProperty.KEY_STORE_LOCATION.getDefaultValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setLastUpdateCount(boolean paramBoolean) {
/* 208 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString(), paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean getLastUpdateCount() {
/* 212 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.toString(), SQLServerDriverBooleanProperty.LAST_UPDATE_COUNT.getDefaultValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEncrypt(boolean paramBoolean) {
/* 218 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.ENCRYPT.toString(), paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean getEncrypt() {
/* 222 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.ENCRYPT.toString(), SQLServerDriverBooleanProperty.ENCRYPT.getDefaultValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTransparentNetworkIPResolution(boolean paramBoolean) {
/* 227 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.toString(), paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean getTransparentNetworkIPResolution() {
/* 231 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.toString(), SQLServerDriverBooleanProperty.TRANSPARENT_NETWORK_IP_RESOLUTION.getDefaultValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setTrustServerCertificate(boolean paramBoolean) {
/* 236 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString(), paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean getTrustServerCertificate() {
/* 240 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.toString(), SQLServerDriverBooleanProperty.TRUST_SERVER_CERTIFICATE.getDefaultValue());
/*     */   }
/*     */   
/*     */   public void setTrustStore(String paramString) {
/* 244 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getTrustStore() {
/* 248 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE.toString(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTrustStorePassword(String paramString) {
/* 254 */     if (paramString != null)
/* 255 */       this.trustStorePasswordStripped = false; 
/* 256 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString(), paramString);
/*     */   }
/*     */   
/*     */   public void setHostNameInCertificate(String paramString) {
/* 260 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getHostNameInCertificate() {
/* 264 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLockTimeout(int paramInt) {
/* 274 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOCK_TIMEOUT.toString(), paramInt);
/*     */   }
/*     */   
/*     */   public int getLockTimeout() {
/* 278 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.LOCK_TIMEOUT.toString(), SQLServerDriverIntProperty.LOCK_TIMEOUT.getDefaultValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPassword(String paramString) {
/* 286 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.PASSWORD.toString(), paramString);
/*     */   }
/*     */   
/*     */   String getPassword() {
/* 290 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.PASSWORD.toString(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPortNumber(int paramInt) {
/* 300 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.PORT_NUMBER.toString(), paramInt);
/*     */   }
/*     */   
/*     */   public int getPortNumber() {
/* 304 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.PORT_NUMBER.toString(), SQLServerDriverIntProperty.PORT_NUMBER.getDefaultValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSelectMethod(String paramString) {
/* 315 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SELECT_METHOD.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getSelectMethod() {
/* 319 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SELECT_METHOD.toString(), SQLServerDriverStringProperty.SELECT_METHOD.getDefaultValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setResponseBuffering(String paramString) {
/* 324 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getResponseBuffering() {
/* 328 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.RESPONSE_BUFFERING.toString(), SQLServerDriverStringProperty.RESPONSE_BUFFERING.getDefaultValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setApplicationIntent(String paramString) {
/* 333 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_INTENT.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getApplicationIntent() {
/* 337 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.APPLICATION_INTENT.toString(), SQLServerDriverStringProperty.APPLICATION_INTENT.getDefaultValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setSendTimeAsDatetime(boolean paramBoolean) {
/* 342 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getSendTimeAsDatetime() {
/* 347 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.toString(), SQLServerDriverBooleanProperty.SEND_TIME_AS_DATETIME.getDefaultValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSendStringParametersAsUnicode(boolean paramBoolean) {
/* 357 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean getSendStringParametersAsUnicode() {
/* 361 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.toString(), SQLServerDriverBooleanProperty.SEND_STRING_PARAMETERS_AS_UNICODE.getDefaultValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public void setServerNameAsACE(boolean paramBoolean) {
/* 366 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString(), paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean getServerNameAsACE() {
/* 370 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.toString(), SQLServerDriverBooleanProperty.SERVER_NAME_AS_ACE.getDefaultValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServerName(String paramString) {
/* 376 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_NAME.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getServerName() {
/* 380 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_NAME.toString(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setServerSpn(String paramString) {
/* 386 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_SPN.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getServerSpn() {
/* 390 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.SERVER_SPN.toString(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFailoverPartner(String paramString) {
/* 396 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.FAILOVER_PARTNER.toString(), paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFailoverPartner() {
/* 402 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.FAILOVER_PARTNER.toString(), null);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setMultiSubnetFailover(boolean paramBoolean) {
/* 407 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString(), paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean getMultiSubnetFailover() {
/* 412 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.toString(), SQLServerDriverBooleanProperty.MULTI_SUBNET_FAILOVER.getDefaultValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setUser(String paramString) {
/* 419 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.USER.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getUser() {
/* 423 */     return getStringProperty(this.connectionProps, SQLServerDriverStringProperty.USER.toString(), null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setWorkstationID(String paramString) {
/* 432 */     setStringProperty(this.connectionProps, SQLServerDriverStringProperty.WORKSTATION_ID.toString(), paramString);
/*     */   }
/*     */   
/*     */   public String getWorkstationID() {
/* 436 */     if (loggerExternal.isLoggable(Level.FINER))
/* 437 */       loggerExternal.entering(getClassNameLogging(), "getWorkstationID"); 
/* 438 */     String str = this.connectionProps.getProperty(SQLServerDriverStringProperty.WORKSTATION_ID.toString());
/*     */     
/* 440 */     if (null == str)
/*     */     {
/* 442 */       str = Util.lookupHostName();
/*     */     }
/* 444 */     loggerExternal.exiting(getClassNameLogging(), "getWorkstationID", str);
/* 445 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXopenStates(boolean paramBoolean) {
/* 454 */     setBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.XOPEN_STATES.toString(), paramBoolean);
/*     */   }
/*     */   
/*     */   public boolean getXopenStates() {
/* 458 */     return getBooleanProperty(this.connectionProps, SQLServerDriverBooleanProperty.XOPEN_STATES.toString(), SQLServerDriverBooleanProperty.XOPEN_STATES.getDefaultValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setURL(String paramString) {
/* 476 */     loggerExternal.entering(getClassNameLogging(), "setURL", paramString);
/*     */     
/* 478 */     this.dataSourceURL = paramString;
/* 479 */     loggerExternal.exiting(getClassNameLogging(), "setURL");
/*     */   }
/*     */   
/*     */   public String getURL() {
/* 483 */     String str = this.dataSourceURL;
/* 484 */     loggerExternal.entering(getClassNameLogging(), "getURL");
/*     */     
/* 486 */     if (null == this.dataSourceURL)
/* 487 */       str = "jdbc:sqlserver://"; 
/* 488 */     loggerExternal.exiting(getClassNameLogging(), "getURL", str);
/* 489 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescription(String paramString) {
/* 498 */     loggerExternal.entering(getClassNameLogging(), "setDescription", paramString);
/* 499 */     this.dataSourceDescription = paramString;
/* 500 */     loggerExternal.exiting(getClassNameLogging(), "setDescription");
/*     */   }
/*     */   
/*     */   public String getDescription() {
/* 504 */     loggerExternal.entering(getClassNameLogging(), "getDescription");
/* 505 */     loggerExternal.exiting(getClassNameLogging(), "getDescription", this.dataSourceDescription);
/* 506 */     return this.dataSourceDescription;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPacketSize(int paramInt) {
/* 515 */     setIntProperty(this.connectionProps, SQLServerDriverIntProperty.PACKET_SIZE.toString(), paramInt);
/*     */   }
/*     */   
/*     */   public int getPacketSize() {
/* 519 */     return getIntProperty(this.connectionProps, SQLServerDriverIntProperty.PACKET_SIZE.toString(), SQLServerDriverIntProperty.PACKET_SIZE.getDefaultValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setStringProperty(Properties paramProperties, String paramString1, String paramString2) {
/* 547 */     if (loggerExternal.isLoggable(Level.FINER) && !paramString1.contains("password") && !paramString1.contains("Password")) {
/*     */       
/* 549 */       loggerExternal.entering(getClassNameLogging(), "set" + paramString1, paramString2);
/*     */     } else {
/*     */       
/* 552 */       loggerExternal.entering(getClassNameLogging(), "set" + paramString1);
/* 553 */     }  if (null != paramString2)
/* 554 */       paramProperties.setProperty(paramString1, paramString2); 
/* 555 */     loggerExternal.exiting(getClassNameLogging(), "set" + paramString1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getStringProperty(Properties paramProperties, String paramString1, String paramString2) {
/* 563 */     if (loggerExternal.isLoggable(Level.FINER))
/* 564 */       loggerExternal.entering(getClassNameLogging(), "get" + paramString1); 
/* 565 */     String str = paramProperties.getProperty(paramString1);
/* 566 */     if (null == str)
/* 567 */       str = paramString2; 
/* 568 */     if (loggerExternal.isLoggable(Level.FINER) && !paramString1.contains("password") && !paramString1.contains("Password"))
/* 569 */       loggerExternal.exiting(getClassNameLogging(), "get" + paramString1, str); 
/* 570 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setIntProperty(Properties paramProperties, String paramString, int paramInt) {
/* 577 */     if (loggerExternal.isLoggable(Level.FINER))
/* 578 */       loggerExternal.entering(getClassNameLogging(), "set" + paramString, new Integer(paramInt)); 
/* 579 */     paramProperties.setProperty(paramString, (new Integer(paramInt)).toString());
/* 580 */     loggerExternal.exiting(getClassNameLogging(), "set" + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getIntProperty(Properties paramProperties, String paramString, int paramInt) {
/* 588 */     if (loggerExternal.isLoggable(Level.FINER))
/* 589 */       loggerExternal.entering(getClassNameLogging(), "get" + paramString); 
/* 590 */     String str = paramProperties.getProperty(paramString);
/* 591 */     int i = paramInt;
/* 592 */     if (null != str) {
/*     */       
/*     */       try {
/*     */         
/* 596 */         i = Integer.parseInt(str);
/*     */       }
/* 598 */       catch (NumberFormatException numberFormatException) {
/*     */ 
/*     */ 
/*     */         
/* 602 */         assert false : "Bad portNumber:-" + str;
/*     */       } 
/*     */     }
/* 605 */     if (loggerExternal.isLoggable(Level.FINER))
/* 606 */       loggerExternal.exiting(getClassNameLogging(), "get" + paramString, new Integer(i)); 
/* 607 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setBooleanProperty(Properties paramProperties, String paramString, boolean paramBoolean) {
/* 614 */     if (loggerExternal.isLoggable(Level.FINER))
/* 615 */       loggerExternal.entering(getClassNameLogging(), "set" + paramString, Boolean.valueOf(paramBoolean)); 
/* 616 */     paramProperties.setProperty(paramString, paramBoolean ? "true" : "false");
/* 617 */     loggerExternal.exiting(getClassNameLogging(), "set" + paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean getBooleanProperty(Properties paramProperties, String paramString, boolean paramBoolean) {
/*     */     Boolean bool;
/* 625 */     if (loggerExternal.isLoggable(Level.FINER))
/* 626 */       loggerExternal.entering(getClassNameLogging(), "get" + paramString); 
/* 627 */     String str = paramProperties.getProperty(paramString);
/*     */     
/* 629 */     if (null == str) {
/*     */       
/* 631 */       bool = Boolean.valueOf(paramBoolean);
/*     */     
/*     */     }
/*     */     else {
/*     */ 
/*     */       
/* 637 */       bool = Boolean.valueOf(str);
/*     */     } 
/* 639 */     loggerExternal.exiting(getClassNameLogging(), "get" + paramString, bool);
/* 640 */     return bool.booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerConnection getConnectionInternal(String paramString1, String paramString2, SQLServerPooledConnection paramSQLServerPooledConnection) throws SQLServerException {
/* 655 */     Properties properties1 = null;
/* 656 */     Properties properties2 = null;
/*     */     
/* 658 */     if (this.trustStorePasswordStripped) {
/* 659 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_referencingFailedTSP"), null, true);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 664 */     if (null != paramString1 || null != paramString2) {
/*     */       
/* 666 */       properties1 = (Properties)this.connectionProps.clone();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 671 */       properties1.remove(SQLServerDriverStringProperty.USER.toString());
/* 672 */       properties1.remove(SQLServerDriverStringProperty.PASSWORD.toString());
/*     */       
/* 674 */       if (null != paramString1)
/* 675 */         properties1.put(SQLServerDriverStringProperty.USER.toString(), paramString1); 
/* 676 */       if (null != paramString2) {
/* 677 */         properties1.put(SQLServerDriverStringProperty.PASSWORD.toString(), paramString2);
/*     */       }
/*     */     } else {
/*     */       
/* 681 */       properties1 = this.connectionProps;
/*     */     } 
/*     */ 
/*     */     
/* 685 */     if (null != this.dataSourceURL) {
/*     */       
/* 687 */       Properties properties = Util.parseUrl(this.dataSourceURL, dsLogger);
/*     */       
/* 689 */       if (null == properties) {
/* 690 */         SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_errorConnectionString"), null, true);
/*     */       }
/*     */       
/* 693 */       properties2 = SQLServerDriver.mergeURLAndSuppliedProperties(properties, properties1);
/*     */     }
/*     */     else {
/*     */       
/* 697 */       properties2 = properties1;
/*     */     } 
/*     */ 
/*     */     
/* 701 */     if (dsLogger.isLoggable(Level.FINER))
/* 702 */       dsLogger.finer(toString() + " Begin create new connection."); 
/* 703 */     SQLServerConnection sQLServerConnection = new SQLServerConnection(toString());
/* 704 */     sQLServerConnection.connect(properties2, paramSQLServerPooledConnection);
/* 705 */     if (dsLogger.isLoggable(Level.FINER))
/* 706 */       dsLogger.finer(toString() + " End create new connection " + sQLServerConnection.toString()); 
/* 707 */     return sQLServerConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Reference getReference() {
/* 714 */     loggerExternal.entering(getClassNameLogging(), "getReference");
/* 715 */     Reference reference = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerDataSource");
/* 716 */     loggerExternal.exiting(getClassNameLogging(), "getReference", reference);
/* 717 */     return reference;
/*     */   }
/*     */ 
/*     */   
/*     */   Reference getReferenceInternal(String paramString) {
/* 722 */     if (dsLogger.isLoggable(Level.FINER)) {
/* 723 */       dsLogger.finer(toString() + " creating reference for " + paramString + ".");
/*     */     }
/* 725 */     Reference reference = new Reference(getClass().getName(), "com.microsoft.sqlserver.jdbc.SQLServerDataSourceObjectFactory", null);
/*     */     
/* 727 */     if (null != paramString) {
/* 728 */       reference.add(new StringRefAddr("class", paramString));
/*     */     }
/* 730 */     if (this.trustStorePasswordStripped) {
/* 731 */       reference.add(new StringRefAddr("trustStorePasswordStripped", "true"));
/*     */     }
/*     */     
/* 734 */     Enumeration<Object> enumeration = this.connectionProps.keys();
/* 735 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 737 */       String str = (String)enumeration.nextElement();
/*     */       
/* 739 */       if (str.equals(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString())) {
/*     */ 
/*     */         
/* 742 */         assert !this.trustStorePasswordStripped;
/* 743 */         reference.add(new StringRefAddr("trustStorePasswordStripped", "true"));
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/* 748 */       if (!str.contains(SQLServerDriverStringProperty.PASSWORD.toString())) {
/* 749 */         reference.add(new StringRefAddr(str, this.connectionProps.getProperty(str)));
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 754 */     if (null != this.dataSourceURL) {
/* 755 */       reference.add(new StringRefAddr("dataSourceURL", this.dataSourceURL));
/*     */     }
/* 757 */     if (null != this.dataSourceDescription) {
/* 758 */       reference.add(new StringRefAddr("dataSourceDescription", this.dataSourceDescription));
/*     */     }
/* 760 */     return reference;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initializeFromReference(Reference paramReference) {
/* 768 */     Enumeration<RefAddr> enumeration = paramReference.getAll();
/* 769 */     while (enumeration.hasMoreElements()) {
/*     */       
/* 771 */       StringRefAddr stringRefAddr = (StringRefAddr)enumeration.nextElement();
/* 772 */       String str1 = stringRefAddr.getType();
/* 773 */       String str2 = (String)stringRefAddr.getContent();
/*     */ 
/*     */       
/* 776 */       if (str1.equals("dataSourceURL")) {
/*     */         
/* 778 */         this.dataSourceURL = str2; continue;
/*     */       } 
/* 780 */       if (str1.equals("dataSourceDescription")) {
/*     */         
/* 782 */         this.dataSourceDescription = str2; continue;
/*     */       } 
/* 784 */       if (str1.equals("trustStorePasswordStripped")) {
/*     */         
/* 786 */         this.trustStorePasswordStripped = true;
/*     */         continue;
/*     */       } 
/* 789 */       if (false == str1.equals("class"))
/*     */       {
/*     */         
/* 792 */         this.connectionProps.setProperty(str1, str2);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
/* 799 */     loggerExternal.entering(getClassNameLogging(), "isWrapperFor", paramClass);
/* 800 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 801 */     boolean bool = paramClass.isInstance(this);
/* 802 */     loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
/* 803 */     return bool;
/*     */   }
/*     */   
/*     */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/*     */     T t;
/* 808 */     loggerExternal.entering(getClassNameLogging(), "unwrap", paramClass);
/* 809 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 814 */       t = paramClass.cast(this);
/*     */     }
/* 816 */     catch (ClassCastException classCastException) {
/*     */       
/* 818 */       throw new SQLServerException(classCastException.getMessage(), classCastException);
/*     */     } 
/* 820 */     loggerExternal.exiting(getClassNameLogging(), "unwrap", t);
/* 821 */     return t;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized int nextDataSourceID() {
/* 827 */     baseDataSourceID++;
/* 828 */     return baseDataSourceID;
/*     */   }
/*     */   
/*     */   private Object writeReplace() throws ObjectStreamException {
/* 832 */     return new SerializationProxy(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws InvalidObjectException {
/* 842 */     throw new InvalidObjectException("");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class SerializationProxy
/*     */     implements Serializable
/*     */   {
/*     */     private final Reference ref;
/*     */     
/*     */     private static final long serialVersionUID = 654661379542314226L;
/*     */ 
/*     */     
/*     */     SerializationProxy(SQLServerDataSource param1SQLServerDataSource) {
/* 856 */       this.ref = param1SQLServerDataSource.getReferenceInternal(null);
/*     */     }
/*     */     
/*     */     private Object readResolve() {
/* 860 */       SQLServerDataSource sQLServerDataSource = new SQLServerDataSource();
/* 861 */       sQLServerDataSource.initializeFromReference(this.ref);
/* 862 */       return sQLServerDataSource;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerDataSource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */