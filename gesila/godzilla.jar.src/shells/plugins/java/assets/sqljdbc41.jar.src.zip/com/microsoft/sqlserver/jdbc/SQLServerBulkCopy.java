/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.MathContext;
/*      */ import java.math.RoundingMode;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.charset.Charset;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.SimpleTimeZone;
/*      */ import java.util.TimeZone;
/*      */ import java.util.UUID;
/*      */ import java.util.Vector;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.sql.RowSet;
/*      */ import microsoft.sql.DateTimeOffset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLServerBulkCopy
/*      */   implements AutoCloseable
/*      */ {
/*      */   private static final String loggerClassName = "com.microsoft.sqlserver.jdbc.SQLServerBulkCopy";
/*      */   private static final int SQL_SERVER_2016_VERSION = 13;
/*      */   
/*      */   private class ColumnMapping
/*      */   {
/*   61 */     String sourceColumnName = null;
/*   62 */     int sourceColumnOrdinal = -1;
/*   63 */     String destinationColumnName = null;
/*   64 */     int destinationColumnOrdinal = -1;
/*      */ 
/*      */     
/*      */     ColumnMapping(String param1String1, String param1String2) {
/*   68 */       this.sourceColumnName = param1String1;
/*   69 */       this.destinationColumnName = param1String2;
/*      */     }
/*      */ 
/*      */     
/*      */     ColumnMapping(String param1String, int param1Int) {
/*   74 */       this.sourceColumnName = param1String;
/*   75 */       this.destinationColumnOrdinal = param1Int;
/*      */     }
/*      */ 
/*      */     
/*      */     ColumnMapping(int param1Int, String param1String) {
/*   80 */       this.sourceColumnOrdinal = param1Int;
/*   81 */       this.destinationColumnName = param1String;
/*      */     }
/*      */ 
/*      */     
/*      */     ColumnMapping(int param1Int1, int param1Int2) {
/*   86 */       this.sourceColumnOrdinal = param1Int1;
/*   87 */       this.destinationColumnOrdinal = param1Int2;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  102 */   private static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SQLServerConnection connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SQLServerBulkCopyOptions copyOptions;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private List<ColumnMapping> columnMappings;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean ownsConnection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String destinationTableName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ISQLServerBulkRecord sourceBulkRecord;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSet sourceResultSet;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private ResultSetMetaData sourceResultSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  156 */   private CekTable destCekTable = null;
/*      */   private Map<Integer, BulkColumnMetaData> destColumnMetadata;
/*      */   private Map<Integer, BulkColumnMetaData> srcColumnMetadata;
/*      */   private int destColumnCount;
/*      */   private int srcColumnCount;
/*      */   
/*      */   class BulkColumnMetaData {
/*      */     String columnName;
/*  164 */     SSType ssType = null; int jdbcType;
/*      */     int precision;
/*      */     int scale;
/*      */     SQLCollation collation;
/*  168 */     byte[] flags = new byte[2];
/*      */     boolean isIdentity = false;
/*      */     boolean isNullable;
/*      */     String collationName;
/*  172 */     CryptoMetadata cryptoMeta = null;
/*  173 */     DateTimeFormatter dateTimeFormatter = null;
/*      */ 
/*      */     
/*  176 */     String encryptionType = null;
/*      */ 
/*      */     
/*      */     BulkColumnMetaData(Column param1Column) throws SQLServerException {
/*  180 */       this.cryptoMeta = param1Column.getCryptoMetadata();
/*  181 */       TypeInfo typeInfo = param1Column.getTypeInfo();
/*  182 */       this.columnName = param1Column.getColumnName();
/*  183 */       this.ssType = typeInfo.getSSType();
/*  184 */       this.flags = typeInfo.getFlags();
/*  185 */       this.isIdentity = typeInfo.isIdentity();
/*  186 */       this.isNullable = typeInfo.isNullable();
/*  187 */       this.precision = typeInfo.getPrecision();
/*  188 */       this.scale = typeInfo.getScale();
/*  189 */       this.collation = typeInfo.getSQLCollation();
/*  190 */       this.jdbcType = this.ssType.getJDBCType().getIntValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     BulkColumnMetaData(String param1String, boolean param1Boolean, int param1Int1, int param1Int2, int param1Int3, DateTimeFormatter param1DateTimeFormatter) throws SQLServerException {
/*  197 */       this.columnName = param1String;
/*  198 */       this.isNullable = param1Boolean;
/*  199 */       this.precision = param1Int1;
/*  200 */       this.scale = param1Int2;
/*  201 */       this.jdbcType = param1Int3;
/*  202 */       this.dateTimeFormatter = param1DateTimeFormatter;
/*      */     }
/*      */ 
/*      */     
/*      */     BulkColumnMetaData(Column param1Column, String param1String1, String param1String2) throws SQLServerException {
/*  207 */       this(param1Column);
/*  208 */       this.collationName = param1String1;
/*  209 */       this.encryptionType = param1String2;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     BulkColumnMetaData(BulkColumnMetaData param1BulkColumnMetaData, CryptoMetadata param1CryptoMetadata) {
/*  215 */       this.columnName = param1BulkColumnMetaData.columnName;
/*  216 */       this.isNullable = param1BulkColumnMetaData.isNullable;
/*  217 */       this.precision = param1BulkColumnMetaData.precision;
/*  218 */       this.scale = param1BulkColumnMetaData.scale;
/*  219 */       this.jdbcType = param1BulkColumnMetaData.jdbcType;
/*  220 */       this.cryptoMeta = param1CryptoMetadata;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class BulkTimeoutTimer
/*      */     implements Runnable
/*      */   {
/*      */     private final int timeoutSeconds;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private int secondsRemaining;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TDSCommand command;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private Thread timerThread;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private volatile boolean canceled = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     BulkTimeoutTimer(int param1Int, TDSCommand param1TDSCommand) {
/*  258 */       assert param1Int > 0;
/*  259 */       assert null != param1TDSCommand;
/*      */       
/*  261 */       this.timeoutSeconds = param1Int;
/*  262 */       this.secondsRemaining = param1Int;
/*  263 */       this.command = param1TDSCommand;
/*      */     }
/*      */ 
/*      */     
/*      */     final void start() {
/*  268 */       this.timerThread = new Thread(this);
/*  269 */       this.timerThread.setDaemon(true);
/*  270 */       this.timerThread.start();
/*      */     }
/*      */ 
/*      */     
/*      */     final void stop() {
/*  275 */       this.canceled = true;
/*  276 */       this.timerThread.interrupt();
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean expired() {
/*  281 */       return (this.secondsRemaining <= 0);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void run() {
/*      */       try {
/*      */         do {
/*  292 */           if (this.canceled) {
/*      */             return;
/*      */           }
/*  295 */           Thread.sleep(1000L);
/*      */         }
/*  297 */         while (--this.secondsRemaining > 0);
/*      */       }
/*  299 */       catch (InterruptedException interruptedException) {
/*      */         return;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  308 */         this.command.interrupt(SQLServerException.getErrString("R_queryTimedOut"));
/*      */       }
/*  310 */       catch (SQLServerException sQLServerException) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  315 */         this.command.log(Level.FINE, "Command could not be timed out. Reason: " + sQLServerException.getMessage());
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*  320 */   private BulkTimeoutTimer timeoutTimer = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLServerBulkCopy(Connection paramConnection) throws SQLServerException {
/*  330 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy", paramConnection);
/*      */     
/*  332 */     if (null == paramConnection || !paramConnection.getClass().equals(SQLServerConnection.class))
/*      */     {
/*  334 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_invalidDestConnection"), (String)null, false);
/*      */     }
/*      */     
/*  337 */     if (paramConnection instanceof SQLServerConnection) {
/*      */       
/*  339 */       this.connection = (SQLServerConnection)paramConnection;
/*      */     }
/*      */     else {
/*      */       
/*  343 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_invalidDestConnection"), (String)null, false);
/*      */     } 
/*  345 */     this.ownsConnection = false;
/*      */ 
/*      */ 
/*      */     
/*  349 */     this.copyOptions = new SQLServerBulkCopyOptions();
/*      */     
/*  351 */     initializeDefaults();
/*      */     
/*  353 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLServerBulkCopy(String paramString) throws SQLException {
/*  364 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy", "connectionUrl not traced.");
/*  365 */     if (paramString == null || paramString.trim().equals(""))
/*      */     {
/*  367 */       throw new SQLServerException(null, SQLServerException.getErrString("R_nullConnection"), null, 0, false);
/*      */     }
/*      */     
/*  370 */     this.ownsConnection = true;
/*  371 */     SQLServerDriver sQLServerDriver = new SQLServerDriver();
/*  372 */     this.connection = (SQLServerConnection)sQLServerDriver.connect(paramString, null);
/*  373 */     if (null == this.connection)
/*      */     {
/*  375 */       throw new SQLServerException(null, SQLServerException.getErrString("R_invalidConnection"), null, 0, false);
/*      */     }
/*      */     
/*  378 */     this.copyOptions = new SQLServerBulkCopyOptions();
/*      */     
/*  380 */     initializeDefaults();
/*      */     
/*  382 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "SQLServerBulkCopy");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addColumnMapping(int paramInt1, int paramInt2) throws SQLServerException {
/*  394 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) });
/*      */     
/*  396 */     if (0 >= paramInt1) {
/*  397 */       throwInvalidArgument("sourceColumn");
/*  398 */     } else if (0 >= paramInt2) {
/*  399 */       throwInvalidArgument("destinationColumn");
/*      */     } 
/*  401 */     this.columnMappings.add(new ColumnMapping(paramInt1, paramInt2));
/*      */     
/*  403 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addColumnMapping(int paramInt, String paramString) throws SQLServerException {
/*  415 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] { Integer.valueOf(paramInt), paramString });
/*      */     
/*  417 */     if (0 >= paramInt) {
/*  418 */       throwInvalidArgument("sourceColumn");
/*  419 */     } else if (null == paramString || paramString.isEmpty()) {
/*  420 */       throwInvalidArgument("destinationColumn");
/*      */     } 
/*  422 */     this.columnMappings.add(new ColumnMapping(paramInt, paramString.trim()));
/*      */     
/*  424 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addColumnMapping(String paramString, int paramInt) throws SQLServerException {
/*  436 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] { paramString, Integer.valueOf(paramInt) });
/*      */     
/*  438 */     if (0 >= paramInt) {
/*  439 */       throwInvalidArgument("destinationColumn");
/*  440 */     } else if (null == paramString || paramString.isEmpty()) {
/*  441 */       throwInvalidArgument("sourceColumn");
/*      */     } 
/*  443 */     this.columnMappings.add(new ColumnMapping(paramString.trim(), paramInt));
/*      */     
/*  445 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addColumnMapping(String paramString1, String paramString2) throws SQLServerException {
/*  457 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping", new Object[] { paramString1, paramString2 });
/*      */     
/*  459 */     if (null == paramString1 || paramString1.isEmpty()) {
/*  460 */       throwInvalidArgument("sourceColumn");
/*  461 */     } else if (null == paramString2 || paramString2.isEmpty()) {
/*  462 */       throwInvalidArgument("destinationColumn");
/*      */     } 
/*  464 */     this.columnMappings.add(new ColumnMapping(paramString1.trim(), paramString2.trim()));
/*      */     
/*  466 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "addColumnMapping");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearColumnMappings() {
/*  474 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "clearColumnMappings");
/*      */     
/*  476 */     this.columnMappings.clear();
/*      */     
/*  478 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "clearColumnMappings");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() {
/*  486 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "close");
/*      */     
/*  488 */     if (this.ownsConnection) {
/*      */       
/*      */       try {
/*  491 */         this.connection.close();
/*  492 */       } catch (SQLException sQLException) {}
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  497 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "close");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDestinationTableName() {
/*  507 */     return this.destinationTableName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDestinationTableName(String paramString) throws SQLServerException {
/*  518 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "setDestinationTableName", paramString);
/*      */     
/*  520 */     if (null == paramString || 0 == paramString.trim().length())
/*      */     {
/*  522 */       throwInvalidArgument("tableName");
/*      */     }
/*      */     
/*  525 */     this.destinationTableName = paramString.trim();
/*      */     
/*  527 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "setDestinationTableName");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLServerBulkCopyOptions getBulkCopyOptions() {
/*  537 */     return this.copyOptions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBulkCopyOptions(SQLServerBulkCopyOptions paramSQLServerBulkCopyOptions) throws SQLServerException {
/*  549 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "updateBulkCopyOptions", paramSQLServerBulkCopyOptions);
/*      */ 
/*      */ 
/*      */     
/*  553 */     if (!this.ownsConnection && paramSQLServerBulkCopyOptions.isUseInternalTransaction())
/*      */     {
/*  555 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_invalidTransactionOption"), (String)null, false);
/*      */     }
/*      */     
/*  558 */     this.copyOptions = paramSQLServerBulkCopyOptions;
/*      */     
/*  560 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "updateBulkCopyOptions");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeToServer(ResultSet paramResultSet) throws SQLServerException {
/*  571 */     writeResultSet(paramResultSet, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeToServer(RowSet paramRowSet) throws SQLServerException {
/*  582 */     writeResultSet(paramRowSet, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeResultSet(ResultSet paramResultSet, boolean paramBoolean) throws SQLServerException {
/*  593 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
/*      */     
/*  595 */     if (null == paramResultSet)
/*      */     {
/*  597 */       throwInvalidArgument("sourceData");
/*      */     }
/*      */     
/*      */     try {
/*  601 */       if (paramBoolean)
/*      */       {
/*  603 */         if (!paramResultSet.isBeforeFirst())
/*      */         {
/*  605 */           paramResultSet.beforeFirst();
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  610 */       else if (paramResultSet.isClosed())
/*      */       {
/*  612 */         SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_resultsetClosed"), (String)null, false);
/*      */       }
/*      */     
/*  615 */     } catch (SQLException sQLException) {
/*      */       
/*  617 */       throw new SQLServerException(null, sQLException.getMessage(), null, 0, false);
/*      */     } 
/*      */     
/*  620 */     this.sourceResultSet = paramResultSet;
/*      */     
/*  622 */     this.sourceBulkRecord = null;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  627 */       this.sourceResultSetMetaData = this.sourceResultSet.getMetaData();
/*      */     }
/*  629 */     catch (SQLException sQLException) {
/*      */       
/*  631 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), sQLException);
/*      */     } 
/*      */     
/*  634 */     writeToServer();
/*      */     
/*  636 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeToServer(ISQLServerBulkRecord paramISQLServerBulkRecord) throws SQLServerException {
/*  647 */     loggerExternal.entering("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
/*      */     
/*  649 */     if (null == paramISQLServerBulkRecord)
/*      */     {
/*  651 */       throwInvalidArgument("sourceData");
/*      */     }
/*      */     
/*  654 */     this.sourceBulkRecord = paramISQLServerBulkRecord;
/*  655 */     this.sourceResultSet = null;
/*      */     
/*  657 */     writeToServer();
/*      */     
/*  659 */     loggerExternal.exiting("com.microsoft.sqlserver.jdbc.SQLServerBulkCopy", "writeToServer");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeDefaults() {
/*  667 */     this.columnMappings = new LinkedList<>();
/*  668 */     this.destinationTableName = null;
/*  669 */     this.sourceBulkRecord = null;
/*  670 */     this.sourceResultSet = null;
/*  671 */     this.sourceResultSetMetaData = null;
/*  672 */     this.srcColumnCount = 0;
/*  673 */     this.srcColumnMetadata = null;
/*  674 */     this.destColumnMetadata = null;
/*  675 */     this.destColumnCount = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void sendBulkLoadBCP() throws SQLServerException {
/*      */     final class InsertBulk
/*      */       extends TDSCommand
/*      */     {
/*      */       InsertBulk() {
/*  687 */         super("InsertBulk", 0);
/*  688 */         int i = SQLServerBulkCopy.this.copyOptions.getBulkCopyTimeout();
/*  689 */         SQLServerBulkCopy.this.timeoutTimer = (i > 0) ? new SQLServerBulkCopy.BulkTimeoutTimer(i, this) : null;
/*      */       }
/*      */ 
/*      */       
/*      */       final boolean doExecute() throws SQLServerException {
/*  694 */         if (null != SQLServerBulkCopy.this.timeoutTimer) {
/*      */           
/*  696 */           if (logger.isLoggable(Level.FINEST)) {
/*  697 */             logger.finest(toString() + ": Starting bulk timer...");
/*      */           }
/*  699 */           SQLServerBulkCopy.this.timeoutTimer.start();
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  707 */           while (SQLServerBulkCopy.this.doInsertBulk(this));
/*      */         }
/*  709 */         catch (SQLServerException sQLServerException) {
/*      */ 
/*      */           
/*  712 */           Throwable throwable = sQLServerException;
/*  713 */           while (null != throwable.getCause())
/*      */           {
/*  715 */             throwable = throwable.getCause();
/*      */           }
/*      */ 
/*      */           
/*  719 */           if (throwable instanceof SQLException)
/*      */           {
/*  721 */             SQLServerBulkCopy.this.checkForTimeoutException((SQLException)throwable, SQLServerBulkCopy.this.timeoutTimer);
/*      */           }
/*      */ 
/*      */           
/*  725 */           throw sQLServerException;
/*      */         } 
/*      */         
/*  728 */         if (null != SQLServerBulkCopy.this.timeoutTimer) {
/*      */           
/*  730 */           if (logger.isLoggable(Level.FINEST)) {
/*  731 */             logger.finest(toString() + ": Stopping bulk timer...");
/*      */           }
/*  733 */           SQLServerBulkCopy.this.timeoutTimer.stop();
/*      */         } 
/*      */         
/*  736 */         return true;
/*      */       }
/*      */     };
/*      */     
/*  740 */     this.connection.executeCommand(new InsertBulk());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void writeColumnMetaDataColumnData(TDSWriter paramTDSWriter, int paramInt) throws SQLServerException {
/*      */     boolean bool;
/*  748 */     int i = 0, j = 0;
/*  749 */     int k = 0, m = 0, n = 0;
/*  750 */     SQLCollation sQLCollation = null;
/*  751 */     SSType sSType = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  760 */     byte[] arrayOfByte1 = new byte[4];
/*  761 */     arrayOfByte1[0] = 0;
/*  762 */     arrayOfByte1[1] = 0;
/*  763 */     arrayOfByte1[2] = 0;
/*      */     
/*  765 */     arrayOfByte1[3] = 0;
/*  766 */     paramTDSWriter.writeBytes(arrayOfByte1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  775 */     int i1 = ((ColumnMapping)this.columnMappings.get(paramInt)).destinationColumnOrdinal;
/*  776 */     byte[] arrayOfByte2 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).flags;
/*  777 */     paramTDSWriter.writeBytes(arrayOfByte2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  786 */     i = ((ColumnMapping)this.columnMappings.get(paramInt)).sourceColumnOrdinal;
/*      */     
/*  788 */     k = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(i))).jdbcType;
/*  789 */     m = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(i))).precision;
/*  790 */     n = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(i))).scale;
/*  791 */     boolean bool1 = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(i))).isNullable;
/*      */ 
/*      */     
/*  794 */     sSType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).ssType;
/*  795 */     j = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).precision;
/*      */     
/*  797 */     m = validateSourcePrecision(m, k, j);
/*      */     
/*  799 */     sQLCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).collation;
/*  800 */     if (null == sQLCollation) {
/*  801 */       sQLCollation = this.connection.getDatabaseCollation();
/*      */     }
/*  803 */     if (-15 == k || -9 == k || -16 == k) {
/*      */ 
/*      */ 
/*      */       
/*  807 */       bool = (4000 < m || 4000 < j) ? true : false;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  812 */       bool = (8000 < m || 8000 < j) ? true : false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  821 */     if (this.sourceResultSet instanceof SQLServerResultSet && this.connection.isColumnEncryptionSettingEnabled()) {
/*      */ 
/*      */       
/*  824 */       k = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).jdbcType;
/*  825 */       m = j;
/*  826 */       n = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).scale;
/*      */     } 
/*      */ 
/*      */     
/*  830 */     if ((null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).encryptionType && this.copyOptions.isAllowEncryptedValueModifications()) || null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).cryptoMeta) {
/*      */ 
/*      */ 
/*      */       
/*  834 */       paramTDSWriter.writeByte((byte)-91);
/*      */       
/*  836 */       if (bool)
/*      */       {
/*  838 */         paramTDSWriter.writeShort((short)-1);
/*      */       }
/*      */       else
/*      */       {
/*  842 */         paramTDSWriter.writeShort((short)m);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  847 */     else if ((1 == k || 12 == k || -1 == k) && (SSType.BINARY == sSType || SSType.VARBINARY == sSType || SSType.VARBINARYMAX == sSType || SSType.IMAGE == sSType)) {
/*      */ 
/*      */       
/*  850 */       if (bool) {
/*      */ 
/*      */         
/*  853 */         paramTDSWriter.writeByte((byte)-91);
/*      */       }
/*      */       else {
/*      */         
/*  857 */         paramTDSWriter.writeByte((byte)((SSType.BINARY == sSType) ? 173 : 165));
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  863 */       paramTDSWriter.writeShort((short)m);
/*      */     }
/*      */     else {
/*      */       
/*  867 */       writeTypeInfo(paramTDSWriter, k, n, m, sSType, sQLCollation, bool, bool1, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  877 */     CryptoMetadata cryptoMetadata = null;
/*  878 */     if (null != (cryptoMetadata = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(i1))).cryptoMeta)) {
/*      */       
/*  880 */       int i3 = cryptoMetadata.baseTypeInfo.getSSType().getJDBCType().asJavaSqlType();
/*  881 */       int i4 = cryptoMetadata.baseTypeInfo.getPrecision();
/*      */       
/*  883 */       if (-15 == i3 || -9 == i3 || -16 == i3) {
/*      */ 
/*      */         
/*  886 */         bool = (4000 < i4) ? true : false;
/*      */       } else {
/*  888 */         bool = (8000 < i4) ? true : false;
/*      */       } 
/*      */       
/*  891 */       paramTDSWriter.writeShort(cryptoMetadata.getOrdinal());
/*  892 */       paramTDSWriter.writeBytes(arrayOfByte1);
/*      */       
/*  894 */       writeTypeInfo(paramTDSWriter, i3, cryptoMetadata.baseTypeInfo.getScale(), i4, cryptoMetadata.baseTypeInfo.getSSType(), sQLCollation, bool, bool1, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  903 */       paramTDSWriter.writeByte(cryptoMetadata.cipherAlgorithmId);
/*  904 */       paramTDSWriter.writeByte(cryptoMetadata.encryptionType.getValue());
/*  905 */       paramTDSWriter.writeByte(cryptoMetadata.normalizationRuleVersion);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  912 */     int i2 = ((ColumnMapping)this.columnMappings.get(paramInt)).destinationColumnName.length();
/*  913 */     String str = ((ColumnMapping)this.columnMappings.get(paramInt)).destinationColumnName;
/*  914 */     byte[] arrayOfByte3 = new byte[2 * i2];
/*      */     
/*  916 */     for (byte b = 0; b < i2; b++) {
/*  917 */       char c = str.charAt(b);
/*  918 */       arrayOfByte3[2 * b] = (byte)(c & 0xFF);
/*  919 */       arrayOfByte3[2 * b + 1] = (byte)(c >> 8 & 0xFF);
/*      */     } 
/*      */     
/*  922 */     paramTDSWriter.writeByte((byte)i2);
/*  923 */     paramTDSWriter.writeBytes(arrayOfByte3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void writeTypeInfo(TDSWriter paramTDSWriter, int paramInt1, int paramInt2, int paramInt3, SSType paramSSType, SQLCollation paramSQLCollation, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) throws SQLServerException {
/*  930 */     switch (paramInt1) {
/*      */       
/*      */       case 4:
/*  933 */         if (!paramBoolean2) {
/*      */           
/*  935 */           paramTDSWriter.writeByte(TDSType.INT4.byteValue());
/*      */         }
/*      */         else {
/*      */           
/*  939 */           paramTDSWriter.writeByte(TDSType.INTN.byteValue());
/*  940 */           paramTDSWriter.writeByte((byte)4);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -5:
/*  945 */         if (!paramBoolean2) {
/*      */           
/*  947 */           paramTDSWriter.writeByte(TDSType.INT8.byteValue());
/*      */         }
/*      */         else {
/*      */           
/*  951 */           paramTDSWriter.writeByte(TDSType.INTN.byteValue());
/*  952 */           paramTDSWriter.writeByte((byte)8);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -7:
/*  957 */         if (!paramBoolean2) {
/*      */           
/*  959 */           paramTDSWriter.writeByte(TDSType.BIT1.byteValue());
/*      */         }
/*      */         else {
/*      */           
/*  963 */           paramTDSWriter.writeByte(TDSType.BITN.byteValue());
/*  964 */           paramTDSWriter.writeByte((byte)1);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 5:
/*  969 */         if (!paramBoolean2) {
/*      */           
/*  971 */           paramTDSWriter.writeByte(TDSType.INT2.byteValue());
/*      */         }
/*      */         else {
/*      */           
/*  975 */           paramTDSWriter.writeByte(TDSType.INTN.byteValue());
/*  976 */           paramTDSWriter.writeByte((byte)2);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -6:
/*  981 */         if (!paramBoolean2) {
/*      */           
/*  983 */           paramTDSWriter.writeByte(TDSType.INT1.byteValue());
/*      */         }
/*      */         else {
/*      */           
/*  987 */           paramTDSWriter.writeByte(TDSType.INTN.byteValue());
/*  988 */           paramTDSWriter.writeByte((byte)1);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 8:
/*  993 */         if (!paramBoolean2) {
/*      */           
/*  995 */           paramTDSWriter.writeByte(TDSType.FLOAT8.byteValue());
/*      */         }
/*      */         else {
/*      */           
/*  999 */           paramTDSWriter.writeByte(TDSType.FLOATN.byteValue());
/* 1000 */           paramTDSWriter.writeByte((byte)8);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 7:
/* 1005 */         if (!paramBoolean2) {
/*      */           
/* 1007 */           paramTDSWriter.writeByte(TDSType.FLOAT4.byteValue());
/*      */         }
/*      */         else {
/*      */           
/* 1011 */           paramTDSWriter.writeByte(TDSType.FLOATN.byteValue());
/* 1012 */           paramTDSWriter.writeByte((byte)4);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -148:
/*      */       case -146:
/*      */       case 2:
/*      */       case 3:
/* 1020 */         if (paramBoolean3 && (SSType.MONEY == paramSSType || SSType.SMALLMONEY == paramSSType)) {
/*      */           
/* 1022 */           paramTDSWriter.writeByte(TDSType.MONEYN.byteValue());
/* 1023 */           if (SSType.MONEY == paramSSType) {
/* 1024 */             paramTDSWriter.writeByte((byte)8);
/*      */           } else {
/* 1026 */             paramTDSWriter.writeByte((byte)4);
/*      */           } 
/*      */         } else {
/*      */           
/* 1030 */           if (3 == paramInt1) {
/* 1031 */             paramTDSWriter.writeByte(TDSType.DECIMALN.byteValue());
/*      */           } else {
/* 1033 */             paramTDSWriter.writeByte(TDSType.NUMERICN.byteValue());
/* 1034 */           }  paramTDSWriter.writeByte((byte)17);
/* 1035 */           paramTDSWriter.writeByte((byte)paramInt3);
/* 1036 */           paramTDSWriter.writeByte((byte)paramInt2);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -145:
/*      */       case 1:
/* 1042 */         if (paramBoolean3 && SSType.GUID == paramSSType) {
/*      */           
/* 1044 */           paramTDSWriter.writeByte(TDSType.GUID.byteValue());
/* 1045 */           paramTDSWriter.writeByte((byte)16);
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 1050 */           paramTDSWriter.writeByte(TDSType.BIGCHAR.byteValue());
/*      */           
/* 1052 */           paramTDSWriter.writeShort((short)paramInt3);
/*      */           
/* 1054 */           paramSQLCollation.writeCollation(paramTDSWriter);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -15:
/* 1059 */         paramTDSWriter.writeByte(TDSType.NCHAR.byteValue());
/* 1060 */         paramTDSWriter.writeShort(paramBoolean3 ? (short)paramInt3 : (short)(2 * paramInt3));
/* 1061 */         paramSQLCollation.writeCollation(paramTDSWriter);
/*      */         return;
/*      */ 
/*      */       
/*      */       case -1:
/*      */       case 12:
/* 1067 */         paramTDSWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1068 */         if (paramBoolean1) {
/*      */           
/* 1070 */           paramTDSWriter.writeShort((short)-1);
/*      */         }
/*      */         else {
/*      */           
/* 1074 */           paramTDSWriter.writeShort((short)paramInt3);
/*      */         } 
/* 1076 */         paramSQLCollation.writeCollation(paramTDSWriter);
/*      */         return;
/*      */       
/*      */       case -16:
/*      */       case -9:
/* 1081 */         paramTDSWriter.writeByte(TDSType.NVARCHAR.byteValue());
/* 1082 */         if (paramBoolean1) {
/*      */           
/* 1084 */           paramTDSWriter.writeShort((short)-1);
/*      */         }
/*      */         else {
/*      */           
/* 1088 */           paramTDSWriter.writeShort(paramBoolean3 ? (short)paramInt3 : (short)(2 * paramInt3));
/*      */         } 
/* 1090 */         paramSQLCollation.writeCollation(paramTDSWriter);
/*      */         return;
/*      */       
/*      */       case -2:
/* 1094 */         paramTDSWriter.writeByte(TDSType.BIGBINARY.byteValue());
/* 1095 */         paramTDSWriter.writeShort((short)paramInt3);
/*      */         return;
/*      */ 
/*      */       
/*      */       case -4:
/*      */       case -3:
/* 1101 */         paramTDSWriter.writeByte(TDSType.BIGVARBINARY.byteValue());
/* 1102 */         if (paramBoolean1) {
/*      */           
/* 1104 */           paramTDSWriter.writeShort((short)-1);
/*      */         }
/*      */         else {
/*      */           
/* 1108 */           paramTDSWriter.writeShort((short)paramInt3);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -151:
/*      */       case -150:
/*      */       case 93:
/* 1115 */         if (!paramBoolean3 && null != this.sourceBulkRecord) {
/*      */           
/* 1117 */           paramTDSWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1118 */           paramTDSWriter.writeShort((short)paramInt3);
/* 1119 */           paramSQLCollation.writeCollation(paramTDSWriter);
/*      */         }
/*      */         else {
/*      */           
/* 1123 */           switch (paramSSType) {
/*      */             
/*      */             case DATE:
/* 1126 */               if (!paramBoolean2) {
/* 1127 */                 paramTDSWriter.writeByte(TDSType.DATETIME4.byteValue());
/*      */               } else {
/*      */                 
/* 1130 */                 paramTDSWriter.writeByte(TDSType.DATETIMEN.byteValue());
/* 1131 */                 paramTDSWriter.writeByte((byte)4);
/*      */               } 
/*      */               return;
/*      */             case TIME:
/* 1135 */               if (!paramBoolean2) {
/* 1136 */                 paramTDSWriter.writeByte(TDSType.DATETIME8.byteValue());
/*      */               } else {
/*      */                 
/* 1139 */                 paramTDSWriter.writeByte(TDSType.DATETIMEN.byteValue());
/* 1140 */                 paramTDSWriter.writeByte((byte)8);
/*      */               } 
/*      */               return;
/*      */           } 
/*      */           
/* 1145 */           paramTDSWriter.writeByte(TDSType.DATETIME2N.byteValue());
/* 1146 */           paramTDSWriter.writeByte((byte)paramInt2);
/*      */         } 
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 91:
/* 1158 */         if (!paramBoolean3 && null != this.sourceBulkRecord) {
/*      */           
/* 1160 */           paramTDSWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1161 */           paramTDSWriter.writeShort((short)paramInt3);
/* 1162 */           paramSQLCollation.writeCollation(paramTDSWriter);
/*      */         }
/*      */         else {
/*      */           
/* 1166 */           paramTDSWriter.writeByte(TDSType.DATEN.byteValue());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 92:
/* 1171 */         if (!paramBoolean3 && null != this.sourceBulkRecord) {
/*      */           
/* 1173 */           paramTDSWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1174 */           paramTDSWriter.writeShort((short)paramInt3);
/* 1175 */           paramSQLCollation.writeCollation(paramTDSWriter);
/*      */         }
/*      */         else {
/*      */           
/* 1179 */           paramTDSWriter.writeByte(TDSType.TIMEN.byteValue());
/* 1180 */           paramTDSWriter.writeByte((byte)paramInt2);
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case 2013:
/*      */       case 2014:
/* 1187 */         paramTDSWriter.writeByte(TDSType.DATETIMEOFFSETN.byteValue());
/* 1188 */         paramTDSWriter.writeByte((byte)paramInt2);
/*      */         return;
/*      */       
/*      */       case -155:
/* 1192 */         if (!paramBoolean3 && null != this.sourceBulkRecord) {
/*      */           
/* 1194 */           paramTDSWriter.writeByte(TDSType.BIGVARCHAR.byteValue());
/* 1195 */           paramTDSWriter.writeShort((short)paramInt3);
/* 1196 */           paramSQLCollation.writeCollation(paramTDSWriter);
/*      */         }
/*      */         else {
/*      */           
/* 1200 */           paramTDSWriter.writeByte(TDSType.DATETIMEOFFSETN.byteValue());
/* 1201 */           paramTDSWriter.writeByte((byte)paramInt2);
/*      */         } 
/*      */         return;
/*      */     } 
/*      */     
/* 1206 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 1207 */     String str = JDBCType.of(paramInt1).toString().toLowerCase(Locale.ENGLISH);
/* 1208 */     throw new SQLServerException(messageFormat.format(new Object[] { str }, ), null, 0, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeCekTable(TDSWriter paramTDSWriter) throws SQLServerException {
/* 1220 */     if (this.connection.getServerSupportsColumnEncryption())
/*      */     {
/* 1222 */       if (null != this.destCekTable && 0 < this.destCekTable.getSize()) {
/*      */         
/* 1224 */         paramTDSWriter.writeShort((short)this.destCekTable.getSize());
/* 1225 */         for (byte b = 0; b < this.destCekTable.getSize(); b++)
/*      */         {
/* 1227 */           paramTDSWriter.writeInt(((EncryptionKeyInfo)this.destCekTable.getCekTableEntry(b).getColumnEncryptionKeyValues().get(0)).databaseId);
/* 1228 */           paramTDSWriter.writeInt(((EncryptionKeyInfo)this.destCekTable.getCekTableEntry(b).getColumnEncryptionKeyValues().get(0)).cekId);
/* 1229 */           paramTDSWriter.writeInt(((EncryptionKeyInfo)this.destCekTable.getCekTableEntry(b).getColumnEncryptionKeyValues().get(0)).cekVersion);
/* 1230 */           paramTDSWriter.writeBytes(((EncryptionKeyInfo)this.destCekTable.getCekTableEntry(b).getColumnEncryptionKeyValues().get(0)).cekMdVersion);
/*      */ 
/*      */           
/* 1233 */           paramTDSWriter.writeByte((byte)0);
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1239 */         paramTDSWriter.writeShort((short)0);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void writeColumnMetaData(TDSWriter paramTDSWriter) throws SQLServerException {
/* 1271 */     paramTDSWriter.writeByte((byte)-127);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1281 */     byte[] arrayOfByte = new byte[2];
/* 1282 */     arrayOfByte[0] = (byte)(this.columnMappings.size() & 0xFF);
/* 1283 */     arrayOfByte[1] = (byte)(this.columnMappings.size() >> 8 & 0xFF);
/* 1284 */     paramTDSWriter.writeBytes(arrayOfByte);
/*      */     
/* 1286 */     writeCekTable(paramTDSWriter);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1292 */     for (byte b = 0; b < this.columnMappings.size(); b++)
/*      */     {
/* 1294 */       writeColumnMetaDataColumnData(paramTDSWriter, b);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void checkForTimeoutException(SQLException paramSQLException, BulkTimeoutTimer paramBulkTimeoutTimer) throws SQLServerException {
/* 1303 */     if (null != paramSQLException.getSQLState() && paramSQLException.getSQLState().equals(SQLState.STATEMENT_CANCELED.getSQLStateCode()) && paramBulkTimeoutTimer.expired()) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1308 */       if (this.copyOptions.isUseInternalTransaction())
/*      */       {
/* 1310 */         this.connection.rollback();
/*      */       }
/*      */       
/* 1313 */       throw new SQLServerException(SQLServerException.getErrString("R_queryTimedOut"), SQLState.STATEMENT_CANCELED, DriverError.NOT_SET, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validateDataTypeConversions(int paramInt1, int paramInt2) throws SQLServerException {
/* 1331 */     CryptoMetadata cryptoMetadata1 = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).cryptoMeta;
/* 1332 */     CryptoMetadata cryptoMetadata2 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta;
/*      */     
/* 1334 */     JDBCType jDBCType = (null != cryptoMetadata1) ? cryptoMetadata1.baseTypeInfo.getSSType().getJDBCType() : JDBCType.of(((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).jdbcType);
/*      */ 
/*      */ 
/*      */     
/* 1338 */     SSType sSType = (null != cryptoMetadata2) ? cryptoMetadata2.baseTypeInfo.getSSType() : ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).ssType;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1343 */     if (!jDBCType.convertsTo(sSType))
/*      */     {
/* 1345 */       DataTypes.throwConversionError(jDBCType.toString(), sSType.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String getDestTypeFromSrcType(int paramInt1, int paramInt2, TDSWriter paramTDSWriter) throws SQLServerException {
/*      */     boolean bool;
/* 1357 */     SSType sSType = (null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta) ? ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta.baseTypeInfo.getSSType() : ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).ssType;
/*      */ 
/*      */ 
/*      */     
/* 1361 */     int i = 0, j = 0, k = 0;
/* 1362 */     int m = 0;
/*      */     
/* 1364 */     i = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).jdbcType;
/*      */     
/* 1366 */     j = m = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).precision;
/* 1367 */     int n = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).precision;
/* 1368 */     k = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).scale;
/*      */     
/* 1370 */     CryptoMetadata cryptoMetadata = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta;
/* 1371 */     if (null != cryptoMetadata) {
/*      */ 
/*      */       
/* 1374 */       paramTDSWriter.setCryptoMetaData(((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta);
/*      */ 
/*      */       
/* 1377 */       if (8000 < n)
/*      */       {
/* 1379 */         return "varbinary(max)";
/*      */       }
/*      */ 
/*      */       
/* 1383 */       return "varbinary(" + ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).precision + ")";
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1388 */     if (null != this.sourceResultSet && null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).encryptionType && this.copyOptions.isAllowEncryptedValueModifications())
/*      */     {
/*      */ 
/*      */       
/* 1392 */       return "varbinary(" + j + ")";
/*      */     }
/* 1394 */     j = validateSourcePrecision(m, i, n);
/*      */ 
/*      */     
/* 1397 */     if (this.sourceResultSet instanceof SQLServerResultSet && this.connection.isColumnEncryptionSettingEnabled()) {
/*      */ 
/*      */       
/* 1400 */       i = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).jdbcType;
/* 1401 */       j = n;
/* 1402 */       k = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).scale;
/*      */     } 
/*      */     
/* 1405 */     if (-15 == i || -9 == i || -16 == i) {
/*      */ 
/*      */ 
/*      */       
/* 1409 */       bool = (4000 < m || 4000 < n) ? true : false;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1414 */       bool = (8000 < m || 8000 < n) ? true : false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1419 */     if (Util.isCharType(i).booleanValue() && Util.isBinaryType(sSType).booleanValue()) {
/*      */       
/* 1421 */       if (bool) {
/* 1422 */         return "varbinary(max)";
/*      */       }
/*      */       
/* 1425 */       return sSType.toString() + "(" + ((8000 < n) ? "max" : (String)Integer.valueOf(n)) + ")";
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1431 */     switch (i) {
/*      */ 
/*      */       
/*      */       case 4:
/* 1435 */         return "int";
/*      */       
/*      */       case 5:
/* 1438 */         return "smallint";
/*      */       
/*      */       case -5:
/* 1441 */         return "bigint";
/*      */       
/*      */       case -7:
/* 1444 */         return "bit";
/*      */       
/*      */       case -6:
/* 1447 */         return "tinyint";
/*      */       
/*      */       case 8:
/* 1450 */         return "float";
/*      */       
/*      */       case 7:
/* 1453 */         return "real";
/*      */       
/*      */       case -148:
/*      */       case -146:
/*      */       case 3:
/* 1458 */         return "decimal(" + j + ", " + k + ")";
/*      */       
/*      */       case 2:
/* 1461 */         return "numeric(" + j + ", " + k + ")";
/*      */ 
/*      */       
/*      */       case -145:
/*      */       case 1:
/* 1466 */         return "char(" + j + ")";
/*      */       
/*      */       case -15:
/* 1469 */         return "NCHAR(" + j + ")";
/*      */ 
/*      */ 
/*      */       
/*      */       case -1:
/*      */       case 12:
/* 1475 */         if (bool)
/*      */         {
/* 1477 */           return "varchar(max)";
/*      */         }
/*      */ 
/*      */         
/* 1481 */         return "varchar(" + j + ")";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -16:
/*      */       case -9:
/* 1488 */         if (bool)
/*      */         {
/* 1490 */           return "NVARCHAR(MAX)";
/*      */         }
/*      */ 
/*      */         
/* 1494 */         return "NVARCHAR(" + j + ")";
/*      */ 
/*      */ 
/*      */       
/*      */       case -2:
/* 1499 */         return "binary(" + j + ")";
/*      */       
/*      */       case -4:
/*      */       case -3:
/* 1503 */         if (bool) {
/* 1504 */           return "varbinary(max)";
/*      */         }
/* 1506 */         return "varbinary(" + j + ")";
/*      */       
/*      */       case -151:
/*      */       case -150:
/*      */       case 93:
/* 1511 */         switch (sSType) {
/*      */           
/*      */           case DATE:
/* 1514 */             if (null != this.sourceBulkRecord)
/*      */             {
/* 1516 */               return "varchar(" + ((0 == j) ? n : j) + ")";
/*      */             }
/*      */ 
/*      */             
/* 1520 */             return "smalldatetime";
/*      */           
/*      */           case TIME:
/* 1523 */             if (null != this.sourceBulkRecord)
/*      */             {
/* 1525 */               return "varchar(" + ((0 == j) ? n : j) + ")";
/*      */             }
/*      */ 
/*      */             
/* 1529 */             return "datetime";
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1539 */         if (null != this.sourceBulkRecord)
/*      */         {
/* 1541 */           return "varchar(" + ((0 == j) ? n : j) + ")";
/*      */         }
/*      */ 
/*      */         
/* 1545 */         return "datetime2(" + k + ")";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 91:
/* 1556 */         if (null != this.sourceBulkRecord)
/*      */         {
/* 1558 */           return "varchar(" + ((0 == j) ? n : j) + ")";
/*      */         }
/*      */ 
/*      */         
/* 1562 */         return "date";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 92:
/* 1572 */         if (null != this.sourceBulkRecord)
/*      */         {
/* 1574 */           return "varchar(" + ((0 == j) ? n : j) + ")";
/*      */         }
/*      */ 
/*      */         
/* 1578 */         return "time(" + k + ")";
/*      */ 
/*      */ 
/*      */       
/*      */       case 2013:
/*      */       case 2014:
/* 1584 */         return "datetimeoffset(" + k + ")";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -155:
/* 1593 */         if (null != this.sourceBulkRecord)
/*      */         {
/* 1595 */           return "varchar(" + ((0 == j) ? n : j) + ")";
/*      */         }
/*      */ 
/*      */         
/* 1599 */         return "datetimeoffset(" + k + ")";
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1604 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 1605 */     Object[] arrayOfObject = { JDBCType.of(i).toString().toLowerCase(Locale.ENGLISH) };
/* 1606 */     SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
/*      */ 
/*      */     
/* 1609 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final String createInsertBulkCommand(TDSWriter paramTDSWriter) throws SQLServerException {
/* 1617 */     StringBuilder stringBuilder = new StringBuilder();
/* 1618 */     Vector<String> vector = new Vector();
/* 1619 */     String str = " , ";
/* 1620 */     stringBuilder.append("INSERT BULK " + this.destinationTableName + " (");
/*      */     
/* 1622 */     for (byte b = 0; b < this.columnMappings.size(); b++) {
/*      */       
/* 1624 */       if (b == this.columnMappings.size() - 1)
/*      */       {
/* 1626 */         str = " ) ";
/*      */       }
/* 1628 */       ColumnMapping columnMapping = this.columnMappings.get(b);
/* 1629 */       String str1 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(((ColumnMapping)this.columnMappings.get(b)).destinationColumnOrdinal))).collationName;
/*      */       
/* 1631 */       String str2 = "";
/*      */ 
/*      */       
/* 1634 */       String str3 = getDestTypeFromSrcType(columnMapping.sourceColumnOrdinal, columnMapping.destinationColumnOrdinal, paramTDSWriter).toUpperCase(Locale.ENGLISH);
/*      */ 
/*      */ 
/*      */       
/* 1638 */       if (null != str1 && str1.trim().length() > 0)
/*      */       {
/*      */         
/* 1641 */         if (null != str3 && (str3.toLowerCase().trim().startsWith("char") || str3.toLowerCase().trim().startsWith("varchar")))
/*      */         {
/*      */           
/* 1644 */           str2 = " COLLATE " + str1; } 
/*      */       }
/* 1646 */       stringBuilder.append("[" + columnMapping.destinationColumnName + "] " + str3 + str2 + str);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1654 */     if (true == this.copyOptions.isCheckConstraints())
/*      */     {
/* 1656 */       vector.add("CHECK_CONSTRAINTS");
/*      */     }
/*      */     
/* 1659 */     if (true == this.copyOptions.isFireTriggers())
/*      */     {
/* 1661 */       vector.add("FIRE_TRIGGERS");
/*      */     }
/*      */     
/* 1664 */     if (true == this.copyOptions.isKeepNulls())
/*      */     {
/* 1666 */       vector.add("KEEP_NULLS");
/*      */     }
/*      */     
/* 1669 */     if (this.copyOptions.getBatchSize() > 0)
/*      */     {
/* 1671 */       vector.add("ROWS_PER_BATCH = " + this.copyOptions.getBatchSize());
/*      */     }
/*      */     
/* 1674 */     if (true == this.copyOptions.isTableLock())
/*      */     {
/* 1676 */       vector.add("TABLOCK");
/*      */     }
/*      */     
/* 1679 */     if (true == this.copyOptions.isAllowEncryptedValueModifications())
/*      */     {
/* 1681 */       vector.add("ALLOW_ENCRYPTED_VALUE_MODIFICATIONS");
/*      */     }
/*      */     
/* 1684 */     Iterator<String> iterator = vector.iterator();
/* 1685 */     if (iterator.hasNext()) {
/*      */       
/* 1687 */       stringBuilder.append(" with (");
/* 1688 */       while (iterator.hasNext()) {
/*      */         
/* 1690 */         stringBuilder.append(((String)iterator.next()).toString());
/* 1691 */         if (iterator.hasNext())
/*      */         {
/* 1693 */           stringBuilder.append(", ");
/*      */         }
/*      */       } 
/* 1696 */       stringBuilder.append(")");
/*      */     } 
/*      */     
/* 1699 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1700 */       loggerExternal.finer(toString() + " TDSCommand: " + stringBuilder);
/*      */     }
/* 1702 */     return stringBuilder.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean doInsertBulk(TDSCommand paramTDSCommand) throws SQLServerException {
/* 1710 */     if (this.copyOptions.isUseInternalTransaction())
/*      */     {
/*      */       
/* 1713 */       this.connection.setAutoCommit(false);
/*      */     }
/*      */ 
/*      */     
/* 1717 */     TDSWriter tDSWriter = paramTDSCommand.startRequest((byte)1);
/* 1718 */     String str = createInsertBulkCommand(tDSWriter);
/* 1719 */     tDSWriter.writeString(str);
/* 1720 */     TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
/*      */ 
/*      */     
/* 1723 */     tDSWriter = paramTDSCommand.startRequest((byte)7);
/*      */     
/* 1725 */     boolean bool = false;
/*      */ 
/*      */     
/*      */     try {
/* 1729 */       writeColumnMetaData(tDSWriter);
/*      */ 
/*      */       
/* 1732 */       bool = writeBatchData(tDSWriter);
/*      */     }
/* 1734 */     catch (SQLServerException sQLServerException) {
/*      */ 
/*      */       
/* 1737 */       writePacketDataDone(tDSWriter);
/*      */ 
/*      */       
/* 1740 */       paramTDSCommand.startRequest((byte)6);
/*      */       
/* 1742 */       TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
/* 1743 */       paramTDSCommand.interrupt(sQLServerException.getMessage());
/* 1744 */       paramTDSCommand.onRequestComplete();
/*      */       
/* 1746 */       throw sQLServerException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/* 1751 */       tDSWriter.setCryptoMetaData(null);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1758 */     writePacketDataDone(tDSWriter);
/*      */ 
/*      */     
/* 1761 */     TDSParser.parse(paramTDSCommand.startResponse(), paramTDSCommand.getLogContext());
/*      */     
/* 1763 */     if (this.copyOptions.isUseInternalTransaction())
/*      */     {
/*      */       
/* 1766 */       this.connection.commit();
/*      */     }
/*      */     
/* 1769 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void writePacketDataDone(TDSWriter paramTDSWriter) throws SQLServerException {
/* 1778 */     paramTDSWriter.writeByte((byte)-3);
/* 1779 */     paramTDSWriter.writeLong(0L);
/* 1780 */     paramTDSWriter.writeInt(0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void throwInvalidArgument(String paramString) throws SQLServerException {
/* 1788 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidArgument"));
/* 1789 */     Object[] arrayOfObject = { paramString };
/* 1790 */     SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void throwInvalidJavaToJDBC(String paramString, int paramInt) throws SQLServerException {
/* 1799 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorConvertingValue"));
/* 1800 */     throw new SQLServerException(messageFormat.format(new Object[] { paramString, Integer.valueOf(paramInt) }, ), null, 0, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeToServer() throws SQLServerException {
/* 1808 */     if (this.connection.isClosed())
/*      */     {
/* 1810 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_connectionIsClosed"), "08003", false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1818 */     long l1 = System.currentTimeMillis();
/* 1819 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1820 */       loggerExternal.finer(toString() + " Start writeToServer: " + l1);
/*      */     }
/* 1822 */     getDestinationMetadata();
/*      */ 
/*      */ 
/*      */     
/* 1826 */     getSourceMetadata();
/*      */     
/* 1828 */     validateColumnMappings();
/*      */     
/* 1830 */     sendBulkLoadBCP();
/*      */     
/* 1832 */     long l2 = System.currentTimeMillis();
/* 1833 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*      */       
/* 1835 */       loggerExternal.finer(toString() + " End writeToServer: " + l2);
/* 1836 */       int i = (int)((l2 - l1) / 1000L);
/* 1837 */       loggerExternal.finer(toString() + "Time elapsed: " + i + " seconds");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validateStringBinaryLengths(Object paramObject, int paramInt1, int paramInt2) throws SQLServerException {
/* 1845 */     int i = 0;
/* 1846 */     int j = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).precision;
/* 1847 */     int k = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).jdbcType;
/* 1848 */     SSType sSType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).ssType;
/*      */     
/* 1850 */     if ((Util.isCharType(k).booleanValue() && Util.isCharType(sSType).booleanValue()) || (Util.isBinaryType(k).booleanValue() && Util.isBinaryType(sSType).booleanValue())) {
/*      */ 
/*      */       
/* 1853 */       if (paramObject instanceof String) {
/*      */         
/* 1855 */         i = ((String)paramObject).length();
/*      */       }
/* 1857 */       else if (paramObject instanceof byte[]) {
/*      */         
/* 1859 */         i = ((byte[])paramObject).length;
/*      */       } else {
/*      */         return;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1866 */       if (i > j) {
/*      */         
/* 1868 */         String str1 = JDBCType.of(k) + "(" + i + ")";
/* 1869 */         String str2 = sSType.toString() + "(" + j + ")";
/* 1870 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 1871 */         Object[] arrayOfObject = { str1, str2 };
/* 1872 */         throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getDestinationMetadata() throws SQLServerException {
/* 1882 */     if (null == this.destinationTableName)
/*      */     {
/* 1884 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, SQLServerException.getErrString("R_invalidDestinationTable"), (String)null, false);
/*      */     }
/*      */     
/* 1887 */     SQLServerResultSet sQLServerResultSet1 = null;
/* 1888 */     SQLServerResultSet sQLServerResultSet2 = null;
/*      */ 
/*      */     
/*      */     try {
/* 1892 */       sQLServerResultSet1 = ((SQLServerStatement)this.connection.createStatement()).executeQueryInternal("SET FMTONLY ON SELECT * FROM " + this.destinationTableName + " SET FMTONLY OFF ");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1898 */       this.destColumnCount = sQLServerResultSet1.getMetaData().getColumnCount();
/* 1899 */       this.destColumnMetadata = new HashMap<>();
/* 1900 */       this.destCekTable = sQLServerResultSet1.getCekTable();
/*      */       
/* 1902 */       if (!this.connection.getServerSupportsColumnEncryption()) {
/*      */         
/* 1904 */         sQLServerResultSet2 = ((SQLServerStatement)this.connection.createStatement()).executeQueryInternal("select collation_name from sys.columns where object_id=OBJECT_ID('" + this.destinationTableName + "') " + "order by column_id ASC");
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1911 */         sQLServerResultSet2 = ((SQLServerStatement)this.connection.createStatement()).executeQueryInternal("select collation_name, encryption_type from sys.columns where object_id=OBJECT_ID('" + this.destinationTableName + "') " + "order by column_id ASC");
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1917 */       for (byte b = 1; b <= this.destColumnCount; b++) {
/* 1918 */         if (sQLServerResultSet2.next())
/*      */         {
/* 1920 */           if (!this.connection.getServerSupportsColumnEncryption()) {
/* 1921 */             this.destColumnMetadata.put(Integer.valueOf(b), new BulkColumnMetaData(sQLServerResultSet1.getColumn(b), sQLServerResultSet2.getString("collation_name"), null));
/*      */           
/*      */           }
/*      */           else {
/*      */             
/* 1926 */             this.destColumnMetadata.put(Integer.valueOf(b), new BulkColumnMetaData(sQLServerResultSet1.getColumn(b), sQLServerResultSet2.getString("collation_name"), sQLServerResultSet2.getString("encryption_type")));
/*      */           
/*      */           }
/*      */ 
/*      */         
/*      */         }
/*      */         else
/*      */         {
/*      */           
/* 1935 */           this.destColumnMetadata.put(Integer.valueOf(b), new BulkColumnMetaData(sQLServerResultSet1.getColumn(b)));
/*      */         }
/*      */       
/*      */       } 
/* 1939 */     } catch (SQLException sQLException) {
/*      */       
/* 1941 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), sQLException);
/*      */     }
/*      */     finally {
/*      */       
/* 1945 */       if (null != sQLServerResultSet1) sQLServerResultSet1.close(); 
/* 1946 */       if (null != sQLServerResultSet2) sQLServerResultSet2.close();
/*      */     
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void getSourceMetadata() throws SQLServerException {
/* 1957 */     this.srcColumnMetadata = new HashMap<>();
/*      */     
/* 1959 */     if (null != this.sourceResultSet) {
/*      */       
/*      */       try {
/* 1962 */         this.srcColumnCount = this.sourceResultSetMetaData.getColumnCount();
/* 1963 */         for (byte b = 1; b <= this.srcColumnCount; b++)
/*      */         {
/* 1965 */           this.srcColumnMetadata.put(Integer.valueOf(b), new BulkColumnMetaData(this.sourceResultSetMetaData.getColumnName(b), !(0 == this.sourceResultSetMetaData.isNullable(b)), this.sourceResultSetMetaData.getPrecision(b), this.sourceResultSetMetaData.getScale(b), this.sourceResultSetMetaData.getColumnType(b), null));
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1975 */       catch (SQLException sQLException) {
/*      */         
/* 1977 */         throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), sQLException);
/*      */       }
/*      */     
/* 1980 */     } else if (null != this.sourceBulkRecord) {
/*      */       
/* 1982 */       Set<Integer> set = this.sourceBulkRecord.getColumnOrdinals();
/* 1983 */       this.srcColumnCount = set.size();
/* 1984 */       if (0 == this.srcColumnCount)
/*      */       {
/*      */         
/* 1987 */         throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), null);
/*      */       }
/*      */ 
/*      */       
/* 1991 */       Iterator<Integer> iterator = set.iterator();
/* 1992 */       while (iterator.hasNext())
/*      */       {
/* 1994 */         int i = ((Integer)iterator.next()).intValue();
/* 1995 */         this.srcColumnMetadata.put(Integer.valueOf(i), new BulkColumnMetaData(this.sourceBulkRecord.getColumnName(i), true, this.sourceBulkRecord.getPrecision(i), this.sourceBulkRecord.getScale(i), this.sourceBulkRecord.getColumnType(i), (this.sourceBulkRecord instanceof SQLServerBulkCSVFileRecord) ? ((SQLServerBulkCSVFileRecord)this.sourceBulkRecord).getColumnDateTimeFormatter(i) : null));
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2012 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int validateSourcePrecision(int paramInt1, int paramInt2, int paramInt3) {
/* 2021 */     if (1 > paramInt1 && Util.isCharType(paramInt2).booleanValue())
/*      */     {
/* 2023 */       paramInt1 = paramInt3;
/*      */     }
/* 2025 */     return paramInt1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void validateColumnMappings() throws SQLServerException {
/*      */     try {
/* 2035 */       if (this.columnMappings.isEmpty()) {
/*      */ 
/*      */ 
/*      */         
/* 2039 */         if (this.destColumnCount != this.srcColumnCount)
/*      */         {
/* 2041 */           throw new SQLServerException(SQLServerException.getErrString("R_schemaMismatch"), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 2048 */         for (byte b = 1; b <= this.srcColumnCount; b++) {
/*      */ 
/*      */           
/* 2051 */           if (!((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(b))).isIdentity || this.copyOptions.isKeepIdentity()) {
/*      */             
/* 2053 */             ColumnMapping columnMapping = new ColumnMapping(b, b);
/*      */             
/* 2055 */             columnMapping.destinationColumnName = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(b))).columnName;
/* 2056 */             this.columnMappings.add(columnMapping);
/*      */           } 
/*      */         } 
/*      */         
/* 2060 */         if (null != this.sourceBulkRecord) {
/*      */           
/* 2062 */           Set<Integer> set = this.sourceBulkRecord.getColumnOrdinals();
/* 2063 */           Iterator<Integer> iterator = set.iterator();
/* 2064 */           int i = 1;
/* 2065 */           while (iterator.hasNext())
/*      */           {
/* 2067 */             int j = ((Integer)iterator.next()).intValue();
/* 2068 */             if (i != j) {
/*      */               
/* 2070 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 2071 */               Object[] arrayOfObject = { Integer.valueOf(j) };
/* 2072 */               throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */             } 
/* 2074 */             i++;
/*      */           }
/*      */         
/*      */         } 
/*      */       } else {
/*      */         
/* 2080 */         int i = this.columnMappings.size();
/*      */         
/*      */         byte b;
/*      */         
/* 2084 */         for (b = 0; b < i; b++) {
/*      */           
/* 2086 */           ColumnMapping columnMapping = this.columnMappings.get(b);
/*      */ 
/*      */           
/* 2089 */           if (-1 == columnMapping.destinationColumnOrdinal) {
/*      */             
/* 2091 */             boolean bool = false;
/*      */             
/* 2093 */             for (byte b1 = 1; b1 <= this.destColumnCount; b1++) {
/*      */               
/* 2095 */               if (((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(b1))).columnName.equals(columnMapping.destinationColumnName)) {
/*      */                 
/* 2097 */                 bool = true;
/* 2098 */                 columnMapping.destinationColumnOrdinal = b1;
/*      */                 
/*      */                 break;
/*      */               } 
/*      */             } 
/* 2103 */             if (!bool) {
/*      */               
/* 2105 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 2106 */               Object[] arrayOfObject = { columnMapping.destinationColumnName };
/* 2107 */               throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */             } 
/*      */           } else {
/* 2110 */             if (0 > columnMapping.destinationColumnOrdinal || this.destColumnCount < columnMapping.destinationColumnOrdinal) {
/*      */               
/* 2112 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 2113 */               Object[] arrayOfObject = { Integer.valueOf(columnMapping.destinationColumnOrdinal) };
/* 2114 */               throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */             } 
/*      */ 
/*      */             
/* 2118 */             columnMapping.destinationColumnName = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(columnMapping.destinationColumnOrdinal))).columnName;
/*      */           } 
/*      */         } 
/*      */ 
/*      */         
/* 2123 */         for (b = 0; b < i; b++) {
/*      */           
/* 2125 */           ColumnMapping columnMapping = this.columnMappings.get(b);
/*      */ 
/*      */           
/* 2128 */           if (-1 == columnMapping.sourceColumnOrdinal) {
/*      */             
/* 2130 */             boolean bool = false;
/* 2131 */             if (null != this.sourceResultSet) {
/*      */               
/* 2133 */               int j = this.sourceResultSetMetaData.getColumnCount();
/* 2134 */               for (byte b1 = 1; b1 <= j; b1++) {
/*      */                 
/* 2136 */                 if (this.sourceResultSetMetaData.getColumnName(b1).equals(columnMapping.sourceColumnName)) {
/*      */                   
/* 2138 */                   bool = true;
/* 2139 */                   columnMapping.sourceColumnOrdinal = b1;
/*      */ 
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             } else {
/* 2146 */               Set<Integer> set = this.sourceBulkRecord.getColumnOrdinals();
/* 2147 */               Iterator<Integer> iterator = set.iterator();
/* 2148 */               while (iterator.hasNext()) {
/*      */                 
/* 2150 */                 int j = ((Integer)iterator.next()).intValue();
/* 2151 */                 if (this.sourceBulkRecord.getColumnName(j).equals(columnMapping.sourceColumnName)) {
/*      */                   
/* 2153 */                   bool = true;
/* 2154 */                   columnMapping.sourceColumnOrdinal = j;
/*      */                   
/*      */                   break;
/*      */                 } 
/*      */               } 
/*      */             } 
/* 2160 */             if (!bool)
/*      */             {
/* 2162 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 2163 */               Object[] arrayOfObject = { columnMapping.sourceColumnName };
/* 2164 */               throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/* 2169 */             boolean bool = true;
/* 2170 */             if (null != this.sourceResultSet) {
/*      */               
/* 2172 */               int j = this.sourceResultSetMetaData.getColumnCount();
/* 2173 */               if (0 < columnMapping.sourceColumnOrdinal && j >= columnMapping.sourceColumnOrdinal)
/*      */               {
/* 2175 */                 bool = false;
/*      */ 
/*      */               
/*      */               }
/*      */             
/*      */             }
/* 2181 */             else if (this.srcColumnMetadata.containsKey(Integer.valueOf(columnMapping.sourceColumnOrdinal))) {
/*      */               
/* 2183 */               bool = false;
/*      */             } 
/*      */ 
/*      */             
/* 2187 */             if (bool) {
/*      */               
/* 2189 */               MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidColumn"));
/* 2190 */               Object[] arrayOfObject = { Integer.valueOf(columnMapping.sourceColumnOrdinal) };
/* 2191 */               throw new SQLServerException(messageFormat.format(arrayOfObject), SQLState.COL_NOT_FOUND, DriverError.NOT_SET, null);
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/* 2196 */           if (((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(columnMapping.destinationColumnOrdinal))).isIdentity && !this.copyOptions.isKeepIdentity())
/*      */           {
/* 2198 */             this.columnMappings.remove(b);
/* 2199 */             i--;
/* 2200 */             b--;
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/* 2205 */     } catch (SQLException sQLException) {
/*      */ 
/*      */       
/* 2208 */       if (sQLException instanceof SQLServerException && null != sQLException.getSQLState() && sQLException.getSQLState().equals(SQLState.COL_NOT_FOUND.getSQLStateCode()))
/*      */       {
/* 2210 */         throw (SQLServerException)sQLException;
/*      */       }
/*      */ 
/*      */       
/* 2214 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), sQLException);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2219 */     if (this.columnMappings.isEmpty())
/*      */     {
/* 2221 */       throw new SQLServerException(null, SQLServerException.getErrString("R_BulkColumnMappingsIsEmpty"), null, 0, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeNullToTdsWriter(TDSWriter paramTDSWriter, int paramInt, boolean paramBoolean) throws SQLServerException {
/* 2230 */     switch (paramInt) {
/*      */       
/*      */       case -16:
/*      */       case -15:
/*      */       case -9:
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/* 2241 */         if (paramBoolean) {
/*      */           
/* 2243 */           paramTDSWriter.writeLong(-1L);
/*      */         }
/*      */         else {
/*      */           
/* 2247 */           paramTDSWriter.writeByte((byte)-1);
/* 2248 */           paramTDSWriter.writeByte((byte)-1);
/*      */         } 
/*      */         return;
/*      */       case -155:
/*      */       case -7:
/*      */       case -6:
/*      */       case -5:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 7:
/*      */       case 8:
/*      */       case 91:
/*      */       case 92:
/*      */       case 93:
/*      */       case 2013:
/*      */       case 2014:
/* 2266 */         paramTDSWriter.writeByte((byte)0);
/*      */         return;
/*      */     } 
/* 2269 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 2270 */     Object[] arrayOfObject = { JDBCType.of(paramInt).toString().toLowerCase(Locale.ENGLISH) };
/* 2271 */     SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeColumnToTdsWriter(TDSWriter paramTDSWriter, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, int paramInt4, int paramInt5, boolean paramBoolean2, Object paramObject) throws SQLServerException {
/* 2290 */     SSType sSType = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).ssType;
/*      */     
/* 2292 */     paramInt1 = validateSourcePrecision(paramInt1, paramInt3, ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).precision);
/*      */     
/* 2294 */     CryptoMetadata cryptoMetadata = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt4))).cryptoMeta;
/* 2295 */     if ((null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).encryptionType && this.copyOptions.isAllowEncryptedValueModifications()) || null != ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).cryptoMeta) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2300 */       paramInt3 = -3;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 2307 */     else if (null != cryptoMetadata) {
/*      */       
/* 2309 */       paramInt3 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).jdbcType;
/* 2310 */       paramInt2 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).scale;
/*      */     }
/* 2312 */     else if (null != this.sourceBulkRecord) {
/*      */ 
/*      */ 
/*      */       
/* 2316 */       switch (paramInt3) {
/*      */         
/*      */         case -155:
/*      */         case 91:
/*      */         case 92:
/*      */         case 93:
/* 2322 */           paramInt3 = 12;
/*      */           break;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     } 
/* 2330 */     switch (paramInt3) {
/*      */       
/*      */       case 4:
/* 2333 */         if (null == paramObject) {
/*      */           
/* 2335 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2339 */           if (paramBoolean1)
/*      */           {
/* 2341 */             paramTDSWriter.writeByte((byte)4);
/*      */           }
/* 2343 */           paramTDSWriter.writeInt(((Integer)paramObject).intValue());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 5:
/* 2348 */         if (null == paramObject) {
/*      */           
/* 2350 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2354 */           if (paramBoolean1)
/*      */           {
/* 2356 */             paramTDSWriter.writeByte((byte)2);
/*      */           }
/* 2358 */           paramTDSWriter.writeShort(((Number)paramObject).shortValue());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -5:
/* 2363 */         if (null == paramObject) {
/*      */           
/* 2365 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2369 */           if (paramBoolean1)
/*      */           {
/* 2371 */             paramTDSWriter.writeByte((byte)8);
/*      */           }
/* 2373 */           paramTDSWriter.writeLong(((Long)paramObject).longValue());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -7:
/* 2378 */         if (null == paramObject) {
/*      */           
/* 2380 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2384 */           if (paramBoolean1)
/*      */           {
/* 2386 */             paramTDSWriter.writeByte((byte)1);
/*      */           }
/* 2388 */           paramTDSWriter.writeByte((byte)(((Boolean)paramObject).booleanValue() ? 1 : 0));
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -6:
/* 2393 */         if (null == paramObject) {
/*      */           
/* 2395 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2399 */           if (paramBoolean1)
/*      */           {
/* 2401 */             paramTDSWriter.writeByte((byte)1);
/*      */           }
/*      */ 
/*      */           
/* 2405 */           paramTDSWriter.writeByte((byte)(((Number)paramObject).shortValue() & 0xFF));
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case 8:
/* 2411 */         if (null == paramObject) {
/*      */           
/* 2413 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2417 */           if (paramBoolean1)
/*      */           {
/* 2419 */             paramTDSWriter.writeByte((byte)8);
/*      */           }
/* 2421 */           paramTDSWriter.writeDouble(((Double)paramObject).doubleValue());
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 7:
/* 2426 */         if (null == paramObject) {
/*      */           
/* 2428 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2432 */           if (paramBoolean1)
/*      */           {
/* 2434 */             paramTDSWriter.writeByte((byte)4);
/*      */           }
/* 2436 */           paramTDSWriter.writeReal(Float.valueOf(((Float)paramObject).floatValue()));
/*      */         } 
/*      */         return;
/*      */       
/*      */       case -148:
/*      */       case -146:
/*      */       case 2:
/*      */       case 3:
/* 2444 */         if (null == paramObject) {
/*      */           
/* 2446 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2450 */           paramTDSWriter.writeBigDecimal((BigDecimal)paramObject, paramInt3, paramInt1);
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case -145:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/* 2459 */         if (paramBoolean2) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2464 */           if (null == paramObject)
/*      */           {
/* 2466 */             writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */           
/*      */           }
/*      */           else
/*      */           {
/* 2471 */             paramTDSWriter.writeLong(-2L);
/*      */ 
/*      */ 
/*      */             
/*      */             try {
/* 2476 */               Reader reader = null;
/* 2477 */               if (paramObject instanceof Reader) {
/*      */                 
/* 2479 */                 reader = (Reader)paramObject;
/*      */               }
/*      */               else {
/*      */                 
/* 2483 */                 reader = new StringReader(paramObject.toString());
/*      */               } 
/*      */               
/* 2486 */               if (SSType.BINARY == sSType || SSType.VARBINARY == sSType || SSType.VARBINARYMAX == sSType || SSType.IMAGE == sSType) {
/*      */                 
/* 2488 */                 paramTDSWriter.writeNonUnicodeReader(reader, -1L, true, null);
/*      */ 
/*      */               
/*      */               }
/*      */               else {
/*      */ 
/*      */ 
/*      */                 
/* 2496 */                 SQLCollation sQLCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).collation;
/*      */                 
/* 2498 */                 if (null != sQLCollation) {
/*      */                   
/* 2500 */                   paramTDSWriter.writeNonUnicodeReader(reader, -1L, false, sQLCollation.getCharset());
/*      */ 
/*      */                 
/*      */                 }
/*      */                 else {
/*      */ 
/*      */ 
/*      */                   
/* 2508 */                   paramTDSWriter.writeNonUnicodeReader(reader, -1L, false, null);
/*      */                 } 
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 2515 */               reader.close();
/*      */             }
/* 2517 */             catch (IOException iOException) {
/*      */               
/* 2519 */               throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), iOException);
/*      */             }
/*      */           
/*      */           }
/*      */         
/*      */         }
/* 2525 */         else if (null == paramObject) {
/*      */           
/* 2527 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2531 */           String str = paramObject.toString();
/* 2532 */           if (SSType.BINARY == sSType || SSType.VARBINARY == sSType) {
/*      */             
/* 2534 */             byte[] arrayOfByte = null;
/*      */             
/*      */             try {
/* 2537 */               arrayOfByte = ParameterUtils.HexToBin(str);
/*      */             }
/* 2539 */             catch (SQLServerException sQLServerException) {
/*      */               
/* 2541 */               throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLServerException);
/*      */             } 
/* 2543 */             paramTDSWriter.writeShort((short)arrayOfByte.length);
/* 2544 */             paramTDSWriter.writeBytes(arrayOfByte);
/*      */           } else {
/*      */ 
/*      */             
/*      */             try {
/*      */               
/* 2550 */               paramTDSWriter.writeShort((short)str.length());
/*      */ 
/*      */               
/* 2553 */               SQLCollation sQLCollation = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).collation;
/*      */               
/* 2555 */               if (null != sQLCollation)
/*      */               {
/* 2557 */                 paramTDSWriter.writeBytes(str.getBytes(((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt5))).collation.getCharset()));
/*      */ 
/*      */               
/*      */               }
/*      */               else
/*      */               {
/*      */                 
/* 2564 */                 paramTDSWriter.writeBytes(str.getBytes());
/*      */               }
/*      */             
/* 2567 */             } catch (UnsupportedEncodingException unsupportedEncodingException) {
/*      */               
/* 2569 */               throw new SQLServerException(SQLServerException.getErrString("R_encodingErrorWritingTDS"), unsupportedEncodingException);
/*      */             } 
/*      */           } 
/*      */         } 
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -16:
/*      */       case -15:
/*      */       case -9:
/* 2588 */         if (paramBoolean2) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2593 */           if (null == paramObject)
/*      */           {
/* 2595 */             writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */           
/*      */           }
/*      */           else
/*      */           {
/* 2600 */             paramTDSWriter.writeLong(-2L);
/*      */ 
/*      */             
/*      */             try {
/* 2604 */               Reader reader = null;
/* 2605 */               if (paramObject instanceof Reader) {
/*      */                 
/* 2607 */                 reader = (Reader)paramObject;
/*      */               }
/*      */               else {
/*      */                 
/* 2611 */                 reader = new StringReader(paramObject.toString());
/*      */               } 
/*      */ 
/*      */               
/* 2615 */               paramTDSWriter.writeReader(reader, -1L, true);
/* 2616 */               reader.close();
/*      */             }
/* 2618 */             catch (IOException iOException) {
/*      */               
/* 2620 */               throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), iOException);
/*      */             }
/*      */           
/*      */           }
/*      */         
/*      */         }
/* 2626 */         else if (null == paramObject) {
/*      */           
/* 2628 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2632 */           int i = paramObject.toString().length();
/* 2633 */           byte[] arrayOfByte = new byte[2];
/* 2634 */           arrayOfByte[0] = (byte)(2 * i & 0xFF);
/* 2635 */           arrayOfByte[1] = (byte)(2 * i >> 8 & 0xFF);
/* 2636 */           paramTDSWriter.writeBytes(arrayOfByte);
/* 2637 */           paramTDSWriter.writeString(paramObject.toString());
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/* 2645 */         if (paramBoolean2) {
/*      */ 
/*      */ 
/*      */           
/* 2649 */           if (null == paramObject)
/*      */           {
/* 2651 */             writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */           
/*      */           }
/*      */           else
/*      */           {
/* 2656 */             paramTDSWriter.writeLong(-2L);
/*      */ 
/*      */             
/*      */             try {
/* 2660 */               InputStream inputStream = null;
/* 2661 */               if (paramObject instanceof InputStream) {
/*      */                 
/* 2663 */                 inputStream = (InputStream)paramObject;
/*      */ 
/*      */               
/*      */               }
/* 2667 */               else if (paramObject instanceof byte[]) {
/*      */                 
/* 2669 */                 inputStream = new ByteArrayInputStream((byte[])paramObject);
/*      */               } else {
/*      */                 
/* 2672 */                 inputStream = new ByteArrayInputStream(ParameterUtils.HexToBin(paramObject.toString()));
/*      */               } 
/*      */               
/* 2675 */               paramTDSWriter.writeStream(inputStream, -1L, true);
/* 2676 */               inputStream.close();
/*      */             }
/* 2678 */             catch (IOException iOException) {
/*      */               
/* 2680 */               throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), iOException);
/*      */             }
/*      */           
/*      */           }
/*      */         
/*      */         }
/* 2686 */         else if (null == paramObject) {
/*      */           
/* 2688 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         } else {
/*      */           byte[] arrayOfByte;
/*      */ 
/*      */           
/* 2693 */           if (paramObject instanceof byte[]) {
/*      */             
/* 2695 */             arrayOfByte = (byte[])paramObject;
/*      */           } else {
/*      */ 
/*      */             
/*      */             try {
/*      */               
/* 2701 */               arrayOfByte = ParameterUtils.HexToBin(paramObject.toString());
/*      */             }
/* 2703 */             catch (SQLServerException sQLServerException) {
/*      */               
/* 2705 */               throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLServerException);
/*      */             } 
/*      */           } 
/* 2708 */           paramTDSWriter.writeShort((short)arrayOfByte.length);
/* 2709 */           paramTDSWriter.writeBytes(arrayOfByte);
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case -151:
/*      */       case -150:
/*      */       case 93:
/* 2717 */         if (null == paramObject) {
/*      */           
/* 2719 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2723 */           switch (sSType) {
/*      */             
/*      */             case DATE:
/* 2726 */               if (paramBoolean1)
/* 2727 */                 paramTDSWriter.writeByte((byte)4); 
/* 2728 */               paramTDSWriter.writeSmalldatetime(paramObject.toString());
/*      */               return;
/*      */             case TIME:
/* 2731 */               if (paramBoolean1)
/* 2732 */                 paramTDSWriter.writeByte((byte)8); 
/* 2733 */               paramTDSWriter.writeDatetime(paramObject.toString());
/*      */               return;
/*      */           } 
/* 2736 */           if (paramBoolean1)
/*      */           {
/* 2738 */             if (2 >= paramInt2) {
/* 2739 */               paramTDSWriter.writeByte((byte)6);
/* 2740 */             } else if (4 >= paramInt2) {
/* 2741 */               paramTDSWriter.writeByte((byte)7);
/*      */             } else {
/* 2743 */               paramTDSWriter.writeByte((byte)8);
/*      */             }  } 
/* 2745 */           String str = paramObject.toString();
/* 2746 */           paramTDSWriter.writeTime(Timestamp.valueOf(str), paramInt2);
/*      */           
/* 2748 */           paramTDSWriter.writeDate(str.substring(0, str.lastIndexOf(' ')));
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case 91:
/* 2754 */         if (null == paramObject) {
/*      */           
/* 2756 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2760 */           paramTDSWriter.writeByte((byte)3);
/* 2761 */           paramTDSWriter.writeDate(paramObject.toString());
/*      */         } 
/*      */         return;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 92:
/* 2769 */         if (null == paramObject) {
/*      */           
/* 2771 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2775 */           if (2 >= paramInt2) {
/* 2776 */             paramTDSWriter.writeByte((byte)3);
/* 2777 */           } else if (4 >= paramInt2) {
/* 2778 */             paramTDSWriter.writeByte((byte)4);
/*      */           } else {
/* 2780 */             paramTDSWriter.writeByte((byte)5);
/*      */           } 
/* 2782 */           paramTDSWriter.writeTime((Timestamp)paramObject, paramInt2);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 2013:
/* 2787 */         if (null == paramObject) {
/*      */           
/* 2789 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2793 */           if (2 >= paramInt2) {
/* 2794 */             paramTDSWriter.writeByte((byte)8);
/* 2795 */           } else if (4 >= paramInt2) {
/* 2796 */             paramTDSWriter.writeByte((byte)9);
/*      */           } else {
/* 2798 */             paramTDSWriter.writeByte((byte)10);
/*      */           } 
/* 2800 */           paramTDSWriter.writeOffsetTimeWithTimezone((OffsetTime)paramObject, paramInt2);
/*      */         } 
/*      */         return;
/*      */       
/*      */       case 2014:
/* 2805 */         if (null == paramObject) {
/*      */           
/* 2807 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2811 */           if (2 >= paramInt2) {
/* 2812 */             paramTDSWriter.writeByte((byte)8);
/* 2813 */           } else if (4 >= paramInt2) {
/* 2814 */             paramTDSWriter.writeByte((byte)9);
/*      */           } else {
/* 2816 */             paramTDSWriter.writeByte((byte)10);
/*      */           } 
/* 2818 */           paramTDSWriter.writeOffsetDateTimeWithTimezone((OffsetDateTime)paramObject, paramInt2);
/*      */         } 
/*      */         return;
/*      */ 
/*      */       
/*      */       case -155:
/* 2824 */         if (null == paramObject) {
/*      */           
/* 2826 */           writeNullToTdsWriter(paramTDSWriter, paramInt3, paramBoolean2);
/*      */         }
/*      */         else {
/*      */           
/* 2830 */           if (2 >= paramInt2) {
/* 2831 */             paramTDSWriter.writeByte((byte)8);
/* 2832 */           } else if (4 >= paramInt2) {
/* 2833 */             paramTDSWriter.writeByte((byte)9);
/*      */           } else {
/* 2835 */             paramTDSWriter.writeByte((byte)10);
/*      */           } 
/* 2837 */           paramTDSWriter.writeDateTimeOffset(paramObject, paramInt2, sSType);
/*      */         } 
/*      */         return;
/*      */     } 
/*      */     
/* 2842 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 2843 */     Object[] arrayOfObject = { JDBCType.of(paramInt3).toString().toLowerCase(Locale.ENGLISH) };
/* 2844 */     SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object readColumnFromResultSet(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) throws SQLServerException {
/* 2858 */     CryptoMetadata cryptoMetadata = null;
/*      */ 
/*      */     
/* 2861 */     if (this.sourceResultSet instanceof SQLServerResultSet && null != (cryptoMetadata = ((SQLServerResultSet)this.sourceResultSet).getterGetColumn(paramInt1).getCryptoMetadata())) {
/*      */ 
/*      */       
/* 2864 */       paramInt2 = cryptoMetadata.baseTypeInfo.getSSType().getJDBCType().asJavaSqlType();
/* 2865 */       BulkColumnMetaData bulkColumnMetaData = this.srcColumnMetadata.get(Integer.valueOf(paramInt1));
/* 2866 */       this.srcColumnMetadata.put(Integer.valueOf(paramInt1), new BulkColumnMetaData(bulkColumnMetaData, cryptoMetadata));
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/* 2871 */       switch (paramInt2) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -7:
/*      */         case -6:
/*      */         case -5:
/*      */         case 4:
/*      */         case 5:
/*      */         case 7:
/*      */         case 8:
/* 2883 */           return this.sourceResultSet.getObject(paramInt1);
/*      */         
/*      */         case -148:
/*      */         case -146:
/*      */         case 2:
/*      */         case 3:
/* 2889 */           return this.sourceResultSet.getBigDecimal(paramInt1);
/*      */ 
/*      */         
/*      */         case -145:
/*      */         case -1:
/*      */         case 1:
/*      */         case 12:
/* 2896 */           if (paramBoolean1 && !paramBoolean2)
/*      */           {
/*      */ 
/*      */             
/* 2900 */             return this.sourceResultSet.getCharacterStream(paramInt1);
/*      */           }
/*      */ 
/*      */           
/* 2904 */           return this.sourceResultSet.getString(paramInt1);
/*      */ 
/*      */         
/*      */         case -16:
/*      */         case -15:
/*      */         case -9:
/* 2910 */           if (paramBoolean1 && !paramBoolean2)
/*      */           {
/*      */ 
/*      */             
/* 2914 */             return this.sourceResultSet.getNCharacterStream(paramInt1);
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 2919 */           return this.sourceResultSet.getObject(paramInt1);
/*      */ 
/*      */         
/*      */         case -4:
/*      */         case -3:
/*      */         case -2:
/* 2925 */           if (paramBoolean1 && !paramBoolean2)
/*      */           {
/* 2927 */             return this.sourceResultSet.getBinaryStream(paramInt1);
/*      */           }
/*      */ 
/*      */           
/* 2931 */           return this.sourceResultSet.getBytes(paramInt1);
/*      */ 
/*      */         
/*      */         case -151:
/*      */         case -150:
/*      */         case 93:
/* 2937 */           return this.sourceResultSet.getTimestamp(paramInt1);
/*      */         
/*      */         case 91:
/* 2940 */           return this.sourceResultSet.getDate(paramInt1);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 92:
/* 2946 */           return this.sourceResultSet.getTimestamp(paramInt1);
/*      */ 
/*      */         
/*      */         case -155:
/* 2950 */           return ((SQLServerResultSet)this.sourceResultSet).getDateTimeOffset(paramInt1);
/*      */       } 
/*      */       
/* 2953 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_BulkTypeNotSupported"));
/* 2954 */       Object[] arrayOfObject = { JDBCType.of(paramInt2).toString().toLowerCase(Locale.ENGLISH) };
/* 2955 */       SQLServerException.makeFromDriverError((SQLServerConnection)null, (Object)null, messageFormat.format(arrayOfObject), (String)null, true);
/*      */       
/* 2957 */       return null;
/*      */     
/*      */     }
/* 2960 */     catch (SQLException sQLException) {
/*      */       
/* 2962 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void writeColumn(TDSWriter paramTDSWriter, int paramInt1, int paramInt2, Object paramObject) throws SQLServerException {
/* 2976 */     int i = 0, j = 0, k = 0, m = 0;
/* 2977 */     SSType sSType = null;
/* 2978 */     boolean bool = false;
/* 2979 */     i = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).precision;
/* 2980 */     j = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).scale;
/* 2981 */     m = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).jdbcType;
/* 2982 */     boolean bool1 = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).isNullable;
/*      */     
/* 2984 */     k = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).precision;
/*      */ 
/*      */ 
/*      */     
/* 2988 */     if (-15 == m || -9 == m || -16 == m) {
/*      */ 
/*      */ 
/*      */       
/* 2992 */       bool = (4000 < i || 4000 < k) ? true : false;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2997 */       bool = (8000 < i || 8000 < k) ? true : false;
/*      */     } 
/*      */ 
/*      */     
/* 3001 */     CryptoMetadata cryptoMetadata1 = ((BulkColumnMetaData)this.destColumnMetadata.get(Integer.valueOf(paramInt2))).cryptoMeta;
/* 3002 */     if (null != cryptoMetadata1)
/*      */     {
/* 3004 */       sSType = cryptoMetadata1.baseTypeInfo.getSSType();
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3009 */     if (null != this.sourceResultSet) {
/*      */       
/* 3011 */       paramObject = readColumnFromResultSet(paramInt1, m, bool, (null != cryptoMetadata1));
/* 3012 */       validateStringBinaryLengths(paramObject, paramInt1, paramInt2);
/*      */ 
/*      */       
/* 3015 */       if (!this.copyOptions.isAllowEncryptedValueModifications() && (null == cryptoMetadata1 || null == paramObject))
/*      */       {
/*      */ 
/*      */         
/* 3019 */         validateDataTypeConversions(paramInt1, paramInt2);
/*      */       }
/*      */     }
/* 3022 */     else if (null != this.sourceBulkRecord && null != cryptoMetadata1) {
/*      */ 
/*      */       
/* 3025 */       if (91 == m || 92 == m || 93 == m || -155 == m || 2013 == m || 2014 == m) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3032 */         paramObject = getTemporalObjectFromCSV(paramObject, m, paramInt1);
/*      */       }
/* 3034 */       else if (2 == m || 3 == m) {
/*      */         
/* 3036 */         int n = cryptoMetadata1.baseTypeInfo.getPrecision();
/* 3037 */         int i1 = cryptoMetadata1.baseTypeInfo.getScale();
/* 3038 */         if (j != i1 || i != n) {
/*      */           
/* 3040 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3041 */           String str1 = JDBCType.of(m) + "(" + i + "," + j + ")";
/* 3042 */           String str2 = sSType + "(" + n + "," + i1 + ")";
/* 3043 */           Object[] arrayOfObject = { str1, str2 };
/* 3044 */           throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 3049 */     CryptoMetadata cryptoMetadata2 = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).cryptoMeta;
/*      */     
/* 3051 */     if (null != cryptoMetadata1 && null != paramObject) {
/*      */       
/* 3053 */       JDBCType jDBCType = (null != cryptoMetadata2) ? ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt1))).cryptoMeta.baseTypeInfo.getSSType().getJDBCType() : JDBCType.of(m);
/*      */ 
/*      */       
/* 3056 */       if (JDBCType.TIMESTAMP == jDBCType) {
/* 3057 */         if (SSType.DATETIME == sSType) {
/*      */           
/* 3059 */           jDBCType = JDBCType.DATETIME;
/*      */         }
/* 3061 */         else if (SSType.SMALLDATETIME == sSType) {
/*      */           
/* 3063 */           jDBCType = JDBCType.SMALLDATETIME;
/*      */         } 
/*      */       }
/*      */       
/* 3067 */       if ((SSType.MONEY != sSType || JDBCType.DECIMAL != jDBCType) && (SSType.SMALLMONEY != sSType || JDBCType.DECIMAL != jDBCType) && (SSType.GUID != sSType || JDBCType.CHAR != jDBCType))
/*      */       {
/*      */ 
/*      */         
/* 3071 */         if ((!Util.isCharType(sSType).booleanValue() || !Util.isCharType(m).booleanValue()) && !(this.sourceResultSet instanceof SQLServerResultSet))
/*      */         {
/* 3073 */           if (!jDBCType.normalizationCheck(sSType)) {
/*      */             
/* 3075 */             MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedConversionAE"));
/* 3076 */             Object[] arrayOfObject = { jDBCType, sSType };
/* 3077 */             throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */           } 
/*      */         }
/*      */       }
/* 3081 */       if (jDBCType == JDBCType.DATE || jDBCType == JDBCType.TIMESTAMP || jDBCType == JDBCType.TIME || jDBCType == JDBCType.DATETIMEOFFSET || jDBCType == JDBCType.DATETIME || jDBCType == JDBCType.SMALLDATETIME) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3088 */         paramObject = getEncryptedTemporalBytes(paramTDSWriter, jDBCType, paramObject, paramInt1, cryptoMetadata1.baseTypeInfo.getScale());
/*      */       }
/*      */       else {
/*      */         
/* 3092 */         TypeInfo typeInfo = cryptoMetadata1.getBaseTypeInfo();
/*      */         
/* 3094 */         paramObject = SQLServerSecurityUtility.encryptWithKey(normalizedValue(typeInfo.getSSType().getJDBCType(), paramObject, jDBCType, typeInfo.getPrecision(), typeInfo.getScale()), cryptoMetadata1, this.connection);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3099 */     writeColumnToTdsWriter(paramTDSWriter, i, j, m, bool1, paramInt1, paramInt2, bool, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object getTemporalObjectFromCSVWithFormatter(String paramString, int paramInt1, int paramInt2, DateTimeFormatter paramDateTimeFormatter) throws SQLServerException {
/* 3114 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     try {
/* 3116 */       TemporalAccessor temporalAccessor = DateTimeFormatter.parse(paramString);
/*      */ 
/*      */       
/* 3119 */       int i3 = 0, i2 = i3, i1 = i2, n = i1, m = n, k = m, j = k, i = j;
/* 3120 */       if (temporalAccessor.isSupported(ChronoField.NANO_OF_SECOND))
/* 3121 */         i2 = temporalAccessor.get(ChronoField.NANO_OF_SECOND); 
/* 3122 */       if (temporalAccessor.isSupported(ChronoField.OFFSET_SECONDS))
/* 3123 */         i3 = temporalAccessor.get(ChronoField.OFFSET_SECONDS); 
/* 3124 */       if (temporalAccessor.isSupported(ChronoField.HOUR_OF_DAY))
/* 3125 */         i = temporalAccessor.get(ChronoField.HOUR_OF_DAY); 
/* 3126 */       if (temporalAccessor.isSupported(ChronoField.MINUTE_OF_HOUR))
/* 3127 */         j = temporalAccessor.get(ChronoField.MINUTE_OF_HOUR); 
/* 3128 */       if (temporalAccessor.isSupported(ChronoField.SECOND_OF_MINUTE))
/* 3129 */         k = temporalAccessor.get(ChronoField.SECOND_OF_MINUTE); 
/* 3130 */       if (temporalAccessor.isSupported(ChronoField.DAY_OF_MONTH))
/* 3131 */         i1 = temporalAccessor.get(ChronoField.DAY_OF_MONTH); 
/* 3132 */       if (temporalAccessor.isSupported(ChronoField.MONTH_OF_YEAR))
/* 3133 */         n = temporalAccessor.get(ChronoField.MONTH_OF_YEAR); 
/* 3134 */       if (temporalAccessor.isSupported(ChronoField.YEAR)) {
/* 3135 */         m = temporalAccessor.get(ChronoField.YEAR);
/*      */       }
/* 3137 */       GregorianCalendar gregorianCalendar = null;
/* 3138 */       gregorianCalendar = new GregorianCalendar(new SimpleTimeZone(i3 * 1000, ""));
/* 3139 */       gregorianCalendar.clear();
/* 3140 */       gregorianCalendar.set(11, i);
/* 3141 */       gregorianCalendar.set(12, j);
/* 3142 */       gregorianCalendar.set(13, k);
/* 3143 */       gregorianCalendar.set(5, i1);
/* 3144 */       gregorianCalendar.set(2, n - 1);
/* 3145 */       gregorianCalendar.set(1, m);
/* 3146 */       int i4 = Integer.toString(i2).length();
/* 3147 */       for (byte b = 0; b < 9 - i4; b++)
/* 3148 */         i2 *= 10; 
/* 3149 */       Timestamp timestamp = new Timestamp(gregorianCalendar.getTimeInMillis());
/* 3150 */       timestamp.setNanos(i2);
/*      */       
/* 3152 */       switch (paramInt1) {
/*      */         
/*      */         case 93:
/* 3155 */           return timestamp;
/*      */         
/*      */         case 92:
/* 3158 */           gregorianCalendar.set(this.connection.baseYear(), 0, 1);
/* 3159 */           timestamp = new Timestamp(gregorianCalendar.getTimeInMillis());
/* 3160 */           timestamp.setNanos(i2);
/* 3161 */           return new Timestamp(timestamp.getTime());
/*      */         case 91:
/* 3163 */           return new Date(timestamp.getTime());
/*      */         case -155:
/* 3165 */           return DateTimeOffset.valueOf(timestamp, i3 / 60);
/*      */       } 
/*      */     
/* 3168 */     } catch (DateTimeException|ArithmeticException dateTimeException) {
/*      */       
/* 3170 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
/* 3171 */       Object[] arrayOfObject = { JDBCType.of(paramInt1) };
/* 3172 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     } 
/*      */     
/* 3175 */     return paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object getTemporalObjectFromCSV(Object paramObject, int paramInt1, int paramInt2) throws SQLServerException {
/* 3181 */     if (2013 == paramInt1) {
/*      */       
/* 3183 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
/* 3184 */       Object[] arrayOfObject = { "TIME_WITH_TIMEZONE" };
/* 3185 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     } 
/* 3187 */     if (2014 == paramInt1) {
/*      */       
/* 3189 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
/* 3190 */       Object[] arrayOfObject = { "TIMESTAMP_WITH_TIMEZONE" };
/* 3191 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     } 
/*      */     
/* 3194 */     String str1 = null;
/* 3195 */     String str2 = null;
/*      */     
/* 3197 */     if (null != paramObject && paramObject instanceof String) {
/*      */       
/* 3199 */       str2 = (String)paramObject;
/* 3200 */       str1 = str2.trim();
/*      */     } 
/*      */ 
/*      */     
/* 3204 */     if (null == str1)
/*      */     {
/* 3206 */       switch (paramInt1) {
/*      */         
/*      */         case 92:
/*      */         case 93:
/* 3210 */           return null;
/*      */         case 91:
/* 3212 */           return null;
/*      */         case -155:
/* 3214 */           return null;
/*      */       } 
/*      */ 
/*      */     
/*      */     }
/* 3219 */     GregorianCalendar gregorianCalendar = null;
/*      */ 
/*      */     
/* 3222 */     DateTimeFormatter dateTimeFormatter = ((BulkColumnMetaData)this.srcColumnMetadata.get(Integer.valueOf(paramInt2))).dateTimeFormatter;
/* 3223 */     if (null != dateTimeFormatter)
/*      */     {
/* 3225 */       return getTemporalObjectFromCSVWithFormatter(str2, paramInt1, paramInt2, dateTimeFormatter); }  try {
/*      */       String str; int i; Timestamp timestamp1; int j; int k; int m; int n; int i1; int i2; int i3; int i4; int i5; boolean bool1;
/*      */       boolean bool2;
/*      */       int i6;
/*      */       byte b;
/*      */       Timestamp timestamp2;
/* 3231 */       switch (paramInt1) {
/*      */ 
/*      */         
/*      */         case 93:
/* 3235 */           return Timestamp.valueOf(str1);
/*      */ 
/*      */         
/*      */         case 92:
/* 3239 */           str = this.connection.baseYear() + "-01-01 " + str1;
/* 3240 */           return Timestamp.valueOf(str);
/*      */ 
/*      */         
/*      */         case 91:
/* 3244 */           return Date.valueOf(str1);
/*      */         
/*      */         case -155:
/* 3247 */           i = str1.indexOf('-', 0);
/* 3248 */           j = Integer.parseInt(str1.substring(0, i));
/*      */           
/* 3250 */           k = ++i;
/* 3251 */           i = str1.indexOf('-', k);
/* 3252 */           m = Integer.parseInt(str1.substring(k, i));
/*      */           
/* 3254 */           k = ++i;
/* 3255 */           i = str1.indexOf(' ', k);
/* 3256 */           n = Integer.parseInt(str1.substring(k, i));
/*      */           
/* 3258 */           k = ++i;
/* 3259 */           i = str1.indexOf(':', k);
/* 3260 */           i1 = Integer.parseInt(str1.substring(k, i));
/*      */           
/* 3262 */           k = ++i;
/* 3263 */           i = str1.indexOf(':', k);
/* 3264 */           i2 = Integer.parseInt(str1.substring(k, i));
/*      */           
/* 3266 */           k = ++i;
/* 3267 */           i = str1.indexOf('.', k);
/* 3268 */           i3 = 0; i4 = 0; i5 = 0;
/* 3269 */           bool1 = false;
/* 3270 */           bool2 = false;
/* 3271 */           i6 = 0;
/* 3272 */           if (-1 != i) {
/*      */             
/* 3274 */             i3 = Integer.parseInt(str1.substring(k, i));
/*      */             
/* 3276 */             k = ++i;
/* 3277 */             i = str1.indexOf(' ', k);
/* 3278 */             if (-1 != i)
/*      */             {
/* 3280 */               i5 = Integer.parseInt(str1.substring(k, i));
/* 3281 */               i6 = i - k;
/* 3282 */               bool2 = true;
/*      */             }
/*      */             else
/*      */             {
/* 3286 */               i5 = Integer.parseInt(str1.substring(k));
/* 3287 */               i6 = str1.length() - k;
/*      */             }
/*      */           
/*      */           } else {
/*      */             
/* 3292 */             i = str1.indexOf(' ', k);
/* 3293 */             if (-1 != i) {
/* 3294 */               bool2 = true;
/* 3295 */               i3 = Integer.parseInt(str1.substring(k, i));
/*      */             }
/*      */             else {
/*      */               
/* 3299 */               i3 = Integer.parseInt(str1.substring(k));
/* 3300 */               k = ++i;
/*      */             } 
/*      */           } 
/* 3303 */           if (bool2) {
/*      */             
/* 3305 */             k = ++i;
/* 3306 */             if ('+' == str1.charAt(k)) {
/* 3307 */               k++;
/* 3308 */             } else if ('-' == str1.charAt(k)) {
/*      */               
/* 3310 */               bool1 = true;
/* 3311 */               k++;
/*      */             } 
/* 3313 */             i = str1.indexOf(':', k);
/*      */             
/* 3315 */             int i7 = Integer.parseInt(str1.substring(k, i));
/* 3316 */             k = ++i;
/* 3317 */             int i8 = Integer.parseInt(str1.substring(k));
/* 3318 */             i4 = i7 * 60 + i8;
/* 3319 */             if (bool1)
/* 3320 */               i4 = -i4; 
/*      */           } 
/* 3322 */           gregorianCalendar = new GregorianCalendar(new SimpleTimeZone(i4 * 60 * 1000, ""), Locale.US);
/* 3323 */           gregorianCalendar.clear();
/* 3324 */           gregorianCalendar.set(11, i1);
/* 3325 */           gregorianCalendar.set(12, i2);
/* 3326 */           gregorianCalendar.set(13, i3);
/* 3327 */           gregorianCalendar.set(5, n);
/* 3328 */           gregorianCalendar.set(2, m - 1);
/* 3329 */           gregorianCalendar.set(1, j);
/* 3330 */           for (b = 0; b < 9 - i6; b++) {
/* 3331 */             i5 *= 10;
/*      */           }
/* 3333 */           timestamp2 = new Timestamp(gregorianCalendar.getTimeInMillis());
/* 3334 */           timestamp2.setNanos(i5);
/* 3335 */           return DateTimeOffset.valueOf(timestamp2, i4);
/*      */       } 
/*      */     
/* 3338 */     } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
/*      */       
/* 3340 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
/* 3341 */       Object[] arrayOfObject = { JDBCType.of(paramInt1) };
/* 3342 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     }
/* 3344 */     catch (NumberFormatException numberFormatException) {
/*      */       
/* 3346 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
/* 3347 */       Object[] arrayOfObject = { JDBCType.of(paramInt1) };
/* 3348 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     }
/* 3350 */     catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/* 3352 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_ParsingError"));
/* 3353 */       Object[] arrayOfObject = { JDBCType.of(paramInt1) };
/* 3354 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     } 
/*      */     
/* 3357 */     return paramObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] getEncryptedTemporalBytes(TDSWriter paramTDSWriter, JDBCType paramJDBCType, Object paramObject, int paramInt1, int paramInt2) throws SQLServerException {
/*      */     int i;
/*      */     DateTimeOffset dateTimeOffset;
/*      */     int j;
/* 3367 */     long l = 0L;
/* 3368 */     GregorianCalendar gregorianCalendar = null;
/*      */     
/* 3370 */     switch (paramJDBCType) {
/*      */       
/*      */       case DATE:
/* 3373 */         gregorianCalendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
/* 3374 */         gregorianCalendar.setLenient(true);
/* 3375 */         gregorianCalendar.clear();
/* 3376 */         gregorianCalendar.setTimeInMillis(((Date)paramObject).getTime());
/* 3377 */         return paramTDSWriter.writeEncryptedScaledTemporal(gregorianCalendar, 0, 0, SSType.DATE, (short)0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case TIME:
/* 3385 */         gregorianCalendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
/* 3386 */         gregorianCalendar.setLenient(true);
/* 3387 */         gregorianCalendar.clear();
/* 3388 */         l = ((Timestamp)paramObject).getTime();
/* 3389 */         gregorianCalendar.setTimeInMillis(l);
/* 3390 */         i = 0;
/* 3391 */         if (paramObject instanceof Timestamp) {
/*      */           
/* 3393 */           i = ((Timestamp)paramObject).getNanos();
/*      */         }
/*      */         else {
/*      */           
/* 3397 */           i = 1000000 * (int)(l % 1000L);
/* 3398 */           if (i < 0)
/* 3399 */             i += 1000000000; 
/*      */         } 
/* 3401 */         return paramTDSWriter.writeEncryptedScaledTemporal(gregorianCalendar, i, paramInt2, SSType.TIME, (short)0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case TIMESTAMP:
/* 3409 */         gregorianCalendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
/* 3410 */         gregorianCalendar.setLenient(true);
/* 3411 */         gregorianCalendar.clear();
/* 3412 */         l = ((Timestamp)paramObject).getTime();
/* 3413 */         gregorianCalendar.setTimeInMillis(l);
/* 3414 */         i = ((Timestamp)paramObject).getNanos();
/* 3415 */         return paramTDSWriter.writeEncryptedScaledTemporal(gregorianCalendar, i, paramInt2, SSType.DATETIME2, (short)0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case DATETIME:
/*      */       case SMALLDATETIME:
/* 3424 */         gregorianCalendar = new GregorianCalendar(TimeZone.getDefault(), Locale.US);
/* 3425 */         gregorianCalendar.setLenient(true);
/* 3426 */         gregorianCalendar.clear();
/* 3427 */         l = ((Timestamp)paramObject).getTime();
/* 3428 */         gregorianCalendar.setTimeInMillis(l);
/* 3429 */         i = ((Timestamp)paramObject).getNanos();
/* 3430 */         return paramTDSWriter.getEncryptedDateTimeAsBytes(gregorianCalendar, i, paramJDBCType);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case DATETIMEOFFSET:
/* 3436 */         dateTimeOffset = (DateTimeOffset)paramObject;
/* 3437 */         l = dateTimeOffset.getTimestamp().getTime();
/* 3438 */         i = dateTimeOffset.getTimestamp().getNanos();
/* 3439 */         j = dateTimeOffset.getMinutesOffset();
/* 3440 */         gregorianCalendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
/* 3441 */         gregorianCalendar.setLenient(true);
/* 3442 */         gregorianCalendar.clear();
/* 3443 */         gregorianCalendar.setTimeInMillis(l);
/* 3444 */         return paramTDSWriter.writeEncryptedScaledTemporal(gregorianCalendar, i, paramInt2, SSType.DATETIMEOFFSET, (short)j);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3453 */     MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
/*      */     
/* 3455 */     Object[] arrayOfObject = { paramJDBCType };
/* 3456 */     throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private byte[] normalizedValue(JDBCType paramJDBCType1, Object paramObject, JDBCType paramJDBCType2, int paramInt1, int paramInt2) throws SQLServerException {
/* 3462 */     Long long_ = null;
/* 3463 */     byte[] arrayOfByte = null; try {
/*      */       int i, j; byte[] arrayOfByte1; Float float_; Double double_; BigDecimal bigDecimal1; byte[] arrayOfByte2; BigDecimal bigDecimal2;
/*      */       int k;
/*      */       long l;
/*      */       ByteBuffer byteBuffer;
/* 3468 */       switch (paramJDBCType1) {
/*      */         
/*      */         case BIT:
/* 3471 */           long_ = Long.valueOf(((Boolean)paramObject).booleanValue() ? 1L : 0L);
/* 3472 */           return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();
/*      */         
/*      */         case TINYINT:
/*      */         case SMALLINT:
/* 3476 */           switch (paramJDBCType2)
/*      */           
/*      */           { case BIT:
/* 3479 */               long_ = new Long(((Boolean)paramObject).booleanValue() ? 1L : 0L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 3491 */               return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array(); }  if (paramObject instanceof Integer) { int m = ((Integer)paramObject).intValue(); short s = (short)m; long_ = new Long(s); } else { long_ = new Long(((Short)paramObject).shortValue()); }  return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();
/*      */         
/*      */         case INTEGER:
/* 3494 */           switch (paramJDBCType2)
/*      */           
/*      */           { case BIT:
/* 3497 */               long_ = new Long(((Boolean)paramObject).booleanValue() ? 1L : 0L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 3506 */               return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();case TINYINT: case SMALLINT: long_ = new Long(((Short)paramObject).shortValue()); return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array(); }  long_ = new Long(((Integer)paramObject).intValue()); return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();
/*      */         
/*      */         case BIGINT:
/* 3509 */           switch (paramJDBCType2)
/*      */           
/*      */           { case BIT:
/* 3512 */               long_ = new Long(((Boolean)paramObject).booleanValue() ? 1L : 0L);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 3524 */               return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();case TINYINT: case SMALLINT: long_ = new Long(((Short)paramObject).shortValue()); return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();case INTEGER: long_ = new Long(((Integer)paramObject).intValue()); return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array(); }  long_ = new Long(((Long)paramObject).longValue()); return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(long_.longValue()).array();
/*      */         
/*      */         case BINARY:
/*      */         case VARBINARY:
/*      */         case LONGVARBINARY:
/* 3529 */           arrayOfByte1 = null;
/* 3530 */           if (paramObject instanceof String) {
/*      */             
/* 3532 */             arrayOfByte1 = ParameterUtils.HexToBin((String)paramObject);
/*      */           }
/*      */           else {
/*      */             
/* 3536 */             arrayOfByte1 = (byte[])paramObject;
/*      */           } 
/* 3538 */           if (arrayOfByte1.length > paramInt1) {
/*      */             
/* 3540 */             MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3541 */             Object[] arrayOfObject1 = { paramJDBCType2, paramJDBCType1 };
/* 3542 */             throw new SQLServerException(this, messageFormat1.format(arrayOfObject1), null, 0, false);
/*      */           } 
/* 3544 */           return arrayOfByte1;
/*      */         case GUID:
/* 3546 */           return Util.asGuidByteArray(UUID.fromString((String)paramObject));
/*      */ 
/*      */ 
/*      */         
/*      */         case CHAR:
/*      */         case VARCHAR:
/*      */         case LONGVARCHAR:
/* 3553 */           if (((String)paramObject).length() > paramInt1) {
/*      */             
/* 3555 */             MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3556 */             Object[] arrayOfObject1 = { paramJDBCType2, paramJDBCType1 };
/* 3557 */             throw new SQLServerException(this, messageFormat1.format(arrayOfObject1), null, 0, false);
/*      */           } 
/* 3559 */           return ((String)paramObject).getBytes(Charset.forName("UTF-8"));
/*      */ 
/*      */         
/*      */         case NCHAR:
/*      */         case NVARCHAR:
/*      */         case LONGNVARCHAR:
/* 3565 */           if (((String)paramObject).length() > paramInt1) {
/*      */             
/* 3567 */             MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3568 */             Object[] arrayOfObject1 = { paramJDBCType2, paramJDBCType1 };
/* 3569 */             throw new SQLServerException(this, messageFormat1.format(arrayOfObject1), null, 0, false);
/*      */           } 
/* 3571 */           return ((String)paramObject).getBytes(Charset.forName("UTF-16LE"));
/*      */ 
/*      */         
/*      */         case REAL:
/*      */         case FLOAT:
/* 3576 */           float_ = Float.valueOf((paramObject instanceof String) ? Float.parseFloat((String)paramObject) : ((Float)paramObject).floatValue());
/* 3577 */           return ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(float_.floatValue()).array();
/*      */         
/*      */         case DOUBLE:
/* 3580 */           double_ = Double.valueOf((paramObject instanceof String) ? Double.parseDouble((String)paramObject) : ((Double)paramObject).doubleValue());
/* 3581 */           return ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putDouble(double_.doubleValue()).array();
/*      */         
/*      */         case NUMERIC:
/*      */         case DECIMAL:
/* 3585 */           j = ((BigDecimal)paramObject).scale();
/* 3586 */           i = ((BigDecimal)paramObject).precision();
/* 3587 */           bigDecimal1 = (BigDecimal)paramObject;
/* 3588 */           if (i > paramInt1 || j > paramInt2) {
/*      */             
/* 3590 */             MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3591 */             Object[] arrayOfObject1 = { paramJDBCType2, paramJDBCType1 };
/* 3592 */             throw new SQLServerException(this, messageFormat1.format(arrayOfObject1), null, 0, false);
/*      */           } 
/* 3594 */           if (j < paramInt2)
/*      */           {
/* 3596 */             bigDecimal1 = bigDecimal1.setScale(paramInt2);
/*      */           }
/* 3598 */           arrayOfByte = DDC.convertBigDecimalToBytes(bigDecimal1, bigDecimal1.scale());
/* 3599 */           arrayOfByte2 = new byte[16];
/*      */           
/* 3601 */           System.arraycopy(arrayOfByte, 2, arrayOfByte2, 0, arrayOfByte.length - 2);
/* 3602 */           return arrayOfByte2;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case SMALLMONEY:
/*      */         case MONEY:
/* 3609 */           bigDecimal2 = (BigDecimal)paramObject;
/*      */           
/* 3611 */           Util.validateMoneyRange(bigDecimal2, paramJDBCType1);
/*      */ 
/*      */           
/* 3614 */           k = bigDecimal2.precision() - bigDecimal2.scale() + 4;
/*      */           
/* 3616 */           l = ((BigDecimal)paramObject).multiply(new BigDecimal(10000), new MathContext(k, RoundingMode.HALF_UP)).longValue();
/* 3617 */           byteBuffer = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN);
/* 3618 */           byteBuffer.putInt((int)(l >> 32L)).array();
/* 3619 */           byteBuffer.putInt((int)l).array();
/* 3620 */           return byteBuffer.array();
/*      */       } 
/*      */       
/* 3623 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnsupportedDataTypeAE"));
/* 3624 */       Object[] arrayOfObject = { paramJDBCType1 };
/* 3625 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */ 
/*      */     
/*      */     }
/* 3629 */     catch (NumberFormatException numberFormatException) {
/*      */       
/* 3631 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3632 */       Object[] arrayOfObject = { paramJDBCType2, paramJDBCType1 };
/* 3633 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     }
/* 3635 */     catch (IllegalArgumentException illegalArgumentException) {
/*      */       
/* 3637 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidDataForAE"));
/* 3638 */       Object[] arrayOfObject = { paramJDBCType2, paramJDBCType1 };
/* 3639 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean goToNextRow() throws SQLServerException {
/*      */     try {
/* 3646 */       if (null != this.sourceResultSet)
/*      */       {
/* 3648 */         return this.sourceResultSet.next();
/*      */       }
/*      */ 
/*      */       
/* 3652 */       return this.sourceBulkRecord.next();
/*      */     
/*      */     }
/* 3655 */     catch (SQLException sQLException) {
/*      */       
/* 3657 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean writeBatchData(TDSWriter paramTDSWriter) throws SQLServerException {
/* 3670 */     int i = this.copyOptions.getBatchSize();
/* 3671 */     byte b = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 3676 */       if (0 != i && b >= i) {
/* 3677 */         return true;
/*      */       }
/*      */       
/* 3680 */       if (!goToNextRow()) {
/* 3681 */         return false;
/*      */       }
/*      */       
/* 3684 */       paramTDSWriter.writeByte((byte)-47);
/* 3685 */       int j = this.columnMappings.size();
/*      */ 
/*      */       
/* 3688 */       if (null != this.sourceResultSet) {
/*      */ 
/*      */ 
/*      */         
/* 3692 */         for (byte b1 = 0; b1 < j; b1++)
/*      */         {
/* 3694 */           writeColumn(paramTDSWriter, ((ColumnMapping)this.columnMappings.get(b1)).sourceColumnOrdinal, ((ColumnMapping)this.columnMappings.get(b1)).destinationColumnOrdinal, null);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/* 3706 */         Object[] arrayOfObject = this.sourceBulkRecord.getRowData();
/*      */         
/* 3708 */         for (byte b1 = 0; b1 < j; b1++)
/*      */         {
/*      */ 
/*      */           
/* 3712 */           writeColumn(paramTDSWriter, ((ColumnMapping)this.columnMappings.get(b1)).sourceColumnOrdinal, ((ColumnMapping)this.columnMappings.get(b1)).destinationColumnOrdinal, arrayOfObject[((ColumnMapping)this.columnMappings.get(b1)).sourceColumnOrdinal - 1]);
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3719 */       b++;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerBulkCopy.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */