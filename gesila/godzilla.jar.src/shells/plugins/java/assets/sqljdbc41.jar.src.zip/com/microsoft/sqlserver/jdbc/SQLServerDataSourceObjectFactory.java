/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.util.Hashtable;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.Name;
/*    */ import javax.naming.RefAddr;
/*    */ import javax.naming.Reference;
/*    */ import javax.naming.spi.ObjectFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLServerDataSourceObjectFactory
/*    */   implements ObjectFactory
/*    */ {
/*    */   public Object getObjectInstance(Object paramObject, Name paramName, Context paramContext, Hashtable<?, ?> paramHashtable) throws SQLServerException {
/*    */     try {
/* 29 */       Reference reference = (Reference)paramObject;
/*    */       
/* 31 */       RefAddr refAddr = reference.get("class");
/*    */ 
/*    */       
/* 34 */       if (null == refAddr)
/*    */       {
/* 36 */         SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */       }
/*    */ 
/*    */       
/* 40 */       String str = (String)refAddr.getContent();
/*    */       
/* 42 */       if (null == str) {
/* 43 */         SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */       }
/*    */ 
/*    */       
/* 47 */       if (str.equals("com.microsoft.sqlserver.jdbc.SQLServerDataSource") || str.equals("com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource") || str.equals("com.microsoft.sqlserver.jdbc.SQLServerXADataSource")) {
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */         
/* 53 */         Class<?> clazz = Class.forName(str);
/* 54 */         Object object = clazz.newInstance();
/*    */ 
/*    */ 
/*    */         
/* 58 */         SQLServerDataSource sQLServerDataSource = (SQLServerDataSource)object;
/* 59 */         sQLServerDataSource.initializeFromReference(reference);
/* 60 */         return object;
/*    */       } 
/*    */       
/* 63 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */     
/*    */     }
/* 66 */     catch (ClassNotFoundException classNotFoundException) {
/*    */       
/* 68 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */     
/*    */     }
/* 71 */     catch (InstantiationException instantiationException) {
/*    */       
/* 73 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */     
/*    */     }
/* 76 */     catch (IllegalAccessException illegalAccessException) {
/*    */       
/* 78 */       SQLServerException.makeFromDriverError(null, null, SQLServerException.getErrString("R_invalidDataSourceReference"), null, true);
/*    */     } 
/*    */ 
/*    */     
/* 82 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerDataSourceObjectFactory.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */