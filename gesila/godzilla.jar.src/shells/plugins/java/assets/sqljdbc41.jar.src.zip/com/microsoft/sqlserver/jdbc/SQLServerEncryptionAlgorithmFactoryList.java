/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class SQLServerEncryptionAlgorithmFactoryList
/*    */ {
/*    */   private ConcurrentHashMap<String, SQLServerEncryptionAlgorithmFactory> encryptionAlgoFactoryMap;
/* 15 */   private static final SQLServerEncryptionAlgorithmFactoryList instance = new SQLServerEncryptionAlgorithmFactoryList();
/*    */   
/*    */   private SQLServerEncryptionAlgorithmFactoryList() {
/* 18 */     this.encryptionAlgoFactoryMap = new ConcurrentHashMap<>();
/* 19 */     this.encryptionAlgoFactoryMap.putIfAbsent("AEAD_AES_256_CBC_HMAC_SHA256", new SQLServerAeadAes256CbcHmac256Factory());
/*    */   }
/*    */   
/*    */   static SQLServerEncryptionAlgorithmFactoryList getInstance() {
/* 23 */     return instance;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   String getRegisteredCipherAlgorithmNames() {
/* 30 */     StringBuffer stringBuffer = new StringBuffer();
/* 31 */     boolean bool = true;
/* 32 */     for (String str : this.encryptionAlgoFactoryMap.keySet()) {
/* 33 */       if (bool) {
/* 34 */         stringBuffer.append("'");
/* 35 */         bool = false;
/*    */       } else {
/* 37 */         stringBuffer.append(", '");
/*    */       } 
/* 39 */       stringBuffer.append(str);
/* 40 */       stringBuffer.append("'");
/*    */     } 
/*    */     
/* 43 */     return stringBuffer.toString();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   SQLServerEncryptionAlgorithm getAlgorithm(SQLServerSymmetricKey paramSQLServerSymmetricKey, SQLServerEncryptionType paramSQLServerEncryptionType, String paramString) throws SQLServerException {
/* 55 */     SQLServerEncryptionAlgorithm sQLServerEncryptionAlgorithm = null;
/* 56 */     SQLServerEncryptionAlgorithmFactory sQLServerEncryptionAlgorithmFactory = null;
/* 57 */     if (!this.encryptionAlgoFactoryMap.containsKey(paramString)) {
/* 58 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_UnknownColumnEncryptionAlgorithm"));
/* 59 */       Object[] arrayOfObject = { paramString, getInstance().getRegisteredCipherAlgorithmNames() };
/* 60 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*    */     } 
/*    */     
/* 63 */     sQLServerEncryptionAlgorithmFactory = this.encryptionAlgoFactoryMap.get(paramString);
/* 64 */     assert null != sQLServerEncryptionAlgorithmFactory : "Null Algorithm Factory class detected";
/* 65 */     sQLServerEncryptionAlgorithm = sQLServerEncryptionAlgorithmFactory.create(paramSQLServerSymmetricKey, paramSQLServerEncryptionType, paramString);
/* 66 */     return sQLServerEncryptionAlgorithm;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerEncryptionAlgorithmFactoryList.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */