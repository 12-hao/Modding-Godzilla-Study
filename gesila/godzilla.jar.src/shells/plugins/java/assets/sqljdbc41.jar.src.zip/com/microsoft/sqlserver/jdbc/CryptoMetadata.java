/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CryptoMetadata
/*     */ {
/*     */   TypeInfo baseTypeInfo;
/*     */   CekTableEntry cekTableEntry;
/*     */   byte cipherAlgorithmId;
/*     */   String cipherAlgorithmName;
/*     */   SQLServerEncryptionType encryptionType;
/*     */   byte normalizationRuleVersion;
/* 167 */   SQLServerEncryptionAlgorithm cipherAlgorithm = null;
/*     */   EncryptionKeyInfo encryptionKeyInfo;
/*     */   short ordinal;
/*     */   
/*     */   CekTableEntry getCekTableEntry() {
/* 172 */     return this.cekTableEntry;
/*     */   }
/*     */   
/*     */   void setCekTableEntry(CekTableEntry paramCekTableEntry) {
/* 176 */     this.cekTableEntry = paramCekTableEntry;
/*     */   }
/*     */   
/*     */   TypeInfo getBaseTypeInfo() {
/* 180 */     return this.baseTypeInfo;
/*     */   }
/*     */   
/*     */   void setBaseTypeInfo(TypeInfo paramTypeInfo) {
/* 184 */     this.baseTypeInfo = paramTypeInfo;
/*     */   }
/*     */   
/*     */   SQLServerEncryptionAlgorithm getEncryptionAlgorithm() {
/* 188 */     return this.cipherAlgorithm;
/*     */   }
/*     */   
/*     */   void setEncryptionAlgorithm(SQLServerEncryptionAlgorithm paramSQLServerEncryptionAlgorithm) {
/* 192 */     this.cipherAlgorithm = paramSQLServerEncryptionAlgorithm;
/*     */   }
/*     */   
/*     */   EncryptionKeyInfo getEncryptionKeyInfo() {
/* 196 */     return this.encryptionKeyInfo;
/*     */   }
/*     */   
/*     */   void setEncryptionKeyInfo(EncryptionKeyInfo paramEncryptionKeyInfo) {
/* 200 */     this.encryptionKeyInfo = paramEncryptionKeyInfo;
/*     */   }
/*     */   
/*     */   byte getEncryptionAlgorithmId() {
/* 204 */     return this.cipherAlgorithmId;
/*     */   }
/*     */   
/*     */   String getEncryptionAlgorithmName() {
/* 208 */     return this.cipherAlgorithmName;
/*     */   }
/*     */   
/*     */   SQLServerEncryptionType getEncryptionType() {
/* 212 */     return this.encryptionType;
/*     */   }
/*     */   
/*     */   byte getNormalizationRuleVersion() {
/* 216 */     return this.normalizationRuleVersion;
/*     */   }
/*     */   
/*     */   short getOrdinal() {
/* 220 */     return this.ordinal;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CryptoMetadata(CekTableEntry paramCekTableEntry, short paramShort, byte paramByte1, String paramString, byte paramByte2, byte paramByte3) throws SQLServerException {
/* 230 */     this.cekTableEntry = paramCekTableEntry;
/* 231 */     this.ordinal = paramShort;
/* 232 */     this.cipherAlgorithmId = paramByte1;
/* 233 */     this.cipherAlgorithmName = paramString;
/* 234 */     this.encryptionType = SQLServerEncryptionType.of(paramByte2);
/* 235 */     this.normalizationRuleVersion = paramByte3;
/* 236 */     this.encryptionKeyInfo = null;
/*     */   }
/*     */   
/*     */   boolean IsAlgorithmInitialized() {
/* 240 */     return (null != this.cipherAlgorithm);
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/CryptoMetadata.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */