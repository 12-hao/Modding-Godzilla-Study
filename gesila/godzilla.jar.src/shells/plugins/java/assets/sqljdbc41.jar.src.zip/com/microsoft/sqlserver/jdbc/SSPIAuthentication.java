package com.microsoft.sqlserver.jdbc;

abstract class SSPIAuthentication {
  abstract byte[] GenerateClientContext(byte[] paramArrayOfbyte, boolean[] paramArrayOfboolean) throws SQLServerException;
  
  abstract int ReleaseClientContext() throws SQLServerException;
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SSPIAuthentication.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */