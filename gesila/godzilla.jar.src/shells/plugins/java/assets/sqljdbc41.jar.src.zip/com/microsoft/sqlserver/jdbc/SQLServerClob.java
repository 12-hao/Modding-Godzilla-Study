/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Reader;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.io.Writer;
/*    */ import java.sql.Clob;
/*    */ import java.sql.SQLException;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ 
/*    */ public class SQLServerClob
/*    */   extends SQLServerClobBase
/*    */   implements Clob
/*    */ {
/* 17 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerClob");
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Deprecated
/*    */   public SQLServerClob(SQLServerConnection paramSQLServerConnection, String paramString) {
/* 27 */     super(paramSQLServerConnection, paramString, (null == paramSQLServerConnection) ? null : paramSQLServerConnection.getDatabaseCollation(), logger);
/*    */     
/* 29 */     if (null == paramString) {
/* 30 */       throw new NullPointerException(SQLServerException.getErrString("R_cantSetNull"));
/*    */     }
/*    */   }
/*    */   
/*    */   SQLServerClob(SQLServerConnection paramSQLServerConnection) {
/* 35 */     super(paramSQLServerConnection, "", paramSQLServerConnection.getDatabaseCollation(), logger);
/*    */   }
/*    */ 
/*    */   
/*    */   SQLServerClob(BaseInputStream paramBaseInputStream, TypeInfo paramTypeInfo) throws SQLServerException, UnsupportedEncodingException {
/* 40 */     super(null, new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()), paramTypeInfo.getSQLCollation(), logger);
/*    */   }
/*    */   final JDBCType getJdbcType() {
/* 43 */     return JDBCType.CLOB;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerClob.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */