/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.security.InvalidKeyException;
/*     */ import java.text.MessageFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerAeadAes256CbcHmac256EncryptionKey
/*     */   extends SQLServerSymmetricKey
/*     */ {
/*     */   static final int keySize = 256;
/*     */   private final String algorithmName;
/*     */   private String encryptionKeySaltFormat;
/*     */   private String macKeySaltFormat;
/*     */   private String ivKeySaltFormat;
/*     */   private SQLServerSymmetricKey encryptionKey;
/*     */   private SQLServerSymmetricKey macKey;
/*     */   private SQLServerSymmetricKey ivKey;
/*     */   
/*     */   SQLServerAeadAes256CbcHmac256EncryptionKey(byte[] paramArrayOfbyte, String paramString) throws SQLServerException {
/*  40 */     super(paramArrayOfbyte);
/*  41 */     this.algorithmName = paramString;
/*  42 */     this.encryptionKeySaltFormat = "Microsoft SQL Server cell encryption key with encryption algorithm:" + this.algorithmName + " and key length:" + 'Ā';
/*     */     
/*  44 */     this.macKeySaltFormat = "Microsoft SQL Server cell MAC key with encryption algorithm:" + this.algorithmName + " and key length:" + 'Ā';
/*     */     
/*  46 */     this.ivKeySaltFormat = "Microsoft SQL Server cell IV key with encryption algorithm:" + this.algorithmName + " and key length:" + 'Ā';
/*     */     
/*  48 */     byte b = 32;
/*  49 */     if (paramArrayOfbyte.length != b) {
/*     */       
/*  51 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidKeySize"));
/*  52 */       Object[] arrayOfObject = { Integer.valueOf(paramArrayOfbyte.length), Integer.valueOf(b), this.algorithmName };
/*  53 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  59 */     byte[] arrayOfByte = new byte[b];
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  64 */       arrayOfByte = SQLServerSecurityUtility.getHMACWithSHA256(this.encryptionKeySaltFormat.getBytes("UTF-16LE"), paramArrayOfbyte, arrayOfByte.length);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  69 */       this.encryptionKey = new SQLServerSymmetricKey(arrayOfByte);
/*     */ 
/*     */       
/*  72 */       byte[] arrayOfByte1 = new byte[b];
/*  73 */       arrayOfByte1 = SQLServerSecurityUtility.getHMACWithSHA256(this.macKeySaltFormat.getBytes("UTF-16LE"), paramArrayOfbyte, arrayOfByte1.length);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  78 */       this.macKey = new SQLServerSymmetricKey(arrayOfByte1);
/*     */ 
/*     */       
/*  81 */       byte[] arrayOfByte2 = new byte[b];
/*  82 */       arrayOfByte2 = SQLServerSecurityUtility.getHMACWithSHA256(this.ivKeySaltFormat.getBytes("UTF-16LE"), paramArrayOfbyte, arrayOfByte2.length);
/*     */ 
/*     */ 
/*     */       
/*  86 */       this.ivKey = new SQLServerSymmetricKey(arrayOfByte2);
/*     */     }
/*  88 */     catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */       
/*  90 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_unsupportedEncoding"));
/*     */       
/*  92 */       Object[] arrayOfObject = { "UTF-16LE" };
/*  93 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     }
/*  95 */     catch (InvalidKeyException|java.security.NoSuchAlgorithmException invalidKeyException) {
/*     */       
/*  97 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_KeyExtractionFailed"));
/*     */       
/*  99 */       Object[] arrayOfObject = { invalidKeyException.getMessage() };
/* 100 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getEncryptionKey() {
/* 112 */     return this.encryptionKey.getRootKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getMacKey() {
/* 121 */     return this.macKey.getRootKey();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getIVKey() {
/* 130 */     return this.ivKey.getRootKey();
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerAeadAes256CbcHmac256EncryptionKey.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */