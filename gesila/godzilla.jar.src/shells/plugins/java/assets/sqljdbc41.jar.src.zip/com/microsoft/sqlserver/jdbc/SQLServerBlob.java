/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.Closeable;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Blob;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLFeatureNotSupportedException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class SQLServerBlob
/*     */   implements Blob, Serializable
/*     */ {
/*     */   private byte[] value;
/*     */   private SQLServerConnection con;
/*     */   private boolean isClosed = false;
/*  28 */   ArrayList<Closeable> activeStreams = new ArrayList<>(1);
/*     */   
/*  30 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerBlob");
/*     */   
/*  32 */   private static int baseID = 0;
/*     */   private final String traceID;
/*     */   
/*     */   public final String toString() {
/*  36 */     return this.traceID;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized int nextInstanceID() {
/*  42 */     baseID++;
/*  43 */     return baseID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @Deprecated
/*     */   public SQLServerBlob(SQLServerConnection paramSQLServerConnection, byte[] paramArrayOfbyte) {
/*  54 */     this.traceID = " SQLServerBlob:" + nextInstanceID();
/*  55 */     this.con = paramSQLServerConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     if (null == paramArrayOfbyte) {
/*  61 */       throw new NullPointerException(SQLServerException.getErrString("R_cantSetNull"));
/*     */     }
/*  63 */     this.value = paramArrayOfbyte;
/*     */     
/*  65 */     if (logger.isLoggable(Level.FINE)) {
/*     */       
/*  67 */       String str = (null != paramSQLServerConnection) ? paramSQLServerConnection.toString() : "null connection";
/*  68 */       logger.fine(toString() + " created by (" + str + ")");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   SQLServerBlob(SQLServerConnection paramSQLServerConnection) {
/*  74 */     this.traceID = " SQLServerBlob:" + nextInstanceID();
/*  75 */     this.con = paramSQLServerConnection;
/*  76 */     this.value = new byte[0];
/*  77 */     if (logger.isLoggable(Level.FINE)) {
/*  78 */       logger.fine(toString() + " created by (" + paramSQLServerConnection.toString() + ")");
/*     */     }
/*     */   }
/*     */   
/*     */   SQLServerBlob(BaseInputStream paramBaseInputStream) throws SQLServerException {
/*  83 */     this.traceID = " SQLServerBlob:" + nextInstanceID();
/*  84 */     this.value = paramBaseInputStream.getBytes();
/*  85 */     if (logger.isLoggable(Level.FINE)) {
/*  86 */       logger.fine(toString() + " created by (null connection)");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void free() throws SQLException {
/*  98 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */     
/* 100 */     if (!this.isClosed) {
/*     */ 
/*     */       
/* 103 */       if (null != this.activeStreams) {
/*     */         
/* 105 */         for (Closeable closeable : this.activeStreams) {
/*     */ 
/*     */           
/*     */           try {
/* 109 */             closeable.close();
/*     */           }
/* 111 */           catch (IOException iOException) {
/*     */             
/* 113 */             logger.fine(toString() + " ignored IOException closing stream " + closeable + ": " + iOException.getMessage());
/*     */           } 
/*     */         } 
/* 116 */         this.activeStreams = null;
/*     */       } 
/*     */ 
/*     */       
/* 120 */       this.value = null;
/*     */       
/* 122 */       this.isClosed = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void checkClosed() throws SQLServerException {
/* 131 */     if (this.isClosed) {
/*     */       
/* 133 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 134 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(new Object[] { "Blob" }, ), null, true);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getBinaryStream() throws SQLException {
/* 145 */     checkClosed();
/*     */     
/* 147 */     return getBinaryStreamInternal(0, this.value.length);
/*     */   }
/*     */ 
/*     */   
/*     */   public InputStream getBinaryStream(long paramLong1, long paramLong2) throws SQLException {
/* 152 */     DriverJDBCVersion.checkSupportsJDBC4();
/*     */ 
/*     */     
/* 155 */     throw new SQLFeatureNotSupportedException(SQLServerException.getErrString("R_notSupported"));
/*     */   }
/*     */ 
/*     */   
/*     */   private InputStream getBinaryStreamInternal(int paramInt1, int paramInt2) {
/* 160 */     assert null != this.value;
/* 161 */     assert paramInt1 >= 0;
/* 162 */     assert 0 <= paramInt2 && paramInt2 <= this.value.length - paramInt1;
/* 163 */     assert null != this.activeStreams;
/*     */     
/* 165 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.value, paramInt1, paramInt2);
/* 166 */     this.activeStreams.add(byteArrayInputStream);
/* 167 */     return byteArrayInputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] getBytes(long paramLong, int paramInt) throws SQLException {
/* 182 */     checkClosed();
/*     */     
/* 184 */     if (paramLong < 1L) {
/*     */       
/* 186 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 187 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 188 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     } 
/*     */     
/* 191 */     if (paramInt < 0) {
/*     */       
/* 193 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 194 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 195 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     } 
/*     */ 
/*     */     
/* 199 */     paramLong--;
/*     */ 
/*     */     
/* 202 */     if (paramLong > this.value.length) {
/* 203 */       paramLong = this.value.length;
/*     */     }
/*     */     
/* 206 */     if (paramInt > this.value.length - paramLong) {
/* 207 */       paramInt = (int)(this.value.length - paramLong);
/*     */     }
/* 209 */     byte[] arrayOfByte = new byte[paramInt];
/* 210 */     System.arraycopy(this.value, (int)paramLong, arrayOfByte, 0, paramInt);
/* 211 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long length() throws SQLException {
/* 221 */     checkClosed();
/*     */     
/* 223 */     return this.value.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long position(Blob paramBlob, long paramLong) throws SQLException {
/* 237 */     checkClosed();
/*     */     
/* 239 */     if (paramLong < 1L) {
/*     */       
/* 241 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 242 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 243 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     } 
/*     */     
/* 246 */     if (null == paramBlob) {
/* 247 */       return -1L;
/*     */     }
/* 249 */     return position(paramBlob.getBytes(1L, (int)paramBlob.length()), paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long position(byte[] paramArrayOfbyte, long paramLong) throws SQLException {
/* 263 */     checkClosed();
/*     */     
/* 265 */     if (paramLong < 1L) {
/*     */       
/* 267 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 268 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 269 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 274 */     if (null == paramArrayOfbyte) {
/* 275 */       return -1L;
/*     */     }
/*     */     
/* 278 */     paramLong--;
/*     */ 
/*     */     
/* 281 */     for (int i = (int)paramLong; i <= this.value.length - paramArrayOfbyte.length; i++) {
/*     */       
/* 283 */       boolean bool = true;
/* 284 */       for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/*     */         
/* 286 */         if (this.value[i + b] != paramArrayOfbyte[b]) {
/*     */           
/* 288 */           bool = false;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 293 */       if (bool) {
/* 294 */         return (i + 1);
/*     */       }
/*     */     } 
/* 297 */     return -1L;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void truncate(long paramLong) throws SQLException {
/* 309 */     checkClosed();
/*     */     
/* 311 */     if (paramLong < 0L) {
/*     */       
/* 313 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 314 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 315 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     } 
/*     */     
/* 318 */     if (this.value.length > paramLong) {
/*     */       
/* 320 */       byte[] arrayOfByte = new byte[(int)paramLong];
/* 321 */       System.arraycopy(this.value, 0, arrayOfByte, 0, (int)paramLong);
/* 322 */       this.value = arrayOfByte;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream setBinaryStream(long paramLong) throws SQLException {
/* 334 */     checkClosed();
/*     */     
/* 336 */     if (paramLong < 1L) {
/*     */       
/* 338 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 339 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(new Object[] { Long.valueOf(paramLong) }, ), null, true);
/*     */     } 
/*     */     
/* 342 */     return new SQLServerBlobOutputStream(this, paramLong);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setBytes(long paramLong, byte[] paramArrayOfbyte) throws SQLException {
/* 355 */     checkClosed();
/*     */     
/* 357 */     if (null == paramArrayOfbyte) {
/* 358 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/*     */     }
/* 360 */     return setBytes(paramLong, paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int setBytes(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 384 */     checkClosed();
/*     */     
/* 386 */     if (null == paramArrayOfbyte) {
/* 387 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true);
/*     */     }
/*     */     
/* 390 */     if (paramInt1 < 0 || paramInt1 > paramArrayOfbyte.length) {
/*     */       
/* 392 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidOffset"));
/* 393 */       Object[] arrayOfObject = { new Integer(paramInt1) };
/* 394 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     } 
/*     */ 
/*     */     
/* 398 */     if (paramInt2 < 0 || paramInt2 > paramArrayOfbyte.length - paramInt1) {
/*     */       
/* 400 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 401 */       Object[] arrayOfObject = { new Integer(paramInt2) };
/* 402 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 408 */     if (paramLong <= 0L || paramLong > (this.value.length + 1)) {
/*     */       
/* 410 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidPositionIndex"));
/* 411 */       Object[] arrayOfObject = { new Long(paramLong) };
/* 412 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     } 
/*     */ 
/*     */     
/* 416 */     paramLong--;
/*     */ 
/*     */     
/* 419 */     if (paramInt2 >= this.value.length - paramLong) {
/*     */ 
/*     */       
/* 422 */       DataTypes.getCheckedLength(this.con, JDBCType.BLOB, paramLong + paramInt2, false);
/* 423 */       assert paramLong + paramInt2 <= 2147483647L;
/*     */ 
/*     */       
/* 426 */       byte[] arrayOfByte = new byte[(int)paramLong + paramInt2];
/* 427 */       System.arraycopy(this.value, 0, arrayOfByte, 0, (int)paramLong);
/*     */ 
/*     */       
/* 430 */       System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, (int)paramLong, paramInt2);
/* 431 */       this.value = arrayOfByte;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 436 */       System.arraycopy(paramArrayOfbyte, paramInt1, this.value, (int)paramLong, paramInt2);
/*     */     } 
/*     */     
/* 439 */     return paramInt2;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerBlob.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */