/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.sql.Savepoint;
/*    */ import java.text.MessageFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class SQLServerSavepoint
/*    */   implements Savepoint
/*    */ {
/*    */   private final String sName;
/*    */   private final int nId;
/*    */   private final SQLServerConnection con;
/*    */   
/*    */   public SQLServerSavepoint(SQLServerConnection paramSQLServerConnection, String paramString) {
/* 27 */     this.con = paramSQLServerConnection;
/* 28 */     if (paramString == null) {
/*    */       
/* 30 */       this.nId = paramSQLServerConnection.getNextSavepointId();
/* 31 */       this.sName = null;
/*    */     }
/*    */     else {
/*    */       
/* 35 */       this.sName = paramString;
/* 36 */       this.nId = 0;
/*    */     } 
/*    */   }
/*    */   
/*    */   public String getSavepointName() throws SQLServerException {
/* 41 */     if (this.sName == null)
/* 42 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_savepointNotNamed"), null, false); 
/* 43 */     return this.sName;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public String getLabel() {
/* 51 */     if (this.sName == null) {
/* 52 */       return "S" + this.nId;
/*    */     }
/* 54 */     return this.sName;
/*    */   }
/*    */   
/*    */   public boolean isNamed() {
/* 58 */     return (this.sName != null);
/*    */   }
/*    */   
/*    */   public int getSavepointId() throws SQLServerException {
/* 62 */     if (this.sName != null) {
/*    */       
/* 64 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_savepointNamed"));
/* 65 */       Object[] arrayOfObject = { new String(this.sName) };
/* 66 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, false);
/*    */     } 
/* 68 */     return this.nId;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerSavepoint.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */