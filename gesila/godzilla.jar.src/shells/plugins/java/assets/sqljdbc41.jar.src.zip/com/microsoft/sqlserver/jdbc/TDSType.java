/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.text.MessageFormat;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ enum TDSType
/*    */ {
/* 23 */   BIT1(50),
/* 24 */   INT8(127),
/* 25 */   INT4(56),
/* 26 */   INT2(52),
/* 27 */   INT1(48),
/* 28 */   FLOAT4(59),
/* 29 */   FLOAT8(62),
/* 30 */   DATETIME4(58),
/* 31 */   DATETIME8(61),
/* 32 */   MONEY4(122),
/* 33 */   MONEY8(60),
/*    */ 
/*    */   
/* 36 */   BITN(104),
/* 37 */   INTN(38),
/* 38 */   DECIMALN(106),
/* 39 */   NUMERICN(108),
/* 40 */   FLOATN(109),
/* 41 */   MONEYN(110),
/* 42 */   DATETIMEN(111),
/* 43 */   GUID(36),
/* 44 */   DATEN(40),
/* 45 */   TIMEN(41),
/* 46 */   DATETIME2N(42),
/* 47 */   DATETIMEOFFSETN(43),
/*    */ 
/*    */   
/* 50 */   BIGCHAR(175),
/* 51 */   BIGVARCHAR(167),
/* 52 */   BIGBINARY(173),
/* 53 */   BIGVARBINARY(165),
/* 54 */   NCHAR(239),
/* 55 */   NVARCHAR(231),
/*    */ 
/*    */   
/* 58 */   IMAGE(34),
/* 59 */   TEXT(35),
/* 60 */   NTEXT(99),
/* 61 */   UDT(240),
/* 62 */   XML(241),
/*    */ 
/*    */   
/* 65 */   SQL_VARIANT(98);
/*    */   
/*    */   private final int intValue;
/*    */   
/*    */   static {
/* 70 */     valuesTypes = new TDSType[256];
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 76 */     for (TDSType tDSType : values())
/* 77 */       valuesTypes[tDSType.intValue] = tDSType; 
/*    */   }
/*    */   private static final int MAXELEMENTS = 256; private static final TDSType[] valuesTypes;
/*    */   
/*    */   TDSType(int paramInt1) {
/* 82 */     this.intValue = paramInt1;
/*    */   }
/*    */   
/*    */   byte byteValue() {
/*    */     return (byte)this.intValue;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/TDSType.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */