/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.Reader;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.io.Writer;
/*    */ import java.sql.Clob;
/*    */ import java.sql.NClob;
/*    */ import java.sql.SQLException;
/*    */ import java.util.logging.Logger;
/*    */ 
/*    */ public final class SQLServerNClob
/*    */   extends SQLServerClobBase implements NClob {
/* 15 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerNClob");
/*    */ 
/*    */   
/*    */   SQLServerNClob(SQLServerConnection paramSQLServerConnection) {
/* 19 */     super(paramSQLServerConnection, "", paramSQLServerConnection.getDatabaseCollation(), logger);
/*    */   }
/*    */ 
/*    */   
/*    */   SQLServerNClob(BaseInputStream paramBaseInputStream, TypeInfo paramTypeInfo) throws SQLServerException, UnsupportedEncodingException {
/* 24 */     super(null, new String(paramBaseInputStream.getBytes(), paramTypeInfo.getCharset()), paramTypeInfo.getSQLCollation(), logger);
/*    */   }
/*    */   final JDBCType getJdbcType() {
/* 27 */     return JDBCType.NCLOB;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerNClob.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */