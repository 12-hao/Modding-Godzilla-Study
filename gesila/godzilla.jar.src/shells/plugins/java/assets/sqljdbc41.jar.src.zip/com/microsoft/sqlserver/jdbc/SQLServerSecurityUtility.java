/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.util.Iterator;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerSecurityUtility
/*     */ {
/*     */   static byte[] getHMACWithSHA256(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt) throws NoSuchAlgorithmException, InvalidKeyException {
/*  27 */     byte[] arrayOfByte2 = new byte[paramInt];
/*  28 */     Mac mac = Mac.getInstance("HmacSHA256");
/*  29 */     SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte2, "HmacSHA256");
/*  30 */     mac.init(secretKeySpec);
/*  31 */     byte[] arrayOfByte1 = mac.doFinal(paramArrayOfbyte1);
/*     */     
/*  33 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfByte2.length);
/*  34 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static boolean compareBytes(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) {
/*  46 */     if (null == paramArrayOfbyte1 || null == paramArrayOfbyte2) {
/*  47 */       return false;
/*     */     }
/*     */     
/*  50 */     if (paramArrayOfbyte2.length - paramInt1 < paramInt2) {
/*  51 */       return false;
/*     */     }
/*     */     
/*  54 */     for (byte b = 0; b < paramArrayOfbyte1.length && b < paramInt2; b++) {
/*  55 */       if (paramArrayOfbyte1[b] != paramArrayOfbyte2[paramInt1 + b]) {
/*  56 */         return false;
/*     */       }
/*     */     } 
/*  59 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] encryptWithKey(byte[] paramArrayOfbyte, CryptoMetadata paramCryptoMetadata, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/*  69 */     String str = paramSQLServerConnection.getTrustedServerNameAE();
/*  70 */     assert str != null : "Server name should npt be null in EncryptWithKey";
/*     */ 
/*     */     
/*  73 */     if (!paramCryptoMetadata.IsAlgorithmInitialized()) {
/*  74 */       decryptSymmetricKey(paramCryptoMetadata, paramSQLServerConnection);
/*     */     }
/*     */     
/*  77 */     assert paramCryptoMetadata.IsAlgorithmInitialized();
/*  78 */     byte[] arrayOfByte = paramCryptoMetadata.cipherAlgorithm.encryptData(paramArrayOfbyte);
/*  79 */     if (null == arrayOfByte || 0 == arrayOfByte.length) {
/*  80 */       throw new SQLServerException(null, SQLServerException.getErrString("R_NullCipherTextAE"), null, 0, false);
/*     */     }
/*  82 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static String ValidateAndGetEncryptionAlgorithmName(byte paramByte, String paramString) throws SQLServerException {
/*  94 */     if (2 != paramByte) {
/*  95 */       throw new SQLServerException(null, SQLServerException.getErrString("R_CustomCipherAlgorithmNotSupportedAE"), null, 0, false);
/*     */     }
/*  97 */     return "AEAD_AES_256_CBC_HMAC_SHA256";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void decryptSymmetricKey(CryptoMetadata paramCryptoMetadata, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/* 108 */     assert null != paramCryptoMetadata : "md should not be null in DecryptSymmetricKey.";
/* 109 */     assert null != paramCryptoMetadata.cekTableEntry : "md.EncryptionInfo should not be null in DecryptSymmetricKey.";
/* 110 */     assert null != paramCryptoMetadata.cekTableEntry.columnEncryptionKeyValues : "md.EncryptionInfo.ColumnEncryptionKeyValues should not be null in DecryptSymmetricKey.";
/*     */     
/* 112 */     SQLServerSymmetricKey sQLServerSymmetricKey = null;
/* 113 */     EncryptionKeyInfo encryptionKeyInfo = null;
/* 114 */     SQLServerSymmetricKeyCache sQLServerSymmetricKeyCache = SQLServerSymmetricKeyCache.getInstance();
/* 115 */     Iterator<EncryptionKeyInfo> iterator = paramCryptoMetadata.cekTableEntry.columnEncryptionKeyValues.iterator();
/* 116 */     SQLServerException sQLServerException = null;
/* 117 */     while (iterator.hasNext()) {
/*     */       
/* 119 */       EncryptionKeyInfo encryptionKeyInfo1 = iterator.next();
/*     */       try {
/* 121 */         sQLServerSymmetricKey = sQLServerSymmetricKeyCache.getKey(encryptionKeyInfo1, paramSQLServerConnection);
/* 122 */         if (null != sQLServerSymmetricKey) {
/* 123 */           encryptionKeyInfo = encryptionKeyInfo1;
/*     */           
/*     */           break;
/*     */         } 
/* 127 */       } catch (SQLServerException sQLServerException1) {
/*     */         
/* 129 */         sQLServerException = sQLServerException1;
/*     */       } 
/*     */     } 
/*     */     
/* 133 */     if (null == sQLServerSymmetricKey) {
/* 134 */       assert null != sQLServerException : "CEK decryption failed without raising exceptions";
/* 135 */       throw sQLServerException;
/*     */     } 
/*     */ 
/*     */     
/* 139 */     paramCryptoMetadata.cipherAlgorithm = null;
/* 140 */     SQLServerEncryptionAlgorithm sQLServerEncryptionAlgorithm = null;
/* 141 */     String str = ValidateAndGetEncryptionAlgorithmName(paramCryptoMetadata.cipherAlgorithmId, paramCryptoMetadata.cipherAlgorithmName);
/* 142 */     sQLServerEncryptionAlgorithm = SQLServerEncryptionAlgorithmFactoryList.getInstance().getAlgorithm(sQLServerSymmetricKey, paramCryptoMetadata.encryptionType, str);
/* 143 */     assert null != sQLServerEncryptionAlgorithm : "Cipher algorithm cannot be null in DecryptSymmetricKey";
/* 144 */     paramCryptoMetadata.cipherAlgorithm = sQLServerEncryptionAlgorithm;
/* 145 */     paramCryptoMetadata.encryptionKeyInfo = encryptionKeyInfo;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static byte[] decryptWithKey(byte[] paramArrayOfbyte, CryptoMetadata paramCryptoMetadata, SQLServerConnection paramSQLServerConnection) throws SQLServerException {
/* 154 */     String str = paramSQLServerConnection.getTrustedServerNameAE();
/* 155 */     assert null != str : "serverName should not be null in DecryptWithKey.";
/*     */ 
/*     */     
/* 158 */     if (!paramCryptoMetadata.IsAlgorithmInitialized()) {
/* 159 */       decryptSymmetricKey(paramCryptoMetadata, paramSQLServerConnection);
/*     */     }
/*     */     
/* 162 */     assert paramCryptoMetadata.IsAlgorithmInitialized() : "Decryption Algorithm is not initialized";
/* 163 */     byte[] arrayOfByte = paramCryptoMetadata.cipherAlgorithm.decryptData(paramArrayOfbyte);
/* 164 */     if (null == arrayOfByte) {
/* 165 */       throw new SQLServerException(null, SQLServerException.getErrString("R_PlainTextNullAE"), null, 0, false);
/*     */     }
/*     */     
/* 168 */     return arrayOfByte;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerSecurityUtility.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */