/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TVP
/*     */ {
/*     */   String TVPName;
/*     */   String TVP_owningSchema;
/*     */   String TVP_dbName;
/*  26 */   ResultSet sourceResultSet = null;
/*  27 */   SQLServerDataTable sourceDataTable = null;
/*  28 */   Map<Integer, SQLServerMetaData> columnMetadata = null;
/*  29 */   Iterator<Map.Entry<Integer, Object[]>> sourceDataTableRowIterator = null;
/*  30 */   ISQLServerDataRecord sourceRecord = null;
/*     */   
/*  32 */   TVPType tvpType = null;
/*     */   
/*     */   enum MPIState
/*     */   {
/*  36 */     MPI_Value,
/*  37 */     MPI_ParseNonQuote,
/*  38 */     MPI_LookForSeparator,
/*  39 */     MPI_LookForNextCharOrSeparator,
/*  40 */     MPI_ParseQuote,
/*  41 */     MPI_RightQuote;
/*     */   }
/*     */ 
/*     */   
/*     */   void initTVP(TVPType paramTVPType, String paramString) throws SQLServerException {
/*  46 */     this.tvpType = paramTVPType;
/*  47 */     this.columnMetadata = new LinkedHashMap<>();
/*  48 */     parseTypeName(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   TVP(String paramString) throws SQLServerException {
/*  53 */     initTVP(TVPType.Null, paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   TVP(String paramString, SQLServerDataTable paramSQLServerDataTable) throws SQLServerException {
/*  59 */     initTVP(TVPType.SQLServerDataTable, paramString);
/*  60 */     this.sourceDataTable = paramSQLServerDataTable;
/*  61 */     this.sourceDataTableRowIterator = this.sourceDataTable.getIterator();
/*  62 */     populateMetadataFromDataTable();
/*     */   }
/*     */ 
/*     */   
/*     */   TVP(String paramString, ResultSet paramResultSet) throws SQLServerException {
/*  67 */     initTVP(TVPType.ResultSet, paramString);
/*  68 */     this.sourceResultSet = paramResultSet;
/*     */     
/*  70 */     populateMetadataFromResultSet();
/*     */   }
/*     */ 
/*     */   
/*     */   TVP(String paramString, ISQLServerDataRecord paramISQLServerDataRecord) throws SQLServerException {
/*  75 */     initTVP(TVPType.ISQLServerDataRecord, paramString);
/*  76 */     this.sourceRecord = paramISQLServerDataRecord;
/*     */     
/*  78 */     populateMetadataFromDataRecord();
/*     */ 
/*     */     
/*  81 */     validateOrderProperty();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean isNull() {
/*  86 */     return (TVPType.Null == this.tvpType);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   Object[] getRowData() throws SQLServerException {
/*  92 */     if (TVPType.ResultSet == this.tvpType) {
/*     */       
/*  94 */       int i = this.columnMetadata.size();
/*  95 */       Object[] arrayOfObject = new Object[i];
/*  96 */       for (byte b = 0; b < i; b++) {
/*     */ 
/*     */         
/*     */         try {
/* 100 */           arrayOfObject[b] = this.sourceResultSet.getObject(b + 1);
/*     */         }
/* 102 */         catch (SQLException sQLException) {
/*     */           
/* 104 */           throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLException);
/*     */         } 
/*     */       } 
/* 107 */       return arrayOfObject;
/*     */     } 
/* 109 */     if (TVPType.SQLServerDataTable == this.tvpType) {
/*     */       
/* 111 */       Map.Entry entry = this.sourceDataTableRowIterator.next();
/* 112 */       return (Object[])entry.getValue();
/*     */     } 
/*     */     
/* 115 */     return this.sourceRecord.getRowData();
/*     */   }
/*     */ 
/*     */   
/*     */   boolean next() throws SQLServerException {
/* 120 */     if (TVPType.ResultSet == this.tvpType) {
/*     */       
/*     */       try {
/*     */         
/* 124 */         return this.sourceResultSet.next();
/*     */       }
/* 126 */       catch (SQLException sQLException) {
/*     */         
/* 128 */         throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveSourceData"), sQLException);
/*     */       } 
/*     */     }
/* 131 */     if (TVPType.SQLServerDataTable == this.tvpType)
/*     */     {
/* 133 */       return this.sourceDataTableRowIterator.hasNext();
/*     */     }
/*     */     
/* 136 */     return this.sourceRecord.next();
/*     */   }
/*     */ 
/*     */   
/*     */   void populateMetadataFromDataTable() throws SQLServerException {
/* 141 */     assert null != this.sourceDataTable;
/*     */     
/* 143 */     Map<Integer, SQLServerDataColumn> map = this.sourceDataTable.getColumnMetadata();
/* 144 */     if (null == map || map.isEmpty())
/*     */     {
/* 146 */       throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
/*     */     }
/*     */ 
/*     */     
/* 150 */     Iterator<Map.Entry> iterator = map.entrySet().iterator();
/* 151 */     while (iterator.hasNext()) {
/*     */       
/* 153 */       Map.Entry entry = iterator.next();
/*     */       
/* 155 */       this.columnMetadata.put((Integer)entry.getKey(), new SQLServerMetaData(((SQLServerDataColumn)entry.getValue()).columnName, ((SQLServerDataColumn)entry.getValue()).javaSqlType, ((SQLServerDataColumn)entry.getValue()).precision, ((SQLServerDataColumn)entry.getValue()).scale));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void populateMetadataFromResultSet() throws SQLServerException {
/* 167 */     assert null != this.sourceResultSet;
/*     */     
/*     */     try {
/* 170 */       ResultSetMetaData resultSetMetaData = this.sourceResultSet.getMetaData();
/* 171 */       for (byte b = 0; b < resultSetMetaData.getColumnCount(); b++)
/*     */       {
/* 173 */         SQLServerMetaData sQLServerMetaData = new SQLServerMetaData(resultSetMetaData.getColumnName(b + 1), resultSetMetaData.getColumnType(b + 1), resultSetMetaData.getPrecision(b + 1), resultSetMetaData.getScale(b + 1));
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 178 */         this.columnMetadata.put(Integer.valueOf(b), sQLServerMetaData);
/*     */       }
/*     */     
/* 181 */     } catch (SQLException sQLException) {
/*     */       
/* 183 */       throw new SQLServerException(SQLServerException.getErrString("R_unableRetrieveColMeta"), sQLException);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void populateMetadataFromDataRecord() throws SQLServerException {
/* 189 */     assert null != this.sourceRecord;
/* 190 */     if (0 >= this.sourceRecord.getColumnCount())
/*     */     {
/* 192 */       throw new SQLServerException(SQLServerException.getErrString("R_TVPEmptyMetadata"), null);
/*     */     }
/*     */ 
/*     */     
/* 196 */     for (byte b = 0; b < this.sourceRecord.getColumnCount(); b++) {
/*     */ 
/*     */       
/* 199 */       Util.checkDuplicateColumnName((this.sourceRecord.getColumnMetaData(b + 1)).columnName, this.columnMetadata);
/* 200 */       SQLServerMetaData sQLServerMetaData = new SQLServerMetaData(this.sourceRecord.getColumnMetaData(b + 1));
/* 201 */       this.columnMetadata.put(Integer.valueOf(b), sQLServerMetaData);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void validateOrderProperty() throws SQLServerException {
/* 207 */     int i = this.columnMetadata.size();
/* 208 */     boolean[] arrayOfBoolean = new boolean[i];
/*     */     
/* 210 */     int j = -1;
/* 211 */     byte b = 0;
/* 212 */     Iterator<Map.Entry> iterator = this.columnMetadata.entrySet().iterator();
/* 213 */     while (iterator.hasNext()) {
/*     */       
/* 215 */       Map.Entry entry = iterator.next();
/* 216 */       SQLServerSortOrder sQLServerSortOrder = ((SQLServerMetaData)entry.getValue()).sortOrder;
/* 217 */       int k = ((SQLServerMetaData)entry.getValue()).sortOrdinal;
/*     */       
/* 219 */       if (SQLServerSortOrder.Unspecified != sQLServerSortOrder) {
/*     */ 
/*     */         
/* 222 */         if (i <= k) {
/*     */           
/* 224 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPSortOrdinalGreaterThanFieldCount"));
/* 225 */           throw new SQLServerException(messageFormat.format(new Object[] { Integer.valueOf(k), entry.getKey() }, ), null, 0, null);
/*     */         } 
/*     */ 
/*     */         
/* 229 */         if (arrayOfBoolean[k]) {
/*     */           
/* 231 */           MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPDuplicateSortOrdinal"));
/* 232 */           throw new SQLServerException(messageFormat.format(new Object[] { Integer.valueOf(k) }, ), null, 0, null);
/*     */         } 
/*     */         
/* 235 */         arrayOfBoolean[k] = true;
/* 236 */         if (k > j) {
/* 237 */           j = k;
/*     */         }
/* 239 */         b++;
/*     */       } 
/*     */     } 
/*     */     
/* 243 */     if (0 < b)
/*     */     {
/*     */       
/* 246 */       if (j >= b) {
/*     */         byte b1;
/*     */ 
/*     */         
/* 250 */         for (b1 = 0; b1 < b; b1++) {
/*     */           
/* 252 */           if (!arrayOfBoolean[b1])
/*     */             break; 
/*     */         } 
/* 255 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_TVPMissingSortOrdinal"));
/* 256 */         throw new SQLServerException(messageFormat.format(new Object[] { Integer.valueOf(b1) }, ), null, 0, null);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   void parseTypeName(String paramString) throws SQLServerException {
/*     */     MessageFormat messageFormat;
/* 263 */     String str1 = "[\"";
/* 264 */     String str2 = "]\"";
/* 265 */     byte b1 = 46;
/* 266 */     byte b2 = 3;
/* 267 */     String[] arrayOfString = new String[b2];
/* 268 */     int i = 0;
/*     */     
/* 270 */     if (null == paramString || 0 == paramString.length()) {
/*     */       
/* 272 */       MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidTVPName"));
/* 273 */       Object[] arrayOfObject = new Object[0];
/* 274 */       throw new SQLServerException(null, messageFormat1.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */     
/* 277 */     StringBuilder stringBuilder1 = new StringBuilder(paramString.length());
/*     */ 
/*     */     
/* 280 */     StringBuilder stringBuilder2 = null;
/*     */ 
/*     */     
/* 283 */     char c = ' ';
/* 284 */     MPIState mPIState = MPIState.MPI_Value;
/*     */     
/* 286 */     for (byte b3 = 0; b3 < paramString.length(); b3++) {
/*     */       int k;
/* 288 */       char c1 = paramString.charAt(b3);
/* 289 */       switch (mPIState) {
/*     */ 
/*     */         
/*     */         case MPI_Value:
/* 293 */           if (Character.isWhitespace(c1))
/*     */             break; 
/* 295 */           if (c1 == b1) {
/*     */ 
/*     */             
/* 298 */             arrayOfString[i] = "";
/* 299 */             i++; break;
/*     */           } 
/* 301 */           if (-1 != (k = str1.indexOf(c1))) {
/*     */ 
/*     */             
/* 304 */             c = str2.charAt(k);
/* 305 */             stringBuilder1.setLength(0);
/* 306 */             mPIState = MPIState.MPI_ParseQuote; break;
/*     */           } 
/* 308 */           if (-1 != str2.indexOf(c1)) {
/*     */ 
/*     */             
/* 311 */             MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 312 */             throw new SQLServerException(null, messageFormat1.format(new Object[0]), null, 0, false);
/*     */           } 
/*     */ 
/*     */           
/* 316 */           stringBuilder1.setLength(0);
/* 317 */           stringBuilder1.append(c1);
/* 318 */           mPIState = MPIState.MPI_ParseNonQuote;
/*     */           break;
/*     */ 
/*     */         
/*     */         case MPI_ParseNonQuote:
/* 323 */           if (c1 == b1) {
/*     */             
/* 325 */             arrayOfString[i] = stringBuilder1.toString();
/* 326 */             i = incrementStringCount(arrayOfString, i);
/* 327 */             mPIState = MPIState.MPI_Value;
/*     */             break;
/*     */           } 
/* 330 */           if (-1 != str2.indexOf(c1) || -1 != str1.indexOf(c1)) {
/*     */ 
/*     */             
/* 333 */             MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 334 */             throw new SQLServerException(null, messageFormat1.format(new Object[0]), null, 0, false);
/*     */           } 
/* 336 */           if (Character.isWhitespace(c1)) {
/*     */ 
/*     */             
/* 339 */             arrayOfString[i] = stringBuilder1.toString();
/* 340 */             if (null == stringBuilder2)
/* 341 */               stringBuilder2 = new StringBuilder(); 
/* 342 */             stringBuilder2.setLength(0);
/*     */             
/* 344 */             stringBuilder2.append(c1);
/* 345 */             mPIState = MPIState.MPI_LookForNextCharOrSeparator;
/*     */             break;
/*     */           } 
/* 348 */           stringBuilder1.append(c1);
/*     */           break;
/*     */ 
/*     */         
/*     */         case MPI_LookForNextCharOrSeparator:
/* 353 */           if (!Character.isWhitespace(c1)) {
/*     */ 
/*     */             
/* 356 */             if (c1 == b1) {
/*     */               
/* 358 */               i = incrementStringCount(arrayOfString, i);
/* 359 */               mPIState = MPIState.MPI_Value;
/*     */               
/*     */               break;
/*     */             } 
/*     */             
/* 364 */             stringBuilder1.append(stringBuilder2);
/* 365 */             stringBuilder1.append(c1);
/* 366 */             arrayOfString[i] = stringBuilder1.toString();
/* 367 */             mPIState = MPIState.MPI_ParseNonQuote;
/*     */             
/*     */             break;
/*     */           } 
/* 371 */           stringBuilder2.append(c1);
/*     */           break;
/*     */ 
/*     */         
/*     */         case MPI_ParseQuote:
/* 376 */           if (c1 == c) {
/* 377 */             mPIState = MPIState.MPI_RightQuote; break;
/*     */           } 
/* 379 */           stringBuilder1.append(c1);
/*     */           break;
/*     */         
/*     */         case MPI_RightQuote:
/* 383 */           if (c1 == c) {
/*     */ 
/*     */             
/* 386 */             stringBuilder1.append(c1);
/* 387 */             mPIState = MPIState.MPI_ParseQuote; break;
/*     */           } 
/* 389 */           if (c1 == b1) {
/*     */ 
/*     */             
/* 392 */             arrayOfString[i] = stringBuilder1.toString();
/* 393 */             i = incrementStringCount(arrayOfString, i);
/* 394 */             mPIState = MPIState.MPI_Value; break;
/*     */           } 
/* 396 */           if (!Character.isWhitespace(c1)) {
/*     */ 
/*     */             
/* 399 */             MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 400 */             throw new SQLServerException(null, messageFormat1.format(new Object[0]), null, 0, false);
/*     */           } 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 406 */           arrayOfString[i] = stringBuilder1.toString();
/* 407 */           mPIState = MPIState.MPI_LookForSeparator;
/*     */           break;
/*     */ 
/*     */         
/*     */         case MPI_LookForSeparator:
/* 412 */           if (!Character.isWhitespace(c1)) {
/*     */ 
/*     */             
/* 415 */             if (c1 == b1) {
/*     */ 
/*     */               
/* 418 */               i = incrementStringCount(arrayOfString, i);
/* 419 */               mPIState = MPIState.MPI_Value;
/*     */               
/*     */               break;
/*     */             } 
/*     */             
/* 424 */             MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 425 */             throw new SQLServerException(null, messageFormat1.format(new Object[0]), null, 0, false);
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } 
/* 432 */     if (i > b2 - 1) {
/*     */       
/* 434 */       MessageFormat messageFormat1 = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 435 */       throw new SQLServerException(null, messageFormat1.format(new Object[0]), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 439 */     switch (mPIState) {
/*     */       case MPI_Value:
/*     */       case MPI_LookForNextCharOrSeparator:
/*     */       case MPI_LookForSeparator:
/*     */         break;
/*     */       
/*     */       case MPI_ParseNonQuote:
/*     */       case MPI_RightQuote:
/* 447 */         arrayOfString[i] = stringBuilder1.toString();
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 452 */         messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 453 */         throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
/*     */     } 
/*     */     
/* 456 */     if (arrayOfString[0] == null) {
/*     */       
/* 458 */       messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 459 */       throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 464 */     int j = b2 - i - 1;
/* 465 */     if (j > 0) {
/* 466 */       for (int k = b2 - 1; k >= j; k--) {
/*     */         
/* 468 */         arrayOfString[k] = arrayOfString[k - j];
/* 469 */         arrayOfString[k - j] = null;
/*     */       } 
/*     */     }
/*     */     
/* 473 */     this.TVPName = arrayOfString[2];
/* 474 */     this.TVP_owningSchema = arrayOfString[1];
/* 475 */     this.TVP_dbName = arrayOfString[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int incrementStringCount(String[] paramArrayOfString, int paramInt) throws SQLServerException {
/* 488 */     paramInt++;
/* 489 */     int i = paramArrayOfString.length;
/* 490 */     if (paramInt >= i) {
/*     */       
/* 492 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidThreePartName"));
/* 493 */       throw new SQLServerException(null, messageFormat.format(new Object[0]), null, 0, false);
/*     */     } 
/* 495 */     paramArrayOfString[paramInt] = new String();
/* 496 */     return paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   String getTVPName() {
/* 501 */     return this.TVPName;
/*     */   }
/*     */ 
/*     */   
/*     */   String getDbNameTVP() {
/* 506 */     return this.TVP_dbName;
/*     */   }
/*     */ 
/*     */   
/*     */   String getOwningSchemaNameTVP() {
/* 511 */     return this.TVP_owningSchema;
/*     */   }
/*     */ 
/*     */   
/*     */   int getTVPColumnCount() {
/* 516 */     return this.columnMetadata.size();
/*     */   }
/*     */ 
/*     */   
/*     */   Map<Integer, SQLServerMetaData> getColumnMetadata() {
/* 521 */     return this.columnMetadata;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/TVP.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */