/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class TemporalCompatibility
/*    */ {
/*    */   public int getYear() throws SQLServerException {
/* 20 */     SQLServerException.makeFromDriverError(null, null, null, null, false);
/* 21 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getMonthValue() throws SQLServerException {
/* 26 */     SQLServerException.makeFromDriverError(null, null, null, null, false);
/* 27 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getDayOfMonth() throws SQLServerException {
/* 32 */     SQLServerException.makeFromDriverError(null, null, null, null, false);
/* 33 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getHour() throws SQLServerException {
/* 38 */     SQLServerException.makeFromDriverError(null, null, null, null, false);
/* 39 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getMinute() throws SQLServerException {
/* 44 */     SQLServerException.makeFromDriverError(null, null, null, null, false);
/* 45 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getSecond() throws SQLServerException {
/* 50 */     SQLServerException.makeFromDriverError(null, null, null, null, false);
/* 51 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getNano() throws SQLServerException {
/* 56 */     SQLServerException.makeFromDriverError(null, null, null, null, false);
/* 57 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public ZoneOffset getOffset() throws SQLServerException {
/* 62 */     SQLServerException.makeFromDriverError(null, null, null, null, false);
/* 63 */     return null;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/TemporalCompatibility.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */