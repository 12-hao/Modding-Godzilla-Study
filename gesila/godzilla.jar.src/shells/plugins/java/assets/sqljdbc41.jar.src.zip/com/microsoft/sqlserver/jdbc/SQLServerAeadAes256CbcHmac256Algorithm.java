/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ import java.security.InvalidKeyException;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Logger;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.Mac;
/*     */ import javax.crypto.spec.IvParameterSpec;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLServerAeadAes256CbcHmac256Algorithm
/*     */   extends SQLServerEncryptionAlgorithm
/*     */ {
/*  28 */   private static final Logger aeLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.SQLServerAeadAes256CbcHmac256Algorithm");
/*     */ 
/*     */   
/*     */   static final String algorithmName = "AEAD_AES_256_CBC_HMAC_SHA256";
/*     */   
/*     */   private SQLServerAeadAes256CbcHmac256EncryptionKey columnEncryptionkey;
/*     */   
/*     */   private byte algorithmVersion;
/*     */   
/*     */   private boolean isDeterministic = false;
/*     */   
/*  39 */   private int blockSizeInBytes = 16;
/*  40 */   private int keySizeInBytes = 32;
/*  41 */   private byte[] version = new byte[] { 1 };
/*     */   
/*  43 */   private byte[] versionSize = new byte[] { 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  49 */   private int minimumCipherTextLengthInBytesNoAuthenticationTag = 1 + this.blockSizeInBytes + this.blockSizeInBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  55 */   private int minimumCipherTextLengthInBytesWithAuthenticationTag = this.minimumCipherTextLengthInBytesNoAuthenticationTag + this.keySizeInBytes;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerAeadAes256CbcHmac256Algorithm(SQLServerAeadAes256CbcHmac256EncryptionKey paramSQLServerAeadAes256CbcHmac256EncryptionKey, SQLServerEncryptionType paramSQLServerEncryptionType, byte paramByte) {
/*  75 */     this.columnEncryptionkey = paramSQLServerAeadAes256CbcHmac256EncryptionKey;
/*     */     
/*  77 */     if (paramSQLServerEncryptionType == SQLServerEncryptionType.Deterministic)
/*     */     {
/*  79 */       this.isDeterministic = true;
/*     */     }
/*  81 */     this.algorithmVersion = paramByte;
/*  82 */     this.version[0] = paramByte;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] encryptData(byte[] paramArrayOfbyte) throws SQLServerException {
/*  88 */     return encryptData(paramArrayOfbyte, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected byte[] encryptData(byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
/*  99 */     aeLogger.entering(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Encrypting data.");
/*     */ 
/*     */     
/* 102 */     assert paramArrayOfbyte != null;
/* 103 */     byte[] arrayOfByte1 = new byte[this.blockSizeInBytes];
/*     */     
/* 105 */     SecretKeySpec secretKeySpec = new SecretKeySpec(this.columnEncryptionkey.getEncryptionKey(), "AES");
/*     */ 
/*     */     
/* 108 */     if (this.isDeterministic) {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 113 */         arrayOfByte1 = SQLServerSecurityUtility.getHMACWithSHA256(paramArrayOfbyte, this.columnEncryptionkey.getIVKey(), this.blockSizeInBytes);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 118 */       catch (InvalidKeyException|NoSuchAlgorithmException invalidKeyException) {
/*     */         
/* 120 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/*     */         
/* 122 */         Object[] arrayOfObject = { invalidKeyException.getMessage() };
/* 123 */         throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */       } 
/*     */     } else {
/* 126 */       SecureRandom secureRandom = new SecureRandom();
/* 127 */       secureRandom.nextBytes(arrayOfByte1);
/*     */     } 
/*     */ 
/*     */     
/* 131 */     int i = paramArrayOfbyte.length / this.blockSizeInBytes + 1;
/*     */     
/* 133 */     byte b1 = 1;
/* 134 */     byte b2 = paramBoolean ? this.keySizeInBytes : 0;
/* 135 */     int j = b1 + b2;
/* 136 */     int k = j + this.blockSizeInBytes;
/*     */ 
/*     */     
/* 139 */     int m = 1 + b2 + arrayOfByte1.length + i * this.blockSizeInBytes;
/* 140 */     byte[] arrayOfByte2 = new byte[m];
/*     */ 
/*     */     
/* 143 */     arrayOfByte2[0] = this.algorithmVersion;
/*     */     
/* 145 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, j, arrayOfByte1.length);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 151 */       IvParameterSpec ivParameterSpec = new IvParameterSpec(arrayOfByte1);
/* 152 */       Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
/* 153 */       cipher.init(1, secretKeySpec, ivParameterSpec);
/*     */       
/* 155 */       int n = 0;
/* 156 */       int i1 = k;
/*     */       
/* 158 */       if (i > 1) {
/* 159 */         n = (i - 1) * this.blockSizeInBytes;
/* 160 */         i1 += cipher.update(paramArrayOfbyte, 0, n, arrayOfByte2, i1);
/*     */       } 
/*     */       
/* 163 */       byte[] arrayOfByte = cipher.doFinal(paramArrayOfbyte, n, paramArrayOfbyte.length - n);
/*     */       
/* 165 */       System.arraycopy(arrayOfByte, 0, arrayOfByte2, i1, arrayOfByte.length);
/*     */       
/* 167 */       if (paramBoolean)
/*     */       {
/* 169 */         Mac mac = Mac.getInstance("HmacSHA256");
/* 170 */         SecretKeySpec secretKeySpec1 = new SecretKeySpec(this.columnEncryptionkey.getMacKey(), "HmacSHA256");
/* 171 */         mac.init(secretKeySpec1);
/* 172 */         mac.update(this.version, 0, this.version.length);
/* 173 */         mac.update(arrayOfByte1, 0, arrayOfByte1.length);
/* 174 */         mac.update(arrayOfByte2, k, i * this.blockSizeInBytes);
/* 175 */         mac.update(this.versionSize, 0, this.version.length);
/* 176 */         byte[] arrayOfByte3 = mac.doFinal();
/*     */         
/* 178 */         System.arraycopy(arrayOfByte3, 0, arrayOfByte2, b1, b2);
/*     */       }
/*     */     
/* 181 */     } catch (NoSuchAlgorithmException|java.security.InvalidAlgorithmParameterException|InvalidKeyException|javax.crypto.NoSuchPaddingException|javax.crypto.IllegalBlockSizeException|javax.crypto.BadPaddingException|javax.crypto.ShortBufferException noSuchAlgorithmException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_EncryptionFailed"));
/*     */       
/* 192 */       Object[] arrayOfObject = { noSuchAlgorithmException.getMessage() };
/* 193 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */     
/* 196 */     aeLogger.exiting(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Data encrypted.");
/* 197 */     return arrayOfByte2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] decryptData(byte[] paramArrayOfbyte) throws SQLServerException {
/* 204 */     return decryptData(paramArrayOfbyte, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] decryptData(byte[] paramArrayOfbyte, boolean paramBoolean) throws SQLServerException {
/* 216 */     assert paramArrayOfbyte != null;
/*     */     
/* 218 */     byte[] arrayOfByte = new byte[this.blockSizeInBytes];
/*     */     
/* 220 */     int i = paramBoolean ? this.minimumCipherTextLengthInBytesWithAuthenticationTag : this.minimumCipherTextLengthInBytesNoAuthenticationTag;
/*     */ 
/*     */ 
/*     */     
/* 224 */     if (paramArrayOfbyte.length < i) {
/* 225 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidCipherTextSize"));
/* 226 */       Object[] arrayOfObject = { Integer.valueOf(paramArrayOfbyte.length), Integer.valueOf(i) };
/* 227 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 232 */     int j = 0;
/* 233 */     if (paramArrayOfbyte[j] != this.algorithmVersion) {
/* 234 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_InvalidAlgorithmVersion"));
/*     */       
/* 236 */       Object[] arrayOfObject = { String.format("%02X ", new Object[] { Byte.valueOf(paramArrayOfbyte[j]) }), String.format("%02X ", new Object[] { Byte.valueOf(this.algorithmVersion) }) };
/* 237 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 241 */     j++;
/* 242 */     int k = 0;
/*     */ 
/*     */     
/* 245 */     if (paramBoolean) {
/* 246 */       k = j;
/*     */       
/* 248 */       j += this.keySizeInBytes;
/*     */     } 
/*     */ 
/*     */     
/* 252 */     System.arraycopy(paramArrayOfbyte, j, arrayOfByte, 0, arrayOfByte.length);
/* 253 */     j += arrayOfByte.length;
/*     */ 
/*     */     
/* 256 */     int m = j;
/*     */     
/* 258 */     int n = paramArrayOfbyte.length - j;
/*     */     
/* 260 */     if (paramBoolean) {
/*     */       byte[] arrayOfByte1;
/*     */       
/*     */       try {
/* 264 */         arrayOfByte1 = prepareAuthenticationTag(arrayOfByte, paramArrayOfbyte, m, n);
/*     */       }
/* 266 */       catch (InvalidKeyException|NoSuchAlgorithmException invalidKeyException) {
/*     */         
/* 268 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_DecryptionFailed"));
/*     */         
/* 270 */         Object[] arrayOfObject = { invalidKeyException.getMessage() };
/* 271 */         throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */       } 
/*     */       
/* 274 */       if (!SQLServerSecurityUtility.compareBytes(arrayOfByte1, paramArrayOfbyte, k, n))
/*     */       {
/* 276 */         throw new SQLServerException(this, SQLServerException.getErrString("R_InvalidAuthenticationTag"), null, 0, false);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 283 */     return decryptData(arrayOfByte, paramArrayOfbyte, m, n);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] decryptData(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) throws SQLServerException {
/* 296 */     aeLogger.entering(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Decrypting data.");
/* 297 */     assert paramArrayOfbyte2 != null;
/* 298 */     assert paramArrayOfbyte1 != null;
/* 299 */     byte[] arrayOfByte = null;
/*     */     
/* 301 */     SecretKeySpec secretKeySpec = new SecretKeySpec(this.columnEncryptionkey.getEncryptionKey(), "AES");
/*     */     
/* 303 */     IvParameterSpec ivParameterSpec = new IvParameterSpec(paramArrayOfbyte1);
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 308 */       Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
/* 309 */       cipher.init(2, secretKeySpec, ivParameterSpec);
/* 310 */       arrayOfByte = cipher.doFinal(paramArrayOfbyte2, paramInt1, paramInt2);
/*     */     }
/* 312 */     catch (NoSuchAlgorithmException|java.security.InvalidAlgorithmParameterException|InvalidKeyException|javax.crypto.NoSuchPaddingException|javax.crypto.IllegalBlockSizeException|javax.crypto.BadPaddingException noSuchAlgorithmException) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 321 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_DecryptionFailed"));
/*     */       
/* 323 */       Object[] arrayOfObject = { noSuchAlgorithmException.getMessage() };
/* 324 */       throw new SQLServerException(this, messageFormat.format(arrayOfObject), null, 0, false);
/*     */     } 
/*     */     
/* 327 */     aeLogger.exiting(SQLServerAeadAes256CbcHmac256Algorithm.class.getName(), Thread.currentThread().getStackTrace()[1].getMethodName(), "Data decrypted.");
/* 328 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] prepareAuthenticationTag(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) throws NoSuchAlgorithmException, InvalidKeyException {
/* 344 */     assert paramArrayOfbyte2 != null;
/*     */     
/* 346 */     byte[] arrayOfByte2 = new byte[this.keySizeInBytes];
/*     */     
/* 348 */     Mac mac = Mac.getInstance("HmacSHA256");
/* 349 */     SecretKeySpec secretKeySpec = new SecretKeySpec(this.columnEncryptionkey.getMacKey(), "HmacSHA256");
/*     */     
/* 351 */     mac.init(secretKeySpec);
/* 352 */     mac.update(this.version, 0, this.version.length);
/* 353 */     mac.update(paramArrayOfbyte1, 0, paramArrayOfbyte1.length);
/* 354 */     mac.update(paramArrayOfbyte2, paramInt1, paramInt2);
/* 355 */     mac.update(this.versionSize, 0, this.version.length);
/* 356 */     byte[] arrayOfByte1 = mac.doFinal();
/* 357 */     System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, arrayOfByte2.length);
/*     */ 
/*     */ 
/*     */     
/* 361 */     return arrayOfByte2;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerAeadAes256CbcHmac256Algorithm.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */