/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class EncryptionKeyInfo
/*    */ {
/*    */   byte[] encryptedKey;
/*    */   int databaseId;
/*    */   int cekId;
/*    */   int cekVersion;
/*    */   byte[] cekMdVersion;
/*    */   String keyPath;
/*    */   String keyStoreName;
/*    */   String algorithmName;
/*    */   byte normalizationRuleVersion;
/*    */   
/*    */   EncryptionKeyInfo(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfbyte2, String paramString1, String paramString2, String paramString3) {
/* 19 */     this.encryptedKey = paramArrayOfbyte1;
/* 20 */     this.databaseId = paramInt1;
/* 21 */     this.cekId = paramInt2;
/* 22 */     this.cekVersion = paramInt3;
/* 23 */     this.cekMdVersion = paramArrayOfbyte2;
/* 24 */     this.keyPath = paramString1;
/* 25 */     this.keyStoreName = paramString2;
/* 26 */     this.algorithmName = paramString3;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/EncryptionKeyInfo.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */