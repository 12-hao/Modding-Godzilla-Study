/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.ListIterator;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.Vector;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SQLServerStatement
/*      */   implements ISQLServerStatement
/*      */ {
/*      */   static final char LEFT_CURLY_BRACKET = '{';
/*      */   static final char RIGHT_CURLY_BRACKET = '}';
/*      */   private boolean isResponseBufferingAdaptive = false;
/*      */   private boolean wasResponseBufferingSet = false;
/*      */   static final String identityQuery = " select SCOPE_IDENTITY() AS GENERATED_KEYS";
/*      */   String procedureName;
/*      */   private int serverCursorId;
/*      */   private int serverCursorRowCount;
/*      */   
/*      */   final boolean getIsResponseBufferingAdaptive() {
/*   39 */     return this.isResponseBufferingAdaptive;
/*      */   } final boolean wasResponseBufferingSet() {
/*   41 */     return this.wasResponseBufferingSet;
/*      */   }
/*      */   boolean stmtPoolable;
/*      */   private TDSReader tdsReader;
/*      */   Parameter[] inOutParam;
/*      */   final SQLServerConnection connection;
/*      */   int queryTimeout;
/*      */   
/*      */   final int getServerCursorId() {
/*   50 */     return this.serverCursorId;
/*      */   }
/*      */   final int getServerCursorRowCount() {
/*   53 */     return this.serverCursorRowCount;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final TDSReader resultsReader()
/*      */   {
/*   60 */     return this.tdsReader; } final boolean wasExecuted() {
/*   61 */     return (null != this.tdsReader);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isCloseOnCompletion = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   90 */   private volatile TDSCommand currentCommand = null;
/*   91 */   private TDSCommand lastStmtExecCmd = null;
/*      */   
/*      */   final void discardLastExecutionResults() {
/*   94 */     if (null != this.lastStmtExecCmd && !this.bIsClosed) {
/*      */       
/*   96 */       this.lastStmtExecCmd.close();
/*   97 */       this.lastStmtExecCmd = null;
/*      */     } 
/*   99 */     clearLastResult();
/*      */   }
/*      */   
/*  102 */   static final Logger loggerExternal = Logger.getLogger("com.microsoft.sqlserver.jdbc.Statement");
/*      */   
/*      */   private final String loggingClassName;
/*      */   private final String traceID;
/*      */   
/*      */   String getClassNameLogging() {
/*  108 */     return this.loggingClassName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  117 */   protected SQLServerStatementColumnEncryptionSetting stmtColumnEncriptionSetting = SQLServerStatementColumnEncryptionSetting.UseConnectionSetting;
/*      */   private ExecuteProperties execProps;
/*      */   
/*      */   final class ExecuteProperties {
/*      */     private final boolean wasResponseBufferingSet;
/*      */     private final boolean isResponseBufferingAdaptive;
/*      */     private final int holdability;
/*      */     
/*      */     final boolean wasResponseBufferingSet() {
/*  126 */       return this.wasResponseBufferingSet;
/*      */     }
/*      */     final boolean isResponseBufferingAdaptive() {
/*  129 */       return this.isResponseBufferingAdaptive;
/*      */     }
/*      */     final int getHoldability() {
/*  132 */       return this.holdability;
/*      */     }
/*      */     
/*      */     ExecuteProperties(SQLServerStatement param1SQLServerStatement1) {
/*  136 */       this.wasResponseBufferingSet = param1SQLServerStatement1.wasResponseBufferingSet();
/*  137 */       this.isResponseBufferingAdaptive = param1SQLServerStatement1.getIsResponseBufferingAdaptive();
/*  138 */       this.holdability = param1SQLServerStatement1.connection.getHoldabilityInternal();
/*      */     }
/*      */   }
/*      */   
/*      */   final ExecuteProperties getExecProps() {
/*  143 */     return this.execProps;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void executeStatement(TDSCommand paramTDSCommand) throws SQLServerException {
/*  156 */     discardLastExecutionResults();
/*      */ 
/*      */     
/*  159 */     checkClosed();
/*      */     
/*  161 */     this.execProps = new ExecuteProperties(this);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  166 */       executeCommand(paramTDSCommand);
/*      */     }
/*      */     finally {
/*      */       
/*  170 */       this.lastStmtExecCmd = paramTDSCommand;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void executeCommand(TDSCommand paramTDSCommand) throws SQLServerException {
/*  190 */     this.currentCommand = paramTDSCommand;
/*  191 */     this.connection.executeCommand(paramTDSCommand);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean moreResults = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLServerResultSet resultSet;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  209 */   int resultSetCount = 0; static final int EXECUTE_NOT_SET = 0;
/*      */   static final int EXECUTE_QUERY = 1;
/*      */   static final int EXECUTE_UPDATE = 2;
/*      */   
/*      */   synchronized void incrResultSetCount() {
/*  214 */     this.resultSetCount++;
/*      */   }
/*      */   static final int EXECUTE = 3;
/*      */   static final int EXECUTE_BATCH = 4;
/*      */   static final int EXECUTE_QUERY_INTERNAL = 5;
/*      */   
/*      */   synchronized void decrResultSetCount() {
/*  221 */     this.resultSetCount--;
/*  222 */     assert this.resultSetCount >= 0;
/*      */ 
/*      */     
/*  225 */     if (this.isCloseOnCompletion && (4 != this.executeMethod || !this.moreResults) && this.resultSetCount == 0)
/*      */     {
/*      */ 
/*      */       
/*  229 */       closeInternal();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  243 */   int executeMethod = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  248 */   long updateCount = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean escapeProcessing;
/*      */ 
/*      */ 
/*      */   
/*  257 */   int maxRows = 0;
/*      */ 
/*      */   
/*  260 */   int maxFieldSize = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int resultSetConcurrency;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int appResultSetType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int resultSetType;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int getSQLResultSetType()
/*      */   {
/*  307 */     return this.resultSetType; } final int getCursorType() {
/*  308 */     return getResultSetScrollOpt() & 0xFFFFEFFF;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isCursorable(int paramInt) {
/*  324 */     return (this.resultSetType != 2003 && (3 == paramInt || 1 == paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   boolean executedSqlDirectly = false;
/*      */ 
/*      */   
/*      */   boolean expectCursorOutParams;
/*      */ 
/*      */   
/*      */   String cursorName;
/*      */ 
/*      */   
/*      */   int nFetchSize;
/*      */   
/*      */   int defaultFetchSize;
/*      */   
/*      */   int nFetchDirection;
/*      */   
/*      */   boolean bIsClosed;
/*      */   
/*      */   boolean bRequestedGeneratedKeys;
/*      */   
/*      */   private ResultSet autoGeneratedKeys;
/*      */ 
/*      */   
/*      */   class StmtExecOutParamHandler
/*      */     extends TDSTokenHandler
/*      */   {
/*      */     StmtExecOutParamHandler() {
/*  355 */       super("StmtExecOutParamHandler");
/*      */     }
/*      */ 
/*      */     
/*      */     boolean onRetStatus(TDSReader param1TDSReader) throws SQLServerException {
/*  360 */       (new StreamRetStatus()).setFromTDS(param1TDSReader);
/*  361 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean onRetValue(TDSReader param1TDSReader) throws SQLServerException {
/*  366 */       if (SQLServerStatement.this.expectCursorOutParams) {
/*      */         
/*  368 */         Parameter parameter = new Parameter(Util.shouldHonorAEForParameters(SQLServerStatement.this.stmtColumnEncriptionSetting, SQLServerStatement.this.connection));
/*      */ 
/*      */         
/*  371 */         parameter.skipRetValStatus(param1TDSReader);
/*  372 */         SQLServerStatement.this.serverCursorId = parameter.getInt(param1TDSReader);
/*  373 */         parameter.skipValue(param1TDSReader, true);
/*      */         
/*  375 */         parameter = new Parameter(Util.shouldHonorAEForParameters(SQLServerStatement.this.stmtColumnEncriptionSetting, SQLServerStatement.this.connection));
/*      */         
/*  377 */         parameter.skipRetValStatus(param1TDSReader);
/*  378 */         if (-1 == (SQLServerStatement.this.serverCursorRowCount = parameter.getInt(param1TDSReader)))
/*  379 */           SQLServerStatement.this.serverCursorRowCount = -3; 
/*  380 */         parameter.skipValue(param1TDSReader, true);
/*      */ 
/*      */         
/*  383 */         SQLServerStatement.this.expectCursorOutParams = false;
/*  384 */         return true;
/*      */       } 
/*      */       
/*  387 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     boolean onDone(TDSReader param1TDSReader) throws SQLServerException {
/*  392 */       return false;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  432 */   private final ArrayList<String> batchStatementBuffer = new ArrayList<>();
/*      */ 
/*      */   
/*  435 */   private static final Logger stmtlogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerStatement");
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String toString() {
/*  441 */     return this.traceID;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   String getClassNameInternal() {
/*  447 */     return "SQLServerStatement";
/*      */   }
/*      */ 
/*      */   
/*  451 */   private static int lastStatementID = 0; Vector<SQLWarning> sqlWarnings; private static synchronized int nextStatementID() {
/*  452 */     return ++lastStatementID;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   SQLServerStatement(SQLServerConnection paramSQLServerConnection, int paramInt1, int paramInt2, SQLServerStatementColumnEncryptionSetting paramSQLServerStatementColumnEncryptionSetting) throws SQLServerException {
/*  473 */     int i = nextStatementID();
/*  474 */     String str = getClassNameInternal();
/*  475 */     this.traceID = str + ":" + i;
/*  476 */     this.loggingClassName = "com.microsoft.sqlserver.jdbc." + str + ":" + i;
/*      */     
/*  478 */     this.stmtPoolable = false;
/*  479 */     this.connection = paramSQLServerConnection;
/*  480 */     this.bIsClosed = false;
/*      */ 
/*      */ 
/*      */     
/*  484 */     if (1003 != paramInt1 && 1005 != paramInt1 && 1004 != paramInt1 && 2003 != paramInt1 && 2004 != paramInt1 && 1006 != paramInt1 && 1005 != paramInt1 && 1004 != paramInt1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  493 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_unsupportedCursor"), (String)null, true);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  498 */     if (1007 != paramInt2 && 1008 != paramInt2 && 1009 != paramInt2 && 1008 != paramInt2 && 1010 != paramInt2)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  504 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_unsupportedConcurrency"), (String)null, true);
/*      */     }
/*      */ 
/*      */     
/*  508 */     if (null == paramSQLServerStatementColumnEncryptionSetting)
/*      */     {
/*  510 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_unsupportedStmtColEncSetting"), (String)null, true);
/*      */     }
/*      */ 
/*      */     
/*  514 */     this.stmtColumnEncriptionSetting = paramSQLServerStatementColumnEncryptionSetting;
/*      */     
/*  516 */     this.resultSetConcurrency = paramInt2;
/*      */ 
/*      */ 
/*      */     
/*  520 */     this.appResultSetType = paramInt1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  525 */     if (1003 == paramInt1) {
/*      */       
/*  527 */       if (1007 == paramInt2)
/*      */       {
/*      */ 
/*      */         
/*  531 */         String str1 = paramSQLServerConnection.getSelectMethod();
/*  532 */         this.resultSetType = (null == str1 || !str1.equals("cursor")) ? 2003 : 2004;
/*      */ 
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*      */         
/*  539 */         this.resultSetType = 2004;
/*      */       }
/*      */     
/*  542 */     } else if (1004 == paramInt1) {
/*      */       
/*  544 */       this.resultSetType = 1004;
/*      */     }
/*  546 */     else if (1005 == paramInt1) {
/*      */       
/*  548 */       this.resultSetType = 1005;
/*      */     }
/*      */     else {
/*      */       
/*  552 */       this.resultSetType = paramInt1;
/*      */     } 
/*      */ 
/*      */     
/*  556 */     this.nFetchDirection = (2003 == this.resultSetType || 2004 == this.resultSetType) ? 1000 : 1002;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  566 */     this.nFetchSize = (1009 == this.resultSetConcurrency) ? 8 : 128;
/*      */ 
/*      */     
/*  569 */     this.defaultFetchSize = this.nFetchSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  576 */     if (1007 != paramInt2 && (2003 == this.resultSetType || 1004 == this.resultSetType))
/*      */     {
/*      */ 
/*      */       
/*  580 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_unsupportedCursorAndConcurrency"), (String)null, true);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  585 */     setResponseBuffering(this.connection.getResponseBuffering());
/*      */ 
/*      */     
/*  588 */     if (stmtlogger.isLoggable(Level.FINER))
/*      */     {
/*  590 */       stmtlogger.finer("Properties for " + toString() + ":" + " Result type:" + this.appResultSetType + " (" + this.resultSetType + ")" + " Concurrency:" + this.resultSetConcurrency + " Fetchsize:" + this.nFetchSize + " bIsClosed:" + this.bIsClosed + " useLastUpdateCount:" + this.connection.useLastUpdateCount());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  598 */     if (stmtlogger.isLoggable(Level.FINE))
/*      */     {
/*  600 */       stmtlogger.fine(toString() + " created by (" + this.connection.toString() + ")");
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   final Logger getStatementLogger() {
/*  606 */     return stmtlogger;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void NotImplemented() throws SQLServerException {
/*  613 */     SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_notSupported"), (String)null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeInternal() {
/*  629 */     assert !this.bIsClosed;
/*      */     
/*  631 */     discardLastExecutionResults();
/*      */     
/*  633 */     this.bIsClosed = true;
/*  634 */     this.autoGeneratedKeys = null;
/*  635 */     this.sqlWarnings = null;
/*  636 */     this.inOutParam = null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void close() throws SQLServerException {
/*  641 */     loggerExternal.entering(getClassNameLogging(), "close");
/*      */     
/*  643 */     if (!this.bIsClosed) {
/*  644 */       closeInternal();
/*      */     }
/*  646 */     loggerExternal.exiting(getClassNameLogging(), "close");
/*      */   }
/*      */ 
/*      */   
/*      */   public void closeOnCompletion() throws SQLException {
/*  651 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */     
/*  653 */     loggerExternal.entering(getClassNameLogging(), "closeOnCompletion");
/*      */     
/*  655 */     checkClosed();
/*      */ 
/*      */     
/*  658 */     this.isCloseOnCompletion = true;
/*      */     
/*  660 */     loggerExternal.exiting(getClassNameLogging(), "closeOnCompletion");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery(String paramString) throws SQLServerException {
/*  671 */     loggerExternal.entering(getClassNameLogging(), "executeQuery", paramString);
/*  672 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  674 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  676 */     checkClosed();
/*  677 */     executeStatement(new StmtExecCmd(this, paramString, 1, 2));
/*  678 */     loggerExternal.exiting(getClassNameLogging(), "executeQuery", this.resultSet);
/*  679 */     return this.resultSet;
/*      */   }
/*      */ 
/*      */   
/*      */   final SQLServerResultSet executeQueryInternal(String paramString) throws SQLServerException {
/*  684 */     checkClosed();
/*  685 */     executeStatement(new StmtExecCmd(this, paramString, 5, 2));
/*  686 */     return this.resultSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String paramString) throws SQLServerException {
/*  697 */     loggerExternal.entering(getClassNameLogging(), "executeUpdate", paramString);
/*  698 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  700 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  702 */     checkClosed();
/*  703 */     executeStatement(new StmtExecCmd(this, paramString, 2, 2));
/*      */ 
/*      */     
/*  706 */     if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
/*  707 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
/*      */     }
/*  709 */     loggerExternal.exiting(getClassNameLogging(), "executeUpdate", new Long(this.updateCount));
/*      */     
/*  711 */     return (int)this.updateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long executeLargeUpdate(String paramString) throws SQLServerException {
/*  722 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/*  724 */     loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", paramString);
/*  725 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  727 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  729 */     checkClosed();
/*  730 */     executeStatement(new StmtExecCmd(this, paramString, 2, 2));
/*      */     
/*  732 */     loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", new Long(this.updateCount));
/*  733 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String paramString) throws SQLServerException {
/*  745 */     loggerExternal.entering(getClassNameLogging(), "execute", paramString);
/*  746 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  748 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  750 */     checkClosed();
/*  751 */     executeStatement(new StmtExecCmd(this, paramString, 3, 2));
/*  752 */     loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf((null != this.resultSet)));
/*  753 */     return (null != this.resultSet);
/*      */   }
/*      */ 
/*      */   
/*      */   private final class StmtExecCmd
/*      */     extends TDSCommand
/*      */   {
/*      */     final SQLServerStatement stmt;
/*      */     
/*      */     final String sql;
/*      */     
/*      */     final int executeMethod;
/*      */     
/*      */     final int autoGeneratedKeys;
/*      */     
/*      */     StmtExecCmd(SQLServerStatement param1SQLServerStatement1, String param1String, int param1Int1, int param1Int2) {
/*  769 */       super(param1SQLServerStatement1.toString() + " executeXXX", param1SQLServerStatement1.queryTimeout);
/*  770 */       this.stmt = param1SQLServerStatement1;
/*  771 */       this.sql = param1String;
/*  772 */       this.executeMethod = param1Int1;
/*  773 */       this.autoGeneratedKeys = param1Int2;
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean doExecute() throws SQLServerException {
/*  778 */       this.stmt.doExecuteStatement(this);
/*  779 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     final void processResponse(TDSReader param1TDSReader) throws SQLServerException {
/*  784 */       SQLServerStatement.this.ensureExecuteResultsReader(param1TDSReader);
/*  785 */       SQLServerStatement.this.processExecuteResults();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private String ensureSQLSyntax(String paramString) throws SQLServerException {
/*  791 */     if (paramString.indexOf('{') >= 0) {
/*      */       
/*  793 */       JDBCSyntaxTranslator jDBCSyntaxTranslator = new JDBCSyntaxTranslator();
/*  794 */       String str = jDBCSyntaxTranslator.translate(paramString);
/*  795 */       this.procedureName = jDBCSyntaxTranslator.getProcedureName();
/*  796 */       return str;
/*      */     } 
/*      */     
/*  799 */     return paramString;
/*      */   }
/*      */ 
/*      */   
/*      */   void startResults() {
/*  804 */     this.moreResults = true;
/*      */   }
/*      */   
/*      */   final void setMaxRowsAndMaxFieldSize() throws SQLServerException {
/*  808 */     if (1 == this.executeMethod || 3 == this.executeMethod) {
/*      */       
/*  810 */       this.connection.setMaxRows(this.maxRows);
/*  811 */       this.connection.setMaxFieldSize(this.maxFieldSize);
/*      */     }
/*      */     else {
/*      */       
/*  815 */       assert 2 == this.executeMethod || 4 == this.executeMethod || 5 == this.executeMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  822 */       this.connection.setMaxRows(0);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   final void doExecuteStatement(StmtExecCmd paramStmtExecCmd) throws SQLServerException {
/*  828 */     resetForReexecute();
/*      */ 
/*      */     
/*  831 */     this.executeMethod = paramStmtExecCmd.executeMethod;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  836 */     String str = ensureSQLSyntax(paramStmtExecCmd.sql);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  848 */     setMaxRowsAndMaxFieldSize();
/*      */     
/*  850 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  852 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*  854 */     if (isCursorable(this.executeMethod) && isSelect(str)) {
/*      */       
/*  856 */       if (stmtlogger.isLoggable(Level.FINE)) {
/*  857 */         stmtlogger.fine(toString() + " Executing server side cursor " + str);
/*      */       }
/*  859 */       doExecuteCursored(paramStmtExecCmd, str);
/*      */     }
/*      */     else {
/*      */       
/*  863 */       this.executedSqlDirectly = true;
/*  864 */       this.expectCursorOutParams = false;
/*      */       
/*  866 */       TDSWriter tDSWriter = paramStmtExecCmd.startRequest((byte)1);
/*      */       
/*  868 */       tDSWriter.writeString(str);
/*      */ 
/*      */ 
/*      */       
/*  872 */       if (1 == paramStmtExecCmd.autoGeneratedKeys && (2 == this.executeMethod || 3 == this.executeMethod) && str.trim().toUpperCase().startsWith("INSERT"))
/*      */       {
/*      */ 
/*      */         
/*  876 */         tDSWriter.writeString(" select SCOPE_IDENTITY() AS GENERATED_KEYS");
/*      */       }
/*      */       
/*  879 */       if (stmtlogger.isLoggable(Level.FINE)) {
/*  880 */         stmtlogger.fine(toString() + " Executing (not server cursor) " + str);
/*      */       }
/*      */       
/*  883 */       ensureExecuteResultsReader(paramStmtExecCmd.startResponse(this.isResponseBufferingAdaptive));
/*  884 */       startResults();
/*  885 */       getNextResult();
/*      */     } 
/*      */ 
/*      */     
/*  889 */     if (null == this.resultSet) {
/*      */       
/*  891 */       if (1 == this.executeMethod)
/*      */       {
/*  893 */         SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_noResultset"), (String)null, true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*  905 */     else if (2 == this.executeMethod || 4 == this.executeMethod) {
/*      */       
/*  907 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class StmtBatchExecCmd
/*      */     extends TDSCommand
/*      */   {
/*      */     final SQLServerStatement stmt;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     StmtBatchExecCmd(SQLServerStatement param1SQLServerStatement1) {
/*  923 */       super(param1SQLServerStatement1.toString() + " executeBatch", param1SQLServerStatement1.queryTimeout);
/*  924 */       this.stmt = param1SQLServerStatement1;
/*      */     }
/*      */ 
/*      */     
/*      */     final boolean doExecute() throws SQLServerException {
/*  929 */       this.stmt.doExecuteStatementBatch(this);
/*  930 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     final void processResponse(TDSReader param1TDSReader) throws SQLServerException {
/*  935 */       SQLServerStatement.this.ensureExecuteResultsReader(param1TDSReader);
/*  936 */       SQLServerStatement.this.processExecuteResults();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final void doExecuteStatementBatch(StmtBatchExecCmd paramStmtBatchExecCmd) throws SQLServerException {
/*  942 */     resetForReexecute();
/*      */ 
/*      */     
/*  945 */     this.connection.setMaxRows(0);
/*      */     
/*  947 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/*  949 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/*      */ 
/*      */     
/*  953 */     this.executeMethod = 4;
/*  954 */     this.executedSqlDirectly = true;
/*  955 */     this.expectCursorOutParams = false;
/*      */     
/*  957 */     TDSWriter tDSWriter = paramStmtBatchExecCmd.startRequest((byte)1);
/*      */ 
/*      */     
/*  960 */     ListIterator<String> listIterator = this.batchStatementBuffer.listIterator();
/*  961 */     tDSWriter.writeString(listIterator.next());
/*  962 */     while (listIterator.hasNext()) {
/*      */       
/*  964 */       tDSWriter.writeString(" ; ");
/*  965 */       tDSWriter.writeString(listIterator.next());
/*      */     } 
/*      */ 
/*      */     
/*  969 */     ensureExecuteResultsReader(paramStmtBatchExecCmd.startResponse(this.isResponseBufferingAdaptive));
/*  970 */     startResults();
/*  971 */     getNextResult();
/*      */ 
/*      */     
/*  974 */     if (null != this.resultSet)
/*      */     {
/*  976 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void resetForReexecute() throws SQLServerException {
/*  991 */     ensureExecuteResultsReader(null);
/*  992 */     this.autoGeneratedKeys = null;
/*  993 */     this.updateCount = -1L;
/*  994 */     this.sqlWarnings = null;
/*  995 */     this.executedSqlDirectly = false;
/*  996 */     startResults();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isSelect(String paramString) throws SQLServerException {
/* 1006 */     checkClosed();
/*      */ 
/*      */ 
/*      */     
/* 1010 */     String str = paramString.trim();
/* 1011 */     char c = str.charAt(0);
/* 1012 */     if (c != 's' && c != 'S')
/* 1013 */       return false; 
/* 1014 */     return str.substring(0, 6).equalsIgnoreCase("select");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String replaceParameterWithString(String paramString1, char paramChar, String paramString2) {
/* 1025 */     int i = 0;
/* 1026 */     while ((i = paramString1.indexOf("" + paramChar)) >= 0) {
/* 1027 */       paramString1 = paramString1.substring(0, i) + paramString2 + paramString1.substring(i + 1, paramString1.length());
/*      */     }
/* 1029 */     return paramString1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String replaceMarkerWithNull(String paramString) {
/* 1038 */     if (paramString.indexOf("'") < 0) {
/* 1039 */       return replaceParameterWithString(paramString, '?', "null");
/*      */     }
/*      */ 
/*      */     
/* 1043 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, "'", true);
/* 1044 */     boolean bool = true;
/* 1045 */     String str = "";
/* 1046 */     while (stringTokenizer.hasMoreTokens()) {
/* 1047 */       String str1 = stringTokenizer.nextToken();
/* 1048 */       if (str1.equals("'")) {
/* 1049 */         str = str + "'";
/* 1050 */         bool = !bool ? true : false;
/*      */         continue;
/*      */       } 
/* 1053 */       if (bool) {
/* 1054 */         String str2 = replaceParameterWithString(str1, '?', "null");
/* 1055 */         str = str + str2;
/*      */         continue;
/*      */       } 
/* 1058 */       str = str + str1;
/*      */     } 
/*      */ 
/*      */     
/* 1062 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void checkClosed() throws SQLServerException {
/* 1071 */     this.connection.checkClosed();
/* 1072 */     if (this.bIsClosed) {
/* 1073 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_statementIsClosed"), (String)null, false);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getMaxFieldSize() throws SQLServerException {
/* 1081 */     loggerExternal.entering(getClassNameLogging(), "getMaxFieldSize");
/* 1082 */     checkClosed();
/* 1083 */     loggerExternal.exiting(getClassNameLogging(), "getMaxFieldSize", new Integer(this.maxFieldSize));
/* 1084 */     return this.maxFieldSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMaxFieldSize(int paramInt) throws SQLServerException {
/* 1089 */     loggerExternal.entering(getClassNameLogging(), "setMaxFieldSize", new Integer(paramInt));
/* 1090 */     checkClosed();
/* 1091 */     if (paramInt < 0) {
/*      */       
/* 1093 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidLength"));
/* 1094 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 1095 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, true);
/*      */     } 
/* 1097 */     this.maxFieldSize = paramInt;
/* 1098 */     loggerExternal.exiting(getClassNameLogging(), "setMaxFieldSize");
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getMaxRows() throws SQLServerException {
/* 1103 */     loggerExternal.entering(getClassNameLogging(), "getMaxRows");
/* 1104 */     checkClosed();
/* 1105 */     loggerExternal.exiting(getClassNameLogging(), "getMaxRows", new Integer(this.maxRows));
/* 1106 */     return this.maxRows;
/*      */   }
/*      */ 
/*      */   
/*      */   public final long getLargeMaxRows() throws SQLServerException {
/* 1111 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1113 */     loggerExternal.entering(getClassNameLogging(), "getLargeMaxRows");
/*      */ 
/*      */ 
/*      */     
/* 1117 */     loggerExternal.exiting(getClassNameLogging(), "getLargeMaxRows", new Long(this.maxRows));
/*      */     
/* 1119 */     return getMaxRows();
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setMaxRows(int paramInt) throws SQLServerException {
/* 1124 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1125 */       loggerExternal.entering(getClassNameLogging(), "setMaxRows", new Integer(paramInt)); 
/* 1126 */     checkClosed();
/* 1127 */     if (paramInt < 0) {
/*      */       
/* 1129 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidRowcount"));
/* 1130 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 1131 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, true);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1137 */     if (1006 != this.resultSetType)
/* 1138 */       this.maxRows = paramInt; 
/* 1139 */     loggerExternal.exiting(getClassNameLogging(), "setMaxRows");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setLargeMaxRows(long paramLong) throws SQLServerException {
/* 1144 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1146 */     if (loggerExternal.isLoggable(Level.FINER)) {
/* 1147 */       loggerExternal.entering(getClassNameLogging(), "setLargeMaxRows", new Long(paramLong));
/*      */     }
/*      */ 
/*      */     
/* 1151 */     if (paramLong > 2147483647L)
/*      */     {
/* 1153 */       throw new UnsupportedOperationException(SQLServerException.getErrString("R_invalidMaxRows"));
/*      */     }
/* 1155 */     setMaxRows((int)paramLong);
/* 1156 */     loggerExternal.exiting(getClassNameLogging(), "setLargeMaxRows");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setEscapeProcessing(boolean paramBoolean) throws SQLServerException {
/* 1161 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1162 */       loggerExternal.entering(getClassNameLogging(), "setEscapeProcessing", Boolean.valueOf(paramBoolean)); 
/* 1163 */     checkClosed();
/* 1164 */     this.escapeProcessing = paramBoolean;
/* 1165 */     loggerExternal.exiting(getClassNameLogging(), "setEscapeProcessing");
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getQueryTimeout() throws SQLServerException {
/* 1170 */     loggerExternal.entering(getClassNameLogging(), "getQueryTimeout");
/* 1171 */     checkClosed();
/* 1172 */     loggerExternal.exiting(getClassNameLogging(), "getQueryTimeout", new Integer(this.queryTimeout));
/* 1173 */     return this.queryTimeout;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setQueryTimeout(int paramInt) throws SQLServerException {
/* 1178 */     loggerExternal.entering(getClassNameLogging(), "setQueryTimeout", new Integer(paramInt));
/* 1179 */     checkClosed();
/* 1180 */     if (paramInt < 0) {
/*      */       
/* 1182 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidQueryTimeOutValue"));
/* 1183 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 1184 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, true);
/*      */     } 
/* 1186 */     this.queryTimeout = paramInt;
/* 1187 */     loggerExternal.exiting(getClassNameLogging(), "setQueryTimeout");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void cancel() throws SQLServerException {
/* 1192 */     loggerExternal.entering(getClassNameLogging(), "cancel");
/* 1193 */     checkClosed();
/*      */ 
/*      */     
/* 1196 */     if (null != this.currentCommand)
/* 1197 */       this.currentCommand.interrupt(SQLServerException.getErrString("R_queryCancelled")); 
/* 1198 */     loggerExternal.exiting(getClassNameLogging(), "cancel");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final SQLWarning getWarnings() throws SQLServerException {
/* 1205 */     loggerExternal.entering(getClassNameLogging(), "getWarnings");
/* 1206 */     checkClosed();
/* 1207 */     if (this.sqlWarnings == null)
/* 1208 */       return null; 
/* 1209 */     SQLWarning sQLWarning = this.sqlWarnings.elementAt(0);
/* 1210 */     loggerExternal.exiting(getClassNameLogging(), "getWarnings", sQLWarning);
/* 1211 */     return sQLWarning;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void clearWarnings() throws SQLServerException {
/* 1216 */     loggerExternal.entering(getClassNameLogging(), "clearWarnings");
/* 1217 */     checkClosed();
/* 1218 */     this.sqlWarnings = null;
/* 1219 */     loggerExternal.exiting(getClassNameLogging(), "clearWarnings");
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setCursorName(String paramString) throws SQLServerException {
/* 1224 */     loggerExternal.entering(getClassNameLogging(), "setCursorName", paramString);
/* 1225 */     checkClosed();
/* 1226 */     this.cursorName = paramString;
/* 1227 */     loggerExternal.exiting(getClassNameLogging(), "setCursorName");
/*      */   }
/*      */ 
/*      */   
/*      */   final String getCursorName() {
/* 1232 */     return this.cursorName;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ResultSet getResultSet() throws SQLServerException {
/* 1237 */     loggerExternal.entering(getClassNameLogging(), "getResultSet");
/* 1238 */     checkClosed();
/* 1239 */     loggerExternal.exiting(getClassNameLogging(), "getResultSet", this.resultSet);
/* 1240 */     return this.resultSet;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getUpdateCount() throws SQLServerException {
/* 1245 */     loggerExternal.entering(getClassNameLogging(), "getUpdateCount");
/*      */     
/* 1247 */     checkClosed();
/*      */ 
/*      */     
/* 1250 */     if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
/* 1251 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
/*      */     }
/* 1253 */     loggerExternal.exiting(getClassNameLogging(), "getUpdateCount", new Long(this.updateCount));
/*      */     
/* 1255 */     return (int)this.updateCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public final long getLargeUpdateCount() throws SQLServerException {
/* 1260 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1262 */     loggerExternal.entering(getClassNameLogging(), "getUpdateCount");
/* 1263 */     checkClosed();
/* 1264 */     loggerExternal.exiting(getClassNameLogging(), "getUpdateCount", new Long(this.updateCount));
/* 1265 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */   
/*      */   final void ensureExecuteResultsReader(TDSReader paramTDSReader) {
/* 1270 */     this.tdsReader = paramTDSReader;
/*      */   }
/*      */ 
/*      */   
/*      */   final void processExecuteResults() throws SQLServerException {
/* 1275 */     if (wasExecuted()) {
/*      */       
/* 1277 */       processBatch();
/* 1278 */       TDSParser.parse(resultsReader(), "batch completion");
/* 1279 */       ensureExecuteResultsReader(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   void processBatch() throws SQLServerException {
/* 1285 */     processResults();
/*      */   }
/*      */ 
/*      */   
/*      */   final void processResults() throws SQLServerException {
/* 1290 */     SQLServerException sQLServerException = null;
/*      */     
/* 1292 */     while (this.moreResults) {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/* 1297 */         getNextResult();
/*      */       }
/* 1299 */       catch (SQLServerException sQLServerException1) {
/*      */ 
/*      */ 
/*      */         
/* 1303 */         if (this.moreResults) {
/*      */ 
/*      */           
/* 1306 */           if (2 == sQLServerException1.getDriverErrorCode()) {
/*      */             
/* 1308 */             if (stmtlogger.isLoggable(Level.FINEST))
/*      */             {
/* 1310 */               stmtlogger.finest(this + " ignoring database error: " + sQLServerException1.getErrorCode() + " " + sQLServerException1.getMessage());
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             continue;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/* 1321 */           if (sQLServerException1.getSQLState().equals(SQLState.STATEMENT_CANCELED.getSQLStateCode())) {
/*      */             
/* 1323 */             sQLServerException = sQLServerException1;
/*      */             
/*      */             continue;
/*      */           } 
/*      */         } 
/*      */         
/* 1329 */         this.moreResults = false;
/* 1330 */         throw sQLServerException1;
/*      */       } 
/*      */     } 
/*      */     
/* 1334 */     clearLastResult();
/*      */     
/* 1336 */     if (null != sQLServerException) {
/* 1337 */       throw sQLServerException;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final boolean getMoreResults() throws SQLServerException {
/* 1347 */     loggerExternal.entering(getClassNameLogging(), "getMoreResults");
/* 1348 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1353 */     getNextResult();
/* 1354 */     loggerExternal.exiting(getClassNameLogging(), "getMoreResults", Boolean.valueOf((null != this.resultSet)));
/* 1355 */     return (null != this.resultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void clearLastResult() {
/* 1375 */     this.updateCount = -1L;
/*      */ 
/*      */     
/* 1378 */     if (null != this.resultSet) {
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1385 */         this.resultSet.close();
/*      */       }
/* 1387 */       catch (SQLServerException sQLServerException) {
/*      */         
/* 1389 */         stmtlogger.finest(this + " clearing last result; ignored error closing ResultSet: " + sQLServerException.getErrorCode() + " " + sQLServerException.getMessage());
/*      */       
/*      */       }
/*      */       finally {
/*      */ 
/*      */         
/* 1395 */         this.resultSet = null;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean getNextResult() throws SQLServerException {
/*      */     final class NextResult
/*      */       extends TDSTokenHandler
/*      */     {
/* 1415 */       private StreamDone stmtDoneToken = null;
/* 1416 */       final boolean isUpdateCount() { return (null != this.stmtDoneToken); } final long getUpdateCount() {
/* 1417 */         return this.stmtDoneToken.getUpdateCount();
/*      */       } private boolean isResultSet = false;
/*      */       final boolean isResultSet() {
/* 1420 */         return this.isResultSet;
/*      */       }
/* 1422 */       private StreamRetStatus procedureRetStatToken = null;
/*      */ 
/*      */       
/*      */       NextResult() {
/* 1426 */         super("getNextResult");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onColMetaData(TDSReader param1TDSReader) throws SQLServerException {
/* 1435 */         if (null != this.stmtDoneToken) {
/* 1436 */           return false;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1442 */         if (null != getDatabaseError()) {
/* 1443 */           return false;
/*      */         }
/*      */         
/* 1446 */         this.isResultSet = true;
/* 1447 */         return false;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onDone(TDSReader param1TDSReader) throws SQLServerException {
/* 1454 */         StreamDone streamDone = new StreamDone();
/* 1455 */         streamDone.setFromTDS(param1TDSReader);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1461 */         if (streamDone.isAttnAck()) {
/* 1462 */           return false;
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1470 */         if (streamDone.cmdIsDMLOrDDL()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1476 */           if (-1L == streamDone.getUpdateCount() && 4 != SQLServerStatement.this.executeMethod) {
/* 1477 */             return true;
/*      */           }
/*      */ 
/*      */           
/* 1481 */           this.stmtDoneToken = streamDone;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1487 */           if (255 != streamDone.getTokenType()) {
/* 1488 */             return false;
/*      */           }
/* 1490 */           if (4 != SQLServerStatement.this.executeMethod)
/*      */           {
/*      */             
/* 1493 */             if (null != SQLServerStatement.this.procedureName) {
/* 1494 */               return false;
/*      */             }
/*      */             
/* 1497 */             if (3 == SQLServerStatement.this.executeMethod) {
/* 1498 */               return false;
/*      */             }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1505 */             if (!SQLServerStatement.this.connection.useLastUpdateCount()) {
/* 1506 */               return false;
/*      */ 
/*      */ 
/*      */             
/*      */             }
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */           
/* 1523 */           if (streamDone.isFinal()) {
/*      */             
/* 1525 */             SQLServerStatement.this.moreResults = false;
/* 1526 */             return false;
/*      */           } 
/*      */           
/* 1529 */           if (4 == SQLServerStatement.this.executeMethod)
/*      */           {
/*      */ 
/*      */             
/* 1533 */             if (255 != streamDone.getTokenType() || streamDone.wasRPCInBatch()) {
/*      */               
/* 1535 */               SQLServerStatement.this.moreResults = false;
/* 1536 */               return false;
/*      */             } 
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1543 */         if (streamDone.isError()) {
/* 1544 */           return false;
/*      */         }
/*      */         
/* 1547 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onRetStatus(TDSReader param1TDSReader) throws SQLServerException {
/* 1555 */         if (SQLServerStatement.this.consumeExecOutParam(param1TDSReader)) {
/*      */           
/* 1557 */           SQLServerStatement.this.moreResults = false;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1568 */           this.procedureRetStatToken = new StreamRetStatus();
/* 1569 */           this.procedureRetStatToken.setFromTDS(param1TDSReader);
/*      */         } 
/*      */         
/* 1572 */         return true;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       boolean onRetValue(TDSReader param1TDSReader) throws SQLServerException {
/* 1581 */         if (SQLServerStatement.this.moreResults && null == this.procedureRetStatToken) {
/*      */           
/* 1583 */           Parameter parameter = new Parameter(Util.shouldHonorAEForParameters(SQLServerStatement.this.stmtColumnEncriptionSetting, SQLServerStatement.this.connection));
/* 1584 */           parameter.skipRetValStatus(param1TDSReader);
/* 1585 */           parameter.skipValue(param1TDSReader, true);
/* 1586 */           return true;
/*      */         } 
/*      */         
/* 1589 */         return false;
/*      */       }
/*      */ 
/*      */       
/*      */       boolean onInfo(TDSReader param1TDSReader) throws SQLServerException {
/* 1594 */         StreamInfo streamInfo = new StreamInfo();
/* 1595 */         streamInfo.setFromTDS(param1TDSReader);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1609 */         if (16954 == streamInfo.msg.getErrorNumber()) {
/* 1610 */           SQLServerStatement.this.executedSqlDirectly = true;
/*      */         }
/* 1612 */         SQLWarning sQLWarning = new SQLWarning(streamInfo.msg.getMessage(), SQLServerException.generateStateCode(SQLServerStatement.this.connection, streamInfo.msg.getErrorNumber(), streamInfo.msg.getErrorState()), streamInfo.msg.getErrorNumber());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1618 */         if (SQLServerStatement.this.sqlWarnings == null) {
/*      */           
/* 1620 */           SQLServerStatement.this.sqlWarnings = new Vector<>();
/*      */         }
/*      */         else {
/*      */           
/* 1624 */           int i = SQLServerStatement.this.sqlWarnings.size();
/* 1625 */           SQLWarning sQLWarning1 = SQLServerStatement.this.sqlWarnings.elementAt(i - 1);
/* 1626 */           sQLWarning1.setNextWarning(sQLWarning);
/*      */         } 
/* 1628 */         SQLServerStatement.this.sqlWarnings.add(sQLWarning);
/* 1629 */         return true;
/*      */       }
/*      */     };
/*      */ 
/*      */     
/* 1634 */     if (!wasExecuted()) {
/*      */       
/* 1636 */       this.moreResults = false;
/* 1637 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1641 */     clearLastResult();
/*      */ 
/*      */ 
/*      */     
/* 1645 */     if (!this.moreResults) {
/* 1646 */       return false;
/*      */     }
/*      */     
/* 1649 */     NextResult nextResult = new NextResult();
/* 1650 */     TDSParser.parse(resultsReader(), nextResult);
/*      */ 
/*      */     
/* 1653 */     if (null != nextResult.getDatabaseError()) {
/*      */       
/* 1655 */       SQLServerException.makeFromDatabaseError(this.connection, (Object)null, nextResult.getDatabaseError().getMessage(), nextResult.getDatabaseError(), false);
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/* 1664 */       if (nextResult.isResultSet()) {
/*      */         
/* 1666 */         this.resultSet = new SQLServerResultSet(this);
/* 1667 */         return true;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1677 */       if (nextResult.isUpdateCount()) {
/*      */         
/* 1679 */         this.updateCount = nextResult.getUpdateCount();
/* 1680 */         return true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1690 */     this.updateCount = -1L;
/* 1691 */     if (!this.moreResults) {
/* 1692 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1697 */     this.moreResults = false;
/* 1698 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean consumeExecOutParam(TDSReader paramTDSReader) throws SQLServerException {
/* 1710 */     if (this.expectCursorOutParams) {
/*      */       
/* 1712 */       TDSParser.parse(paramTDSReader, new StmtExecOutParamHandler());
/* 1713 */       return true;
/*      */     } 
/*      */     
/* 1716 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setFetchDirection(int paramInt) throws SQLServerException {
/* 1723 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1724 */       loggerExternal.entering(getClassNameLogging(), "setFetchDirection", new Integer(paramInt)); 
/* 1725 */     checkClosed();
/* 1726 */     if ((1000 != paramInt && 1001 != paramInt && 1002 != paramInt) || (1000 != paramInt && (2003 == this.resultSetType || 2004 == this.resultSetType))) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1734 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidFetchDirection"));
/* 1735 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 1736 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */     } 
/*      */     
/* 1739 */     this.nFetchDirection = paramInt;
/* 1740 */     loggerExternal.exiting(getClassNameLogging(), "setFetchDirection");
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getFetchDirection() throws SQLServerException {
/* 1745 */     loggerExternal.entering(getClassNameLogging(), "getFetchDirection");
/* 1746 */     checkClosed();
/* 1747 */     loggerExternal.exiting(getClassNameLogging(), "getFetchDirection", new Integer(this.nFetchDirection));
/* 1748 */     return this.nFetchDirection;
/*      */   }
/*      */ 
/*      */   
/*      */   public final void setFetchSize(int paramInt) throws SQLServerException {
/* 1753 */     if (loggerExternal.isLoggable(Level.FINER))
/* 1754 */       loggerExternal.entering(getClassNameLogging(), "setFetchSize", new Integer(paramInt)); 
/* 1755 */     checkClosed();
/* 1756 */     if (paramInt < 0) {
/* 1757 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidFetchSize"), (String)null, false);
/*      */     }
/* 1759 */     this.nFetchSize = (0 == paramInt) ? this.defaultFetchSize : paramInt;
/* 1760 */     loggerExternal.exiting(getClassNameLogging(), "setFetchSize");
/*      */   }
/*      */   
/*      */   public final int getFetchSize() throws SQLServerException {
/* 1764 */     loggerExternal.entering(getClassNameLogging(), "getFetchSize");
/* 1765 */     checkClosed();
/* 1766 */     loggerExternal.exiting(getClassNameLogging(), "getFetchSize", new Integer(this.nFetchSize));
/* 1767 */     return this.nFetchSize;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getResultSetConcurrency() throws SQLServerException {
/* 1772 */     loggerExternal.entering(getClassNameLogging(), "getResultSetConcurrency");
/* 1773 */     checkClosed();
/* 1774 */     loggerExternal.exiting(getClassNameLogging(), "getResultSetConcurrency", new Integer(this.resultSetConcurrency));
/* 1775 */     return this.resultSetConcurrency;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int getResultSetType() throws SQLServerException {
/* 1780 */     loggerExternal.entering(getClassNameLogging(), "getResultSetType");
/* 1781 */     checkClosed();
/* 1782 */     loggerExternal.exiting(getClassNameLogging(), "getResultSetType", new Integer(this.appResultSetType));
/* 1783 */     return this.appResultSetType;
/*      */   }
/*      */ 
/*      */   
/*      */   public void addBatch(String paramString) throws SQLServerException {
/* 1788 */     loggerExternal.entering(getClassNameLogging(), "addBatch", paramString);
/* 1789 */     checkClosed();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1794 */     paramString = ensureSQLSyntax(paramString);
/*      */     
/* 1796 */     this.batchStatementBuffer.add(paramString);
/* 1797 */     loggerExternal.exiting(getClassNameLogging(), "addBatch");
/*      */   }
/*      */ 
/*      */   
/*      */   public void clearBatch() throws SQLServerException {
/* 1802 */     loggerExternal.entering(getClassNameLogging(), "clearBatch");
/* 1803 */     checkClosed();
/* 1804 */     this.batchStatementBuffer.clear();
/* 1805 */     loggerExternal.exiting(getClassNameLogging(), "clearBatch");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] executeBatch() throws SQLServerException, BatchUpdateException {
/* 1813 */     loggerExternal.entering(getClassNameLogging(), "executeBatch");
/* 1814 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 1816 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1818 */     checkClosed();
/* 1819 */     discardLastExecutionResults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1826 */       int i = this.batchStatementBuffer.size();
/* 1827 */       int[] arrayOfInt = new int[i];
/* 1828 */       for (byte b1 = 0; b1 < i; b1++) {
/* 1829 */         arrayOfInt[b1] = -3;
/*      */       }
/*      */ 
/*      */       
/* 1833 */       SQLServerException sQLServerException = null;
/*      */       
/* 1835 */       for (byte b2 = 0; b2 < i; b2++) {
/*      */ 
/*      */         
/*      */         try {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1843 */           if (0 == b2) {
/*      */ 
/*      */             
/* 1846 */             executeStatement(new StmtBatchExecCmd(this));
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 1853 */             startResults();
/* 1854 */             if (!getNextResult()) {
/*      */               break;
/*      */             }
/*      */           } 
/* 1858 */           if (null != this.resultSet)
/*      */           {
/* 1860 */             SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, true);
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */             
/* 1869 */             arrayOfInt[b2] = (-1 != (int)this.updateCount) ? (int)this.updateCount : -2;
/*      */           }
/*      */         
/* 1872 */         } catch (SQLServerException sQLServerException1) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1877 */           if (this.connection.isSessionUnAvailable() || this.connection.rolledBackTransaction()) {
/* 1878 */             throw sQLServerException1;
/*      */           }
/*      */ 
/*      */           
/* 1882 */           sQLServerException = sQLServerException1;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1887 */       if (null != sQLServerException)
/*      */       {
/* 1889 */         throw new BatchUpdateException(sQLServerException.getMessage(), sQLServerException.getSQLState(), sQLServerException.getErrorCode(), arrayOfInt);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1895 */       loggerExternal.exiting(getClassNameLogging(), "executeBatch", arrayOfInt);
/* 1896 */       return arrayOfInt;
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */       
/* 1904 */       this.batchStatementBuffer.clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public long[] executeLargeBatch() throws SQLServerException, BatchUpdateException {
/* 1910 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 1912 */     loggerExternal.entering(getClassNameLogging(), "executeLargeBatch");
/* 1913 */     if (loggerExternal.isLoggable(Level.FINER) && Util.IsActivityTraceOn())
/*      */     {
/* 1915 */       loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */     }
/* 1917 */     checkClosed();
/* 1918 */     discardLastExecutionResults();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1925 */       int i = this.batchStatementBuffer.size();
/* 1926 */       long[] arrayOfLong = new long[i];
/* 1927 */       for (byte b1 = 0; b1 < i; b1++) {
/* 1928 */         arrayOfLong[b1] = -3L;
/*      */       }
/*      */ 
/*      */       
/* 1932 */       SQLServerException sQLServerException = null;
/*      */       
/* 1934 */       for (byte b2 = 0; b2 < i; b2++) {
/*      */ 
/*      */         
/*      */         try {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1942 */           if (0 == b2) {
/*      */ 
/*      */             
/* 1945 */             executeStatement(new StmtBatchExecCmd(this));
/*      */ 
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 1952 */             startResults();
/* 1953 */             if (!getNextResult()) {
/*      */               break;
/*      */             }
/*      */           } 
/* 1957 */           if (null != this.resultSet)
/*      */           {
/* 1959 */             SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_resultsetGeneratedForUpdate"), (String)null, true);
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */           else
/*      */           {
/*      */ 
/*      */             
/* 1968 */             arrayOfLong[b2] = (-1L != this.updateCount) ? this.updateCount : -2L;
/*      */           }
/*      */         
/* 1971 */         } catch (SQLServerException sQLServerException1) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1976 */           if (this.connection.isSessionUnAvailable() || this.connection.rolledBackTransaction()) {
/* 1977 */             throw sQLServerException1;
/*      */           }
/*      */ 
/*      */           
/* 1981 */           sQLServerException = sQLServerException1;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1986 */       if (null != sQLServerException)
/*      */       {
/* 1988 */         DriverJDBCVersion.throwBatchUpdateException(sQLServerException, arrayOfLong);
/*      */       }
/* 1990 */       loggerExternal.exiting(getClassNameLogging(), "executeLargeBatch", arrayOfLong);
/* 1991 */       return arrayOfLong;
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */ 
/*      */       
/* 1999 */       this.batchStatementBuffer.clear();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final Connection getConnection() throws SQLServerException {
/* 2010 */     loggerExternal.entering(getClassNameLogging(), "getConnection");
/* 2011 */     if (this.bIsClosed)
/*      */     {
/* 2013 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_statementIsClosed"), (String)null, false);
/*      */     }
/* 2015 */     Connection connection = this.connection.getConnection();
/* 2016 */     loggerExternal.exiting(getClassNameLogging(), "getConnection", connection);
/* 2017 */     return connection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final int getResultSetScrollOpt() {
/* 2031 */     boolean bool = (null == this.inOutParam) ? false : true;
/*      */     
/* 2033 */     switch (this.resultSetType) {
/*      */       
/*      */       case 2004:
/* 2036 */         return bool | ((1007 == this.resultSetConcurrency) ? 16 : 4);
/*      */ 
/*      */ 
/*      */       
/*      */       case 1006:
/* 2041 */         return bool | 0x2;
/*      */       
/*      */       case 1005:
/* 2044 */         return bool | true;
/*      */       
/*      */       case 1004:
/* 2047 */         return bool | 0x8;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2052 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   final int getResultSetCCOpt() {
/* 2057 */     switch (this.resultSetConcurrency) {
/*      */       
/*      */       case 1007:
/* 2060 */         return 8193;
/*      */ 
/*      */       
/*      */       case 1008:
/* 2064 */         return 24580;
/*      */       
/*      */       case 1009:
/* 2067 */         return 24578;
/*      */       
/*      */       case 1010:
/* 2070 */         return 24584;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2075 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   private final void doExecuteCursored(StmtExecCmd paramStmtExecCmd, String paramString) throws SQLServerException {
/* 2080 */     if (stmtlogger.isLoggable(Level.FINER))
/*      */     {
/* 2082 */       stmtlogger.finer(toString() + " Execute for cursor open" + " SQL:" + paramString + " Scrollability:" + getResultSetScrollOpt() + " Concurrency:" + getResultSetCCOpt());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2089 */     this.executedSqlDirectly = false;
/* 2090 */     this.expectCursorOutParams = true;
/* 2091 */     TDSWriter tDSWriter = paramStmtExecCmd.startRequest((byte)3);
/* 2092 */     tDSWriter.writeShort((short)-1);
/* 2093 */     tDSWriter.writeShort((short)2);
/* 2094 */     tDSWriter.writeByte((byte)0);
/* 2095 */     tDSWriter.writeByte((byte)0);
/*      */ 
/*      */     
/* 2098 */     tDSWriter.writeRPCInt(null, new Integer(0), true);
/*      */ 
/*      */     
/* 2101 */     tDSWriter.writeRPCStringUnicode(paramString);
/*      */ 
/*      */     
/* 2104 */     tDSWriter.writeRPCInt(null, new Integer(getResultSetScrollOpt()), false);
/*      */ 
/*      */     
/* 2107 */     tDSWriter.writeRPCInt(null, new Integer(getResultSetCCOpt()), false);
/*      */ 
/*      */     
/* 2110 */     tDSWriter.writeRPCInt(null, new Integer(0), true);
/*      */     
/* 2112 */     ensureExecuteResultsReader(paramStmtExecCmd.startResponse(this.isResponseBufferingAdaptive));
/* 2113 */     startResults();
/* 2114 */     getNextResult();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final int getResultSetHoldability() throws SQLException {
/* 2121 */     loggerExternal.entering(getClassNameLogging(), "getResultSetHoldability");
/* 2122 */     checkClosed();
/* 2123 */     int i = this.connection.getHoldability();
/* 2124 */     loggerExternal.exiting(getClassNameLogging(), "getResultSetHoldability", new Integer(i));
/* 2125 */     return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean execute(String paramString, int paramInt) throws SQLServerException {
/* 2130 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*      */       
/* 2132 */       loggerExternal.entering(getClassNameLogging(), "execute", new Object[] { paramString, new Integer(paramInt) });
/* 2133 */       if (Util.IsActivityTraceOn())
/*      */       {
/* 2135 */         loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */       }
/*      */     } 
/* 2138 */     checkClosed();
/* 2139 */     if (paramInt != 1 && paramInt != 2) {
/*      */ 
/*      */       
/* 2142 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidAutoGeneratedKeys"));
/* 2143 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 2144 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2152 */     executeStatement(new StmtExecCmd(this, paramString, 3, paramInt));
/* 2153 */     loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf((null != this.resultSet)));
/* 2154 */     return (null != this.resultSet);
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean execute(String paramString, int[] paramArrayOfint) throws SQLServerException {
/* 2159 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2160 */       loggerExternal.entering(getClassNameLogging(), "execute", new Object[] { paramString, paramArrayOfint }); 
/* 2161 */     checkClosed();
/* 2162 */     if (paramArrayOfint == null || paramArrayOfint.length != 1)
/*      */     {
/* 2164 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2171 */     boolean bool = execute(paramString, 1);
/* 2172 */     loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf(bool));
/* 2173 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean execute(String paramString, String[] paramArrayOfString) throws SQLServerException {
/* 2178 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2179 */       loggerExternal.entering(getClassNameLogging(), "execute", new Object[] { paramString, paramArrayOfString }); 
/* 2180 */     checkClosed();
/* 2181 */     if (paramArrayOfString == null || paramArrayOfString.length != 1)
/*      */     {
/* 2183 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2190 */     boolean bool = execute(paramString, 1);
/* 2191 */     loggerExternal.exiting(getClassNameLogging(), "execute", Boolean.valueOf(bool));
/* 2192 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int executeUpdate(String paramString, int paramInt) throws SQLServerException {
/* 2197 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*      */       
/* 2199 */       loggerExternal.entering(getClassNameLogging(), "executeUpdate", new Object[] { paramString, new Integer(paramInt) });
/* 2200 */       if (Util.IsActivityTraceOn())
/*      */       {
/* 2202 */         loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */       }
/*      */     } 
/* 2205 */     checkClosed();
/* 2206 */     if (paramInt != 1 && paramInt != 2) {
/*      */ 
/*      */       
/* 2209 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidAutoGeneratedKeys"));
/* 2210 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 2211 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2218 */     executeStatement(new StmtExecCmd(this, paramString, 2, paramInt));
/*      */ 
/*      */     
/* 2221 */     if (this.updateCount < -2147483648L || this.updateCount > 2147483647L) {
/* 2222 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_updateCountOutofRange"), (String)null, true);
/*      */     }
/* 2224 */     loggerExternal.exiting(getClassNameLogging(), "executeUpdate", new Long(this.updateCount));
/*      */     
/* 2226 */     return (int)this.updateCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public final long executeLargeUpdate(String paramString, int paramInt) throws SQLServerException {
/* 2231 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 2233 */     if (loggerExternal.isLoggable(Level.FINER)) {
/*      */       
/* 2235 */       loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", new Object[] { paramString, new Integer(paramInt) });
/* 2236 */       if (Util.IsActivityTraceOn())
/*      */       {
/* 2238 */         loggerExternal.finer(toString() + " ActivityId: " + ActivityCorrelator.getNext().toString());
/*      */       }
/*      */     } 
/* 2241 */     checkClosed();
/* 2242 */     if (paramInt != 1 && paramInt != 2) {
/*      */ 
/*      */       
/* 2245 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidAutoGeneratedKeys"));
/* 2246 */       Object[] arrayOfObject = { new Integer(paramInt) };
/* 2247 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2254 */     executeStatement(new StmtExecCmd(this, paramString, 2, paramInt));
/* 2255 */     loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", new Long(this.updateCount));
/* 2256 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int executeUpdate(String paramString, int[] paramArrayOfint) throws SQLServerException {
/* 2261 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2262 */       loggerExternal.entering(getClassNameLogging(), "executeUpdate", new Object[] { paramString, paramArrayOfint }); 
/* 2263 */     checkClosed();
/* 2264 */     if (paramArrayOfint == null || paramArrayOfint.length != 1)
/*      */     {
/* 2266 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2273 */     int i = executeUpdate(paramString, 1);
/* 2274 */     loggerExternal.exiting(getClassNameLogging(), "executeUpdate", new Integer(i));
/* 2275 */     return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public final long executeLargeUpdate(String paramString, int[] paramArrayOfint) throws SQLServerException {
/* 2280 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 2282 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2283 */       loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", new Object[] { paramString, paramArrayOfint }); 
/* 2284 */     checkClosed();
/* 2285 */     if (paramArrayOfint == null || paramArrayOfint.length != 1)
/*      */     {
/* 2287 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2294 */     long l = executeLargeUpdate(paramString, 1);
/* 2295 */     loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", new Long(l));
/* 2296 */     return l;
/*      */   }
/*      */ 
/*      */   
/*      */   public final int executeUpdate(String paramString, String[] paramArrayOfString) throws SQLServerException {
/* 2301 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2302 */       loggerExternal.entering(getClassNameLogging(), "executeUpdate", new Object[] { paramString, paramArrayOfString }); 
/* 2303 */     checkClosed();
/* 2304 */     if (paramArrayOfString == null || paramArrayOfString.length != 1)
/*      */     {
/* 2306 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2313 */     int i = executeUpdate(paramString, 1);
/* 2314 */     loggerExternal.exiting(getClassNameLogging(), "executeUpdate", new Integer(i));
/* 2315 */     return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public final long executeLargeUpdate(String paramString, String[] paramArrayOfString) throws SQLServerException {
/* 2320 */     DriverJDBCVersion.checkSupportsJDBC42();
/*      */     
/* 2322 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2323 */       loggerExternal.entering(getClassNameLogging(), "executeLargeUpdate", new Object[] { paramString, paramArrayOfString }); 
/* 2324 */     checkClosed();
/* 2325 */     if (paramArrayOfString == null || paramArrayOfString.length != 1)
/*      */     {
/* 2327 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_invalidColumnArrayLength"), (String)null, false);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2334 */     long l = executeLargeUpdate(paramString, 1);
/* 2335 */     loggerExternal.exiting(getClassNameLogging(), "executeLargeUpdate", new Long(l));
/* 2336 */     return l;
/*      */   }
/*      */ 
/*      */   
/*      */   public final ResultSet getGeneratedKeys() throws SQLServerException {
/* 2341 */     loggerExternal.entering(getClassNameLogging(), "getGeneratedKeys");
/* 2342 */     checkClosed();
/*      */     
/* 2344 */     if (null == this.autoGeneratedKeys) {
/*      */       
/* 2346 */       long l = this.updateCount;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2351 */       if (!getNextResult() || null == this.resultSet)
/*      */       {
/* 2353 */         SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_statementMustBeExecuted"), (String)null, false);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2361 */       this.autoGeneratedKeys = this.resultSet;
/* 2362 */       this.updateCount = l;
/*      */     } 
/* 2364 */     loggerExternal.exiting(getClassNameLogging(), "getGeneratedKeys", this.autoGeneratedKeys);
/* 2365 */     return this.autoGeneratedKeys;
/*      */   }
/*      */ 
/*      */   
/*      */   public final boolean getMoreResults(int paramInt) throws SQLServerException {
/* 2370 */     if (loggerExternal.isLoggable(Level.FINER))
/* 2371 */       loggerExternal.entering(getClassNameLogging(), "getMoreResults", new Integer(paramInt)); 
/* 2372 */     checkClosed();
/* 2373 */     if (2 == paramInt) {
/* 2374 */       NotImplemented();
/*      */     }
/* 2376 */     if (1 != paramInt && 3 != paramInt) {
/* 2377 */       SQLServerException.makeFromDriverError(this.connection, this, SQLServerException.getErrString("R_modeSuppliedNotValid"), (String)null, true);
/*      */     }
/*      */     
/* 2380 */     SQLServerResultSet sQLServerResultSet = this.resultSet;
/* 2381 */     boolean bool = getMoreResults();
/* 2382 */     if (sQLServerResultSet != null) {
/*      */       
/*      */       try {
/*      */         
/* 2386 */         sQLServerResultSet.close();
/*      */       }
/* 2388 */       catch (SQLException sQLException) {
/*      */         
/* 2390 */         throw new SQLServerException(null, sQLException.getMessage(), null, 0, false);
/*      */       } 
/*      */     }
/*      */     
/* 2394 */     loggerExternal.exiting(getClassNameLogging(), "getMoreResults", Boolean.valueOf(bool));
/* 2395 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isClosed() throws SQLException {
/* 2400 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */     
/* 2402 */     loggerExternal.entering(getClassNameLogging(), "isClosed");
/* 2403 */     boolean bool = (this.bIsClosed || this.connection.isSessionUnAvailable()) ? true : false;
/* 2404 */     loggerExternal.exiting(getClassNameLogging(), "isClosed", Boolean.valueOf(bool));
/* 2405 */     return bool;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isCloseOnCompletion() throws SQLException {
/* 2410 */     DriverJDBCVersion.checkSupportsJDBC41();
/*      */     
/* 2412 */     loggerExternal.entering(getClassNameLogging(), "isCloseOnCompletion");
/* 2413 */     checkClosed();
/* 2414 */     loggerExternal.exiting(getClassNameLogging(), "isCloseOnCompletion", Boolean.valueOf(this.isCloseOnCompletion));
/* 2415 */     return this.isCloseOnCompletion;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isPoolable() throws SQLException {
/* 2420 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2421 */     loggerExternal.entering(getClassNameLogging(), "isPoolable");
/* 2422 */     checkClosed();
/* 2423 */     loggerExternal.exiting(getClassNameLogging(), "isPoolable", Boolean.valueOf(this.stmtPoolable));
/* 2424 */     return this.stmtPoolable;
/*      */   }
/*      */ 
/*      */   
/*      */   public void setPoolable(boolean paramBoolean) throws SQLException {
/* 2429 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2430 */     loggerExternal.entering(getClassNameLogging(), "setPoolable", Boolean.valueOf(paramBoolean));
/* 2431 */     checkClosed();
/* 2432 */     this.stmtPoolable = paramBoolean;
/* 2433 */     loggerExternal.exiting(getClassNameLogging(), "setPoolable");
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean isWrapperFor(Class<?> paramClass) throws SQLException {
/* 2438 */     loggerExternal.entering(getClassNameLogging(), "isWrapperFor");
/* 2439 */     DriverJDBCVersion.checkSupportsJDBC4();
/* 2440 */     boolean bool = paramClass.isInstance(this);
/* 2441 */     loggerExternal.exiting(getClassNameLogging(), "isWrapperFor", Boolean.valueOf(bool));
/* 2442 */     return bool;
/*      */   }
/*      */   
/*      */   public <T> T unwrap(Class<T> paramClass) throws SQLException {
/*      */     T t;
/* 2447 */     loggerExternal.entering(getClassNameLogging(), "unwrap");
/* 2448 */     DriverJDBCVersion.checkSupportsJDBC4();
/*      */ 
/*      */     
/*      */     try {
/* 2452 */       t = paramClass.cast(this);
/*      */     }
/* 2454 */     catch (ClassCastException classCastException) {
/*      */       
/* 2456 */       throw new SQLServerException(classCastException.getMessage(), classCastException);
/*      */     } 
/* 2458 */     loggerExternal.exiting(getClassNameLogging(), "unwrap", t);
/* 2459 */     return t;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setResponseBuffering(String paramString) throws SQLServerException {
/* 2483 */     loggerExternal.entering(getClassNameLogging(), "setResponseBuffering", paramString);
/* 2484 */     checkClosed();
/* 2485 */     if (paramString.equalsIgnoreCase("full")) {
/*      */       
/* 2487 */       this.isResponseBufferingAdaptive = false;
/* 2488 */       this.wasResponseBufferingSet = true;
/*      */     }
/* 2490 */     else if (paramString.equalsIgnoreCase("adaptive")) {
/*      */       
/* 2492 */       this.isResponseBufferingAdaptive = true;
/* 2493 */       this.wasResponseBufferingSet = true;
/*      */     }
/*      */     else {
/*      */       
/* 2497 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_invalidresponseBuffering"));
/* 2498 */       Object[] arrayOfObject = { new String(paramString) };
/* 2499 */       SQLServerException.makeFromDriverError(this.connection, this, messageFormat.format(arrayOfObject), (String)null, false);
/*      */     } 
/* 2501 */     loggerExternal.exiting(getClassNameLogging(), "setResponseBuffering");
/*      */   }
/*      */   
/*      */   public final String getResponseBuffering() throws SQLServerException {
/*      */     String str;
/* 2506 */     loggerExternal.entering(getClassNameLogging(), "getResponseBuffering");
/* 2507 */     checkClosed();
/*      */     
/* 2509 */     if (this.wasResponseBufferingSet) {
/*      */       
/* 2511 */       if (this.isResponseBufferingAdaptive) {
/* 2512 */         str = "adaptive";
/*      */       } else {
/* 2514 */         str = "full";
/*      */       } 
/*      */     } else {
/*      */       
/* 2518 */       str = this.connection.getResponseBuffering();
/*      */     } 
/* 2520 */     loggerExternal.exiting(getClassNameLogging(), "getResponseBuffering", str);
/* 2521 */     return str;
/*      */   }
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerStatement.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */