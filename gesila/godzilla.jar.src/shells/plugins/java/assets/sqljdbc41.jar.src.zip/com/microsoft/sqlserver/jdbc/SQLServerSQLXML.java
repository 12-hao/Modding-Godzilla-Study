/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.SQLException;
/*     */ import java.text.MessageFormat;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.stream.XMLInputFactory;
/*     */ import javax.xml.stream.XMLOutputFactory;
/*     */ import javax.xml.stream.XMLStreamException;
/*     */ import javax.xml.stream.XMLStreamWriter;
/*     */ import javax.xml.transform.Result;
/*     */ import javax.xml.transform.Source;
/*     */ import javax.xml.transform.TransformerException;
/*     */ import javax.xml.transform.TransformerFactory;
/*     */ import javax.xml.transform.dom.DOMResult;
/*     */ import javax.xml.transform.dom.DOMSource;
/*     */ import javax.xml.transform.sax.SAXResult;
/*     */ import javax.xml.transform.sax.SAXSource;
/*     */ import javax.xml.transform.sax.SAXTransformerFactory;
/*     */ import javax.xml.transform.sax.TransformerHandler;
/*     */ import javax.xml.transform.stax.StAXResult;
/*     */ import javax.xml.transform.stax.StAXSource;
/*     */ import javax.xml.transform.stream.StreamResult;
/*     */ import javax.xml.transform.stream.StreamSource;
/*     */ import org.w3c.dom.Document;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ 
/*     */ final class SQLServerSQLXML implements SQLXML {
/*  38 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.SQLServerSQLXML");
/*     */   private final SQLServerConnection con;
/*     */   private final PLPXMLInputStream contents;
/*     */   private final InputStreamGetterArgs getterArgs;
/*     */   private final TypeInfo typeInfo;
/*     */   private boolean isUsed = false;
/*     */   private boolean isFreed = false;
/*     */   private ByteArrayOutputStreamToInputStream outputStreamValue;
/*     */   private Document docValue;
/*     */   private String strValue;
/*  48 */   private static int baseID = 0;
/*     */   private final String traceID;
/*     */   
/*     */   public final String toString() {
/*  52 */     return this.traceID;
/*     */   }
/*     */ 
/*     */   
/*     */   private static synchronized int nextInstanceID() {
/*  57 */     baseID++;
/*  58 */     return baseID;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   InputStream getValue() throws SQLServerException {
/*  66 */     checkClosed();
/*     */ 
/*     */     
/*  69 */     if (!this.isUsed)
/*  70 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_noDataXML"), null, true); 
/*  71 */     assert null == this.contents;
/*  72 */     ByteArrayInputStream byteArrayInputStream = null;
/*  73 */     if (null != this.outputStreamValue) {
/*     */       
/*  75 */       byteArrayInputStream = this.outputStreamValue.getInputStream();
/*  76 */       assert null == this.docValue;
/*  77 */       assert null == this.strValue;
/*     */     
/*     */     }
/*  80 */     else if (null != this.docValue) {
/*     */       
/*  82 */       assert null == this.outputStreamValue;
/*  83 */       assert null == this.strValue;
/*  84 */       ByteArrayOutputStreamToInputStream byteArrayOutputStreamToInputStream = new ByteArrayOutputStreamToInputStream();
/*     */ 
/*     */       
/*  87 */       Object object = null;
/*     */       
/*     */       try {
/*  90 */         TransformerFactory transformerFactory = TransformerFactory.newInstance();
/*  91 */         transformerFactory.newTransformer().transform(new DOMSource(this.docValue), new StreamResult(byteArrayOutputStreamToInputStream));
/*     */       }
/*  93 */       catch (TransformerException transformerException) {
/*     */         
/*  95 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/*  96 */         Object[] arrayOfObject = { transformerException.toString() };
/*  97 */         SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */       } 
/*  99 */       byteArrayInputStream = byteArrayOutputStreamToInputStream.getInputStream();
/*     */     }
/*     */     else {
/*     */       
/* 103 */       assert null == this.outputStreamValue;
/* 104 */       assert null == this.docValue;
/* 105 */       assert null != this.strValue;
/*     */       
/*     */       try {
/* 108 */         byteArrayInputStream = new ByteArrayInputStream(this.strValue.getBytes(Encoding.UNICODE.charsetName()));
/*     */       }
/* 110 */       catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */         
/* 112 */         throw new SQLServerException(null, unsupportedEncodingException.getMessage(), null, 0, true);
/*     */       } 
/*     */     } 
/* 115 */     assert null != byteArrayInputStream;
/* 116 */     this.isFreed = true;
/* 117 */     return byteArrayInputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   SQLServerSQLXML(SQLServerConnection paramSQLServerConnection) {
/* 123 */     this.contents = null;
/* 124 */     this.traceID = " SQLServerSQLXML:" + nextInstanceID();
/* 125 */     this.con = paramSQLServerConnection;
/*     */     
/* 127 */     if (logger.isLoggable(Level.FINE))
/* 128 */       logger.fine(toString() + " created by (" + paramSQLServerConnection.toString() + ")"); 
/* 129 */     this.getterArgs = null;
/* 130 */     this.typeInfo = null;
/*     */   }
/*     */ 
/*     */   
/*     */   SQLServerSQLXML(InputStream paramInputStream, InputStreamGetterArgs paramInputStreamGetterArgs, TypeInfo paramTypeInfo) throws SQLServerException {
/* 135 */     this.traceID = " SQLServerSQLXML:" + nextInstanceID();
/* 136 */     this.contents = (PLPXMLInputStream)paramInputStream;
/* 137 */     this.con = null;
/* 138 */     this.getterArgs = paramInputStreamGetterArgs;
/* 139 */     this.typeInfo = paramTypeInfo;
/* 140 */     if (logger.isLoggable(Level.FINE))
/* 141 */       logger.fine(toString() + " created by (null connection)"); 
/*     */   }
/*     */   
/*     */   InputStream getStream() {
/* 145 */     return this.contents;
/*     */   }
/*     */   
/*     */   public void free() throws SQLException {
/* 149 */     if (!this.isFreed) {
/*     */       
/* 151 */       this.isFreed = true;
/* 152 */       if (null != this.contents) {
/*     */         
/*     */         try {
/*     */           
/* 156 */           this.contents.close();
/*     */         }
/* 158 */         catch (IOException iOException) {
/*     */           
/* 160 */           SQLServerException.makeFromDriverError(null, null, iOException.getMessage(), null, true);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkClosed() throws SQLServerException {
/* 167 */     if (this.isFreed || (null != this.con && this.con.isClosed())) {
/*     */       
/* 169 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 170 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(new Object[] { "SQLXML" }, ), null, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void checkReadXML() throws SQLException {
/* 175 */     if (null == this.contents)
/* 176 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_writeOnlyXML"), null, true); 
/* 177 */     if (this.isUsed) {
/* 178 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_dataHasBeenReadXML"), null, true);
/*     */     }
/*     */     try {
/* 181 */       this.contents.checkClosed();
/*     */     }
/* 183 */     catch (IOException iOException) {
/*     */       
/* 185 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_isFreed"));
/* 186 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(new Object[] { "SQLXML" }, ), null, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   void checkWriteXML() throws SQLException {
/* 191 */     if (null != this.contents)
/* 192 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_readOnlyXML"), null, true); 
/* 193 */     if (this.isUsed) {
/* 194 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_dataHasBeenSetXML"), null, true);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public InputStream getBinaryStream() throws SQLException {
/* 205 */     checkClosed();
/* 206 */     checkReadXML();
/* 207 */     this.isUsed = true;
/* 208 */     return this.contents;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream setBinaryStream() throws SQLException {
/* 220 */     checkClosed();
/* 221 */     checkWriteXML();
/* 222 */     this.isUsed = true;
/* 223 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 224 */     return this.outputStreamValue;
/*     */   }
/*     */   
/*     */   public Writer setCharacterStream() throws SQLException {
/* 228 */     checkClosed();
/* 229 */     checkWriteXML();
/* 230 */     this.isUsed = true;
/* 231 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 232 */     OutputStreamWriter outputStreamWriter = null;
/*     */     
/*     */     try {
/* 235 */       outputStreamWriter = new OutputStreamWriter(this.outputStreamValue, Encoding.UNICODE.charsetName());
/*     */     }
/* 237 */     catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */       
/* 239 */       throw new SQLServerException(null, unsupportedEncodingException.getMessage(), null, 0, true);
/*     */     } 
/* 241 */     return outputStreamWriter;
/*     */   }
/*     */   
/*     */   public Reader getCharacterStream() throws SQLException {
/* 245 */     checkClosed();
/* 246 */     checkReadXML();
/* 247 */     this.isUsed = true;
/* 248 */     StreamType streamType = StreamType.CHARACTER;
/* 249 */     InputStreamGetterArgs inputStreamGetterArgs = new InputStreamGetterArgs(streamType, this.getterArgs.isAdaptive, this.getterArgs.isStreaming, this.getterArgs.logContext);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 255 */     assert null != this.contents;
/*     */ 
/*     */     
/*     */     try {
/* 259 */       this.contents.read();
/* 260 */       this.contents.read();
/*     */     }
/* 262 */     catch (IOException iOException) {
/*     */       
/* 264 */       SQLServerException.makeFromDriverError(null, null, iOException.getMessage(), null, true);
/*     */     } 
/*     */     
/* 267 */     return (Reader)DDC.convertStreamToObject(this.contents, this.typeInfo, streamType.getJDBCType(), inputStreamGetterArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getString() throws SQLException {
/* 273 */     checkClosed();
/* 274 */     checkReadXML();
/* 275 */     this.isUsed = true;
/* 276 */     assert null != this.contents;
/*     */ 
/*     */     
/*     */     try {
/* 280 */       this.contents.read();
/* 281 */       this.contents.read();
/*     */     }
/* 283 */     catch (IOException iOException) {
/*     */       
/* 285 */       SQLServerException.makeFromDriverError(null, null, iOException.getMessage(), null, true);
/*     */     } 
/*     */     
/* 288 */     byte[] arrayOfByte = this.contents.getBytes();
/* 289 */     String str = null;
/*     */     
/*     */     try {
/* 292 */       str = new String(arrayOfByte, 0, arrayOfByte.length, Encoding.UNICODE.charsetName());
/*     */     }
/* 294 */     catch (UnsupportedEncodingException unsupportedEncodingException) {
/*     */       
/* 296 */       throw new SQLServerException(null, unsupportedEncodingException.getMessage(), null, 0, true);
/*     */     } 
/* 298 */     return str;
/*     */   }
/*     */   
/*     */   public void setString(String paramString) throws SQLException {
/* 302 */     checkClosed();
/* 303 */     checkWriteXML();
/* 304 */     this.isUsed = true;
/* 305 */     if (null == paramString)
/* 306 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_cantSetNull"), null, true); 
/* 307 */     this.strValue = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public <T extends Source> T getSource(Class<T> paramClass) throws SQLException {
/* 314 */     checkClosed();
/* 315 */     checkReadXML();
/* 316 */     if (null == paramClass)
/*     */     {
/*     */ 
/*     */       
/* 320 */       return (T)getSourceInternal((Class)StreamSource.class);
/*     */     }
/*     */ 
/*     */     
/* 324 */     return getSourceInternal(paramClass);
/*     */   }
/*     */   
/*     */   <T extends Source> T getSourceInternal(Class<T> paramClass) throws SQLException {
/* 328 */     this.isUsed = true;
/* 329 */     Source source = null;
/* 330 */     if (DOMSource.class == paramClass) {
/*     */       
/* 332 */       source = (Source)paramClass.cast(getDOMSource());
/*     */     }
/* 334 */     else if (SAXSource.class == paramClass) {
/*     */       
/* 336 */       source = (Source)paramClass.cast(getSAXSource());
/*     */     
/*     */     }
/* 339 */     else if (StAXSource.class == paramClass) {
/*     */       
/* 341 */       source = (Source)paramClass.cast(getStAXSource());
/*     */     
/*     */     }
/* 344 */     else if (StreamSource.class == paramClass) {
/*     */       
/* 346 */       source = (Source)paramClass.cast(new StreamSource(this.contents));
/*     */     }
/*     */     else {
/*     */       
/* 350 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_notSupported"), null, true);
/* 351 */     }  return (T)source;
/*     */   }
/*     */   
/*     */   public <T extends Result> T setResult(Class<T> paramClass) throws SQLException {
/* 355 */     checkClosed();
/* 356 */     checkWriteXML();
/* 357 */     if (null == paramClass)
/*     */     {
/*     */ 
/*     */       
/* 361 */       return (T)setResultInternal((Class)StreamResult.class);
/*     */     }
/*     */ 
/*     */     
/* 365 */     return setResultInternal(paramClass);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   <T extends Result> T setResultInternal(Class<T> paramClass) throws SQLException {
/* 371 */     this.isUsed = true;
/* 372 */     Result result = null;
/* 373 */     if (DOMResult.class == paramClass) {
/*     */       
/* 375 */       result = (Result)paramClass.cast(getDOMResult());
/*     */     
/*     */     }
/* 378 */     else if (SAXResult.class == paramClass) {
/*     */       
/* 380 */       result = (Result)paramClass.cast(getSAXResult());
/*     */     
/*     */     }
/* 383 */     else if (StAXResult.class == paramClass) {
/*     */       
/* 385 */       result = (Result)paramClass.cast(getStAXResult());
/*     */     }
/* 387 */     else if (StreamResult.class == paramClass) {
/*     */       
/* 389 */       this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 390 */       result = (Result)paramClass.cast(new StreamResult(this.outputStreamValue));
/*     */     } else {
/*     */       
/* 393 */       SQLServerException.makeFromDriverError(this.con, null, SQLServerException.getErrString("R_notSupported"), null, true);
/* 394 */     }  return (T)result;
/*     */   }
/*     */ 
/*     */   
/*     */   private final DOMSource getDOMSource() throws SQLException {
/* 399 */     Document document = null;
/* 400 */     DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 410 */       documentBuilderFactory.setFeature("http://javax.xml.XMLConstants/feature/secure-processing", true);
/* 411 */       DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
/*     */ 
/*     */       
/* 414 */       documentBuilder.setEntityResolver(new SQLServerEntityResolver());
/*     */       
/*     */       try {
/* 417 */         document = documentBuilder.parse(this.contents);
/*     */       }
/* 419 */       catch (IOException iOException) {
/*     */         
/* 421 */         MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_errorReadingStream"));
/* 422 */         Object[] arrayOfObject = { iOException.toString() };
/* 423 */         SQLServerException.makeFromDriverError(null, null, messageFormat.format(arrayOfObject), "", true);
/*     */       } 
/* 425 */       return new DOMSource(document);
/*     */     
/*     */     }
/* 428 */     catch (ParserConfigurationException parserConfigurationException) {
/*     */       
/* 430 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 431 */       Object[] arrayOfObject = { parserConfigurationException.toString() };
/* 432 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     }
/* 434 */     catch (SAXException sAXException) {
/*     */       
/* 436 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToParseXML"));
/* 437 */       Object[] arrayOfObject = { sAXException.toString() };
/* 438 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     } 
/* 440 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   private final SAXSource getSAXSource() throws SQLException {
/*     */     try {
/* 446 */       InputSource inputSource = new InputSource(this.contents);
/* 447 */       XMLReader xMLReader = XMLReaderFactory.createXMLReader();
/* 448 */       return new SAXSource(xMLReader, inputSource);
/*     */ 
/*     */     
/*     */     }
/* 452 */     catch (SAXException sAXException) {
/*     */       
/* 454 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_failedToParseXML"));
/* 455 */       Object[] arrayOfObject = { sAXException.toString() };
/* 456 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */       
/* 458 */       return null;
/*     */     } 
/*     */   }
/*     */   private final StAXSource getStAXSource() throws SQLException {
/* 462 */     XMLInputFactory xMLInputFactory = XMLInputFactory.newInstance();
/*     */     
/*     */     try {
/* 465 */       XMLStreamReader xMLStreamReader = xMLInputFactory.createXMLStreamReader(this.contents);
/* 466 */       return new StAXSource(xMLStreamReader);
/*     */     
/*     */     }
/* 469 */     catch (XMLStreamException xMLStreamException) {
/*     */       
/* 471 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 472 */       Object[] arrayOfObject = { xMLStreamException.toString() };
/* 473 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */       
/* 475 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private final StAXResult getStAXResult() throws SQLException {
/* 480 */     XMLOutputFactory xMLOutputFactory = XMLOutputFactory.newInstance();
/* 481 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/*     */     
/*     */     try {
/* 484 */       XMLStreamWriter xMLStreamWriter = xMLOutputFactory.createXMLStreamWriter(this.outputStreamValue);
/* 485 */       return new StAXResult(xMLStreamWriter);
/*     */     
/*     */     }
/* 488 */     catch (XMLStreamException xMLStreamException) {
/*     */       
/* 490 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 491 */       Object[] arrayOfObject = { xMLStreamException.toString() };
/* 492 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */       
/* 494 */       return null;
/*     */     } 
/*     */   }
/*     */   private final SAXResult getSAXResult() throws SQLException {
/* 498 */     TransformerHandler transformerHandler = null;
/*     */     
/*     */     try {
/* 501 */       SAXTransformerFactory sAXTransformerFactory = (SAXTransformerFactory)TransformerFactory.newInstance();
/*     */       
/* 503 */       transformerHandler = sAXTransformerFactory.newTransformerHandler();
/*     */     }
/* 505 */     catch (TransformerConfigurationException transformerConfigurationException) {
/*     */       
/* 507 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 508 */       Object[] arrayOfObject = { transformerConfigurationException.toString() };
/* 509 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     }
/* 511 */     catch (ClassCastException classCastException) {
/*     */       
/* 513 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 514 */       Object[] arrayOfObject = { classCastException.toString() };
/* 515 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */     } 
/* 517 */     this.outputStreamValue = new ByteArrayOutputStreamToInputStream();
/* 518 */     transformerHandler.setResult(new StreamResult(this.outputStreamValue));
/* 519 */     return new SAXResult(transformerHandler);
/*     */   }
/*     */ 
/*     */   
/*     */   private final DOMResult getDOMResult() throws SQLException {
/* 524 */     DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
/*     */     
/* 526 */     assert null == this.outputStreamValue;
/*     */     
/*     */     try {
/* 529 */       DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
/* 530 */       this.docValue = documentBuilder.newDocument();
/* 531 */       return new DOMResult(this.docValue);
/*     */     
/*     */     }
/* 534 */     catch (ParserConfigurationException parserConfigurationException) {
/*     */       
/* 536 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_noParserSupport"));
/* 537 */       Object[] arrayOfObject = { parserConfigurationException.toString() };
/* 538 */       SQLServerException.makeFromDriverError(this.con, null, messageFormat.format(arrayOfObject), null, true);
/*     */       
/* 540 */       return null;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerSQLXML.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */