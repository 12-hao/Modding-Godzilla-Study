/*      */ package com.microsoft.sqlserver.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileNotFoundException;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.net.InetAddress;
/*      */ import java.net.Socket;
/*      */ import java.net.SocketAddress;
/*      */ import java.net.SocketException;
/*      */ import java.nio.channels.SocketChannel;
/*      */ import java.security.KeyStore;
/*      */ import java.security.Provider;
/*      */ import java.security.Security;
/*      */ import java.security.cert.CertificateException;
/*      */ import java.security.cert.X509Certificate;
/*      */ import java.text.MessageFormat;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import javax.net.ssl.SSLContext;
/*      */ import javax.net.ssl.SSLSocket;
/*      */ import javax.net.ssl.TrustManager;
/*      */ import javax.net.ssl.TrustManagerFactory;
/*      */ import javax.net.ssl.X509TrustManager;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ final class TDSChannel
/*      */ {
/*  466 */   private static final Logger logger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.Channel"); private final String traceID; private final SQLServerConnection con; private final TDSWriter tdsWriter; private Socket tcpSocket; private SSLSocket sslSocket; private Socket channelSocket; final Logger getLogger() {
/*  467 */     return logger;
/*      */   } public final String toString() {
/*  469 */     return this.traceID;
/*      */   }
/*      */   
/*      */   final TDSWriter getWriter()
/*      */   {
/*  474 */     return this.tdsWriter; } final TDSReader getReader(TDSCommand paramTDSCommand) {
/*  475 */     return new TDSReader(this, this.con, paramTDSCommand);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  492 */   ProxySocket proxySocket = null;
/*      */ 
/*      */   
/*      */   private InputStream tcpInputStream;
/*      */ 
/*      */   
/*      */   private OutputStream tcpOutputStream;
/*      */ 
/*      */   
/*      */   private InputStream inputStream;
/*      */ 
/*      */   
/*      */   private OutputStream outputStream;
/*      */   
/*  506 */   private static Logger packetLogger = Logger.getLogger("com.microsoft.sqlserver.jdbc.internals.TDS.DATA");
/*  507 */   private final boolean isLoggingPackets = packetLogger.isLoggable(Level.FINEST); final boolean isLoggingPackets() {
/*  508 */     return this.isLoggingPackets;
/*      */   }
/*      */   
/*  511 */   int numMsgsSent = 0;
/*  512 */   int numMsgsRcvd = 0;
/*      */ 
/*      */ 
/*      */   
/*  516 */   private int spid = 0;
/*  517 */   void setSPID(int paramInt) { this.spid = paramInt; }
/*  518 */   int getSPID() { return this.spid; } void resetPooledConnection() {
/*  519 */     this.tdsWriter.resetPooledConnection();
/*      */   }
/*      */   
/*      */   TDSChannel(SQLServerConnection paramSQLServerConnection) {
/*  523 */     this.con = paramSQLServerConnection;
/*  524 */     this.traceID = "TDSChannel (" + paramSQLServerConnection.toString() + ")";
/*  525 */     this.tcpSocket = null;
/*  526 */     this.sslSocket = null;
/*  527 */     this.channelSocket = null;
/*  528 */     this.tcpInputStream = null;
/*  529 */     this.tcpOutputStream = null;
/*  530 */     this.inputStream = null;
/*  531 */     this.outputStream = null;
/*  532 */     this.tdsWriter = new TDSWriter(this, paramSQLServerConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void open(String paramString, int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, int paramInt3) throws SQLServerException {
/*  547 */     if (logger.isLoggable(Level.FINER)) {
/*  548 */       logger.finer(toString() + ": Opening TCP socket...");
/*      */     }
/*  550 */     SocketFinder socketFinder = new SocketFinder(this.traceID, this.con);
/*  551 */     this.channelSocket = this.tcpSocket = socketFinder.findSocket(paramString, paramInt1, paramInt2, paramBoolean1, paramBoolean2, paramBoolean3, paramInt3);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  557 */       this.tcpSocket.setTcpNoDelay(true);
/*  558 */       this.tcpSocket.setKeepAlive(true);
/*      */       
/*  560 */       this.inputStream = this.tcpInputStream = this.tcpSocket.getInputStream();
/*  561 */       this.outputStream = this.tcpOutputStream = this.tcpSocket.getOutputStream();
/*      */     }
/*  563 */     catch (IOException iOException) {
/*      */       
/*  565 */       SQLServerException.ConvertConnectExceptionToSQLServerException(paramString, paramInt1, this.con, iOException);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void disableSSL() {
/*  574 */     if (logger.isLoggable(Level.FINER)) {
/*  575 */       logger.finer(toString() + " Disabling SSL...");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  594 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(new byte[0]);
/*      */     
/*      */     try {
/*  597 */       byteArrayInputStream.close();
/*      */     }
/*  599 */     catch (IOException iOException) {
/*      */ 
/*      */ 
/*      */       
/*  603 */       logger.fine("Ignored error closing InputStream: " + iOException.getMessage());
/*      */     } 
/*      */     
/*  606 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/*      */     
/*      */     try {
/*  609 */       byteArrayOutputStream.close();
/*      */     }
/*  611 */     catch (IOException iOException) {
/*      */ 
/*      */ 
/*      */       
/*  615 */       logger.fine("Ignored error closing OutputStream: " + iOException.getMessage());
/*      */     } 
/*      */ 
/*      */     
/*  619 */     if (logger.isLoggable(Level.FINEST))
/*  620 */       logger.finest(toString() + " Rewiring proxy streams for SSL socket close"); 
/*  621 */     this.proxySocket.setStreams(byteArrayInputStream, byteArrayOutputStream);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  627 */       if (logger.isLoggable(Level.FINER)) {
/*  628 */         logger.finer(toString() + " Closing SSL socket");
/*      */       }
/*  630 */       this.sslSocket.close();
/*      */     }
/*  632 */     catch (IOException iOException) {
/*      */ 
/*      */       
/*  635 */       logger.fine("Ignored error closing SSLSocket: " + iOException.getMessage());
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  641 */     this.proxySocket = null;
/*      */ 
/*      */ 
/*      */     
/*  645 */     this.inputStream = this.tcpInputStream;
/*  646 */     this.outputStream = this.tcpOutputStream;
/*  647 */     this.channelSocket = this.tcpSocket;
/*  648 */     this.sslSocket = null;
/*      */     
/*  650 */     if (logger.isLoggable(Level.FINER)) {
/*  651 */       logger.finer(toString() + " SSL disabled");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class SSLHandshakeInputStream
/*      */     extends InputStream
/*      */   {
/*      */     private final TDSReader tdsReader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final TDSChannel.SSLHandshakeOutputStream sslHandshakeOutputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Logger logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String logContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final byte[] oneByte;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final void ensureSSLPayload() throws IOException {
/*      */       if (0 == this.tdsReader.available()) {
/*      */         if (this.logger.isLoggable(Level.FINEST)) {
/*      */           this.logger.finest(this.logContext + " No handshake response bytes available. Flushing SSL handshake output stream.");
/*      */         }
/*      */         try {
/*      */           this.sslHandshakeOutputStream.endMessage();
/*      */         } catch (SQLServerException sQLServerException) {
/*      */           this.logger.finer(this.logContext + " Ending TDS message threw exception:" + sQLServerException.getMessage());
/*      */           throw new IOException(sQLServerException.getMessage());
/*      */         } 
/*      */         if (this.logger.isLoggable(Level.FINEST)) {
/*      */           this.logger.finest(this.logContext + " Reading first packet of SSL handshake response");
/*      */         }
/*      */         try {
/*      */           this.tdsReader.readPacket();
/*      */         } catch (SQLServerException sQLServerException) {
/*      */           this.logger.finer(this.logContext + " Reading response packet threw exception:" + sQLServerException.getMessage());
/*      */           throw new IOException(sQLServerException.getMessage());
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     SSLHandshakeInputStream(TDSChannel param1TDSChannel1, TDSChannel.SSLHandshakeOutputStream param1SSLHandshakeOutputStream)
/*      */     {
/*  741 */       this.oneByte = new byte[1];
/*      */       this.tdsReader = param1TDSChannel1.getReader(null);
/*      */       this.sslHandshakeOutputStream = param1SSLHandshakeOutputStream;
/*      */       this.logger = param1TDSChannel1.getLogger();
/*      */       this.logContext = param1TDSChannel1.toString() + " (SSLHandshakeInputStream):"; } public int read() throws IOException { int i;
/*  746 */       while (0 == (i = readInternal(this.oneByte, 0, this.oneByte.length)));
/*      */ 
/*      */       
/*  749 */       assert 1 == i || -1 == i;
/*  750 */       return (1 == i) ? this.oneByte[0] : -1; }
/*      */ 
/*      */ 
/*      */     
/*      */     public int read(byte[] param1ArrayOfbyte) throws IOException {
/*  755 */       return readInternal(param1ArrayOfbyte, 0, param1ArrayOfbyte.length); }
/*      */     public long skip(long param1Long) throws IOException { if (this.logger.isLoggable(Level.FINEST))
/*      */         this.logger.finest(this.logContext + " Skipping " + param1Long + " bytes...");  if (param1Long <= 0L)
/*      */         return 0L;  if (param1Long > 2147483647L)
/*      */         param1Long = 2147483647L;  ensureSSLPayload(); try { this.tdsReader.skip((int)param1Long); } catch (SQLServerException sQLServerException) { this.logger.finer(this.logContext + " Skipping bytes threw exception:" + sQLServerException.getMessage()); throw new IOException(sQLServerException.getMessage()); }
/*  760 */        return param1Long; } public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException { return readInternal(param1ArrayOfbyte, param1Int1, param1Int2); }
/*      */ 
/*      */ 
/*      */     
/*      */     private int readInternal(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/*  765 */       if (this.logger.isLoggable(Level.FINEST)) {
/*  766 */         this.logger.finest(this.logContext + " Reading " + param1Int2 + " bytes...");
/*      */       }
/*  768 */       ensureSSLPayload();
/*      */ 
/*      */       
/*      */       try {
/*  772 */         this.tdsReader.readBytes(param1ArrayOfbyte, param1Int1, param1Int2);
/*      */       }
/*  774 */       catch (SQLServerException sQLServerException) {
/*      */         
/*  776 */         this.logger.finer(this.logContext + " Reading bytes threw exception:" + sQLServerException.getMessage());
/*  777 */         throw new IOException(sQLServerException.getMessage());
/*      */       } 
/*      */       
/*  780 */       return param1Int2;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class SSLHandshakeOutputStream
/*      */     extends OutputStream
/*      */   {
/*      */     private final TDSWriter tdsWriter;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean messageStarted;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final Logger logger;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final String logContext;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final byte[] singleByte;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     SSLHandshakeOutputStream(TDSChannel param1TDSChannel1) {
/*  834 */       this.singleByte = new byte[1]; this.tdsWriter = param1TDSChannel1.getWriter(); this.messageStarted = false; this.logger = param1TDSChannel1.getLogger();
/*      */       this.logContext = param1TDSChannel1.toString() + " (SSLHandshakeOutputStream):";
/*      */     } public void flush() throws IOException { if (this.logger.isLoggable(Level.FINEST))
/*  837 */         this.logger.finest(this.logContext + " Ignored a request to flush the stream");  } public void write(int param1Int) throws IOException { this.singleByte[0] = (byte)(param1Int & 0xFF);
/*  838 */       writeInternal(this.singleByte, 0, this.singleByte.length); } void endMessage() throws SQLServerException { assert this.messageStarted;
/*      */       if (this.logger.isLoggable(Level.FINEST))
/*      */         this.logger.finest(this.logContext + " Finishing TDS message"); 
/*      */       this.tdsWriter.endMessage();
/*      */       this.messageStarted = false; }
/*  843 */     public void write(byte[] param1ArrayOfbyte) throws IOException { writeInternal(param1ArrayOfbyte, 0, param1ArrayOfbyte.length); }
/*      */ 
/*      */ 
/*      */     
/*      */     public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/*  848 */       writeInternal(param1ArrayOfbyte, param1Int1, param1Int2);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void writeInternal(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/*      */       try {
/*  857 */         if (!this.messageStarted) {
/*      */           
/*  859 */           if (this.logger.isLoggable(Level.FINEST)) {
/*  860 */             this.logger.finest(this.logContext + " Starting new TDS packet...");
/*      */           }
/*  862 */           this.tdsWriter.startMessage(null, (byte)18);
/*  863 */           this.messageStarted = true;
/*      */         } 
/*      */         
/*  866 */         if (this.logger.isLoggable(Level.FINEST)) {
/*  867 */           this.logger.finest(this.logContext + " Writing " + param1Int2 + " bytes...");
/*      */         }
/*  869 */         this.tdsWriter.writeBytes(param1ArrayOfbyte, param1Int1, param1Int2);
/*      */       }
/*  871 */       catch (SQLServerException sQLServerException) {
/*      */         
/*  873 */         this.logger.finer(this.logContext + " Writing bytes threw exception:" + sQLServerException.getMessage());
/*  874 */         throw new IOException(sQLServerException.getMessage());
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final class ProxyInputStream
/*      */     extends InputStream
/*      */   {
/*      */     private InputStream filteredStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final byte[] oneByte;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ProxyInputStream(InputStream param1InputStream) {
/*  924 */       this.oneByte = new byte[1];
/*      */       this.filteredStream = param1InputStream;
/*      */     } final void setFilteredStream(InputStream param1InputStream) {
/*      */       this.filteredStream = param1InputStream;
/*      */     } public int read() throws IOException { int i;
/*  929 */       while (0 == (i = readInternal(this.oneByte, 0, this.oneByte.length)));
/*      */ 
/*      */       
/*  932 */       assert 1 == i || -1 == i;
/*  933 */       return (1 == i) ? this.oneByte[0] : -1; } public long skip(long param1Long) throws IOException { if (TDSChannel.logger.isLoggable(Level.FINEST))
/*      */         TDSChannel.logger.finest(toString() + " Skipping " + param1Long + " bytes");  long l = this.filteredStream.skip(param1Long); if (TDSChannel.logger.isLoggable(Level.FINEST))
/*      */         TDSChannel.logger.finest(toString() + " Skipped " + param1Long + " bytes");  return l; }
/*      */     public int available() throws IOException { int i = this.filteredStream.available(); if (TDSChannel.logger.isLoggable(Level.FINEST))
/*      */         TDSChannel.logger.finest(toString() + " " + i + " bytes available");  return i; }
/*  938 */     public int read(byte[] param1ArrayOfbyte) throws IOException { return readInternal(param1ArrayOfbyte, 0, param1ArrayOfbyte.length); }
/*      */ 
/*      */ 
/*      */     
/*      */     public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/*  943 */       return readInternal(param1ArrayOfbyte, param1Int1, param1Int2);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private int readInternal(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/*      */       int i;
/*  950 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  951 */         TDSChannel.logger.finest(toString() + " Reading " + param1Int2 + " bytes");
/*      */       }
/*      */       
/*      */       try {
/*  955 */         i = this.filteredStream.read(param1ArrayOfbyte, param1Int1, param1Int2);
/*      */       }
/*  957 */       catch (IOException iOException) {
/*      */         
/*  959 */         if (TDSChannel.logger.isLoggable(Level.FINER)) {
/*  960 */           TDSChannel.logger.finer(toString() + " " + iOException.getMessage());
/*      */         }
/*  962 */         TDSChannel.logger.finer(toString() + " Reading bytes threw exception:" + iOException.getMessage());
/*  963 */         throw iOException;
/*      */       } 
/*      */       
/*  966 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  967 */         TDSChannel.logger.finest(toString() + " Read " + i + " bytes");
/*      */       }
/*  969 */       return i;
/*      */     }
/*      */ 
/*      */     
/*      */     public boolean markSupported() {
/*  974 */       boolean bool = this.filteredStream.markSupported();
/*      */       
/*  976 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  977 */         TDSChannel.logger.finest(toString() + " Returning markSupported: " + bool);
/*      */       }
/*  979 */       return bool;
/*      */     }
/*      */ 
/*      */     
/*      */     public void mark(int param1Int) {
/*  984 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  985 */         TDSChannel.logger.finest(toString() + " Marking next " + param1Int + " bytes");
/*      */       }
/*  987 */       this.filteredStream.mark(param1Int);
/*      */     }
/*      */ 
/*      */     
/*      */     public void reset() throws IOException {
/*  992 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/*  993 */         TDSChannel.logger.finest(toString() + " Resetting to previous mark");
/*      */       }
/*  995 */       this.filteredStream.reset();
/*      */     }
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 1000 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1001 */         TDSChannel.logger.finest(toString() + " Closing");
/*      */       }
/* 1003 */       this.filteredStream.close();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final class ProxyOutputStream
/*      */     extends OutputStream
/*      */   {
/*      */     private OutputStream filteredStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final byte[] singleByte;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     ProxyOutputStream(OutputStream param1OutputStream) {
/* 1043 */       this.singleByte = new byte[1];
/*      */       this.filteredStream = param1OutputStream;
/*      */     } final void setFilteredStream(OutputStream param1OutputStream) { this.filteredStream = param1OutputStream; }
/* 1046 */     public void write(int param1Int) throws IOException { this.singleByte[0] = (byte)(param1Int & 0xFF);
/* 1047 */       writeInternal(this.singleByte, 0, this.singleByte.length); } public void close() throws IOException { if (TDSChannel.logger.isLoggable(Level.FINEST))
/*      */         TDSChannel.logger.finest(toString() + " Closing");  this.filteredStream.close(); }
/*      */     public void flush() throws IOException { if (TDSChannel.logger.isLoggable(Level.FINEST))
/*      */         TDSChannel.logger.finest(toString() + " Flushing"); 
/*      */       this.filteredStream.flush(); }
/* 1052 */     public void write(byte[] param1ArrayOfbyte) throws IOException { writeInternal(param1ArrayOfbyte, 0, param1ArrayOfbyte.length); }
/*      */ 
/*      */ 
/*      */     
/*      */     public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/* 1057 */       writeInternal(param1ArrayOfbyte, param1Int1, param1Int2);
/*      */     }
/*      */ 
/*      */     
/*      */     private void writeInternal(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/* 1062 */       if (TDSChannel.logger.isLoggable(Level.FINEST)) {
/* 1063 */         TDSChannel.logger.finest(toString() + " Writing " + param1Int2 + " bytes");
/*      */       }
/* 1065 */       this.filteredStream.write(param1ArrayOfbyte, param1Int1, param1Int2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private class ProxySocket
/*      */     extends Socket
/*      */   {
/*      */     private final TDSChannel tdsChannel;
/*      */ 
/*      */     
/*      */     private final Logger logger;
/*      */ 
/*      */     
/*      */     private final String logContext;
/*      */ 
/*      */     
/*      */     private final TDSChannel.ProxyInputStream proxyInputStream;
/*      */ 
/*      */     
/*      */     private final TDSChannel.ProxyOutputStream proxyOutputStream;
/*      */ 
/*      */ 
/*      */     
/*      */     ProxySocket(TDSChannel param1TDSChannel1) {
/* 1092 */       this.tdsChannel = param1TDSChannel1;
/* 1093 */       this.logger = param1TDSChannel1.getLogger();
/* 1094 */       this.logContext = param1TDSChannel1.toString() + " (ProxySocket):";
/*      */ 
/*      */       
/* 1097 */       TDSChannel.SSLHandshakeOutputStream sSLHandshakeOutputStream = new TDSChannel.SSLHandshakeOutputStream(param1TDSChannel1);
/* 1098 */       TDSChannel.SSLHandshakeInputStream sSLHandshakeInputStream = new TDSChannel.SSLHandshakeInputStream(param1TDSChannel1, sSLHandshakeOutputStream);
/* 1099 */       this.proxyOutputStream = new TDSChannel.ProxyOutputStream(sSLHandshakeOutputStream);
/* 1100 */       this.proxyInputStream = new TDSChannel.ProxyInputStream(sSLHandshakeInputStream);
/*      */     }
/*      */ 
/*      */     
/*      */     void setStreams(InputStream param1InputStream, OutputStream param1OutputStream) {
/* 1105 */       this.proxyInputStream.setFilteredStream(param1InputStream);
/* 1106 */       this.proxyOutputStream.setFilteredStream(param1OutputStream);
/*      */     }
/*      */ 
/*      */     
/*      */     public InputStream getInputStream() throws IOException {
/* 1111 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1112 */         this.logger.finest(this.logContext + " Getting input stream");
/*      */       }
/* 1114 */       return this.proxyInputStream;
/*      */     }
/*      */ 
/*      */     
/*      */     public OutputStream getOutputStream() throws IOException {
/* 1119 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1120 */         this.logger.finest(this.logContext + " Getting output stream");
/*      */       }
/* 1122 */       return this.proxyOutputStream;
/*      */     }
/*      */     
/*      */     public InetAddress getInetAddress() {
/* 1126 */       return this.tdsChannel.tcpSocket.getInetAddress();
/* 1127 */     } public boolean getKeepAlive() throws SocketException { return this.tdsChannel.tcpSocket.getKeepAlive(); }
/* 1128 */     public InetAddress getLocalAddress() { return this.tdsChannel.tcpSocket.getLocalAddress(); }
/* 1129 */     public int getLocalPort() { return this.tdsChannel.tcpSocket.getLocalPort(); }
/* 1130 */     public SocketAddress getLocalSocketAddress() { return this.tdsChannel.tcpSocket.getLocalSocketAddress(); }
/* 1131 */     public boolean getOOBInline() throws SocketException { return this.tdsChannel.tcpSocket.getOOBInline(); }
/* 1132 */     public int getPort() { return this.tdsChannel.tcpSocket.getPort(); }
/* 1133 */     public int getReceiveBufferSize() throws SocketException { return this.tdsChannel.tcpSocket.getReceiveBufferSize(); }
/* 1134 */     public SocketAddress getRemoteSocketAddress() { return this.tdsChannel.tcpSocket.getRemoteSocketAddress(); }
/* 1135 */     public boolean getReuseAddress() throws SocketException { return this.tdsChannel.tcpSocket.getReuseAddress(); }
/* 1136 */     public int getSendBufferSize() throws SocketException { return this.tdsChannel.tcpSocket.getSendBufferSize(); }
/* 1137 */     public int getSoLinger() throws SocketException { return this.tdsChannel.tcpSocket.getSoLinger(); }
/* 1138 */     public int getSoTimeout() throws SocketException { return this.tdsChannel.tcpSocket.getSoTimeout(); }
/* 1139 */     public boolean getTcpNoDelay() throws SocketException { return this.tdsChannel.tcpSocket.getTcpNoDelay(); }
/* 1140 */     public int getTrafficClass() throws SocketException { return this.tdsChannel.tcpSocket.getTrafficClass(); }
/* 1141 */     public boolean isBound() { return true; }
/* 1142 */     public boolean isClosed() { return false; }
/* 1143 */     public boolean isConnected() { return true; }
/* 1144 */     public boolean isInputShutdown() { return false; }
/* 1145 */     public boolean isOutputShutdown() { return false; }
/* 1146 */     public String toString() { return this.tdsChannel.tcpSocket.toString(); } public SocketChannel getChannel() {
/* 1147 */       return null;
/*      */     }
/*      */ 
/*      */     
/*      */     public void bind(SocketAddress param1SocketAddress) throws IOException {
/* 1152 */       this.logger.finer(this.logContext + " Disallowed call to bind.  Throwing IOException.");
/* 1153 */       throw new IOException();
/*      */     }
/*      */ 
/*      */     
/*      */     public void connect(SocketAddress param1SocketAddress) throws IOException {
/* 1158 */       this.logger.finer(this.logContext + " Disallowed call to connect (without timeout).  Throwing IOException.");
/* 1159 */       throw new IOException();
/*      */     }
/*      */ 
/*      */     
/*      */     public void connect(SocketAddress param1SocketAddress, int param1Int) throws IOException {
/* 1164 */       this.logger.finer(this.logContext + " Disallowed call to connect (with timeout).  Throwing IOException.");
/* 1165 */       throw new IOException();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() throws IOException {
/* 1172 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1173 */         this.logger.finer(this.logContext + " Ignoring close");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setReceiveBufferSize(int param1Int) throws SocketException {
/* 1178 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1179 */         this.logger.finer(toString() + " Ignoring setReceiveBufferSize size:" + param1Int);
/*      */       }
/*      */     }
/*      */     
/*      */     public void setSendBufferSize(int param1Int) throws SocketException {
/* 1184 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1185 */         this.logger.finer(toString() + " Ignoring setSendBufferSize size:" + param1Int);
/*      */       }
/*      */     }
/*      */     
/*      */     public void setReuseAddress(boolean param1Boolean) throws SocketException {
/* 1190 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1191 */         this.logger.finer(toString() + " Ignoring setReuseAddress");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setSoLinger(boolean param1Boolean, int param1Int) throws SocketException {
/* 1196 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1197 */         this.logger.finer(toString() + " Ignoring setSoLinger");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setSoTimeout(int param1Int) throws SocketException {
/* 1202 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1203 */         this.logger.finer(toString() + " Ignoring setSoTimeout");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setTcpNoDelay(boolean param1Boolean) throws SocketException {
/* 1208 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1209 */         this.logger.finer(toString() + " Ignoring setTcpNoDelay");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setTrafficClass(int param1Int) throws SocketException {
/* 1214 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1215 */         this.logger.finer(toString() + " Ignoring setTrafficClass");
/*      */       }
/*      */     }
/*      */     
/*      */     public void shutdownInput() throws IOException {
/* 1220 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1221 */         this.logger.finer(toString() + " Ignoring shutdownInput");
/*      */       }
/*      */     }
/*      */     
/*      */     public void shutdownOutput() throws IOException {
/* 1226 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1227 */         this.logger.finer(toString() + " Ignoring shutdownOutput");
/*      */       }
/*      */     }
/*      */     
/*      */     public void sendUrgentData(int param1Int) throws IOException {
/* 1232 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1233 */         this.logger.finer(toString() + " Ignoring sendUrgentData");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setKeepAlive(boolean param1Boolean) throws SocketException {
/* 1238 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1239 */         this.logger.finer(toString() + " Ignoring setKeepAlive");
/*      */       }
/*      */     }
/*      */     
/*      */     public void setOOBInline(boolean param1Boolean) throws SocketException {
/* 1244 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1245 */         this.logger.finer(toString() + " Ignoring setOOBInline");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final class PermissiveX509TrustManager
/*      */     implements X509TrustManager
/*      */   {
/*      */     private final TDSChannel tdsChannel;
/*      */     
/*      */     private final Logger logger;
/*      */     
/*      */     private final String logContext;
/*      */ 
/*      */     
/*      */     PermissiveX509TrustManager(TDSChannel param1TDSChannel1) {
/* 1263 */       this.tdsChannel = param1TDSChannel1;
/* 1264 */       this.logger = param1TDSChannel1.getLogger();
/* 1265 */       this.logContext = param1TDSChannel1.toString() + " (PermissiveX509TrustManager):";
/*      */     }
/*      */ 
/*      */     
/*      */     public void checkClientTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) throws CertificateException {
/* 1270 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1271 */         this.logger.finer(this.logContext + " Trusting client certificate (!)");
/*      */       }
/*      */     }
/*      */     
/*      */     public void checkServerTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) throws CertificateException {
/* 1276 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1277 */         this.logger.finer(this.logContext + " Trusting server certificate");
/*      */       }
/*      */     }
/*      */     
/*      */     public X509Certificate[] getAcceptedIssuers() {
/* 1282 */       return new X509Certificate[0];
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private final class HostNameOverrideX509TrustManager
/*      */     implements X509TrustManager
/*      */   {
/*      */     private final Logger logger;
/*      */     
/*      */     private final String logContext;
/*      */     
/*      */     private final X509TrustManager defaultTrustManager;
/*      */     
/*      */     private String hostName;
/*      */     
/*      */     HostNameOverrideX509TrustManager(TDSChannel param1TDSChannel1, X509TrustManager param1X509TrustManager, String param1String) {
/* 1299 */       this.logger = param1TDSChannel1.getLogger();
/* 1300 */       this.logContext = param1TDSChannel1.toString() + " (HostNameOverrideX509TrustManager):";
/* 1301 */       this.defaultTrustManager = param1X509TrustManager;
/*      */       
/* 1303 */       this.hostName = param1String.toLowerCase();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private String parseCommonName(String param1String) {
/* 1314 */       int i = param1String.indexOf("cn=");
/* 1315 */       if (i == -1)
/*      */       {
/* 1317 */         return null;
/*      */       }
/* 1319 */       param1String = param1String.substring(i + 3);
/*      */ 
/*      */ 
/*      */       
/* 1323 */       for (i = 0; i < param1String.length(); i++) {
/*      */         
/* 1325 */         if (param1String.charAt(i) == ',') {
/*      */           break;
/*      */         }
/*      */       } 
/*      */       
/* 1330 */       String str = param1String.substring(0, i);
/*      */       
/* 1332 */       if (str.length() > 1 && '"' == str.charAt(0))
/*      */       {
/* 1334 */         if ('"' == str.charAt(str.length() - 1)) {
/* 1335 */           str = str.substring(1, str.length() - 1);
/*      */         }
/*      */         else {
/*      */           
/* 1339 */           str = null;
/*      */         } 
/*      */       }
/* 1342 */       return str;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private boolean validateServerName(String param1String) throws CertificateException {
/* 1348 */       if (null == param1String) {
/*      */         
/* 1350 */         if (this.logger.isLoggable(Level.FINER))
/* 1351 */           this.logger.finer(this.logContext + " Failed to parse the name from the certificate or name is empty."); 
/* 1352 */         return false;
/*      */       } 
/*      */ 
/*      */       
/* 1356 */       if (!param1String.equals(this.hostName)) {
/*      */         
/* 1358 */         if (this.logger.isLoggable(Level.FINER))
/* 1359 */           this.logger.finer(this.logContext + " The name in certificate " + param1String + " does not match with the server name " + this.hostName + "."); 
/* 1360 */         return false;
/*      */       } 
/*      */       
/* 1363 */       if (this.logger.isLoggable(Level.FINER)) {
/* 1364 */         this.logger.finer(this.logContext + " The name in certificate:" + param1String + " validated against server name " + this.hostName + ".");
/*      */       }
/* 1366 */       return true;
/*      */     }
/*      */ 
/*      */     
/*      */     public void checkClientTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) throws CertificateException {
/* 1371 */       if (this.logger.isLoggable(Level.FINEST))
/* 1372 */         this.logger.finest(this.logContext + " Forwarding ClientTrusted."); 
/* 1373 */       this.defaultTrustManager.checkClientTrusted(param1ArrayOfX509Certificate, param1String);
/*      */     }
/*      */ 
/*      */     
/*      */     public void checkServerTrusted(X509Certificate[] param1ArrayOfX509Certificate, String param1String) throws CertificateException {
/* 1378 */       if (this.logger.isLoggable(Level.FINEST))
/* 1379 */         this.logger.finest(this.logContext + " Forwarding Trusting server certificate"); 
/* 1380 */       this.defaultTrustManager.checkServerTrusted(param1ArrayOfX509Certificate, param1String);
/* 1381 */       if (this.logger.isLoggable(Level.FINEST)) {
/* 1382 */         this.logger.finest(this.logContext + " default serverTrusted succeeded proceeding with server name validation");
/*      */       }
/* 1384 */       validateServerNameInCertificate(param1ArrayOfX509Certificate[0]);
/*      */     }
/*      */ 
/*      */     
/*      */     private void validateServerNameInCertificate(X509Certificate param1X509Certificate) throws CertificateException {
/* 1389 */       String str1 = param1X509Certificate.getSubjectX500Principal().getName("canonical");
/* 1390 */       if (this.logger.isLoggable(Level.FINER)) {
/*      */         
/* 1392 */         this.logger.finer(this.logContext + " Validating the server name:" + this.hostName);
/* 1393 */         this.logger.finer(this.logContext + " The DN name in certificate:" + str1);
/*      */       } 
/*      */       
/* 1396 */       boolean bool = false;
/*      */ 
/*      */       
/* 1399 */       String str2 = parseCommonName(str1);
/*      */       
/* 1401 */       bool = validateServerName(str2);
/*      */       
/* 1403 */       if (!bool) {
/*      */ 
/*      */         
/* 1406 */         Collection<List<?>> collection = param1X509Certificate.getSubjectAlternativeNames();
/*      */         
/* 1408 */         if (collection != null)
/*      */         {
/*      */           
/* 1411 */           for (List<Object> list : collection) {
/*      */ 
/*      */             
/* 1414 */             if (list != null && list.size() >= 2) {
/*      */               
/* 1416 */               String str3 = (String)list.get(0);
/* 1417 */               String str4 = (String)list.get(1);
/*      */               
/* 1419 */               if (this.logger.isLoggable(Level.FINER))
/*      */               {
/* 1421 */                 this.logger.finer(this.logContext + "Key: " + str3 + "; KeyClass:" + ((str3 != null) ? (String)str3.getClass() : null) + ";value: " + str4 + "; valueClass:" + ((str4 != null) ? (String)str4.getClass() : null));
/*      */               }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1435 */               if (str3 != null && str3 instanceof Integer && ((Integer)str3).intValue() == 2) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                 
/* 1443 */                 if (str4 != null && str4 instanceof String) {
/*      */                   
/* 1445 */                   String str = str4;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */                   
/* 1452 */                   str = str.toUpperCase(Locale.US);
/* 1453 */                   str = str.toLowerCase(Locale.US);
/*      */                   
/* 1455 */                   bool = validateServerName(str);
/*      */                   
/* 1457 */                   if (bool) {
/*      */                     
/* 1459 */                     if (this.logger.isLoggable(Level.FINER))
/*      */                     {
/* 1461 */                       this.logger.finer(this.logContext + " found a valid name in certificate: " + str);
/*      */                     }
/*      */                     
/*      */                     break;
/*      */                   } 
/*      */                 } 
/*      */                 
/* 1468 */                 if (this.logger.isLoggable(Level.FINER))
/*      */                 {
/* 1470 */                   this.logger.finer(this.logContext + " the following name in certificate does not match the serverName: " + str4);
/*      */                 }
/*      */               } 
/*      */ 
/*      */               
/*      */               continue;
/*      */             } 
/*      */             
/* 1478 */             if (this.logger.isLoggable(Level.FINER))
/*      */             {
/* 1480 */               this.logger.finer(this.logContext + " found an invalid san entry: " + list);
/*      */             }
/*      */           } 
/*      */         }
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1488 */       if (!bool) {
/*      */         
/* 1490 */         String str = SQLServerException.getErrString("R_certNameFailed");
/* 1491 */         throw new CertificateException(str);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public X509Certificate[] getAcceptedIssuers() {
/* 1497 */       return this.defaultTrustManager.getAcceptedIssuers();
/*      */     }
/*      */   }
/*      */   
/*      */   enum SSLHandhsakeState
/*      */   {
/* 1503 */     SSL_HANDHSAKE_NOT_STARTED,
/* 1504 */     SSL_HANDHSAKE_STARTED,
/* 1505 */     SSL_HANDHSAKE_COMPLETE;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void enableSSL(String paramString, int paramInt) throws SQLServerException {
/* 1512 */     Provider provider1 = null;
/* 1513 */     Provider provider2 = null;
/* 1514 */     Provider provider3 = null;
/* 1515 */     String str = null;
/* 1516 */     SSLHandhsakeState sSLHandhsakeState = SSLHandhsakeState.SSL_HANDHSAKE_NOT_STARTED;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1521 */       if (logger.isLoggable(Level.FINER)) {
/* 1522 */         logger.finer(toString() + " Enabling SSL...");
/*      */       }
/* 1524 */       String str1 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_STORE.toString());
/* 1525 */       String str2 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
/* 1526 */       String str3 = this.con.activeConnectionProperties.getProperty(SQLServerDriverStringProperty.HOSTNAME_IN_CERTIFICATE.toString());
/*      */       
/* 1528 */       assert 0 == this.con.getRequestedEncryptionLevel() || 1 == this.con.getRequestedEncryptionLevel();
/*      */ 
/*      */ 
/*      */       
/* 1532 */       assert 0 == this.con.getNegotiatedEncryptionLevel() || 1 == this.con.getNegotiatedEncryptionLevel() || 3 == this.con.getNegotiatedEncryptionLevel();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1540 */       TrustManager[] arrayOfTrustManager = null;
/* 1541 */       if (0 == this.con.getRequestedEncryptionLevel() || (1 == this.con.getRequestedEncryptionLevel() && this.con.trustServerCertificate())) {
/*      */ 
/*      */         
/* 1544 */         if (logger.isLoggable(Level.FINER)) {
/* 1545 */           logger.finer(toString() + " SSL handshake will trust any certificate");
/*      */         }
/* 1547 */         arrayOfTrustManager = new TrustManager[] { new PermissiveX509TrustManager(this) };
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1554 */         if (logger.isLoggable(Level.FINER)) {
/* 1555 */           logger.finer(toString() + " SSL handshake will validate server certificate");
/*      */         }
/* 1557 */         KeyStore keyStore = null;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1562 */         if (null == str1 && null == str2) {
/*      */           
/* 1564 */           if (logger.isLoggable(Level.FINER)) {
/* 1565 */             logger.finer(toString() + " Using system default trust store and password");
/*      */ 
/*      */           
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/* 1574 */           if (logger.isLoggable(Level.FINEST)) {
/* 1575 */             logger.finest(toString() + " Finding key store interface");
/*      */           }
/* 1577 */           keyStore = KeyStore.getInstance("JKS");
/* 1578 */           provider3 = keyStore.getProvider();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1584 */           InputStream inputStream = loadTrustStore(str1);
/*      */ 
/*      */ 
/*      */           
/* 1588 */           if (logger.isLoggable(Level.FINEST)) {
/* 1589 */             logger.finest(toString() + " Loading key store");
/*      */           }
/*      */           
/*      */           try {
/* 1593 */             keyStore.load(inputStream, (null == str2) ? null : str2.toCharArray());
/*      */           
/*      */           }
/*      */           finally {
/*      */             
/* 1598 */             this.con.activeConnectionProperties.remove(SQLServerDriverStringProperty.TRUST_STORE_PASSWORD.toString());
/*      */ 
/*      */             
/* 1601 */             if (null != inputStream) {
/*      */               
/*      */               try {
/*      */                 
/* 1605 */                 inputStream.close();
/*      */               }
/* 1607 */               catch (IOException iOException) {
/*      */                 
/* 1609 */                 if (logger.isLoggable(Level.FINE)) {
/* 1610 */                   logger.fine(toString() + " Ignoring error closing trust material InputStream...");
/*      */                 }
/*      */               } 
/*      */             }
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1623 */         TrustManagerFactory trustManagerFactory = null;
/*      */         
/* 1625 */         if (logger.isLoggable(Level.FINEST)) {
/* 1626 */           logger.finest(toString() + " Locating X.509 trust manager factory");
/*      */         }
/* 1628 */         str = TrustManagerFactory.getDefaultAlgorithm();
/* 1629 */         trustManagerFactory = TrustManagerFactory.getInstance(str);
/* 1630 */         provider1 = trustManagerFactory.getProvider();
/*      */ 
/*      */ 
/*      */         
/* 1634 */         if (logger.isLoggable(Level.FINEST)) {
/* 1635 */           logger.finest(toString() + " Getting trust manager");
/*      */         }
/* 1637 */         trustManagerFactory.init(keyStore);
/* 1638 */         arrayOfTrustManager = trustManagerFactory.getTrustManagers();
/*      */ 
/*      */         
/* 1641 */         if (null != str3) {
/*      */           
/* 1643 */           arrayOfTrustManager = new TrustManager[] { new HostNameOverrideX509TrustManager(this, (X509TrustManager)arrayOfTrustManager[0], str3) };
/*      */         }
/*      */         else {
/*      */           
/* 1647 */           arrayOfTrustManager = new TrustManager[] { new HostNameOverrideX509TrustManager(this, (X509TrustManager)arrayOfTrustManager[0], paramString) };
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1653 */       SSLContext sSLContext = null;
/*      */       
/* 1655 */       if (logger.isLoggable(Level.FINEST)) {
/* 1656 */         logger.finest(toString() + " Getting TLS or better SSL context");
/*      */       }
/* 1658 */       sSLContext = SSLContext.getInstance("TLS");
/* 1659 */       provider2 = sSLContext.getProvider();
/*      */       
/* 1661 */       if (logger.isLoggable(Level.FINEST)) {
/* 1662 */         logger.finest(toString() + " Initializing SSL context");
/*      */       }
/* 1664 */       sSLContext.init(null, arrayOfTrustManager, null);
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1669 */       this.proxySocket = new ProxySocket(this);
/*      */       
/* 1671 */       if (logger.isLoggable(Level.FINEST)) {
/* 1672 */         logger.finest(toString() + " Creating SSL socket");
/*      */       }
/* 1674 */       this.sslSocket = (SSLSocket)sSLContext.getSocketFactory().createSocket(this.proxySocket, paramString, paramInt, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1683 */       if (logger.isLoggable(Level.FINER)) {
/* 1684 */         logger.finer(toString() + " Starting SSL handshake");
/*      */       }
/*      */       
/* 1687 */       sSLHandhsakeState = SSLHandhsakeState.SSL_HANDHSAKE_STARTED;
/* 1688 */       this.sslSocket.startHandshake();
/* 1689 */       sSLHandhsakeState = SSLHandhsakeState.SSL_HANDHSAKE_COMPLETE;
/*      */ 
/*      */       
/* 1692 */       if (logger.isLoggable(Level.FINEST)) {
/* 1693 */         logger.finest(toString() + " Rewiring proxy streams after handshake");
/*      */       }
/* 1695 */       this.proxySocket.setStreams(this.inputStream, this.outputStream);
/*      */ 
/*      */       
/* 1698 */       if (logger.isLoggable(Level.FINEST)) {
/* 1699 */         logger.finest(toString() + " Getting SSL InputStream");
/*      */       }
/* 1701 */       this.inputStream = this.sslSocket.getInputStream();
/*      */       
/* 1703 */       if (logger.isLoggable(Level.FINEST)) {
/* 1704 */         logger.finest(toString() + " Getting SSL OutputStream");
/*      */       }
/* 1706 */       this.outputStream = this.sslSocket.getOutputStream();
/*      */ 
/*      */       
/* 1709 */       this.channelSocket = this.sslSocket;
/*      */       
/* 1711 */       if (logger.isLoggable(Level.FINER)) {
/* 1712 */         logger.finer(toString() + " SSL enabled");
/*      */       }
/* 1714 */     } catch (Exception exception) {
/*      */ 
/*      */       
/* 1717 */       if (logger.isLoggable(Level.FINER)) {
/* 1718 */         logger.log(Level.FINER, exception.getMessage(), exception);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1724 */       if (logger.isLoggable(Level.FINER)) {
/* 1725 */         logger.log(Level.FINER, "java.security path: " + JAVA_SECURITY + "\n" + "Security providers: " + Arrays.<Provider>asList(Security.getProviders()) + "\n" + ((null != provider2) ? ("SSLContext provider info: " + provider2.getInfo() + "\n" + "SSLContext provider services:\n" + provider2.getServices() + "\n") : "") + ((null != provider1) ? ("TrustManagerFactory provider info: " + provider1.getInfo() + "\n") : "") + ((null != str) ? ("TrustManagerFactory default algorithm: " + str + "\n") : "") + ((null != provider3) ? ("KeyStore provider info: " + provider3.getInfo() + "\n") : "") + "java.ext.dirs: " + System.getProperty("java.ext.dirs"));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1740 */       MessageFormat messageFormat = new MessageFormat(SQLServerException.getErrString("R_sslFailed"));
/* 1741 */       Object[] arrayOfObject = { exception.getMessage() };
/*      */ 
/*      */       
/* 1744 */       String str1 = exception.getLocalizedMessage();
/*      */ 
/*      */ 
/*      */       
/* 1748 */       if (-1 != str1.indexOf(" ClientConnectionId:"))
/*      */       {
/* 1750 */         str1 = str1.substring(0, str1.indexOf(" ClientConnectionId:"));
/*      */       }
/*      */ 
/*      */       
/* 1754 */       if (exception instanceof IOException && SSLHandhsakeState.SSL_HANDHSAKE_STARTED == sSLHandhsakeState && str1.equals(SQLServerException.getErrString("R_truncatedServerResponse"))) {
/*      */ 
/*      */ 
/*      */         
/* 1758 */         this.con.terminate(7, messageFormat.format(arrayOfObject), exception);
/*      */       }
/*      */       else {
/*      */         
/* 1762 */         this.con.terminate(5, messageFormat.format(arrayOfObject), exception);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1782 */   private static final String SEPARATOR = System.getProperty("file.separator");
/* 1783 */   private static final String JAVA_HOME = System.getProperty("java.home");
/* 1784 */   private static final String JAVA_SECURITY = JAVA_HOME + SEPARATOR + "lib" + SEPARATOR + "security";
/* 1785 */   private static final String JSSECACERTS = JAVA_SECURITY + SEPARATOR + "jssecacerts";
/* 1786 */   private static final String CACERTS = JAVA_SECURITY + SEPARATOR + "cacerts";
/*      */   
/*      */   final InputStream loadTrustStore(String paramString) {
/* 1789 */     FileInputStream fileInputStream = null;
/*      */ 
/*      */     
/* 1792 */     if (null != paramString) {
/*      */       
/*      */       try
/*      */       {
/* 1796 */         if (logger.isLoggable(Level.FINEST)) {
/* 1797 */           logger.finest(toString() + " Opening specified trust store: " + paramString);
/*      */         }
/* 1799 */         fileInputStream = new FileInputStream(paramString);
/*      */       }
/* 1801 */       catch (FileNotFoundException fileNotFoundException)
/*      */       {
/* 1803 */         if (logger.isLoggable(Level.FINE)) {
/* 1804 */           logger.fine(toString() + " Trust store not found: " + fileNotFoundException.getMessage());
/*      */ 
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1813 */     else if (null != (paramString = System.getProperty("javax.net.ssl.trustStore"))) {
/*      */ 
/*      */       
/*      */       try {
/* 1817 */         if (logger.isLoggable(Level.FINEST)) {
/* 1818 */           logger.finest(toString() + " Opening default trust store (from javax.net.ssl.trustStore): " + paramString);
/*      */         }
/* 1820 */         fileInputStream = new FileInputStream(paramString);
/*      */       }
/* 1822 */       catch (FileNotFoundException fileNotFoundException) {
/*      */         
/* 1824 */         if (logger.isLoggable(Level.FINE)) {
/* 1825 */           logger.fine(toString() + " Trust store not found: " + fileNotFoundException.getMessage());
/*      */         }
/*      */       } 
/*      */     } else {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1838 */         if (logger.isLoggable(Level.FINEST)) {
/* 1839 */           logger.finest(toString() + " Opening default trust store: " + JSSECACERTS);
/*      */         }
/* 1841 */         fileInputStream = new FileInputStream(JSSECACERTS);
/*      */       }
/* 1843 */       catch (FileNotFoundException fileNotFoundException) {
/*      */         
/* 1845 */         if (logger.isLoggable(Level.FINE)) {
/* 1846 */           logger.fine(toString() + " Trust store not found: " + fileNotFoundException.getMessage());
/*      */         }
/*      */       } 
/*      */       
/* 1850 */       if (null == fileInputStream) {
/*      */         
/*      */         try {
/*      */           
/* 1854 */           if (logger.isLoggable(Level.FINEST)) {
/* 1855 */             logger.finest(toString() + " Opening default trust store: " + CACERTS);
/*      */           }
/* 1857 */           fileInputStream = new FileInputStream(CACERTS);
/*      */         }
/* 1859 */         catch (FileNotFoundException fileNotFoundException) {
/*      */           
/* 1861 */           if (logger.isLoggable(Level.FINE)) {
/* 1862 */             logger.fine(toString() + " Trust store not found: " + fileNotFoundException.getMessage());
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1870 */     return fileInputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLServerException {
/*      */     try {
/* 1877 */       return this.inputStream.read(paramArrayOfbyte, paramInt1, paramInt2);
/*      */     }
/* 1879 */     catch (IOException iOException) {
/*      */       
/* 1881 */       if (logger.isLoggable(Level.FINE)) {
/* 1882 */         logger.fine(toString() + " read failed:" + iOException.getMessage());
/*      */       }
/* 1884 */       this.con.terminate(3, iOException.getMessage());
/* 1885 */       return 0;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLServerException {
/*      */     try {
/* 1893 */       this.outputStream.write(paramArrayOfbyte, paramInt1, paramInt2);
/*      */     }
/* 1895 */     catch (IOException iOException) {
/*      */       
/* 1897 */       if (logger.isLoggable(Level.FINER)) {
/* 1898 */         logger.finer(toString() + " write failed:" + iOException.getMessage());
/*      */       }
/* 1900 */       this.con.terminate(3, iOException.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   final void flush() throws SQLServerException {
/*      */     try {
/* 1908 */       this.outputStream.flush();
/*      */     }
/* 1910 */     catch (IOException iOException) {
/*      */       
/* 1912 */       if (logger.isLoggable(Level.FINER)) {
/* 1913 */         logger.finer(toString() + " flush failed:" + iOException.getMessage());
/*      */       }
/* 1915 */       this.con.terminate(3, iOException.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   final void close() {
/* 1921 */     if (null != this.sslSocket) {
/* 1922 */       disableSSL();
/*      */     }
/* 1924 */     if (null != this.inputStream) {
/*      */       
/* 1926 */       if (logger.isLoggable(Level.FINEST)) {
/* 1927 */         logger.finest(toString() + ": Closing inputStream...");
/*      */       }
/*      */       
/*      */       try {
/* 1931 */         this.inputStream.close();
/*      */       }
/* 1933 */       catch (IOException iOException) {
/*      */         
/* 1935 */         if (logger.isLoggable(Level.FINE)) {
/* 1936 */           logger.log(Level.FINE, toString() + ": Ignored error closing inputStream", iOException);
/*      */         }
/*      */       } 
/*      */     } 
/* 1940 */     if (null != this.outputStream) {
/*      */       
/* 1942 */       if (logger.isLoggable(Level.FINEST)) {
/* 1943 */         logger.finest(toString() + ": Closing outputStream...");
/*      */       }
/*      */       
/*      */       try {
/* 1947 */         this.outputStream.close();
/*      */       }
/* 1949 */       catch (IOException iOException) {
/*      */         
/* 1951 */         if (logger.isLoggable(Level.FINE)) {
/* 1952 */           logger.log(Level.FINE, toString() + ": Ignored error closing outputStream", iOException);
/*      */         }
/*      */       } 
/*      */     } 
/* 1956 */     if (null != this.tcpSocket) {
/*      */       
/* 1958 */       if (logger.isLoggable(Level.FINER)) {
/* 1959 */         logger.finer(toString() + ": Closing TCP socket...");
/*      */       }
/*      */       
/*      */       try {
/* 1963 */         this.tcpSocket.close();
/*      */       }
/* 1965 */       catch (IOException iOException) {
/*      */         
/* 1967 */         if (logger.isLoggable(Level.FINE)) {
/* 1968 */           logger.log(Level.FINE, toString() + ": Ignored error closing socket", iOException);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void logPacket(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, String paramString) {
/* 1983 */     assert 0 <= paramInt2 && paramInt2 <= paramArrayOfbyte.length;
/* 1984 */     assert 0 <= paramInt1 && paramInt1 <= paramArrayOfbyte.length;
/*      */     
/* 1986 */     char[] arrayOfChar1 = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1992 */     char[] arrayOfChar2 = { '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', ' ', '!', '"', '#', '$', '%', '&', '\'', '(', ')', '*', '+', ',', '-', '.', '/', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', ':', ';', '<', '=', '>', '?', '@', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '[', '\\', ']', '^', '_', '`', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '{', '|', '}', '~', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2018 */     char[] arrayOfChar3 = { ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', ' ', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.', '.' };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2031 */     char[] arrayOfChar4 = new char[arrayOfChar3.length];
/* 2032 */     System.arraycopy(arrayOfChar3, 0, arrayOfChar4, 0, arrayOfChar3.length);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2037 */     StringBuilder stringBuilder = new StringBuilder(paramString.length() + 4 * paramInt2 + 4 * (1 + paramInt2 / 16) + 80);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2048 */     stringBuilder.append(this.tcpSocket.getLocalAddress().toString() + ":" + this.tcpSocket.getLocalPort() + " SPID:" + this.spid + " " + paramString + "\r\n");
/*      */ 
/*      */     
/* 2051 */     byte b = 0;
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/* 2056 */       byte b1 = 0;
/* 2057 */       for (; b1 < 16 && b < paramInt2; 
/* 2058 */         b1++, b++) {
/*      */         
/* 2060 */         int i = (paramArrayOfbyte[paramInt1 + b] + 256) % 256;
/* 2061 */         arrayOfChar4[3 * b1] = arrayOfChar1[i / 16];
/* 2062 */         arrayOfChar4[3 * b1 + 1] = arrayOfChar1[i % 16];
/* 2063 */         arrayOfChar4[50 + b1] = arrayOfChar2[i];
/*      */       } 
/*      */ 
/*      */       
/* 2067 */       byte b2 = b1;
/* 2068 */       for (; b2 < 16; b2++) {
/*      */         
/* 2070 */         arrayOfChar4[3 * b2] = ' ';
/* 2071 */         arrayOfChar4[3 * b2 + 1] = ' ';
/*      */       } 
/*      */       
/* 2074 */       stringBuilder.append(arrayOfChar4, 0, 50 + b1);
/* 2075 */       if (b == paramInt2) {
/*      */         break;
/*      */       }
/* 2078 */       stringBuilder.append("\r\n");
/*      */     } 
/*      */     
/* 2081 */     packetLogger.finest(stringBuilder.toString());
/*      */   }
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/TDSChannel.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */