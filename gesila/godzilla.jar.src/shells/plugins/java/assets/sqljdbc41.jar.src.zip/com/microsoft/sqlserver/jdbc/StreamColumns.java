/*     */ package com.microsoft.sqlserver.jdbc;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class StreamColumns
/*     */   extends StreamPacket
/*     */ {
/*     */   private Column[] columns;
/*  17 */   private CekTable cekTable = null;
/*     */ 
/*     */   
/*     */   private boolean shouldHonorAEForRead = false;
/*     */ 
/*     */   
/*     */   CekTable getCekTable() {
/*  24 */     return this.cekTable;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StreamColumns() {
/*  31 */     super(129);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   StreamColumns(boolean paramBoolean) {
/*  38 */     super(129);
/*  39 */     this.shouldHonorAEForRead = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CekTableEntry readCEKTableEntry(TDSReader paramTDSReader) throws SQLServerException {
/*  50 */     int i = paramTDSReader.readInt();
/*     */ 
/*     */     
/*  53 */     int j = paramTDSReader.readInt();
/*     */ 
/*     */     
/*  56 */     int k = paramTDSReader.readInt();
/*     */ 
/*     */     
/*  59 */     byte[] arrayOfByte = new byte[8];
/*  60 */     paramTDSReader.readBytes(arrayOfByte, 0, 8);
/*     */ 
/*     */     
/*  63 */     int m = paramTDSReader.readUnsignedByte();
/*     */     
/*  65 */     CekTableEntry cekTableEntry = new CekTableEntry(m);
/*     */     
/*  67 */     for (byte b = 0; b < m; b++) {
/*     */       
/*  69 */       short s1 = paramTDSReader.readShort();
/*     */       
/*  71 */       byte[] arrayOfByte1 = new byte[s1];
/*     */ 
/*     */       
/*  74 */       paramTDSReader.readBytes(arrayOfByte1, 0, s1);
/*     */ 
/*     */       
/*  77 */       int n = paramTDSReader.readUnsignedByte();
/*     */ 
/*     */       
/*  80 */       String str1 = paramTDSReader.readUnicodeString(n);
/*     */ 
/*     */       
/*  83 */       short s2 = paramTDSReader.readShort();
/*     */ 
/*     */       
/*  86 */       String str2 = paramTDSReader.readUnicodeString(s2);
/*     */ 
/*     */       
/*  89 */       int i1 = paramTDSReader.readUnsignedByte();
/*     */ 
/*     */       
/*  92 */       String str3 = paramTDSReader.readUnicodeString(i1);
/*     */ 
/*     */       
/*  95 */       cekTableEntry.add(arrayOfByte1, i, j, k, arrayOfByte, str2, str1, str3);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 105 */     return cekTableEntry;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void readCEKTable(TDSReader paramTDSReader) throws SQLServerException {
/* 116 */     short s = paramTDSReader.readShort();
/*     */ 
/*     */ 
/*     */     
/* 120 */     if (0 != s) {
/* 121 */       this.cekTable = new CekTable(s);
/*     */ 
/*     */       
/* 124 */       for (byte b = 0; b < s; b++)
/*     */       {
/* 126 */         this.cekTable.setCekTableEntry(b, readCEKTableEntry(paramTDSReader));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CryptoMetadata readCryptoMetadata(TDSReader paramTDSReader) throws SQLServerException {
/* 139 */     short s = 0;
/*     */     
/* 141 */     if (null != this.cekTable)
/*     */     {
/* 143 */       s = paramTDSReader.readShort();
/*     */     }
/*     */     
/* 146 */     TypeInfo typeInfo = TypeInfo.getInstance(paramTDSReader, false);
/*     */ 
/*     */     
/* 149 */     byte b1 = (byte)paramTDSReader.readUnsignedByte();
/*     */     
/* 151 */     String str = null;
/* 152 */     if (0 == b1) {
/*     */       
/* 154 */       int i = paramTDSReader.readUnsignedByte();
/* 155 */       str = paramTDSReader.readUnicodeString(i);
/*     */     } 
/*     */ 
/*     */     
/* 159 */     byte b2 = (byte)paramTDSReader.readUnsignedByte();
/*     */ 
/*     */     
/* 162 */     byte b3 = (byte)paramTDSReader.readUnsignedByte();
/*     */     
/* 164 */     CryptoMetadata cryptoMetadata = new CryptoMetadata((this.cekTable == null) ? null : this.cekTable.getCekTableEntry(s), s, b1, str, b2, b3);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 171 */     cryptoMetadata.setBaseTypeInfo(typeInfo);
/*     */     
/* 173 */     return cryptoMetadata;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setFromTDS(TDSReader paramTDSReader) throws SQLServerException {
/* 183 */     if (129 != paramTDSReader.readUnsignedByte() && !$assertionsDisabled) throw new AssertionError();
/*     */     
/* 185 */     int i = paramTDSReader.readUnsignedShort();
/*     */ 
/*     */     
/* 188 */     if (65535 == i) {
/*     */       return;
/*     */     }
/* 191 */     if (paramTDSReader.getServerSupportsColumnEncryption())
/*     */     {
/* 193 */       readCEKTable(paramTDSReader);
/*     */     }
/*     */     
/* 196 */     this.columns = new Column[i];
/*     */     
/* 198 */     for (byte b = 0; b < i; b++) {
/*     */ 
/*     */       
/* 201 */       TypeInfo typeInfo = TypeInfo.getInstance(paramTDSReader, true);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 207 */       SQLIdentifier sQLIdentifier = new SQLIdentifier();
/* 208 */       if (SSType.TEXT == typeInfo.getSSType() || SSType.NTEXT == typeInfo.getSSType() || SSType.IMAGE == typeInfo.getSSType())
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 213 */         sQLIdentifier = paramTDSReader.readSQLIdentifier();
/*     */       }
/*     */       
/* 216 */       CryptoMetadata cryptoMetadata = null;
/* 217 */       if (paramTDSReader.getServerSupportsColumnEncryption() && typeInfo.isEncrypted()) {
/*     */         
/* 219 */         cryptoMetadata = readCryptoMetadata(paramTDSReader);
/* 220 */         cryptoMetadata.baseTypeInfo.setFlags(Short.valueOf(typeInfo.getFlagsAsShort()));
/* 221 */         typeInfo.setSQLCollation(cryptoMetadata.baseTypeInfo.getSQLCollation());
/*     */       } 
/*     */ 
/*     */       
/* 225 */       String str = paramTDSReader.readUnicodeString(paramTDSReader.readUnsignedByte());
/*     */       
/* 227 */       if (this.shouldHonorAEForRead) {
/*     */         
/* 229 */         this.columns[b] = new Column(typeInfo, str, sQLIdentifier, cryptoMetadata);
/*     */       
/*     */       }
/*     */       else {
/*     */         
/* 234 */         this.columns[b] = new Column(typeInfo, str, sQLIdentifier, null);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Column[] buildColumns(StreamColInfo paramStreamColInfo, StreamTabName paramStreamTabName) throws SQLServerException {
/* 246 */     if (null != paramStreamColInfo && null != paramStreamTabName) {
/* 247 */       paramStreamTabName.applyTo(this.columns, paramStreamColInfo.applyTo(this.columns));
/*     */     }
/* 249 */     return this.columns;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/StreamColumns.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */