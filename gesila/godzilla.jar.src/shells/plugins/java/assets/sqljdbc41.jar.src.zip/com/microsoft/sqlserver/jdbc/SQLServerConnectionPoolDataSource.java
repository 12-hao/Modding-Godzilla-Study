/*    */ package com.microsoft.sqlserver.jdbc;
/*    */ 
/*    */ import java.io.InvalidObjectException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectStreamException;
/*    */ import java.io.Serializable;
/*    */ import java.sql.SQLException;
/*    */ import java.util.logging.Level;
/*    */ import javax.naming.Reference;
/*    */ import javax.sql.ConnectionPoolDataSource;
/*    */ import javax.sql.PooledConnection;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SQLServerConnectionPoolDataSource
/*    */   extends SQLServerDataSource
/*    */   implements ConnectionPoolDataSource
/*    */ {
/*    */   public PooledConnection getPooledConnection() throws SQLException {
/* 22 */     if (loggerExternal.isLoggable(Level.FINER))
/* 23 */       loggerExternal.entering(getClassNameLogging(), "getPooledConnection"); 
/* 24 */     PooledConnection pooledConnection = getPooledConnection(getUser(), getPassword());
/* 25 */     if (loggerExternal.isLoggable(Level.FINER))
/* 26 */       loggerExternal.exiting(getClassNameLogging(), "getPooledConnection", pooledConnection); 
/* 27 */     return pooledConnection;
/*    */   }
/*    */ 
/*    */   
/*    */   public PooledConnection getPooledConnection(String paramString1, String paramString2) throws SQLException {
/* 32 */     if (loggerExternal.isLoggable(Level.FINER))
/* 33 */       loggerExternal.entering(getClassNameLogging(), "getPooledConnection", new Object[] { paramString1, "Password not traced" }); 
/* 34 */     SQLServerPooledConnection sQLServerPooledConnection = new SQLServerPooledConnection(this, paramString1, paramString2);
/* 35 */     if (loggerExternal.isLoggable(Level.FINER))
/* 36 */       loggerExternal.exiting(getClassNameLogging(), "getPooledConnection", sQLServerPooledConnection); 
/* 37 */     return sQLServerPooledConnection;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public Reference getReference() {
/* 44 */     if (loggerExternal.isLoggable(Level.FINER))
/* 45 */       loggerExternal.entering(getClassNameLogging(), "getReference"); 
/* 46 */     Reference reference = getReferenceInternal("com.microsoft.sqlserver.jdbc.SQLServerConnectionPoolDataSource");
/* 47 */     if (loggerExternal.isLoggable(Level.FINER))
/* 48 */       loggerExternal.exiting(getClassNameLogging(), "getReference", reference); 
/* 49 */     return reference;
/*    */   }
/*    */   
/*    */   private Object writeReplace() throws ObjectStreamException {
/* 53 */     return new SerializationProxy(this);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private void readObject(ObjectInputStream paramObjectInputStream) throws InvalidObjectException {
/* 63 */     throw new InvalidObjectException("");
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static class SerializationProxy
/*    */     implements Serializable
/*    */   {
/*    */     private final Reference ref;
/*    */ 
/*    */     
/*    */     private static final long serialVersionUID = 654661379842314126L;
/*    */ 
/*    */     
/*    */     SerializationProxy(SQLServerConnectionPoolDataSource param1SQLServerConnectionPoolDataSource) {
/* 78 */       this.ref = param1SQLServerConnectionPoolDataSource.getReferenceInternal(null);
/*    */     }
/*    */     
/*    */     private Object readResolve() {
/* 82 */       SQLServerConnectionPoolDataSource sQLServerConnectionPoolDataSource = new SQLServerConnectionPoolDataSource();
/* 83 */       sQLServerConnectionPoolDataSource.initializeFromReference(this.ref);
/* 84 */       return sQLServerConnectionPoolDataSource;
/*    */     }
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/sqljdbc41.jar!/com/microsoft/sqlserver/jdbc/SQLServerConnectionPoolDataSource.class
 * Java compiler version: 7 (51.0)
 * JD-Core Version:       1.1.3
 */