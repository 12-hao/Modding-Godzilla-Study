/*    */ package jna.pty4j.windows;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WinPTYInputStream
/*    */   extends InputStream
/*    */ {
/*    */   private final WinPty myWinPty;
/*    */   private final NamedPipe myNamedPipe;
/*    */   
/*    */   public WinPTYInputStream(WinPty winPty, NamedPipe namedPipe) {
/* 19 */     this.myWinPty = winPty;
/* 20 */     this.myNamedPipe = namedPipe;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int read() throws IOException {
/* 30 */     byte[] b = new byte[1];
/* 31 */     if (1 != read(b, 0, 1)) {
/* 32 */       return -1;
/*    */     }
/* 34 */     return b[0];
/*    */   }
/*    */ 
/*    */   
/*    */   public int read(byte[] buf, int off, int len) throws IOException {
/* 39 */     return this.myNamedPipe.read(buf, off, len);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void close() throws IOException {
/* 53 */     this.myWinPty.decrementOpenInputStreamCount();
/* 54 */     this.myNamedPipe.close();
/*    */   }
/*    */ 
/*    */   
/*    */   public int available() throws IOException {
/* 59 */     return this.myNamedPipe.available();
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/jna/pty4j/windows/WinPTYInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */