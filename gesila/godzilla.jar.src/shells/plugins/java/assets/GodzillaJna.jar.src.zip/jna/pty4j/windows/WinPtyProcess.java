/*     */ package jna.pty4j.windows;
/*     */ 
/*     */ import com.sun.jna.platform.win32.Advapi32Util;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PipedInputStream;
/*     */ import java.io.PipedOutputStream;
/*     */ import java.util.Arrays;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import jna.pty4j.PtyProcess;
/*     */ import jna.pty4j.PtyProcessOptions;
/*     */ import jna.pty4j.WinSize;
/*     */ 
/*     */ public class WinPtyProcess
/*     */   extends PtyProcess {
/*     */   private WinPty myWinPty;
/*     */   private InputStream myInputStream;
/*     */   private InputStream myErrorStream;
/*     */   private WinPTYOutputStream myOutputStream;
/*     */   
/*     */   @Deprecated
/*     */   public WinPtyProcess(String[] command, String[] environment, String workingDirectory, boolean consoleMode) throws IOException {
/*  27 */     this(command, convertEnvironment(environment), workingDirectory, consoleMode);
/*     */   }
/*     */   private List<String> myCommand; private boolean myUsedInputStream = false; private boolean myUsedOutputStream = false; private boolean myUsedErrorStream = false;
/*     */   private static String convertEnvironment(String[] environment) {
/*  31 */     StringBuilder envString = new StringBuilder();
/*  32 */     for (String s : environment) {
/*  33 */       envString.append(s).append(false);
/*     */     }
/*  35 */     envString.append(false);
/*  36 */     return envString.toString();
/*     */   }
/*     */   
/*     */   @Deprecated
/*     */   public WinPtyProcess(String[] command, String environment, String workingDirectory, boolean consoleMode) throws IOException {
/*  41 */     this(command, environment, workingDirectory, null, null, consoleMode, false);
/*     */   }
/*     */   
/*     */   public WinPtyProcess(String commandLine) throws IOException {
/*     */     try {
/*  46 */       HashMap<String, String> envMap = new HashMap<String, String>(System.getenv());
/*  47 */       envMap.put("TERM", "xterm");
/*  48 */       this
/*  49 */         .myWinPty = new WinPty(commandLine, null, convertEnvironment(envMap), false, Integer.valueOf(200), Integer.valueOf(100), true);
/*  50 */     } catch (WinPtyException e) {
/*  51 */       throw new IOException("Couldn't create PTY", e);
/*     */     } 
/*  53 */     this.myInputStream = new WinPTYInputStream(this.myWinPty, this.myWinPty.getInputPipe());
/*  54 */     this.myOutputStream = new WinPTYOutputStream(this.myWinPty, this.myWinPty.getOutputPipe(), true, true);
/*  55 */     this.myErrorStream = new WinPTYInputStream(this.myWinPty, this.myWinPty.getErrorPipe());
/*     */     
/*  57 */     PipedOutputStream out = new PipedOutputStream();
/*  58 */     PipedInputStream in = new PipedInputStream(out);
/*     */     
/*  60 */     (new RedirectStream(out, this.myInputStream)).start();
/*  61 */     (new RedirectStream(out, this.myErrorStream)).start();
/*     */     
/*  63 */     this.myInputStream = in;
/*  64 */     this.myErrorStream = in;
/*     */   }
/*     */ 
/*     */   
/*     */   public WinPtyProcess(PtyProcessOptions options, boolean consoleMode) throws IOException {
/*  69 */     this(options.getCommand(), 
/*  70 */         convertEnvironment(options.getEnvironment()), options
/*  71 */         .getDirectory(), options
/*  72 */         .getInitialColumns(), options
/*  73 */         .getInitialRows(), consoleMode, options
/*     */         
/*  75 */         .isWindowsAnsiColorEnabled());
/*     */   }
/*     */ 
/*     */   
/*     */   private static String convertEnvironment(Map<String, String> environment) {
/*  80 */     return Advapi32Util.getEnvironmentBlock((environment != null) ? environment : Collections.emptyMap());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private WinPtyProcess(String[] command, String environment, String workingDirectory, Integer initialColumns, Integer initialRows, boolean consoleMode, boolean enableAnsiColor) throws IOException {
/*  90 */     this.myCommand = Arrays.asList(command);
/*     */     try {
/*  92 */       this.myWinPty = new WinPty(joinCmdArgs(command), workingDirectory, environment, consoleMode, initialColumns, initialRows, enableAnsiColor);
/*     */     }
/*  94 */     catch (WinPtyException e) {
/*  95 */       throw new IOException("Couldn't create PTY", e);
/*     */     } 
/*  97 */     this.myInputStream = new WinPTYInputStream(this.myWinPty, this.myWinPty.getInputPipe());
/*  98 */     this.myOutputStream = new WinPTYOutputStream(this.myWinPty, this.myWinPty.getOutputPipe(), consoleMode, true);
/*  99 */     if (!consoleMode) {
/* 100 */       this.myErrorStream = new InputStream()
/*     */         {
/*     */           public int read() {
/* 103 */             return -1;
/*     */           }
/*     */         };
/*     */     } else {
/* 107 */       this.myErrorStream = new WinPTYInputStream(this.myWinPty, this.myWinPty.getErrorPipe());
/*     */     } 
/*     */   }
/*     */   
/*     */   static String joinCmdArgs(String[] commands) {
/* 112 */     StringBuilder cmd = new StringBuilder();
/* 113 */     boolean flag = false;
/* 114 */     for (String s : commands) {
/* 115 */       if (flag) {
/* 116 */         cmd.append(' ');
/*     */       } else {
/* 118 */         flag = true;
/*     */       } 
/*     */       
/* 121 */       if (s.indexOf(' ') >= 0 || s.indexOf('\t') >= 0) {
/* 122 */         if (s.charAt(0) != '"') {
/* 123 */           cmd.append('"').append(s);
/*     */           
/* 125 */           if (s.endsWith("\\")) {
/* 126 */             cmd.append("\\");
/*     */           }
/* 128 */           cmd.append('"');
/*     */         } else {
/* 130 */           cmd.append(s);
/*     */         } 
/*     */       } else {
/* 133 */         cmd.append(s);
/*     */       } 
/*     */     } 
/*     */     
/* 137 */     return cmd.toString();
/*     */   }
/*     */   
/*     */   public List<String> getCommand() {
/* 141 */     return this.myCommand;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isRunning() {
/* 146 */     return this.myWinPty.isRunning();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setWinSize(WinSize winSize) {
/*     */     try {
/* 152 */       this.myWinPty.setWinSize(winSize);
/*     */     }
/* 154 */     catch (IOException e) {
/* 155 */       throw new IllegalStateException(e);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public WinSize getWinSize() throws IOException {
/* 161 */     return this.myWinPty.getWinSize();
/*     */   }
/*     */ 
/*     */   
/*     */   public int getPid() {
/* 166 */     return this.myWinPty.getChildProcessId();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getWorkingDirectory() throws IOException {
/* 171 */     return this.myWinPty.getWorkingDirectory();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConsoleProcessCount() throws IOException {
/* 180 */     return this.myWinPty.getConsoleProcessList();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized OutputStream getOutputStream() {
/* 185 */     this.myUsedOutputStream = true;
/* 186 */     return this.myOutputStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized InputStream getInputStream() {
/* 191 */     this.myUsedInputStream = true;
/* 192 */     return this.myInputStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized InputStream getErrorStream() {
/* 197 */     this.myUsedErrorStream = true;
/* 198 */     return this.myErrorStream;
/*     */   }
/*     */ 
/*     */   
/*     */   public int waitFor() throws InterruptedException {
/* 203 */     return this.myWinPty.waitFor();
/*     */   }
/*     */   
/*     */   public int getChildProcessId() {
/* 207 */     return this.myWinPty.getChildProcessId();
/*     */   }
/*     */ 
/*     */   
/*     */   public int exitValue() {
/* 212 */     return this.myWinPty.exitValue();
/*     */   }
/*     */ 
/*     */   
/*     */   public synchronized void destroy() {
/* 217 */     this.myWinPty.close();
/*     */ 
/*     */     
/* 220 */     if (!this.myUsedInputStream) {
/*     */       try {
/* 222 */         this.myInputStream.close();
/* 223 */       } catch (IOException iOException) {}
/*     */     }
/* 225 */     if (!this.myUsedOutputStream) {
/*     */       try {
/* 227 */         this.myOutputStream.close();
/* 228 */       } catch (IOException iOException) {}
/*     */     }
/* 230 */     if (!this.myUsedErrorStream)
/*     */       try {
/* 232 */         this.myErrorStream.close();
/* 233 */       } catch (IOException iOException) {} 
/*     */   }
/*     */   
/*     */   class RedirectStream extends Thread {
/*     */     private OutputStream out;
/*     */     private InputStream in;
/*     */     
/*     */     public RedirectStream(OutputStream outputStream, InputStream inputStream) {
/* 241 */       this.out = outputStream;
/* 242 */       this.in = inputStream;
/*     */     }
/*     */     public void dup() {
/* 245 */       if (this.out != null && this.in != null) {
/* 246 */         byte[] buffer = new byte[521];
/* 247 */         int readNum = 0;
/*     */         try {
/* 249 */           while ((readNum = this.in.read(buffer)) > -1) {
/* 250 */             this.out.write(buffer, 0, readNum);
/* 251 */             this.out.flush();
/*     */           } 
/* 253 */         } catch (Exception exception) {}
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void run() {
/* 261 */       dup();
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/jna/pty4j/windows/WinPtyProcess.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */