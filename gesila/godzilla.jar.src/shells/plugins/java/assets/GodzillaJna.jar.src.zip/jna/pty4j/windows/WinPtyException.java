/*   */ package jna.pty4j.windows;
/*   */ 
/*   */ public class WinPtyException
/*   */   extends Exception {
/*   */   WinPtyException(String message) {
/* 6 */     super(message);
/*   */   }
/*   */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/jna/pty4j/windows/WinPtyException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */