/*     */ package jna.pty4j.windows;
/*     */ 
/*     */ import com.sun.jna.Memory;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.platform.win32.Kernel32;
/*     */ import com.sun.jna.platform.win32.WinBase;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import java.io.IOException;
/*     */ import java.util.concurrent.locks.ReentrantLock;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class NamedPipe
/*     */ {
/*     */   private WinNT.HANDLE myHandle;
/*     */   boolean myCloseHandleOnFinalize;
/*     */   private WinNT.HANDLE shutdownEvent;
/*     */   private volatile boolean shutdownFlag = false;
/*     */   private volatile boolean myFinalizedFlag = false;
/*  22 */   private ReentrantLock readLock = new ReentrantLock();
/*  23 */   private ReentrantLock writeLock = new ReentrantLock();
/*     */   
/*  25 */   private Memory readBuffer = new Memory(16384L);
/*  26 */   private Memory writeBuffer = new Memory(16384L);
/*     */   
/*     */   private WinNT.HANDLE readEvent;
/*     */   
/*     */   private WinNT.HANDLE writeEvent;
/*     */   
/*     */   private WinNT.HANDLE[] readWaitHandles;
/*     */   private WinNT.HANDLE[] writeWaitHandles;
/*  34 */   private IntByReference readActual = new IntByReference();
/*  35 */   private IntByReference writeActual = new IntByReference();
/*  36 */   private IntByReference peekActual = new IntByReference();
/*     */   
/*  38 */   private WinBase.OVERLAPPED readOver = new WinBase.OVERLAPPED();
/*  39 */   private WinBase.OVERLAPPED writeOver = new WinBase.OVERLAPPED();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NamedPipe(WinNT.HANDLE handle, boolean closeHandleOnFinalize) {
/*  47 */     this.myHandle = handle;
/*  48 */     this.myCloseHandleOnFinalize = closeHandleOnFinalize;
/*  49 */     this.shutdownEvent = Kernel32.INSTANCE.CreateEvent(null, true, false, null);
/*  50 */     this.readEvent = Kernel32.INSTANCE.CreateEvent(null, true, false, null);
/*  51 */     this.writeEvent = Kernel32.INSTANCE.CreateEvent(null, true, false, null);
/*  52 */     this.readWaitHandles = new WinNT.HANDLE[] { this.readEvent, this.shutdownEvent };
/*  53 */     this.writeWaitHandles = new WinNT.HANDLE[] { this.writeEvent, this.shutdownEvent };
/*     */   }
/*     */   
/*     */   public static NamedPipe connectToServer(String name, int desiredAccess) throws IOException {
/*  57 */     WinNT.HANDLE handle = Kernel32.INSTANCE.CreateFile(name, desiredAccess, 0, null, 3, 0, null);
/*     */     
/*  59 */     if (handle == WinBase.INVALID_HANDLE_VALUE) {
/*  60 */       throw new IOException("Error connecting to pipe '" + name + "': " + Native.getLastError());
/*     */     }
/*  62 */     return new NamedPipe(handle, true);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int read(byte[] buf, int off, int len) {
/*  70 */     if (buf == null) {
/*  71 */       throw new NullPointerException();
/*     */     }
/*  73 */     if (off < 0 || len < 0 || len > buf.length - off) {
/*  74 */       throw new IndexOutOfBoundsException();
/*     */     }
/*  76 */     this.readLock.lock();
/*     */     try {
/*  78 */       if (this.shutdownFlag) {
/*  79 */         return -1;
/*     */       }
/*  81 */       if (len == 0) {
/*  82 */         return 0;
/*     */       }
/*  84 */       if (this.readBuffer.size() < len) {
/*  85 */         this.readBuffer = new Memory(len);
/*     */       }
/*  87 */       this.readOver.hEvent = this.readEvent;
/*  88 */       this.readOver.write();
/*  89 */       this.readActual.setValue(0);
/*  90 */       boolean success = WinPty.KERNEL32.ReadFile(this.myHandle, (Pointer)this.readBuffer, len, this.readActual, this.readOver.getPointer());
/*  91 */       if (!success && Native.getLastError() == 997) {
/*  92 */         int waitRet = Kernel32.INSTANCE.WaitForMultipleObjects(this.readWaitHandles.length, this.readWaitHandles, false, -1);
/*     */         
/*  94 */         if (waitRet != 0) {
/*  95 */           WinPty.KERNEL32.CancelIo(this.myHandle);
/*     */         }
/*  97 */         success = WinPty.KERNEL32.GetOverlappedResult(this.myHandle, this.readOver.getPointer(), this.readActual, true);
/*     */       } 
/*  99 */       int actual = this.readActual.getValue();
/* 100 */       if (!success || actual <= 0) {
/* 101 */         return -1;
/*     */       }
/* 103 */       this.readBuffer.read(0L, buf, off, actual);
/* 104 */       return actual;
/*     */     } finally {
/* 106 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] buf, int off, int len) {
/* 114 */     if (buf == null) {
/* 115 */       throw new NullPointerException();
/*     */     }
/* 117 */     if (off < 0 || len < 0 || len > buf.length - off) {
/* 118 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 120 */     this.writeLock.lock();
/*     */     try {
/* 122 */       if (this.shutdownFlag) {
/*     */         return;
/*     */       }
/* 125 */       if (len == 0) {
/*     */         return;
/*     */       }
/* 128 */       if (this.writeBuffer.size() < len) {
/* 129 */         this.writeBuffer = new Memory(len);
/*     */       }
/* 131 */       this.writeBuffer.write(0L, buf, off, len);
/* 132 */       this.writeOver.hEvent = this.writeEvent;
/* 133 */       this.writeOver.write();
/* 134 */       this.writeActual.setValue(0);
/* 135 */       boolean success = WinPty.KERNEL32.WriteFile(this.myHandle, (Pointer)this.writeBuffer, len, this.writeActual, this.writeOver.getPointer());
/* 136 */       if (!success && Native.getLastError() == 997) {
/* 137 */         int waitRet = Kernel32.INSTANCE.WaitForMultipleObjects(this.writeWaitHandles.length, this.writeWaitHandles, false, -1);
/*     */         
/* 139 */         if (waitRet != 0) {
/* 140 */           WinPty.KERNEL32.CancelIo(this.myHandle);
/*     */         }
/* 142 */         WinPty.KERNEL32.GetOverlappedResult(this.myHandle, this.writeOver.getPointer(), this.writeActual, true);
/*     */       } 
/*     */     } finally {
/* 145 */       this.writeLock.unlock();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int available() throws IOException {
/* 150 */     this.readLock.lock();
/*     */     try {
/* 152 */       if (this.shutdownFlag) {
/* 153 */         return -1;
/*     */       }
/* 155 */       this.peekActual.setValue(0);
/* 156 */       if (!WinPty.KERNEL32.PeekNamedPipe(this.myHandle, null, 0, null, this.peekActual, null)) {
/* 157 */         throw new IOException("PeekNamedPipe failed");
/*     */       }
/* 159 */       return this.peekActual.getValue();
/*     */     } finally {
/* 161 */       this.readLock.unlock();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void markClosed() {
/* 169 */     closeImpl();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void close() throws IOException {
/* 181 */     if (!closeImpl()) {
/*     */       return;
/*     */     }
/* 184 */     if (!Kernel32.INSTANCE.CloseHandle(this.myHandle)) {
/* 185 */       throw new IOException("Close error:" + Native.getLastError());
/*     */     }
/*     */   }
/*     */   
/*     */   private synchronized boolean closeImpl() {
/* 190 */     if (this.shutdownFlag)
/*     */     {
/* 192 */       return false;
/*     */     }
/* 194 */     this.shutdownFlag = true;
/* 195 */     Kernel32.INSTANCE.SetEvent(this.shutdownEvent);
/* 196 */     if (!this.myFinalizedFlag) {
/* 197 */       this.readLock.lock();
/* 198 */       this.writeLock.lock();
/* 199 */       this.writeLock.unlock();
/* 200 */       this.readLock.unlock();
/*     */     } 
/* 202 */     Kernel32.INSTANCE.CloseHandle(this.shutdownEvent);
/* 203 */     Kernel32.INSTANCE.CloseHandle(this.readEvent);
/* 204 */     Kernel32.INSTANCE.CloseHandle(this.writeEvent);
/* 205 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void finalize() throws Throwable {
/* 215 */     this.myFinalizedFlag = true;
/* 216 */     if (this.myCloseHandleOnFinalize) {
/* 217 */       close();
/*     */     }
/* 219 */     super.finalize();
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/jna/pty4j/windows/NamedPipe.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */