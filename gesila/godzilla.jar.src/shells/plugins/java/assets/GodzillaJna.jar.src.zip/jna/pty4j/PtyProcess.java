/*    */ package jna.pty4j;
/*    */ 
/*    */ import com.sun.jna.Platform;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.Map;
/*    */ import jna.pty4j.windows.WinPtyProcess;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class PtyProcess
/*    */   extends Process
/*    */ {
/*    */   public abstract boolean isRunning();
/*    */   
/*    */   public abstract void setWinSize(WinSize paramWinSize);
/*    */   
/*    */   public abstract WinSize getWinSize() throws IOException;
/*    */   
/*    */   public long pid() {
/* 36 */     return getPid();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract int getPid();
/*    */ 
/*    */   
/*    */   public byte getEnterKeyCode() {
/* 45 */     return 13;
/*    */   }
/*    */   
/*    */   public static PtyProcess exec(String[] command) throws IOException {
/* 49 */     return exec(command, (Map<String, String>)null);
/*    */   }
/*    */   
/*    */   public static PtyProcess exec(String[] command, Map<String, String> environment) throws IOException {
/* 53 */     return exec(command, environment, null, false, false, null);
/*    */   }
/*    */   
/*    */   public static PtyProcess exec(String[] command, Map<String, String> environment, String workingDirectory) throws IOException {
/* 57 */     return exec(command, environment, workingDirectory, false, false, null);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static PtyProcess exec(String[] command, String[] environment) throws IOException {
/* 62 */     return exec(command, environment, (String)null, false);
/*    */   }
/*    */   
/*    */   @Deprecated
/*    */   public static PtyProcess exec(String[] command, String[] environment, String workingDirectory, boolean console) throws IOException {
/* 67 */     if (Platform.isWindows()) {
/* 68 */       return (PtyProcess)new WinPtyProcess(command, environment, workingDirectory, console);
/*    */     }
/* 70 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public static PtyProcess exec(String[] command, Map<String, String> environment, String workingDirectory, boolean console) throws IOException {
/* 75 */     return exec(command, environment, workingDirectory, console, false, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static PtyProcess exec(String[] command, Map<String, String> environment, String workingDirectory, boolean console, boolean cygwin, File logFile) throws IOException {
/* 85 */     PtyProcessBuilder builder = (new PtyProcessBuilder(command)).setEnvironment(environment).setDirectory(workingDirectory).setConsole(console).setCygwin(cygwin).setLogFile(logFile);
/* 86 */     return builder.start();
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/jna/pty4j/PtyProcess.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */