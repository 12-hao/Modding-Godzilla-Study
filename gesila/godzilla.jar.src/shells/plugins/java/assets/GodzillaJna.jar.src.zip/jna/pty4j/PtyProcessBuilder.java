/*     */ package jna.pty4j;
/*     */ 
/*     */ import com.sun.jna.Platform;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Map;
/*     */ import jna.pty4j.windows.WinPtyProcess;
/*     */ 
/*     */ 
/*     */ public class PtyProcessBuilder
/*     */ {
/*     */   private String[] myCommand;
/*     */   private Map<String, String> myEnvironment;
/*     */   private String myDirectory;
/*     */   private boolean myConsole;
/*     */   private boolean myCygwin;
/*     */   private File myLogFile;
/*     */   private boolean myRedirectErrorStream = false;
/*     */   private Integer myInitialColumns;
/*     */   private Integer myInitialRows;
/*     */   private boolean myWindowsAnsiColorEnabled = false;
/*     */   private boolean myUnixOpenTtyToPreserveOutputAfterTermination = false;
/*     */   
/*     */   public PtyProcessBuilder() {}
/*     */   
/*     */   public PtyProcessBuilder(String[] command) {
/*  27 */     this.myCommand = command;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtyProcessBuilder setCommand(String[] command) {
/*  32 */     this.myCommand = command;
/*  33 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtyProcessBuilder setEnvironment(Map<String, String> environment) {
/*  38 */     this.myEnvironment = environment;
/*  39 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtyProcessBuilder setDirectory(String directory) {
/*  44 */     this.myDirectory = directory;
/*  45 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtyProcessBuilder setConsole(boolean console) {
/*  50 */     this.myConsole = console;
/*  51 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtyProcessBuilder setCygwin(boolean cygwin) {
/*  56 */     this.myCygwin = cygwin;
/*  57 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtyProcessBuilder setLogFile(File logFile) {
/*  62 */     this.myLogFile = logFile;
/*  63 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtyProcessBuilder setRedirectErrorStream(boolean redirectErrorStream) {
/*  68 */     this.myRedirectErrorStream = redirectErrorStream;
/*  69 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtyProcessBuilder setInitialColumns(Integer initialColumns) {
/*  74 */     this.myInitialColumns = initialColumns;
/*  75 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtyProcessBuilder setInitialRows(Integer initialRows) {
/*  80 */     this.myInitialRows = initialRows;
/*  81 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtyProcessBuilder setWindowsAnsiColorEnabled(boolean windowsAnsiColorEnabled) {
/*  86 */     this.myWindowsAnsiColorEnabled = windowsAnsiColorEnabled;
/*  87 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PtyProcessBuilder setUnixOpenTtyToPreserveOutputAfterTermination(boolean unixOpenTtyToPreserveOutputAfterTermination) {
/* 100 */     this.myUnixOpenTtyToPreserveOutputAfterTermination = unixOpenTtyToPreserveOutputAfterTermination;
/* 101 */     return this;
/*     */   }
/*     */ 
/*     */   
/*     */   public PtyProcess start() throws IOException {
/* 106 */     if (this.myEnvironment == null) {
/* 107 */       this.myEnvironment = System.getenv();
/*     */     }
/* 109 */     PtyProcessOptions options = new PtyProcessOptions(this.myCommand, this.myEnvironment, this.myDirectory, this.myRedirectErrorStream, this.myInitialColumns, this.myInitialRows, this.myWindowsAnsiColorEnabled, this.myUnixOpenTtyToPreserveOutputAfterTermination);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 117 */     if (Platform.isWindows()) {
/* 118 */       return (PtyProcess)new WinPtyProcess(options, this.myConsole);
/*     */     }
/* 120 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/jna/pty4j/PtyProcessBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */