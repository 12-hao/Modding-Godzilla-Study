/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class W32Errors
/*     */   implements WinError
/*     */ {
/*     */   public static final boolean SUCCEEDED(int hr) {
/*  30 */     return (hr >= 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean FAILED(int hr) {
/*  40 */     return (hr < 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean SUCCEEDED(WinNT.HRESULT hr) {
/*  50 */     return (hr == null || SUCCEEDED(hr.intValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final boolean FAILED(WinNT.HRESULT hr) {
/*  60 */     return (hr != null && FAILED(hr.intValue()));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int HRESULT_CODE(int hr) {
/*  70 */     return hr & 0xFFFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SCODE_CODE(int sc) {
/*  80 */     return sc & 0xFFFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int HRESULT_FACILITY(int hr) {
/*  90 */     return (hr >>= 16) & 0x1FFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int SCODE_FACILITY(short sc) {
/* 100 */     return (sc = (short)(sc >> 16)) & 0x1FFF;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static short HRESULT_SEVERITY(int hr) {
/* 110 */     return (short)((hr >>= 31) & 0x1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static short SCODE_SEVERITY(short sc) {
/* 120 */     return (short)((sc = (short)(sc >> 31)) & 0x1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int MAKE_HRESULT(short sev, short fac, short code) {
/* 132 */     return sev << 31 | fac << 16 | code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int MAKE_SCODE(short sev, short fac, short code) {
/* 144 */     return sev << 31 | fac << 16 | code;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final WinNT.HRESULT HRESULT_FROM_WIN32(int x) {
/* 156 */     int f = 7;
/* 157 */     return new WinNT.HRESULT((x <= 0) ? x : (x & 0xFFFF | (f <<= 16) | Integer.MIN_VALUE));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int FILTER_HRESULT_FROM_FLT_NTSTATUS(int x) {
/* 170 */     int f = 31;
/* 171 */     return x & 0x8000FFFF | (f <<= 16);
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/W32Errors.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */