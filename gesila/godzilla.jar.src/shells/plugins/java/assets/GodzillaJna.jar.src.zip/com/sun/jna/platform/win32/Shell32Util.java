/*    */ package com.sun.jna.platform.win32;
/*    */ 
/*    */ import com.sun.jna.Native;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class Shell32Util
/*    */ {
/*    */   public static String getFolderPath(WinDef.HWND hwnd, int nFolder, WinDef.DWORD dwFlags) {
/* 39 */     char[] pszPath = new char[260];
/* 40 */     WinNT.HRESULT hr = Shell32.INSTANCE.SHGetFolderPath(hwnd, nFolder, null, dwFlags, pszPath);
/*    */ 
/*    */     
/* 43 */     if (!hr.equals(W32Errors.S_OK)) {
/* 44 */       throw new Win32Exception(hr);
/*    */     }
/* 46 */     return Native.toString(pszPath);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static String getFolderPath(int nFolder) {
/* 57 */     return getFolderPath(null, nFolder, ShlObj.SHGFP_TYPE_CURRENT);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final String getSpecialFolderPath(int csidl, boolean create) {
/* 71 */     char[] pszPath = new char[260];
/* 72 */     if (!Shell32.INSTANCE.SHGetSpecialFolderPath(null, pszPath, csidl, create))
/* 73 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError()); 
/* 74 */     return Native.toString(pszPath);
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/Shell32Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */