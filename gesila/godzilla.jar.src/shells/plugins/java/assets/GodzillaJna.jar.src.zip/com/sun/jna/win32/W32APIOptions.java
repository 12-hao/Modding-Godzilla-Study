/*    */ package com.sun.jna.win32;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public interface W32APIOptions
/*    */   extends StdCallLibrary {
/*  8 */   public static final Map UNICODE_OPTIONS = new HashMap<Object, Object>()
/*    */     {
/*    */     
/*    */     };
/*    */ 
/*    */ 
/*    */   
/* 15 */   public static final Map ASCII_OPTIONS = new HashMap<Object, Object>()
/*    */     {
/*    */     
/*    */     };
/*    */ 
/*    */   
/* 21 */   public static final Map DEFAULT_OPTIONS = Boolean.getBoolean("w32.ascii") ? ASCII_OPTIONS : UNICODE_OPTIONS;
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/win32/W32APIOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */