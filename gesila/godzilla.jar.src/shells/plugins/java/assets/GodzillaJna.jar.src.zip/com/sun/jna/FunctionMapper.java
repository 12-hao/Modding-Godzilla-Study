package com.sun.jna;

import java.lang.reflect.Method;

public interface FunctionMapper {
  String getFunctionName(NativeLibrary paramNativeLibrary, Method paramMethod);
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/FunctionMapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */