/*    */ package com.sun.jna;
/*    */ 
/*    */ import java.nio.CharBuffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class WString
/*    */   implements CharSequence, Comparable
/*    */ {
/*    */   private String string;
/*    */   
/*    */   public WString(String s) {
/* 23 */     if (s == null) throw new NullPointerException("String initializer must be non-null"); 
/* 24 */     this.string = s;
/*    */   }
/*    */   public String toString() {
/* 27 */     return this.string;
/*    */   }
/*    */   public boolean equals(Object o) {
/* 30 */     return (o instanceof WString && toString().equals(o.toString()));
/*    */   }
/*    */   public int hashCode() {
/* 33 */     return toString().hashCode();
/*    */   }
/*    */   public int compareTo(Object o) {
/* 36 */     return toString().compareTo(o.toString());
/*    */   }
/*    */   public int length() {
/* 39 */     return toString().length();
/*    */   }
/*    */   public char charAt(int index) {
/* 42 */     return toString().charAt(index);
/*    */   }
/*    */   public CharSequence subSequence(int start, int end) {
/* 45 */     return CharBuffer.wrap(toString()).subSequence(start, end);
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/WString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */