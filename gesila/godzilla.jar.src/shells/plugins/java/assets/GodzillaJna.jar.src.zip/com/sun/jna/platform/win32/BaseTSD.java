/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.IntegerType;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.ptr.ByReference;
/*     */ import com.sun.jna.win32.StdCallLibrary;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface BaseTSD
/*     */   extends StdCallLibrary
/*     */ {
/*     */   public static class LONG_PTR
/*     */     extends IntegerType
/*     */   {
/*     */     public LONG_PTR() {
/*  32 */       this(0L);
/*     */     }
/*     */     
/*     */     public LONG_PTR(long value) {
/*  36 */       super(Pointer.SIZE, value);
/*     */     }
/*     */     
/*     */     public Pointer toPointer() {
/*  40 */       return Pointer.createConstant(longValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class SSIZE_T
/*     */     extends LONG_PTR
/*     */   {
/*     */     public SSIZE_T() {
/*  49 */       this(0L);
/*     */     }
/*     */     
/*     */     public SSIZE_T(long value) {
/*  53 */       super(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ULONG_PTR
/*     */     extends IntegerType
/*     */   {
/*     */     public ULONG_PTR() {
/*  62 */       this(0L);
/*     */     }
/*     */     
/*     */     public ULONG_PTR(long value) {
/*  66 */       super(Pointer.SIZE, value, true);
/*     */     }
/*     */     
/*     */     public Pointer toPointer() {
/*  70 */       return Pointer.createConstant(longValue());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class ULONG_PTRByReference
/*     */     extends ByReference
/*     */   {
/*     */     public ULONG_PTRByReference() {
/*  79 */       this(new BaseTSD.ULONG_PTR(0L));
/*     */     }
/*     */     public ULONG_PTRByReference(BaseTSD.ULONG_PTR value) {
/*  82 */       super(Pointer.SIZE);
/*  83 */       setValue(value);
/*     */     }
/*     */     public void setValue(BaseTSD.ULONG_PTR value) {
/*  86 */       if (Pointer.SIZE == 4) {
/*  87 */         getPointer().setInt(0L, value.intValue());
/*     */       } else {
/*     */         
/*  90 */         getPointer().setLong(0L, value.longValue());
/*     */       } 
/*     */     }
/*     */     public BaseTSD.ULONG_PTR getValue() {
/*  94 */       return new BaseTSD.ULONG_PTR((Pointer.SIZE == 4) ? getPointer().getInt(0L) : getPointer().getLong(0L));
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class DWORD_PTR
/*     */     extends IntegerType
/*     */   {
/*     */     public DWORD_PTR() {
/* 106 */       this(0L);
/*     */     }
/*     */     
/*     */     public DWORD_PTR(long value) {
/* 110 */       super(Pointer.SIZE, value);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class SIZE_T
/*     */     extends ULONG_PTR
/*     */   {
/*     */     public SIZE_T() {
/* 120 */       this(0L);
/*     */     }
/*     */     
/*     */     public SIZE_T(long value) {
/* 124 */       super(value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/BaseTSD.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */