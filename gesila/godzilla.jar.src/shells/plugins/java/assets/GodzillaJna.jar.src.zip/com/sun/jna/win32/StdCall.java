package com.sun.jna.win32;

import com.sun.jna.AltCallingConvention;

public interface StdCall extends AltCallingConvention {}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/win32/StdCall.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */