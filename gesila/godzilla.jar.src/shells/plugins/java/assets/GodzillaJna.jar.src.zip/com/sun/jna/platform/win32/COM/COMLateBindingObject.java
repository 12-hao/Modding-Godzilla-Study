/*     */ package com.sun.jna.platform.win32.COM;
/*     */ 
/*     */ import com.sun.jna.platform.win32.Guid;
/*     */ import com.sun.jna.platform.win32.OaIdl;
/*     */ import com.sun.jna.platform.win32.Variant;
/*     */ import com.sun.jna.platform.win32.WinDef;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class COMLateBindingObject
/*     */   extends COMBindingBaseObject
/*     */ {
/*     */   public COMLateBindingObject(IDispatch iDispatch) {
/*  39 */     super(iDispatch);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public COMLateBindingObject(Guid.CLSID clsid, boolean useActiveInstance) {
/*  51 */     super(clsid, useActiveInstance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public COMLateBindingObject(String progId, boolean useActiveInstance) throws COMException {
/*  66 */     super(progId, useActiveInstance);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IDispatch getAutomationProperty(String propertyName) {
/*  77 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/*  78 */     oleMethod(2, result, getIDispatch(), propertyName);
/*     */ 
/*     */     
/*  81 */     return (IDispatch)result.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IDispatch getAutomationProperty(String propertyName, COMLateBindingObject comObject) {
/*  95 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/*  96 */     oleMethod(2, result, comObject.getIDispatch(), propertyName);
/*     */ 
/*     */     
/*  99 */     return (IDispatch)result.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IDispatch getAutomationProperty(String propertyName, COMLateBindingObject comObject, Variant.VARIANT value) {
/* 115 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 116 */     oleMethod(2, result, comObject.getIDispatch(), propertyName, value);
/*     */ 
/*     */     
/* 119 */     return (IDispatch)result.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected IDispatch getAutomationProperty(String propertyName, IDispatch iDispatch) {
/* 133 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 134 */     oleMethod(2, result, getIDispatch(), propertyName);
/*     */ 
/*     */     
/* 137 */     return (IDispatch)result.getValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean getBooleanProperty(String propertyName) {
/* 148 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 149 */     oleMethod(2, result, getIDispatch(), propertyName);
/*     */ 
/*     */     
/* 152 */     return (((OaIdl.VARIANT_BOOL)result.getValue()).intValue() != 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Date getDateProperty(String propertyName) {
/* 163 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 164 */     oleMethod(2, result, getIDispatch(), propertyName);
/*     */ 
/*     */     
/* 167 */     return result.dateValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int getIntProperty(String propertyName) {
/* 178 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 179 */     oleMethod(2, result, getIDispatch(), propertyName);
/*     */ 
/*     */     
/* 182 */     return ((WinDef.LONG)result.getValue()).intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected short getShortProperty(String propertyName) {
/* 193 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 194 */     oleMethod(2, result, getIDispatch(), propertyName);
/*     */ 
/*     */     
/* 197 */     return ((WinDef.SHORT)result.getValue()).shortValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected String getStringProperty(String propertyName) {
/* 208 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 209 */     oleMethod(2, result, getIDispatch(), propertyName);
/*     */ 
/*     */     
/* 212 */     return result.getValue().toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Variant.VARIANT invoke(String methodName) {
/* 223 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 224 */     oleMethod(1, result, getIDispatch(), methodName);
/*     */ 
/*     */     
/* 227 */     return (Variant.VARIANT)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Variant.VARIANT invoke(String methodName, Variant.VARIANT arg) {
/* 240 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 241 */     oleMethod(1, result, getIDispatch(), methodName, arg);
/*     */ 
/*     */     
/* 244 */     return (Variant.VARIANT)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Variant.VARIANT invoke(String methodName, Variant.VARIANT[] args) {
/* 257 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 258 */     oleMethod(1, result, getIDispatch(), methodName, args);
/*     */ 
/*     */     
/* 261 */     return (Variant.VARIANT)result;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Variant.VARIANT invoke(String methodName, Variant.VARIANT arg1, Variant.VARIANT arg2) {
/* 276 */     return invoke(methodName, new Variant.VARIANT[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Variant.VARIANT invoke(String methodName, Variant.VARIANT arg1, Variant.VARIANT arg2, Variant.VARIANT arg3) {
/* 294 */     return invoke(methodName, new Variant.VARIANT[] { arg1, arg2, arg3 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Variant.VARIANT invoke(String methodName, Variant.VARIANT arg1, Variant.VARIANT arg2, Variant.VARIANT arg3, Variant.VARIANT arg4) {
/* 314 */     return invoke(methodName, new Variant.VARIANT[] { arg1, arg2, arg3, arg4 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName, IDispatch dispatch) {
/* 326 */     oleMethod(1, (Variant.VARIANT.ByReference)null, dispatch, methodName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName, COMLateBindingObject comObject) {
/* 339 */     oleMethod(1, (Variant.VARIANT.ByReference)null, comObject.getIDispatch(), methodName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName, IDispatch dispatch, Variant.VARIANT arg) {
/* 355 */     oleMethod(1, (Variant.VARIANT.ByReference)null, dispatch, methodName, arg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName, IDispatch dispatch, Variant.VARIANT arg1, Variant.VARIANT arg2) {
/* 372 */     oleMethod(1, (Variant.VARIANT.ByReference)null, dispatch, methodName, new Variant.VARIANT[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName, COMLateBindingObject comObject, Variant.VARIANT arg) {
/* 388 */     oleMethod(1, (Variant.VARIANT.ByReference)null, comObject.getIDispatch(), methodName, arg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName, IDispatch dispatch, Variant.VARIANT[] args) {
/* 404 */     oleMethod(1, (Variant.VARIANT.ByReference)null, dispatch, methodName, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName) {
/* 415 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 416 */     oleMethod(1, result, getIDispatch(), methodName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName, Variant.VARIANT arg) {
/* 429 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 430 */     oleMethod(1, result, getIDispatch(), methodName, arg);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName, Variant.VARIANT[] args) {
/* 443 */     Variant.VARIANT.ByReference result = new Variant.VARIANT.ByReference();
/* 444 */     oleMethod(1, result, getIDispatch(), methodName, args);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName, Variant.VARIANT arg1, Variant.VARIANT arg2) {
/* 459 */     invokeNoReply(methodName, new Variant.VARIANT[] { arg1, arg2 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName, Variant.VARIANT arg1, Variant.VARIANT arg2, Variant.VARIANT arg3) {
/* 476 */     invokeNoReply(methodName, new Variant.VARIANT[] { arg1, arg2, arg3 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void invokeNoReply(String methodName, Variant.VARIANT arg1, Variant.VARIANT arg2, Variant.VARIANT arg3, Variant.VARIANT arg4) {
/* 495 */     invokeNoReply(methodName, new Variant.VARIANT[] { arg1, arg2, arg3, arg4 });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setProperty(String propertyName, boolean value) {
/* 507 */     oleMethod(4, (Variant.VARIANT.ByReference)null, getIDispatch(), propertyName, new Variant.VARIANT(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setProperty(String propertyName, Date value) {
/* 520 */     oleMethod(4, (Variant.VARIANT.ByReference)null, getIDispatch(), propertyName, new Variant.VARIANT(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setProperty(String propertyName, IDispatch value) {
/* 533 */     oleMethod(4, (Variant.VARIANT.ByReference)null, getIDispatch(), propertyName, new Variant.VARIANT(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setProperty(String propertyName, int value) {
/* 546 */     oleMethod(4, (Variant.VARIANT.ByReference)null, getIDispatch(), propertyName, new Variant.VARIANT(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setProperty(String propertyName, short value) {
/* 559 */     oleMethod(4, (Variant.VARIANT.ByReference)null, getIDispatch(), propertyName, new Variant.VARIANT(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setProperty(String propertyName, String value) {
/* 572 */     oleMethod(4, (Variant.VARIANT.ByReference)null, getIDispatch(), propertyName, new Variant.VARIANT(value));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setProperty(String propertyName, IDispatch iDispatch, Variant.VARIANT value) {
/* 588 */     oleMethod(4, (Variant.VARIANT.ByReference)null, iDispatch, propertyName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void setProperty(String propertyName, COMLateBindingObject comObject, Variant.VARIANT value) {
/* 604 */     oleMethod(4, (Variant.VARIANT.ByReference)null, comObject.getIDispatch(), propertyName, value);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Variant.VARIANT toVariant() {
/* 614 */     return new Variant.VARIANT(getIDispatch());
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/COM/COMLateBindingObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */