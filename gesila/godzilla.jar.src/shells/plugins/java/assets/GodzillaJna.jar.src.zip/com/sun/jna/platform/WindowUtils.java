/*      */ package com.sun.jna.platform;
/*      */ 
/*      */ import com.sun.jna.Memory;
/*      */ import com.sun.jna.Native;
/*      */ import com.sun.jna.NativeLong;
/*      */ import com.sun.jna.Platform;
/*      */ import com.sun.jna.Pointer;
/*      */ import com.sun.jna.platform.unix.X11;
/*      */ import com.sun.jna.platform.win32.GDI32;
/*      */ import com.sun.jna.platform.win32.User32;
/*      */ import com.sun.jna.platform.win32.WinDef;
/*      */ import com.sun.jna.platform.win32.WinGDI;
/*      */ import com.sun.jna.platform.win32.WinNT;
/*      */ import com.sun.jna.platform.win32.WinUser;
/*      */ import com.sun.jna.ptr.ByteByReference;
/*      */ import com.sun.jna.ptr.IntByReference;
/*      */ import com.sun.jna.ptr.PointerByReference;
/*      */ import java.awt.AWTEvent;
/*      */ import java.awt.AlphaComposite;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Color;
/*      */ import java.awt.Component;
/*      */ import java.awt.Container;
/*      */ import java.awt.Dialog;
/*      */ import java.awt.Dimension;
/*      */ import java.awt.Frame;
/*      */ import java.awt.Graphics;
/*      */ import java.awt.Graphics2D;
/*      */ import java.awt.GraphicsConfiguration;
/*      */ import java.awt.GraphicsDevice;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.awt.Point;
/*      */ import java.awt.Rectangle;
/*      */ import java.awt.Shape;
/*      */ import java.awt.Toolkit;
/*      */ import java.awt.Window;
/*      */ import java.awt.event.AWTEventListener;
/*      */ import java.awt.event.ComponentEvent;
/*      */ import java.awt.event.ComponentListener;
/*      */ import java.awt.event.ContainerEvent;
/*      */ import java.awt.event.HierarchyEvent;
/*      */ import java.awt.event.HierarchyListener;
/*      */ import java.awt.event.MouseEvent;
/*      */ import java.awt.event.WindowAdapter;
/*      */ import java.awt.event.WindowEvent;
/*      */ import java.awt.geom.Area;
/*      */ import java.awt.geom.PathIterator;
/*      */ import java.awt.image.BufferedImage;
/*      */ import java.awt.image.Raster;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import javax.swing.Icon;
/*      */ import javax.swing.JComponent;
/*      */ import javax.swing.JLayeredPane;
/*      */ import javax.swing.JPanel;
/*      */ import javax.swing.JRootPane;
/*      */ import javax.swing.RootPaneContainer;
/*      */ import javax.swing.SwingUtilities;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class WindowUtils
/*      */ {
/*      */   private static final String TRANSPARENT_OLD_BG = "transparent-old-bg";
/*      */   private static final String TRANSPARENT_OLD_OPAQUE = "transparent-old-opaque";
/*      */   private static final String TRANSPARENT_ALPHA = "transparent-alpha";
/*  136 */   public static final Shape MASK_NONE = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class HeavyweightForcer
/*      */     extends Window
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private final boolean packed;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public HeavyweightForcer(Window parent) {
/*  158 */       super(parent);
/*  159 */       pack();
/*  160 */       this.packed = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isVisible() {
/*  167 */       return this.packed;
/*      */     }
/*      */     
/*      */     public Rectangle getBounds() {
/*  171 */       return getOwner().getBounds();
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   protected static class RepaintTrigger
/*      */     extends JComponent
/*      */   {
/*      */     private static final long serialVersionUID = 1L;
/*      */     
/*      */     protected class Listener
/*      */       extends WindowAdapter
/*      */       implements ComponentListener, HierarchyListener, AWTEventListener
/*      */     {
/*      */       public void windowOpened(WindowEvent e) {
/*  186 */         WindowUtils.RepaintTrigger.this.repaint();
/*      */       }
/*      */       
/*      */       public void componentHidden(ComponentEvent e) {}
/*      */       
/*      */       public void componentMoved(ComponentEvent e) {}
/*      */       
/*      */       public void componentResized(ComponentEvent e) {
/*  194 */         WindowUtils.RepaintTrigger.this.setSize(WindowUtils.RepaintTrigger.this.getParent().getSize());
/*  195 */         WindowUtils.RepaintTrigger.this.repaint();
/*      */       }
/*      */       
/*      */       public void componentShown(ComponentEvent e) {
/*  199 */         WindowUtils.RepaintTrigger.this.repaint();
/*      */       }
/*      */       
/*      */       public void hierarchyChanged(HierarchyEvent e) {
/*  203 */         WindowUtils.RepaintTrigger.this.repaint();
/*      */       }
/*      */       
/*      */       public void eventDispatched(AWTEvent e) {
/*  207 */         if (e instanceof MouseEvent) {
/*  208 */           Component src = ((MouseEvent)e).getComponent();
/*  209 */           if (src != null && SwingUtilities.isDescendingFrom(src, WindowUtils.RepaintTrigger.this.content)) {
/*      */             
/*  211 */             MouseEvent me = SwingUtilities.convertMouseEvent(src, (MouseEvent)e, WindowUtils.RepaintTrigger.this.content);
/*  212 */             Component c = SwingUtilities.getDeepestComponentAt(WindowUtils.RepaintTrigger.this.content, me.getX(), me.getY());
/*  213 */             if (c != null) {
/*  214 */               WindowUtils.RepaintTrigger.this.setCursor(c.getCursor());
/*      */             }
/*      */           } 
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*  221 */     private final Listener listener = createListener(); private final JComponent content;
/*      */     private Rectangle dirty;
/*      */     
/*      */     public RepaintTrigger(JComponent content) {
/*  225 */       this.content = content;
/*      */     }
/*      */     
/*      */     public void addNotify() {
/*  229 */       super.addNotify();
/*  230 */       Window w = SwingUtilities.getWindowAncestor(this);
/*  231 */       setSize(getParent().getSize());
/*  232 */       w.addComponentListener(this.listener);
/*  233 */       w.addWindowListener(this.listener);
/*  234 */       Toolkit.getDefaultToolkit().addAWTEventListener(this.listener, 48L);
/*      */     }
/*      */     
/*      */     public void removeNotify() {
/*  238 */       Toolkit.getDefaultToolkit().removeAWTEventListener(this.listener);
/*  239 */       Window w = SwingUtilities.getWindowAncestor(this);
/*  240 */       w.removeComponentListener(this.listener);
/*  241 */       w.removeWindowListener(this.listener);
/*  242 */       super.removeNotify();
/*      */     }
/*      */ 
/*      */     
/*      */     protected void paintComponent(Graphics g) {
/*  247 */       Rectangle bounds = g.getClipBounds();
/*  248 */       if (this.dirty == null || !this.dirty.contains(bounds)) {
/*  249 */         if (this.dirty == null) {
/*  250 */           this.dirty = bounds;
/*      */         } else {
/*      */           
/*  253 */           this.dirty = this.dirty.union(bounds);
/*      */         } 
/*  255 */         this.content.repaint(this.dirty);
/*      */       } else {
/*      */         
/*  258 */         this.dirty = null;
/*      */       } 
/*      */     }
/*      */     
/*      */     protected Listener createListener() {
/*  263 */       return new Listener();
/*      */     }
/*      */   }
/*      */   
/*      */   public static abstract class NativeWindowUtils {
/*      */     protected abstract class TransparentContentPane
/*      */       extends JPanel implements AWTEventListener {
/*      */       private static final long serialVersionUID = 1L;
/*      */       private boolean transparent;
/*      */       
/*      */       public TransparentContentPane(Container oldContent) {
/*  274 */         super(new BorderLayout());
/*  275 */         add(oldContent, "Center");
/*  276 */         setTransparent(true);
/*  277 */         if (oldContent instanceof JPanel)
/*  278 */           ((JComponent)oldContent).setOpaque(false); 
/*      */       }
/*      */       
/*      */       public void addNotify() {
/*  282 */         super.addNotify();
/*  283 */         Toolkit.getDefaultToolkit().addAWTEventListener(this, 2L);
/*      */       }
/*      */       public void removeNotify() {
/*  286 */         Toolkit.getDefaultToolkit().removeAWTEventListener(this);
/*  287 */         super.removeNotify();
/*      */       }
/*      */       public void setTransparent(boolean transparent) {
/*  290 */         this.transparent = transparent;
/*  291 */         setOpaque(!transparent);
/*  292 */         setDoubleBuffered(!transparent);
/*  293 */         repaint();
/*      */       }
/*      */       public void eventDispatched(AWTEvent e) {
/*  296 */         if (e.getID() == 300 && SwingUtilities.isDescendingFrom(((ContainerEvent)e).getChild(), this)) {
/*      */           
/*  298 */           Component child = ((ContainerEvent)e).getChild();
/*  299 */           WindowUtils.NativeWindowUtils.this.setDoubleBuffered(child, false);
/*      */         } 
/*      */       }
/*      */       public void paint(Graphics gr) {
/*  303 */         if (this.transparent) {
/*  304 */           Rectangle r = gr.getClipBounds();
/*  305 */           int w = r.width;
/*  306 */           int h = r.height;
/*  307 */           if (getWidth() > 0 && getHeight() > 0) {
/*  308 */             BufferedImage buf = new BufferedImage(w, h, 3);
/*      */ 
/*      */             
/*  311 */             Graphics2D g = buf.createGraphics();
/*  312 */             g.setComposite(AlphaComposite.Clear);
/*  313 */             g.fillRect(0, 0, w, h);
/*  314 */             g.dispose();
/*      */             
/*  316 */             g = buf.createGraphics();
/*  317 */             g.translate(-r.x, -r.y);
/*  318 */             super.paint(g);
/*  319 */             g.dispose();
/*      */             
/*  321 */             paintDirect(buf, r);
/*      */           } 
/*      */         } else {
/*      */           
/*  325 */           super.paint(gr);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*      */       protected abstract void paintDirect(BufferedImage param2BufferedImage, Rectangle param2Rectangle);
/*      */     }
/*      */ 
/*      */     
/*      */     protected Window getWindow(Component c) {
/*  335 */       return (c instanceof Window) ? (Window)c : SwingUtilities.getWindowAncestor(c);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void whenDisplayable(Component w, final Runnable action) {
/*  343 */       if (w.isDisplayable() && (!WindowUtils.Holder.requiresVisible || w.isVisible())) {
/*  344 */         action.run();
/*      */       }
/*  346 */       else if (WindowUtils.Holder.requiresVisible) {
/*  347 */         getWindow(w).addWindowListener(new WindowAdapter() {
/*      */               public void windowOpened(WindowEvent e) {
/*  349 */                 e.getWindow().removeWindowListener(this);
/*  350 */                 action.run();
/*      */               }
/*      */               public void windowClosed(WindowEvent e) {
/*  353 */                 e.getWindow().removeWindowListener(this);
/*      */               }
/*      */             });
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  360 */         w.addHierarchyListener(new HierarchyListener() {
/*      */               public void hierarchyChanged(HierarchyEvent e) {
/*  362 */                 if ((e.getChangeFlags() & 0x2L) != 0L && e.getComponent().isDisplayable()) {
/*      */                   
/*  364 */                   e.getComponent().removeHierarchyListener(this);
/*  365 */                   action.run();
/*      */                 } 
/*      */               }
/*      */             });
/*      */       } 
/*      */     }
/*      */     
/*      */     protected Raster toRaster(Shape mask) {
/*  373 */       Raster raster = null;
/*  374 */       if (mask != WindowUtils.MASK_NONE) {
/*  375 */         Rectangle bounds = mask.getBounds();
/*  376 */         if (bounds.width > 0 && bounds.height > 0) {
/*  377 */           BufferedImage clip = new BufferedImage(bounds.x + bounds.width, bounds.y + bounds.height, 12);
/*      */ 
/*      */ 
/*      */           
/*  381 */           Graphics2D g = clip.createGraphics();
/*  382 */           g.setColor(Color.black);
/*  383 */           g.fillRect(0, 0, bounds.x + bounds.width, bounds.y + bounds.height);
/*  384 */           g.setColor(Color.white);
/*  385 */           g.fill(mask);
/*  386 */           raster = clip.getRaster();
/*      */         } 
/*      */       } 
/*  389 */       return raster;
/*      */     }
/*      */     
/*      */     protected Raster toRaster(Component c, Icon mask) {
/*  393 */       Raster raster = null;
/*  394 */       if (mask != null) {
/*  395 */         Rectangle bounds = new Rectangle(0, 0, mask.getIconWidth(), mask.getIconHeight());
/*      */         
/*  397 */         BufferedImage clip = new BufferedImage(bounds.width, bounds.height, 2);
/*      */ 
/*      */         
/*  400 */         Graphics2D g = clip.createGraphics();
/*  401 */         g.setComposite(AlphaComposite.Clear);
/*  402 */         g.fillRect(0, 0, bounds.width, bounds.height);
/*  403 */         g.setComposite(AlphaComposite.SrcOver);
/*  404 */         mask.paintIcon(c, g, 0, 0);
/*  405 */         raster = clip.getAlphaRaster();
/*      */       } 
/*  407 */       return raster;
/*      */     }
/*      */     
/*      */     protected Shape toShape(Raster raster) {
/*  411 */       final Area area = new Area(new Rectangle(0, 0, 0, 0));
/*  412 */       RasterRangesUtils.outputOccupiedRanges(raster, new RasterRangesUtils.RangesOutput() {
/*      */             public boolean outputRange(int x, int y, int w, int h) {
/*  414 */               area.add(new Area(new Rectangle(x, y, w, h)));
/*  415 */               return true;
/*      */             }
/*      */           });
/*  418 */       return area;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowAlpha(Window w, float alpha) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isWindowAlphaSupported() {
/*  431 */       return false;
/*      */     }
/*      */ 
/*      */     
/*      */     public GraphicsConfiguration getAlphaCompatibleGraphicsConfiguration() {
/*  436 */       GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*      */       
/*  438 */       GraphicsDevice dev = env.getDefaultScreenDevice();
/*  439 */       return dev.getDefaultConfiguration();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowTransparent(Window w, boolean transparent) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void setDoubleBuffered(Component root, boolean buffered) {
/*  452 */       if (root instanceof JComponent) {
/*  453 */         ((JComponent)root).setDoubleBuffered(buffered);
/*      */       }
/*  455 */       if (root instanceof JRootPane && buffered) {
/*  456 */         ((JRootPane)root).setDoubleBuffered(true);
/*      */       }
/*  458 */       else if (root instanceof Container) {
/*  459 */         Component[] kids = ((Container)root).getComponents();
/*  460 */         for (int i = 0; i < kids.length; i++) {
/*  461 */           setDoubleBuffered(kids[i], buffered);
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     protected void setLayersTransparent(Window w, boolean transparent) {
/*  468 */       Color bg = transparent ? new Color(0, 0, 0, 0) : null;
/*  469 */       if (w instanceof RootPaneContainer) {
/*  470 */         RootPaneContainer rpc = (RootPaneContainer)w;
/*  471 */         JRootPane root = rpc.getRootPane();
/*  472 */         JLayeredPane lp = root.getLayeredPane();
/*  473 */         Container c = root.getContentPane();
/*  474 */         JComponent content = (c instanceof JComponent) ? (JComponent)c : null;
/*      */         
/*  476 */         if (transparent) {
/*  477 */           lp.putClientProperty("transparent-old-opaque", Boolean.valueOf(lp.isOpaque()));
/*      */           
/*  479 */           lp.setOpaque(false);
/*  480 */           root.putClientProperty("transparent-old-opaque", Boolean.valueOf(root.isOpaque()));
/*      */           
/*  482 */           root.setOpaque(false);
/*  483 */           if (content != null) {
/*  484 */             content.putClientProperty("transparent-old-opaque", Boolean.valueOf(content.isOpaque()));
/*      */             
/*  486 */             content.setOpaque(false);
/*      */           } 
/*  488 */           root.putClientProperty("transparent-old-bg", root.getParent().getBackground());
/*      */         }
/*      */         else {
/*      */           
/*  492 */           lp.setOpaque(Boolean.TRUE.equals(lp.getClientProperty("transparent-old-opaque")));
/*  493 */           lp.putClientProperty("transparent-old-opaque", (Object)null);
/*  494 */           root.setOpaque(Boolean.TRUE.equals(root.getClientProperty("transparent-old-opaque")));
/*  495 */           root.putClientProperty("transparent-old-opaque", (Object)null);
/*  496 */           if (content != null) {
/*  497 */             content.setOpaque(Boolean.TRUE.equals(content.getClientProperty("transparent-old-opaque")));
/*  498 */             content.putClientProperty("transparent-old-opaque", (Object)null);
/*      */           } 
/*  500 */           bg = (Color)root.getClientProperty("transparent-old-bg");
/*  501 */           root.putClientProperty("transparent-old-bg", (Object)null);
/*      */         } 
/*      */       } 
/*  504 */       w.setBackground(bg);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void setMask(Component c, Raster raster) {
/*  511 */       throw new UnsupportedOperationException("Window masking is not available");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void setWindowMask(Component w, Raster raster) {
/*  520 */       if (w.isLightweight())
/*  521 */         throw new IllegalArgumentException("Component must be heavyweight: " + w); 
/*  522 */       setMask(w, raster);
/*      */     }
/*      */ 
/*      */     
/*      */     public void setWindowMask(Component w, Shape mask) {
/*  527 */       setWindowMask(w, toRaster(mask));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowMask(Component w, Icon mask) {
/*  535 */       setWindowMask(w, toRaster(w, mask));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     protected void setForceHeavyweightPopups(Window w, boolean force) {
/*  544 */       if (!(w instanceof WindowUtils.HeavyweightForcer)) {
/*  545 */         Window[] owned = w.getOwnedWindows();
/*  546 */         for (int i = 0; i < owned.length; i++) {
/*  547 */           if (owned[i] instanceof WindowUtils.HeavyweightForcer) {
/*  548 */             if (force)
/*      */               return; 
/*  550 */             owned[i].dispose();
/*      */           } 
/*      */         } 
/*  553 */         Boolean b = Boolean.valueOf(System.getProperty("jna.force_hw_popups", "true"));
/*  554 */         if (force && b.booleanValue()) {
/*  555 */           new WindowUtils.HeavyweightForcer(w);
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static class Holder
/*      */   {
/*      */     public static boolean requiresVisible;
/*      */     
/*      */     public static final WindowUtils.NativeWindowUtils INSTANCE;
/*      */ 
/*      */     
/*      */     static {
/*  570 */       if (Platform.isWindows()) {
/*  571 */         INSTANCE = new WindowUtils.W32WindowUtils();
/*      */       }
/*  573 */       else if (Platform.isMac()) {
/*  574 */         INSTANCE = new WindowUtils.MacWindowUtils();
/*      */       }
/*  576 */       else if (Platform.isX11()) {
/*  577 */         INSTANCE = new WindowUtils.X11WindowUtils();
/*  578 */         requiresVisible = System.getProperty("java.version").matches("^1\\.4\\..*");
/*      */       }
/*      */       else {
/*      */         
/*  582 */         String os = System.getProperty("os.name");
/*  583 */         throw new UnsupportedOperationException("No support for " + os);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static NativeWindowUtils getInstance() {
/*  589 */     return Holder.INSTANCE;
/*      */   }
/*      */   private static class W32WindowUtils extends NativeWindowUtils { private W32WindowUtils() {}
/*      */     
/*      */     private WinDef.HWND getHWnd(Component w) {
/*  594 */       WinDef.HWND hwnd = new WinDef.HWND();
/*  595 */       hwnd.setPointer(Native.getComponentPointer(w));
/*  596 */       return hwnd;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean isWindowAlphaSupported() {
/*  604 */       return Boolean.getBoolean("sun.java2d.noddraw");
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean usingUpdateLayeredWindow(Window w) {
/*  609 */       if (w instanceof RootPaneContainer) {
/*  610 */         JRootPane root = ((RootPaneContainer)w).getRootPane();
/*  611 */         return (root.getClientProperty("transparent-old-bg") != null);
/*      */       } 
/*  613 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void storeAlpha(Window w, byte alpha) {
/*  620 */       if (w instanceof RootPaneContainer) {
/*  621 */         JRootPane root = ((RootPaneContainer)w).getRootPane();
/*  622 */         Byte b = (alpha == -1) ? null : new Byte(alpha);
/*  623 */         root.putClientProperty("transparent-alpha", b);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private byte getAlpha(Window w) {
/*  629 */       if (w instanceof RootPaneContainer) {
/*  630 */         JRootPane root = ((RootPaneContainer)w).getRootPane();
/*  631 */         Byte b = (Byte)root.getClientProperty("transparent-alpha");
/*  632 */         if (b != null) {
/*  633 */           return b.byteValue();
/*      */         }
/*      */       } 
/*  636 */       return -1;
/*      */     }
/*      */     
/*      */     public void setWindowAlpha(final Window w, final float alpha) {
/*  640 */       if (!isWindowAlphaSupported()) {
/*  641 */         throw new UnsupportedOperationException("Set sun.java2d.noddraw=true to enable transparent windows");
/*      */       }
/*  643 */       whenDisplayable(w, new Runnable() {
/*      */             public void run() {
/*  645 */               WinDef.HWND hWnd = WindowUtils.W32WindowUtils.this.getHWnd(w);
/*  646 */               User32 user = User32.INSTANCE;
/*  647 */               int flags = user.GetWindowLong(hWnd, -20);
/*  648 */               byte level = (byte)((int)(255.0F * alpha) & 0xFF);
/*  649 */               if (WindowUtils.W32WindowUtils.this.usingUpdateLayeredWindow(w)) {
/*      */ 
/*      */                 
/*  652 */                 WinUser.BLENDFUNCTION blend = new WinUser.BLENDFUNCTION();
/*  653 */                 blend.SourceConstantAlpha = level;
/*  654 */                 blend.AlphaFormat = 1;
/*  655 */                 user.UpdateLayeredWindow(hWnd, null, null, null, null, null, 0, blend, 2);
/*      */ 
/*      */               
/*      */               }
/*  659 */               else if (alpha == 1.0F) {
/*  660 */                 flags &= 0xFFF7FFFF;
/*  661 */                 user.SetWindowLong(hWnd, -20, flags);
/*      */               } else {
/*      */                 
/*  664 */                 flags |= 0x80000;
/*  665 */                 user.SetWindowLong(hWnd, -20, flags);
/*  666 */                 user.SetLayeredWindowAttributes(hWnd, 0, level, 2);
/*      */               } 
/*      */               
/*  669 */               WindowUtils.W32WindowUtils.this.setForceHeavyweightPopups(w, (alpha != 1.0F));
/*  670 */               WindowUtils.W32WindowUtils.this.storeAlpha(w, level);
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     private class W32TransparentContentPane
/*      */       extends WindowUtils.NativeWindowUtils.TransparentContentPane
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/*      */       private WinDef.HDC memDC;
/*      */       private WinDef.HBITMAP hBitmap;
/*      */       private Pointer pbits;
/*      */       private Dimension bitmapSize;
/*      */       
/*      */       public W32TransparentContentPane(Container content) {
/*  686 */         super(content);
/*      */       }
/*      */       private void disposeBackingStore() {
/*  689 */         GDI32 gdi = GDI32.INSTANCE;
/*  690 */         if (this.hBitmap != null) {
/*  691 */           gdi.DeleteObject((WinNT.HANDLE)this.hBitmap);
/*  692 */           this.hBitmap = null;
/*      */         } 
/*  694 */         if (this.memDC != null) {
/*  695 */           gdi.DeleteDC(this.memDC);
/*  696 */           this.memDC = null;
/*      */         } 
/*      */       }
/*      */       public void removeNotify() {
/*  700 */         super.removeNotify();
/*  701 */         disposeBackingStore();
/*      */       }
/*      */       public void setTransparent(boolean transparent) {
/*  704 */         super.setTransparent(transparent);
/*  705 */         if (!transparent) {
/*  706 */           disposeBackingStore();
/*      */         }
/*      */       }
/*      */       
/*      */       protected void paintDirect(BufferedImage buf, Rectangle bounds) {
/*  711 */         Window win = SwingUtilities.getWindowAncestor(this);
/*  712 */         GDI32 gdi = GDI32.INSTANCE;
/*  713 */         User32 user = User32.INSTANCE;
/*  714 */         int x = bounds.x;
/*  715 */         int y = bounds.y;
/*  716 */         Point origin = SwingUtilities.convertPoint(this, x, y, win);
/*  717 */         int w = bounds.width;
/*  718 */         int h = bounds.height;
/*  719 */         int ww = win.getWidth();
/*  720 */         int wh = win.getHeight();
/*  721 */         WinDef.HDC screenDC = user.GetDC(null);
/*  722 */         WinNT.HANDLE oldBitmap = null;
/*      */         try {
/*  724 */           if (this.memDC == null) {
/*  725 */             this.memDC = gdi.CreateCompatibleDC(screenDC);
/*      */           }
/*  727 */           if (this.hBitmap == null || !win.getSize().equals(this.bitmapSize)) {
/*  728 */             if (this.hBitmap != null) {
/*  729 */               gdi.DeleteObject((WinNT.HANDLE)this.hBitmap);
/*  730 */               this.hBitmap = null;
/*      */             } 
/*  732 */             WinGDI.BITMAPINFO bmi = new WinGDI.BITMAPINFO();
/*  733 */             bmi.bmiHeader.biWidth = ww;
/*  734 */             bmi.bmiHeader.biHeight = wh;
/*  735 */             bmi.bmiHeader.biPlanes = 1;
/*  736 */             bmi.bmiHeader.biBitCount = 32;
/*  737 */             bmi.bmiHeader.biCompression = 0;
/*  738 */             bmi.bmiHeader.biSizeImage = ww * wh * 4;
/*  739 */             PointerByReference ppbits = new PointerByReference();
/*  740 */             this.hBitmap = gdi.CreateDIBSection(this.memDC, bmi, 0, ppbits, null, 0);
/*      */ 
/*      */             
/*  743 */             this.pbits = ppbits.getValue();
/*  744 */             this.bitmapSize = new Dimension(ww, wh);
/*      */           } 
/*  746 */           oldBitmap = gdi.SelectObject(this.memDC, (WinNT.HANDLE)this.hBitmap);
/*  747 */           Raster raster = buf.getData();
/*  748 */           int[] pixel = new int[4];
/*  749 */           int[] bits = new int[w];
/*  750 */           for (int row = 0; row < h; row++) {
/*  751 */             for (int col = 0; col < w; col++) {
/*  752 */               raster.getPixel(col, row, pixel);
/*  753 */               int alpha = (pixel[3] & 0xFF) << 24;
/*  754 */               int red = pixel[2] & 0xFF;
/*  755 */               int green = (pixel[1] & 0xFF) << 8;
/*  756 */               int blue = (pixel[0] & 0xFF) << 16;
/*  757 */               bits[col] = alpha | red | green | blue;
/*      */             } 
/*  759 */             int v = wh - origin.y + row - 1;
/*  760 */             this.pbits.write(((v * ww + origin.x) * 4), bits, 0, bits.length);
/*      */           } 
/*  762 */           WinUser.SIZE winSize = new WinUser.SIZE();
/*  763 */           winSize.cx = win.getWidth();
/*  764 */           winSize.cy = win.getHeight();
/*  765 */           WinDef.POINT winLoc = new WinDef.POINT();
/*  766 */           winLoc.x = win.getX();
/*  767 */           winLoc.y = win.getY();
/*  768 */           WinDef.POINT srcLoc = new WinDef.POINT();
/*  769 */           WinUser.BLENDFUNCTION blend = new WinUser.BLENDFUNCTION();
/*  770 */           WinDef.HWND hWnd = WindowUtils.W32WindowUtils.this.getHWnd(win);
/*      */           
/*  772 */           ByteByReference bref = new ByteByReference();
/*  773 */           IntByReference iref = new IntByReference();
/*  774 */           byte level = WindowUtils.W32WindowUtils.this.getAlpha(win);
/*      */           
/*      */           try {
/*  777 */             if (user.GetLayeredWindowAttributes(hWnd, null, bref, iref) && (iref.getValue() & 0x2) != 0)
/*      */             {
/*  779 */               level = bref.getValue();
/*      */             }
/*      */           }
/*  782 */           catch (UnsatisfiedLinkError e) {}
/*      */           
/*  784 */           blend.SourceConstantAlpha = level;
/*  785 */           blend.AlphaFormat = 1;
/*  786 */           user.UpdateLayeredWindow(hWnd, screenDC, winLoc, winSize, this.memDC, srcLoc, 0, blend, 2);
/*      */         } finally {
/*      */           
/*  789 */           user.ReleaseDC(null, screenDC);
/*  790 */           if (this.memDC != null && oldBitmap != null) {
/*  791 */             gdi.SelectObject(this.memDC, oldBitmap);
/*      */           }
/*      */         } 
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowTransparent(final Window w, final boolean transparent) {
/*  802 */       if (!(w instanceof RootPaneContainer)) {
/*  803 */         throw new IllegalArgumentException("Window must be a RootPaneContainer");
/*      */       }
/*  805 */       if (!isWindowAlphaSupported()) {
/*  806 */         throw new UnsupportedOperationException("Set sun.java2d.noddraw=true to enable transparent windows");
/*      */       }
/*  808 */       boolean isTransparent = (w.getBackground() != null && w.getBackground().getAlpha() == 0);
/*      */       
/*  810 */       if (transparent == isTransparent)
/*      */         return; 
/*  812 */       whenDisplayable(w, new Runnable() {
/*      */             public void run() {
/*  814 */               User32 user = User32.INSTANCE;
/*  815 */               WinDef.HWND hWnd = WindowUtils.W32WindowUtils.this.getHWnd(w);
/*  816 */               int flags = user.GetWindowLong(hWnd, -20);
/*  817 */               JRootPane root = ((RootPaneContainer)w).getRootPane();
/*  818 */               JLayeredPane lp = root.getLayeredPane();
/*  819 */               Container content = root.getContentPane();
/*  820 */               if (content instanceof WindowUtils.W32WindowUtils.W32TransparentContentPane) {
/*  821 */                 ((WindowUtils.W32WindowUtils.W32TransparentContentPane)content).setTransparent(transparent);
/*      */               }
/*  823 */               else if (transparent) {
/*  824 */                 WindowUtils.W32WindowUtils.W32TransparentContentPane w32content = new WindowUtils.W32WindowUtils.W32TransparentContentPane(content);
/*      */                 
/*  826 */                 root.setContentPane(w32content);
/*  827 */                 lp.add(new WindowUtils.RepaintTrigger(w32content), JLayeredPane.DRAG_LAYER);
/*      */               } 
/*      */               
/*  830 */               if (transparent && !WindowUtils.W32WindowUtils.this.usingUpdateLayeredWindow(w)) {
/*  831 */                 flags |= 0x80000;
/*  832 */                 user.SetWindowLong(hWnd, -20, flags);
/*      */               }
/*  834 */               else if (!transparent && WindowUtils.W32WindowUtils.this.usingUpdateLayeredWindow(w)) {
/*  835 */                 flags &= 0xFFF7FFFF;
/*  836 */                 user.SetWindowLong(hWnd, -20, flags);
/*      */               } 
/*  838 */               WindowUtils.W32WindowUtils.this.setLayersTransparent(w, transparent);
/*  839 */               WindowUtils.W32WindowUtils.this.setForceHeavyweightPopups(w, transparent);
/*  840 */               WindowUtils.W32WindowUtils.this.setDoubleBuffered(w, !transparent);
/*      */             }
/*      */           });
/*      */     }
/*      */     
/*      */     public void setWindowMask(Component w, Shape mask) {
/*  846 */       if (mask instanceof Area && ((Area)mask).isPolygonal()) {
/*  847 */         setMask(w, (Area)mask);
/*      */       } else {
/*      */         
/*  850 */         super.setWindowMask(w, mask);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     private void setWindowRegion(final Component w, final WinDef.HRGN hrgn) {
/*  856 */       whenDisplayable(w, new Runnable() {
/*      */             public void run() {
/*  858 */               GDI32 gdi = GDI32.INSTANCE;
/*  859 */               User32 user = User32.INSTANCE;
/*  860 */               WinDef.HWND hWnd = WindowUtils.W32WindowUtils.this.getHWnd(w);
/*      */               try {
/*  862 */                 user.SetWindowRgn(hWnd, hrgn, true);
/*  863 */                 WindowUtils.W32WindowUtils.this.setForceHeavyweightPopups(WindowUtils.W32WindowUtils.this.getWindow(w), (hrgn != null));
/*      */               } finally {
/*      */                 
/*  866 */                 gdi.DeleteObject((WinNT.HANDLE)hrgn);
/*      */               } 
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     private void setMask(Component w, Area area) {
/*  874 */       GDI32 gdi = GDI32.INSTANCE;
/*  875 */       PathIterator pi = area.getPathIterator(null);
/*  876 */       int mode = (pi.getWindingRule() == 1) ? 2 : 1;
/*      */       
/*  878 */       float[] coords = new float[6];
/*  879 */       List<WinDef.POINT> points = new ArrayList<WinDef.POINT>();
/*  880 */       int size = 0;
/*  881 */       List<Integer> sizes = new ArrayList<Integer>();
/*  882 */       while (!pi.isDone()) {
/*  883 */         int type = pi.currentSegment(coords);
/*  884 */         if (type == 0) {
/*  885 */           size = 1;
/*  886 */           points.add(new WinDef.POINT((int)coords[0], (int)coords[1]));
/*      */         }
/*  888 */         else if (type == 1) {
/*  889 */           size++;
/*  890 */           points.add(new WinDef.POINT((int)coords[0], (int)coords[1]));
/*      */         }
/*  892 */         else if (type == 4) {
/*  893 */           sizes.add(new Integer(size));
/*      */         } else {
/*      */           
/*  896 */           throw new RuntimeException("Area is not polygonal: " + area);
/*      */         } 
/*  898 */         pi.next();
/*      */       } 
/*  900 */       WinDef.POINT[] lppt = (WinDef.POINT[])(new WinDef.POINT()).toArray(points.size());
/*  901 */       WinDef.POINT[] pts = points.<WinDef.POINT>toArray(new WinDef.POINT[points.size()]);
/*  902 */       for (int i = 0; i < lppt.length; i++) {
/*  903 */         (lppt[i]).x = (pts[i]).x;
/*  904 */         (lppt[i]).y = (pts[i]).y;
/*      */       } 
/*  906 */       int[] counts = new int[sizes.size()];
/*  907 */       for (int j = 0; j < counts.length; j++) {
/*  908 */         counts[j] = ((Integer)sizes.get(j)).intValue();
/*      */       }
/*  910 */       WinDef.HRGN hrgn = gdi.CreatePolyPolygonRgn(lppt, counts, counts.length, mode);
/*  911 */       setWindowRegion(w, hrgn);
/*      */     }
/*      */     
/*      */     protected void setMask(Component w, Raster raster) {
/*  915 */       GDI32 gdi = GDI32.INSTANCE;
/*  916 */       final WinDef.HRGN region = (raster != null) ? gdi.CreateRectRgn(0, 0, 0, 0) : null;
/*      */       
/*  918 */       if (region != null) {
/*  919 */         final WinDef.HRGN tempRgn = gdi.CreateRectRgn(0, 0, 0, 0);
/*      */         try {
/*  921 */           RasterRangesUtils.outputOccupiedRanges(raster, new RasterRangesUtils.RangesOutput() {
/*      */                 public boolean outputRange(int x, int y, int w, int h) {
/*  923 */                   GDI32 gdi = GDI32.INSTANCE;
/*  924 */                   gdi.SetRectRgn(tempRgn, x, y, x + w, y + h);
/*  925 */                   return (gdi.CombineRgn(region, region, tempRgn, 2) != 0);
/*      */                 }
/*      */               });
/*      */         } finally {
/*      */           
/*  930 */           gdi.DeleteObject((WinNT.HANDLE)tempRgn);
/*      */         } 
/*      */       } 
/*  933 */       setWindowRegion(w, region);
/*      */     } }
/*      */   
/*      */   private static class MacWindowUtils extends NativeWindowUtils { private static final String WDRAG = "apple.awt.draggableWindowBackground";
/*      */     
/*      */     public boolean isWindowAlphaSupported() {
/*  939 */       return true;
/*      */     }
/*      */     private MacWindowUtils() {}
/*      */     private OSXMaskingContentPane installMaskingPane(Window w) {
/*      */       OSXMaskingContentPane content;
/*  944 */       if (w instanceof RootPaneContainer) {
/*      */         
/*  946 */         RootPaneContainer rpc = (RootPaneContainer)w;
/*  947 */         Container oldContent = rpc.getContentPane();
/*  948 */         if (oldContent instanceof OSXMaskingContentPane) {
/*  949 */           content = (OSXMaskingContentPane)oldContent;
/*      */         } else {
/*      */           
/*  952 */           content = new OSXMaskingContentPane(oldContent);
/*      */           
/*  954 */           rpc.setContentPane(content);
/*      */         } 
/*      */       } else {
/*      */         
/*  958 */         Component oldContent = (w.getComponentCount() > 0) ? w.getComponent(0) : null;
/*  959 */         if (oldContent instanceof OSXMaskingContentPane) {
/*  960 */           content = (OSXMaskingContentPane)oldContent;
/*      */         } else {
/*      */           
/*  963 */           content = new OSXMaskingContentPane(oldContent);
/*  964 */           w.add(content);
/*      */         } 
/*      */       } 
/*  967 */       return content;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowTransparent(Window w, boolean transparent) {
/*  979 */       boolean isTransparent = (w.getBackground() != null && w.getBackground().getAlpha() == 0);
/*      */       
/*  981 */       if (transparent != isTransparent) {
/*  982 */         setBackgroundTransparent(w, transparent, "setWindowTransparent");
/*      */       }
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private void fixWindowDragging(Window w, String context) {
/*  989 */       if (w instanceof RootPaneContainer) {
/*  990 */         JRootPane p = ((RootPaneContainer)w).getRootPane();
/*  991 */         Boolean oldDraggable = (Boolean)p.getClientProperty("apple.awt.draggableWindowBackground");
/*  992 */         if (oldDraggable == null) {
/*  993 */           p.putClientProperty("apple.awt.draggableWindowBackground", Boolean.FALSE);
/*  994 */           if (w.isDisplayable()) {
/*  995 */             System.err.println(context + "(): To avoid content dragging, " + context + "() must be called before the window is realized, or " + "apple.awt.draggableWindowBackground" + " must be set to Boolean.FALSE before the window is realized.  If you really want content dragging, set " + "apple.awt.draggableWindowBackground" + " on the window's root pane to Boolean.TRUE before calling " + context + "() to hide this message.");
/*      */           }
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowAlpha(final Window w, final float alpha) {
/* 1010 */       if (w instanceof RootPaneContainer) {
/* 1011 */         JRootPane p = ((RootPaneContainer)w).getRootPane();
/* 1012 */         p.putClientProperty("Window.alpha", new Float(alpha));
/* 1013 */         fixWindowDragging(w, "setWindowAlpha");
/*      */       } 
/* 1015 */       whenDisplayable(w, new Runnable() {
/*      */             public void run() {
/* 1017 */               Object peer = w.getPeer();
/*      */               try {
/* 1019 */                 peer.getClass().getMethod("setAlpha", new Class[] { float.class }).invoke(peer, new Object[] { new Float(this.val$alpha) });
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               }
/* 1025 */               catch (Exception e) {}
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */     
/*      */     protected void setWindowMask(Component w, Raster raster) {
/* 1032 */       if (raster != null) {
/* 1033 */         setWindowMask(w, toShape(raster));
/*      */       } else {
/*      */         
/* 1036 */         setWindowMask(w, new Rectangle(0, 0, w.getWidth(), w.getHeight()));
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public void setWindowMask(Component c, Shape shape) {
/* 1042 */       if (c instanceof Window) {
/* 1043 */         Window w = (Window)c;
/* 1044 */         OSXMaskingContentPane content = installMaskingPane(w);
/* 1045 */         content.setMask(shape);
/* 1046 */         setBackgroundTransparent(w, (shape != WindowUtils.MASK_NONE), "setWindowMask");
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static class OSXMaskingContentPane
/*      */       extends JPanel
/*      */     {
/*      */       private static final long serialVersionUID = 1L;
/*      */       
/*      */       private Shape shape;
/*      */ 
/*      */       
/*      */       public OSXMaskingContentPane(Component oldContent) {
/* 1061 */         super(new BorderLayout());
/* 1062 */         if (oldContent != null) {
/* 1063 */           add(oldContent, "Center");
/*      */         }
/*      */       }
/*      */       
/*      */       public void setMask(Shape shape) {
/* 1068 */         this.shape = shape;
/* 1069 */         repaint();
/*      */       }
/*      */       
/*      */       public void paint(Graphics graphics) {
/* 1073 */         Graphics2D g = (Graphics2D)graphics.create();
/* 1074 */         g.setComposite(AlphaComposite.Clear);
/* 1075 */         g.fillRect(0, 0, getWidth(), getHeight());
/* 1076 */         g.dispose();
/* 1077 */         if (this.shape != null) {
/* 1078 */           g = (Graphics2D)graphics.create();
/* 1079 */           g.setClip(this.shape);
/* 1080 */           super.paint(g);
/* 1081 */           g.dispose();
/*      */         } else {
/*      */           
/* 1084 */           super.paint(graphics);
/*      */         } 
/*      */       }
/*      */     }
/*      */     
/*      */     private void setBackgroundTransparent(Window w, boolean transparent, String context) {
/* 1090 */       JRootPane rp = (w instanceof RootPaneContainer) ? ((RootPaneContainer)w).getRootPane() : null;
/*      */       
/* 1092 */       if (transparent) {
/* 1093 */         if (rp != null) {
/* 1094 */           rp.putClientProperty("transparent-old-bg", w.getBackground());
/*      */         }
/* 1096 */         w.setBackground(new Color(0, 0, 0, 0));
/*      */       
/*      */       }
/* 1099 */       else if (rp != null) {
/* 1100 */         Color bg = (Color)rp.getClientProperty("transparent-old-bg");
/*      */ 
/*      */ 
/*      */         
/* 1104 */         if (bg != null) {
/* 1105 */           bg = new Color(bg.getRed(), bg.getGreen(), bg.getBlue(), bg.getAlpha());
/*      */         }
/* 1107 */         w.setBackground(bg);
/* 1108 */         rp.putClientProperty("transparent-old-bg", (Object)null);
/*      */       } else {
/*      */         
/* 1111 */         w.setBackground((Color)null);
/*      */       } 
/*      */       
/* 1114 */       fixWindowDragging(w, context);
/*      */     } }
/*      */   
/*      */   private static class X11WindowUtils extends NativeWindowUtils {
/*      */     private boolean didCheck;
/*      */     
/*      */     private static X11.Pixmap createBitmap(X11.Display dpy, X11.Window win, Raster raster) {
/* 1121 */       X11 x11 = X11.INSTANCE;
/* 1122 */       Rectangle bounds = raster.getBounds();
/* 1123 */       int width = bounds.x + bounds.width;
/* 1124 */       int height = bounds.y + bounds.height;
/* 1125 */       X11.Pixmap pm = x11.XCreatePixmap(dpy, (X11.Drawable)win, width, height, 1);
/* 1126 */       X11.GC gc = x11.XCreateGC(dpy, (X11.Drawable)pm, new NativeLong(0L), null);
/* 1127 */       if (gc == null) {
/* 1128 */         return null;
/*      */       }
/* 1130 */       x11.XSetForeground(dpy, gc, new NativeLong(0L));
/* 1131 */       x11.XFillRectangle(dpy, (X11.Drawable)pm, gc, 0, 0, width, height);
/* 1132 */       final List<Rectangle> rlist = new ArrayList<Rectangle>();
/*      */       try {
/* 1134 */         RasterRangesUtils.outputOccupiedRanges(raster, new RasterRangesUtils.RangesOutput() {
/*      */               public boolean outputRange(int x, int y, int w, int h) {
/* 1136 */                 rlist.add(new Rectangle(x, y, w, h));
/* 1137 */                 return true;
/*      */               }
/*      */             });
/* 1140 */         X11.XRectangle[] rects = (X11.XRectangle[])(new X11.XRectangle()).toArray(rlist.size());
/*      */         
/* 1142 */         for (int i = 0; i < rects.length; i++) {
/* 1143 */           Rectangle r = rlist.get(i);
/* 1144 */           (rects[i]).x = (short)r.x;
/* 1145 */           (rects[i]).y = (short)r.y;
/* 1146 */           (rects[i]).width = (short)r.width;
/* 1147 */           (rects[i]).height = (short)r.height;
/*      */           
/* 1149 */           Pointer p = rects[i].getPointer();
/* 1150 */           p.setShort(0L, (short)r.x);
/* 1151 */           p.setShort(2L, (short)r.y);
/* 1152 */           p.setShort(4L, (short)r.width);
/* 1153 */           p.setShort(6L, (short)r.height);
/* 1154 */           rects[i].setAutoSynch(false);
/*      */         } 
/*      */         
/* 1157 */         int UNMASKED = 1;
/* 1158 */         x11.XSetForeground(dpy, gc, new NativeLong(1L));
/* 1159 */         x11.XFillRectangles(dpy, (X11.Drawable)pm, gc, rects, rects.length);
/*      */       } finally {
/*      */         
/* 1162 */         x11.XFreeGC(dpy, gc);
/*      */       } 
/* 1164 */       return pm;
/*      */     }
/*      */ 
/*      */     
/* 1168 */     private long[] alphaVisualIDs = new long[0]; private static final long OPAQUE = 4294967295L; private static final String OPACITY = "_NET_WM_WINDOW_OPACITY";
/*      */     
/*      */     public boolean isWindowAlphaSupported() {
/* 1171 */       return ((getAlphaVisualIDs()).length > 0);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private static long getVisualID(GraphicsConfiguration config) {
/*      */       try {
/* 1178 */         Object o = config.getClass().getMethod("getVisual", (Class[])null).invoke(config, (Object[])null);
/*      */ 
/*      */         
/* 1181 */         return ((Number)o).longValue();
/*      */       }
/* 1183 */       catch (Exception e) {
/* 1184 */         e.printStackTrace();
/* 1185 */         return -1L;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     public GraphicsConfiguration getAlphaCompatibleGraphicsConfiguration() {
/* 1191 */       if (isWindowAlphaSupported()) {
/* 1192 */         GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();
/*      */         
/* 1194 */         GraphicsDevice[] devices = env.getScreenDevices();
/* 1195 */         for (int i = 0; i < devices.length; i++) {
/* 1196 */           GraphicsConfiguration[] configs = devices[i].getConfigurations();
/*      */           
/* 1198 */           for (int j = 0; j < configs.length; j++) {
/* 1199 */             long visualID = getVisualID(configs[j]);
/* 1200 */             long[] ids = getAlphaVisualIDs();
/* 1201 */             for (int k = 0; k < ids.length; k++) {
/* 1202 */               if (visualID == ids[k]) {
/* 1203 */                 return configs[j];
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/* 1209 */       return super.getAlphaCompatibleGraphicsConfiguration();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private synchronized long[] getAlphaVisualIDs() {
/* 1217 */       if (this.didCheck) {
/* 1218 */         return this.alphaVisualIDs;
/*      */       }
/* 1220 */       this.didCheck = true;
/* 1221 */       X11 x11 = X11.INSTANCE;
/* 1222 */       X11.Display dpy = x11.XOpenDisplay(null);
/* 1223 */       if (dpy == null)
/* 1224 */         return this.alphaVisualIDs; 
/* 1225 */       X11.XVisualInfo info = null;
/*      */       try {
/* 1227 */         int screen = x11.XDefaultScreen(dpy);
/* 1228 */         X11.XVisualInfo template = new X11.XVisualInfo();
/* 1229 */         template.screen = screen;
/* 1230 */         template.depth = 32;
/* 1231 */         template.c_class = 4;
/* 1232 */         NativeLong mask = new NativeLong(14L);
/*      */ 
/*      */         
/* 1235 */         IntByReference pcount = new IntByReference();
/* 1236 */         info = x11.XGetVisualInfo(dpy, mask, template, pcount);
/* 1237 */         if (info != null) {
/* 1238 */           List<X11.VisualID> list = new ArrayList<X11.VisualID>();
/* 1239 */           X11.XVisualInfo[] infos = (X11.XVisualInfo[])info.toArray(pcount.getValue());
/*      */           int i;
/* 1241 */           for (i = 0; i < infos.length; i++) {
/* 1242 */             X11.Xrender.XRenderPictFormat format = X11.Xrender.INSTANCE.XRenderFindVisualFormat(dpy, (infos[i]).visual);
/*      */ 
/*      */             
/* 1245 */             if (format.type == 1 && format.direct.alphaMask != 0)
/*      */             {
/* 1247 */               list.add((infos[i]).visualid);
/*      */             }
/*      */           } 
/* 1250 */           this.alphaVisualIDs = new long[list.size()];
/* 1251 */           for (i = 0; i < this.alphaVisualIDs.length; i++) {
/* 1252 */             this.alphaVisualIDs[i] = ((Number)list.get(i)).longValue();
/*      */           }
/* 1254 */           return this.alphaVisualIDs;
/*      */         } 
/*      */       } finally {
/*      */         
/* 1258 */         if (info != null) {
/* 1259 */           x11.XFree(info.getPointer());
/*      */         }
/* 1261 */         x11.XCloseDisplay(dpy);
/*      */       } 
/* 1263 */       return this.alphaVisualIDs;
/*      */     }
/*      */ 
/*      */     
/*      */     private static X11.Window getContentWindow(Window w, X11.Display dpy, X11.Window win, Point offset) {
/* 1268 */       if ((w instanceof Frame && !((Frame)w).isUndecorated()) || (w instanceof Dialog && !((Dialog)w).isUndecorated())) {
/*      */         
/* 1270 */         X11 x11 = X11.INSTANCE;
/* 1271 */         X11.WindowByReference rootp = new X11.WindowByReference();
/* 1272 */         X11.WindowByReference parentp = new X11.WindowByReference();
/* 1273 */         PointerByReference childrenp = new PointerByReference();
/* 1274 */         IntByReference countp = new IntByReference();
/* 1275 */         x11.XQueryTree(dpy, win, rootp, parentp, childrenp, countp);
/* 1276 */         Pointer p = childrenp.getValue();
/* 1277 */         int[] ids = p.getIntArray(0L, countp.getValue());
/* 1278 */         int arr$[] = ids, len$ = arr$.length, i$ = 0; if (i$ < len$) { int id = arr$[i$];
/*      */           
/* 1280 */           X11.Window child = new X11.Window(id);
/* 1281 */           X11.XWindowAttributes xwa = new X11.XWindowAttributes();
/* 1282 */           x11.XGetWindowAttributes(dpy, child, xwa);
/* 1283 */           offset.x = -xwa.x;
/* 1284 */           offset.y = -xwa.y;
/* 1285 */           win = child; }
/*      */ 
/*      */         
/* 1288 */         if (p != null) {
/* 1289 */           x11.XFree(p);
/*      */         }
/*      */       } 
/* 1292 */       return win;
/*      */     }
/*      */     
/*      */     private static X11.Window getDrawable(Component w) {
/* 1296 */       int id = (int)Native.getComponentID(w);
/* 1297 */       if (id == 0)
/* 1298 */         return null; 
/* 1299 */       return new X11.Window(id);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowAlpha(final Window w, final float alpha) {
/* 1306 */       if (!isWindowAlphaSupported()) {
/* 1307 */         throw new UnsupportedOperationException("This X11 display does not provide a 32-bit visual");
/*      */       }
/* 1309 */       Runnable action = new Runnable() {
/*      */           public void run() {
/* 1311 */             X11 x11 = X11.INSTANCE;
/* 1312 */             X11.Display dpy = x11.XOpenDisplay(null);
/* 1313 */             if (dpy == null)
/*      */               return; 
/*      */             try {
/* 1316 */               X11.Window win = WindowUtils.X11WindowUtils.getDrawable(w);
/* 1317 */               if (alpha == 1.0F) {
/* 1318 */                 x11.XDeleteProperty(dpy, win, x11.XInternAtom(dpy, "_NET_WM_WINDOW_OPACITY", false));
/*      */               
/*      */               }
/*      */               else {
/*      */                 
/* 1323 */                 int opacity = (int)((long)(alpha * 4.2949673E9F) & 0xFFFFFFFFFFFFFFFFL);
/* 1324 */                 IntByReference patom = new IntByReference(opacity);
/* 1325 */                 x11.XChangeProperty(dpy, win, x11.XInternAtom(dpy, "_NET_WM_WINDOW_OPACITY", false), X11.XA_CARDINAL, 32, 0, patom.getPointer(), 1);
/*      */               
/*      */               }
/*      */ 
/*      */             
/*      */             }
/*      */             finally {
/*      */ 
/*      */               
/* 1334 */               x11.XCloseDisplay(dpy);
/*      */             } 
/*      */           }
/*      */         };
/* 1338 */       whenDisplayable(w, action);
/*      */     }
/*      */     private class X11TransparentContentPane extends WindowUtils.NativeWindowUtils.TransparentContentPane { private static final long serialVersionUID = 1L; private Memory buffer;
/*      */       private int[] pixels;
/*      */       private final int[] pixel;
/*      */       
/*      */       public X11TransparentContentPane(Container oldContent) {
/* 1345 */         super(oldContent);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1350 */         this.pixel = new int[4];
/*      */       }
/*      */ 
/*      */       
/*      */       protected void paintDirect(BufferedImage buf, Rectangle bounds) {
/* 1355 */         Window window = SwingUtilities.getWindowAncestor(this);
/* 1356 */         X11 x11 = X11.INSTANCE;
/* 1357 */         X11.Display dpy = x11.XOpenDisplay(null);
/* 1358 */         X11.Window win = WindowUtils.X11WindowUtils.getDrawable(window);
/* 1359 */         Point offset = new Point();
/* 1360 */         win = WindowUtils.X11WindowUtils.getContentWindow(window, dpy, win, offset);
/* 1361 */         X11.GC gc = x11.XCreateGC(dpy, (X11.Drawable)win, new NativeLong(0L), null);
/*      */         
/* 1363 */         Raster raster = buf.getData();
/* 1364 */         int w = bounds.width;
/* 1365 */         int h = bounds.height;
/* 1366 */         if (this.buffer == null || this.buffer.size() != (w * h * 4)) {
/* 1367 */           this.buffer = new Memory((w * h * 4));
/* 1368 */           this.pixels = new int[w * h];
/*      */         } 
/* 1370 */         for (int y = 0; y < h; y++) {
/* 1371 */           for (int x = 0; x < w; x++) {
/* 1372 */             raster.getPixel(x, y, this.pixel);
/* 1373 */             int alpha = this.pixel[3] & 0xFF;
/* 1374 */             int red = this.pixel[2] & 0xFF;
/* 1375 */             int green = this.pixel[1] & 0xFF;
/* 1376 */             int blue = this.pixel[0] & 0xFF;
/*      */ 
/*      */             
/* 1379 */             this.pixels[y * w + x] = alpha << 24 | blue << 16 | green << 8 | red;
/*      */           } 
/*      */         } 
/* 1382 */         X11.XWindowAttributes xwa = new X11.XWindowAttributes();
/* 1383 */         x11.XGetWindowAttributes(dpy, win, xwa);
/* 1384 */         X11.XImage image = x11.XCreateImage(dpy, xwa.visual, 32, 2, 0, (Pointer)this.buffer, w, h, 32, w * 4);
/*      */ 
/*      */         
/* 1387 */         this.buffer.write(0L, this.pixels, 0, this.pixels.length);
/* 1388 */         offset.x += bounds.x;
/* 1389 */         offset.y += bounds.y;
/* 1390 */         x11.XPutImage(dpy, (X11.Drawable)win, gc, image, 0, 0, offset.x, offset.y, w, h);
/*      */         
/* 1392 */         x11.XFree(image.getPointer());
/* 1393 */         x11.XFreeGC(dpy, gc);
/* 1394 */         x11.XCloseDisplay(dpy);
/*      */       } }
/*      */ 
/*      */ 
/*      */     
/*      */     public void setWindowTransparent(final Window w, final boolean transparent) {
/* 1400 */       if (!(w instanceof RootPaneContainer)) {
/* 1401 */         throw new IllegalArgumentException("Window must be a RootPaneContainer");
/*      */       }
/* 1403 */       if (!isWindowAlphaSupported()) {
/* 1404 */         throw new UnsupportedOperationException("This X11 display does not provide a 32-bit visual");
/*      */       }
/* 1406 */       if (!w.getGraphicsConfiguration().equals(getAlphaCompatibleGraphicsConfiguration()))
/*      */       {
/* 1408 */         throw new IllegalArgumentException("Window GraphicsConfiguration '" + w.getGraphicsConfiguration() + "' does not support transparency");
/*      */       }
/* 1410 */       boolean isTransparent = (w.getBackground() != null && w.getBackground().getAlpha() == 0);
/*      */       
/* 1412 */       if (transparent == isTransparent)
/*      */         return; 
/* 1414 */       whenDisplayable(w, new Runnable() {
/*      */             public void run() {
/* 1416 */               JRootPane root = ((RootPaneContainer)w).getRootPane();
/* 1417 */               JLayeredPane lp = root.getLayeredPane();
/* 1418 */               Container content = root.getContentPane();
/* 1419 */               if (content instanceof WindowUtils.X11WindowUtils.X11TransparentContentPane) {
/* 1420 */                 ((WindowUtils.X11WindowUtils.X11TransparentContentPane)content).setTransparent(transparent);
/*      */               }
/* 1422 */               else if (transparent) {
/* 1423 */                 WindowUtils.X11WindowUtils.X11TransparentContentPane x11content = new WindowUtils.X11WindowUtils.X11TransparentContentPane(content);
/*      */                 
/* 1425 */                 root.setContentPane(x11content);
/* 1426 */                 lp.add(new WindowUtils.RepaintTrigger(x11content), JLayeredPane.DRAG_LAYER);
/*      */               } 
/*      */               
/* 1429 */               WindowUtils.X11WindowUtils.this.setLayersTransparent(w, transparent);
/* 1430 */               WindowUtils.X11WindowUtils.this.setForceHeavyweightPopups(w, transparent);
/* 1431 */               WindowUtils.X11WindowUtils.this.setDoubleBuffered(w, !transparent);
/*      */             }
/*      */           });
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     private void setWindowShape(final Window w, final PixmapSource src) {
/* 1441 */       Runnable action = new Runnable() {
/*      */           public void run() {
/* 1443 */             X11 x11 = X11.INSTANCE;
/* 1444 */             X11.Display dpy = x11.XOpenDisplay(null);
/* 1445 */             if (dpy == null) {
/*      */               return;
/*      */             }
/* 1448 */             X11.Pixmap pm = null;
/*      */             try {
/* 1450 */               X11.Window win = WindowUtils.X11WindowUtils.getDrawable(w);
/* 1451 */               pm = src.getPixmap(dpy, win);
/* 1452 */               X11.Xext ext = X11.Xext.INSTANCE;
/* 1453 */               ext.XShapeCombineMask(dpy, win, 0, 0, 0, (pm == null) ? X11.Pixmap.None : pm, 0);
/*      */             
/*      */             }
/*      */             finally {
/*      */               
/* 1458 */               if (pm != null) {
/* 1459 */                 x11.XFreePixmap(dpy, pm);
/*      */               }
/* 1461 */               x11.XCloseDisplay(dpy);
/*      */             } 
/* 1463 */             WindowUtils.X11WindowUtils.this.setForceHeavyweightPopups(WindowUtils.X11WindowUtils.this.getWindow(w), (pm != null));
/*      */           }
/*      */         };
/* 1466 */       whenDisplayable(w, action);
/*      */     }
/*      */     
/*      */     protected void setMask(Component w, final Raster raster) {
/* 1470 */       setWindowShape(getWindow(w), new PixmapSource() {
/*      */             public X11.Pixmap getPixmap(X11.Display dpy, X11.Window win) {
/* 1472 */               return (raster != null) ? WindowUtils.X11WindowUtils.createBitmap(dpy, win, raster) : null;
/*      */             }
/*      */           });
/*      */     }
/*      */     
/*      */     private X11WindowUtils() {}
/*      */     
/*      */     private static interface PixmapSource {
/*      */       X11.Pixmap getPixmap(X11.Display param2Display, X11.Window param2Window); }
/*      */   }
/*      */   
/*      */   public static void setWindowMask(Window w, Shape mask) {
/* 1484 */     getInstance().setWindowMask(w, mask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setComponentMask(Component c, Shape mask) {
/* 1493 */     getInstance().setWindowMask(c, mask);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setWindowMask(Window w, Icon mask) {
/* 1502 */     getInstance().setWindowMask(w, mask);
/*      */   }
/*      */ 
/*      */   
/*      */   public static boolean isWindowAlphaSupported() {
/* 1507 */     return getInstance().isWindowAlphaSupported();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static GraphicsConfiguration getAlphaCompatibleGraphicsConfiguration() {
/* 1515 */     return getInstance().getAlphaCompatibleGraphicsConfiguration();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setWindowAlpha(Window w, float alpha) {
/* 1533 */     getInstance().setWindowAlpha(w, Math.max(0.0F, Math.min(alpha, 1.0F)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setWindowTransparent(Window w, boolean transparent) {
/* 1549 */     getInstance().setWindowTransparent(w, transparent);
/*      */   }
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/WindowUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */