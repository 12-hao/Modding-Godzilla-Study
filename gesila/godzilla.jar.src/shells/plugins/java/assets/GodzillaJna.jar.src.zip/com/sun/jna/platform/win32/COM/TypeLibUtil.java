/*     */ package com.sun.jna.platform.win32.COM;
/*     */ 
/*     */ import com.sun.jna.WString;
/*     */ import com.sun.jna.platform.win32.Guid;
/*     */ import com.sun.jna.platform.win32.Kernel32;
/*     */ import com.sun.jna.platform.win32.OaIdl;
/*     */ import com.sun.jna.platform.win32.Ole32;
/*     */ import com.sun.jna.platform.win32.OleAuto;
/*     */ import com.sun.jna.platform.win32.WTypes;
/*     */ import com.sun.jna.platform.win32.WinDef;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.ptr.PointerByReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TypeLibUtil
/*     */ {
/*  43 */   public static final OleAuto OLEAUTO = OleAuto.INSTANCE;
/*     */ 
/*     */   
/*     */   private ITypeLib typelib;
/*     */ 
/*     */   
/*  49 */   private WinDef.LCID lcid = Kernel32.INSTANCE.GetUserDefaultLCID();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String docString;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int helpContext;
/*     */ 
/*     */ 
/*     */   
/*     */   private String helpFile;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeLibUtil(String clsidStr, int wVerMajor, int wVerMinor) {
/*  74 */     Guid.CLSID.ByReference clsid = new Guid.CLSID.ByReference();
/*     */     
/*  76 */     WinNT.HRESULT hr = Ole32.INSTANCE.CLSIDFromString(new WString(clsidStr), clsid);
/*     */     
/*  78 */     COMUtils.checkRC(hr);
/*     */ 
/*     */     
/*  81 */     PointerByReference pTypeLib = new PointerByReference();
/*  82 */     hr = OleAuto.INSTANCE.LoadRegTypeLib((Guid.GUID)clsid, wVerMajor, wVerMinor, this.lcid, pTypeLib);
/*     */     
/*  84 */     COMUtils.checkRC(hr);
/*     */ 
/*     */     
/*  87 */     this.typelib = new TypeLib(pTypeLib.getValue());
/*     */     
/*  89 */     initTypeLibInfo();
/*     */   }
/*     */ 
/*     */   
/*     */   public TypeLibUtil(String file) {
/*  94 */     PointerByReference pTypeLib = new PointerByReference();
/*  95 */     WinNT.HRESULT hr = OleAuto.INSTANCE.LoadTypeLib(new WString(file), pTypeLib);
/*  96 */     COMUtils.checkRC(hr);
/*     */ 
/*     */     
/*  99 */     this.typelib = new TypeLib(pTypeLib.getValue());
/*     */     
/* 101 */     initTypeLibInfo();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initTypeLibInfo() {
/* 108 */     TypeLibDoc documentation = getDocumentation(-1);
/* 109 */     this.name = documentation.getName();
/* 110 */     this.docString = documentation.getDocString();
/* 111 */     this.helpContext = documentation.getHelpContext();
/* 112 */     this.helpFile = documentation.getHelpFile();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeInfoCount() {
/* 121 */     return this.typelib.GetTypeInfoCount().intValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OaIdl.TYPEKIND getTypeInfoType(int index) {
/* 132 */     OaIdl.TYPEKIND.ByReference typekind = new OaIdl.TYPEKIND.ByReference();
/* 133 */     WinNT.HRESULT hr = this.typelib.GetTypeInfoType(new WinDef.UINT(index), typekind);
/* 134 */     COMUtils.checkRC(hr);
/* 135 */     return (OaIdl.TYPEKIND)typekind;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeInfo getTypeInfo(int index) {
/* 146 */     PointerByReference ppTInfo = new PointerByReference();
/* 147 */     WinNT.HRESULT hr = this.typelib.GetTypeInfo(new WinDef.UINT(index), ppTInfo);
/* 148 */     COMUtils.checkRC(hr);
/* 149 */     return new TypeInfo(ppTInfo.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeInfoUtil getTypeInfoUtil(int index) {
/* 160 */     return new TypeInfoUtil(getTypeInfo(index));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OaIdl.TLIBATTR getLibAttr() {
/* 169 */     PointerByReference ppTLibAttr = new PointerByReference();
/* 170 */     WinNT.HRESULT hr = this.typelib.GetLibAttr(ppTLibAttr);
/* 171 */     COMUtils.checkRC(hr);
/*     */     
/* 173 */     return new OaIdl.TLIBATTR(ppTLibAttr.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeComp GetTypeComp() {
/* 182 */     PointerByReference ppTComp = new PointerByReference();
/* 183 */     WinNT.HRESULT hr = this.typelib.GetTypeComp(ppTComp);
/* 184 */     COMUtils.checkRC(hr);
/*     */     
/* 186 */     return new TypeComp(ppTComp.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeLibDoc getDocumentation(int index) {
/* 197 */     WTypes.BSTRByReference pBstrName = new WTypes.BSTRByReference();
/* 198 */     WTypes.BSTRByReference pBstrDocString = new WTypes.BSTRByReference();
/* 199 */     WinDef.DWORDByReference pdwHelpContext = new WinDef.DWORDByReference();
/* 200 */     WTypes.BSTRByReference pBstrHelpFile = new WTypes.BSTRByReference();
/*     */     
/* 202 */     WinNT.HRESULT hr = this.typelib.GetDocumentation(index, pBstrName, pBstrDocString, pdwHelpContext, pBstrHelpFile);
/*     */     
/* 204 */     COMUtils.checkRC(hr);
/*     */     
/* 206 */     TypeLibDoc typeLibDoc = new TypeLibDoc(pBstrName.getString(), pBstrDocString.getString(), pdwHelpContext.getValue().intValue(), pBstrHelpFile.getString());
/*     */ 
/*     */ 
/*     */     
/* 210 */     OLEAUTO.SysFreeString(pBstrName.getValue());
/* 211 */     OLEAUTO.SysFreeString(pBstrDocString.getValue());
/* 212 */     OLEAUTO.SysFreeString(pBstrHelpFile.getValue());
/*     */     
/* 214 */     return typeLibDoc;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class TypeLibDoc
/*     */   {
/*     */     private String name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String docString;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private int helpContext;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private String helpFile;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public TypeLibDoc(String name, String docString, int helpContext, String helpFile) {
/* 250 */       this.name = name;
/* 251 */       this.docString = docString;
/* 252 */       this.helpContext = helpContext;
/* 253 */       this.helpFile = helpFile;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getName() {
/* 262 */       return this.name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getDocString() {
/* 271 */       return this.docString;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public int getHelpContext() {
/* 280 */       return this.helpContext;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getHelpFile() {
/* 289 */       return this.helpFile;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IsName IsName(String nameBuf, int hashVal) {
/* 304 */     WTypes.LPOLESTR szNameBuf = new WTypes.LPOLESTR(nameBuf);
/* 305 */     WinDef.ULONG lHashVal = new WinDef.ULONG(hashVal);
/* 306 */     WinDef.BOOLByReference pfName = new WinDef.BOOLByReference();
/*     */     
/* 308 */     WinNT.HRESULT hr = this.typelib.IsName(szNameBuf, lHashVal, pfName);
/* 309 */     COMUtils.checkRC(hr);
/*     */     
/* 311 */     return new IsName(szNameBuf.getValue(), pfName.getValue().booleanValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class IsName
/*     */   {
/*     */     private String nameBuf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private boolean name;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IsName(String nameBuf, boolean name) {
/* 337 */       this.nameBuf = nameBuf;
/* 338 */       this.name = name;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getNameBuf() {
/* 347 */       return this.nameBuf;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean isName() {
/* 356 */       return this.name;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public FindName FindName(String name, int hashVal, short found) {
/* 373 */     WTypes.BSTRByReference szNameBuf = new WTypes.BSTRByReference(OleAuto.INSTANCE.SysAllocString(name));
/*     */     
/* 375 */     WinDef.ULONG lHashVal = new WinDef.ULONG(hashVal);
/* 376 */     WinDef.USHORTByReference pcFound = new WinDef.USHORTByReference(found);
/*     */     
/* 378 */     WinNT.HRESULT hr = this.typelib.FindName(szNameBuf, lHashVal, null, null, pcFound);
/*     */     
/* 380 */     COMUtils.checkRC(hr);
/*     */     
/* 382 */     found = pcFound.getValue().shortValue();
/* 383 */     ITypeInfo[] ppTInfo = new ITypeInfo[found];
/* 384 */     OaIdl.MEMBERID[] rgMemId = new OaIdl.MEMBERID[found];
/* 385 */     hr = this.typelib.FindName(szNameBuf, lHashVal, ppTInfo, rgMemId, pcFound);
/*     */     
/* 387 */     COMUtils.checkRC(hr);
/*     */     
/* 389 */     FindName findName = new FindName(szNameBuf.getString(), ppTInfo, rgMemId, found);
/*     */     
/* 391 */     OLEAUTO.SysFreeString(szNameBuf.getValue());
/*     */     
/* 393 */     return findName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class FindName
/*     */   {
/*     */     private String nameBuf;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private ITypeInfo[] pTInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private OaIdl.MEMBERID[] rgMemId;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private short pcFound;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public FindName(String nameBuf, ITypeInfo[] pTInfo, OaIdl.MEMBERID[] rgMemId, short pcFound) {
/* 429 */       this.nameBuf = nameBuf;
/* 430 */       this.pTInfo = pTInfo;
/* 431 */       this.rgMemId = rgMemId;
/* 432 */       this.pcFound = pcFound;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String getNameBuf() {
/* 441 */       return this.nameBuf;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public ITypeInfo[] getTInfo() {
/* 450 */       return this.pTInfo;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public OaIdl.MEMBERID[] getMemId() {
/* 459 */       return this.rgMemId;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public short getFound() {
/* 468 */       return this.pcFound;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void ReleaseTLibAttr(OaIdl.TLIBATTR pTLibAttr) {
/* 479 */     this.typelib.ReleaseTLibAttr(pTLibAttr);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public WinDef.LCID getLcid() {
/* 488 */     return this.lcid;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ITypeLib getTypelib() {
/* 497 */     return this.typelib;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getName() {
/* 506 */     return this.name;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDocString() {
/* 515 */     return this.docString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public long getHelpContext() {
/* 524 */     return this.helpContext;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getHelpFile() {
/* 533 */     return this.helpFile;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/COM/TypeLibUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */