/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.Structure;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Guid
/*     */ {
/*  31 */   public static final IID IID_NULL = new IID();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class GUID
/*     */     extends Structure
/*     */   {
/*     */     public int Data1;
/*     */ 
/*     */ 
/*     */     
/*     */     public short Data2;
/*     */ 
/*     */ 
/*     */     
/*     */     public short Data3;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static class ByReference
/*     */       extends GUID
/*     */       implements Structure.ByReference
/*     */     {
/*     */       public ByReference() {}
/*     */ 
/*     */ 
/*     */       
/*     */       public ByReference(Guid.GUID guid) {
/*  61 */         super(guid.getPointer());
/*     */         
/*  63 */         this.Data1 = guid.Data1;
/*  64 */         this.Data2 = guid.Data2;
/*  65 */         this.Data3 = guid.Data3;
/*  66 */         this.Data4 = guid.Data4;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ByReference(Pointer memory) {
/*  76 */         super(memory);
/*     */       }
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  90 */     public byte[] Data4 = new byte[8];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GUID() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GUID(GUID guid) {
/* 105 */       this.Data1 = guid.Data1;
/* 106 */       this.Data2 = guid.Data2;
/* 107 */       this.Data3 = guid.Data3;
/* 108 */       this.Data4 = guid.Data4;
/*     */       
/* 110 */       writeFieldsToMemory();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GUID(String guid) {
/* 120 */       this(fromString(guid));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GUID(byte[] data) {
/* 130 */       this(fromBinary(data));
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public GUID(Pointer memory) {
/* 140 */       super(memory);
/* 141 */       read();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static GUID fromBinary(byte[] data) {
/* 152 */       if (data.length != 16) {
/* 153 */         throw new IllegalArgumentException("Invalid data length: " + data.length);
/*     */       }
/*     */ 
/*     */       
/* 157 */       GUID newGuid = new GUID();
/* 158 */       long data1Temp = (data[0] & 0xFF);
/* 159 */       data1Temp <<= 8L;
/* 160 */       data1Temp |= (data[1] & 0xFF);
/* 161 */       data1Temp <<= 8L;
/* 162 */       data1Temp |= (data[2] & 0xFF);
/* 163 */       data1Temp <<= 8L;
/* 164 */       data1Temp |= (data[3] & 0xFF);
/* 165 */       newGuid.Data1 = (int)data1Temp;
/*     */       
/* 167 */       int data2Temp = data[4] & 0xFF;
/* 168 */       data2Temp <<= 8;
/* 169 */       data2Temp |= data[5] & 0xFF;
/* 170 */       newGuid.Data2 = (short)data2Temp;
/*     */       
/* 172 */       int data3Temp = data[6] & 0xFF;
/* 173 */       data3Temp <<= 8;
/* 174 */       data3Temp |= data[7] & 0xFF;
/* 175 */       newGuid.Data3 = (short)data3Temp;
/*     */       
/* 177 */       newGuid.Data4[0] = data[8];
/* 178 */       newGuid.Data4[1] = data[9];
/* 179 */       newGuid.Data4[2] = data[10];
/* 180 */       newGuid.Data4[3] = data[11];
/* 181 */       newGuid.Data4[4] = data[12];
/* 182 */       newGuid.Data4[5] = data[13];
/* 183 */       newGuid.Data4[6] = data[14];
/* 184 */       newGuid.Data4[7] = data[15];
/*     */       
/* 186 */       newGuid.writeFieldsToMemory();
/*     */       
/* 188 */       return newGuid;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static GUID fromString(String guid) {
/* 199 */       int y = 0;
/* 200 */       char[] _cnewguid = new char[32];
/* 201 */       char[] _cguid = guid.toCharArray();
/* 202 */       byte[] bdata = new byte[16];
/* 203 */       GUID newGuid = new GUID();
/*     */ 
/*     */       
/* 206 */       if (guid.length() > 38) {
/* 207 */         throw new IllegalArgumentException("Invalid guid length: " + guid.length());
/*     */       }
/*     */       
/*     */       int i;
/*     */       
/* 212 */       for (i = 0; i < _cguid.length; i++) {
/* 213 */         if (_cguid[i] != '{' && _cguid[i] != '-' && _cguid[i] != '}')
/*     */         {
/* 215 */           _cnewguid[y++] = _cguid[i];
/*     */         }
/*     */       } 
/*     */       
/* 219 */       for (i = 0; i < 32; i += 2) {
/* 220 */         bdata[i / 2] = (byte)((Character.digit(_cnewguid[i], 16) << 4) + Character.digit(_cnewguid[i + 1], 16) & 0xFF);
/*     */       }
/*     */ 
/*     */       
/* 224 */       if (bdata.length != 16) {
/* 225 */         throw new IllegalArgumentException("Invalid data length: " + bdata.length);
/*     */       }
/*     */ 
/*     */       
/* 229 */       long data1Temp = (bdata[0] & 0xFF);
/* 230 */       data1Temp <<= 8L;
/* 231 */       data1Temp |= (bdata[1] & 0xFF);
/* 232 */       data1Temp <<= 8L;
/* 233 */       data1Temp |= (bdata[2] & 0xFF);
/* 234 */       data1Temp <<= 8L;
/* 235 */       data1Temp |= (bdata[3] & 0xFF);
/* 236 */       newGuid.Data1 = (int)data1Temp;
/*     */       
/* 238 */       int data2Temp = bdata[4] & 0xFF;
/* 239 */       data2Temp <<= 8;
/* 240 */       data2Temp |= bdata[5] & 0xFF;
/* 241 */       newGuid.Data2 = (short)data2Temp;
/*     */       
/* 243 */       int data3Temp = bdata[6] & 0xFF;
/* 244 */       data3Temp <<= 8;
/* 245 */       data3Temp |= bdata[7] & 0xFF;
/* 246 */       newGuid.Data3 = (short)data3Temp;
/*     */       
/* 248 */       newGuid.Data4[0] = bdata[8];
/* 249 */       newGuid.Data4[1] = bdata[9];
/* 250 */       newGuid.Data4[2] = bdata[10];
/* 251 */       newGuid.Data4[3] = bdata[11];
/* 252 */       newGuid.Data4[4] = bdata[12];
/* 253 */       newGuid.Data4[5] = bdata[13];
/* 254 */       newGuid.Data4[6] = bdata[14];
/* 255 */       newGuid.Data4[7] = bdata[15];
/*     */       
/* 257 */       newGuid.writeFieldsToMemory();
/*     */       
/* 259 */       return newGuid;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public static GUID newGuid() {
/* 269 */       SecureRandom ng = new SecureRandom();
/* 270 */       byte[] randomBytes = new byte[16];
/*     */       
/* 272 */       ng.nextBytes(randomBytes);
/* 273 */       randomBytes[6] = (byte)(randomBytes[6] & 0xF);
/* 274 */       randomBytes[6] = (byte)(randomBytes[6] | 0x40);
/* 275 */       randomBytes[8] = (byte)(randomBytes[8] & 0x3F);
/* 276 */       randomBytes[8] = (byte)(randomBytes[8] | 0x80);
/*     */       
/* 278 */       return new GUID(randomBytes);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public byte[] toByteArray() {
/* 287 */       byte[] guid = new byte[16];
/*     */       
/* 289 */       byte[] bytes1 = new byte[4];
/* 290 */       bytes1[0] = (byte)(this.Data1 >> 24);
/* 291 */       bytes1[1] = (byte)(this.Data1 >> 16);
/* 292 */       bytes1[2] = (byte)(this.Data1 >> 8);
/* 293 */       bytes1[3] = (byte)(this.Data1 >> 0);
/*     */       
/* 295 */       byte[] bytes2 = new byte[4];
/* 296 */       bytes2[0] = (byte)(this.Data2 >> 24);
/* 297 */       bytes2[1] = (byte)(this.Data2 >> 16);
/* 298 */       bytes2[2] = (byte)(this.Data2 >> 8);
/* 299 */       bytes2[3] = (byte)(this.Data2 >> 0);
/*     */       
/* 301 */       byte[] bytes3 = new byte[4];
/* 302 */       bytes3[0] = (byte)(this.Data3 >> 24);
/* 303 */       bytes3[1] = (byte)(this.Data3 >> 16);
/* 304 */       bytes3[2] = (byte)(this.Data3 >> 8);
/* 305 */       bytes3[3] = (byte)(this.Data3 >> 0);
/*     */       
/* 307 */       System.arraycopy(bytes1, 0, guid, 0, 4);
/* 308 */       System.arraycopy(bytes2, 2, guid, 4, 2);
/* 309 */       System.arraycopy(bytes3, 2, guid, 6, 2);
/* 310 */       System.arraycopy(this.Data4, 0, guid, 8, 8);
/*     */       
/* 312 */       return guid;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public String toGuidString() {
/* 322 */       String HEXES = "0123456789ABCDEF";
/* 323 */       byte[] bGuid = toByteArray();
/*     */       
/* 325 */       StringBuilder hexStr = new StringBuilder(2 * bGuid.length);
/* 326 */       hexStr.append("{");
/*     */       
/* 328 */       for (int i = 0; i < bGuid.length; i++) {
/* 329 */         char ch1 = "0123456789ABCDEF".charAt((bGuid[i] & 0xF0) >> 4);
/* 330 */         char ch2 = "0123456789ABCDEF".charAt(bGuid[i] & 0xF);
/* 331 */         hexStr.append(ch1).append(ch2);
/*     */         
/* 333 */         if (i == 3 || i == 5 || i == 7 || i == 9) {
/* 334 */           hexStr.append("-");
/*     */         }
/*     */       } 
/* 337 */       hexStr.append("}");
/* 338 */       return hexStr.toString();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected void writeFieldsToMemory() {
/* 345 */       writeField("Data1");
/* 346 */       writeField("Data2");
/* 347 */       writeField("Data3");
/* 348 */       writeField("Data4");
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     protected List getFieldOrder() {
/* 357 */       return Arrays.asList(new String[] { "Data1", "Data2", "Data3", "Data4" });
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class CLSID
/*     */     extends GUID
/*     */   {
/*     */     public static class ByReference
/*     */       extends Guid.GUID
/*     */     {
/*     */       public ByReference() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ByReference(Guid.GUID guid) {
/* 389 */         super(guid);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       public ByReference(Pointer memory) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CLSID() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CLSID(String guid) {
/* 415 */       super(guid);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public CLSID(Guid.GUID guid) {
/* 424 */       super(guid);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class REFIID
/*     */     extends IID
/*     */   {
/*     */     public REFIID() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public REFIID(Pointer memory) {
/* 449 */       super(memory);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public REFIID(byte[] data) {
/* 460 */       super(data);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class IID
/*     */     extends GUID
/*     */   {
/*     */     public IID() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IID(Pointer memory) {
/* 487 */       super(memory);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IID(String iid) {
/* 497 */       super(iid);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public IID(byte[] data) {
/* 508 */       super(data);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/Guid.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */