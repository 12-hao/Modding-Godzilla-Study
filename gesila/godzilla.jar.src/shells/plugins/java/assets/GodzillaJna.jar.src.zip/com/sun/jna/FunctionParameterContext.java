/*    */ package com.sun.jna;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FunctionParameterContext
/*    */   extends ToNativeContext
/*    */ {
/*    */   private Function function;
/*    */   private Object[] args;
/*    */   private int index;
/*    */   
/*    */   FunctionParameterContext(Function f, Object[] args, int index) {
/* 23 */     this.function = f;
/* 24 */     this.args = args;
/* 25 */     this.index = index;
/*    */   }
/*    */   public Function getFunction() {
/* 28 */     return this.function;
/*    */   }
/* 30 */   public Object[] getParameters() { return this.args; } public int getParameterIndex() {
/* 31 */     return this.index;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/FunctionParameterContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */