package com.sun.jna;

public interface AltCallingConvention {}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/AltCallingConvention.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */