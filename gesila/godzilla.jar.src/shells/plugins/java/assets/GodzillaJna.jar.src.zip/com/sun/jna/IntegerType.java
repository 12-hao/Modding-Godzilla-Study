/*     */ package com.sun.jna;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class IntegerType
/*     */   extends Number
/*     */   implements NativeMapped
/*     */ {
/*     */   private int size;
/*     */   private Number number;
/*     */   private boolean unsigned;
/*     */   private long value;
/*     */   
/*     */   public IntegerType(int size) {
/*  38 */     this(size, 0L, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntegerType(int size, boolean unsigned) {
/*  43 */     this(size, 0L, unsigned);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntegerType(int size, long value) {
/*  48 */     this(size, value, false);
/*     */   }
/*     */ 
/*     */   
/*     */   public IntegerType(int size, long value, boolean unsigned) {
/*  53 */     this.size = size;
/*  54 */     this.unsigned = unsigned;
/*  55 */     setValue(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void setValue(long value) {
/*  60 */     long truncated = value;
/*  61 */     this.value = value;
/*  62 */     switch (this.size) {
/*     */       case 1:
/*  64 */         if (this.unsigned) this.value = value & 0xFFL; 
/*  65 */         truncated = (byte)(int)value;
/*  66 */         this.number = new Byte((byte)(int)value);
/*     */         break;
/*     */       case 2:
/*  69 */         if (this.unsigned) this.value = value & 0xFFFFL; 
/*  70 */         truncated = (short)(int)value;
/*  71 */         this.number = new Short((short)(int)value);
/*     */         break;
/*     */       case 4:
/*  74 */         if (this.unsigned) this.value = value & 0xFFFFFFFFL; 
/*  75 */         truncated = (int)value;
/*  76 */         this.number = new Integer((int)value);
/*     */         break;
/*     */       case 8:
/*  79 */         this.number = new Long(value);
/*     */         break;
/*     */       default:
/*  82 */         throw new IllegalArgumentException("Unsupported size: " + this.size);
/*     */     } 
/*  84 */     if (this.size < 8) {
/*  85 */       long mask = (1L << this.size * 8) - 1L ^ 0xFFFFFFFFFFFFFFFFL;
/*  86 */       if ((value < 0L && truncated != value) || (value >= 0L && (mask & value) != 0L))
/*     */       {
/*  88 */         throw new IllegalArgumentException("Argument value 0x" + Long.toHexString(value) + " exceeds native capacity (" + this.size + " bytes) mask=0x" + Long.toHexString(mask));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public Object toNative() {
/*  96 */     return this.number;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object fromNative(Object nativeValue, FromNativeContext context) {
/* 101 */     long value = (nativeValue == null) ? 0L : ((Number)nativeValue).longValue();
/*     */     
/*     */     try {
/* 104 */       IntegerType number = (IntegerType)getClass().newInstance();
/* 105 */       number.setValue(value);
/* 106 */       return number;
/*     */     }
/* 108 */     catch (InstantiationException e) {
/* 109 */       throw new IllegalArgumentException("Can't instantiate " + getClass());
/*     */     
/*     */     }
/* 112 */     catch (IllegalAccessException e) {
/* 113 */       throw new IllegalArgumentException("Not allowed to instantiate " + getClass());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public Class nativeType() {
/* 119 */     return this.number.getClass();
/*     */   }
/*     */   
/*     */   public int intValue() {
/* 123 */     return (int)this.value;
/*     */   }
/*     */   
/*     */   public long longValue() {
/* 127 */     return this.value;
/*     */   }
/*     */   
/*     */   public float floatValue() {
/* 131 */     return this.number.floatValue();
/*     */   }
/*     */   
/*     */   public double doubleValue() {
/* 135 */     return this.number.doubleValue();
/*     */   }
/*     */   
/*     */   public boolean equals(Object rhs) {
/* 139 */     return (rhs instanceof IntegerType && this.number.equals(((IntegerType)rhs).number));
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 144 */     return this.number.toString();
/*     */   }
/*     */   
/*     */   public int hashCode() {
/* 148 */     return this.number.hashCode();
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/IntegerType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */