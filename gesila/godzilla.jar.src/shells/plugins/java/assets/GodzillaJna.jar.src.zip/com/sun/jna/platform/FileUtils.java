/*     */ package com.sun.jna.platform;
/*     */ 
/*     */ import com.sun.jna.platform.mac.MacFileUtils;
/*     */ import com.sun.jna.platform.win32.W32FileUtils;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class FileUtils
/*     */ {
/*     */   public boolean hasTrash() {
/*  27 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract void moveToTrash(File[] paramArrayOfFile) throws IOException;
/*     */ 
/*     */   
/*     */   private static class Holder
/*     */   {
/*     */     public static final FileUtils INSTANCE;
/*     */     
/*     */     static {
/*  39 */       String os = System.getProperty("os.name");
/*  40 */       if (os.startsWith("Windows")) {
/*  41 */         INSTANCE = (FileUtils)new W32FileUtils();
/*     */       }
/*  43 */       else if (os.startsWith("Mac")) {
/*  44 */         INSTANCE = (FileUtils)new MacFileUtils();
/*     */       } else {
/*     */         
/*  47 */         INSTANCE = new FileUtils.DefaultFileUtils();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static FileUtils getInstance() {
/*  53 */     return Holder.INSTANCE;
/*     */   }
/*     */   
/*     */   private static class DefaultFileUtils
/*     */     extends FileUtils {
/*     */     private DefaultFileUtils() {}
/*     */     
/*     */     private File getTrashDirectory() {
/*  61 */       File home = new File(System.getProperty("user.home"));
/*  62 */       File trash = new File(home, ".Trash");
/*  63 */       if (!trash.exists()) {
/*  64 */         trash = new File(home, "Trash");
/*  65 */         if (!trash.exists()) {
/*  66 */           File desktop = new File(home, "Desktop");
/*  67 */           if (desktop.exists()) {
/*  68 */             trash = new File(desktop, ".Trash");
/*  69 */             if (!trash.exists()) {
/*  70 */               trash = new File(desktop, "Trash");
/*  71 */               if (!trash.exists()) {
/*  72 */                 trash = new File(System.getProperty("fileutils.trash", "Trash"));
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*  78 */       return trash;
/*     */     }
/*     */     
/*     */     public boolean hasTrash() {
/*  82 */       return getTrashDirectory().exists();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public void moveToTrash(File[] files) throws IOException {
/*  89 */       File trash = getTrashDirectory();
/*  90 */       if (!trash.exists()) {
/*  91 */         throw new IOException("No trash location found (define fileutils.trash to be the path to the trash)");
/*     */       }
/*  93 */       List<File> failed = new ArrayList<File>();
/*  94 */       for (int i = 0; i < files.length; i++) {
/*  95 */         File src = files[i];
/*  96 */         File target = new File(trash, src.getName());
/*  97 */         if (!src.renameTo(target)) {
/*  98 */           failed.add(src);
/*     */         }
/*     */       } 
/* 101 */       if (failed.size() > 0)
/* 102 */         throw new IOException("The following files could not be trashed: " + failed); 
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/FileUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */