/*     */ package com.sun.jna.platform.win32.COM;
/*     */ 
/*     */ import com.sun.jna.WString;
/*     */ import com.sun.jna.platform.win32.Guid;
/*     */ import com.sun.jna.platform.win32.Kernel32;
/*     */ import com.sun.jna.platform.win32.OaIdl;
/*     */ import com.sun.jna.platform.win32.Ole32;
/*     */ import com.sun.jna.platform.win32.OleAuto;
/*     */ import com.sun.jna.platform.win32.Variant;
/*     */ import com.sun.jna.platform.win32.WinDef;
/*     */ import com.sun.jna.platform.win32.WinNT;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import com.sun.jna.ptr.PointerByReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class COMBindingBaseObject
/*     */   extends COMInvoker
/*     */ {
/*  44 */   public static final WinDef.LCID LOCALE_USER_DEFAULT = Kernel32.INSTANCE.GetUserDefaultLCID();
/*     */ 
/*     */ 
/*     */   
/*  48 */   public static final WinDef.LCID LOCALE_SYSTEM_DEFAULT = Kernel32.INSTANCE.GetSystemDefaultLCID();
/*     */ 
/*     */ 
/*     */   
/*     */   private IUnknown iUnknown;
/*     */ 
/*     */   
/*     */   private IDispatch iDispatch;
/*     */ 
/*     */   
/*  58 */   private PointerByReference pDispatch = new PointerByReference();
/*     */ 
/*     */   
/*  61 */   private PointerByReference pUnknown = new PointerByReference();
/*     */ 
/*     */   
/*     */   public COMBindingBaseObject(IDispatch dispatch) {
/*  65 */     this.iDispatch = dispatch;
/*     */   }
/*     */   
/*     */   public COMBindingBaseObject(Guid.CLSID clsid, boolean useActiveInstance) {
/*  69 */     this(clsid, useActiveInstance, 21);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public COMBindingBaseObject(Guid.CLSID clsid, boolean useActiveInstance, int dwClsContext) {
/*  75 */     WinNT.HRESULT hr = Ole32.INSTANCE.CoInitialize(null);
/*     */     
/*  77 */     if (COMUtils.FAILED(hr)) {
/*  78 */       Ole32.INSTANCE.CoUninitialize();
/*  79 */       throw new COMException("CoInitialize() failed!");
/*     */     } 
/*     */     
/*  82 */     if (useActiveInstance) {
/*  83 */       hr = OleAuto.INSTANCE.GetActiveObject((Guid.GUID)clsid, null, this.pUnknown);
/*     */       
/*  85 */       if (COMUtils.SUCCEEDED(hr)) {
/*  86 */         this.iUnknown = new Unknown(this.pUnknown.getValue());
/*  87 */         hr = this.iUnknown.QueryInterface(IDispatch.IID_IDISPATCH, this.pDispatch);
/*     */       } else {
/*     */         
/*  90 */         hr = Ole32.INSTANCE.CoCreateInstance((Guid.GUID)clsid, null, dwClsContext, (Guid.GUID)IDispatch.IID_IDISPATCH, this.pDispatch);
/*     */       } 
/*     */     } else {
/*     */       
/*  94 */       hr = Ole32.INSTANCE.CoCreateInstance((Guid.GUID)clsid, null, dwClsContext, (Guid.GUID)IDispatch.IID_IDISPATCH, this.pDispatch);
/*     */     } 
/*     */ 
/*     */     
/*  98 */     if (COMUtils.FAILED(hr)) {
/*  99 */       throw new COMException("COM object with CLSID " + clsid.toGuidString() + " not registered properly!");
/*     */     }
/*     */ 
/*     */     
/* 103 */     this.iDispatch = new Dispatch(this.pDispatch.getValue());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public COMBindingBaseObject(String progId, boolean useActiveInstance, int dwClsContext) throws COMException {
/* 109 */     WinNT.HRESULT hr = Ole32.INSTANCE.CoInitialize(null);
/*     */     
/* 111 */     if (COMUtils.FAILED(hr)) {
/* 112 */       release();
/* 113 */       throw new COMException("CoInitialize() failed!");
/*     */     } 
/*     */ 
/*     */     
/* 117 */     Guid.CLSID.ByReference clsid = new Guid.CLSID.ByReference();
/* 118 */     hr = Ole32.INSTANCE.CLSIDFromProgID(progId, clsid);
/*     */     
/* 120 */     if (COMUtils.FAILED(hr)) {
/* 121 */       Ole32.INSTANCE.CoUninitialize();
/* 122 */       throw new COMException("CLSIDFromProgID() failed!");
/*     */     } 
/*     */     
/* 125 */     if (useActiveInstance) {
/* 126 */       hr = OleAuto.INSTANCE.GetActiveObject((Guid.GUID)clsid, null, this.pUnknown);
/*     */       
/* 128 */       if (COMUtils.SUCCEEDED(hr)) {
/* 129 */         this.iUnknown = new Unknown(this.pUnknown.getValue());
/* 130 */         hr = this.iUnknown.QueryInterface(IDispatch.IID_IDISPATCH, this.pDispatch);
/*     */       } else {
/*     */         
/* 133 */         hr = Ole32.INSTANCE.CoCreateInstance((Guid.GUID)clsid, null, dwClsContext, (Guid.GUID)IDispatch.IID_IDISPATCH, this.pDispatch);
/*     */       } 
/*     */     } else {
/*     */       
/* 137 */       hr = Ole32.INSTANCE.CoCreateInstance((Guid.GUID)clsid, null, dwClsContext, (Guid.GUID)IDispatch.IID_IDISPATCH, this.pDispatch);
/*     */     } 
/*     */ 
/*     */     
/* 141 */     if (COMUtils.FAILED(hr)) {
/* 142 */       throw new COMException("COM object with ProgID '" + progId + "' and CLSID " + clsid.toGuidString() + " not registered properly!");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 147 */     this.iDispatch = new Dispatch(this.pDispatch.getValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public COMBindingBaseObject(String progId, boolean useActiveInstance) throws COMException {
/* 152 */     this(progId, useActiveInstance, 21);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IDispatch getIDispatch() {
/* 161 */     return this.iDispatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointerByReference getIDispatchPointer() {
/* 170 */     return this.pDispatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public IUnknown getIUnknown() {
/* 179 */     return this.iUnknown;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PointerByReference getIUnknownPointer() {
/* 188 */     return this.pUnknown;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void release() {
/* 195 */     if (this.iDispatch != null) {
/* 196 */       this.iDispatch.Release();
/*     */     }
/* 198 */     Ole32.INSTANCE.CoUninitialize();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, String name, Variant.VARIANT[] pArgs) throws COMException {
/* 204 */     if (pDisp == null) {
/* 205 */       throw new COMException("pDisp (IDispatch) parameter is null!");
/*     */     }
/*     */     
/* 208 */     WString[] ptName = { new WString(name) };
/* 209 */     OaIdl.DISPIDByReference pdispID = new OaIdl.DISPIDByReference();
/*     */ 
/*     */     
/* 212 */     WinNT.HRESULT hr = pDisp.GetIDsOfNames(Guid.IID_NULL, ptName, 1, LOCALE_USER_DEFAULT, pdispID);
/*     */ 
/*     */     
/* 215 */     COMUtils.checkRC(hr);
/*     */     
/* 217 */     return oleMethod(nType, pvResult, pDisp, pdispID.getValue(), pArgs);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, OaIdl.DISPID dispId, Variant.VARIANT[] pArgs) throws COMException {
/* 225 */     if (pDisp == null) {
/* 226 */       throw new COMException("pDisp (IDispatch) parameter is null!");
/*     */     }
/*     */     
/* 229 */     int _argsLen = 0;
/* 230 */     Variant.VARIANT[] _args = null;
/* 231 */     OleAuto.DISPPARAMS dp = new OleAuto.DISPPARAMS();
/* 232 */     OaIdl.EXCEPINFO.ByReference pExcepInfo = new OaIdl.EXCEPINFO.ByReference();
/* 233 */     IntByReference puArgErr = new IntByReference();
/*     */ 
/*     */     
/* 236 */     if (pArgs != null && pArgs.length > 0) {
/* 237 */       _argsLen = pArgs.length;
/* 238 */       _args = new Variant.VARIANT[_argsLen];
/*     */       
/* 240 */       int revCount = _argsLen;
/* 241 */       for (int i = 0; i < _argsLen; i++) {
/* 242 */         _args[i] = pArgs[--revCount];
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 247 */     if (nType == 4) {
/* 248 */       dp.cNamedArgs = new WinDef.UINT(_argsLen);
/* 249 */       dp.rgdispidNamedArgs = new OaIdl.DISPIDByReference(OaIdl.DISPID_PROPERTYPUT);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 254 */     if (_argsLen > 0) {
/* 255 */       dp.cArgs = new WinDef.UINT(_args.length);
/*     */       
/* 257 */       dp.rgvarg = new Variant.VariantArg.ByReference(_args);
/*     */ 
/*     */       
/* 260 */       dp.write();
/*     */     } 
/*     */ 
/*     */     
/* 264 */     WinNT.HRESULT hr = pDisp.Invoke(dispId, Guid.IID_NULL, LOCALE_SYSTEM_DEFAULT, new OaIdl.DISPID(nType), dp, pvResult, pExcepInfo, puArgErr);
/*     */ 
/*     */     
/* 267 */     COMUtils.checkRC(hr, (OaIdl.EXCEPINFO)pExcepInfo, puArgErr);
/* 268 */     return hr;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, String name, Variant.VARIANT pArg) throws COMException {
/* 291 */     return oleMethod(nType, pvResult, pDisp, name, new Variant.VARIANT[] { pArg });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, OaIdl.DISPID dispId, Variant.VARIANT pArg) throws COMException {
/* 298 */     return oleMethod(nType, pvResult, pDisp, dispId, new Variant.VARIANT[] { pArg });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, String name) throws COMException {
/* 320 */     return oleMethod(nType, pvResult, pDisp, name, (Variant.VARIANT[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected WinNT.HRESULT oleMethod(int nType, Variant.VARIANT.ByReference pvResult, IDispatch pDisp, OaIdl.DISPID dispId) throws COMException {
/* 326 */     return oleMethod(nType, pvResult, pDisp, dispId, (Variant.VARIANT[])null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkFailed(WinNT.HRESULT hr) {
/* 336 */     COMUtils.checkRC(hr, null, null);
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/COM/COMBindingBaseObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */