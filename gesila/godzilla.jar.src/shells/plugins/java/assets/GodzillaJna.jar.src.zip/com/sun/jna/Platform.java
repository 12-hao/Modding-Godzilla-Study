/*     */ package com.sun.jna;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Platform
/*     */ {
/*     */   public static final int UNSPECIFIED = -1;
/*     */   public static final int MAC = 0;
/*     */   public static final int LINUX = 1;
/*     */   public static final int WINDOWS = 2;
/*     */   public static final int SOLARIS = 3;
/*     */   public static final int FREEBSD = 4;
/*     */   public static final int OPENBSD = 5;
/*     */   public static final int WINDOWSCE = 6;
/*     */   public static final int AIX = 7;
/*     */   public static final int ANDROID = 8;
/*     */   public static final int GNU = 9;
/*     */   public static final int KFREEBSD = 10;
/*     */   public static final int NETBSD = 11;
/*     */   public static final boolean RO_FIELDS;
/*     */   public static final boolean HAS_BUFFERS;
/*     */   
/*     */   static {
/*  52 */     String osName = System.getProperty("os.name");
/*  53 */     if (osName.startsWith("Linux")) {
/*  54 */       if ("dalvik".equals(System.getProperty("java.vm.name").toLowerCase())) {
/*  55 */         osType = 8;
/*     */         
/*  57 */         System.setProperty("jna.nounpack", "true");
/*     */       } else {
/*     */         
/*  60 */         osType = 1;
/*     */       }
/*     */     
/*  63 */     } else if (osName.startsWith("AIX")) {
/*  64 */       osType = 7;
/*     */     }
/*  66 */     else if (osName.startsWith("Mac") || osName.startsWith("Darwin")) {
/*  67 */       osType = 0;
/*     */     }
/*  69 */     else if (osName.startsWith("Windows CE")) {
/*  70 */       osType = 6;
/*     */     }
/*  72 */     else if (osName.startsWith("Windows")) {
/*  73 */       osType = 2;
/*     */     }
/*  75 */     else if (osName.startsWith("Solaris") || osName.startsWith("SunOS")) {
/*  76 */       osType = 3;
/*     */     }
/*  78 */     else if (osName.startsWith("FreeBSD")) {
/*  79 */       osType = 4;
/*     */     }
/*  81 */     else if (osName.startsWith("OpenBSD")) {
/*  82 */       osType = 5;
/*     */     }
/*  84 */     else if (osName.equalsIgnoreCase("gnu")) {
/*  85 */       osType = 9;
/*     */     }
/*  87 */     else if (osName.equalsIgnoreCase("gnu/kfreebsd")) {
/*  88 */       osType = 10;
/*     */     }
/*  90 */     else if (osName.equalsIgnoreCase("netbsd")) {
/*  91 */       osType = 11;
/*     */     } else {
/*     */       
/*  94 */       osType = -1;
/*     */     } 
/*  96 */     boolean hasBuffers = false;
/*     */     try {
/*  98 */       Class.forName("java.nio.Buffer");
/*  99 */       hasBuffers = true;
/*     */     }
/* 101 */     catch (ClassNotFoundException e) {}
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 106 */   public static final boolean HAS_AWT = (osType != 6 && osType != 8 && osType != 7); public static final String MATH_LIBRARY_NAME; public static final String C_LIBRARY_NAME; public static final boolean HAS_DLL_CALLBACKS; static {
/* 107 */     HAS_BUFFERS = hasBuffers;
/* 108 */     RO_FIELDS = (osType != 6);
/* 109 */     C_LIBRARY_NAME = (osType == 2) ? "msvcrt" : ((osType == 6) ? "coredll" : "c");
/* 110 */     MATH_LIBRARY_NAME = (osType == 2) ? "msvcrt" : ((osType == 6) ? "coredll" : "m");
/* 111 */     HAS_DLL_CALLBACKS = (osType == 2);
/* 112 */     RESOURCE_PREFIX = getNativeLibraryResourcePrefix();
/* 113 */     ARCH = System.getProperty("os.arch").toLowerCase().trim();
/*     */   }
/*     */   public static final String RESOURCE_PREFIX; private static final int osType; public static final String ARCH;
/*     */   public static final int getOSType() {
/* 117 */     return osType;
/*     */   }
/*     */   public static final boolean isMac() {
/* 120 */     return (osType == 0);
/*     */   }
/*     */   public static final boolean isAndroid() {
/* 123 */     return (osType == 8);
/*     */   }
/*     */   public static final boolean isLinux() {
/* 126 */     return (osType == 1);
/*     */   }
/*     */   public static final boolean isAIX() {
/* 129 */     return (osType == 7);
/*     */   }
/*     */   
/*     */   public static final boolean isAix() {
/* 133 */     return isAIX();
/*     */   }
/*     */   public static final boolean isWindowsCE() {
/* 136 */     return (osType == 6);
/*     */   }
/*     */   
/*     */   public static final boolean isWindows() {
/* 140 */     return (osType == 2 || osType == 6);
/*     */   }
/*     */   public static final boolean isSolaris() {
/* 143 */     return (osType == 3);
/*     */   }
/*     */   public static final boolean isFreeBSD() {
/* 146 */     return (osType == 4);
/*     */   }
/*     */   public static final boolean isOpenBSD() {
/* 149 */     return (osType == 5);
/*     */   }
/*     */   public static final boolean isNetBSD() {
/* 152 */     return (osType == 11);
/*     */   }
/*     */   public static final boolean isGNU() {
/* 155 */     return (osType == 9);
/*     */   }
/*     */   public static final boolean iskFreeBSD() {
/* 158 */     return (osType == 10);
/*     */   }
/*     */   
/*     */   public static final boolean isX11() {
/* 162 */     return (!isWindows() && !isMac());
/*     */   }
/*     */   public static final boolean hasRuntimeExec() {
/* 165 */     if (isWindowsCE() && "J9".equals(System.getProperty("java.vm.name")))
/* 166 */       return false; 
/* 167 */     return true;
/*     */   }
/*     */   public static final boolean is64Bit() {
/* 170 */     String model = System.getProperty("sun.arch.data.model", System.getProperty("com.ibm.vm.bitmode"));
/*     */     
/* 172 */     if (model != null) {
/* 173 */       return "64".equals(model);
/*     */     }
/* 175 */     if ("x86_64".equals(ARCH) || "ia64".equals(ARCH) || "ppc64".equals(ARCH) || "sparcv9".equals(ARCH) || "amd64".equals(ARCH))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 180 */       return true;
/*     */     }
/* 182 */     return (Native.POINTER_SIZE == 8);
/*     */   }
/*     */   
/*     */   public static final boolean isIntel() {
/* 186 */     if (ARCH.equals("i386") || ARCH.startsWith("i686") || ARCH.equals("x86") || ARCH.equals("x86_64") || ARCH.equals("amd64"))
/*     */     {
/*     */ 
/*     */ 
/*     */       
/* 191 */       return true;
/*     */     }
/* 193 */     return false;
/*     */   }
/*     */   
/*     */   public static final boolean isPPC() {
/* 197 */     if (ARCH.equals("ppc") || ARCH.equals("ppc64") || ARCH.equals("powerpc") || ARCH.equals("powerpc64"))
/*     */     {
/*     */ 
/*     */       
/* 201 */       return true;
/*     */     }
/* 203 */     return false;
/*     */   }
/*     */   
/*     */   public static final boolean isARM() {
/* 207 */     return ARCH.startsWith("arm");
/*     */   }
/*     */   
/*     */   public static final boolean isSPARC() {
/* 211 */     return ARCH.startsWith("sparc");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getNativeLibraryResourcePrefix() {
/* 218 */     return getNativeLibraryResourcePrefix(getOSType(), System.getProperty("os.arch"), System.getProperty("os.name"));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static String getNativeLibraryResourcePrefix(int osType, String arch, String name) {
/* 229 */     arch = arch.toLowerCase().trim();
/* 230 */     if ("powerpc".equals(arch)) {
/* 231 */       arch = "ppc";
/*     */     }
/* 233 */     else if ("powerpc64".equals(arch)) {
/* 234 */       arch = "ppc64";
/*     */     }
/* 236 */     else if ("i386".equals(arch)) {
/* 237 */       arch = "x86";
/*     */     }
/* 239 */     else if ("x86_64".equals(arch) || "amd64".equals(arch)) {
/* 240 */       arch = "x86-64";
/*     */     } 
/* 242 */     switch (osType)
/*     */     { case 8:
/* 244 */         if (arch.startsWith("arm")) {
/* 245 */           arch = "arm";
/*     */         }
/* 247 */         osPrefix = "android-" + arch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 285 */         return osPrefix;case 2: osPrefix = "win32-" + arch; return osPrefix;case 6: osPrefix = "w32ce-" + arch; return osPrefix;case 0: osPrefix = "darwin"; return osPrefix;case 1: osPrefix = "linux-" + arch; return osPrefix;case 3: osPrefix = "sunos-" + arch; return osPrefix;case 4: osPrefix = "freebsd-" + arch; return osPrefix;case 5: osPrefix = "openbsd-" + arch; return osPrefix;case 11: osPrefix = "netbsd-" + arch; return osPrefix;case 10: osPrefix = "kfreebsd-" + arch; return osPrefix; }  String osPrefix = name.toLowerCase(); int space = osPrefix.indexOf(" "); if (space != -1) osPrefix = osPrefix.substring(0, space);  osPrefix = osPrefix + "-" + arch; return osPrefix;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/Platform.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */