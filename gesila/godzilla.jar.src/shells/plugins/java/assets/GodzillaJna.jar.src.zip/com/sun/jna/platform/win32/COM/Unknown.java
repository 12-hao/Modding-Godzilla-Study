/*    */ package com.sun.jna.platform.win32.COM;
/*    */ 
/*    */ import com.sun.jna.Pointer;
/*    */ import com.sun.jna.Structure;
/*    */ import com.sun.jna.platform.win32.Guid;
/*    */ import com.sun.jna.platform.win32.WinNT;
/*    */ import com.sun.jna.ptr.PointerByReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Unknown
/*    */   extends COMInvoker
/*    */   implements IUnknown
/*    */ {
/*    */   public static class ByReference
/*    */     extends Unknown
/*    */     implements Structure.ByReference {}
/*    */   
/*    */   public Unknown() {}
/*    */   
/*    */   public Unknown(Pointer pvInstance) {
/* 46 */     setPointer(pvInstance);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public WinNT.HRESULT QueryInterface(Guid.IID riid, PointerByReference ppvObject) {
/* 59 */     return (WinNT.HRESULT)_invokeNativeObject(0, new Object[] { getPointer(), riid, ppvObject }, WinNT.HRESULT.class);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int AddRef() {
/* 65 */     return _invokeNativeInt(1, new Object[] { getPointer() });
/*    */   }
/*    */   
/*    */   public int Release() {
/* 69 */     return _invokeNativeInt(2, new Object[] { getPointer() });
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/COM/Unknown.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */