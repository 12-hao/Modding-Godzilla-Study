/*    */ package com.sun.jna.platform.win32;
/*    */ 
/*    */ import com.sun.jna.WString;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class User32Util
/*    */ {
/*    */   public static final int registerWindowMessage(String lpString) {
/* 27 */     int messageId = User32.INSTANCE.RegisterWindowMessage(lpString);
/* 28 */     if (messageId == 0)
/* 29 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError()); 
/* 30 */     return messageId;
/*    */   }
/*    */ 
/*    */   
/*    */   public static final WinDef.HWND createWindow(String className, String windowName, int style, int x, int y, int width, int height, WinDef.HWND parent, WinDef.HMENU menu, WinDef.HINSTANCE instance, WinDef.LPVOID param) {
/* 35 */     return createWindowEx(0, className, windowName, style, x, y, width, height, parent, menu, instance, param);
/*    */   }
/*    */ 
/*    */   
/*    */   public static final WinDef.HWND createWindowEx(int exStyle, String className, String windowName, int style, int x, int y, int width, int height, WinDef.HWND parent, WinDef.HMENU menu, WinDef.HINSTANCE instance, WinDef.LPVOID param) {
/* 40 */     WinDef.HWND hWnd = User32.INSTANCE.CreateWindowEx(exStyle, new WString(className), windowName, style, x, y, width, height, parent, menu, instance, param);
/*    */     
/* 42 */     if (hWnd == null)
/* 43 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError()); 
/* 44 */     return hWnd;
/*    */   }
/*    */   
/*    */   public static final void destroyWindow(WinDef.HWND hWnd) {
/* 48 */     if (!User32.INSTANCE.DestroyWindow(hWnd))
/* 49 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError()); 
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/User32Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */