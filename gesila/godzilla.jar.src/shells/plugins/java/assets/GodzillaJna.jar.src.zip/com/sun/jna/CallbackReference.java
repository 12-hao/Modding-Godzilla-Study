/*     */ package com.sun.jna;
/*     */ 
/*     */ import java.lang.ref.Reference;
/*     */ import java.lang.ref.WeakReference;
/*     */ import java.lang.reflect.InvocationHandler;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Proxy;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CallbackReference
/*     */   extends WeakReference
/*     */ {
/*  38 */   static final Map callbackMap = new WeakHashMap<Object, Object>();
/*  39 */   static final Map directCallbackMap = new WeakHashMap<Object, Object>();
/*  40 */   static final Map pointerCallbackMap = new WeakHashMap<Object, Object>();
/*  41 */   static final Map allocations = new WeakHashMap<Object, Object>();
/*     */   
/*     */   private static final Method PROXY_CALLBACK_METHOD;
/*     */   
/*     */   static {
/*     */     try {
/*  47 */       PROXY_CALLBACK_METHOD = CallbackProxy.class.getMethod("callback", new Class[] { Object[].class });
/*     */     }
/*  49 */     catch (Exception e) {
/*  50 */       throw new Error("Error looking up CallbackProxy.callback() method");
/*     */     } 
/*     */   }
/*     */   Pointer cbstruct; Pointer trampoline;
/*  54 */   private static final Map initializers = new WeakHashMap<Object, Object>(); CallbackProxy proxy; Method method;
/*     */   static void setCallbackThreadInitializer(Callback cb, CallbackThreadInitializer initializer) {
/*  56 */     synchronized (callbackMap) {
/*  57 */       if (initializer != null) {
/*  58 */         initializers.put(cb, initializer);
/*     */       } else {
/*     */         
/*  61 */         initializers.remove(cb);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   static class AttachOptions extends Structure { public boolean daemon;
/*     */     public boolean detach;
/*     */     public String name;
/*     */     
/*     */     AttachOptions() {
/*  71 */       setStringEncoding("utf8");
/*     */     } protected List getFieldOrder() {
/*  73 */       return Arrays.asList(new String[] { "daemon", "detach", "name" });
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   private static ThreadGroup initializeThread(Callback cb, AttachOptions args) {
/*  79 */     CallbackThreadInitializer init = null;
/*  80 */     if (cb instanceof DefaultCallbackProxy) {
/*  81 */       cb = ((DefaultCallbackProxy)cb).getCallback();
/*     */     }
/*  83 */     synchronized (callbackMap) {
/*  84 */       init = (CallbackThreadInitializer)initializers.get(cb);
/*     */     } 
/*  86 */     ThreadGroup group = null;
/*  87 */     if (init != null) {
/*  88 */       group = init.getThreadGroup(cb);
/*  89 */       args.name = init.getName(cb);
/*  90 */       args.daemon = init.isDaemon(cb);
/*  91 */       args.detach = init.detach(cb);
/*  92 */       args.write();
/*     */     } 
/*  94 */     return group;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Callback getCallback(Class type, Pointer p) {
/* 105 */     return getCallback(type, p, false);
/*     */   }
/*     */   
/*     */   private static Callback getCallback(Class<?> type, Pointer p, boolean direct) {
/* 109 */     if (p == null) {
/* 110 */       return null;
/*     */     }
/*     */     
/* 113 */     if (!type.isInterface())
/* 114 */       throw new IllegalArgumentException("Callback type must be an interface"); 
/* 115 */     Map map = direct ? directCallbackMap : callbackMap;
/* 116 */     synchronized (callbackMap) {
/* 117 */       Callback cb = null;
/* 118 */       Reference<Callback> ref = (Reference)pointerCallbackMap.get(p);
/* 119 */       if (ref != null) {
/* 120 */         cb = ref.get();
/* 121 */         if (cb != null && !type.isAssignableFrom(cb.getClass())) {
/* 122 */           throw new IllegalStateException("Pointer " + p + " already mapped to " + cb);
/*     */         }
/* 124 */         return cb;
/*     */       } 
/* 126 */       int ctype = AltCallingConvention.class.isAssignableFrom(type) ? 1 : 0;
/*     */       
/* 128 */       Map<Object, Object> foptions = new HashMap<Object, Object>(Native.getLibraryOptions(type));
/* 129 */       foptions.put("invoking-method", getCallbackMethod(type));
/* 130 */       NativeFunctionHandler h = new NativeFunctionHandler(p, ctype, foptions);
/* 131 */       cb = (Callback)Proxy.newProxyInstance(type.getClassLoader(), new Class[] { type }, h);
/*     */       
/* 133 */       map.put(cb, null);
/* 134 */       pointerCallbackMap.put(p, new WeakReference<Callback>(cb));
/* 135 */       return cb;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private CallbackReference(Callback callback, int callingConvention, boolean direct) {
/* 145 */     super((T)callback);
/* 146 */     TypeMapper mapper = Native.getTypeMapper(callback.getClass());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     boolean ppc = Platform.isPPC();
/* 153 */     if (direct) {
/* 154 */       Method m = getCallbackMethod(callback);
/* 155 */       Class[] ptypes = m.getParameterTypes();
/* 156 */       for (int i = 0; i < ptypes.length; i++) {
/*     */         
/* 158 */         if (ppc && (ptypes[i] == float.class || ptypes[i] == double.class)) {
/*     */           
/* 160 */           direct = false;
/*     */           
/*     */           break;
/*     */         } 
/* 164 */         if (mapper != null && mapper.getFromNativeConverter(ptypes[i]) != null) {
/*     */           
/* 166 */           direct = false;
/*     */           break;
/*     */         } 
/*     */       } 
/* 170 */       if (mapper != null && mapper.getToNativeConverter(m.getReturnType()) != null)
/*     */       {
/* 172 */         direct = false;
/*     */       }
/*     */     } 
/*     */     
/* 176 */     String encoding = Native.getStringEncoding(callback.getClass());
/* 177 */     if (direct) {
/* 178 */       this.method = getCallbackMethod(callback);
/* 179 */       Class[] nativeParamTypes = this.method.getParameterTypes();
/* 180 */       Class<?> returnType = this.method.getReturnType();
/* 181 */       int flags = 1;
/* 182 */       if (callback instanceof com.sun.jna.win32.DLLCallback) {
/* 183 */         flags |= 0x2;
/*     */       }
/* 185 */       long peer = Native.createNativeCallback(callback, this.method, nativeParamTypes, returnType, callingConvention, flags, encoding);
/*     */ 
/*     */ 
/*     */       
/* 189 */       this.cbstruct = (peer != 0L) ? new Pointer(peer) : null;
/*     */     } else {
/*     */       
/* 192 */       if (callback instanceof CallbackProxy) {
/* 193 */         this.proxy = (CallbackProxy)callback;
/*     */       } else {
/*     */         
/* 196 */         this.proxy = new DefaultCallbackProxy(getCallbackMethod(callback), mapper, encoding);
/*     */       } 
/* 198 */       Class[] nativeParamTypes = this.proxy.getParameterTypes();
/* 199 */       Class returnType = this.proxy.getReturnType();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 204 */       if (mapper != null) {
/* 205 */         for (int j = 0; j < nativeParamTypes.length; j++) {
/* 206 */           FromNativeConverter rc = mapper.getFromNativeConverter(nativeParamTypes[j]);
/* 207 */           if (rc != null) {
/* 208 */             nativeParamTypes[j] = rc.nativeType();
/*     */           }
/*     */         } 
/* 211 */         ToNativeConverter tn = mapper.getToNativeConverter(returnType);
/* 212 */         if (tn != null) {
/* 213 */           returnType = tn.nativeType();
/*     */         }
/*     */       } 
/* 216 */       for (int i = 0; i < nativeParamTypes.length; i++) {
/* 217 */         nativeParamTypes[i] = getNativeType(nativeParamTypes[i]);
/* 218 */         if (!isAllowableNativeType(nativeParamTypes[i])) {
/* 219 */           String msg = "Callback argument " + nativeParamTypes[i] + " requires custom type conversion";
/*     */           
/* 221 */           throw new IllegalArgumentException(msg);
/*     */         } 
/*     */       } 
/* 224 */       returnType = getNativeType(returnType);
/* 225 */       if (!isAllowableNativeType(returnType)) {
/* 226 */         String msg = "Callback return type " + returnType + " requires custom type conversion";
/*     */         
/* 228 */         throw new IllegalArgumentException(msg);
/*     */       } 
/* 230 */       int flags = (callback instanceof com.sun.jna.win32.DLLCallback) ? 2 : 0;
/*     */       
/* 232 */       long peer = Native.createNativeCallback(this.proxy, PROXY_CALLBACK_METHOD, nativeParamTypes, returnType, callingConvention, flags, encoding);
/*     */ 
/*     */ 
/*     */       
/* 236 */       this.cbstruct = (peer != 0L) ? new Pointer(peer) : null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Class getNativeType(Class<?> cls) {
/* 241 */     if (Structure.class.isAssignableFrom(cls)) {
/*     */       
/* 243 */       Structure.validate(cls);
/* 244 */       if (!Structure.ByValue.class.isAssignableFrom(cls))
/* 245 */         return Pointer.class; 
/*     */     } else {
/* 247 */       if (NativeMapped.class.isAssignableFrom(cls)) {
/* 248 */         return NativeMappedConverter.getInstance(cls).nativeType();
/*     */       }
/* 250 */       if (cls == String.class || cls == WString.class || cls == String[].class || cls == WString[].class || Callback.class.isAssignableFrom(cls))
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 255 */         return Pointer.class; } 
/*     */     } 
/* 257 */     return cls;
/*     */   }
/*     */   
/*     */   private static Method checkMethod(Method m) {
/* 261 */     if ((m.getParameterTypes()).length > 256) {
/* 262 */       String msg = "Method signature exceeds the maximum parameter count: " + m;
/*     */       
/* 264 */       throw new UnsupportedOperationException(msg);
/*     */     } 
/* 266 */     return m;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static Class findCallbackClass(Class<?> type) {
/* 274 */     if (!Callback.class.isAssignableFrom(type)) {
/* 275 */       throw new IllegalArgumentException(type.getName() + " is not derived from com.sun.jna.Callback");
/*     */     }
/* 277 */     if (type.isInterface()) {
/* 278 */       return type;
/*     */     }
/* 280 */     Class[] ifaces = type.getInterfaces();
/* 281 */     for (int i = 0; i < ifaces.length; i++) {
/* 282 */       if (Callback.class.isAssignableFrom(ifaces[i])) {
/*     */         
/*     */         try {
/* 285 */           getCallbackMethod(ifaces[i]);
/* 286 */           return ifaces[i];
/*     */         }
/* 288 */         catch (IllegalArgumentException e) {
/*     */           break;
/*     */         } 
/*     */       }
/*     */     } 
/* 293 */     if (Callback.class.isAssignableFrom(type.getSuperclass())) {
/* 294 */       return findCallbackClass(type.getSuperclass());
/*     */     }
/* 296 */     return type;
/*     */   }
/*     */   
/*     */   private static Method getCallbackMethod(Callback callback) {
/* 300 */     return getCallbackMethod(findCallbackClass(callback.getClass()));
/*     */   }
/*     */ 
/*     */   
/*     */   private static Method getCallbackMethod(Class cls) {
/* 305 */     Method[] pubMethods = cls.getDeclaredMethods();
/* 306 */     Method[] classMethods = cls.getMethods();
/* 307 */     Set pmethods = new HashSet(Arrays.asList((Object[])pubMethods));
/* 308 */     pmethods.retainAll(Arrays.asList((Object[])classMethods));
/*     */ 
/*     */     
/* 311 */     for (Iterator<Method> i = pmethods.iterator(); i.hasNext(); ) {
/* 312 */       Method m = i.next();
/* 313 */       if (Callback.FORBIDDEN_NAMES.contains(m.getName())) {
/* 314 */         i.remove();
/*     */       }
/*     */     } 
/* 317 */     Method[] methods = (Method[])pmethods.toArray((Object[])new Method[pmethods.size()]);
/* 318 */     if (methods.length == 1) {
/* 319 */       return checkMethod(methods[0]);
/*     */     }
/* 321 */     for (int j = 0; j < methods.length; j++) {
/* 322 */       Method m = methods[j];
/* 323 */       if ("callback".equals(m.getName())) {
/* 324 */         return checkMethod(m);
/*     */       }
/*     */     } 
/* 327 */     String msg = "Callback must implement a single public method, or one public method named 'callback'";
/*     */     
/* 329 */     throw new IllegalArgumentException(msg);
/*     */   }
/*     */ 
/*     */   
/*     */   private void setCallbackOptions(int options) {
/* 334 */     this.cbstruct.setInt(Pointer.SIZE, options);
/*     */   }
/*     */ 
/*     */   
/*     */   public Pointer getTrampoline() {
/* 339 */     if (this.trampoline == null) {
/* 340 */       this.trampoline = this.cbstruct.getPointer(0L);
/*     */     }
/* 342 */     return this.trampoline;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void finalize() {
/* 347 */     dispose();
/*     */   }
/*     */ 
/*     */   
/*     */   protected synchronized void dispose() {
/* 352 */     if (this.cbstruct != null) {
/* 353 */       Native.freeNativeCallback(this.cbstruct.peer);
/* 354 */       this.cbstruct.peer = 0L;
/* 355 */       this.cbstruct = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private Callback getCallback() {
/* 360 */     return (Callback)get();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Pointer getNativeFunctionPointer(Callback cb) {
/* 367 */     if (Proxy.isProxyClass(cb.getClass())) {
/* 368 */       Object handler = Proxy.getInvocationHandler(cb);
/* 369 */       if (handler instanceof NativeFunctionHandler) {
/* 370 */         return ((NativeFunctionHandler)handler).getPointer();
/*     */       }
/*     */     } 
/* 373 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Pointer getFunctionPointer(Callback cb) {
/* 380 */     return getFunctionPointer(cb, false);
/*     */   }
/*     */ 
/*     */   
/*     */   private static Pointer getFunctionPointer(Callback cb, boolean direct) {
/* 385 */     Pointer fp = null;
/* 386 */     if (cb == null) {
/* 387 */       return null;
/*     */     }
/* 389 */     if ((fp = getNativeFunctionPointer(cb)) != null) {
/* 390 */       return fp;
/*     */     }
/* 392 */     int callingConvention = (cb instanceof AltCallingConvention) ? 1 : 0;
/*     */     
/* 394 */     Map<Callback, CallbackReference> map = direct ? directCallbackMap : callbackMap;
/* 395 */     synchronized (callbackMap) {
/* 396 */       CallbackReference cbref = (CallbackReference)map.get(cb);
/* 397 */       if (cbref == null) {
/* 398 */         cbref = new CallbackReference(cb, callingConvention, direct);
/* 399 */         map.put(cb, cbref);
/* 400 */         pointerCallbackMap.put(cbref.getTrampoline(), new WeakReference<Callback>(cb));
/* 401 */         if (initializers.containsKey(cb)) {
/* 402 */           cbref.setCallbackOptions(1);
/*     */         }
/*     */       } 
/* 405 */       return cbref.getTrampoline();
/*     */     } 
/*     */   }
/*     */   
/*     */   private class DefaultCallbackProxy implements CallbackProxy { private final Method callbackMethod;
/*     */     private ToNativeConverter toNative;
/*     */     private final FromNativeConverter[] fromNative;
/*     */     private final String encoding;
/*     */     
/*     */     public DefaultCallbackProxy(Method callbackMethod, TypeMapper mapper, String encoding) {
/* 415 */       this.callbackMethod = callbackMethod;
/* 416 */       this.encoding = encoding;
/* 417 */       Class[] argTypes = callbackMethod.getParameterTypes();
/* 418 */       Class<?> returnType = callbackMethod.getReturnType();
/* 419 */       this.fromNative = new FromNativeConverter[argTypes.length];
/* 420 */       if (NativeMapped.class.isAssignableFrom(returnType)) {
/* 421 */         this.toNative = NativeMappedConverter.getInstance(returnType);
/*     */       }
/* 423 */       else if (mapper != null) {
/* 424 */         this.toNative = mapper.getToNativeConverter(returnType);
/*     */       } 
/* 426 */       for (int i = 0; i < this.fromNative.length; i++) {
/* 427 */         if (NativeMapped.class.isAssignableFrom(argTypes[i])) {
/* 428 */           this.fromNative[i] = new NativeMappedConverter(argTypes[i]);
/*     */         }
/* 430 */         else if (mapper != null) {
/* 431 */           this.fromNative[i] = mapper.getFromNativeConverter(argTypes[i]);
/*     */         } 
/*     */       } 
/* 434 */       if (!callbackMethod.isAccessible()) {
/*     */         try {
/* 436 */           callbackMethod.setAccessible(true);
/*     */         }
/* 438 */         catch (SecurityException e) {
/* 439 */           throw new IllegalArgumentException("Callback method is inaccessible, make sure the interface is public: " + callbackMethod);
/*     */         } 
/*     */       }
/*     */     }
/*     */     
/*     */     public Callback getCallback() {
/* 445 */       return CallbackReference.this.getCallback();
/*     */     }
/*     */     
/*     */     private Object invokeCallback(Object[] args) {
/* 449 */       Class[] paramTypes = this.callbackMethod.getParameterTypes();
/* 450 */       Object[] callbackArgs = new Object[args.length];
/*     */ 
/*     */       
/* 453 */       for (int i = 0; i < args.length; i++) {
/* 454 */         Class type = paramTypes[i];
/* 455 */         Object arg = args[i];
/* 456 */         if (this.fromNative[i] != null) {
/* 457 */           FromNativeContext context = new CallbackParameterContext(type, this.callbackMethod, args, i);
/*     */           
/* 459 */           callbackArgs[i] = this.fromNative[i].fromNative(arg, context);
/*     */         } else {
/*     */           
/* 462 */           callbackArgs[i] = convertArgument(arg, type);
/*     */         } 
/*     */       } 
/*     */       
/* 466 */       Object result = null;
/* 467 */       Callback cb = getCallback();
/* 468 */       if (cb != null) {
/*     */         try {
/* 470 */           result = convertResult(this.callbackMethod.invoke(cb, callbackArgs));
/*     */         }
/* 472 */         catch (IllegalArgumentException e) {
/* 473 */           Native.getCallbackExceptionHandler().uncaughtException(cb, e);
/*     */         }
/* 475 */         catch (IllegalAccessException e) {
/* 476 */           Native.getCallbackExceptionHandler().uncaughtException(cb, e);
/*     */         }
/* 478 */         catch (InvocationTargetException e) {
/* 479 */           Native.getCallbackExceptionHandler().uncaughtException(cb, e.getTargetException());
/*     */         } 
/*     */       }
/*     */       
/* 483 */       for (int j = 0; j < callbackArgs.length; j++) {
/* 484 */         if (callbackArgs[j] instanceof Structure && !(callbackArgs[j] instanceof Structure.ByValue))
/*     */         {
/* 486 */           ((Structure)callbackArgs[j]).autoWrite();
/*     */         }
/*     */       } 
/*     */       
/* 490 */       return result;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public Object callback(Object[] args) {
/*     */       try {
/* 500 */         return invokeCallback(args);
/*     */       }
/* 502 */       catch (Throwable t) {
/* 503 */         Native.getCallbackExceptionHandler().uncaughtException(getCallback(), t);
/* 504 */         return null;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     private Object convertArgument(Object value, Class<String> dstType) {
/* 512 */       if (value instanceof Pointer) {
/* 513 */         if (dstType == String.class) {
/* 514 */           value = ((Pointer)value).getString(0L, this.encoding);
/*     */         }
/* 516 */         else if (dstType == WString.class) {
/* 517 */           value = new WString(((Pointer)value).getWideString(0L));
/*     */         }
/* 519 */         else if (dstType == String[].class) {
/* 520 */           value = ((Pointer)value).getStringArray(0L, this.encoding);
/*     */         }
/* 522 */         else if (dstType == WString[].class) {
/* 523 */           value = ((Pointer)value).getWideStringArray(0L);
/*     */         }
/* 525 */         else if (Callback.class.isAssignableFrom(dstType)) {
/* 526 */           value = CallbackReference.getCallback(dstType, (Pointer)value);
/*     */         }
/* 528 */         else if (Structure.class.isAssignableFrom(dstType)) {
/*     */ 
/*     */           
/* 531 */           if (Structure.ByValue.class.isAssignableFrom(dstType)) {
/* 532 */             Structure s = Structure.newInstance(dstType);
/* 533 */             byte[] buf = new byte[s.size()];
/* 534 */             ((Pointer)value).read(0L, buf, 0, buf.length);
/* 535 */             s.getPointer().write(0L, buf, 0, buf.length);
/* 536 */             s.read();
/* 537 */             value = s;
/*     */           } else {
/*     */             
/* 540 */             Structure s = Structure.newInstance(dstType, (Pointer)value);
/* 541 */             s.conditionalAutoRead();
/* 542 */             value = s;
/*     */           }
/*     */         
/*     */         } 
/* 546 */       } else if ((boolean.class == dstType || Boolean.class == dstType) && value instanceof Number) {
/*     */         
/* 548 */         value = Function.valueOf((((Number)value).intValue() != 0));
/*     */       } 
/* 550 */       return value;
/*     */     }
/*     */     
/*     */     private Object convertResult(Object value) {
/* 554 */       if (this.toNative != null) {
/* 555 */         value = this.toNative.toNative(value, new CallbackResultContext(this.callbackMethod));
/*     */       }
/* 557 */       if (value == null)
/* 558 */         return null; 
/* 559 */       Class<?> cls = value.getClass();
/* 560 */       if (Structure.class.isAssignableFrom(cls)) {
/* 561 */         if (Structure.ByValue.class.isAssignableFrom(cls)) {
/* 562 */           return value;
/*     */         }
/* 564 */         return ((Structure)value).getPointer();
/*     */       } 
/* 566 */       if (cls == boolean.class || cls == Boolean.class) {
/* 567 */         return Boolean.TRUE.equals(value) ? Function.INTEGER_TRUE : Function.INTEGER_FALSE;
/*     */       }
/*     */       
/* 570 */       if (cls == String.class || cls == WString.class) {
/* 571 */         return CallbackReference.getNativeString(value, (cls == WString.class));
/*     */       }
/* 573 */       if (cls == String[].class || cls == WString.class) {
/* 574 */         StringArray sa = (cls == String[].class) ? new StringArray((String[])value, this.encoding) : new StringArray((WString[])value);
/*     */ 
/*     */ 
/*     */         
/* 578 */         CallbackReference.allocations.put(value, sa);
/* 579 */         return sa;
/*     */       } 
/* 581 */       if (Callback.class.isAssignableFrom(cls)) {
/* 582 */         return CallbackReference.getFunctionPointer((Callback)value);
/*     */       }
/* 584 */       return value;
/*     */     }
/*     */     public Class[] getParameterTypes() {
/* 587 */       return this.callbackMethod.getParameterTypes();
/*     */     }
/*     */     public Class getReturnType() {
/* 590 */       return this.callbackMethod.getReturnType();
/*     */     } }
/*     */ 
/*     */ 
/*     */   
/*     */   private static class NativeFunctionHandler
/*     */     implements InvocationHandler
/*     */   {
/*     */     private final Function function;
/*     */     
/*     */     private final Map options;
/*     */     
/*     */     public NativeFunctionHandler(Pointer address, int callingConvention, Map options) {
/* 603 */       String encoding = (String)options.get("string-encoding");
/* 604 */       this.function = new Function(address, callingConvention, encoding);
/* 605 */       this.options = options;
/*     */     }
/*     */ 
/*     */     
/*     */     public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/* 610 */       if (Library.Handler.OBJECT_TOSTRING.equals(method)) {
/* 611 */         String str = "Proxy interface to " + this.function;
/* 612 */         Method m = (Method)this.options.get("invoking-method");
/* 613 */         Class cls = CallbackReference.findCallbackClass(m.getDeclaringClass());
/* 614 */         str = str + " (" + cls.getName() + ")";
/*     */         
/* 616 */         return str;
/*     */       } 
/* 618 */       if (Library.Handler.OBJECT_HASHCODE.equals(method)) {
/* 619 */         return new Integer(hashCode());
/*     */       }
/* 621 */       if (Library.Handler.OBJECT_EQUALS.equals(method)) {
/* 622 */         Object o = args[0];
/* 623 */         if (o != null && Proxy.isProxyClass(o.getClass())) {
/* 624 */           return Function.valueOf((Proxy.getInvocationHandler(o) == this));
/*     */         }
/* 626 */         return Boolean.FALSE;
/*     */       } 
/* 628 */       if (Function.isVarArgs(method)) {
/* 629 */         args = Function.concatenateVarArgs(args);
/*     */       }
/* 631 */       return this.function.invoke(method.getReturnType(), args, this.options);
/*     */     }
/*     */     
/*     */     public Pointer getPointer() {
/* 635 */       return this.function;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean isAllowableNativeType(Class<void> cls) {
/* 643 */     return (cls == void.class || cls == Void.class || cls == boolean.class || cls == Boolean.class || cls == byte.class || cls == Byte.class || cls == short.class || cls == Short.class || cls == char.class || cls == Character.class || cls == int.class || cls == Integer.class || cls == long.class || cls == Long.class || cls == float.class || cls == Float.class || cls == double.class || cls == Double.class || (Structure.ByValue.class.isAssignableFrom(cls) && Structure.class.isAssignableFrom(cls)) || Pointer.class.isAssignableFrom(cls));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Pointer getNativeString(Object value, boolean wide) {
/* 658 */     if (value != null) {
/* 659 */       NativeString ns = new NativeString(value.toString(), wide);
/*     */       
/* 661 */       allocations.put(value, ns);
/* 662 */       return ns.getPointer();
/*     */     } 
/* 664 */     return null;
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/CallbackReference.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */