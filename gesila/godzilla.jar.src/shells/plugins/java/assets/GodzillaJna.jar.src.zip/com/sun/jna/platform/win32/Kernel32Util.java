/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.LastErrorException;
/*     */ import com.sun.jna.Memory;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.Structure;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import com.sun.jna.ptr.PointerByReference;
/*     */ import java.io.File;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Kernel32Util
/*     */   implements WinDef
/*     */ {
/*     */   public static String getComputerName() {
/*  43 */     char[] buffer = new char[WinBase.MAX_COMPUTERNAME_LENGTH + 1];
/*  44 */     IntByReference lpnSize = new IntByReference(buffer.length);
/*  45 */     if (!Kernel32.INSTANCE.GetComputerName(buffer, lpnSize)) {
/*  46 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*  48 */     return Native.toString(buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatMessage(int code) {
/*  60 */     PointerByReference buffer = new PointerByReference();
/*  61 */     if (0 == Kernel32.INSTANCE.FormatMessage(4864, (Pointer)null, code, 0, buffer, 0, (Pointer)null))
/*     */     {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  68 */       throw new LastErrorException(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*  70 */     String s = buffer.getValue().getWideString(0L);
/*  71 */     Kernel32.INSTANCE.LocalFree(buffer.getValue());
/*  72 */     return s.trim();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatMessage(WinNT.HRESULT code) {
/*  83 */     return formatMessage(code.intValue());
/*     */   }
/*     */ 
/*     */   
/*     */   public static String formatMessageFromHR(WinNT.HRESULT code) {
/*  88 */     return formatMessage(code.intValue());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String formatMessageFromLastErrorCode(int code) {
/*  99 */     return formatMessageFromHR(W32Errors.HRESULT_FROM_WIN32(code));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getTempPath() {
/* 108 */     WinDef.DWORD nBufferLength = new WinDef.DWORD(260L);
/* 109 */     char[] buffer = new char[nBufferLength.intValue()];
/* 110 */     if (Kernel32.INSTANCE.GetTempPath(nBufferLength, buffer).intValue() == 0) {
/* 111 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/* 113 */     return Native.toString(buffer);
/*     */   }
/*     */   
/*     */   public static void deleteFile(String filename) {
/* 117 */     if (!Kernel32.INSTANCE.DeleteFile(filename)) {
/* 118 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String[] getLogicalDriveStrings() {
/* 128 */     WinDef.DWORD dwSize = Kernel32.INSTANCE.GetLogicalDriveStrings(new WinDef.DWORD(0L), null);
/*     */     
/* 130 */     if (dwSize.intValue() <= 0) {
/* 131 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */     
/* 134 */     char[] buf = new char[dwSize.intValue()];
/* 135 */     dwSize = Kernel32.INSTANCE.GetLogicalDriveStrings(dwSize, buf);
/* 136 */     if (dwSize.intValue() <= 0) {
/* 137 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */     
/* 140 */     List<String> drives = new ArrayList<String>();
/* 141 */     String drive = "";
/*     */     
/* 143 */     for (int i = 0; i < buf.length - 1; i++) {
/* 144 */       if (buf[i] == '\000') {
/* 145 */         drives.add(drive);
/* 146 */         drive = "";
/*     */       } else {
/* 148 */         drive = drive + buf[i];
/*     */       } 
/*     */     } 
/* 151 */     return drives.<String>toArray(new String[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getFileAttributes(String fileName) {
/* 162 */     int fileAttributes = Kernel32.INSTANCE.GetFileAttributes(fileName);
/* 163 */     if (fileAttributes == -1) {
/* 164 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/* 166 */     return fileAttributes;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getFileType(String fileName) throws FileNotFoundException {
/* 173 */     File f = new File(fileName);
/* 174 */     if (!f.exists()) {
/* 175 */       throw new FileNotFoundException(fileName);
/*     */     }
/*     */     
/* 178 */     WinNT.HANDLE hFile = null; try {
/*     */       int err;
/* 180 */       hFile = Kernel32.INSTANCE.CreateFile(fileName, -2147483648, 1, new WinBase.SECURITY_ATTRIBUTES(), 3, 128, (new WinNT.HANDLEByReference()).getValue());
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 185 */       if (WinBase.INVALID_HANDLE_VALUE.equals(hFile)) {
/* 186 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */       }
/*     */       
/* 189 */       int type = Kernel32.INSTANCE.GetFileType(hFile);
/* 190 */       switch (type) {
/*     */         case 0:
/* 192 */           err = Kernel32.INSTANCE.GetLastError();
/* 193 */           switch (err) {
/*     */             case 0:
/*     */               break;
/*     */           } 
/* 197 */           throw new Win32Exception(err);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 202 */       return type;
/*     */     } finally {
/*     */       
/* 205 */       if (hFile != null && 
/* 206 */         !Kernel32.INSTANCE.CloseHandle(hFile)) {
/* 207 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static int getDriveType(String rootName) {
/* 217 */     return Kernel32.INSTANCE.GetDriveType(rootName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getEnvironmentVariable(String name) {
/* 229 */     int size = Kernel32.INSTANCE.GetEnvironmentVariable(name, null, 0);
/* 230 */     if (size == 0)
/* 231 */       return null; 
/* 232 */     if (size < 0) {
/* 233 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */     
/* 236 */     char[] buffer = new char[size];
/* 237 */     size = Kernel32.INSTANCE.GetEnvironmentVariable(name, buffer, buffer.length);
/*     */     
/* 239 */     if (size <= 0) {
/* 240 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/* 242 */     return Native.toString(buffer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int getPrivateProfileInt(String appName, String keyName, int defaultValue, String fileName) {
/* 267 */     return Kernel32.INSTANCE.GetPrivateProfileInt(appName, keyName, defaultValue, fileName);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String getPrivateProfileString(String lpAppName, String lpKeyName, String lpDefault, String lpFileName) {
/* 322 */     char[] buffer = new char[1024];
/* 323 */     Kernel32.INSTANCE.GetPrivateProfileString(lpAppName, lpKeyName, lpDefault, buffer, new WinDef.DWORD(buffer.length), lpFileName);
/*     */     
/* 325 */     return Native.toString(buffer);
/*     */   }
/*     */ 
/*     */   
/*     */   public static final void writePrivateProfileString(String appName, String keyName, String string, String fileName) {
/* 330 */     if (!Kernel32.INSTANCE.WritePrivateProfileString(appName, keyName, string, fileName))
/*     */     {
/* 332 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION[] getLogicalProcessorInformation() {
/*     */     Memory memory;
/* 342 */     int sizePerStruct = (new WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION()).size();
/*     */     
/* 344 */     WinDef.DWORDByReference bufferSize = new WinDef.DWORDByReference(new WinDef.DWORD(sizePerStruct));
/*     */ 
/*     */     
/*     */     while (true) {
/* 348 */       memory = new Memory(bufferSize.getValue().intValue());
/* 349 */       if (!Kernel32.INSTANCE.GetLogicalProcessorInformation((Pointer)memory, bufferSize)) {
/*     */         
/* 351 */         int err = Kernel32.INSTANCE.GetLastError();
/* 352 */         if (err != 122)
/* 353 */           throw new Win32Exception(err); 
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 358 */     WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION firstInformation = new WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION((Pointer)memory);
/*     */     
/* 360 */     int returnedStructCount = bufferSize.getValue().intValue() / sizePerStruct;
/*     */     
/* 362 */     return (WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION[])firstInformation.toArray((Structure[])new WinNT.SYSTEM_LOGICAL_PROCESSOR_INFORMATION[returnedStructCount]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String[] getPrivateProfileSection(String appName, String fileName) {
/* 384 */     char[] buffer = new char[32768];
/* 385 */     if (Kernel32.INSTANCE.GetPrivateProfileSection(appName, buffer, new WinDef.DWORD(buffer.length), fileName).intValue() == 0) {
/* 386 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/* 388 */     return (new String(buffer)).split("\000");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final String[] getPrivateProfileSectionNames(String fileName) {
/* 403 */     char[] buffer = new char[65536];
/* 404 */     if (Kernel32.INSTANCE.GetPrivateProfileSectionNames(buffer, new WinDef.DWORD(buffer.length), fileName).intValue() == 0) {
/* 405 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */     }
/* 407 */     return (new String(buffer)).split("\000");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final void writePrivateProfileSection(String appName, String[] strings, String fileName) {
/* 420 */     StringBuilder buffer = new StringBuilder();
/* 421 */     for (String string : strings)
/* 422 */       buffer.append(string).append(false); 
/* 423 */     buffer.append(false);
/* 424 */     if (!Kernel32.INSTANCE.WritePrivateProfileSection(appName, buffer.toString(), fileName))
/* 425 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError()); 
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/Kernel32Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */