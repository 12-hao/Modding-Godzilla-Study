/*    */ package com.sun.jna.platform.win32;
/*    */ 
/*    */ import com.sun.jna.Function;
/*    */ import com.sun.jna.Pointer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class OpenGL32Util
/*    */ {
/*    */   public static Function wglGetProcAddress(String procName) {
/* 33 */     Pointer funcPointer = OpenGL32.INSTANCE.wglGetProcAddress("wglEnumGpusNV");
/* 34 */     return (funcPointer == null) ? null : Function.getFunction(funcPointer);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static int countGpusNV() {
/* 44 */     WinDef.HWND hWnd = User32Util.createWindow("Message", null, 0, 0, 0, 0, 0, null, null, null, null);
/* 45 */     WinDef.HDC hdc = User32.INSTANCE.GetDC(hWnd);
/*    */ 
/*    */     
/* 48 */     WinGDI.PIXELFORMATDESCRIPTOR.ByReference pfd = new WinGDI.PIXELFORMATDESCRIPTOR.ByReference();
/* 49 */     pfd.nVersion = 1;
/* 50 */     pfd.dwFlags = 37;
/* 51 */     pfd.iPixelType = 0;
/* 52 */     pfd.cColorBits = 24;
/* 53 */     pfd.cDepthBits = 16;
/* 54 */     pfd.iLayerType = 0;
/* 55 */     GDI32.INSTANCE.SetPixelFormat(hdc, GDI32.INSTANCE.ChoosePixelFormat(hdc, pfd), pfd);
/*    */ 
/*    */     
/* 58 */     WinDef.HGLRC hGLRC = OpenGL32.INSTANCE.wglCreateContext(hdc);
/* 59 */     OpenGL32.INSTANCE.wglMakeCurrent(hdc, hGLRC);
/* 60 */     Pointer funcPointer = OpenGL32.INSTANCE.wglGetProcAddress("wglEnumGpusNV");
/* 61 */     Function fncEnumGpusNV = (funcPointer == null) ? null : Function.getFunction(funcPointer);
/* 62 */     OpenGL32.INSTANCE.wglDeleteContext(hGLRC);
/*    */ 
/*    */     
/* 65 */     User32.INSTANCE.ReleaseDC(hWnd, hdc);
/* 66 */     User32Util.destroyWindow(hWnd);
/*    */ 
/*    */     
/* 69 */     if (fncEnumGpusNV == null) return 0;
/*    */ 
/*    */     
/* 72 */     WinDef.HGLRCByReference hGPU = new WinDef.HGLRCByReference();
/* 73 */     for (int i = 0; i < 16; i++) {
/* 74 */       Boolean ok = (Boolean)fncEnumGpusNV.invoke(Boolean.class, new Object[] { Integer.valueOf(i), hGPU });
/* 75 */       if (!ok.booleanValue()) return i;
/*    */     
/*    */     } 
/* 78 */     return 0;
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/OpenGL32Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */