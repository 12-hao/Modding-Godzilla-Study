/*     */ package com.sun.jna;
/*     */ 
/*     */ import java.nio.CharBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class NativeString
/*     */   implements CharSequence, Comparable
/*     */ {
/*     */   static final String WIDE_STRING = "--WIDE-STRING--";
/*     */   private Pointer pointer;
/*     */   private String encoding;
/*     */   
/*     */   public NativeString(String string) {
/*  34 */     this(string, Native.getDefaultStringEncoding());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeString(String string, boolean wide) {
/*  46 */     this(string, wide ? "--WIDE-STRING--" : Native.getDefaultStringEncoding());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeString(WString string) {
/*  53 */     this(string.toString(), "--WIDE-STRING--");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public NativeString(String string, String encoding) {
/*  60 */     if (string == null) {
/*  61 */       throw new NullPointerException("String must not be null");
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*  66 */     this.encoding = encoding;
/*  67 */     if (this.encoding == "--WIDE-STRING--") {
/*  68 */       int len = (string.length() + 1) * Native.WCHAR_SIZE;
/*  69 */       this.pointer = new Memory(len);
/*  70 */       this.pointer.setWideString(0L, string);
/*     */     } else {
/*     */       
/*  73 */       byte[] data = Native.getBytes(string, encoding);
/*  74 */       this.pointer = new Memory((data.length + 1));
/*  75 */       this.pointer.write(0L, data, 0, data.length);
/*  76 */       this.pointer.setByte(data.length, (byte)0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int hashCode() {
/*  81 */     return toString().hashCode();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object other) {
/*  86 */     if (other instanceof CharSequence) {
/*  87 */       return (compareTo(other) == 0);
/*     */     }
/*  89 */     return false;
/*     */   }
/*     */   
/*     */   public String toString() {
/*  93 */     boolean wide = (this.encoding == "--WIDE-STRING--");
/*  94 */     String s = wide ? "const wchar_t*" : "const char*";
/*  95 */     s = s + "(" + (wide ? this.pointer.getWideString(0L) : this.pointer.getString(0L, this.encoding)) + ")";
/*  96 */     return s;
/*     */   }
/*     */   
/*     */   public Pointer getPointer() {
/* 100 */     return this.pointer;
/*     */   }
/*     */   
/*     */   public char charAt(int index) {
/* 104 */     return toString().charAt(index);
/*     */   }
/*     */   
/*     */   public int length() {
/* 108 */     return toString().length();
/*     */   }
/*     */   
/*     */   public CharSequence subSequence(int start, int end) {
/* 112 */     return CharBuffer.wrap(toString()).subSequence(start, end);
/*     */   }
/*     */ 
/*     */   
/*     */   public int compareTo(Object other) {
/* 117 */     if (other == null) {
/* 118 */       return 1;
/*     */     }
/* 120 */     return toString().compareTo(other.toString());
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/NativeString.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */