/*      */ package com.sun.jna;
/*      */ 
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Constructor;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.nio.Buffer;
/*      */ import java.util.AbstractCollection;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedHashMap;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import java.util.WeakHashMap;
/*      */ import java.util.zip.Adler32;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Structure
/*      */ {
/*      */   public static final int ALIGN_DEFAULT = 0;
/*      */   public static final int ALIGN_NONE = 1;
/*      */   public static final int ALIGN_GNUC = 2;
/*      */   public static final int ALIGN_MSVC = 3;
/*      */   protected static final int CALCULATE_SIZE = -1;
/*  126 */   static final Map layoutInfo = new WeakHashMap<Object, Object>();
/*  127 */   static final Map fieldOrder = new WeakHashMap<Object, Object>();
/*      */   
/*      */   private Pointer memory;
/*      */   
/*  131 */   private int size = -1;
/*      */   
/*      */   private int alignType;
/*      */   
/*      */   private String encoding;
/*      */   private int actualAlignType;
/*      */   private int structAlignment;
/*      */   private Map structFields;
/*  139 */   private final Map nativeStrings = new HashMap<Object, Object>();
/*      */   
/*      */   private TypeMapper typeMapper;
/*      */   
/*      */   private long typeInfo;
/*      */   
/*      */   private boolean autoRead = true;
/*      */   private boolean autoWrite = true;
/*      */   private Structure[] array;
/*      */   private boolean readCalled;
/*      */   
/*      */   protected Structure() {
/*  151 */     this(0);
/*      */   }
/*      */   
/*      */   protected Structure(TypeMapper mapper) {
/*  155 */     this(null, 0, mapper);
/*      */   }
/*      */   
/*      */   protected Structure(int alignType) {
/*  159 */     this((Pointer)null, alignType);
/*      */   }
/*      */   
/*      */   protected Structure(int alignType, TypeMapper mapper) {
/*  163 */     this(null, alignType, mapper);
/*      */   }
/*      */ 
/*      */   
/*      */   protected Structure(Pointer p) {
/*  168 */     this(p, 0);
/*      */   }
/*      */   
/*      */   protected Structure(Pointer p, int alignType) {
/*  172 */     this(p, alignType, null);
/*      */   }
/*      */   
/*      */   protected Structure(Pointer p, int alignType, TypeMapper mapper) {
/*  176 */     setAlignType(alignType);
/*  177 */     setStringEncoding(Native.getStringEncoding(getClass()));
/*  178 */     initializeTypeMapper(mapper);
/*  179 */     validateFields();
/*  180 */     if (p != null) {
/*  181 */       useMemory(p, 0, true);
/*      */     } else {
/*      */       
/*  184 */       allocateMemory(-1);
/*      */     } 
/*  186 */     initializeFields();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Map fields() {
/*  196 */     return this.structFields;
/*      */   }
/*      */ 
/*      */   
/*      */   TypeMapper getTypeMapper() {
/*  201 */     return this.typeMapper;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeTypeMapper(TypeMapper mapper) {
/*  209 */     if (mapper == null) {
/*  210 */       mapper = Native.getTypeMapper(getClass());
/*      */     }
/*  212 */     this.typeMapper = mapper;
/*  213 */     layoutChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void layoutChanged() {
/*  220 */     if (this.size != -1) {
/*  221 */       this.size = -1;
/*  222 */       if (this.memory instanceof AutoAllocated) {
/*  223 */         this.memory = null;
/*      */       }
/*      */       
/*  226 */       ensureAllocated();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setStringEncoding(String encoding) {
/*  234 */     this.encoding = encoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String getStringEncoding() {
/*  241 */     return this.encoding;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void setAlignType(int alignType) {
/*  249 */     this.alignType = alignType;
/*  250 */     if (alignType == 0) {
/*  251 */       alignType = Native.getStructureAlignment(getClass());
/*  252 */       if (alignType == 0)
/*  253 */         if (Platform.isWindows()) {
/*  254 */           alignType = 3;
/*      */         } else {
/*  256 */           alignType = 2;
/*      */         }  
/*      */     } 
/*  259 */     this.actualAlignType = alignType;
/*  260 */     layoutChanged();
/*      */   }
/*      */   
/*      */   protected Memory autoAllocate(int size) {
/*  264 */     return new AutoAllocated(size);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void useMemory(Pointer m) {
/*  273 */     useMemory(m, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void useMemory(Pointer m, int offset) {
/*  282 */     useMemory(m, offset, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void useMemory(Pointer m, int offset, boolean force) {
/*      */     try {
/*  298 */       this.nativeStrings.clear();
/*      */       
/*  300 */       if (this instanceof ByValue && !force) {
/*      */ 
/*      */         
/*  303 */         byte[] buf = new byte[size()];
/*  304 */         m.read(0L, buf, 0, buf.length);
/*  305 */         this.memory.write(0L, buf, 0, buf.length);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  310 */         this.memory = m.share(offset);
/*  311 */         if (this.size == -1) {
/*  312 */           this.size = calculateSize(false);
/*      */         }
/*  314 */         if (this.size != -1) {
/*  315 */           this.memory = m.share(offset, this.size);
/*      */         }
/*      */       } 
/*  318 */       this.array = null;
/*  319 */       this.readCalled = false;
/*      */     }
/*  321 */     catch (IndexOutOfBoundsException e) {
/*  322 */       throw new IllegalArgumentException("Structure exceeds provided memory bounds");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void ensureAllocated() {
/*  329 */     ensureAllocated(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void ensureAllocated(boolean avoidFFIType) {
/*  338 */     if (this.memory == null) {
/*  339 */       allocateMemory(avoidFFIType);
/*      */     }
/*  341 */     else if (this.size == -1) {
/*  342 */       this.size = calculateSize(true, avoidFFIType);
/*  343 */       if (!(this.memory instanceof AutoAllocated)) {
/*      */         
/*      */         try {
/*  346 */           this.memory = this.memory.share(0L, this.size);
/*      */         }
/*  348 */         catch (IndexOutOfBoundsException e) {
/*  349 */           throw new IllegalArgumentException("Structure exceeds provided memory bounds");
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void allocateMemory() {
/*  359 */     allocateMemory(false);
/*      */   }
/*      */   
/*      */   private void allocateMemory(boolean avoidFFIType) {
/*  363 */     allocateMemory(calculateSize(true, avoidFFIType));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void allocateMemory(int size) {
/*  373 */     if (size == -1) {
/*      */       
/*  375 */       size = calculateSize(false);
/*      */     }
/*  377 */     else if (size <= 0) {
/*  378 */       throw new IllegalArgumentException("Structure size must be greater than zero: " + size);
/*      */     } 
/*      */ 
/*      */     
/*  382 */     if (size != -1) {
/*  383 */       if (this.memory == null || this.memory instanceof AutoAllocated)
/*      */       {
/*  385 */         this.memory = autoAllocate(size);
/*      */       }
/*  387 */       this.size = size;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public int size() {
/*  393 */     ensureAllocated();
/*  394 */     return this.size;
/*      */   }
/*      */ 
/*      */   
/*      */   public void clear() {
/*  399 */     ensureAllocated();
/*  400 */     this.memory.clear(size());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Pointer getPointer() {
/*  411 */     ensureAllocated();
/*  412 */     return this.memory;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  421 */   private static final ThreadLocal reads = new ThreadLocal() {
/*      */       protected synchronized Object initialValue() {
/*  423 */         return new HashMap<Object, Object>();
/*      */       }
/*      */     };
/*      */ 
/*      */ 
/*      */   
/*  429 */   private static final ThreadLocal busy = new ThreadLocal() {
/*      */       class StructureSet
/*      */         extends AbstractCollection
/*      */         implements Set {
/*      */         private Structure[] elements;
/*      */         private int count;
/*      */         
/*      */         private void ensureCapacity(int size) {
/*  437 */           if (this.elements == null) {
/*  438 */             this.elements = new Structure[size * 3 / 2];
/*      */           }
/*  440 */           else if (this.elements.length < size) {
/*  441 */             Structure[] e = new Structure[size * 3 / 2];
/*  442 */             System.arraycopy(this.elements, 0, e, 0, this.elements.length);
/*  443 */             this.elements = e;
/*      */           } 
/*      */         } public int size() {
/*  446 */           return this.count;
/*      */         } public boolean contains(Object o) {
/*  448 */           return (indexOf(o) != -1);
/*      */         }
/*      */         public boolean add(Object o) {
/*  451 */           if (!contains(o)) {
/*  452 */             ensureCapacity(this.count + 1);
/*  453 */             this.elements[this.count++] = (Structure)o;
/*      */           } 
/*  455 */           return true;
/*      */         }
/*      */         private int indexOf(Object o) {
/*  458 */           Structure s1 = (Structure)o;
/*  459 */           for (int i = 0; i < this.count; i++) {
/*  460 */             Structure s2 = this.elements[i];
/*  461 */             if (s1 == s2 || (s1.getClass() == s2.getClass() && s1.size() == s2.size() && s1.getPointer().equals(s2.getPointer())))
/*      */             {
/*      */ 
/*      */               
/*  465 */               return i;
/*      */             }
/*      */           } 
/*  468 */           return -1;
/*      */         }
/*      */         public boolean remove(Object o) {
/*  471 */           int idx = indexOf(o);
/*  472 */           if (idx != -1) {
/*  473 */             if (--this.count > 0) {
/*  474 */               this.elements[idx] = this.elements[this.count];
/*  475 */               this.elements[this.count] = null;
/*      */             } 
/*  477 */             return true;
/*      */           } 
/*  479 */           return false;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*      */         public Iterator iterator() {
/*  485 */           Structure[] e = new Structure[this.count];
/*  486 */           if (this.count > 0) {
/*  487 */             System.arraycopy(this.elements, 0, e, 0, this.count);
/*      */           }
/*  489 */           return Arrays.<Structure>asList(e).iterator();
/*      */         } }
/*      */       
/*      */       protected synchronized Object initialValue() {
/*  493 */         return new StructureSet();
/*      */       }
/*      */     };
/*      */   static Set busy() {
/*  497 */     return busy.get();
/*      */   }
/*      */   static Map reading() {
/*  500 */     return reads.get();
/*      */   }
/*      */ 
/*      */   
/*      */   void conditionalAutoRead() {
/*  505 */     if (!this.readCalled) {
/*  506 */       autoRead();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void read() {
/*  515 */     if (this.memory == PLACEHOLDER_MEMORY) {
/*      */       return;
/*      */     }
/*  518 */     this.readCalled = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  524 */     ensureAllocated();
/*      */ 
/*      */     
/*  527 */     if (busy().contains(this)) {
/*      */       return;
/*      */     }
/*  530 */     busy().add(this);
/*  531 */     if (this instanceof ByReference) {
/*  532 */       reading().put(getPointer(), this);
/*      */     }
/*      */     try {
/*  535 */       for (Iterator<StructField> i = fields().values().iterator(); i.hasNext(); ) {
/*  536 */         StructField structField = i.next();
/*  537 */         readField(structField);
/*      */       } 
/*      */     } finally {
/*      */       
/*  541 */       busy().remove(this);
/*  542 */       if (reading().get(getPointer()) == this) {
/*  543 */         reading().remove(getPointer());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected int fieldOffset(String name) {
/*  550 */     ensureAllocated();
/*  551 */     StructField f = (StructField)fields().get(name);
/*  552 */     if (f == null)
/*  553 */       throw new IllegalArgumentException("No such field: " + name); 
/*  554 */     return f.offset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object readField(String name) {
/*  563 */     ensureAllocated();
/*  564 */     StructField f = (StructField)fields().get(name);
/*  565 */     if (f == null)
/*  566 */       throw new IllegalArgumentException("No such field: " + name); 
/*  567 */     return readField(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getFieldValue(Field field) {
/*      */     try {
/*  575 */       return field.get(this);
/*      */     }
/*  577 */     catch (Exception e) {
/*  578 */       throw new Error("Exception reading field '" + field.getName() + "' in " + getClass() + ": " + e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void setFieldValue(Field field, Object value) {
/*  585 */     setFieldValue(field, value, false);
/*      */   }
/*      */ 
/*      */   
/*      */   private void setFieldValue(Field field, Object value, boolean overrideFinal) {
/*      */     try {
/*  591 */       field.set(this, value);
/*      */     }
/*  593 */     catch (IllegalAccessException e) {
/*  594 */       int modifiers = field.getModifiers();
/*  595 */       if (Modifier.isFinal(modifiers)) {
/*  596 */         if (overrideFinal)
/*      */         {
/*      */           
/*  599 */           throw new UnsupportedOperationException("This VM does not support Structures with final fields (field '" + field.getName() + "' within " + getClass() + ")");
/*      */         }
/*  601 */         throw new UnsupportedOperationException("Attempt to write to read-only field '" + field.getName() + "' within " + getClass());
/*      */       } 
/*  603 */       throw new Error("Unexpectedly unable to write to field '" + field.getName() + "' within " + getClass() + ": " + e);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Structure updateStructureByReference(Class type, Structure s, Pointer address) {
/*  617 */     if (address == null) {
/*  618 */       s = null;
/*      */     
/*      */     }
/*  621 */     else if (s == null || !address.equals(s.getPointer())) {
/*  622 */       Structure s1 = (Structure)reading().get(address);
/*  623 */       if (s1 != null && type.equals(s1.getClass())) {
/*  624 */         s = s1;
/*  625 */         s.autoRead();
/*      */       } else {
/*      */         
/*  628 */         s = newInstance(type, address);
/*  629 */         s.conditionalAutoRead();
/*      */       } 
/*      */     } else {
/*      */       
/*  633 */       s.autoRead();
/*      */     } 
/*      */     
/*  636 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Object readField(StructField structField) {
/*      */     Object result;
/*  646 */     int offset = structField.offset;
/*      */ 
/*      */     
/*  649 */     Class<?> fieldType = structField.type;
/*  650 */     FromNativeConverter readConverter = structField.readConverter;
/*  651 */     if (readConverter != null) {
/*  652 */       fieldType = readConverter.nativeType();
/*      */     }
/*      */     
/*  655 */     Object currentValue = (Structure.class.isAssignableFrom(fieldType) || Callback.class.isAssignableFrom(fieldType) || (Platform.HAS_BUFFERS && Buffer.class.isAssignableFrom(fieldType)) || Pointer.class.isAssignableFrom(fieldType) || NativeMapped.class.isAssignableFrom(fieldType) || fieldType.isArray()) ? getFieldValue(structField.field) : null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  664 */     if (fieldType == String.class) {
/*  665 */       Pointer p = this.memory.getPointer(offset);
/*  666 */       result = (p == null) ? null : p.getString(0L, this.encoding);
/*      */     } else {
/*      */       
/*  669 */       result = this.memory.getValue(offset, fieldType, currentValue);
/*      */     } 
/*  671 */     if (readConverter != null) {
/*  672 */       result = readConverter.fromNative(result, structField.context);
/*  673 */       if (currentValue != null && currentValue.equals(result)) {
/*  674 */         result = currentValue;
/*      */       }
/*      */     } 
/*      */     
/*  678 */     if (fieldType.equals(String.class) || fieldType.equals(WString.class)) {
/*      */       
/*  680 */       this.nativeStrings.put(structField.name + ".ptr", this.memory.getPointer(offset));
/*  681 */       this.nativeStrings.put(structField.name + ".val", result);
/*      */     } 
/*      */ 
/*      */     
/*  685 */     setFieldValue(structField.field, result, true);
/*  686 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void write() {
/*  694 */     if (this.memory == PLACEHOLDER_MEMORY) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  701 */     ensureAllocated();
/*      */ 
/*      */     
/*  704 */     if (this instanceof ByValue) {
/*  705 */       getTypeInfo();
/*      */     }
/*      */ 
/*      */     
/*  709 */     if (busy().contains(this)) {
/*      */       return;
/*      */     }
/*  712 */     busy().add(this);
/*      */     
/*      */     try {
/*  715 */       for (Iterator<StructField> i = fields().values().iterator(); i.hasNext(); ) {
/*  716 */         StructField sf = i.next();
/*  717 */         if (!sf.isVolatile) {
/*  718 */           writeField(sf);
/*      */         }
/*      */       } 
/*      */     } finally {
/*      */       
/*  723 */       busy().remove(this);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeField(String name) {
/*  732 */     ensureAllocated();
/*  733 */     StructField f = (StructField)fields().get(name);
/*  734 */     if (f == null)
/*  735 */       throw new IllegalArgumentException("No such field: " + name); 
/*  736 */     writeField(f);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void writeField(String name, Object value) {
/*  745 */     ensureAllocated();
/*  746 */     StructField structField = (StructField)fields().get(name);
/*  747 */     if (structField == null)
/*  748 */       throw new IllegalArgumentException("No such field: " + name); 
/*  749 */     setFieldValue(structField.field, value);
/*  750 */     writeField(structField);
/*      */   }
/*      */ 
/*      */   
/*      */   protected void writeField(StructField structField) {
/*  755 */     if (structField.isReadOnly) {
/*      */       return;
/*      */     }
/*      */     
/*  759 */     int offset = structField.offset;
/*      */ 
/*      */     
/*  762 */     Object value = getFieldValue(structField.field);
/*      */ 
/*      */     
/*  765 */     Class<String> fieldType = structField.type;
/*  766 */     ToNativeConverter converter = structField.writeConverter;
/*  767 */     if (converter != null) {
/*  768 */       value = converter.toNative(value, new StructureWriteContext(this, structField.field));
/*  769 */       fieldType = converter.nativeType();
/*      */     } 
/*      */ 
/*      */     
/*  773 */     if (String.class == fieldType || WString.class == fieldType) {
/*      */ 
/*      */       
/*  776 */       boolean wide = (fieldType == WString.class);
/*  777 */       if (value != null) {
/*      */ 
/*      */         
/*  780 */         if (this.nativeStrings.containsKey(structField.name + ".ptr") && value.equals(this.nativeStrings.get(structField.name + ".val"))) {
/*      */           return;
/*      */         }
/*      */         
/*  784 */         NativeString nativeString = wide ? new NativeString(value.toString(), true) : new NativeString(value.toString(), this.encoding);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  789 */         this.nativeStrings.put(structField.name, nativeString);
/*  790 */         value = nativeString.getPointer();
/*      */       } else {
/*      */         
/*  793 */         this.nativeStrings.remove(structField.name);
/*      */       } 
/*  795 */       this.nativeStrings.remove(structField.name + ".ptr");
/*  796 */       this.nativeStrings.remove(structField.name + ".val");
/*      */     } 
/*      */     
/*      */     try {
/*  800 */       this.memory.setValue(offset, value, fieldType);
/*      */     }
/*  802 */     catch (IllegalArgumentException e) {
/*  803 */       String msg = "Structure field \"" + structField.name + "\" was declared as " + structField.type + ((structField.type == fieldType) ? "" : (" (native type " + fieldType + ")")) + ", which is not supported within a Structure";
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  808 */       throw new IllegalArgumentException(msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected final void setFieldOrder(String[] fields) {
/*  842 */     throw new Error("This method is obsolete, use getFieldOrder() instead");
/*      */   }
/*      */ 
/*      */   
/*      */   protected void sortFields(List<Field> fields, List<String> names) {
/*  847 */     for (int i = 0; i < names.size(); i++) {
/*  848 */       String name = names.get(i);
/*  849 */       for (int f = 0; f < fields.size(); f++) {
/*  850 */         Field field = fields.get(f);
/*  851 */         if (name.equals(field.getName())) {
/*  852 */           Collections.swap(fields, i, f);
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   protected List getFieldList() {
/*  861 */     List<Field> flist = new ArrayList();
/*  862 */     Class<?> cls = getClass();
/*  863 */     for (; !cls.equals(Structure.class); 
/*  864 */       cls = cls.getSuperclass()) {
/*  865 */       List<Field> classFields = new ArrayList();
/*  866 */       Field[] fields = cls.getDeclaredFields();
/*  867 */       for (int i = 0; i < fields.length; i++) {
/*  868 */         int modifiers = fields[i].getModifiers();
/*  869 */         if (!Modifier.isStatic(modifiers) && Modifier.isPublic(modifiers))
/*      */         {
/*      */           
/*  872 */           classFields.add(fields[i]); } 
/*      */       } 
/*  874 */       flist.addAll(0, classFields);
/*      */     } 
/*  876 */     return flist;
/*      */   }
/*      */ 
/*      */   
/*      */   private List fieldOrder() {
/*  881 */     synchronized (fieldOrder) {
/*  882 */       List list = (List)fieldOrder.get(getClass());
/*  883 */       if (list == null) {
/*  884 */         list = getFieldOrder();
/*  885 */         fieldOrder.put(getClass(), list);
/*      */       } 
/*  887 */       return list;
/*      */     } 
/*      */   }
/*      */   
/*      */   private List sort(Collection<?> c) {
/*  892 */     List<Comparable> list = new ArrayList(c);
/*  893 */     Collections.sort(list);
/*  894 */     return list;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List getFields(boolean force) {
/*  905 */     List flist = getFieldList();
/*  906 */     Set<String> names = new HashSet();
/*  907 */     for (Iterator<Field> i = flist.iterator(); i.hasNext();) {
/*  908 */       names.add(((Field)i.next()).getName());
/*      */     }
/*  910 */     List<?> fieldOrder = fieldOrder();
/*  911 */     if (fieldOrder.size() != flist.size() && flist.size() > 1) {
/*  912 */       if (force) {
/*  913 */         throw new Error("Structure.getFieldOrder() on " + getClass() + " does not provide enough names (" + sort(fieldOrder) + ") to match declared fields (" + sort(names) + ")");
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  920 */       return null;
/*      */     } 
/*      */     
/*  923 */     Set orderedNames = new HashSet(fieldOrder);
/*  924 */     if (!orderedNames.equals(names)) {
/*  925 */       throw new Error("Structure.getFieldOrder() on " + getClass() + " returns names (" + sort(fieldOrder) + ") which do not match declared field names (" + sort(names) + ")");
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  932 */     sortFields(flist, fieldOrder);
/*      */     
/*  934 */     return flist;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int calculateSize(boolean force) {
/*  949 */     return calculateSize(force, false);
/*      */   }
/*      */ 
/*      */   
/*      */   static int size(Class type) {
/*  954 */     return size(type, null);
/*      */   }
/*      */ 
/*      */   
/*      */   static int size(Class type, Structure value) {
/*      */     LayoutInfo info;
/*  960 */     synchronized (layoutInfo) {
/*  961 */       info = (LayoutInfo)layoutInfo.get(type);
/*      */     } 
/*  963 */     int sz = (info != null && !info.variable) ? info.size : -1;
/*  964 */     if (sz == -1) {
/*  965 */       if (value == null) {
/*  966 */         value = newInstance(type, PLACEHOLDER_MEMORY);
/*      */       }
/*  968 */       sz = value.size();
/*      */     } 
/*  970 */     return sz;
/*      */   }
/*      */   int calculateSize(boolean force, boolean avoidFFIType) {
/*      */     LayoutInfo info;
/*  974 */     int size = -1;
/*      */     
/*  976 */     synchronized (layoutInfo) {
/*  977 */       info = (LayoutInfo)layoutInfo.get(getClass());
/*      */     } 
/*  979 */     if (info == null || this.alignType != info.alignType || this.typeMapper != info.typeMapper)
/*      */     {
/*      */       
/*  982 */       info = deriveLayout(force, avoidFFIType);
/*      */     }
/*  984 */     if (info != null) {
/*  985 */       this.structAlignment = info.alignment;
/*  986 */       this.structFields = info.fields;
/*      */       
/*  988 */       if (!info.variable) {
/*  989 */         synchronized (layoutInfo) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  995 */           if (!layoutInfo.containsKey(getClass()) || this.alignType != 0 || this.typeMapper != null)
/*      */           {
/*      */             
/*  998 */             layoutInfo.put(getClass(), info);
/*      */           }
/*      */         } 
/*      */       }
/* 1002 */       size = info.size;
/*      */     } 
/* 1004 */     return size;
/*      */   }
/*      */   
/*      */   private static class LayoutInfo
/*      */   {
/*      */     private LayoutInfo() {}
/*      */     
/* 1011 */     private int size = -1;
/* 1012 */     private int alignment = 1;
/* 1013 */     private final Map fields = Collections.synchronizedMap(new LinkedHashMap<Object, Object>());
/* 1014 */     private int alignType = 0;
/*      */     
/*      */     private TypeMapper typeMapper;
/*      */     private boolean variable;
/*      */     private Structure.StructField typeInfoField;
/*      */   }
/*      */   
/*      */   private void validateField(String name, Class type) {
/* 1022 */     if (this.typeMapper != null) {
/* 1023 */       ToNativeConverter toNative = this.typeMapper.getToNativeConverter(type);
/* 1024 */       if (toNative != null) {
/* 1025 */         validateField(name, toNative.nativeType());
/*      */         return;
/*      */       } 
/*      */     } 
/* 1029 */     if (type.isArray()) {
/* 1030 */       validateField(name, type.getComponentType());
/*      */     } else {
/*      */       
/*      */       try {
/* 1034 */         getNativeSize(type);
/*      */       }
/* 1036 */       catch (IllegalArgumentException e) {
/* 1037 */         String msg = "Invalid Structure field in " + getClass() + ", field name '" + name + "' (" + type + "): " + e.getMessage();
/* 1038 */         throw new IllegalArgumentException(msg);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void validateFields() {
/* 1045 */     List fields = getFieldList();
/* 1046 */     for (Iterator<Field> i = fields.iterator(); i.hasNext(); ) {
/* 1047 */       Field f = i.next();
/* 1048 */       validateField(f.getName(), f.getType());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private LayoutInfo deriveLayout(boolean force, boolean avoidFFIType) {
/* 1057 */     int calculatedSize = 0;
/* 1058 */     List fields = getFields(force);
/* 1059 */     if (fields == null) {
/* 1060 */       return null;
/*      */     }
/*      */     
/* 1063 */     LayoutInfo info = new LayoutInfo();
/* 1064 */     info.alignType = this.alignType;
/* 1065 */     info.typeMapper = this.typeMapper;
/*      */     
/* 1067 */     boolean firstField = true;
/* 1068 */     for (Iterator<Field> i = fields.iterator(); i.hasNext(); firstField = false) {
/* 1069 */       Field field = i.next();
/* 1070 */       int modifiers = field.getModifiers();
/*      */       
/* 1072 */       Class<?> type = field.getType();
/* 1073 */       if (type.isArray()) {
/* 1074 */         info.variable = true;
/*      */       }
/* 1076 */       StructField structField = new StructField();
/* 1077 */       structField.isVolatile = Modifier.isVolatile(modifiers);
/* 1078 */       structField.isReadOnly = Modifier.isFinal(modifiers);
/* 1079 */       if (structField.isReadOnly) {
/* 1080 */         if (!Platform.RO_FIELDS) {
/* 1081 */           throw new IllegalArgumentException("This VM does not support read-only fields (field '" + field.getName() + "' within " + getClass() + ")");
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 1086 */         field.setAccessible(true);
/*      */       } 
/* 1088 */       structField.field = field;
/* 1089 */       structField.name = field.getName();
/* 1090 */       structField.type = type;
/*      */ 
/*      */       
/* 1093 */       if (Callback.class.isAssignableFrom(type) && !type.isInterface()) {
/* 1094 */         throw new IllegalArgumentException("Structure Callback field '" + field.getName() + "' must be an interface");
/*      */       }
/*      */ 
/*      */       
/* 1098 */       if (type.isArray() && Structure.class.equals(type.getComponentType())) {
/*      */         
/* 1100 */         String msg = "Nested Structure arrays must use a derived Structure type so that the size of the elements can be determined";
/*      */ 
/*      */         
/* 1103 */         throw new IllegalArgumentException(msg);
/*      */       } 
/*      */       
/* 1106 */       int fieldAlignment = 1;
/* 1107 */       if (Modifier.isPublic(field.getModifiers())) {
/*      */ 
/*      */ 
/*      */         
/* 1111 */         Object value = getFieldValue(structField.field);
/* 1112 */         if (value == null && type.isArray()) {
/* 1113 */           if (force) {
/* 1114 */             throw new IllegalStateException("Array fields must be initialized");
/*      */           }
/*      */           
/* 1117 */           return null;
/*      */         } 
/* 1119 */         Class<?> nativeType = type;
/* 1120 */         if (NativeMapped.class.isAssignableFrom(type)) {
/* 1121 */           NativeMappedConverter tc = NativeMappedConverter.getInstance(type);
/* 1122 */           nativeType = tc.nativeType();
/* 1123 */           structField.writeConverter = tc;
/* 1124 */           structField.readConverter = tc;
/* 1125 */           structField.context = new StructureReadContext(this, field);
/*      */         }
/* 1127 */         else if (this.typeMapper != null) {
/* 1128 */           ToNativeConverter writeConverter = this.typeMapper.getToNativeConverter(type);
/* 1129 */           FromNativeConverter readConverter = this.typeMapper.getFromNativeConverter(type);
/* 1130 */           if (writeConverter != null && readConverter != null) {
/* 1131 */             value = writeConverter.toNative(value, new StructureWriteContext(this, structField.field));
/*      */             
/* 1133 */             nativeType = (value != null) ? value.getClass() : Pointer.class;
/* 1134 */             structField.writeConverter = writeConverter;
/* 1135 */             structField.readConverter = readConverter;
/* 1136 */             structField.context = new StructureReadContext(this, field);
/*      */           }
/* 1138 */           else if (writeConverter != null || readConverter != null) {
/* 1139 */             String msg = "Structures require bidirectional type conversion for " + type;
/* 1140 */             throw new IllegalArgumentException(msg);
/*      */           } 
/*      */         } 
/*      */         
/* 1144 */         if (value == null) {
/* 1145 */           value = initializeField(structField.field, type);
/*      */         }
/*      */         
/*      */         try {
/* 1149 */           structField.size = getNativeSize(nativeType, value);
/* 1150 */           fieldAlignment = getNativeAlignment(nativeType, value, firstField);
/*      */         }
/* 1152 */         catch (IllegalArgumentException e) {
/*      */           
/* 1154 */           if (!force && this.typeMapper == null) {
/* 1155 */             return null;
/*      */           }
/* 1157 */           String msg = "Invalid Structure field in " + getClass() + ", field name '" + structField.name + "' (" + structField.type + "): " + e.getMessage();
/* 1158 */           throw new IllegalArgumentException(msg);
/*      */         } 
/*      */ 
/*      */         
/* 1162 */         if (fieldAlignment == 0) {
/* 1163 */           throw new Error("Field alignment is zero for field '" + structField.name + "' within " + getClass());
/*      */         }
/* 1165 */         info.alignment = Math.max(info.alignment, fieldAlignment);
/* 1166 */         if (calculatedSize % fieldAlignment != 0) {
/* 1167 */           calculatedSize += fieldAlignment - calculatedSize % fieldAlignment;
/*      */         }
/* 1169 */         if (this instanceof Union) {
/* 1170 */           structField.offset = 0;
/* 1171 */           calculatedSize = Math.max(calculatedSize, structField.size);
/*      */         } else {
/*      */           
/* 1174 */           structField.offset = calculatedSize;
/* 1175 */           calculatedSize += structField.size;
/*      */         } 
/*      */ 
/*      */         
/* 1179 */         info.fields.put(structField.name, structField);
/*      */         
/* 1181 */         if (info.typeInfoField == null || info.typeInfoField.size < structField.size || (info.typeInfoField.size == structField.size && Structure.class.isAssignableFrom(structField.type)))
/*      */         {
/*      */ 
/*      */           
/* 1185 */           info.typeInfoField = structField;
/*      */         }
/*      */       } 
/*      */     } 
/* 1189 */     if (calculatedSize > 0) {
/* 1190 */       int size = addPadding(calculatedSize, info.alignment);
/*      */       
/* 1192 */       if (this instanceof ByValue && !avoidFFIType) {
/* 1193 */         getTypeInfo();
/*      */       }
/* 1195 */       info.size = size;
/* 1196 */       return info;
/*      */     } 
/*      */     
/* 1199 */     throw new IllegalArgumentException("Structure " + getClass() + " has unknown or zero size (ensure " + "all fields are public)");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initializeFields() {
/* 1210 */     List flist = getFieldList();
/* 1211 */     for (Iterator<Field> i = flist.iterator(); i.hasNext(); ) {
/* 1212 */       Field f = i.next();
/*      */       try {
/* 1214 */         Object o = f.get(this);
/* 1215 */         if (o == null) {
/* 1216 */           initializeField(f, f.getType());
/*      */         }
/*      */       }
/* 1219 */       catch (Exception e) {
/* 1220 */         throw new Error("Exception reading field '" + f.getName() + "' in " + getClass() + ": " + e);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private Object initializeField(Field field, Class<?> type) {
/* 1228 */     Object value = null;
/* 1229 */     if (Structure.class.isAssignableFrom(type) && !ByReference.class.isAssignableFrom(type)) {
/*      */       
/*      */       try {
/* 1232 */         value = newInstance(type, PLACEHOLDER_MEMORY);
/* 1233 */         setFieldValue(field, value);
/*      */       }
/* 1235 */       catch (IllegalArgumentException e) {
/* 1236 */         String msg = "Can't determine size of nested structure: " + e.getMessage();
/*      */         
/* 1238 */         throw new IllegalArgumentException(msg);
/*      */       }
/*      */     
/* 1241 */     } else if (NativeMapped.class.isAssignableFrom(type)) {
/* 1242 */       NativeMappedConverter tc = NativeMappedConverter.getInstance(type);
/* 1243 */       value = tc.defaultValue();
/* 1244 */       setFieldValue(field, value);
/*      */     } 
/* 1246 */     return value;
/*      */   }
/*      */   
/*      */   private int addPadding(int calculatedSize) {
/* 1250 */     return addPadding(calculatedSize, this.structAlignment);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private int addPadding(int calculatedSize, int alignment) {
/* 1256 */     if (this.actualAlignType != 1 && 
/* 1257 */       calculatedSize % alignment != 0) {
/* 1258 */       calculatedSize += alignment - calculatedSize % alignment;
/*      */     }
/*      */     
/* 1261 */     return calculatedSize;
/*      */   }
/*      */   
/*      */   protected int getStructAlignment() {
/* 1265 */     if (this.size == -1)
/*      */     {
/* 1267 */       calculateSize(true);
/*      */     }
/* 1269 */     return this.structAlignment;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getNativeAlignment(Class<?> type, Object value, boolean isFirstElement) {
/* 1277 */     int alignment = 1;
/* 1278 */     if (NativeMapped.class.isAssignableFrom(type)) {
/* 1279 */       NativeMappedConverter tc = NativeMappedConverter.getInstance(type);
/* 1280 */       type = tc.nativeType();
/* 1281 */       value = tc.toNative(value, new ToNativeContext());
/*      */     } 
/* 1283 */     int size = Native.getNativeSize(type, value);
/* 1284 */     if (type.isPrimitive() || Long.class == type || Integer.class == type || Short.class == type || Character.class == type || Byte.class == type || Boolean.class == type || Float.class == type || Double.class == type) {
/*      */ 
/*      */ 
/*      */       
/* 1288 */       alignment = size;
/*      */     }
/* 1290 */     else if ((Pointer.class.isAssignableFrom(type) && !Function.class.isAssignableFrom(type)) || (Platform.HAS_BUFFERS && Buffer.class.isAssignableFrom(type)) || Callback.class.isAssignableFrom(type) || WString.class == type || String.class == type) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1295 */       alignment = Pointer.SIZE;
/*      */     }
/* 1297 */     else if (Structure.class.isAssignableFrom(type)) {
/* 1298 */       if (ByReference.class.isAssignableFrom(type)) {
/* 1299 */         alignment = Pointer.SIZE;
/*      */       } else {
/*      */         
/* 1302 */         if (value == null)
/* 1303 */           value = newInstance(type, PLACEHOLDER_MEMORY); 
/* 1304 */         alignment = ((Structure)value).getStructAlignment();
/*      */       }
/*      */     
/* 1307 */     } else if (type.isArray()) {
/* 1308 */       alignment = getNativeAlignment(type.getComponentType(), null, isFirstElement);
/*      */     } else {
/*      */       
/* 1311 */       throw new IllegalArgumentException("Type " + type + " has unknown " + "native alignment");
/*      */     } 
/*      */     
/* 1314 */     if (this.actualAlignType == 1) {
/* 1315 */       alignment = 1;
/*      */     }
/* 1317 */     else if (this.actualAlignType == 3) {
/* 1318 */       alignment = Math.min(8, alignment);
/*      */     }
/* 1320 */     else if (this.actualAlignType == 2) {
/*      */ 
/*      */       
/* 1323 */       if (!isFirstElement || !Platform.isMac() || !Platform.isPPC()) {
/* 1324 */         alignment = Math.min(Native.MAX_ALIGNMENT, alignment);
/*      */       }
/* 1326 */       if (!isFirstElement && Platform.isAIX() && (type == double.class || type == Double.class)) {
/* 1327 */         alignment = 4;
/*      */       }
/*      */     } 
/* 1330 */     return alignment;
/*      */   }
/*      */   
/*      */   public String toString() {
/* 1334 */     return toString(Boolean.getBoolean("jna.dump_memory"));
/*      */   }
/*      */   
/*      */   public String toString(boolean debug) {
/* 1338 */     return toString(0, true, debug);
/*      */   }
/*      */   
/*      */   private String format(Class type) {
/* 1342 */     String s = type.getName();
/* 1343 */     int dot = s.lastIndexOf(".");
/* 1344 */     return s.substring(dot + 1);
/*      */   }
/*      */   
/*      */   private String toString(int indent, boolean showContents, boolean dumpMemory) {
/* 1348 */     ensureAllocated();
/* 1349 */     String LS = System.getProperty("line.separator");
/* 1350 */     String name = format(getClass()) + "(" + getPointer() + ")";
/* 1351 */     if (!(getPointer() instanceof Memory)) {
/* 1352 */       name = name + " (" + size() + " bytes)";
/*      */     }
/* 1354 */     String prefix = "";
/* 1355 */     for (int idx = 0; idx < indent; idx++) {
/* 1356 */       prefix = prefix + "  ";
/*      */     }
/* 1358 */     String contents = LS;
/* 1359 */     if (!showContents) {
/* 1360 */       contents = "...}";
/*      */     } else {
/* 1362 */       for (Iterator<StructField> i = fields().values().iterator(); i.hasNext(); ) {
/* 1363 */         StructField sf = i.next();
/* 1364 */         Object value = getFieldValue(sf.field);
/* 1365 */         String type = format(sf.type);
/* 1366 */         String index = "";
/* 1367 */         contents = contents + prefix;
/* 1368 */         if (sf.type.isArray() && value != null) {
/* 1369 */           type = format(sf.type.getComponentType());
/* 1370 */           index = "[" + Array.getLength(value) + "]";
/*      */         } 
/* 1372 */         contents = contents + "  " + type + " " + sf.name + index + "@" + Integer.toHexString(sf.offset);
/*      */         
/* 1374 */         if (value instanceof Structure) {
/* 1375 */           value = ((Structure)value).toString(indent + 1, !(value instanceof ByReference), dumpMemory);
/*      */         }
/* 1377 */         contents = contents + "=";
/* 1378 */         if (value instanceof Long) {
/* 1379 */           contents = contents + Long.toHexString(((Long)value).longValue());
/*      */         }
/* 1381 */         else if (value instanceof Integer) {
/* 1382 */           contents = contents + Integer.toHexString(((Integer)value).intValue());
/*      */         }
/* 1384 */         else if (value instanceof Short) {
/* 1385 */           contents = contents + Integer.toHexString(((Short)value).shortValue());
/*      */         }
/* 1387 */         else if (value instanceof Byte) {
/* 1388 */           contents = contents + Integer.toHexString(((Byte)value).byteValue());
/*      */         } else {
/*      */           
/* 1391 */           contents = contents + String.valueOf(value).trim();
/*      */         } 
/* 1393 */         contents = contents + LS;
/* 1394 */         if (!i.hasNext())
/* 1395 */           contents = contents + prefix + "}"; 
/*      */       } 
/* 1397 */     }  if (indent == 0 && dumpMemory) {
/* 1398 */       int BYTES_PER_ROW = 4;
/* 1399 */       contents = contents + LS + "memory dump" + LS;
/* 1400 */       byte[] buf = getPointer().getByteArray(0L, size());
/* 1401 */       for (int i = 0; i < buf.length; i++) {
/* 1402 */         if (i % 4 == 0) contents = contents + "["; 
/* 1403 */         if (buf[i] >= 0 && buf[i] < 16)
/* 1404 */           contents = contents + "0"; 
/* 1405 */         contents = contents + Integer.toHexString(buf[i] & 0xFF);
/* 1406 */         if (i % 4 == 3 && i < buf.length - 1)
/* 1407 */           contents = contents + "]" + LS; 
/*      */       } 
/* 1409 */       contents = contents + "]";
/*      */     } 
/* 1411 */     return name + " {" + contents;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Structure[] toArray(Structure[] array) {
/* 1421 */     ensureAllocated();
/* 1422 */     if (this.memory instanceof AutoAllocated) {
/*      */       
/* 1424 */       Memory m = (Memory)this.memory;
/* 1425 */       int requiredSize = array.length * size();
/* 1426 */       if (m.size() < requiredSize) {
/* 1427 */         useMemory(autoAllocate(requiredSize));
/*      */       }
/*      */     } 
/*      */     
/* 1431 */     array[0] = this;
/* 1432 */     int size = size();
/* 1433 */     for (int i = 1; i < array.length; i++) {
/* 1434 */       array[i] = newInstance(getClass(), this.memory.share((i * size), size));
/* 1435 */       array[i].conditionalAutoRead();
/*      */     } 
/*      */     
/* 1438 */     if (!(this instanceof ByValue))
/*      */     {
/* 1440 */       this.array = array;
/*      */     }
/*      */     
/* 1443 */     return array;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Structure[] toArray(int size) {
/* 1453 */     return toArray((Structure[])Array.newInstance(getClass(), size));
/*      */   }
/*      */   
/*      */   private Class baseClass() {
/* 1457 */     if ((this instanceof ByReference || this instanceof ByValue) && Structure.class.isAssignableFrom(getClass().getSuperclass()))
/*      */     {
/*      */       
/* 1460 */       return getClass().getSuperclass();
/*      */     }
/* 1462 */     return getClass();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean equals(Object o) {
/* 1469 */     if (o == this) {
/* 1470 */       return true;
/*      */     }
/* 1472 */     if (!(o instanceof Structure)) {
/* 1473 */       return false;
/*      */     }
/* 1475 */     if (o.getClass() != getClass() && ((Structure)o).baseClass() != baseClass())
/*      */     {
/* 1477 */       return false;
/*      */     }
/* 1479 */     Structure s = (Structure)o;
/* 1480 */     if (s.getPointer().equals(getPointer())) {
/* 1481 */       return true;
/*      */     }
/* 1483 */     if (s.size() == size()) {
/* 1484 */       clear(); write();
/* 1485 */       byte[] buf = getPointer().getByteArray(0L, size());
/* 1486 */       s.clear(); s.write();
/* 1487 */       byte[] sbuf = s.getPointer().getByteArray(0L, s.size());
/* 1488 */       return Arrays.equals(buf, sbuf);
/*      */     } 
/* 1490 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int hashCode() {
/* 1497 */     clear(); write();
/* 1498 */     Adler32 code = new Adler32();
/* 1499 */     code.update(getPointer().getByteArray(0L, size()));
/* 1500 */     return (int)code.getValue();
/*      */   }
/*      */ 
/*      */   
/*      */   protected void cacheTypeInfo(Pointer p) {
/* 1505 */     this.typeInfo = p.peer;
/*      */   }
/*      */ 
/*      */   
/*      */   Pointer getFieldTypeInfo(StructField f) {
/* 1510 */     Class type = f.type;
/* 1511 */     Object value = getFieldValue(f.field);
/* 1512 */     if (this.typeMapper != null) {
/* 1513 */       ToNativeConverter nc = this.typeMapper.getToNativeConverter(type);
/* 1514 */       if (nc != null) {
/* 1515 */         type = nc.nativeType();
/* 1516 */         value = nc.toNative(value, new ToNativeContext());
/*      */       } 
/*      */     } 
/* 1519 */     return FFIType.get(value, type);
/*      */   }
/*      */ 
/*      */   
/*      */   Pointer getTypeInfo() {
/* 1524 */     Pointer p = getTypeInfo(this);
/* 1525 */     cacheTypeInfo(p);
/* 1526 */     return p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoSynch(boolean auto) {
/* 1550 */     setAutoRead(auto);
/* 1551 */     setAutoWrite(auto);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoRead(boolean auto) {
/* 1558 */     this.autoRead = auto;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAutoRead() {
/* 1565 */     return this.autoRead;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAutoWrite(boolean auto) {
/* 1572 */     this.autoWrite = auto;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getAutoWrite() {
/* 1579 */     return this.autoWrite;
/*      */   }
/*      */ 
/*      */   
/*      */   static Pointer getTypeInfo(Object obj) {
/* 1584 */     return FFIType.get(obj);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Structure newInstance(Class type, long init) {
/*      */     try {
/* 1593 */       Structure s = newInstance(type, (init == 0L) ? PLACEHOLDER_MEMORY : new Pointer(init));
/* 1594 */       if (init != 0L) {
/* 1595 */         s.conditionalAutoRead();
/*      */       }
/* 1597 */       return s;
/*      */     }
/* 1599 */     catch (Throwable e) {
/* 1600 */       System.err.println("JNA: Error creating structure: " + e);
/* 1601 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Structure newInstance(Class type, Pointer init) throws IllegalArgumentException {
/*      */     try {
/* 1614 */       Constructor<Structure> ctor = type.getConstructor(new Class[] { Pointer.class });
/* 1615 */       return ctor.newInstance(new Object[] { init });
/*      */     }
/* 1617 */     catch (NoSuchMethodException e) {
/*      */ 
/*      */     
/* 1620 */     } catch (SecurityException e) {
/*      */ 
/*      */     
/* 1623 */     } catch (InstantiationException e) {
/* 1624 */       String msg = "Can't instantiate " + type + " (" + e + ")";
/* 1625 */       throw new IllegalArgumentException(msg);
/*      */     }
/* 1627 */     catch (IllegalAccessException e) {
/* 1628 */       String msg = "Instantiation of " + type + "(Pointer) not allowed, is it public? (" + e + ")";
/*      */       
/* 1630 */       throw new IllegalArgumentException(msg);
/*      */     }
/* 1632 */     catch (InvocationTargetException e) {
/* 1633 */       String msg = "Exception thrown while instantiating an instance of " + type + " (" + e + ")";
/* 1634 */       e.printStackTrace();
/* 1635 */       throw new IllegalArgumentException(msg);
/*      */     } 
/* 1637 */     Structure s = newInstance(type);
/* 1638 */     if (init != PLACEHOLDER_MEMORY) {
/* 1639 */       s.useMemory(init);
/*      */     }
/* 1641 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Structure newInstance(Class<Structure> type) throws IllegalArgumentException {
/*      */     try {
/* 1651 */       Structure s = type.newInstance();
/* 1652 */       if (s instanceof ByValue) {
/* 1653 */         s.allocateMemory();
/*      */       }
/* 1655 */       return s;
/*      */     }
/* 1657 */     catch (InstantiationException e) {
/* 1658 */       String msg = "Can't instantiate " + type + " (" + e + ")";
/* 1659 */       throw new IllegalArgumentException(msg);
/*      */     }
/* 1661 */     catch (IllegalAccessException e) {
/* 1662 */       String msg = "Instantiation of " + type + " not allowed, is it public? (" + e + ")";
/*      */       
/* 1664 */       throw new IllegalArgumentException(msg);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   StructField typeInfoField() {
/*      */     LayoutInfo info;
/* 1673 */     synchronized (layoutInfo) {
/* 1674 */       info = (LayoutInfo)layoutInfo.get(getClass());
/*      */     } 
/* 1676 */     if (info != null) {
/* 1677 */       return info.typeInfoField;
/*      */     }
/* 1679 */     return null;
/*      */   }
/*      */   
/*      */   protected static class StructField {
/*      */     public String name;
/*      */     public Class type;
/*      */     public Field field;
/* 1686 */     public int size = -1;
/* 1687 */     public int offset = -1; public boolean isVolatile;
/*      */     public boolean isReadOnly;
/*      */     public FromNativeConverter readConverter;
/*      */     public ToNativeConverter writeConverter;
/*      */     public FromNativeContext context;
/*      */     
/*      */     public String toString() {
/* 1694 */       return this.name + "@" + this.offset + "[" + this.size + "] (" + this.type + ")";
/*      */     }
/*      */   }
/*      */   
/*      */   static class FFIType
/*      */     extends Structure {
/*      */     public static class size_t
/*      */       extends IntegerType
/*      */     {
/* 1703 */       public size_t() { this(0L); } public size_t(long value) {
/* 1704 */         super(Native.SIZE_T_SIZE, value);
/*      */       } }
/* 1706 */     private static Map typeInfoMap = new WeakHashMap<Object, Object>(); private static final int FFI_TYPE_STRUCT = 13; public size_t size; public short alignment;
/*      */     public short type;
/*      */     public Pointer elements;
/*      */     
/*      */     private static class FFITypes {
/*      */       private static Pointer ffi_type_void;
/*      */       private static Pointer ffi_type_float;
/*      */       private static Pointer ffi_type_double;
/*      */       private static Pointer ffi_type_longdouble;
/*      */       private static Pointer ffi_type_uint8;
/*      */       private static Pointer ffi_type_sint8;
/*      */       private static Pointer ffi_type_uint16;
/*      */       private static Pointer ffi_type_sint16;
/*      */       private static Pointer ffi_type_uint32;
/*      */       private static Pointer ffi_type_sint32;
/*      */       private static Pointer ffi_type_uint64;
/*      */       private static Pointer ffi_type_sint64;
/*      */       private static Pointer ffi_type_pointer; }
/*      */     
/*      */     static {
/* 1726 */       if (Native.POINTER_SIZE == 0)
/* 1727 */         throw new Error("Native library not initialized"); 
/* 1728 */       if (FFITypes.ffi_type_void == null)
/* 1729 */         throw new Error("FFI types not initialized"); 
/* 1730 */       typeInfoMap.put(void.class, FFITypes.ffi_type_void);
/* 1731 */       typeInfoMap.put(Void.class, FFITypes.ffi_type_void);
/* 1732 */       typeInfoMap.put(float.class, FFITypes.ffi_type_float);
/* 1733 */       typeInfoMap.put(Float.class, FFITypes.ffi_type_float);
/* 1734 */       typeInfoMap.put(double.class, FFITypes.ffi_type_double);
/* 1735 */       typeInfoMap.put(Double.class, FFITypes.ffi_type_double);
/* 1736 */       typeInfoMap.put(long.class, FFITypes.ffi_type_sint64);
/* 1737 */       typeInfoMap.put(Long.class, FFITypes.ffi_type_sint64);
/* 1738 */       typeInfoMap.put(int.class, FFITypes.ffi_type_sint32);
/* 1739 */       typeInfoMap.put(Integer.class, FFITypes.ffi_type_sint32);
/* 1740 */       typeInfoMap.put(short.class, FFITypes.ffi_type_sint16);
/* 1741 */       typeInfoMap.put(Short.class, FFITypes.ffi_type_sint16);
/* 1742 */       Pointer ctype = (Native.WCHAR_SIZE == 2) ? FFITypes.ffi_type_uint16 : FFITypes.ffi_type_uint32;
/*      */       
/* 1744 */       typeInfoMap.put(char.class, ctype);
/* 1745 */       typeInfoMap.put(Character.class, ctype);
/* 1746 */       typeInfoMap.put(byte.class, FFITypes.ffi_type_sint8);
/* 1747 */       typeInfoMap.put(Byte.class, FFITypes.ffi_type_sint8);
/* 1748 */       typeInfoMap.put(Pointer.class, FFITypes.ffi_type_pointer);
/* 1749 */       typeInfoMap.put(String.class, FFITypes.ffi_type_pointer);
/* 1750 */       typeInfoMap.put(WString.class, FFITypes.ffi_type_pointer);
/* 1751 */       typeInfoMap.put(boolean.class, FFITypes.ffi_type_uint32);
/* 1752 */       typeInfoMap.put(Boolean.class, FFITypes.ffi_type_uint32);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     private FFIType(Structure ref) {
/*      */       Pointer[] els;
/* 1759 */       this.type = 13;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1764 */       ref.ensureAllocated(true);
/*      */       
/* 1766 */       if (ref instanceof Union) {
/* 1767 */         Structure.StructField sf = ((Union)ref).typeInfoField();
/* 1768 */         els = new Pointer[] { get(ref.getFieldValue(sf.field), sf.type), null };
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1774 */         els = new Pointer[ref.fields().size() + 1];
/* 1775 */         int idx = 0;
/* 1776 */         for (Iterator<Structure.StructField> i = ref.fields().values().iterator(); i.hasNext(); ) {
/* 1777 */           Structure.StructField sf = i.next();
/* 1778 */           els[idx++] = ref.getFieldTypeInfo(sf);
/*      */         } 
/*      */       } 
/* 1781 */       init(els);
/*      */     }
/*      */     private FFIType(Object array, Class type) {
/*      */       this.type = 13;
/* 1785 */       int length = Array.getLength(array);
/* 1786 */       Pointer[] els = new Pointer[length + 1];
/* 1787 */       Pointer p = get((Object)null, type.getComponentType());
/* 1788 */       for (int i = 0; i < length; i++) {
/* 1789 */         els[i] = p;
/*      */       }
/* 1791 */       init(els);
/*      */     }
/*      */     protected List getFieldOrder() {
/* 1794 */       return Arrays.asList(new String[] { "size", "alignment", "type", "elements" });
/*      */     }
/*      */     private void init(Pointer[] els) {
/* 1797 */       this.elements = new Memory((Pointer.SIZE * els.length));
/* 1798 */       this.elements.write(0L, els, 0, els.length);
/* 1799 */       write();
/*      */     }
/*      */     
/*      */     static Pointer get(Object obj) {
/* 1803 */       if (obj == null)
/* 1804 */         return FFITypes.ffi_type_pointer; 
/* 1805 */       if (obj instanceof Class)
/* 1806 */         return get((Object)null, (Class)obj); 
/* 1807 */       return get(obj, obj.getClass());
/*      */     }
/*      */     
/*      */     private static Pointer get(Object obj, Class<?> cls) {
/* 1811 */       TypeMapper mapper = Native.getTypeMapper(cls);
/* 1812 */       if (mapper != null) {
/* 1813 */         ToNativeConverter nc = mapper.getToNativeConverter(cls);
/* 1814 */         if (nc != null) {
/* 1815 */           cls = nc.nativeType();
/*      */         }
/*      */       } 
/* 1818 */       synchronized (typeInfoMap) {
/* 1819 */         Object o = typeInfoMap.get(cls);
/* 1820 */         if (o instanceof Pointer) {
/* 1821 */           return (Pointer)o;
/*      */         }
/* 1823 */         if (o instanceof FFIType) {
/* 1824 */           return ((FFIType)o).getPointer();
/*      */         }
/* 1826 */         if ((Platform.HAS_BUFFERS && Buffer.class.isAssignableFrom(cls)) || Callback.class.isAssignableFrom(cls)) {
/*      */           
/* 1828 */           typeInfoMap.put(cls, FFITypes.ffi_type_pointer);
/* 1829 */           return FFITypes.ffi_type_pointer;
/*      */         } 
/* 1831 */         if (Structure.class.isAssignableFrom(cls)) {
/* 1832 */           if (obj == null) obj = newInstance(cls, Structure.PLACEHOLDER_MEMORY); 
/* 1833 */           if (Structure.ByReference.class.isAssignableFrom(cls)) {
/* 1834 */             typeInfoMap.put(cls, FFITypes.ffi_type_pointer);
/* 1835 */             return FFITypes.ffi_type_pointer;
/*      */           } 
/* 1837 */           FFIType type = new FFIType((Structure)obj);
/* 1838 */           typeInfoMap.put(cls, type);
/* 1839 */           return type.getPointer();
/*      */         } 
/* 1841 */         if (NativeMapped.class.isAssignableFrom(cls)) {
/* 1842 */           NativeMappedConverter c = NativeMappedConverter.getInstance(cls);
/* 1843 */           return get(c.toNative(obj, new ToNativeContext()), c.nativeType());
/*      */         } 
/* 1845 */         if (cls.isArray()) {
/* 1846 */           FFIType type = new FFIType(obj, cls);
/*      */           
/* 1848 */           typeInfoMap.put(obj, type);
/* 1849 */           return type.getPointer();
/*      */         } 
/* 1851 */         throw new IllegalArgumentException("Unsupported Structure field type " + cls);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   private static class AutoAllocated extends Memory {
/*      */     public AutoAllocated(int size) {
/* 1858 */       super(size);
/*      */       
/* 1860 */       clear();
/*      */     }
/*      */     public String toString() {
/* 1863 */       return "auto-" + super.toString();
/*      */     }
/*      */   }
/*      */   
/*      */   private static void structureArrayCheck(Structure[] ss) {
/* 1868 */     if (ByReference[].class.isAssignableFrom(ss.getClass())) {
/*      */       return;
/*      */     }
/* 1871 */     Pointer base = ss[0].getPointer();
/* 1872 */     int size = ss[0].size();
/* 1873 */     for (int si = 1; si < ss.length; si++) {
/* 1874 */       if ((ss[si].getPointer()).peer != base.peer + (size * si)) {
/* 1875 */         String msg = "Structure array elements must use contiguous memory (bad backing address at Structure array index " + si + ")";
/*      */         
/* 1877 */         throw new IllegalArgumentException(msg);
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void autoRead(Structure[] ss) {
/* 1883 */     structureArrayCheck(ss);
/* 1884 */     if ((ss[0]).array == ss) {
/* 1885 */       ss[0].autoRead();
/*      */     } else {
/*      */       
/* 1888 */       for (int si = 0; si < ss.length; si++) {
/* 1889 */         if (ss[si] != null) {
/* 1890 */           ss[si].autoRead();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void autoRead() {
/* 1897 */     if (getAutoRead()) {
/* 1898 */       read();
/* 1899 */       if (this.array != null) {
/* 1900 */         for (int i = 1; i < this.array.length; i++) {
/* 1901 */           this.array[i].autoRead();
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   public static void autoWrite(Structure[] ss) {
/* 1908 */     structureArrayCheck(ss);
/* 1909 */     if ((ss[0]).array == ss) {
/* 1910 */       ss[0].autoWrite();
/*      */     } else {
/*      */       
/* 1913 */       for (int si = 0; si < ss.length; si++) {
/* 1914 */         if (ss[si] != null) {
/* 1915 */           ss[si].autoWrite();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void autoWrite() {
/* 1922 */     if (getAutoWrite()) {
/* 1923 */       write();
/* 1924 */       if (this.array != null) {
/* 1925 */         for (int i = 1; i < this.array.length; i++) {
/* 1926 */           this.array[i].autoWrite();
/*      */         }
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getNativeSize(Class nativeType) {
/* 1936 */     return getNativeSize(nativeType, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int getNativeSize(Class nativeType, Object value) {
/* 1943 */     return Native.getNativeSize(nativeType, value);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1949 */   private static final Pointer PLACEHOLDER_MEMORY = new Pointer(0L) { public Pointer share(long offset, long sz) {
/* 1950 */         return this;
/*      */       } }
/*      */   ;
/*      */   
/*      */   static void validate(Class cls) {
/* 1955 */     newInstance(cls, PLACEHOLDER_MEMORY);
/*      */   }
/*      */   
/*      */   protected abstract List getFieldOrder();
/*      */   
/*      */   public static interface ByReference {}
/*      */   
/*      */   public static interface ByValue {}
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/Structure.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */