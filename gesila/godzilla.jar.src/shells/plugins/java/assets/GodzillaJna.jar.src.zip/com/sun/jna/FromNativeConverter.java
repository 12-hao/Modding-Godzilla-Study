package com.sun.jna;

public interface FromNativeConverter {
  Object fromNative(Object paramObject, FromNativeContext paramFromNativeContext);
  
  Class nativeType();
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/FromNativeConverter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */