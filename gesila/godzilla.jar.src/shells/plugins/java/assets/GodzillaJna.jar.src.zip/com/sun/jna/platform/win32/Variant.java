/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.Structure;
/*     */ import com.sun.jna.Union;
/*     */ import com.sun.jna.platform.win32.COM.Dispatch;
/*     */ import com.sun.jna.platform.win32.COM.IDispatch;
/*     */ import com.sun.jna.platform.win32.COM.IRecordInfo;
/*     */ import com.sun.jna.platform.win32.COM.Unknown;
/*     */ import com.sun.jna.ptr.ByteByReference;
/*     */ import com.sun.jna.ptr.DoubleByReference;
/*     */ import com.sun.jna.ptr.FloatByReference;
/*     */ import com.sun.jna.ptr.IntByReference;
/*     */ import com.sun.jna.ptr.ShortByReference;
/*     */ import java.util.Arrays;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface Variant
/*     */ {
/*     */   public static final int VT_EMPTY = 0;
/*     */   public static final int VT_NULL = 1;
/*     */   public static final int VT_I2 = 2;
/*     */   public static final int VT_I4 = 3;
/*     */   public static final int VT_R4 = 4;
/*     */   public static final int VT_R8 = 5;
/*     */   public static final int VT_CY = 6;
/*     */   public static final int VT_DATE = 7;
/*     */   public static final int VT_BSTR = 8;
/*     */   public static final int VT_DISPATCH = 9;
/*     */   public static final int VT_ERROR = 10;
/*     */   public static final int VT_BOOL = 11;
/*     */   public static final int VT_VARIANT = 12;
/*     */   public static final int VT_UNKNOWN = 13;
/*     */   public static final int VT_DECIMAL = 14;
/*     */   public static final int VT_I1 = 16;
/*     */   public static final int VT_UI1 = 17;
/*     */   public static final int VT_UI2 = 18;
/*     */   public static final int VT_UI4 = 19;
/*     */   public static final int VT_I8 = 20;
/*     */   public static final int VT_UI8 = 21;
/*     */   public static final int VT_INT = 22;
/*     */   public static final int VT_UINT = 23;
/*     */   public static final int VT_VOID = 24;
/*     */   public static final int VT_HRESULT = 25;
/*     */   public static final int VT_PTR = 26;
/*     */   public static final int VT_SAFEARRAY = 27;
/*     */   public static final int VT_CARRAY = 28;
/*     */   public static final int VT_USERDEFINED = 29;
/*     */   public static final int VT_LPSTR = 30;
/*     */   public static final int VT_LPWSTR = 31;
/*     */   public static final int VT_RECORD = 36;
/*     */   public static final int VT_INT_PTR = 37;
/*     */   public static final int VT_UINT_PTR = 38;
/*     */   public static final int VT_FILETIME = 64;
/*     */   public static final int VT_BLOB = 65;
/*     */   public static final int VT_STREAM = 66;
/*     */   public static final int VT_STORAGE = 67;
/*     */   public static final int VT_STREAMED_OBJECT = 68;
/*     */   public static final int VT_STORED_OBJECT = 69;
/*     */   public static final int VT_BLOB_OBJECT = 70;
/*     */   public static final int VT_CF = 71;
/*     */   public static final int VT_CLSID = 72;
/*     */   public static final int VT_VERSIONED_STREAM = 73;
/*     */   public static final int VT_BSTR_BLOB = 4095;
/*     */   public static final int VT_VECTOR = 4096;
/*     */   public static final int VT_ARRAY = 8192;
/*     */   public static final int VT_BYREF = 16384;
/*     */   public static final int VT_RESERVED = 32768;
/*     */   public static final int VT_ILLEGAL = 65535;
/*     */   public static final int VT_ILLEGALMASKED = 4095;
/*     */   public static final int VT_TYPEMASK = 4095;
/* 106 */   public static final OaIdl.VARIANT_BOOL VARIANT_TRUE = new OaIdl.VARIANT_BOOL(65535L);
/* 107 */   public static final OaIdl.VARIANT_BOOL VARIANT_FALSE = new OaIdl.VARIANT_BOOL(0L);
/*     */   
/*     */   public static final long COM_DAYS_ADJUSTMENT = 25569L;
/*     */   
/*     */   public static final long MICRO_SECONDS_PER_DAY = 86400000L;
/*     */ 
/*     */   
/*     */   public static class VARIANT
/*     */     extends Union
/*     */   {
/*     */     public _VARIANT _variant;
/*     */     
/*     */     public OaIdl.DECIMAL decVal;
/*     */     
/*     */     public static class ByReference
/*     */       extends VARIANT
/*     */       implements Structure.ByReference {}
/*     */     
/*     */     public VARIANT() {
/* 126 */       setType("_variant");
/* 127 */       read();
/*     */     }
/*     */     
/*     */     public VARIANT(Pointer pointer) {
/* 131 */       super(pointer);
/* 132 */       setType("_variant");
/* 133 */       read();
/*     */     }
/*     */     
/*     */     public VARIANT(WTypes.BSTR value) {
/* 137 */       this();
/* 138 */       setValue(8, value);
/*     */     }
/*     */     
/*     */     public VARIANT(WTypes.BSTRByReference value) {
/* 142 */       this();
/* 143 */       setValue(16392, value);
/*     */     }
/*     */     
/*     */     public VARIANT(OaIdl.VARIANT_BOOL value) {
/* 147 */       this();
/* 148 */       setValue(11, new WinDef.BOOL(value.intValue()));
/*     */     }
/*     */     
/*     */     public VARIANT(WinDef.BOOL value) {
/* 152 */       this();
/* 153 */       setValue(11, value);
/*     */     }
/*     */     
/*     */     public VARIANT(WinDef.LONG value) {
/* 157 */       this();
/* 158 */       setValue(3, value);
/*     */     }
/*     */     
/*     */     public VARIANT(WinDef.SHORT value) {
/* 162 */       this();
/* 163 */       setValue(2, value);
/*     */     }
/*     */     
/*     */     public VARIANT(OaIdl.DATE value) {
/* 167 */       this();
/* 168 */       setValue(7, value);
/*     */     }
/*     */     
/*     */     public VARIANT(short value) {
/* 172 */       this();
/* 173 */       setValue(2, Short.valueOf(value));
/*     */     }
/*     */     
/*     */     public VARIANT(int value) {
/* 177 */       this();
/* 178 */       setValue(3, Integer.valueOf(value));
/*     */     }
/*     */     
/*     */     public VARIANT(long value) {
/* 182 */       this();
/* 183 */       setValue(20, Long.valueOf(value));
/*     */     }
/*     */     
/*     */     public VARIANT(float value) {
/* 187 */       this();
/* 188 */       setValue(4, Float.valueOf(value));
/*     */     }
/*     */     
/*     */     public VARIANT(double value) {
/* 192 */       this();
/* 193 */       setValue(5, Double.valueOf(value));
/*     */     }
/*     */     
/*     */     public VARIANT(String value) {
/* 197 */       this();
/* 198 */       WTypes.BSTR bstrValue = OleAuto.INSTANCE.SysAllocString(value);
/* 199 */       setValue(8, bstrValue);
/*     */     }
/*     */     
/*     */     public VARIANT(boolean value) {
/* 203 */       this();
/* 204 */       if (value) {
/* 205 */         setValue(11, new WinDef.BOOL(Variant.VARIANT_TRUE.intValue()));
/*     */       } else {
/* 207 */         setValue(11, new WinDef.BOOL(Variant.VARIANT_FALSE.intValue()));
/*     */       } 
/*     */     }
/*     */     public VARIANT(IDispatch value) {
/* 211 */       this();
/* 212 */       setValue(9, value);
/*     */     }
/*     */     
/*     */     public VARIANT(Date value) {
/* 216 */       this();
/* 217 */       OaIdl.DATE date = fromJavaDate(value);
/* 218 */       setValue(7, date);
/*     */     }
/*     */     
/*     */     public WTypes.VARTYPE getVarType() {
/* 222 */       read();
/* 223 */       return this._variant.vt;
/*     */     }
/*     */     
/*     */     public void setVarType(short vt) {
/* 227 */       this._variant.vt = new WTypes.VARTYPE(vt);
/*     */     }
/*     */     
/*     */     public void setValue(int vt, Object value) {
/* 231 */       setValue(new WTypes.VARTYPE(vt), value);
/*     */     }
/*     */     
/*     */     public void setValue(WTypes.VARTYPE vt, Object value) {
/* 235 */       switch (vt.intValue()) {
/*     */         case 2:
/* 237 */           this._variant.__variant.writeField("iVal", value);
/*     */           break;
/*     */         case 3:
/* 240 */           this._variant.__variant.writeField("lVal", value);
/*     */           break;
/*     */         case 20:
/* 243 */           this._variant.__variant.writeField("llVal", value);
/*     */           break;
/*     */         case 4:
/* 246 */           this._variant.__variant.writeField("fltVal", value);
/*     */           break;
/*     */         case 5:
/* 249 */           this._variant.__variant.writeField("dblVal", value);
/*     */           break;
/*     */         case 11:
/* 252 */           this._variant.__variant.writeField("boolVal", value);
/*     */           break;
/*     */         case 10:
/* 255 */           this._variant.__variant.writeField("scode", value);
/*     */           break;
/*     */         case 6:
/* 258 */           this._variant.__variant.writeField("cyVal", value);
/*     */           break;
/*     */         case 7:
/* 261 */           this._variant.__variant.writeField("date", value);
/*     */           break;
/*     */         case 8:
/* 264 */           this._variant.__variant.writeField("bstrVal", value);
/*     */           break;
/*     */         case 13:
/* 267 */           this._variant.__variant.writeField("punkVal", value);
/*     */           break;
/*     */         case 9:
/* 270 */           this._variant.__variant.writeField("pdispVal", value);
/*     */           break;
/*     */         case 27:
/* 273 */           this._variant.__variant.writeField("parray", value);
/*     */           break;
/*     */         case 8192:
/* 276 */           this._variant.__variant.writeField("parray", value);
/*     */           break;
/*     */         case 16401:
/* 279 */           this._variant.__variant.writeField("pbVal", value);
/*     */           break;
/*     */         case 16386:
/* 282 */           this._variant.__variant.writeField("piVal", value);
/*     */           break;
/*     */         case 16387:
/* 285 */           this._variant.__variant.writeField("plVal", value);
/*     */           break;
/*     */         case 16404:
/* 288 */           this._variant.__variant.writeField("pllVal", value);
/*     */           break;
/*     */         case 16388:
/* 291 */           this._variant.__variant.writeField("pfltVal", value);
/*     */           break;
/*     */         case 16389:
/* 294 */           this._variant.__variant.writeField("pdblVal", value);
/*     */           break;
/*     */         case 16395:
/* 297 */           this._variant.__variant.writeField("pboolVal", value);
/*     */           break;
/*     */         case 16394:
/* 300 */           this._variant.__variant.writeField("pscode", value);
/*     */           break;
/*     */         case 16390:
/* 303 */           this._variant.__variant.writeField("pcyVal", value);
/*     */           break;
/*     */         case 16391:
/* 306 */           this._variant.__variant.writeField("pdate", value);
/*     */           break;
/*     */         case 16392:
/* 309 */           this._variant.__variant.writeField("pbstrVal", value);
/*     */           break;
/*     */         case 16397:
/* 312 */           this._variant.__variant.writeField("ppunkVal", value);
/*     */           break;
/*     */         case 16393:
/* 315 */           this._variant.__variant.writeField("ppdispVal", value);
/*     */           break;
/*     */         case 24576:
/* 318 */           this._variant.__variant.writeField("pparray", value);
/*     */           break;
/*     */         case 16396:
/* 321 */           this._variant.__variant.writeField("pvarVal", value);
/*     */           break;
/*     */         case 16384:
/* 324 */           this._variant.__variant.writeField("byref", value);
/*     */           break;
/*     */         case 16:
/* 327 */           this._variant.__variant.writeField("cVal", value);
/*     */           break;
/*     */         case 18:
/* 330 */           this._variant.__variant.writeField("uiVal", value);
/*     */           break;
/*     */         case 19:
/* 333 */           this._variant.__variant.writeField("ulVal", value);
/*     */           break;
/*     */         case 21:
/* 336 */           this._variant.__variant.writeField("ullVal", value);
/*     */           break;
/*     */         case 22:
/* 339 */           this._variant.__variant.writeField("intVal", value);
/*     */           break;
/*     */         case 23:
/* 342 */           this._variant.__variant.writeField("uintVal", value);
/*     */           break;
/*     */         case 16398:
/* 345 */           this._variant.__variant.writeField("pdecVal", value);
/*     */           break;
/*     */         case 16400:
/* 348 */           this._variant.__variant.writeField("pcVal", value);
/*     */           break;
/*     */         case 16402:
/* 351 */           this._variant.__variant.writeField("puiVal", value);
/*     */           break;
/*     */         case 16403:
/* 354 */           this._variant.__variant.writeField("pulVal", value);
/*     */           break;
/*     */         case 16405:
/* 357 */           this._variant.__variant.writeField("pullVal", value);
/*     */           break;
/*     */         case 16406:
/* 360 */           this._variant.__variant.writeField("pintVal", value);
/*     */           break;
/*     */         case 16407:
/* 363 */           this._variant.__variant.writeField("puintVal", value);
/*     */           break;
/*     */       } 
/*     */       
/* 367 */       this._variant.writeField("vt", vt);
/* 368 */       write();
/*     */     }
/*     */     
/*     */     public Object getValue() {
/* 372 */       read();
/* 373 */       switch (getVarType().intValue()) {
/*     */         case 2:
/* 375 */           return this._variant.__variant.readField("iVal");
/*     */         case 3:
/* 377 */           return this._variant.__variant.readField("lVal");
/*     */         case 20:
/* 379 */           return this._variant.__variant.readField("llVal");
/*     */         case 4:
/* 381 */           return this._variant.__variant.readField("fltVal");
/*     */         case 5:
/* 383 */           return this._variant.__variant.readField("dblVal");
/*     */         case 11:
/* 385 */           return this._variant.__variant.readField("boolVal");
/*     */         case 10:
/* 387 */           return this._variant.__variant.readField("scode");
/*     */         case 6:
/* 389 */           return this._variant.__variant.readField("cyVal");
/*     */         case 7:
/* 391 */           return this._variant.__variant.readField("date");
/*     */         case 8:
/* 393 */           return this._variant.__variant.readField("bstrVal");
/*     */         case 13:
/* 395 */           return this._variant.__variant.readField("punkVal");
/*     */         case 9:
/* 397 */           return this._variant.__variant.readField("pdispVal");
/*     */         case 27:
/* 399 */           return this._variant.__variant.readField("parray");
/*     */         case 8192:
/* 401 */           return this._variant.__variant.readField("parray");
/*     */         case 16401:
/* 403 */           return this._variant.__variant.readField("pbVal");
/*     */         case 16386:
/* 405 */           return this._variant.__variant.readField("piVal");
/*     */         case 16387:
/* 407 */           return this._variant.__variant.readField("plVal");
/*     */         case 16404:
/* 409 */           return this._variant.__variant.readField("pllVal");
/*     */         case 16388:
/* 411 */           return this._variant.__variant.readField("pfltVal");
/*     */         case 16389:
/* 413 */           return this._variant.__variant.readField("pdblVal");
/*     */         case 16395:
/* 415 */           return this._variant.__variant.readField("pboolVal");
/*     */         case 16394:
/* 417 */           return this._variant.__variant.readField("pscode");
/*     */         case 16390:
/* 419 */           return this._variant.__variant.readField("pcyVal");
/*     */         case 16391:
/* 421 */           return this._variant.__variant.readField("pdate");
/*     */         case 16392:
/* 423 */           return this._variant.__variant.readField("pbstrVal");
/*     */         case 16397:
/* 425 */           return this._variant.__variant.readField("ppunkVal");
/*     */         case 16393:
/* 427 */           return this._variant.__variant.readField("ppdispVal");
/*     */         case 24576:
/* 429 */           return this._variant.__variant.readField("pparray");
/*     */         case 16396:
/* 431 */           return this._variant.__variant.readField("pvarVal");
/*     */         case 16384:
/* 433 */           return this._variant.__variant.readField("byref");
/*     */         case 16:
/* 435 */           return this._variant.__variant.readField("cVal");
/*     */         case 18:
/* 437 */           return this._variant.__variant.readField("uiVal");
/*     */         case 19:
/* 439 */           return this._variant.__variant.readField("ulVal");
/*     */         case 21:
/* 441 */           return this._variant.__variant.readField("ullVal");
/*     */         case 22:
/* 443 */           return this._variant.__variant.readField("intVal");
/*     */         case 23:
/* 445 */           return this._variant.__variant.readField("uintVal");
/*     */         case 16398:
/* 447 */           return this._variant.__variant.readField("pdecVal");
/*     */         case 16400:
/* 449 */           return this._variant.__variant.readField("pcVal");
/*     */         case 16402:
/* 451 */           return this._variant.__variant.readField("puiVal");
/*     */         case 16403:
/* 453 */           return this._variant.__variant.readField("pulVal");
/*     */         case 16405:
/* 455 */           return this._variant.__variant.readField("pullVal");
/*     */         case 16406:
/* 457 */           return this._variant.__variant.readField("pintVal");
/*     */         case 16407:
/* 459 */           return this._variant.__variant.readField("puintVal");
/*     */       } 
/* 461 */       return null;
/*     */     }
/*     */ 
/*     */     
/*     */     public int shortValue() {
/* 466 */       return ((Short)getValue()).shortValue();
/*     */     }
/*     */     
/*     */     public int intValue() {
/* 470 */       return ((Integer)getValue()).intValue();
/*     */     }
/*     */     
/*     */     public long longValue() {
/* 474 */       return ((Long)getValue()).longValue();
/*     */     }
/*     */     
/*     */     public float floatValue() {
/* 478 */       return ((Float)getValue()).floatValue();
/*     */     }
/*     */     
/*     */     public double doubleValue() {
/* 482 */       return ((Double)getValue()).doubleValue();
/*     */     }
/*     */     
/*     */     public String stringValue() {
/* 486 */       WTypes.BSTR bstr = (WTypes.BSTR)getValue();
/* 487 */       return bstr.getValue();
/*     */     }
/*     */     
/*     */     public boolean booleanValue() {
/* 491 */       return ((Boolean)getValue()).booleanValue();
/*     */     }
/*     */     
/*     */     public Date dateValue() {
/* 495 */       OaIdl.DATE varDate = (OaIdl.DATE)getValue();
/* 496 */       return toJavaDate(varDate);
/*     */     }
/*     */ 
/*     */     
/*     */     protected Date toJavaDate(OaIdl.DATE varDate) {
/* 501 */       double doubleDate = varDate.date;
/* 502 */       long longDate = (long)doubleDate;
/*     */       
/* 504 */       double doubleTime = doubleDate - longDate;
/* 505 */       long longTime = (long)doubleTime * 86400000L;
/*     */       
/* 507 */       return new Date((longDate - 25569L) * 86400000L + longTime);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/*     */     protected OaIdl.DATE fromJavaDate(Date javaDate) {
/* 513 */       long longTime = javaDate.getTime() % 86400000L;
/* 514 */       long longDate = (javaDate.getTime() - longTime) / 86400000L + 25569L;
/*     */ 
/*     */       
/* 517 */       float floatTime = (float)longTime / 8.64E7F;
/*     */       
/* 519 */       float floatDateTime = floatTime + (float)longDate;
/* 520 */       return new OaIdl.DATE(floatDateTime);
/*     */     }
/*     */     
/*     */     public static class _VARIANT
/*     */       extends Structure
/*     */     {
/*     */       public WTypes.VARTYPE vt;
/*     */       public short wReserved1;
/*     */       public short wReserved2;
/*     */       public short wReserved3;
/*     */       public __VARIANT __variant;
/*     */       
/*     */       public _VARIANT() {}
/*     */       
/*     */       public _VARIANT(Pointer pointer) {
/* 535 */         super(pointer);
/* 536 */         read();
/*     */       }
/*     */ 
/*     */       
/*     */       public static class __VARIANT
/*     */         extends Union
/*     */       {
/*     */         public WinDef.LONGLONG llVal;
/*     */         
/*     */         public WinDef.LONG lVal;
/*     */         
/*     */         public WinDef.BYTE bVal;
/*     */         
/*     */         public WinDef.SHORT iVal;
/*     */         
/*     */         public Float fltVal;
/*     */         
/*     */         public Double dblVal;
/*     */         
/*     */         public WinDef.BOOL boolVal;
/*     */         
/*     */         public WinDef.SCODE scode;
/*     */         
/*     */         public OaIdl.CURRENCY cyVal;
/*     */         
/*     */         public OaIdl.DATE date;
/*     */         
/*     */         public WTypes.BSTR bstrVal;
/*     */         
/*     */         public Unknown punkVal;
/*     */         
/*     */         public Dispatch pdispVal;
/*     */         
/*     */         public OaIdl.SAFEARRAY.ByReference parray;
/*     */         
/*     */         public ByteByReference pbVal;
/*     */         
/*     */         public ShortByReference piVal;
/*     */         
/*     */         public WinDef.LONGByReference plVal;
/*     */         
/*     */         public WinDef.LONGLONGByReference pllVal;
/*     */         
/*     */         public FloatByReference pfltVal;
/*     */         
/*     */         public DoubleByReference pdblVal;
/*     */         
/*     */         public OaIdl.VARIANT_BOOLByReference pboolVal;
/*     */         
/*     */         public OaIdl._VARIANT_BOOLByReference pbool;
/*     */         
/*     */         public WinDef.SCODEByReference pscode;
/*     */         
/*     */         public OaIdl.CURRENCY.ByReference pcyVal;
/*     */         
/*     */         public OaIdl.DATE.ByReference pdate;
/*     */         
/*     */         public WTypes.BSTR.ByReference pbstrVal;
/*     */         
/*     */         public Unknown.ByReference ppunkVal;
/*     */         
/*     */         public Dispatch.ByReference ppdispVal;
/*     */         
/*     */         public OaIdl.SAFEARRAY.ByReference pparray;
/*     */         
/*     */         public Variant.VARIANT.ByReference pvarVal;
/*     */         
/*     */         public WinDef.PVOID byref;
/*     */         
/*     */         public WinDef.CHAR cVal;
/*     */         
/*     */         public WinDef.USHORT uiVal;
/*     */         
/*     */         public WinDef.ULONG ulVal;
/*     */         
/*     */         public WinDef.ULONGLONG ullVal;
/*     */         
/*     */         public Integer intVal;
/*     */         
/*     */         public WinDef.UINT uintVal;
/*     */         
/*     */         public OaIdl.DECIMAL.ByReference pdecVal;
/*     */         
/*     */         public WinDef.CHARByReference pcVal;
/*     */         
/*     */         public WinDef.USHORTByReference puiVal;
/*     */         
/*     */         public WinDef.ULONGByReference pulVal;
/*     */         
/*     */         public WinDef.ULONGLONGByReference pullVal;
/*     */         public IntByReference pintVal;
/*     */         public WinDef.UINTByReference puintVal;
/*     */         
/*     */         public static class BRECORD
/*     */           extends Structure
/*     */         {
/*     */           public WinDef.PVOID pvRecord;
/*     */           public IRecordInfo pRecInfo;
/*     */           
/*     */           public static class ByReference
/*     */             extends BRECORD
/*     */             implements Structure.ByReference {}
/*     */           
/*     */           public BRECORD() {}
/*     */           
/*     */           public BRECORD(Pointer pointer) {
/* 642 */             super(pointer);
/*     */           }
/*     */ 
/*     */           
/*     */           protected List getFieldOrder() {
/* 647 */             return Arrays.asList(new String[] { "pvRecord", "pRecInfo" });
/*     */           }
/*     */         }
/*     */ 
/*     */ 
/*     */         
/*     */         public __VARIANT() {
/* 654 */           read();
/*     */         }
/*     */         
/*     */         public __VARIANT(Pointer pointer) {
/* 658 */           super(pointer);
/* 659 */           read();
/*     */         }
/*     */       }
/*     */ 
/*     */       
/*     */       protected List getFieldOrder() {
/* 665 */         return Arrays.asList(new String[] { "vt", "wReserved1", "wReserved2", "wReserved3", "__variant" });
/*     */       }
/*     */     } public static class __VARIANT extends Union { public WinDef.LONGLONG llVal; public WinDef.LONG lVal; public WinDef.BYTE bVal; public WinDef.SHORT iVal; public Float fltVal; public Double dblVal; public WinDef.BOOL boolVal; public WinDef.SCODE scode; public OaIdl.CURRENCY cyVal; public OaIdl.DATE date; public WTypes.BSTR bstrVal; public Unknown punkVal; public Dispatch pdispVal; public OaIdl.SAFEARRAY.ByReference parray; public ByteByReference pbVal; public ShortByReference piVal; public WinDef.LONGByReference plVal; public WinDef.LONGLONGByReference pllVal; public FloatByReference pfltVal; public DoubleByReference pdblVal; public OaIdl.VARIANT_BOOLByReference pboolVal; public OaIdl._VARIANT_BOOLByReference pbool; public WinDef.SCODEByReference pscode; public OaIdl.CURRENCY.ByReference pcyVal; public OaIdl.DATE.ByReference pdate; public WTypes.BSTR.ByReference pbstrVal; public Unknown.ByReference ppunkVal; public Dispatch.ByReference ppdispVal; public OaIdl.SAFEARRAY.ByReference pparray; public Variant.VARIANT.ByReference pvarVal; public WinDef.PVOID byref; public WinDef.CHAR cVal; public WinDef.USHORT uiVal; public WinDef.ULONG ulVal; public WinDef.ULONGLONG ullVal; public Integer intVal; public WinDef.UINT uintVal; public OaIdl.DECIMAL.ByReference pdecVal; public WinDef.CHARByReference pcVal; public WinDef.USHORTByReference puiVal; public WinDef.ULONGByReference pulVal; public WinDef.ULONGLONGByReference pullVal; public IntByReference pintVal; public WinDef.UINTByReference puintVal; public static class BRECORD extends Structure { public WinDef.PVOID pvRecord; public IRecordInfo pRecInfo; public static class ByReference extends BRECORD implements Structure.ByReference {} public BRECORD() {} public BRECORD(Pointer pointer) {
/*     */           super(pointer);
/*     */         } protected List getFieldOrder() {
/*     */           return Arrays.asList(new String[] { "pvRecord", "pRecInfo" });
/*     */         } } public __VARIANT() {
/*     */         read();
/*     */       } public __VARIANT(Pointer pointer) {
/*     */         super(pointer);
/*     */         read();
/*     */       } }
/*     */   }
/*     */   public static class VariantArg extends Structure { public static class ByReference extends VariantArg implements Structure.ByReference { public ByReference(Variant.VARIANT[] variantArg) {
/* 679 */         this.variantArg = variantArg;
/*     */       }
/*     */       public ByReference() {} }
/*     */     
/* 683 */     public Variant.VARIANT[] variantArg = new Variant.VARIANT[1];
/*     */ 
/*     */     
/*     */     public VariantArg() {}
/*     */     
/*     */     public VariantArg(Variant.VARIANT[] variantArg) {
/* 689 */       this.variantArg = variantArg;
/*     */     }
/*     */ 
/*     */     
/*     */     protected List getFieldOrder() {
/* 694 */       return Arrays.asList(new String[] { "variantArg" });
/*     */     } }
/*     */ 
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/Variant.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */