/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.Memory;
/*     */ import com.sun.jna.Native;
/*     */ import com.sun.jna.Pointer;
/*     */ import com.sun.jna.PointerType;
/*     */ import com.sun.jna.Structure;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public interface WTypes
/*     */ {
/*     */   public static final int CLSCTX_INPROC_SERVER = 1;
/*     */   public static final int CLSCTX_INPROC_HANDLER = 2;
/*     */   public static final int CLSCTX_LOCAL_SERVER = 4;
/*     */   public static final int CLSCTX_INPROC_SERVER16 = 8;
/*     */   public static final int CLSCTX_REMOTE_SERVER = 16;
/*     */   public static final int CLSCTX_INPROC_HANDLER16 = 32;
/*     */   public static final int CLSCTX_RESERVED1 = 64;
/*     */   public static final int CLSCTX_RESERVED2 = 128;
/*     */   public static final int CLSCTX_RESERVED3 = 256;
/*     */   public static final int CLSCTX_RESERVED4 = 512;
/*     */   public static final int CLSCTX_NO_CODE_DOWNLOAD = 1024;
/*     */   public static final int CLSCTX_RESERVED5 = 2048;
/*     */   public static final int CLSCTX_NO_CUSTOM_MARSHAL = 4096;
/*     */   public static final int CLSCTX_ENABLE_CODE_DOWNLOAD = 8192;
/*     */   public static final int CLSCTX_NO_FAILURE_LOG = 16384;
/*     */   public static final int CLSCTX_DISABLE_AAA = 32768;
/*     */   public static final int CLSCTX_ENABLE_AAA = 65536;
/*     */   public static final int CLSCTX_FROM_DEFAULT_CONTEXT = 131072;
/*     */   public static final int CLSCTX_ACTIVATE_32_BIT_SERVER = 262144;
/*     */   public static final int CLSCTX_ACTIVATE_64_BIT_SERVER = 524288;
/*     */   public static final int CLSCTX_ENABLE_CLOAKING = 1048576;
/*     */   public static final int CLSCTX_APPCONTAINER = 4194304;
/*     */   public static final int CLSCTX_ACTIVATE_AAA_AS_IU = 8388608;
/*     */   public static final int CLSCTX_PS_DLL = -2147483648;
/*     */   public static final int CLSCTX_SERVER = 21;
/*     */   public static final int CLSCTX_ALL = 7;
/*     */   
/*     */   public static class BSTR
/*     */     extends PointerType
/*     */   {
/*     */     public static class ByReference
/*     */       extends BSTR
/*     */       implements Structure.ByReference {}
/*     */     
/*     */     public BSTR() {
/*  70 */       super((Pointer)new Memory(Pointer.SIZE));
/*     */     }
/*     */     
/*     */     public BSTR(Pointer pointer) {
/*  74 */       super(pointer);
/*     */     }
/*     */     
/*     */     public BSTR(String value) {
/*  78 */       super((Pointer)new Memory((value.length() + 1L) * Native.WCHAR_SIZE));
/*  79 */       setValue(value);
/*     */     }
/*     */     
/*     */     public void setValue(String value) {
/*  83 */       getPointer().setWideString(0L, value);
/*     */     }
/*     */     
/*     */     public String getValue() {
/*  87 */       Pointer pointer = getPointer();
/*  88 */       String str = null;
/*  89 */       if (pointer != null) {
/*  90 */         str = pointer.getWideString(0L);
/*     */       }
/*  92 */       return str;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/*  97 */       return getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class BSTRByReference extends com.sun.jna.ptr.ByReference {
/*     */     public BSTRByReference() {
/* 103 */       super(Pointer.SIZE);
/*     */     }
/*     */     
/*     */     public BSTRByReference(WTypes.BSTR value) {
/* 107 */       this();
/* 108 */       setValue(value);
/*     */     }
/*     */     
/*     */     public void setValue(WTypes.BSTR value) {
/* 112 */       getPointer().setPointer(0L, value.getPointer());
/*     */     }
/*     */     
/*     */     public WTypes.BSTR getValue() {
/* 116 */       return new WTypes.BSTR(getPointer().getPointer(0L));
/*     */     }
/*     */     
/*     */     public String getString() {
/* 120 */       return getValue().getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LPSTR
/*     */     extends PointerType {
/*     */     public static class ByReference
/*     */       extends WTypes.BSTR implements Structure.ByReference {}
/*     */     
/*     */     public LPSTR() {
/* 130 */       super(Pointer.NULL);
/*     */     }
/*     */     
/*     */     public LPSTR(Pointer pointer) {
/* 134 */       super(pointer);
/*     */     }
/*     */     
/*     */     public LPSTR(String value) {
/* 138 */       this();
/* 139 */       setValue(value);
/*     */     }
/*     */     
/*     */     public void setValue(String value) {
/* 143 */       getPointer().setWideString(0L, value);
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 147 */       Pointer pointer = getPointer();
/* 148 */       String str = null;
/* 149 */       if (pointer != null) {
/* 150 */         str = pointer.getWideString(0L);
/*     */       }
/* 152 */       return str;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 157 */       return getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LPWSTR
/*     */     extends PointerType {
/*     */     public static class ByReference
/*     */       extends WTypes.BSTR implements Structure.ByReference {}
/*     */     
/*     */     public LPWSTR() {
/* 167 */       super(Pointer.NULL);
/*     */     }
/*     */     
/*     */     public LPWSTR(Pointer pointer) {
/* 171 */       super(pointer);
/*     */     }
/*     */     
/*     */     public LPWSTR(String value) {
/* 175 */       this();
/* 176 */       setValue(value);
/*     */     }
/*     */     
/*     */     public void setValue(String value) {
/* 180 */       getPointer().setWideString(0L, value);
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 184 */       Pointer pointer = getPointer();
/* 185 */       String str = null;
/* 186 */       if (pointer != null) {
/* 187 */         str = pointer.getWideString(0L);
/*     */       }
/* 189 */       return str;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 194 */       return getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class LPOLESTR
/*     */     extends PointerType {
/*     */     public static class ByReference
/*     */       extends WTypes.BSTR implements Structure.ByReference {}
/*     */     
/*     */     public LPOLESTR() {
/* 204 */       super(Pointer.NULL);
/*     */     }
/*     */     
/*     */     public LPOLESTR(Pointer pointer) {
/* 208 */       super(pointer);
/*     */     }
/*     */     
/*     */     public LPOLESTR(String value) {
/* 212 */       super((Pointer)new Memory((value.length() + 1L) * Native.WCHAR_SIZE));
/* 213 */       setValue(value);
/*     */     }
/*     */     
/*     */     public void setValue(String value) {
/* 217 */       getPointer().setWideString(0L, value);
/*     */     }
/*     */     
/*     */     public String getValue() {
/* 221 */       Pointer pointer = getPointer();
/* 222 */       String str = null;
/* 223 */       if (pointer != null) {
/* 224 */         str = pointer.getWideString(0L);
/*     */       }
/* 226 */       return str;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 231 */       return getValue();
/*     */     }
/*     */   }
/*     */   
/*     */   public static class VARTYPE extends WinDef.USHORT {
/*     */     public VARTYPE() {
/* 237 */       this(0);
/*     */     }
/*     */     
/*     */     public VARTYPE(int value) {
/* 241 */       super(value);
/*     */     }
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/WTypes.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */