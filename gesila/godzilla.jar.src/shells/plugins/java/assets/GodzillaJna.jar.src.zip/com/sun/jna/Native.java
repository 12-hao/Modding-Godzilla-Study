/*      */ package com.sun.jna;
/*      */ 
/*      */ import java.awt.Component;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.awt.HeadlessException;
/*      */ import java.awt.Window;
/*      */ import java.io.File;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.FilenameFilter;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Field;
/*      */ import java.lang.reflect.InvocationHandler;
/*      */ import java.lang.reflect.Method;
/*      */ import java.lang.reflect.Modifier;
/*      */ import java.lang.reflect.Proxy;
/*      */ import java.net.URI;
/*      */ import java.net.URISyntaxException;
/*      */ import java.net.URL;
/*      */ import java.net.URLClassLoader;
/*      */ import java.nio.Buffer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.WeakHashMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public final class Native
/*      */   implements Version
/*      */ {
/*      */   public static final String DEFAULT_ENCODING = "utf8";
/*   95 */   static final boolean DEBUG_LOAD = Boolean.getBoolean("jna.debug_load");
/*   96 */   static final boolean DEBUG_JNA_LOAD = Boolean.getBoolean("jna.debug_load.jna");
/*      */ 
/*      */   
/*   99 */   static String jnidispatchPath = null;
/*  100 */   private static Map options = new WeakHashMap<Object, Object>();
/*  101 */   private static Map libraries = new WeakHashMap<Object, Object>();
/*  102 */   private static final Callback.UncaughtExceptionHandler DEFAULT_HANDLER = new Callback.UncaughtExceptionHandler()
/*      */     {
/*      */       public void uncaughtException(Callback c, Throwable e) {
/*  105 */         System.err.println("JNA: Callback " + c + " threw the following exception:");
/*  106 */         e.printStackTrace();
/*      */       }
/*      */     };
/*  109 */   private static Callback.UncaughtExceptionHandler callbackExceptionHandler = DEFAULT_HANDLER;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static {
/*  131 */     loadNativeDispatchLibrary();
/*  132 */   } public static final int POINTER_SIZE = sizeof(0);
/*  133 */   public static final int LONG_SIZE = sizeof(1);
/*  134 */   public static final int WCHAR_SIZE = sizeof(2);
/*  135 */   public static final int SIZE_T_SIZE = sizeof(3); private static final int TYPE_VOIDP = 0; private static final int TYPE_LONG = 1; private static final int TYPE_WCHAR_T = 2;
/*      */   private static final int TYPE_SIZE_T = 3;
/*      */   
/*      */   static {
/*  139 */     initIDs();
/*  140 */     if (Boolean.getBoolean("jna.protected")) {
/*  141 */       setProtected(true);
/*      */     }
/*  143 */     String version = getNativeVersion();
/*  144 */     if (!"4.0.0".equals(version)) {
/*  145 */       String LS = System.getProperty("line.separator");
/*  146 */       throw new Error(LS + LS + "There is an incompatible JNA native library installed on this system" + LS + ((jnidispatchPath != null) ? ("(at " + jnidispatchPath + ")") : System.getProperty("java.library.path")) + "." + LS + "To resolve this issue you may do one of the following:" + LS + " - remove or uninstall the offending library" + LS + " - set the system property jna.nosys=true" + LS + " - set jna.boot.library.path to include the path to the version of the " + LS + "   jnidispatch library included with the JNA jar file you are using" + LS);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  157 */   static final int MAX_ALIGNMENT = (Platform.isSPARC() || Platform.isWindows() || (Platform.isLinux() && (Platform.isARM() || Platform.isPPC())) || Platform.isAIX() || Platform.isAndroid()) ? 8 : LONG_SIZE;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  162 */   static final int MAX_PADDING = (Platform.isMac() && Platform.isPPC()) ? 8 : MAX_ALIGNMENT;
/*      */ 
/*      */ 
/*      */   
/*  166 */   private static final Object finalizer = new Object() {
/*      */       protected void finalize() {
/*  168 */         Native.dispose();
/*      */       }
/*      */     };
/*      */   static final String JNA_TMPLIB_PREFIX = "jna";
/*      */   
/*      */   private static void dispose() {
/*  174 */     NativeLibrary.disposeAll();
/*  175 */     jnidispatchPath = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static boolean deleteLibrary(File lib) {
/*  190 */     if (lib.delete()) {
/*  191 */       return true;
/*      */     }
/*      */ 
/*      */     
/*  195 */     markTemporaryFile(lib);
/*      */     
/*  197 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setPreserveLastError(boolean enable) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean getPreserveLastError() {
/*  246 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long getWindowID(Window w) throws HeadlessException {
/*  255 */     return AWT.getWindowID(w);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long getComponentID(Component c) throws HeadlessException {
/*  265 */     return AWT.getComponentID(c);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer getWindowPointer(Window w) throws HeadlessException {
/*  275 */     return new Pointer(AWT.getWindowID(w));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer getComponentPointer(Component c) throws HeadlessException {
/*  285 */     return new Pointer(AWT.getComponentID(c));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Pointer getDirectBufferPointer(Buffer b) {
/*  294 */     long peer = _getDirectBufferPointer(b);
/*  295 */     return (peer == 0L) ? null : new Pointer(peer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(byte[] buf) {
/*  305 */     return toString(buf, getDefaultStringEncoding());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(byte[] buf, String encoding) {
/*  314 */     String s = null;
/*  315 */     if (encoding != null) {
/*      */       try {
/*  317 */         s = new String(buf, encoding);
/*      */       }
/*  319 */       catch (UnsupportedEncodingException e) {
/*  320 */         System.err.println("JNA Warning: Encoding '" + encoding + "' is unsupported");
/*      */       } 
/*      */     }
/*      */     
/*  324 */     if (s == null) {
/*  325 */       System.err.println("JNA Warning: Decoding with fallback " + System.getProperty("file.encoding"));
/*  326 */       s = new String(buf);
/*      */     } 
/*  328 */     int term = s.indexOf(false);
/*  329 */     if (term != -1) {
/*  330 */       s = s.substring(0, term);
/*      */     }
/*  332 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String toString(char[] buf) {
/*  339 */     String s = new String(buf);
/*  340 */     int term = s.indexOf(false);
/*  341 */     if (term != -1) {
/*  342 */       s = s.substring(0, term);
/*      */     }
/*  344 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object loadLibrary(Class interfaceClass) {
/*  358 */     return loadLibrary((String)null, interfaceClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object loadLibrary(Class interfaceClass, Map options) {
/*  375 */     return loadLibrary(null, interfaceClass, options);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object loadLibrary(String name, Class interfaceClass) {
/*  391 */     return loadLibrary(name, interfaceClass, Collections.EMPTY_MAP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object loadLibrary(String name, Class interfaceClass, Map options) {
/*  412 */     Library.Handler handler = new Library.Handler(name, interfaceClass, options);
/*      */     
/*  414 */     ClassLoader loader = interfaceClass.getClassLoader();
/*  415 */     Library proxy = (Library)Proxy.newProxyInstance(loader, new Class[] { interfaceClass }, handler);
/*      */ 
/*      */     
/*  418 */     cacheOptions(interfaceClass, options, proxy);
/*  419 */     return proxy;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void loadLibraryInstance(Class<?> cls) {
/*  428 */     synchronized (libraries) {
/*  429 */       if (cls != null && !libraries.containsKey(cls)) {
/*      */         try {
/*  431 */           Field[] fields = cls.getFields();
/*  432 */           for (int i = 0; i < fields.length; i++) {
/*  433 */             Field field = fields[i];
/*  434 */             if (field.getType() == cls && Modifier.isStatic(field.getModifiers())) {
/*      */ 
/*      */               
/*  437 */               libraries.put(cls, new WeakReference(field.get(null)));
/*      */               
/*      */               break;
/*      */             } 
/*      */           } 
/*  442 */         } catch (Exception e) {
/*  443 */           throw new IllegalArgumentException("Could not access instance of " + cls + " (" + e + ")");
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Class findEnclosingLibraryClass(Class<?> cls) {
/*  455 */     if (cls == null) {
/*  456 */       return null;
/*      */     }
/*      */ 
/*      */     
/*  460 */     synchronized (libraries) {
/*  461 */       if (options.containsKey(cls)) {
/*  462 */         return cls;
/*      */       }
/*      */     } 
/*  465 */     if (Library.class.isAssignableFrom(cls)) {
/*  466 */       return cls;
/*      */     }
/*  468 */     if (Callback.class.isAssignableFrom(cls)) {
/*  469 */       cls = CallbackReference.findCallbackClass(cls);
/*      */     }
/*  471 */     Class<?> declaring = cls.getDeclaringClass();
/*  472 */     Class fromDeclaring = findEnclosingLibraryClass(declaring);
/*  473 */     if (fromDeclaring != null) {
/*  474 */       return fromDeclaring;
/*      */     }
/*  476 */     return findEnclosingLibraryClass(cls.getSuperclass());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Map getLibraryOptions(Class<?> type) {
/*  491 */     synchronized (libraries) {
/*  492 */       if (options.containsKey(type)) {
/*  493 */         return (Map)options.get(type);
/*      */       }
/*      */     } 
/*  496 */     Class<?> mappingClass = findEnclosingLibraryClass(type);
/*  497 */     if (mappingClass != null) {
/*  498 */       loadLibraryInstance(mappingClass);
/*      */     } else {
/*      */       
/*  501 */       mappingClass = type;
/*      */     } 
/*  503 */     synchronized (libraries) {
/*  504 */       if (options.containsKey(mappingClass)) {
/*  505 */         Map map = (Map)options.get(mappingClass);
/*  506 */         options.put(type, map);
/*  507 */         return map;
/*      */       } 
/*  509 */       Map<?, ?> libraryOptions = null;
/*      */       try {
/*  511 */         Field field = mappingClass.getField("OPTIONS");
/*  512 */         field.setAccessible(true);
/*  513 */         libraryOptions = (Map)field.get(null);
/*      */       }
/*  515 */       catch (NoSuchFieldException e) {
/*  516 */         libraryOptions = Collections.EMPTY_MAP;
/*      */       }
/*  518 */       catch (Exception e) {
/*  519 */         throw new IllegalArgumentException("OPTIONS must be a public field of type java.util.Map (" + e + "): " + mappingClass);
/*      */       } 
/*      */ 
/*      */       
/*  523 */       libraryOptions = new HashMap<Object, Object>(libraryOptions);
/*  524 */       if (!libraryOptions.containsKey("type-mapper")) {
/*  525 */         libraryOptions.put("type-mapper", lookupField(mappingClass, "TYPE_MAPPER", TypeMapper.class));
/*      */       }
/*  527 */       if (!libraryOptions.containsKey("structure-alignment")) {
/*  528 */         libraryOptions.put("structure-alignment", lookupField(mappingClass, "STRUCTURE_ALIGNMENT", Integer.class));
/*      */       }
/*  530 */       if (!libraryOptions.containsKey("string-encoding")) {
/*  531 */         libraryOptions.put("string-encoding", lookupField(mappingClass, "STRING_ENCODING", String.class));
/*      */       }
/*  533 */       options.put(mappingClass, libraryOptions);
/*      */       
/*  535 */       if (type != mappingClass) {
/*  536 */         options.put(type, libraryOptions);
/*      */       }
/*  538 */       return libraryOptions;
/*      */     } 
/*      */   }
/*      */   
/*      */   private static Object lookupField(Class mappingClass, String fieldName, Class resultClass) {
/*      */     try {
/*  544 */       Field field = mappingClass.getField(fieldName);
/*  545 */       field.setAccessible(true);
/*  546 */       return field.get(null);
/*      */     }
/*  548 */     catch (NoSuchFieldException e) {
/*  549 */       return null;
/*      */     }
/*  551 */     catch (Exception e) {
/*  552 */       throw new IllegalArgumentException(fieldName + " must be a public field of type " + resultClass.getName() + " (" + e + "): " + mappingClass);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TypeMapper getTypeMapper(Class cls) {
/*  562 */     return (TypeMapper)getLibraryOptions(cls).get("type-mapper");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getStringEncoding(Class cls) {
/*  571 */     String encoding = (String)getLibraryOptions(cls).get("string-encoding");
/*  572 */     return (encoding != null) ? encoding : getDefaultStringEncoding();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getDefaultStringEncoding() {
/*  579 */     return System.getProperty("jna.encoding", "utf8");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getStructureAlignment(Class cls) {
/*  586 */     Integer alignment = (Integer)getLibraryOptions(cls).get("structure-alignment");
/*  587 */     return (alignment == null) ? 0 : alignment.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static byte[] getBytes(String s) {
/*  594 */     return getBytes(s, getDefaultStringEncoding());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static byte[] getBytes(String s, String encoding) {
/*  602 */     if (encoding != null) {
/*      */       try {
/*  604 */         return s.getBytes(encoding);
/*      */       }
/*  606 */       catch (UnsupportedEncodingException e) {
/*  607 */         System.err.println("JNA Warning: Encoding '" + encoding + "' is unsupported");
/*      */       } 
/*      */     }
/*      */     
/*  611 */     System.err.println("JNA Warning: Encoding with fallback " + System.getProperty("file.encoding"));
/*      */     
/*  613 */     return s.getBytes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toByteArray(String s) {
/*  620 */     return toByteArray(s, getDefaultStringEncoding());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] toByteArray(String s, String encoding) {
/*  627 */     byte[] bytes = getBytes(s, encoding);
/*  628 */     byte[] buf = new byte[bytes.length + 1];
/*  629 */     System.arraycopy(bytes, 0, buf, 0, bytes.length);
/*  630 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static char[] toCharArray(String s) {
/*  637 */     char[] chars = s.toCharArray();
/*  638 */     char[] buf = new char[chars.length + 1];
/*  639 */     System.arraycopy(chars, 0, buf, 0, chars.length);
/*  640 */     return buf;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void loadNativeDispatchLibrary() {
/*  650 */     if (!Boolean.getBoolean("jna.nounpack")) {
/*      */       try {
/*  652 */         removeTemporaryFiles();
/*      */       }
/*  654 */       catch (IOException e) {
/*  655 */         System.err.println("JNA Warning: IOException removing temporary files: " + e.getMessage());
/*      */       } 
/*      */     }
/*      */     
/*  659 */     String libName = System.getProperty("jna.boot.library.name", "jnidispatch");
/*  660 */     String bootPath = System.getProperty("jna.boot.library.path");
/*  661 */     if (bootPath != null) {
/*      */       
/*  663 */       StringTokenizer dirs = new StringTokenizer(bootPath, File.pathSeparator);
/*  664 */       while (dirs.hasMoreTokens()) {
/*  665 */         String dir = dirs.nextToken();
/*  666 */         File file = new File(new File(dir), System.mapLibraryName(libName).replace(".dylib", ".jnilib"));
/*  667 */         String path = file.getAbsolutePath();
/*  668 */         if (DEBUG_JNA_LOAD) {
/*  669 */           System.out.println("Looking in " + path);
/*      */         }
/*  671 */         if (file.exists()) {
/*      */           try {
/*  673 */             if (DEBUG_JNA_LOAD) {
/*  674 */               System.out.println("Trying " + path);
/*      */             }
/*  676 */             System.setProperty("jnidispatch.path", path);
/*  677 */             System.load(path);
/*  678 */             jnidispatchPath = path;
/*  679 */             if (DEBUG_JNA_LOAD) {
/*  680 */               System.out.println("Found jnidispatch at " + path);
/*      */             }
/*      */             return;
/*  683 */           } catch (UnsatisfiedLinkError ex) {}
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  689 */         if (Platform.isMac()) {
/*      */           String orig, ext;
/*  691 */           if (path.endsWith("dylib")) {
/*  692 */             orig = "dylib";
/*  693 */             ext = "jnilib";
/*      */           } else {
/*  695 */             orig = "jnilib";
/*  696 */             ext = "dylib";
/*      */           } 
/*  698 */           path = path.substring(0, path.lastIndexOf(orig)) + ext;
/*  699 */           if (DEBUG_JNA_LOAD) {
/*  700 */             System.out.println("Looking in " + path);
/*      */           }
/*  702 */           if ((new File(path)).exists()) {
/*      */             try {
/*  704 */               if (DEBUG_JNA_LOAD) {
/*  705 */                 System.out.println("Trying " + path);
/*      */               }
/*  707 */               System.setProperty("jnidispatch.path", path);
/*  708 */               System.load(path);
/*  709 */               jnidispatchPath = path;
/*  710 */               if (DEBUG_JNA_LOAD) {
/*  711 */                 System.out.println("Found jnidispatch at " + path);
/*      */               }
/*      */               return;
/*  714 */             } catch (UnsatisfiedLinkError ex) {
/*  715 */               System.err.println("File found at " + path + " but not loadable: " + ex.getMessage());
/*      */             } 
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } 
/*  721 */     if (!Boolean.getBoolean("jna.nosys")) {
/*      */       try {
/*  723 */         if (DEBUG_JNA_LOAD) {
/*  724 */           System.out.println("Trying (via loadLibrary) " + libName);
/*      */         }
/*  726 */         System.loadLibrary(libName);
/*  727 */         if (DEBUG_JNA_LOAD) {
/*  728 */           System.out.println("Found jnidispatch on system path");
/*      */         }
/*      */         
/*      */         return;
/*  732 */       } catch (UnsatisfiedLinkError e) {}
/*      */     }
/*      */     
/*  735 */     if (!Boolean.getBoolean("jna.noclasspath")) {
/*  736 */       loadNativeDispatchLibraryFromClasspath();
/*      */     } else {
/*      */       
/*  739 */       throw new UnsatisfiedLinkError("Unable to locate JNA native support library");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void loadNativeDispatchLibraryFromClasspath() {
/*      */     try {
/*  750 */       String libName = "/com/sun/jna/" + Platform.RESOURCE_PREFIX + "/" + System.mapLibraryName("jnidispatch").replace(".dylib", ".jnilib");
/*  751 */       File lib = extractFromResourcePath(libName, Native.class.getClassLoader());
/*  752 */       if (lib == null && 
/*  753 */         lib == null) {
/*  754 */         throw new UnsatisfiedLinkError("Could not find JNA native support");
/*      */       }
/*      */       
/*  757 */       if (DEBUG_JNA_LOAD) {
/*  758 */         System.out.println("Trying " + lib.getAbsolutePath());
/*      */       }
/*  760 */       System.setProperty("jnidispatch.path", lib.getAbsolutePath());
/*  761 */       System.load(lib.getAbsolutePath());
/*  762 */       jnidispatchPath = lib.getAbsolutePath();
/*  763 */       if (DEBUG_JNA_LOAD) {
/*  764 */         System.out.println("Found jnidispatch at " + jnidispatchPath);
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  770 */       if (isUnpacked(lib) && !Boolean.getBoolean("jnidispatch.preserve"))
/*      */       {
/*  772 */         deleteLibrary(lib);
/*      */       }
/*      */     }
/*  775 */     catch (IOException e) {
/*  776 */       throw new UnsatisfiedLinkError(e.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static boolean isUnpacked(File file) {
/*  782 */     return file.getName().startsWith("jna");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File extractFromResourcePath(String name) throws IOException {
/*  797 */     return extractFromResourcePath(name, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static File extractFromResourcePath(String name, ClassLoader loader) throws IOException {
/*  813 */     boolean DEBUG = (DEBUG_LOAD || (DEBUG_JNA_LOAD && name.indexOf("jnidispatch") != -1));
/*      */     
/*  815 */     if (loader == null) {
/*  816 */       loader = Thread.currentThread().getContextClassLoader();
/*      */       
/*  818 */       if (loader == null) {
/*  819 */         loader = Native.class.getClassLoader();
/*      */       }
/*      */     } 
/*  822 */     if (DEBUG) {
/*  823 */       System.out.println("Looking in classpath from " + loader + " for " + name);
/*      */     }
/*  825 */     String libname = name.startsWith("/") ? name : NativeLibrary.mapSharedLibraryName(name);
/*  826 */     String resourcePath = name.startsWith("/") ? name : (Platform.RESOURCE_PREFIX + "/" + libname);
/*  827 */     if (resourcePath.startsWith("/")) {
/*  828 */       resourcePath = resourcePath.substring(1);
/*      */     }
/*  830 */     URL url = loader.getResource(resourcePath);
/*  831 */     if (url == null && resourcePath.startsWith(Platform.RESOURCE_PREFIX))
/*      */     {
/*  833 */       url = loader.getResource(libname);
/*      */     }
/*  835 */     if (url == null) {
/*  836 */       String path = System.getProperty("java.class.path");
/*  837 */       if (loader instanceof URLClassLoader) {
/*  838 */         path = Arrays.<URL>asList(((URLClassLoader)loader).getURLs()).toString();
/*      */       }
/*  840 */       throw new IOException("Native library (" + resourcePath + ") not found in resource path (" + path + ")");
/*      */     } 
/*  842 */     if (DEBUG) {
/*  843 */       System.out.println("Found library resource at " + url);
/*      */     }
/*      */     
/*  846 */     File lib = null;
/*  847 */     if (url.getProtocol().toLowerCase().equals("file")) {
/*      */       try {
/*  849 */         lib = new File(new URI(url.toString()));
/*      */       }
/*  851 */       catch (URISyntaxException e) {
/*  852 */         lib = new File(url.getPath());
/*      */       } 
/*  854 */       if (DEBUG) {
/*  855 */         System.out.println("Looking in " + lib.getAbsolutePath());
/*      */       }
/*  857 */       if (!lib.exists()) {
/*  858 */         throw new IOException("File URL " + url + " could not be properly decoded");
/*      */       }
/*      */     }
/*  861 */     else if (!Boolean.getBoolean("jna.nounpack")) {
/*  862 */       InputStream is = loader.getResourceAsStream(resourcePath);
/*  863 */       if (is == null) {
/*  864 */         throw new IOException("Can't obtain InputStream for " + resourcePath);
/*      */       }
/*      */       
/*  867 */       FileOutputStream fos = null;
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  872 */         File dir = getTempDir();
/*  873 */         lib = File.createTempFile("jna", Platform.isWindows() ? ".dll" : null, dir);
/*  874 */         if (!Boolean.getBoolean("jnidispatch.preserve")) {
/*  875 */           lib.deleteOnExit();
/*      */         }
/*  877 */         fos = new FileOutputStream(lib);
/*      */         
/*  879 */         byte[] buf = new byte[1024]; int count;
/*  880 */         while ((count = is.read(buf, 0, buf.length)) > 0) {
/*  881 */           fos.write(buf, 0, count);
/*      */         }
/*      */       }
/*  884 */       catch (IOException e) {
/*  885 */         throw new IOException("Failed to create temporary file for " + name + " library: " + e.getMessage());
/*      */       } finally {
/*      */         
/*  888 */         try { is.close(); } catch (IOException e) {}
/*  889 */         if (fos != null) {
/*  890 */           try { fos.close(); } catch (IOException e) {}
/*      */         }
/*      */       } 
/*      */     } 
/*  894 */     return lib;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Library synchronizedLibrary(final Library library) {
/*  934 */     Class<?> cls = library.getClass();
/*  935 */     if (!Proxy.isProxyClass(cls)) {
/*  936 */       throw new IllegalArgumentException("Library must be a proxy class");
/*      */     }
/*  938 */     InvocationHandler ih = Proxy.getInvocationHandler(library);
/*  939 */     if (!(ih instanceof Library.Handler)) {
/*  940 */       throw new IllegalArgumentException("Unrecognized proxy handler: " + ih);
/*      */     }
/*  942 */     final Library.Handler handler = (Library.Handler)ih;
/*  943 */     InvocationHandler newHandler = new InvocationHandler() {
/*      */         public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
/*  945 */           synchronized (handler.getNativeLibrary()) {
/*  946 */             return handler.invoke(library, method, args);
/*      */           } 
/*      */         }
/*      */       };
/*  950 */     return (Library)Proxy.newProxyInstance(cls.getClassLoader(), cls.getInterfaces(), newHandler);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getWebStartLibraryPath(String libName) {
/*  971 */     if (System.getProperty("javawebstart.version") == null) {
/*  972 */       return null;
/*      */     }
/*      */     try {
/*  975 */       ClassLoader cl = Native.class.getClassLoader();
/*  976 */       Method m = AccessController.<Method>doPrivileged(new PrivilegedAction<Method>() {
/*      */             public Object run() {
/*      */               try {
/*  979 */                 Method m = ClassLoader.class.getDeclaredMethod("findLibrary", new Class[] { String.class });
/*  980 */                 m.setAccessible(true);
/*  981 */                 return m;
/*      */               }
/*  983 */               catch (Exception e) {
/*  984 */                 return null;
/*      */               } 
/*      */             }
/*      */           });
/*  988 */       String libpath = (String)m.invoke(cl, new Object[] { libName });
/*  989 */       if (libpath != null) {
/*  990 */         return (new File(libpath)).getParent();
/*      */       }
/*  992 */       return null;
/*      */     }
/*  994 */     catch (Exception e) {
/*  995 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static void markTemporaryFile(File file) {
/*      */     try {
/* 1005 */       File marker = new File(file.getParentFile(), file.getName() + ".x");
/* 1006 */       marker.createNewFile();
/*      */     } catch (IOException e) {
/* 1008 */       e.printStackTrace();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static File getTempDir() throws IOException {
/*      */     File jnatmp;
/* 1016 */     String prop = System.getProperty("jna.tmpdir");
/* 1017 */     if (prop != null) {
/* 1018 */       jnatmp = new File(prop);
/* 1019 */       jnatmp.mkdirs();
/*      */     } else {
/*      */       
/* 1022 */       File tmp = new File(System.getProperty("java.io.tmpdir"));
/*      */ 
/*      */ 
/*      */       
/* 1026 */       jnatmp = new File(tmp, "jna-" + System.getProperty("user.name").hashCode());
/* 1027 */       jnatmp.mkdirs();
/* 1028 */       if (!jnatmp.exists() || !jnatmp.canWrite()) {
/* 1029 */         jnatmp = tmp;
/*      */       }
/*      */     } 
/* 1032 */     if (!jnatmp.exists()) {
/* 1033 */       throw new IOException("JNA temporary directory '" + jnatmp + "' does not exist");
/*      */     }
/* 1035 */     if (!jnatmp.canWrite()) {
/* 1036 */       throw new IOException("JNA temporary directory '" + jnatmp + "' is not writable");
/*      */     }
/* 1038 */     return jnatmp;
/*      */   }
/*      */ 
/*      */   
/*      */   static void removeTemporaryFiles() throws IOException {
/* 1043 */     File dir = getTempDir();
/* 1044 */     FilenameFilter filter = new FilenameFilter() {
/*      */         public boolean accept(File dir, String name) {
/* 1046 */           return (name.endsWith(".x") && name.startsWith("jna"));
/*      */         }
/*      */       };
/* 1049 */     File[] files = dir.listFiles(filter);
/* 1050 */     for (int i = 0; files != null && i < files.length; i++) {
/* 1051 */       File marker = files[i];
/* 1052 */       String name = marker.getName();
/* 1053 */       name = name.substring(0, name.length() - 2);
/* 1054 */       File target = new File(marker.getParentFile(), name);
/* 1055 */       if (!target.exists() || target.delete()) {
/* 1056 */         marker.delete();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getNativeSize(Class<?> type, Object value) {
/* 1065 */     if (type.isArray()) {
/* 1066 */       int len = Array.getLength(value);
/* 1067 */       if (len > 0) {
/* 1068 */         Object o = Array.get(value, 0);
/* 1069 */         return len * getNativeSize(type.getComponentType(), o);
/*      */       } 
/*      */       
/* 1072 */       throw new IllegalArgumentException("Arrays of length zero not allowed: " + type);
/*      */     } 
/* 1074 */     if (Structure.class.isAssignableFrom(type) && !Structure.ByReference.class.isAssignableFrom(type))
/*      */     {
/* 1076 */       return Structure.size(type, (Structure)value);
/*      */     }
/*      */     try {
/* 1079 */       return getNativeSize(type);
/*      */     }
/* 1081 */     catch (IllegalArgumentException e) {
/* 1082 */       throw new IllegalArgumentException("The type \"" + type.getName() + "\" is not supported: " + e.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int getNativeSize(Class<?> cls) {
/* 1093 */     if (NativeMapped.class.isAssignableFrom(cls)) {
/* 1094 */       cls = NativeMappedConverter.getInstance(cls).nativeType();
/*      */     }
/*      */     
/* 1097 */     if (cls == boolean.class || cls == Boolean.class) return 4; 
/* 1098 */     if (cls == byte.class || cls == Byte.class) return 1; 
/* 1099 */     if (cls == short.class || cls == Short.class) return 2; 
/* 1100 */     if (cls == char.class || cls == Character.class) return WCHAR_SIZE; 
/* 1101 */     if (cls == int.class || cls == Integer.class) return 4; 
/* 1102 */     if (cls == long.class || cls == Long.class) return 8; 
/* 1103 */     if (cls == float.class || cls == Float.class) return 4; 
/* 1104 */     if (cls == double.class || cls == Double.class) return 8; 
/* 1105 */     if (Structure.class.isAssignableFrom(cls)) {
/* 1106 */       if (Structure.ByValue.class.isAssignableFrom(cls)) {
/* 1107 */         return Structure.size(cls);
/*      */       }
/* 1109 */       return POINTER_SIZE;
/*      */     } 
/* 1111 */     if (Pointer.class.isAssignableFrom(cls) || (Platform.HAS_BUFFERS && Buffers.isBuffer(cls)) || Callback.class.isAssignableFrom(cls) || String.class == cls || WString.class == cls)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 1116 */       return POINTER_SIZE;
/*      */     }
/* 1118 */     throw new IllegalArgumentException("Native size for type \"" + cls.getName() + "\" is unknown");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isSupportedNativeType(Class<?> cls) {
/* 1126 */     if (Structure.class.isAssignableFrom(cls)) {
/* 1127 */       return true;
/*      */     }
/*      */     try {
/* 1130 */       return (getNativeSize(cls) != 0);
/*      */     }
/* 1132 */     catch (IllegalArgumentException e) {
/* 1133 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setCallbackExceptionHandler(Callback.UncaughtExceptionHandler eh) {
/* 1142 */     callbackExceptionHandler = (eh == null) ? DEFAULT_HANDLER : eh;
/*      */   }
/*      */ 
/*      */   
/*      */   public static Callback.UncaughtExceptionHandler getCallbackExceptionHandler() {
/* 1147 */     return callbackExceptionHandler;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void register(String libName) {
/* 1156 */     register(findDirectMappedClass(getCallingClass()), libName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void register(NativeLibrary lib) {
/* 1165 */     register(findDirectMappedClass(getCallingClass()), lib);
/*      */   }
/*      */ 
/*      */   
/*      */   static Class findDirectMappedClass(Class cls) {
/* 1170 */     Method[] methods = cls.getDeclaredMethods();
/* 1171 */     for (int i = 0; i < methods.length; i++) {
/* 1172 */       if ((methods[i].getModifiers() & 0x100) != 0) {
/* 1173 */         return cls;
/*      */       }
/*      */     } 
/* 1176 */     int idx = cls.getName().lastIndexOf("$");
/* 1177 */     if (idx != -1) {
/* 1178 */       String name = cls.getName().substring(0, idx);
/*      */       try {
/* 1180 */         return findDirectMappedClass(Class.forName(name, true, cls.getClassLoader()));
/*      */       }
/* 1182 */       catch (ClassNotFoundException e) {}
/*      */     } 
/*      */     
/* 1185 */     throw new IllegalArgumentException("Can't determine class with native methods from the current context (" + cls + ")");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Class getCallingClass() {
/* 1192 */     Class[] context = (new SecurityManager() {
/*      */         public Class[] getClassContext() {
/* 1194 */           return super.getClassContext();
/*      */         }
/*      */       }).getClassContext();
/* 1197 */     if (context == null) {
/* 1198 */       throw new IllegalStateException("The SecurityManager implementation on this platform is broken; you must explicitly provide the class to register");
/*      */     }
/* 1200 */     if (context.length < 4) {
/* 1201 */       throw new IllegalStateException("This method must be called from the static initializer of a class");
/*      */     }
/* 1203 */     return context[3];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setCallbackThreadInitializer(Callback cb, CallbackThreadInitializer initializer) {
/* 1212 */     CallbackReference.setCallbackThreadInitializer(cb, initializer);
/*      */   }
/*      */ 
/*      */   
/* 1216 */   private static Map registeredClasses = new HashMap<Object, Object>();
/* 1217 */   private static Map registeredLibraries = new HashMap<Object, Object>();
/* 1218 */   private static Object unloader = new Object() {
/*      */       protected void finalize() {
/* 1220 */         synchronized (Native.registeredClasses) {
/* 1221 */           for (Iterator<Map.Entry> i = Native.registeredClasses.entrySet().iterator(); i.hasNext(); ) {
/* 1222 */             Map.Entry e = i.next();
/* 1223 */             Native.unregister((Class)e.getKey(), (long[])e.getValue());
/* 1224 */             i.remove();
/*      */           } 
/*      */         } 
/*      */       }
/*      */     };
/*      */   static final int CB_HAS_INITIALIZER = 1; private static final int CVT_UNSUPPORTED = -1; private static final int CVT_DEFAULT = 0; private static final int CVT_POINTER = 1; private static final int CVT_STRING = 2; private static final int CVT_STRUCTURE = 3; private static final int CVT_STRUCTURE_BYVAL = 4; private static final int CVT_BUFFER = 5; private static final int CVT_ARRAY_BYTE = 6; private static final int CVT_ARRAY_SHORT = 7; private static final int CVT_ARRAY_CHAR = 8; private static final int CVT_ARRAY_INT = 9; private static final int CVT_ARRAY_LONG = 10; private static final int CVT_ARRAY_FLOAT = 11; private static final int CVT_ARRAY_DOUBLE = 12; private static final int CVT_ARRAY_BOOLEAN = 13; private static final int CVT_BOOLEAN = 14; private static final int CVT_CALLBACK = 15; private static final int CVT_FLOAT = 16; private static final int CVT_NATIVE_MAPPED = 17; private static final int CVT_WSTRING = 18; private static final int CVT_INTEGER_TYPE = 19; private static final int CVT_POINTER_TYPE = 20;
/*      */   private static final int CVT_TYPE_MAPPER = 21;
/*      */   static final int CB_OPTION_DIRECT = 1;
/*      */   static final int CB_OPTION_IN_DLL = 2;
/*      */   
/*      */   public static void unregister() {
/* 1235 */     unregister(findDirectMappedClass(getCallingClass()));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void unregister(Class cls) {
/* 1243 */     synchronized (registeredClasses) {
/* 1244 */       if (registeredClasses.containsKey(cls)) {
/* 1245 */         unregister(cls, (long[])registeredClasses.get(cls));
/* 1246 */         registeredClasses.remove(cls);
/* 1247 */         registeredLibraries.remove(cls);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static String getSignature(Class<void> cls) {
/* 1256 */     if (cls.isArray()) {
/* 1257 */       return "[" + getSignature(cls.getComponentType());
/*      */     }
/* 1259 */     if (cls.isPrimitive()) {
/* 1260 */       if (cls == void.class) return "V"; 
/* 1261 */       if (cls == boolean.class) return "Z"; 
/* 1262 */       if (cls == byte.class) return "B"; 
/* 1263 */       if (cls == short.class) return "S"; 
/* 1264 */       if (cls == char.class) return "C"; 
/* 1265 */       if (cls == int.class) return "I"; 
/* 1266 */       if (cls == long.class) return "J"; 
/* 1267 */       if (cls == float.class) return "F"; 
/* 1268 */       if (cls == double.class) return "D"; 
/*      */     } 
/* 1270 */     return "L" + replace(".", "/", cls.getName()) + ";";
/*      */   }
/*      */ 
/*      */   
/*      */   static String replace(String s1, String s2, String str) {
/* 1275 */     StringBuilder buf = new StringBuilder();
/*      */     while (true) {
/* 1277 */       int idx = str.indexOf(s1);
/* 1278 */       if (idx == -1) {
/* 1279 */         buf.append(str);
/*      */         
/*      */         break;
/*      */       } 
/* 1283 */       buf.append(str.substring(0, idx));
/* 1284 */       buf.append(s2);
/* 1285 */       str = str.substring(idx + s1.length());
/*      */     } 
/*      */     
/* 1288 */     return buf.toString();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static int getConversion(Class<Boolean> type, TypeMapper mapper) {
/*      */     Class<boolean> clazz1;
/*      */     Class<void> clazz;
/* 1319 */     if (type == Boolean.class) { clazz1 = boolean.class; }
/* 1320 */     else { Class<byte> clazz2; if (clazz1 == Byte.class) { clazz2 = byte.class; }
/* 1321 */       else { Class<short> clazz3; if (clazz2 == Short.class) { clazz3 = short.class; }
/* 1322 */         else { Class<char> clazz4; if (clazz3 == Character.class) { clazz4 = char.class; }
/* 1323 */           else { Class<int> clazz5; if (clazz4 == Integer.class) { clazz5 = int.class; }
/* 1324 */             else { Class<long> clazz6; if (clazz5 == Long.class) { clazz6 = long.class; }
/* 1325 */               else { Class<float> clazz7; if (clazz6 == Float.class) { clazz7 = float.class; }
/* 1326 */                 else { Class<double> clazz8; if (clazz7 == Double.class) { clazz8 = double.class; }
/* 1327 */                   else if (clazz8 == Void.class) { clazz = void.class; }  }  }  }  }  }  }
/*      */        }
/* 1329 */      if (mapper != null && (mapper.getFromNativeConverter(clazz) != null || mapper.getToNativeConverter(clazz) != null))
/*      */     {
/*      */       
/* 1332 */       return 21;
/*      */     }
/*      */     
/* 1335 */     if (Pointer.class.isAssignableFrom(clazz)) {
/* 1336 */       return 1;
/*      */     }
/* 1338 */     if (String.class == clazz) {
/* 1339 */       return 2;
/*      */     }
/* 1341 */     if (WString.class.isAssignableFrom(clazz)) {
/* 1342 */       return 18;
/*      */     }
/* 1344 */     if (Platform.HAS_BUFFERS && Buffers.isBuffer(clazz)) {
/* 1345 */       return 5;
/*      */     }
/* 1347 */     if (Structure.class.isAssignableFrom(clazz)) {
/* 1348 */       if (Structure.ByValue.class.isAssignableFrom(clazz)) {
/* 1349 */         return 4;
/*      */       }
/* 1351 */       return 3;
/*      */     } 
/* 1353 */     if (clazz.isArray()) {
/* 1354 */       switch (clazz.getName().charAt(1)) { case 'Z':
/* 1355 */           return 13;
/* 1356 */         case 'B': return 6;
/* 1357 */         case 'S': return 7;
/* 1358 */         case 'C': return 8;
/* 1359 */         case 'I': return 9;
/* 1360 */         case 'J': return 10;
/* 1361 */         case 'F': return 11;
/* 1362 */         case 'D': return 12; }
/*      */ 
/*      */     
/*      */     }
/* 1366 */     if (clazz.isPrimitive()) {
/* 1367 */       return (clazz == boolean.class) ? 14 : 0;
/*      */     }
/* 1369 */     if (Callback.class.isAssignableFrom(clazz)) {
/* 1370 */       return 15;
/*      */     }
/* 1372 */     if (IntegerType.class.isAssignableFrom(clazz)) {
/* 1373 */       return 19;
/*      */     }
/* 1375 */     if (PointerType.class.isAssignableFrom(clazz)) {
/* 1376 */       return 20;
/*      */     }
/* 1378 */     if (NativeMapped.class.isAssignableFrom(clazz)) {
/* 1379 */       return 17;
/*      */     }
/* 1381 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void register(Class cls, String libName) {
/* 1394 */     Map<Object, Object> options = new HashMap<Object, Object>();
/* 1395 */     options.put("classloader", cls.getClassLoader());
/* 1396 */     register(cls, NativeLibrary.getInstance(libName, options));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void register(Class<?> cls, NativeLibrary lib) {
/* 1409 */     Method[] methods = cls.getDeclaredMethods();
/* 1410 */     List<Method> mlist = new ArrayList();
/* 1411 */     TypeMapper mapper = (TypeMapper)lib.getOptions().get("type-mapper");
/*      */ 
/*      */     
/* 1414 */     for (int i = 0; i < methods.length; i++) {
/* 1415 */       if ((methods[i].getModifiers() & 0x100) != 0) {
/* 1416 */         mlist.add(methods[i]);
/*      */       }
/*      */     } 
/* 1419 */     long[] handles = new long[mlist.size()];
/* 1420 */     for (int j = 0; j < handles.length; j++) {
/* 1421 */       long rtype, closure_rtype; Method method = mlist.get(j);
/* 1422 */       String sig = "(";
/* 1423 */       Class<?> rclass = method.getReturnType();
/*      */       
/* 1425 */       Class[] ptypes = method.getParameterTypes();
/* 1426 */       long[] atypes = new long[ptypes.length];
/* 1427 */       long[] closure_atypes = new long[ptypes.length];
/* 1428 */       int[] cvt = new int[ptypes.length];
/* 1429 */       ToNativeConverter[] toNative = new ToNativeConverter[ptypes.length];
/* 1430 */       FromNativeConverter fromNative = null;
/* 1431 */       int rcvt = getConversion(rclass, mapper);
/* 1432 */       boolean throwLastError = false;
/* 1433 */       switch (rcvt) {
/*      */         case -1:
/* 1435 */           throw new IllegalArgumentException(rclass + " is not a supported return type (in method " + method.getName() + " in " + cls + ")");
/*      */         case 21:
/* 1437 */           fromNative = mapper.getFromNativeConverter(rclass);
/* 1438 */           closure_rtype = (Structure.FFIType.get(rclass)).peer;
/* 1439 */           rtype = (Structure.FFIType.get(fromNative.nativeType())).peer;
/*      */           break;
/*      */         case 17:
/*      */         case 19:
/*      */         case 20:
/* 1444 */           closure_rtype = (Structure.FFIType.get(Pointer.class)).peer;
/* 1445 */           rtype = (Structure.FFIType.get(NativeMappedConverter.getInstance(rclass).nativeType())).peer;
/*      */           break;
/*      */         case 3:
/* 1448 */           closure_rtype = rtype = (Structure.FFIType.get(Pointer.class)).peer;
/*      */         
/*      */         case 4:
/* 1451 */           closure_rtype = (Structure.FFIType.get(Pointer.class)).peer;
/* 1452 */           rtype = (Structure.FFIType.get(rclass)).peer;
/*      */           break;
/*      */         default:
/* 1455 */           closure_rtype = rtype = (Structure.FFIType.get(rclass)).peer;
/*      */           break;
/*      */       } 
/* 1458 */       for (int t = 0; t < ptypes.length; t++) {
/* 1459 */         Class type = ptypes[t];
/* 1460 */         sig = sig + getSignature(type);
/* 1461 */         cvt[t] = getConversion(type, mapper);
/* 1462 */         if (cvt[t] == -1) {
/* 1463 */           throw new IllegalArgumentException(type + " is not a supported argument type (in method " + method.getName() + " in " + cls + ")");
/*      */         }
/* 1465 */         if (cvt[t] == 17 || cvt[t] == 19) {
/*      */           
/* 1467 */           type = NativeMappedConverter.getInstance(type).nativeType();
/*      */         }
/* 1469 */         else if (cvt[t] == 21) {
/* 1470 */           toNative[t] = mapper.getToNativeConverter(type);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1475 */         switch (cvt[t]) {
/*      */           case 4:
/*      */           case 17:
/*      */           case 19:
/*      */           case 20:
/* 1480 */             atypes[t] = (Structure.FFIType.get(type)).peer;
/* 1481 */             closure_atypes[t] = (Structure.FFIType.get(Pointer.class)).peer;
/*      */             break;
/*      */           case 21:
/* 1484 */             if (type.isPrimitive()) {
/* 1485 */               closure_atypes[t] = (Structure.FFIType.get(type)).peer;
/*      */             } else {
/* 1487 */               closure_atypes[t] = (Structure.FFIType.get(Pointer.class)).peer;
/* 1488 */             }  atypes[t] = (Structure.FFIType.get(toNative[t].nativeType())).peer;
/*      */             break;
/*      */           case 0:
/* 1491 */             atypes[t] = (Structure.FFIType.get(type)).peer; closure_atypes[t] = (Structure.FFIType.get(type)).peer;
/*      */           
/*      */           default:
/* 1494 */             atypes[t] = (Structure.FFIType.get(Pointer.class)).peer; closure_atypes[t] = (Structure.FFIType.get(Pointer.class)).peer;
/*      */             break;
/*      */         } 
/*      */       } 
/* 1498 */       sig = sig + ")";
/* 1499 */       sig = sig + getSignature(rclass);
/*      */       
/* 1501 */       Class[] etypes = method.getExceptionTypes();
/* 1502 */       for (int e = 0; e < etypes.length; e++) {
/* 1503 */         if (LastErrorException.class.isAssignableFrom(etypes[e])) {
/* 1504 */           throwLastError = true;
/*      */           
/*      */           break;
/*      */         } 
/*      */       } 
/* 1509 */       Function f = lib.getFunction(method.getName(), method);
/*      */       try {
/* 1511 */         handles[j] = registerMethod(cls, method.getName(), sig, cvt, closure_atypes, atypes, rcvt, closure_rtype, rtype, rclass, f.peer, f.getCallingConvention(), throwLastError, toNative, fromNative, f.encoding);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 1521 */       catch (NoSuchMethodError noSuchMethodError) {
/* 1522 */         throw new UnsatisfiedLinkError("No method " + method.getName() + " with signature " + sig + " in " + cls);
/*      */       } 
/*      */     } 
/* 1525 */     synchronized (registeredClasses) {
/* 1526 */       registeredClasses.put(cls, handles);
/* 1527 */       registeredLibraries.put(cls, lib);
/*      */     } 
/* 1529 */     cacheOptions(cls, lib.getOptions(), null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static void cacheOptions(Class<?> cls, Map<?, ?> libOptions, Object proxy) {
/* 1536 */     libOptions = new HashMap<Object, Object>(libOptions);
/* 1537 */     synchronized (libraries) {
/* 1538 */       options.put(cls, libOptions);
/* 1539 */       if (proxy != null) {
/* 1540 */         libraries.put(cls, new WeakReference(proxy));
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1546 */       if (!cls.isInterface() && Library.class.isAssignableFrom(cls)) {
/*      */         
/* 1548 */         Class[] ifaces = cls.getInterfaces();
/* 1549 */         for (int i = 0; i < ifaces.length; i++) {
/* 1550 */           if (Library.class.isAssignableFrom(ifaces[i])) {
/* 1551 */             cacheOptions(ifaces[i], libOptions, proxy);
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static NativeMapped fromNative(Class cls, Object value) {
/* 1581 */     return (NativeMapped)NativeMappedConverter.getInstance(cls).fromNative(value, new FromNativeContext(cls));
/*      */   }
/*      */   
/*      */   private static Class nativeType(Class cls) {
/* 1585 */     return NativeMappedConverter.getInstance(cls).nativeType();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private static Object toNative(ToNativeConverter cvt, Object o) {
/* 1591 */     return cvt.toNative(o, new ToNativeContext());
/*      */   }
/*      */ 
/*      */   
/*      */   private static Object fromNative(FromNativeConverter cvt, Object o, Class cls) {
/* 1596 */     return cvt.fromNative(o, new FromNativeContext(cls));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void main(String[] args) {
/* 1615 */     String DEFAULT_TITLE = "Java Native Access (JNA)";
/* 1616 */     String DEFAULT_VERSION = "4.1.0";
/* 1617 */     String DEFAULT_BUILD = "4.1.0 (package information missing)";
/* 1618 */     Package pkg = Native.class.getPackage();
/* 1619 */     String title = (pkg != null) ? pkg.getSpecificationTitle() : "Java Native Access (JNA)";
/*      */     
/* 1621 */     if (title == null) title = "Java Native Access (JNA)"; 
/* 1622 */     String version = (pkg != null) ? pkg.getSpecificationVersion() : "4.1.0";
/*      */     
/* 1624 */     if (version == null) version = "4.1.0"; 
/* 1625 */     title = title + " API Version " + version;
/* 1626 */     System.out.println(title);
/* 1627 */     version = (pkg != null) ? pkg.getImplementationVersion() : "4.1.0 (package information missing)";
/*      */     
/* 1629 */     if (version == null) version = "4.1.0 (package information missing)"; 
/* 1630 */     System.out.println("Version: " + version);
/* 1631 */     System.out.println(" Native: " + getNativeVersion() + " (" + getAPIChecksum() + ")");
/*      */     
/* 1633 */     System.out.println(" Prefix: " + Platform.RESOURCE_PREFIX);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Structure invokeStructure(long fp, int callFlags, Object[] args, Structure s) {
/* 1741 */     invokeStructure(fp, callFlags, args, (s.getPointer()).peer, (s.getTypeInfo()).peer);
/*      */     
/* 1743 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static long open(String name) {
/* 1759 */     return open(name, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static Pointer getPointer(long addr) {
/* 1817 */     long peer = _getPointer(addr);
/* 1818 */     return (peer == 0L) ? null : new Pointer(peer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String getString(long addr) {
/* 1826 */     return getString(addr, getDefaultStringEncoding());
/*      */   }
/*      */   
/*      */   static String getString(long addr, String encoding) {
/* 1830 */     byte[] data = getStringBytes(addr);
/* 1831 */     if (encoding != null) {
/*      */       try {
/* 1833 */         return new String(data, encoding);
/*      */       }
/* 1835 */       catch (UnsupportedEncodingException e) {}
/*      */     }
/*      */     
/* 1838 */     return new String(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void detach(boolean detach) {
/* 1900 */     Thread thread = Thread.currentThread();
/* 1901 */     if (detach) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1908 */       nativeThreads.remove(thread);
/* 1909 */       Pointer p = nativeThreadTerminationFlag.get();
/* 1910 */       setDetachState(true, 0L);
/*      */     
/*      */     }
/* 1913 */     else if (!nativeThreads.containsKey(thread)) {
/* 1914 */       Pointer p = nativeThreadTerminationFlag.get();
/* 1915 */       nativeThreads.put(thread, p);
/* 1916 */       setDetachState(false, p.peer);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   static Pointer getTerminationFlag(Thread t) {
/* 1922 */     return (Pointer)nativeThreads.get(t);
/*      */   }
/*      */   
/* 1925 */   private static Map nativeThreads = Collections.synchronizedMap(new WeakHashMap<Object, Object>());
/*      */   
/* 1927 */   private static ThreadLocal nativeThreadTerminationFlag = new ThreadLocal()
/*      */     {
/*      */       protected Object initialValue() {
/* 1930 */         Memory m = new Memory(4L);
/* 1931 */         m.clear();
/* 1932 */         return m;
/*      */       }
/*      */     }; private static native void initIDs(); public static synchronized native void setProtected(boolean paramBoolean); public static synchronized native boolean isProtected(); static native long getWindowHandle0(Component paramComponent); private static native long _getDirectBufferPointer(Buffer paramBuffer); private static native int sizeof(int paramInt); private static native String getNativeVersion(); private static native String getAPIChecksum(); public static native int getLastError(); public static native void setLastError(int paramInt); private static native void unregister(Class paramClass, long[] paramArrayOflong); private static native long registerMethod(Class paramClass1, String paramString1, String paramString2, int[] paramArrayOfint, long[] paramArrayOflong1, long[] paramArrayOflong2, int paramInt1, long paramLong1, long paramLong2, Class paramClass2, long paramLong3, int paramInt2, boolean paramBoolean, ToNativeConverter[] paramArrayOfToNativeConverter, FromNativeConverter paramFromNativeConverter, String paramString3); public static native long ffi_prep_cif(int paramInt1, int paramInt2, long paramLong1, long paramLong2); public static native void ffi_call(long paramLong1, long paramLong2, long paramLong3, long paramLong4); public static native long ffi_prep_closure(long paramLong, ffi_callback paramffi_callback); public static native void ffi_free_closure(long paramLong); static native int initialize_ffi_type(long paramLong); static synchronized native void freeNativeCallback(long paramLong); static synchronized native long createNativeCallback(Callback paramCallback, Method paramMethod, Class[] paramArrayOfClass, Class paramClass, int paramInt1, int paramInt2, String paramString); static native int invokeInt(long paramLong, int paramInt, Object[] paramArrayOfObject); static native long invokeLong(long paramLong, int paramInt, Object[] paramArrayOfObject); static native void invokeVoid(long paramLong, int paramInt, Object[] paramArrayOfObject); static native float invokeFloat(long paramLong, int paramInt, Object[] paramArrayOfObject); static native double invokeDouble(long paramLong, int paramInt, Object[] paramArrayOfObject); static native long invokePointer(long paramLong, int paramInt, Object[] paramArrayOfObject); private static native void invokeStructure(long paramLong1, int paramInt, Object[] paramArrayOfObject, long paramLong2, long paramLong3); static native Object invokeObject(long paramLong, int paramInt, Object[] paramArrayOfObject); static native long open(String paramString, int paramInt); static native void close(long paramLong); static native long findSymbol(long paramLong, String paramString); static native long indexOf(long paramLong, byte paramByte); static native void read(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2); static native void read(long paramLong, short[] paramArrayOfshort, int paramInt1, int paramInt2); static native void read(long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2); static native void read(long paramLong, int[] paramArrayOfint, int paramInt1, int paramInt2); static native void read(long paramLong, long[] paramArrayOflong, int paramInt1, int paramInt2); static native void read(long paramLong, float[] paramArrayOffloat, int paramInt1, int paramInt2); static native void read(long paramLong, double[] paramArrayOfdouble, int paramInt1, int paramInt2); static native void write(long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2); static native void write(long paramLong, short[] paramArrayOfshort, int paramInt1, int paramInt2); static native void write(long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2); static native void write(long paramLong, int[] paramArrayOfint, int paramInt1, int paramInt2); static native void write(long paramLong, long[] paramArrayOflong, int paramInt1, int paramInt2); static native void write(long paramLong, float[] paramArrayOffloat, int paramInt1, int paramInt2); static native void write(long paramLong, double[] paramArrayOfdouble, int paramInt1, int paramInt2); static native byte getByte(long paramLong); static native char getChar(long paramLong); static native short getShort(long paramLong); static native int getInt(long paramLong); static native long getLong(long paramLong); static native float getFloat(long paramLong); static native double getDouble(long paramLong); private static native long _getPointer(long paramLong); static native String getWideString(long paramLong); static native byte[] getStringBytes(long paramLong); static native void setMemory(long paramLong1, long paramLong2, byte paramByte); static native void setByte(long paramLong, byte paramByte); static native void setShort(long paramLong, short paramShort); static native void setChar(long paramLong, char paramChar); static native void setInt(long paramLong, int paramInt); static native void setLong(long paramLong1, long paramLong2); static native void setFloat(long paramLong, float paramFloat); static native void setDouble(long paramLong, double paramDouble); static native void setPointer(long paramLong1, long paramLong2); static native void setWideString(long paramLong, String paramString); public static native long malloc(long paramLong); public static native void free(long paramLong);
/*      */   public static native ByteBuffer getDirectByteBuffer(long paramLong1, long paramLong2);
/*      */   private static native void setDetachState(boolean paramBoolean, long paramLong);
/*      */   public static interface ffi_callback {
/*      */     void invoke(long param1Long1, long param1Long2, long param1Long3); }
/*      */   private static class Buffers { static boolean isBuffer(Class<?> cls) {
/* 1940 */       return Buffer.class.isAssignableFrom(cls);
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static class AWT
/*      */   {
/*      */     static long getWindowID(Window w) throws HeadlessException {
/* 1949 */       return getComponentID(w);
/*      */     }
/*      */ 
/*      */     
/*      */     static long getComponentID(Object o) throws HeadlessException {
/* 1954 */       if (GraphicsEnvironment.isHeadless()) {
/* 1955 */         throw new HeadlessException("No native windows when headless");
/*      */       }
/* 1957 */       Component c = (Component)o;
/* 1958 */       if (c.isLightweight()) {
/* 1959 */         throw new IllegalArgumentException("Component must be heavyweight");
/*      */       }
/* 1961 */       if (!c.isDisplayable()) {
/* 1962 */         throw new IllegalStateException("Component must be displayable");
/*      */       }
/* 1964 */       if (Platform.isX11() && System.getProperty("java.version").startsWith("1.4"))
/*      */       {
/* 1966 */         if (!c.isVisible()) {
/* 1967 */           throw new IllegalStateException("Component must be visible");
/*      */         }
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 1973 */       return Native.getWindowHandle0(c);
/*      */     }
/*      */   }
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/Native.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */