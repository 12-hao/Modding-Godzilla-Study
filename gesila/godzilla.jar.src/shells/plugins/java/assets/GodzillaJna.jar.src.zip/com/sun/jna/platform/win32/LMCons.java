package com.sun.jna.platform.win32;

import com.sun.jna.win32.StdCallLibrary;

public interface LMCons extends StdCallLibrary {
  public static final int NETBIOS_NAME_LEN = 16;
  
  public static final int MAX_PREFERRED_LENGTH = -1;
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/LMCons.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */