/*     */ package com.sun.jna.platform.win32;
/*     */ 
/*     */ import com.sun.jna.ptr.PointerByReference;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Crypt32Util
/*     */ {
/*     */   public static byte[] cryptProtectData(byte[] data) {
/*  33 */     return cryptProtectData(data, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] cryptProtectData(byte[] data, int flags) {
/*  46 */     return cryptProtectData(data, null, flags, "", null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] cryptProtectData(byte[] data, byte[] entropy, int flags, String description, WinCrypt.CRYPTPROTECT_PROMPTSTRUCT prompt) {
/*  66 */     WinCrypt.DATA_BLOB pDataIn = new WinCrypt.DATA_BLOB(data);
/*  67 */     WinCrypt.DATA_BLOB pDataProtected = new WinCrypt.DATA_BLOB();
/*  68 */     WinCrypt.DATA_BLOB pEntropy = (entropy == null) ? null : new WinCrypt.DATA_BLOB(entropy);
/*     */     try {
/*  70 */       if (!Crypt32.INSTANCE.CryptProtectData(pDataIn, description, pEntropy, null, prompt, flags, pDataProtected))
/*     */       {
/*  72 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */       }
/*  74 */       return pDataProtected.getData();
/*     */     } finally {
/*  76 */       if (pDataProtected.pbData != null) {
/*  77 */         Kernel32.INSTANCE.LocalFree(pDataProtected.pbData);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] cryptUnprotectData(byte[] data) {
/*  90 */     return cryptUnprotectData(data, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] cryptUnprotectData(byte[] data, int flags) {
/* 103 */     return cryptUnprotectData(data, null, flags, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static byte[] cryptUnprotectData(byte[] data, byte[] entropy, int flags, WinCrypt.CRYPTPROTECT_PROMPTSTRUCT prompt) {
/* 121 */     WinCrypt.DATA_BLOB pDataIn = new WinCrypt.DATA_BLOB(data);
/* 122 */     WinCrypt.DATA_BLOB pDataUnprotected = new WinCrypt.DATA_BLOB();
/* 123 */     WinCrypt.DATA_BLOB pEntropy = (entropy == null) ? null : new WinCrypt.DATA_BLOB(entropy);
/* 124 */     PointerByReference pDescription = new PointerByReference();
/*     */     try {
/* 126 */       if (!Crypt32.INSTANCE.CryptUnprotectData(pDataIn, pDescription, pEntropy, null, prompt, flags, pDataUnprotected))
/*     */       {
/* 128 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*     */       }
/* 130 */       return pDataUnprotected.getData();
/*     */     } finally {
/* 132 */       if (pDataUnprotected.pbData != null) {
/* 133 */         Kernel32.INSTANCE.LocalFree(pDataUnprotected.pbData);
/*     */       }
/* 135 */       if (pDescription.getValue() != null)
/* 136 */         Kernel32.INSTANCE.LocalFree(pDescription.getValue()); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/Crypt32Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */