/*      */ package com.sun.jna.platform.win32;
/*      */ 
/*      */ import com.sun.jna.Memory;
/*      */ import com.sun.jna.Native;
/*      */ import com.sun.jna.Pointer;
/*      */ import com.sun.jna.WString;
/*      */ import com.sun.jna.ptr.IntByReference;
/*      */ import com.sun.jna.ptr.LongByReference;
/*      */ import com.sun.jna.ptr.PointerByReference;
/*      */ import java.io.File;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class Advapi32Util
/*      */ {
/*      */   public static class Account
/*      */   {
/*      */     public String name;
/*      */     public String domain;
/*      */     public byte[] sid;
/*      */     public String sidString;
/*      */     public int accountType;
/*      */     public String fqn;
/*      */   }
/*      */   
/*      */   public static String getUserName() {
/*   98 */     char[] buffer = new char[128];
/*   99 */     IntByReference len = new IntByReference(buffer.length);
/*  100 */     boolean result = Advapi32.INSTANCE.GetUserNameW(buffer, len);
/*      */     
/*  102 */     if (!result) {
/*  103 */       switch (Kernel32.INSTANCE.GetLastError()) {
/*      */         case 122:
/*  105 */           buffer = new char[len.getValue()];
/*      */           break;
/*      */         
/*      */         default:
/*  109 */           throw new Win32Exception(Native.getLastError());
/*      */       } 
/*      */       
/*  112 */       result = Advapi32.INSTANCE.GetUserNameW(buffer, len);
/*      */     } 
/*      */     
/*  115 */     if (!result) {
/*  116 */       throw new Win32Exception(Native.getLastError());
/*      */     }
/*      */     
/*  119 */     return Native.toString(buffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Account getAccountByName(String accountName) {
/*  131 */     return getAccountByName(null, accountName);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Account getAccountByName(String systemName, String accountName) {
/*  144 */     IntByReference pSid = new IntByReference(0);
/*  145 */     IntByReference cchDomainName = new IntByReference(0);
/*  146 */     PointerByReference peUse = new PointerByReference();
/*      */     
/*  148 */     if (Advapi32.INSTANCE.LookupAccountName(systemName, accountName, null, pSid, null, cchDomainName, peUse))
/*      */     {
/*  150 */       throw new RuntimeException("LookupAccountNameW was expected to fail with ERROR_INSUFFICIENT_BUFFER");
/*      */     }
/*      */ 
/*      */     
/*  154 */     int rc = Kernel32.INSTANCE.GetLastError();
/*  155 */     if (pSid.getValue() == 0 || rc != 122) {
/*  156 */       throw new Win32Exception(rc);
/*      */     }
/*      */     
/*  159 */     Memory sidMemory = new Memory(pSid.getValue());
/*  160 */     WinNT.PSID result = new WinNT.PSID((Pointer)sidMemory);
/*  161 */     char[] referencedDomainName = new char[cchDomainName.getValue() + 1];
/*      */     
/*  163 */     if (!Advapi32.INSTANCE.LookupAccountName(systemName, accountName, result, pSid, referencedDomainName, cchDomainName, peUse))
/*      */     {
/*  165 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */     
/*  168 */     Account account = new Account();
/*  169 */     account.accountType = peUse.getPointer().getInt(0L);
/*  170 */     account.name = accountName;
/*      */     
/*  172 */     String[] accountNamePartsBs = accountName.split("\\\\", 2);
/*  173 */     String[] accountNamePartsAt = accountName.split("@", 2);
/*      */     
/*  175 */     if (accountNamePartsBs.length == 2) {
/*  176 */       account.name = accountNamePartsBs[1];
/*  177 */     } else if (accountNamePartsAt.length == 2) {
/*  178 */       account.name = accountNamePartsAt[0];
/*      */     } else {
/*  180 */       account.name = accountName;
/*      */     } 
/*      */     
/*  183 */     if (cchDomainName.getValue() > 0) {
/*  184 */       account.domain = Native.toString(referencedDomainName);
/*  185 */       account.fqn = account.domain + "\\" + account.name;
/*      */     } else {
/*  187 */       account.fqn = account.name;
/*      */     } 
/*      */     
/*  190 */     account.sid = result.getBytes();
/*  191 */     account.sidString = convertSidToStringSid(new WinNT.PSID(account.sid));
/*  192 */     return account;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Account getAccountBySid(WinNT.PSID sid) {
/*  203 */     return getAccountBySid((String)null, sid);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Account getAccountBySid(String systemName, WinNT.PSID sid) {
/*  216 */     IntByReference cchName = new IntByReference();
/*  217 */     IntByReference cchDomainName = new IntByReference();
/*  218 */     PointerByReference peUse = new PointerByReference();
/*      */     
/*  220 */     if (Advapi32.INSTANCE.LookupAccountSid(null, sid, null, cchName, null, cchDomainName, peUse))
/*      */     {
/*  222 */       throw new RuntimeException("LookupAccountSidW was expected to fail with ERROR_INSUFFICIENT_BUFFER");
/*      */     }
/*      */ 
/*      */     
/*  226 */     int rc = Kernel32.INSTANCE.GetLastError();
/*  227 */     if (cchName.getValue() == 0 || rc != 122)
/*      */     {
/*  229 */       throw new Win32Exception(rc);
/*      */     }
/*      */     
/*  232 */     char[] domainName = new char[cchDomainName.getValue()];
/*  233 */     char[] name = new char[cchName.getValue()];
/*      */     
/*  235 */     if (!Advapi32.INSTANCE.LookupAccountSid(null, sid, name, cchName, domainName, cchDomainName, peUse))
/*      */     {
/*  237 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*      */     
/*  240 */     Account account = new Account();
/*  241 */     account.accountType = peUse.getPointer().getInt(0L);
/*  242 */     account.name = Native.toString(name);
/*      */     
/*  244 */     if (cchDomainName.getValue() > 0) {
/*  245 */       account.domain = Native.toString(domainName);
/*  246 */       account.fqn = account.domain + "\\" + account.name;
/*      */     } else {
/*  248 */       account.fqn = account.name;
/*      */     } 
/*      */     
/*  251 */     account.sid = sid.getBytes();
/*  252 */     account.sidString = convertSidToStringSid(sid);
/*  253 */     return account;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String convertSidToStringSid(WinNT.PSID sid) {
/*  265 */     PointerByReference stringSid = new PointerByReference();
/*  266 */     if (!Advapi32.INSTANCE.ConvertSidToStringSid(sid, stringSid)) {
/*  267 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*  269 */     String result = stringSid.getValue().getWideString(0L);
/*  270 */     Kernel32.INSTANCE.LocalFree(stringSid.getValue());
/*  271 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] convertStringSidToSid(String sidString) {
/*  283 */     WinNT.PSIDByReference pSID = new WinNT.PSIDByReference();
/*  284 */     if (!Advapi32.INSTANCE.ConvertStringSidToSid(sidString, pSID)) {
/*  285 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*  287 */     return pSID.getValue().getBytes();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWellKnownSid(String sidString, int wellKnownSidType) {
/*  301 */     WinNT.PSIDByReference pSID = new WinNT.PSIDByReference();
/*  302 */     if (!Advapi32.INSTANCE.ConvertStringSidToSid(sidString, pSID)) {
/*  303 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*  305 */     return Advapi32.INSTANCE.IsWellKnownSid(pSID.getValue(), wellKnownSidType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean isWellKnownSid(byte[] sidBytes, int wellKnownSidType) {
/*  320 */     WinNT.PSID pSID = new WinNT.PSID(sidBytes);
/*  321 */     return Advapi32.INSTANCE.IsWellKnownSid(pSID, wellKnownSidType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Account getAccountBySid(String sidString) {
/*  332 */     return getAccountBySid((String)null, sidString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Account getAccountBySid(String systemName, String sidString) {
/*  345 */     return getAccountBySid(systemName, new WinNT.PSID(convertStringSidToSid(sidString)));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Account[] getTokenGroups(WinNT.HANDLE hToken) {
/*  359 */     IntByReference tokenInformationLength = new IntByReference();
/*  360 */     if (Advapi32.INSTANCE.GetTokenInformation(hToken, 2, null, 0, tokenInformationLength))
/*      */     {
/*      */       
/*  363 */       throw new RuntimeException("Expected GetTokenInformation to fail with ERROR_INSUFFICIENT_BUFFER");
/*      */     }
/*      */     
/*  366 */     int rc = Kernel32.INSTANCE.GetLastError();
/*  367 */     if (rc != 122) {
/*  368 */       throw new Win32Exception(rc);
/*      */     }
/*      */     
/*  371 */     WinNT.TOKEN_GROUPS groups = new WinNT.TOKEN_GROUPS(tokenInformationLength.getValue());
/*      */     
/*  373 */     if (!Advapi32.INSTANCE.GetTokenInformation(hToken, 2, groups, tokenInformationLength.getValue(), tokenInformationLength))
/*      */     {
/*      */       
/*  376 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*  378 */     ArrayList<Account> userGroups = new ArrayList<Account>();
/*      */     
/*  380 */     for (WinNT.SID_AND_ATTRIBUTES sidAndAttribute : groups.getGroups()) {
/*  381 */       Account group = null;
/*      */       try {
/*  383 */         group = getAccountBySid(sidAndAttribute.Sid);
/*  384 */       } catch (Exception e) {
/*  385 */         group = new Account();
/*  386 */         group.sid = sidAndAttribute.Sid.getBytes();
/*  387 */         group.sidString = convertSidToStringSid(sidAndAttribute.Sid);
/*      */         
/*  389 */         group.name = group.sidString;
/*  390 */         group.fqn = group.sidString;
/*  391 */         group.accountType = 2;
/*      */       } 
/*  393 */       userGroups.add(group);
/*      */     } 
/*  395 */     return userGroups.<Account>toArray(new Account[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Account getTokenAccount(WinNT.HANDLE hToken) {
/*  408 */     IntByReference tokenInformationLength = new IntByReference();
/*  409 */     if (Advapi32.INSTANCE.GetTokenInformation(hToken, 1, null, 0, tokenInformationLength))
/*      */     {
/*      */       
/*  412 */       throw new RuntimeException("Expected GetTokenInformation to fail with ERROR_INSUFFICIENT_BUFFER");
/*      */     }
/*      */     
/*  415 */     int rc = Kernel32.INSTANCE.GetLastError();
/*  416 */     if (rc != 122) {
/*  417 */       throw new Win32Exception(rc);
/*      */     }
/*      */     
/*  420 */     WinNT.TOKEN_USER user = new WinNT.TOKEN_USER(tokenInformationLength.getValue());
/*      */     
/*  422 */     if (!Advapi32.INSTANCE.GetTokenInformation(hToken, 1, user, tokenInformationLength.getValue(), tokenInformationLength))
/*      */     {
/*      */       
/*  425 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     }
/*  427 */     return getAccountBySid(user.User.Sid);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Account[] getCurrentUserGroups() {
/*  436 */     WinNT.HANDLEByReference phToken = new WinNT.HANDLEByReference();
/*      */     
/*      */     try {
/*  439 */       WinNT.HANDLE threadHandle = Kernel32.INSTANCE.GetCurrentThread();
/*  440 */       if (!Advapi32.INSTANCE.OpenThreadToken(threadHandle, 10, true, phToken)) {
/*      */         
/*  442 */         if (1008 != Kernel32.INSTANCE.GetLastError())
/*      */         {
/*  444 */           throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */         }
/*  446 */         WinNT.HANDLE processHandle = Kernel32.INSTANCE.GetCurrentProcess();
/*  447 */         if (!Advapi32.INSTANCE.OpenProcessToken(processHandle, 10, phToken))
/*      */         {
/*  449 */           throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */         }
/*      */       } 
/*  452 */       return getTokenGroups(phToken.getValue());
/*      */     } finally {
/*  454 */       if (phToken.getValue() != WinBase.INVALID_HANDLE_VALUE && 
/*  455 */         !Kernel32.INSTANCE.CloseHandle(phToken.getValue())) {
/*  456 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean registryKeyExists(WinReg.HKEY root, String key) {
/*  472 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/*  473 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, key, 0, 131097, phkKey);
/*      */     
/*  475 */     switch (rc) {
/*      */       case 0:
/*  477 */         Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/*  478 */         return true;
/*      */       case 2:
/*  480 */         return false;
/*      */     } 
/*  482 */     throw new Win32Exception(rc);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean registryValueExists(WinReg.HKEY root, String key, String value) {
/*  499 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/*  500 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, key, 0, 131097, phkKey);
/*      */     
/*      */     try { boolean bool1, bool2;
/*  503 */       switch (rc) {
/*      */         case 0:
/*      */           break;
/*      */         case 2:
/*  507 */           return false;
/*      */         default:
/*  509 */           throw new Win32Exception(rc);
/*      */       } 
/*  511 */       IntByReference lpcbData = new IntByReference();
/*  512 */       IntByReference lpType = new IntByReference();
/*  513 */       rc = Advapi32.INSTANCE.RegQueryValueEx(phkKey.getValue(), value, 0, lpType, (char[])null, lpcbData);
/*      */       
/*  515 */       switch (rc)
/*      */       { case 0:
/*      */         case 122:
/*      */         case 234:
/*  519 */           bool2 = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  529 */           return bool2;case 2: bool2 = false; return bool2; }  throw new Win32Exception(rc); } finally { if (phkKey.getValue() != WinBase.INVALID_HANDLE_VALUE) { rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue()); if (rc != 0) throw new Win32Exception(rc);
/*      */          }
/*      */        }
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String registryGetStringValue(WinReg.HKEY root, String key, String value) {
/*  548 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/*  549 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, key, 0, 131097, phkKey);
/*      */     
/*  551 */     if (rc != 0) {
/*  552 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/*  555 */       return registryGetStringValue(phkKey.getValue(), value);
/*      */     } finally {
/*  557 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/*  558 */       if (rc != 0) {
/*  559 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String registryGetStringValue(WinReg.HKEY hKey, String value) {
/*  574 */     IntByReference lpcbData = new IntByReference();
/*  575 */     IntByReference lpType = new IntByReference();
/*  576 */     int rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, (char[])null, lpcbData);
/*      */     
/*  578 */     if (rc != 0 && rc != 122)
/*      */     {
/*  580 */       throw new Win32Exception(rc);
/*      */     }
/*  582 */     if (lpType.getValue() != 1 && lpType.getValue() != 2)
/*      */     {
/*  584 */       throw new RuntimeException("Unexpected registry type " + lpType.getValue() + ", expected REG_SZ or REG_EXPAND_SZ");
/*      */     }
/*      */ 
/*      */     
/*  588 */     char[] data = new char[lpcbData.getValue()];
/*  589 */     rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, data, lpcbData);
/*      */     
/*  591 */     if (rc != 0 && rc != 122)
/*      */     {
/*  593 */       throw new Win32Exception(rc);
/*      */     }
/*  595 */     return Native.toString(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String registryGetExpandableStringValue(WinReg.HKEY root, String key, String value) {
/*  611 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/*  612 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, key, 0, 131097, phkKey);
/*      */     
/*  614 */     if (rc != 0) {
/*  615 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/*  618 */       return registryGetExpandableStringValue(phkKey.getValue(), value);
/*      */     } finally {
/*  620 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/*  621 */       if (rc != 0) {
/*  622 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String registryGetExpandableStringValue(WinReg.HKEY hKey, String value) {
/*  637 */     IntByReference lpcbData = new IntByReference();
/*  638 */     IntByReference lpType = new IntByReference();
/*  639 */     int rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, (char[])null, lpcbData);
/*      */     
/*  641 */     if (rc != 0 && rc != 122)
/*      */     {
/*  643 */       throw new Win32Exception(rc);
/*      */     }
/*  645 */     if (lpType.getValue() != 2) {
/*  646 */       throw new RuntimeException("Unexpected registry type " + lpType.getValue() + ", expected REG_SZ");
/*      */     }
/*      */     
/*  649 */     char[] data = new char[lpcbData.getValue()];
/*  650 */     rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, data, lpcbData);
/*      */     
/*  652 */     if (rc != 0 && rc != 122)
/*      */     {
/*  654 */       throw new Win32Exception(rc);
/*      */     }
/*  656 */     return Native.toString(data);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] registryGetStringArray(WinReg.HKEY root, String key, String value) {
/*  672 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/*  673 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, key, 0, 131097, phkKey);
/*      */     
/*  675 */     if (rc != 0) {
/*  676 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/*  679 */       return registryGetStringArray(phkKey.getValue(), value);
/*      */     } finally {
/*  681 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/*  682 */       if (rc != 0) {
/*  683 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] registryGetStringArray(WinReg.HKEY hKey, String value) {
/*  698 */     IntByReference lpcbData = new IntByReference();
/*  699 */     IntByReference lpType = new IntByReference();
/*  700 */     int rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, (char[])null, lpcbData);
/*      */     
/*  702 */     if (rc != 0 && rc != 122)
/*      */     {
/*  704 */       throw new Win32Exception(rc);
/*      */     }
/*  706 */     if (lpType.getValue() != 7) {
/*  707 */       throw new RuntimeException("Unexpected registry type " + lpType.getValue() + ", expected REG_SZ");
/*      */     }
/*      */     
/*  710 */     Memory data = new Memory(lpcbData.getValue());
/*  711 */     rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, (Pointer)data, lpcbData);
/*      */     
/*  713 */     if (rc != 0 && rc != 122)
/*      */     {
/*  715 */       throw new Win32Exception(rc);
/*      */     }
/*  717 */     ArrayList<String> result = new ArrayList<String>();
/*  718 */     int offset = 0;
/*  719 */     while (offset < data.size()) {
/*  720 */       String s = data.getWideString(offset);
/*  721 */       offset += s.length() * Native.WCHAR_SIZE;
/*  722 */       offset += Native.WCHAR_SIZE;
/*  723 */       if (s.length() == 0 && offset == data.size()) {
/*      */         continue;
/*      */       }
/*  726 */       result.add(s);
/*      */     } 
/*      */     
/*  729 */     return result.<String>toArray(new String[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] registryGetBinaryValue(WinReg.HKEY root, String key, String value) {
/*  745 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/*  746 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, key, 0, 131097, phkKey);
/*      */     
/*  748 */     if (rc != 0) {
/*  749 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/*  752 */       return registryGetBinaryValue(phkKey.getValue(), value);
/*      */     } finally {
/*  754 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/*  755 */       if (rc != 0) {
/*  756 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static byte[] registryGetBinaryValue(WinReg.HKEY hKey, String value) {
/*  771 */     IntByReference lpcbData = new IntByReference();
/*  772 */     IntByReference lpType = new IntByReference();
/*  773 */     int rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, (char[])null, lpcbData);
/*      */     
/*  775 */     if (rc != 0 && rc != 122)
/*      */     {
/*  777 */       throw new Win32Exception(rc);
/*      */     }
/*  779 */     if (lpType.getValue() != 3) {
/*  780 */       throw new RuntimeException("Unexpected registry type " + lpType.getValue() + ", expected REG_BINARY");
/*      */     }
/*      */     
/*  783 */     byte[] data = new byte[lpcbData.getValue()];
/*  784 */     rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, data, lpcbData);
/*      */     
/*  786 */     if (rc != 0 && rc != 122)
/*      */     {
/*  788 */       throw new Win32Exception(rc);
/*      */     }
/*  790 */     return data;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int registryGetIntValue(WinReg.HKEY root, String key, String value) {
/*  805 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/*  806 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, key, 0, 131097, phkKey);
/*      */     
/*  808 */     if (rc != 0) {
/*  809 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/*  812 */       return registryGetIntValue(phkKey.getValue(), value);
/*      */     } finally {
/*  814 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/*  815 */       if (rc != 0) {
/*  816 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static int registryGetIntValue(WinReg.HKEY hKey, String value) {
/*  831 */     IntByReference lpcbData = new IntByReference();
/*  832 */     IntByReference lpType = new IntByReference();
/*  833 */     int rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, (char[])null, lpcbData);
/*      */     
/*  835 */     if (rc != 0 && rc != 122)
/*      */     {
/*  837 */       throw new Win32Exception(rc);
/*      */     }
/*  839 */     if (lpType.getValue() != 4) {
/*  840 */       throw new RuntimeException("Unexpected registry type " + lpType.getValue() + ", expected REG_DWORD");
/*      */     }
/*      */     
/*  843 */     IntByReference data = new IntByReference();
/*  844 */     rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, data, lpcbData);
/*      */     
/*  846 */     if (rc != 0 && rc != 122)
/*      */     {
/*  848 */       throw new Win32Exception(rc);
/*      */     }
/*  850 */     return data.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long registryGetLongValue(WinReg.HKEY root, String key, String value) {
/*  865 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/*  866 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, key, 0, 131097, phkKey);
/*      */     
/*  868 */     if (rc != 0) {
/*  869 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/*  872 */       return registryGetLongValue(phkKey.getValue(), value);
/*      */     } finally {
/*  874 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/*  875 */       if (rc != 0) {
/*  876 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static long registryGetLongValue(WinReg.HKEY hKey, String value) {
/*  891 */     IntByReference lpcbData = new IntByReference();
/*  892 */     IntByReference lpType = new IntByReference();
/*  893 */     int rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, (char[])null, lpcbData);
/*      */     
/*  895 */     if (rc != 0 && rc != 122)
/*      */     {
/*  897 */       throw new Win32Exception(rc);
/*      */     }
/*  899 */     if (lpType.getValue() != 11) {
/*  900 */       throw new RuntimeException("Unexpected registry type " + lpType.getValue() + ", expected REG_QWORD");
/*      */     }
/*      */     
/*  903 */     LongByReference data = new LongByReference();
/*  904 */     rc = Advapi32.INSTANCE.RegQueryValueEx(hKey, value, 0, lpType, data, lpcbData);
/*      */     
/*  906 */     if (rc != 0 && rc != 122)
/*      */     {
/*  908 */       throw new Win32Exception(rc);
/*      */     }
/*  910 */     return data.getValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Object registryGetValue(WinReg.HKEY hkKey, String subKey, String lpValueName) {
/*  927 */     Object result = null;
/*  928 */     IntByReference lpType = new IntByReference();
/*  929 */     byte[] lpData = new byte[16383];
/*  930 */     IntByReference lpcbData = new IntByReference(16383);
/*      */     
/*  932 */     int rc = Advapi32.INSTANCE.RegGetValue(hkKey, subKey, lpValueName, 65535, lpType, lpData, lpcbData);
/*      */ 
/*      */ 
/*      */     
/*  936 */     if (lpType.getValue() == 0) {
/*  937 */       return null;
/*      */     }
/*  939 */     if (rc != 0 && rc != 122)
/*      */     {
/*  941 */       throw new Win32Exception(rc);
/*      */     }
/*      */     
/*  944 */     Memory byteData = new Memory(lpcbData.getValue());
/*  945 */     byteData.write(0L, lpData, 0, lpcbData.getValue());
/*      */     
/*  947 */     if (lpType.getValue() == 4) {
/*  948 */       result = new Integer(byteData.getInt(0L));
/*  949 */     } else if (lpType.getValue() == 11) {
/*  950 */       result = new Long(byteData.getLong(0L));
/*  951 */     } else if (lpType.getValue() == 3) {
/*  952 */       result = byteData.getByteArray(0L, lpcbData.getValue());
/*  953 */     } else if (lpType.getValue() == 1 || lpType.getValue() == 2) {
/*      */       
/*  955 */       result = byteData.getWideString(0L);
/*      */     } 
/*      */     
/*  958 */     return result;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean registryCreateKey(WinReg.HKEY hKey, String keyName) {
/*  971 */     WinReg.HKEYByReference phkResult = new WinReg.HKEYByReference();
/*  972 */     IntByReference lpdwDisposition = new IntByReference();
/*  973 */     int rc = Advapi32.INSTANCE.RegCreateKeyEx(hKey, keyName, 0, null, 0, 131097, null, phkResult, lpdwDisposition);
/*      */ 
/*      */     
/*  976 */     if (rc != 0) {
/*  977 */       throw new Win32Exception(rc);
/*      */     }
/*  979 */     rc = Advapi32.INSTANCE.RegCloseKey(phkResult.getValue());
/*  980 */     if (rc != 0) {
/*  981 */       throw new Win32Exception(rc);
/*      */     }
/*  983 */     return (1 == lpdwDisposition.getValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean registryCreateKey(WinReg.HKEY root, String parentPath, String keyName) {
/*  999 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1000 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, parentPath, 0, 4, phkKey);
/*      */     
/* 1002 */     if (rc != 0) {
/* 1003 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/* 1006 */       return registryCreateKey(phkKey.getValue(), keyName);
/*      */     } finally {
/* 1008 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/* 1009 */       if (rc != 0) {
/* 1010 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetIntValue(WinReg.HKEY hKey, String name, int value) {
/* 1026 */     byte[] data = new byte[4];
/* 1027 */     data[0] = (byte)(value & 0xFF);
/* 1028 */     data[1] = (byte)(value >> 8 & 0xFF);
/* 1029 */     data[2] = (byte)(value >> 16 & 0xFF);
/* 1030 */     data[3] = (byte)(value >> 24 & 0xFF);
/* 1031 */     int rc = Advapi32.INSTANCE.RegSetValueEx(hKey, name, 0, 4, data, 4);
/*      */     
/* 1033 */     if (rc != 0) {
/* 1034 */       throw new Win32Exception(rc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetIntValue(WinReg.HKEY root, String keyPath, String name, int value) {
/* 1052 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1053 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, keyPath, 0, 131103, phkKey);
/*      */     
/* 1055 */     if (rc != 0) {
/* 1056 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/* 1059 */       registrySetIntValue(phkKey.getValue(), name, value);
/*      */     } finally {
/* 1061 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/* 1062 */       if (rc != 0) {
/* 1063 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetLongValue(WinReg.HKEY hKey, String name, long value) {
/* 1079 */     byte[] data = new byte[8];
/* 1080 */     data[0] = (byte)(int)(value & 0xFFL);
/* 1081 */     data[1] = (byte)(int)(value >> 8L & 0xFFL);
/* 1082 */     data[2] = (byte)(int)(value >> 16L & 0xFFL);
/* 1083 */     data[3] = (byte)(int)(value >> 24L & 0xFFL);
/* 1084 */     data[4] = (byte)(int)(value >> 32L & 0xFFL);
/* 1085 */     data[5] = (byte)(int)(value >> 40L & 0xFFL);
/* 1086 */     data[6] = (byte)(int)(value >> 48L & 0xFFL);
/* 1087 */     data[7] = (byte)(int)(value >> 56L & 0xFFL);
/* 1088 */     int rc = Advapi32.INSTANCE.RegSetValueEx(hKey, name, 0, 11, data, 8);
/*      */     
/* 1090 */     if (rc != 0) {
/* 1091 */       throw new Win32Exception(rc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetLongValue(WinReg.HKEY root, String keyPath, String name, long value) {
/* 1109 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1110 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, keyPath, 0, 131103, phkKey);
/*      */     
/* 1112 */     if (rc != 0) {
/* 1113 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/* 1116 */       registrySetLongValue(phkKey.getValue(), name, value);
/*      */     } finally {
/* 1118 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/* 1119 */       if (rc != 0) {
/* 1120 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetStringValue(WinReg.HKEY hKey, String name, String value) {
/* 1137 */     char[] data = Native.toCharArray(value);
/* 1138 */     int rc = Advapi32.INSTANCE.RegSetValueEx(hKey, name, 0, 1, data, data.length * Native.WCHAR_SIZE);
/*      */     
/* 1140 */     if (rc != 0) {
/* 1141 */       throw new Win32Exception(rc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetStringValue(WinReg.HKEY root, String keyPath, String name, String value) {
/* 1159 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1160 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, keyPath, 0, 131103, phkKey);
/*      */     
/* 1162 */     if (rc != 0) {
/* 1163 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/* 1166 */       registrySetStringValue(phkKey.getValue(), name, value);
/*      */     } finally {
/* 1168 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/* 1169 */       if (rc != 0) {
/* 1170 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetExpandableStringValue(WinReg.HKEY hKey, String name, String value) {
/* 1187 */     char[] data = Native.toCharArray(value);
/* 1188 */     int rc = Advapi32.INSTANCE.RegSetValueEx(hKey, name, 0, 2, data, data.length * Native.WCHAR_SIZE);
/*      */     
/* 1190 */     if (rc != 0) {
/* 1191 */       throw new Win32Exception(rc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetExpandableStringValue(WinReg.HKEY root, String keyPath, String name, String value) {
/* 1209 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1210 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, keyPath, 0, 131103, phkKey);
/*      */     
/* 1212 */     if (rc != 0) {
/* 1213 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/* 1216 */       registrySetExpandableStringValue(phkKey.getValue(), name, value);
/*      */     } finally {
/* 1218 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/* 1219 */       if (rc != 0) {
/* 1220 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetStringArray(WinReg.HKEY hKey, String name, String[] arr) {
/* 1237 */     int size = 0;
/* 1238 */     for (String s : arr) {
/* 1239 */       size += s.length() * Native.WCHAR_SIZE;
/* 1240 */       size += Native.WCHAR_SIZE;
/*      */     } 
/* 1242 */     size += Native.WCHAR_SIZE;
/*      */     
/* 1244 */     int offset = 0;
/* 1245 */     Memory data = new Memory(size);
/* 1246 */     for (String s : arr) {
/* 1247 */       data.setWideString(offset, s);
/* 1248 */       offset += s.length() * Native.WCHAR_SIZE;
/* 1249 */       offset += Native.WCHAR_SIZE;
/*      */     } 
/* 1251 */     for (int i = 0; i < Native.WCHAR_SIZE; i++) {
/* 1252 */       data.setByte(offset++, (byte)0);
/*      */     }
/*      */     
/* 1255 */     int rc = Advapi32.INSTANCE.RegSetValueEx(hKey, name, 0, 7, data.getByteArray(0L, size), size);
/*      */ 
/*      */     
/* 1258 */     if (rc != 0) {
/* 1259 */       throw new Win32Exception(rc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetStringArray(WinReg.HKEY root, String keyPath, String name, String[] arr) {
/* 1277 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1278 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, keyPath, 0, 131103, phkKey);
/*      */     
/* 1280 */     if (rc != 0) {
/* 1281 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/* 1284 */       registrySetStringArray(phkKey.getValue(), name, arr);
/*      */     } finally {
/* 1286 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/* 1287 */       if (rc != 0) {
/* 1288 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetBinaryValue(WinReg.HKEY hKey, String name, byte[] data) {
/* 1305 */     int rc = Advapi32.INSTANCE.RegSetValueEx(hKey, name, 0, 3, data, data.length);
/*      */     
/* 1307 */     if (rc != 0) {
/* 1308 */       throw new Win32Exception(rc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registrySetBinaryValue(WinReg.HKEY root, String keyPath, String name, byte[] data) {
/* 1326 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1327 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, keyPath, 0, 131103, phkKey);
/*      */     
/* 1329 */     if (rc != 0) {
/* 1330 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/* 1333 */       registrySetBinaryValue(phkKey.getValue(), name, data);
/*      */     } finally {
/* 1335 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/* 1336 */       if (rc != 0) {
/* 1337 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registryDeleteKey(WinReg.HKEY hKey, String keyName) {
/* 1351 */     int rc = Advapi32.INSTANCE.RegDeleteKey(hKey, keyName);
/* 1352 */     if (rc != 0) {
/* 1353 */       throw new Win32Exception(rc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registryDeleteKey(WinReg.HKEY root, String keyPath, String keyName) {
/* 1369 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1370 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, keyPath, 0, 131103, phkKey);
/*      */     
/* 1372 */     if (rc != 0) {
/* 1373 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/* 1376 */       registryDeleteKey(phkKey.getValue(), keyName);
/*      */     } finally {
/* 1378 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/* 1379 */       if (rc != 0) {
/* 1380 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registryDeleteValue(WinReg.HKEY hKey, String valueName) {
/* 1394 */     int rc = Advapi32.INSTANCE.RegDeleteValue(hKey, valueName);
/* 1395 */     if (rc != 0) {
/* 1396 */       throw new Win32Exception(rc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registryDeleteValue(WinReg.HKEY root, String keyPath, String valueName) {
/* 1412 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1413 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, keyPath, 0, 131103, phkKey);
/*      */     
/* 1415 */     if (rc != 0) {
/* 1416 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/* 1419 */       registryDeleteValue(phkKey.getValue(), valueName);
/*      */     } finally {
/* 1421 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/* 1422 */       if (rc != 0) {
/* 1423 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] registryGetKeys(WinReg.HKEY hKey) {
/* 1436 */     IntByReference lpcSubKeys = new IntByReference();
/* 1437 */     IntByReference lpcMaxSubKeyLen = new IntByReference();
/* 1438 */     int rc = Advapi32.INSTANCE.RegQueryInfoKey(hKey, null, null, null, lpcSubKeys, lpcMaxSubKeyLen, null, null, null, null, null, null);
/*      */ 
/*      */     
/* 1441 */     if (rc != 0) {
/* 1442 */       throw new Win32Exception(rc);
/*      */     }
/* 1444 */     ArrayList<String> keys = new ArrayList<String>(lpcSubKeys.getValue());
/* 1445 */     char[] name = new char[lpcMaxSubKeyLen.getValue() + 1];
/* 1446 */     for (int i = 0; i < lpcSubKeys.getValue(); i++) {
/* 1447 */       IntByReference lpcchValueName = new IntByReference(lpcMaxSubKeyLen.getValue() + 1);
/*      */       
/* 1449 */       rc = Advapi32.INSTANCE.RegEnumKeyEx(hKey, i, name, lpcchValueName, null, null, null, null);
/*      */       
/* 1451 */       if (rc != 0) {
/* 1452 */         throw new Win32Exception(rc);
/*      */       }
/* 1454 */       keys.add(Native.toString(name));
/*      */     } 
/* 1456 */     return keys.<String>toArray(new String[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String[] registryGetKeys(WinReg.HKEY root, String keyPath) {
/* 1469 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1470 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, keyPath, 0, 131097, phkKey);
/*      */     
/* 1472 */     if (rc != 0) {
/* 1473 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/* 1476 */       return registryGetKeys(phkKey.getValue());
/*      */     } finally {
/* 1478 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/* 1479 */       if (rc != 0) {
/* 1480 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static WinReg.HKEYByReference registryGetKey(WinReg.HKEY root, String keyPath, int samDesired) {
/* 1500 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1501 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, keyPath, 0, samDesired, phkKey);
/*      */     
/* 1503 */     if (rc != 0) {
/* 1504 */       throw new Win32Exception(rc);
/*      */     }
/*      */     
/* 1507 */     return phkKey;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void registryCloseKey(WinReg.HKEY hKey) {
/* 1517 */     int rc = Advapi32.INSTANCE.RegCloseKey(hKey);
/* 1518 */     if (rc != 0) {
/* 1519 */       throw new Win32Exception(rc);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TreeMap<String, Object> registryGetValues(WinReg.HKEY hKey) {
/* 1531 */     IntByReference lpcValues = new IntByReference();
/* 1532 */     IntByReference lpcMaxValueNameLen = new IntByReference();
/* 1533 */     IntByReference lpcMaxValueLen = new IntByReference();
/* 1534 */     int rc = Advapi32.INSTANCE.RegQueryInfoKey(hKey, null, null, null, null, null, null, lpcValues, lpcMaxValueNameLen, lpcMaxValueLen, null, null);
/*      */ 
/*      */     
/* 1537 */     if (rc != 0) {
/* 1538 */       throw new Win32Exception(rc);
/*      */     }
/* 1540 */     TreeMap<String, Object> keyValues = new TreeMap<String, Object>();
/* 1541 */     char[] name = new char[lpcMaxValueNameLen.getValue() + 1];
/* 1542 */     byte[] data = new byte[lpcMaxValueLen.getValue()];
/* 1543 */     for (int i = 0; i < lpcValues.getValue(); i++) {
/* 1544 */       IntByReference lpcchValueName = new IntByReference(lpcMaxValueNameLen.getValue() + 1);
/*      */       
/* 1546 */       IntByReference lpcbData = new IntByReference(lpcMaxValueLen.getValue());
/*      */       
/* 1548 */       IntByReference lpType = new IntByReference();
/* 1549 */       rc = Advapi32.INSTANCE.RegEnumValue(hKey, i, name, lpcchValueName, null, lpType, data, lpcbData);
/*      */       
/* 1551 */       if (rc != 0) {
/* 1552 */         throw new Win32Exception(rc);
/*      */       }
/*      */       
/* 1555 */       String nameString = Native.toString(name);
/*      */       
/* 1557 */       if (lpcbData.getValue() == 0) {
/* 1558 */         switch (lpType.getValue()) {
/*      */           case 3:
/* 1560 */             keyValues.put(nameString, new byte[0]);
/*      */             break;
/*      */           
/*      */           case 1:
/*      */           case 2:
/* 1565 */             keyValues.put(nameString, new char[0]);
/*      */             break;
/*      */           
/*      */           case 7:
/* 1569 */             keyValues.put(nameString, new String[0]);
/*      */             break;
/*      */           
/*      */           case 0:
/* 1573 */             keyValues.put(nameString, null);
/*      */             break;
/*      */           
/*      */           default:
/* 1577 */             throw new RuntimeException("Unsupported empty type: " + lpType.getValue());
/*      */         } 
/*      */       } else {
/*      */         Memory stringData;
/*      */         ArrayList<String> result;
/*      */         int offset;
/* 1583 */         Memory byteData = new Memory(lpcbData.getValue());
/* 1584 */         byteData.write(0L, data, 0, lpcbData.getValue());
/*      */         
/* 1586 */         switch (lpType.getValue()) {
/*      */           case 11:
/* 1588 */             keyValues.put(nameString, Long.valueOf(byteData.getLong(0L)));
/*      */             break;
/*      */           
/*      */           case 4:
/* 1592 */             keyValues.put(nameString, Integer.valueOf(byteData.getInt(0L)));
/*      */             break;
/*      */           
/*      */           case 1:
/*      */           case 2:
/* 1597 */             keyValues.put(nameString, byteData.getWideString(0L));
/*      */             break;
/*      */           
/*      */           case 3:
/* 1601 */             keyValues.put(nameString, byteData.getByteArray(0L, lpcbData.getValue()));
/*      */             break;
/*      */ 
/*      */           
/*      */           case 7:
/* 1606 */             stringData = new Memory(lpcbData.getValue());
/* 1607 */             stringData.write(0L, data, 0, lpcbData.getValue());
/* 1608 */             result = new ArrayList<String>();
/* 1609 */             offset = 0;
/* 1610 */             while (offset < stringData.size()) {
/* 1611 */               String s = stringData.getWideString(offset);
/* 1612 */               offset += s.length() * Native.WCHAR_SIZE;
/* 1613 */               offset += Native.WCHAR_SIZE;
/* 1614 */               if (s.length() == 0 && offset == stringData.size()) {
/*      */                 continue;
/*      */               }
/* 1617 */               result.add(s);
/*      */             } 
/*      */             
/* 1620 */             keyValues.put(nameString, result.toArray(new String[0]));
/*      */             break;
/*      */           
/*      */           default:
/* 1624 */             throw new RuntimeException("Unsupported type: " + lpType.getValue());
/*      */         } 
/*      */       } 
/*      */     } 
/* 1628 */     return keyValues;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static TreeMap<String, Object> registryGetValues(WinReg.HKEY root, String keyPath) {
/* 1642 */     WinReg.HKEYByReference phkKey = new WinReg.HKEYByReference();
/* 1643 */     int rc = Advapi32.INSTANCE.RegOpenKeyEx(root, keyPath, 0, 131097, phkKey);
/*      */     
/* 1645 */     if (rc != 0) {
/* 1646 */       throw new Win32Exception(rc);
/*      */     }
/*      */     try {
/* 1649 */       return registryGetValues(phkKey.getValue());
/*      */     } finally {
/* 1651 */       rc = Advapi32.INSTANCE.RegCloseKey(phkKey.getValue());
/* 1652 */       if (rc != 0) {
/* 1653 */         throw new Win32Exception(rc);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static InfoKey registryQueryInfoKey(WinReg.HKEY hKey, int lpcbSecurityDescriptor) {
/* 1669 */     InfoKey infoKey = new InfoKey(hKey, lpcbSecurityDescriptor);
/* 1670 */     int rc = Advapi32.INSTANCE.RegQueryInfoKey(hKey, infoKey.lpClass, infoKey.lpcClass, null, infoKey.lpcSubKeys, infoKey.lpcMaxSubKeyLen, infoKey.lpcMaxClassLen, infoKey.lpcValues, infoKey.lpcMaxValueNameLen, infoKey.lpcMaxValueLen, infoKey.lpcbSecurityDescriptor, infoKey.lpftLastWriteTime);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1677 */     if (rc != 0) {
/* 1678 */       throw new Win32Exception(rc);
/*      */     }
/*      */     
/* 1681 */     return infoKey;
/*      */   }
/*      */   
/*      */   public static class InfoKey {
/*      */     public WinReg.HKEY hKey;
/* 1686 */     public char[] lpClass = new char[260];
/* 1687 */     public IntByReference lpcClass = new IntByReference(260);
/* 1688 */     public IntByReference lpcSubKeys = new IntByReference();
/* 1689 */     public IntByReference lpcMaxSubKeyLen = new IntByReference();
/* 1690 */     public IntByReference lpcMaxClassLen = new IntByReference();
/* 1691 */     public IntByReference lpcValues = new IntByReference();
/* 1692 */     public IntByReference lpcMaxValueNameLen = new IntByReference();
/* 1693 */     public IntByReference lpcMaxValueLen = new IntByReference();
/* 1694 */     public IntByReference lpcbSecurityDescriptor = new IntByReference();
/* 1695 */     public WinBase.FILETIME lpftLastWriteTime = new WinBase.FILETIME();
/*      */ 
/*      */     
/*      */     public InfoKey() {}
/*      */     
/*      */     public InfoKey(WinReg.HKEY hKey, int securityDescriptor) {
/* 1701 */       this.hKey = hKey;
/* 1702 */       this.lpcbSecurityDescriptor = new IntByReference(securityDescriptor);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static EnumKey registryRegEnumKey(WinReg.HKEY hKey, int dwIndex) {
/* 1715 */     EnumKey enumKey = new EnumKey(hKey, dwIndex);
/* 1716 */     int rc = Advapi32.INSTANCE.RegEnumKeyEx(hKey, enumKey.dwIndex, enumKey.lpName, enumKey.lpcName, null, enumKey.lpClass, enumKey.lpcbClass, enumKey.lpftLastWriteTime);
/*      */ 
/*      */ 
/*      */     
/* 1720 */     if (rc != 0) {
/* 1721 */       throw new Win32Exception(rc);
/*      */     }
/*      */     
/* 1724 */     return enumKey;
/*      */   }
/*      */   
/*      */   public static class EnumKey {
/*      */     public WinReg.HKEY hKey;
/* 1729 */     public int dwIndex = 0;
/* 1730 */     public char[] lpName = new char[255];
/* 1731 */     public IntByReference lpcName = new IntByReference(255);
/*      */     
/* 1733 */     public char[] lpClass = new char[255];
/* 1734 */     public IntByReference lpcbClass = new IntByReference(255);
/*      */     
/* 1736 */     public WinBase.FILETIME lpftLastWriteTime = new WinBase.FILETIME();
/*      */ 
/*      */     
/*      */     public EnumKey() {}
/*      */     
/*      */     public EnumKey(WinReg.HKEY hKey, int dwIndex) {
/* 1742 */       this.hKey = hKey;
/* 1743 */       this.dwIndex = dwIndex;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getEnvironmentBlock(Map<String, String> environment) {
/* 1758 */     StringBuilder out = new StringBuilder();
/* 1759 */     for (Map.Entry<String, String> entry : environment.entrySet()) {
/* 1760 */       if (entry.getValue() != null) {
/* 1761 */         out.append((String)entry.getKey() + "=" + (String)entry.getValue() + "\000");
/*      */       }
/*      */     } 
/* 1764 */     return out.toString() + "\000";
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public enum EventLogType
/*      */   {
/* 1771 */     Error, Warning, Informational, AuditSuccess, AuditFailure;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EventLogRecord
/*      */   {
/* 1778 */     private WinNT.EVENTLOGRECORD _record = null;
/*      */ 
/*      */     
/*      */     private String _source;
/*      */     
/*      */     private byte[] _data;
/*      */     
/*      */     private String[] _strings;
/*      */ 
/*      */     
/*      */     public WinNT.EVENTLOGRECORD getRecord() {
/* 1789 */       return this._record;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getEventId() {
/* 1798 */       return this._record.EventID.intValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String getSource() {
/* 1807 */       return this._source;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getStatusCode() {
/* 1816 */       return this._record.EventID.intValue() & 0xFFFF;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getRecordNumber() {
/* 1827 */       return this._record.RecordNumber.intValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public int getLength() {
/* 1836 */       return this._record.Length.intValue();
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public String[] getStrings() {
/* 1845 */       return this._strings;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public Advapi32Util.EventLogType getType() {
/* 1854 */       switch (this._record.EventType.intValue()) {
/*      */         case 0:
/*      */         case 4:
/* 1857 */           return Advapi32Util.EventLogType.Informational;
/*      */         case 16:
/* 1859 */           return Advapi32Util.EventLogType.AuditFailure;
/*      */         case 8:
/* 1861 */           return Advapi32Util.EventLogType.AuditSuccess;
/*      */         case 1:
/* 1863 */           return Advapi32Util.EventLogType.Error;
/*      */         case 2:
/* 1865 */           return Advapi32Util.EventLogType.Warning;
/*      */       } 
/* 1867 */       throw new RuntimeException("Invalid type: " + this._record.EventType.intValue());
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public byte[] getData() {
/* 1878 */       return this._data;
/*      */     }
/*      */     
/*      */     public EventLogRecord(Pointer pevlr) {
/* 1882 */       this._record = new WinNT.EVENTLOGRECORD(pevlr);
/* 1883 */       this._source = pevlr.getWideString(this._record.size());
/*      */       
/* 1885 */       if (this._record.DataLength.intValue() > 0) {
/* 1886 */         this._data = pevlr.getByteArray(this._record.DataOffset.intValue(), this._record.DataLength.intValue());
/*      */       }
/*      */ 
/*      */       
/* 1890 */       if (this._record.NumStrings.intValue() > 0) {
/* 1891 */         ArrayList<String> strings = new ArrayList<String>();
/* 1892 */         int count = this._record.NumStrings.intValue();
/* 1893 */         long offset = this._record.StringOffset.intValue();
/* 1894 */         while (count > 0) {
/* 1895 */           String s = pevlr.getWideString(0L);
/* 1896 */           strings.add(s);
/* 1897 */           offset += (s.length() * Native.WCHAR_SIZE);
/* 1898 */           offset += Native.WCHAR_SIZE;
/* 1899 */           count--;
/*      */         } 
/* 1901 */         this._strings = strings.<String>toArray(new String[0]);
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static class EventLogIterator
/*      */     implements Iterable<EventLogRecord>, Iterator<EventLogRecord>
/*      */   {
/* 1912 */     private WinNT.HANDLE _h = null;
/* 1913 */     private Memory _buffer = new Memory(65536L);
/*      */     
/*      */     private boolean _done = false;
/* 1916 */     private int _dwRead = 0;
/*      */     
/* 1918 */     private Pointer _pevlr = null;
/* 1919 */     private int _flags = 4;
/*      */     
/*      */     public EventLogIterator(String sourceName) {
/* 1922 */       this(null, sourceName, 4);
/*      */     }
/*      */     
/*      */     public EventLogIterator(String serverName, String sourceName, int flags) {
/* 1926 */       this._flags = flags;
/* 1927 */       this._h = Advapi32.INSTANCE.OpenEventLog(serverName, sourceName);
/* 1928 */       if (this._h == null) {
/* 1929 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */     }
/*      */ 
/*      */     
/*      */     private boolean read() {
/* 1935 */       if (this._done || this._dwRead > 0) {
/* 1936 */         return false;
/*      */       }
/*      */       
/* 1939 */       IntByReference pnBytesRead = new IntByReference();
/* 1940 */       IntByReference pnMinNumberOfBytesNeeded = new IntByReference();
/*      */       
/* 1942 */       if (!Advapi32.INSTANCE.ReadEventLog(this._h, 0x1 | this._flags, 0, (Pointer)this._buffer, (int)this._buffer.size(), pnBytesRead, pnMinNumberOfBytesNeeded)) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1947 */         int rc = Kernel32.INSTANCE.GetLastError();
/*      */ 
/*      */         
/* 1950 */         if (rc == 122) {
/* 1951 */           this._buffer = new Memory(pnMinNumberOfBytesNeeded.getValue());
/*      */           
/* 1953 */           if (!Advapi32.INSTANCE.ReadEventLog(this._h, 0x1 | this._flags, 0, (Pointer)this._buffer, (int)this._buffer.size(), pnBytesRead, pnMinNumberOfBytesNeeded))
/*      */           {
/*      */ 
/*      */             
/* 1957 */             throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */           }
/*      */         }
/*      */         else {
/*      */           
/* 1962 */           close();
/* 1963 */           if (rc != 38) {
/* 1964 */             throw new Win32Exception(rc);
/*      */           }
/* 1966 */           return false;
/*      */         } 
/*      */       } 
/*      */       
/* 1970 */       this._dwRead = pnBytesRead.getValue();
/* 1971 */       this._pevlr = (Pointer)this._buffer;
/* 1972 */       return true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     public void close() {
/* 1980 */       this._done = true;
/* 1981 */       if (this._h != null) {
/* 1982 */         if (!Advapi32.INSTANCE.CloseEventLog(this._h)) {
/* 1983 */           throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */         }
/* 1985 */         this._h = null;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Iterator<Advapi32Util.EventLogRecord> iterator() {
/* 1992 */       return this;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public boolean hasNext() {
/* 1998 */       read();
/* 1999 */       return !this._done;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public Advapi32Util.EventLogRecord next() {
/* 2005 */       read();
/* 2006 */       Advapi32Util.EventLogRecord record = new Advapi32Util.EventLogRecord(this._pevlr);
/* 2007 */       this._dwRead -= record.getLength();
/* 2008 */       this._pevlr = this._pevlr.share(record.getLength());
/* 2009 */       return record;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*      */     public void remove() {}
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static WinNT.ACCESS_ACEStructure[] getFileSecurity(String fileName, boolean compact) {
/* 2020 */     int infoType = 4;
/* 2021 */     int nLength = 1024;
/* 2022 */     boolean repeat = false;
/* 2023 */     Memory memory = null;
/*      */     
/*      */     do {
/* 2026 */       repeat = false;
/* 2027 */       memory = new Memory(nLength);
/* 2028 */       IntByReference lpnSize = new IntByReference();
/* 2029 */       boolean succeded = Advapi32.INSTANCE.GetFileSecurity(new WString(fileName), infoType, (Pointer)memory, nLength, lpnSize);
/*      */ 
/*      */       
/* 2032 */       if (!succeded) {
/* 2033 */         int lastError = Kernel32.INSTANCE.GetLastError();
/* 2034 */         memory.clear();
/* 2035 */         if (122 != lastError) {
/* 2036 */           throw new Win32Exception(lastError);
/*      */         }
/*      */       } 
/* 2039 */       int lengthNeeded = lpnSize.getValue();
/* 2040 */       if (nLength >= lengthNeeded)
/* 2041 */         continue;  repeat = true;
/* 2042 */       nLength = lengthNeeded;
/* 2043 */       memory.clear();
/*      */     }
/* 2045 */     while (repeat);
/*      */     
/* 2047 */     WinNT.SECURITY_DESCRIPTOR_RELATIVE sdr = new WinNT.SECURITY_DESCRIPTOR_RELATIVE((Pointer)memory);
/*      */     
/* 2049 */     memory.clear();
/* 2050 */     WinNT.ACL dacl = sdr.getDiscretionaryACL();
/* 2051 */     WinNT.ACCESS_ACEStructure[] aceStructures = dacl.getACEStructures();
/*      */     
/* 2053 */     if (compact) {
/* 2054 */       Map<String, WinNT.ACCESS_ACEStructure> aceMap = new HashMap<String, WinNT.ACCESS_ACEStructure>();
/* 2055 */       for (WinNT.ACCESS_ACEStructure aceStructure : aceStructures) {
/* 2056 */         boolean inherted = ((aceStructure.AceFlags & 0x1F) != 0);
/* 2057 */         String key = aceStructure.getSidString() + "/" + inherted + "/" + aceStructure.getClass().getName();
/*      */         
/* 2059 */         WinNT.ACCESS_ACEStructure aceStructure2 = aceMap.get(key);
/* 2060 */         if (aceStructure2 != null) {
/* 2061 */           int accessMask = aceStructure2.Mask;
/* 2062 */           accessMask |= aceStructure.Mask;
/* 2063 */           aceStructure2.Mask = accessMask;
/*      */         } else {
/* 2065 */           aceMap.put(key, aceStructure);
/*      */         } 
/*      */       } 
/* 2068 */       return (WinNT.ACCESS_ACEStructure[])aceMap.values().toArray((Object[])new WinNT.ACCESS_ACEStructure[aceMap.size()]);
/*      */     } 
/*      */     
/* 2071 */     return aceStructures;
/*      */   }
/*      */   
/*      */   public enum AccessCheckPermission {
/* 2075 */     READ(-2147483648),
/* 2076 */     WRITE(1073741824),
/* 2077 */     EXECUTE(536870912);
/*      */     
/*      */     final int code;
/*      */     
/*      */     AccessCheckPermission(int code) {
/* 2082 */       this.code = code;
/*      */     }
/*      */     
/*      */     public int getCode() {
/* 2086 */       return this.code;
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   private static Memory getSecurityDescriptorForFile(String absoluteFilePath) {
/* 2092 */     int infoType = 7;
/*      */ 
/*      */     
/* 2095 */     IntByReference lpnSize = new IntByReference();
/* 2096 */     boolean succeeded = Advapi32.INSTANCE.GetFileSecurity(new WString(absoluteFilePath), 7, null, 0, lpnSize);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2102 */     if (!succeeded) {
/* 2103 */       int lastError = Kernel32.INSTANCE.GetLastError();
/* 2104 */       if (122 != lastError) {
/* 2105 */         throw new Win32Exception(lastError);
/*      */       }
/*      */     } 
/*      */     
/* 2109 */     int nLength = lpnSize.getValue();
/* 2110 */     Memory securityDescriptorMemoryPointer = new Memory(nLength);
/* 2111 */     succeeded = Advapi32.INSTANCE.GetFileSecurity(new WString(absoluteFilePath), 7, (Pointer)securityDescriptorMemoryPointer, nLength, lpnSize);
/*      */ 
/*      */     
/* 2114 */     if (!succeeded) {
/* 2115 */       securityDescriptorMemoryPointer.clear();
/* 2116 */       throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */     } 
/*      */     
/* 2119 */     return securityDescriptorMemoryPointer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean accessCheck(File file, AccessCheckPermission permissionToCheck) {
/* 2129 */     boolean hasAccess = false;
/* 2130 */     Memory securityDescriptorMemoryPointer = getSecurityDescriptorForFile(file.getAbsolutePath().replaceAll("/", "\\"));
/*      */     
/* 2132 */     WinNT.HANDLEByReference openedAccessToken = null;
/* 2133 */     WinNT.HANDLEByReference duplicatedToken = new WinNT.HANDLEByReference();
/*      */     try {
/* 2135 */       openedAccessToken = new WinNT.HANDLEByReference();
/*      */       
/* 2137 */       int desireAccess = 131086;
/* 2138 */       if (!Advapi32.INSTANCE.OpenProcessToken(Kernel32.INSTANCE.GetCurrentProcess(), 131086, openedAccessToken)) {
/* 2139 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */       
/* 2142 */       if (!Advapi32.INSTANCE.DuplicateToken(openedAccessToken.getValue(), 2, duplicatedToken)) {
/* 2143 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */       
/* 2146 */       WinNT.GENERIC_MAPPING mapping = new WinNT.GENERIC_MAPPING();
/* 2147 */       mapping.genericRead = new WinDef.DWORD(1179785L);
/* 2148 */       mapping.genericWrite = new WinDef.DWORD(1179926L);
/* 2149 */       mapping.genericExecute = new WinDef.DWORD(1179808L);
/* 2150 */       mapping.genericAll = new WinDef.DWORD(2032127L);
/*      */       
/* 2152 */       WinDef.DWORDByReference rights = new WinDef.DWORDByReference(new WinDef.DWORD(permissionToCheck.getCode()));
/* 2153 */       Advapi32.INSTANCE.MapGenericMask(rights, mapping);
/*      */       
/* 2155 */       WinNT.PRIVILEGE_SET privileges = new WinNT.PRIVILEGE_SET(1);
/* 2156 */       privileges.PrivilegeCount = new WinDef.DWORD(0L);
/* 2157 */       WinDef.DWORDByReference privilegeLength = new WinDef.DWORDByReference(new WinDef.DWORD(privileges.size()));
/*      */       
/* 2159 */       WinDef.DWORDByReference grantedAccess = new WinDef.DWORDByReference();
/* 2160 */       WinDef.BOOLByReference result = new WinDef.BOOLByReference();
/* 2161 */       if (!Advapi32.INSTANCE.AccessCheck((Pointer)securityDescriptorMemoryPointer, duplicatedToken.getValue(), rights.getValue(), mapping, privileges, privilegeLength, grantedAccess, result))
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 2166 */         throw new Win32Exception(Kernel32.INSTANCE.GetLastError());
/*      */       }
/*      */       
/* 2169 */       hasAccess = result.getValue().booleanValue();
/*      */     }
/*      */     finally {
/*      */       
/* 2173 */       if (openedAccessToken != null && openedAccessToken.getValue() != null) {
/* 2174 */         Kernel32.INSTANCE.CloseHandle(openedAccessToken.getValue());
/*      */       }
/*      */       
/* 2177 */       if (duplicatedToken != null && duplicatedToken.getValue() != null) {
/* 2178 */         Kernel32.INSTANCE.CloseHandle(duplicatedToken.getValue());
/*      */       }
/*      */       
/* 2181 */       if (securityDescriptorMemoryPointer != null) {
/* 2182 */         securityDescriptorMemoryPointer.clear();
/*      */       }
/*      */     } 
/*      */     
/* 2186 */     return hasAccess;
/*      */   }
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/GodzillaJna.jar!/com/sun/jna/platform/win32/Advapi32Util.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */