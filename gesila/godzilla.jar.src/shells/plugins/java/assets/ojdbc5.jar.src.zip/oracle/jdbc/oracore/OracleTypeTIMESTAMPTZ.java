/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeTIMESTAMPTZ
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = 5643686037837085645L;
/*  60 */   int precision = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   transient OracleConnection connection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleTypeTIMESTAMPTZ() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleTypeTIMESTAMPTZ(OracleConnection paramOracleConnection) {
/*  81 */     this.connection = paramOracleConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeCode() {
/*  92 */     return -101;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
/* 100 */     this.precision = paramTDSReader.readByte();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getScale() throws SQLException {
/* 107 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecision() throws SQLException {
/* 114 */     return this.precision;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 123 */     this.precision = paramObjectInputStream.readByte();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 131 */     paramObjectOutputStream.writeByte(this.precision);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 139 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 140 */       return null;
/*     */     }
/* 142 */     switch (paramInt) {
/*     */ 
/*     */       
/*     */       case 1:
/* 146 */         return new TIMESTAMPTZ(paramArrayOfbyte);
/*     */       
/*     */       case 2:
/* 149 */         return TIMESTAMPTZ.toTimestamp((Connection)this.connection, paramArrayOfbyte);
/*     */       
/*     */       case 3:
/* 152 */         return paramArrayOfbyte;
/*     */     } 
/*     */ 
/*     */     
/* 156 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 157 */     sQLException.fillInStackTrace();
/* 158 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/* 177 */     TIMESTAMPTZ tIMESTAMPTZ = null;
/*     */     
/* 179 */     if (paramObject != null) {
/*     */       
/*     */       try {
/*     */         
/* 183 */         if (paramObject instanceof TIMESTAMPTZ) {
/* 184 */           tIMESTAMPTZ = (TIMESTAMPTZ)paramObject;
/* 185 */         } else if (paramObject instanceof byte[]) {
/* 186 */           tIMESTAMPTZ = new TIMESTAMPTZ((byte[])paramObject);
/* 187 */         } else if (paramObject instanceof Timestamp) {
/* 188 */           tIMESTAMPTZ = new TIMESTAMPTZ((Connection)paramOracleConnection, (Timestamp)paramObject);
/* 189 */         } else if (paramObject instanceof DATE) {
/* 190 */           tIMESTAMPTZ = new TIMESTAMPTZ((Connection)paramOracleConnection, (DATE)paramObject);
/* 191 */         } else if (paramObject instanceof String) {
/* 192 */           tIMESTAMPTZ = new TIMESTAMPTZ((Connection)paramOracleConnection, (String)paramObject);
/* 193 */         } else if (paramObject instanceof Date) {
/* 194 */           tIMESTAMPTZ = new TIMESTAMPTZ((Connection)paramOracleConnection, (Date)paramObject);
/* 195 */         } else if (paramObject instanceof Time) {
/* 196 */           tIMESTAMPTZ = new TIMESTAMPTZ((Connection)paramOracleConnection, (Time)paramObject);
/*     */         } else {
/*     */           
/* 199 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/* 200 */           sQLException.fillInStackTrace();
/* 201 */           throw sQLException;
/*     */         }
/*     */       
/* 204 */       } catch (Exception exception) {
/*     */ 
/*     */         
/* 207 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/* 208 */         sQLException.fillInStackTrace();
/* 209 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 214 */     return (Datum)tIMESTAMPTZ;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object unpickle81rec(UnpickleContext paramUnpickleContext, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/* 228 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 229 */     sQLException.fillInStackTrace();
/* 230 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 246 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/oracore/OracleTypeTIMESTAMPTZ.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */