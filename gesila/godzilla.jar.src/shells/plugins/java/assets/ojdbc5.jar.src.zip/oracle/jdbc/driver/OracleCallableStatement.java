/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.internal.OracleCallableStatement;
/*      */ import oracle.sql.ANYDATA;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleCallableStatement
/*      */   extends OraclePreparedStatement
/*      */   implements OracleCallableStatement
/*      */ {
/*      */   boolean atLeastOneOrdinalParameter = false;
/*      */   boolean atLeastOneNamedParameter = false;
/*   56 */   String[] namedParameters = new String[8];
/*      */ 
/*      */   
/*   59 */   int parameterCount = 0;
/*      */ 
/*      */   
/*   62 */   final String errMsgMixedBind = "Ordinal binding and Named binding cannot be combined!";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*   83 */     this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleCallableStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  101 */     super(paramPhysicalConnection, paramString, 1, paramInt2, paramInt3, paramInt4);
/*      */ 
/*      */     
/*  104 */     this.statementType = 2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerOutParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString) throws SQLException {
/*  117 */     int i = paramInt1 - 1;
/*  118 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*      */       
/*  120 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  121 */       sQLException.fillInStackTrace();
/*  122 */       throw sQLException;
/*      */     } 
/*      */     
/*  125 */     if (paramInt2 == 0) {
/*      */       
/*  127 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  128 */       sQLException.fillInStackTrace();
/*  129 */       throw sQLException;
/*      */     } 
/*  131 */     int j = getInternalType(paramInt2);
/*      */     
/*  133 */     resetBatch();
/*  134 */     this.currentRowNeedToPrepareBinds = true;
/*      */     
/*  136 */     if (this.currentRowBindAccessors == null) {
/*  137 */       this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*      */     }
/*      */     
/*  140 */     switch (paramInt2) {
/*      */       case -4:
/*      */       case -3:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/*      */       case 70:
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  154 */         paramInt4 = 0;
/*      */         break;
/*      */     } 
/*      */     
/*  158 */     this.currentRowBindAccessors[i] = allocateAccessor(j, paramInt2, i + 1, paramInt4, this.currentRowFormOfUse[i], paramString, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  192 */     if (paramString == null || paramString.length() == 0) {
/*      */       
/*  194 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "empty Object name");
/*  195 */       sQLException.fillInStackTrace();
/*  196 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  202 */     synchronized (this.connection) {
/*  203 */       registerOutParameterInternal(paramInt1, paramInt2, 0, 0, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  232 */     synchronized (this.connection) {
/*      */       
/*  234 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  263 */     synchronized (this.connection) {
/*      */       
/*  265 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/*  282 */     synchronized (this.connection) {
/*      */       
/*  284 */       registerOutParameterInternal(paramInt1, paramInt2, paramInt3, paramInt4, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  301 */     synchronized (this.connection) {
/*      */       
/*  303 */       registerOutParameterInternal(paramString, paramInt1, paramInt2, paramInt3, (String)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isOracleBatchStyle() {
/*  312 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetBatch() {
/*  322 */     this.batch = 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExecuteBatch(int paramInt) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sendBatch() throws SQLException {
/*  351 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  354 */       return this.validRows;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2) throws SQLException {
/*  373 */     registerOutParameter(paramInt1, paramInt2, 0, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  385 */     registerOutParameter(paramInt1, paramInt2, paramInt3, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*  393 */     return wasNullValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/*  403 */     if (this.closed) {
/*      */       
/*  405 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  406 */       sQLException.fillInStackTrace();
/*  407 */       throw sQLException;
/*      */     } 
/*      */     
/*  410 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  413 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  414 */       sQLException.fillInStackTrace();
/*  415 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  419 */     Accessor accessor = null;
/*  420 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  425 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  426 */       sQLException.fillInStackTrace();
/*  427 */       throw sQLException;
/*      */     } 
/*      */     
/*  430 */     this.lastIndex = paramInt;
/*      */     
/*  432 */     if (this.streamList != null) {
/*  433 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  436 */     return accessor.getString(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/*  446 */     if (this.closed) {
/*      */       
/*  448 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  449 */       sQLException.fillInStackTrace();
/*  450 */       throw sQLException;
/*      */     } 
/*      */     
/*  453 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  456 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  457 */       sQLException.fillInStackTrace();
/*  458 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  462 */     Accessor accessor = null;
/*  463 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  468 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  469 */       sQLException.fillInStackTrace();
/*  470 */       throw sQLException;
/*      */     } 
/*      */     
/*  473 */     this.lastIndex = paramInt;
/*      */     
/*  475 */     if (this.streamList != null) {
/*  476 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  479 */     return accessor.getOracleObject(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/*  489 */     if (this.closed) {
/*      */       
/*  491 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  492 */       sQLException.fillInStackTrace();
/*  493 */       throw sQLException;
/*      */     } 
/*      */     
/*  496 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  499 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  500 */       sQLException.fillInStackTrace();
/*  501 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  505 */     Accessor accessor = null;
/*  506 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  511 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  512 */       sQLException.fillInStackTrace();
/*  513 */       throw sQLException;
/*      */     } 
/*      */     
/*  516 */     this.lastIndex = paramInt;
/*      */     
/*  518 */     if (this.streamList != null) {
/*  519 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  522 */     return accessor.getROWID(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/*  532 */     if (this.closed) {
/*      */       
/*  534 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  535 */       sQLException.fillInStackTrace();
/*  536 */       throw sQLException;
/*      */     } 
/*      */     
/*  539 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  542 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  543 */       sQLException.fillInStackTrace();
/*  544 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  548 */     Accessor accessor = null;
/*  549 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  554 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  555 */       sQLException.fillInStackTrace();
/*  556 */       throw sQLException;
/*      */     } 
/*      */     
/*  559 */     this.lastIndex = paramInt;
/*      */     
/*  561 */     if (this.streamList != null) {
/*  562 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  565 */     return accessor.getNUMBER(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/*  575 */     if (this.closed) {
/*      */       
/*  577 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  578 */       sQLException.fillInStackTrace();
/*  579 */       throw sQLException;
/*      */     } 
/*      */     
/*  582 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  585 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  586 */       sQLException.fillInStackTrace();
/*  587 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  591 */     Accessor accessor = null;
/*  592 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  597 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  598 */       sQLException.fillInStackTrace();
/*  599 */       throw sQLException;
/*      */     } 
/*      */     
/*  602 */     this.lastIndex = paramInt;
/*      */     
/*  604 */     if (this.streamList != null) {
/*  605 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  608 */     return accessor.getDATE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/*  618 */     if (this.closed) {
/*      */       
/*  620 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  621 */       sQLException.fillInStackTrace();
/*  622 */       throw sQLException;
/*      */     } 
/*      */     
/*  625 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  628 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  629 */       sQLException.fillInStackTrace();
/*  630 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  634 */     Accessor accessor = null;
/*  635 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  640 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  641 */       sQLException.fillInStackTrace();
/*  642 */       throw sQLException;
/*      */     } 
/*      */     
/*  645 */     this.lastIndex = paramInt;
/*      */     
/*  647 */     if (this.streamList != null) {
/*  648 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  651 */     return accessor.getINTERVALYM(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/*  661 */     if (this.closed) {
/*      */       
/*  663 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  664 */       sQLException.fillInStackTrace();
/*  665 */       throw sQLException;
/*      */     } 
/*      */     
/*  668 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  671 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  672 */       sQLException.fillInStackTrace();
/*  673 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  677 */     Accessor accessor = null;
/*  678 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  683 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  684 */       sQLException.fillInStackTrace();
/*  685 */       throw sQLException;
/*      */     } 
/*      */     
/*  688 */     this.lastIndex = paramInt;
/*      */     
/*  690 */     if (this.streamList != null) {
/*  691 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  694 */     return accessor.getINTERVALDS(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/*  704 */     if (this.closed) {
/*      */       
/*  706 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  707 */       sQLException.fillInStackTrace();
/*  708 */       throw sQLException;
/*      */     } 
/*      */     
/*  711 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  714 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  715 */       sQLException.fillInStackTrace();
/*  716 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  720 */     Accessor accessor = null;
/*  721 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  726 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  727 */       sQLException.fillInStackTrace();
/*  728 */       throw sQLException;
/*      */     } 
/*      */     
/*  731 */     this.lastIndex = paramInt;
/*      */     
/*  733 */     if (this.streamList != null) {
/*  734 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  737 */     return accessor.getTIMESTAMP(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/*  747 */     if (this.closed) {
/*      */       
/*  749 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  750 */       sQLException.fillInStackTrace();
/*  751 */       throw sQLException;
/*      */     } 
/*      */     
/*  754 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  757 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  758 */       sQLException.fillInStackTrace();
/*  759 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  763 */     Accessor accessor = null;
/*  764 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  769 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  770 */       sQLException.fillInStackTrace();
/*  771 */       throw sQLException;
/*      */     } 
/*      */     
/*  774 */     this.lastIndex = paramInt;
/*      */     
/*  776 */     if (this.streamList != null) {
/*  777 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  780 */     return accessor.getTIMESTAMPTZ(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/*  790 */     if (this.closed) {
/*      */       
/*  792 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  793 */       sQLException.fillInStackTrace();
/*  794 */       throw sQLException;
/*      */     } 
/*      */     
/*  797 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  800 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  801 */       sQLException.fillInStackTrace();
/*  802 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  806 */     Accessor accessor = null;
/*  807 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  812 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  813 */       sQLException.fillInStackTrace();
/*  814 */       throw sQLException;
/*      */     } 
/*      */     
/*  817 */     this.lastIndex = paramInt;
/*      */     
/*  819 */     if (this.streamList != null) {
/*  820 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  823 */     return accessor.getTIMESTAMPLTZ(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/*  833 */     if (this.closed) {
/*      */       
/*  835 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  836 */       sQLException.fillInStackTrace();
/*  837 */       throw sQLException;
/*      */     } 
/*      */     
/*  840 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  843 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  844 */       sQLException.fillInStackTrace();
/*  845 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  849 */     Accessor accessor = null;
/*  850 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  855 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  856 */       sQLException.fillInStackTrace();
/*  857 */       throw sQLException;
/*      */     } 
/*      */     
/*  860 */     this.lastIndex = paramInt;
/*      */     
/*  862 */     if (this.streamList != null) {
/*  863 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  866 */     return accessor.getREF(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/*  876 */     if (this.closed) {
/*      */       
/*  878 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  879 */       sQLException.fillInStackTrace();
/*  880 */       throw sQLException;
/*      */     } 
/*      */     
/*  883 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  886 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  887 */       sQLException.fillInStackTrace();
/*  888 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  892 */     Accessor accessor = null;
/*  893 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  898 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  899 */       sQLException.fillInStackTrace();
/*  900 */       throw sQLException;
/*      */     } 
/*      */     
/*  903 */     this.lastIndex = paramInt;
/*      */     
/*  905 */     if (this.streamList != null) {
/*  906 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  909 */     return accessor.getARRAY(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/*  919 */     if (this.closed) {
/*      */       
/*  921 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  922 */       sQLException.fillInStackTrace();
/*  923 */       throw sQLException;
/*      */     } 
/*      */     
/*  926 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  929 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  930 */       sQLException.fillInStackTrace();
/*  931 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  935 */     Accessor accessor = null;
/*  936 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  941 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  942 */       sQLException.fillInStackTrace();
/*  943 */       throw sQLException;
/*      */     } 
/*      */     
/*  946 */     this.lastIndex = paramInt;
/*      */     
/*  948 */     if (this.streamList != null) {
/*  949 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  952 */     return accessor.getSTRUCT(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/*  962 */     if (this.closed) {
/*      */       
/*  964 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  965 */       sQLException.fillInStackTrace();
/*  966 */       throw sQLException;
/*      */     } 
/*      */     
/*  969 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/*  972 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/*  973 */       sQLException.fillInStackTrace();
/*  974 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  978 */     Accessor accessor = null;
/*  979 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  984 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  985 */       sQLException.fillInStackTrace();
/*  986 */       throw sQLException;
/*      */     } 
/*      */     
/*  989 */     this.lastIndex = paramInt;
/*      */     
/*  991 */     if (this.streamList != null) {
/*  992 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/*  995 */     return accessor.getOPAQUE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 1005 */     if (this.closed) {
/*      */       
/* 1007 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1008 */       sQLException.fillInStackTrace();
/* 1009 */       throw sQLException;
/*      */     } 
/*      */     
/* 1012 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1015 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1016 */       sQLException.fillInStackTrace();
/* 1017 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1021 */     Accessor accessor = null;
/* 1022 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1027 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1028 */       sQLException.fillInStackTrace();
/* 1029 */       throw sQLException;
/*      */     } 
/*      */     
/* 1032 */     this.lastIndex = paramInt;
/*      */     
/* 1034 */     if (this.streamList != null) {
/* 1035 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1038 */     return accessor.getCHAR(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 1049 */     if (this.closed) {
/*      */       
/* 1051 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1052 */       sQLException.fillInStackTrace();
/* 1053 */       throw sQLException;
/*      */     } 
/*      */     
/* 1056 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1059 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1060 */       sQLException.fillInStackTrace();
/* 1061 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1065 */     Accessor accessor = null;
/* 1066 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1071 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1072 */       sQLException.fillInStackTrace();
/* 1073 */       throw sQLException;
/*      */     } 
/*      */     
/* 1076 */     this.lastIndex = paramInt;
/*      */     
/* 1078 */     if (this.streamList != null) {
/* 1079 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1082 */     return accessor.getCharacterStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 1092 */     if (this.closed) {
/*      */       
/* 1094 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1095 */       sQLException.fillInStackTrace();
/* 1096 */       throw sQLException;
/*      */     } 
/*      */     
/* 1099 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1102 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1103 */       sQLException.fillInStackTrace();
/* 1104 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1108 */     Accessor accessor = null;
/* 1109 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1114 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1115 */       sQLException.fillInStackTrace();
/* 1116 */       throw sQLException;
/*      */     } 
/*      */     
/* 1119 */     this.lastIndex = paramInt;
/*      */     
/* 1121 */     if (this.streamList != null) {
/* 1122 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1125 */     return accessor.getRAW(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 1136 */     if (this.closed) {
/*      */       
/* 1138 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1139 */       sQLException.fillInStackTrace();
/* 1140 */       throw sQLException;
/*      */     } 
/*      */     
/* 1143 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1146 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1147 */       sQLException.fillInStackTrace();
/* 1148 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1152 */     Accessor accessor = null;
/* 1153 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1158 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1159 */       sQLException.fillInStackTrace();
/* 1160 */       throw sQLException;
/*      */     } 
/*      */     
/* 1163 */     this.lastIndex = paramInt;
/*      */     
/* 1165 */     if (this.streamList != null) {
/* 1166 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1169 */     return accessor.getBLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 1179 */     if (this.closed) {
/*      */       
/* 1181 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1182 */       sQLException.fillInStackTrace();
/* 1183 */       throw sQLException;
/*      */     } 
/*      */     
/* 1186 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1189 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1190 */       sQLException.fillInStackTrace();
/* 1191 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1195 */     Accessor accessor = null;
/* 1196 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1201 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1202 */       sQLException.fillInStackTrace();
/* 1203 */       throw sQLException;
/*      */     } 
/*      */     
/* 1206 */     this.lastIndex = paramInt;
/*      */     
/* 1208 */     if (this.streamList != null) {
/* 1209 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1212 */     return accessor.getCLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 1222 */     if (this.closed) {
/*      */       
/* 1224 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1225 */       sQLException.fillInStackTrace();
/* 1226 */       throw sQLException;
/*      */     } 
/*      */     
/* 1229 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1232 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1233 */       sQLException.fillInStackTrace();
/* 1234 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1238 */     Accessor accessor = null;
/* 1239 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1244 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1245 */       sQLException.fillInStackTrace();
/* 1246 */       throw sQLException;
/*      */     } 
/*      */     
/* 1249 */     this.lastIndex = paramInt;
/*      */     
/* 1251 */     if (this.streamList != null) {
/* 1252 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1255 */     return accessor.getBFILE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 1265 */     if (this.closed) {
/*      */       
/* 1267 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1268 */       sQLException.fillInStackTrace();
/* 1269 */       throw sQLException;
/*      */     } 
/*      */     
/* 1272 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1275 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1276 */       sQLException.fillInStackTrace();
/* 1277 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1281 */     Accessor accessor = null;
/* 1282 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1287 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1288 */       sQLException.fillInStackTrace();
/* 1289 */       throw sQLException;
/*      */     } 
/*      */     
/* 1292 */     this.lastIndex = paramInt;
/*      */     
/* 1294 */     if (this.streamList != null) {
/* 1295 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1298 */     return accessor.getBFILE(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/* 1308 */     if (this.closed) {
/*      */       
/* 1310 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1311 */       sQLException.fillInStackTrace();
/* 1312 */       throw sQLException;
/*      */     } 
/*      */     
/* 1315 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1318 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1319 */       sQLException.fillInStackTrace();
/* 1320 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1324 */     Accessor accessor = null;
/* 1325 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1330 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1331 */       sQLException.fillInStackTrace();
/* 1332 */       throw sQLException;
/*      */     } 
/*      */     
/* 1335 */     this.lastIndex = paramInt;
/*      */     
/* 1337 */     if (this.streamList != null) {
/* 1338 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1341 */     return accessor.getBoolean(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/* 1351 */     if (this.closed) {
/*      */       
/* 1353 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1354 */       sQLException.fillInStackTrace();
/* 1355 */       throw sQLException;
/*      */     } 
/*      */     
/* 1358 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1361 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1362 */       sQLException.fillInStackTrace();
/* 1363 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1367 */     Accessor accessor = null;
/* 1368 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1373 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1374 */       sQLException.fillInStackTrace();
/* 1375 */       throw sQLException;
/*      */     } 
/*      */     
/* 1378 */     this.lastIndex = paramInt;
/*      */     
/* 1380 */     if (this.streamList != null) {
/* 1381 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1384 */     return accessor.getByte(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/* 1394 */     if (this.closed) {
/*      */       
/* 1396 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1397 */       sQLException.fillInStackTrace();
/* 1398 */       throw sQLException;
/*      */     } 
/*      */     
/* 1401 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1404 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1405 */       sQLException.fillInStackTrace();
/* 1406 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1410 */     Accessor accessor = null;
/* 1411 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1416 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1417 */       sQLException.fillInStackTrace();
/* 1418 */       throw sQLException;
/*      */     } 
/*      */     
/* 1421 */     this.lastIndex = paramInt;
/*      */     
/* 1423 */     if (this.streamList != null) {
/* 1424 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1427 */     return accessor.getShort(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/* 1437 */     if (this.closed) {
/*      */       
/* 1439 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1440 */       sQLException.fillInStackTrace();
/* 1441 */       throw sQLException;
/*      */     } 
/*      */     
/* 1444 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1447 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1448 */       sQLException.fillInStackTrace();
/* 1449 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1453 */     Accessor accessor = null;
/* 1454 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1459 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1460 */       sQLException.fillInStackTrace();
/* 1461 */       throw sQLException;
/*      */     } 
/*      */     
/* 1464 */     this.lastIndex = paramInt;
/*      */     
/* 1466 */     if (this.streamList != null) {
/* 1467 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1470 */     return accessor.getInt(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/* 1480 */     if (this.closed) {
/*      */       
/* 1482 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1483 */       sQLException.fillInStackTrace();
/* 1484 */       throw sQLException;
/*      */     } 
/*      */     
/* 1487 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1490 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1491 */       sQLException.fillInStackTrace();
/* 1492 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1496 */     Accessor accessor = null;
/* 1497 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1502 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1503 */       sQLException.fillInStackTrace();
/* 1504 */       throw sQLException;
/*      */     } 
/*      */     
/* 1507 */     this.lastIndex = paramInt;
/*      */     
/* 1509 */     if (this.streamList != null) {
/* 1510 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1513 */     return accessor.getLong(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/* 1523 */     if (this.closed) {
/*      */       
/* 1525 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1526 */       sQLException.fillInStackTrace();
/* 1527 */       throw sQLException;
/*      */     } 
/*      */     
/* 1530 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1533 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1534 */       sQLException.fillInStackTrace();
/* 1535 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1539 */     Accessor accessor = null;
/* 1540 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1545 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1546 */       sQLException.fillInStackTrace();
/* 1547 */       throw sQLException;
/*      */     } 
/*      */     
/* 1550 */     this.lastIndex = paramInt;
/*      */     
/* 1552 */     if (this.streamList != null) {
/* 1553 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1556 */     return accessor.getFloat(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/* 1566 */     if (this.closed) {
/*      */       
/* 1568 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1569 */       sQLException.fillInStackTrace();
/* 1570 */       throw sQLException;
/*      */     } 
/*      */     
/* 1573 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1576 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1577 */       sQLException.fillInStackTrace();
/* 1578 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1582 */     Accessor accessor = null;
/* 1583 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1588 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1589 */       sQLException.fillInStackTrace();
/* 1590 */       throw sQLException;
/*      */     } 
/*      */     
/* 1593 */     this.lastIndex = paramInt;
/*      */     
/* 1595 */     if (this.streamList != null) {
/* 1596 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1599 */     return accessor.getDouble(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/* 1609 */     if (this.closed) {
/*      */       
/* 1611 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1612 */       sQLException.fillInStackTrace();
/* 1613 */       throw sQLException;
/*      */     } 
/*      */     
/* 1616 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1619 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1620 */       sQLException.fillInStackTrace();
/* 1621 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1625 */     Accessor accessor = null;
/* 1626 */     if (paramInt1 <= 0 || paramInt1 > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt1 - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1631 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1632 */       sQLException.fillInStackTrace();
/* 1633 */       throw sQLException;
/*      */     } 
/*      */     
/* 1636 */     this.lastIndex = paramInt1;
/*      */     
/* 1638 */     if (this.streamList != null) {
/* 1639 */       closeUsedStreams(paramInt1);
/*      */     }
/*      */     
/* 1642 */     return accessor.getBigDecimal(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/* 1652 */     if (this.closed) {
/*      */       
/* 1654 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1655 */       sQLException.fillInStackTrace();
/* 1656 */       throw sQLException;
/*      */     } 
/*      */     
/* 1659 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1662 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1663 */       sQLException.fillInStackTrace();
/* 1664 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1668 */     Accessor accessor = null;
/* 1669 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1674 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1675 */       sQLException.fillInStackTrace();
/* 1676 */       throw sQLException;
/*      */     } 
/*      */     
/* 1679 */     this.lastIndex = paramInt;
/*      */     
/* 1681 */     if (this.streamList != null) {
/* 1682 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1685 */     return accessor.getBytes(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] privateGetBytes(int paramInt) throws SQLException {
/* 1695 */     if (this.closed) {
/*      */       
/* 1697 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1698 */       sQLException.fillInStackTrace();
/* 1699 */       throw sQLException;
/*      */     } 
/*      */     
/* 1702 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1705 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1706 */       sQLException.fillInStackTrace();
/* 1707 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1711 */     Accessor accessor = null;
/* 1712 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1717 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1718 */       sQLException.fillInStackTrace();
/* 1719 */       throw sQLException;
/*      */     } 
/*      */     
/* 1722 */     this.lastIndex = paramInt;
/*      */     
/* 1724 */     if (this.streamList != null) {
/* 1725 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1728 */     return accessor.privateGetBytes(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/* 1738 */     if (this.closed) {
/*      */       
/* 1740 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1741 */       sQLException.fillInStackTrace();
/* 1742 */       throw sQLException;
/*      */     } 
/*      */     
/* 1745 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1748 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1749 */       sQLException.fillInStackTrace();
/* 1750 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1754 */     Accessor accessor = null;
/* 1755 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1760 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1761 */       sQLException.fillInStackTrace();
/* 1762 */       throw sQLException;
/*      */     } 
/*      */     
/* 1765 */     this.lastIndex = paramInt;
/*      */     
/* 1767 */     if (this.streamList != null) {
/* 1768 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1771 */     return accessor.getDate(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/* 1781 */     if (this.closed) {
/*      */       
/* 1783 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1784 */       sQLException.fillInStackTrace();
/* 1785 */       throw sQLException;
/*      */     } 
/*      */     
/* 1788 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1791 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1792 */       sQLException.fillInStackTrace();
/* 1793 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1797 */     Accessor accessor = null;
/* 1798 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1803 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1804 */       sQLException.fillInStackTrace();
/* 1805 */       throw sQLException;
/*      */     } 
/*      */     
/* 1808 */     this.lastIndex = paramInt;
/*      */     
/* 1810 */     if (this.streamList != null) {
/* 1811 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1814 */     return accessor.getTime(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/* 1824 */     if (this.closed) {
/*      */       
/* 1826 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1827 */       sQLException.fillInStackTrace();
/* 1828 */       throw sQLException;
/*      */     } 
/*      */     
/* 1831 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1834 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1835 */       sQLException.fillInStackTrace();
/* 1836 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1840 */     Accessor accessor = null;
/* 1841 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1846 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1847 */       sQLException.fillInStackTrace();
/* 1848 */       throw sQLException;
/*      */     } 
/*      */     
/* 1851 */     this.lastIndex = paramInt;
/*      */     
/* 1853 */     if (this.streamList != null) {
/* 1854 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1857 */     return accessor.getTimestamp(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 1867 */     if (this.closed) {
/*      */       
/* 1869 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1870 */       sQLException.fillInStackTrace();
/* 1871 */       throw sQLException;
/*      */     } 
/*      */     
/* 1874 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1877 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1878 */       sQLException.fillInStackTrace();
/* 1879 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1883 */     Accessor accessor = null;
/* 1884 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1889 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1890 */       sQLException.fillInStackTrace();
/* 1891 */       throw sQLException;
/*      */     } 
/*      */     
/* 1894 */     this.lastIndex = paramInt;
/*      */     
/* 1896 */     if (this.streamList != null) {
/* 1897 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1900 */     return accessor.getAsciiStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 1910 */     if (this.closed) {
/*      */       
/* 1912 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1913 */       sQLException.fillInStackTrace();
/* 1914 */       throw sQLException;
/*      */     } 
/*      */     
/* 1917 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1920 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1921 */       sQLException.fillInStackTrace();
/* 1922 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1926 */     Accessor accessor = null;
/* 1927 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1932 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1933 */       sQLException.fillInStackTrace();
/* 1934 */       throw sQLException;
/*      */     } 
/*      */     
/* 1937 */     this.lastIndex = paramInt;
/*      */     
/* 1939 */     if (this.streamList != null) {
/* 1940 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1943 */     return accessor.getUnicodeStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 1953 */     if (this.closed) {
/*      */       
/* 1955 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1956 */       sQLException.fillInStackTrace();
/* 1957 */       throw sQLException;
/*      */     } 
/*      */     
/* 1960 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 1963 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 1964 */       sQLException.fillInStackTrace();
/* 1965 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1969 */     Accessor accessor = null;
/* 1970 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1975 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1976 */       sQLException.fillInStackTrace();
/* 1977 */       throw sQLException;
/*      */     } 
/*      */     
/* 1980 */     this.lastIndex = paramInt;
/*      */     
/* 1982 */     if (this.streamList != null) {
/* 1983 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 1986 */     return accessor.getBinaryStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/* 1996 */     if (this.closed) {
/*      */       
/* 1998 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1999 */       sQLException.fillInStackTrace();
/* 2000 */       throw sQLException;
/*      */     } 
/*      */     
/* 2003 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2006 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2007 */       sQLException.fillInStackTrace();
/* 2008 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2012 */     Accessor accessor = null;
/* 2013 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2018 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2019 */       sQLException.fillInStackTrace();
/* 2020 */       throw sQLException;
/*      */     } 
/*      */     
/* 2023 */     this.lastIndex = paramInt;
/*      */     
/* 2025 */     if (this.streamList != null) {
/* 2026 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2029 */     return accessor.getObject(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAnyDataEmbeddedObject(int paramInt) throws SQLException {
/* 2038 */     Object object1 = null;
/* 2039 */     Object object2 = getObject(paramInt);
/* 2040 */     if (object2 instanceof ANYDATA) {
/*      */       
/* 2042 */       Datum datum = ((ANYDATA)object2).accessDatum();
/* 2043 */       if (datum != null) object1 = datum.toJdbc(); 
/*      */     } 
/* 2045 */     return object1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 2055 */     if (this.closed) {
/*      */       
/* 2057 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2058 */       sQLException.fillInStackTrace();
/* 2059 */       throw sQLException;
/*      */     } 
/*      */     
/* 2062 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2065 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2066 */       sQLException.fillInStackTrace();
/* 2067 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2071 */     Accessor accessor = null;
/* 2072 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2077 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2078 */       sQLException.fillInStackTrace();
/* 2079 */       throw sQLException;
/*      */     } 
/*      */     
/* 2082 */     this.lastIndex = paramInt;
/*      */     
/* 2084 */     if (this.streamList != null) {
/* 2085 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2088 */     return accessor.getCustomDatum(this.currentRank, paramCustomDatumFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 2097 */     if (this.closed) {
/*      */       
/* 2099 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2100 */       sQLException.fillInStackTrace();
/* 2101 */       throw sQLException;
/*      */     } 
/*      */     
/* 2104 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2107 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2108 */       sQLException.fillInStackTrace();
/* 2109 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2113 */     Accessor accessor = null;
/* 2114 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2119 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2120 */       sQLException.fillInStackTrace();
/* 2121 */       throw sQLException;
/*      */     } 
/*      */     
/* 2124 */     this.lastIndex = paramInt;
/*      */     
/* 2126 */     if (this.streamList != null) {
/* 2127 */       closeUsedStreams(paramInt);
/*      */     }
/* 2129 */     return accessor.getObject(this.currentRank, paramOracleDataFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 2139 */     if (this.closed) {
/*      */       
/* 2141 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2142 */       sQLException.fillInStackTrace();
/* 2143 */       throw sQLException;
/*      */     } 
/*      */     
/* 2146 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2149 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2150 */       sQLException.fillInStackTrace();
/* 2151 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2155 */     Accessor accessor = null;
/* 2156 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2161 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2162 */       sQLException.fillInStackTrace();
/* 2163 */       throw sQLException;
/*      */     } 
/*      */     
/* 2166 */     this.lastIndex = paramInt;
/*      */     
/* 2168 */     if (this.streamList != null) {
/* 2169 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2172 */     return accessor.getORAData(this.currentRank, paramORADataFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/* 2182 */     if (this.closed) {
/*      */       
/* 2184 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2185 */       sQLException.fillInStackTrace();
/* 2186 */       throw sQLException;
/*      */     } 
/*      */     
/* 2189 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2192 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2193 */       sQLException.fillInStackTrace();
/* 2194 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2198 */     Accessor accessor = null;
/* 2199 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2204 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2205 */       sQLException.fillInStackTrace();
/* 2206 */       throw sQLException;
/*      */     } 
/*      */     
/* 2209 */     this.lastIndex = paramInt;
/*      */     
/* 2211 */     if (this.streamList != null) {
/* 2212 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2215 */     return accessor.getCursor(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearParameters() throws SQLException {
/* 2222 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2225 */       super.clearParameters();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 2246 */     if (this.closed) {
/*      */       
/* 2248 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2249 */       sQLException.fillInStackTrace();
/* 2250 */       throw sQLException;
/*      */     } 
/*      */     
/* 2253 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2256 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2257 */       sQLException.fillInStackTrace();
/* 2258 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2262 */     Accessor accessor = null;
/* 2263 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2268 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2269 */       sQLException.fillInStackTrace();
/* 2270 */       throw sQLException;
/*      */     } 
/*      */     
/* 2273 */     this.lastIndex = paramInt;
/*      */     
/* 2275 */     if (this.streamList != null) {
/* 2276 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2279 */     return accessor.getObject(this.currentRank, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 2289 */     if (this.closed) {
/*      */       
/* 2291 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2292 */       sQLException.fillInStackTrace();
/* 2293 */       throw sQLException;
/*      */     } 
/*      */     
/* 2296 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2299 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2300 */       sQLException.fillInStackTrace();
/* 2301 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2305 */     Accessor accessor = null;
/* 2306 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2311 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2312 */       sQLException.fillInStackTrace();
/* 2313 */       throw sQLException;
/*      */     } 
/*      */     
/* 2316 */     this.lastIndex = paramInt;
/*      */     
/* 2318 */     if (this.streamList != null) {
/* 2319 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2322 */     return (Ref)accessor.getREF(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 2332 */     if (this.closed) {
/*      */       
/* 2334 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2335 */       sQLException.fillInStackTrace();
/* 2336 */       throw sQLException;
/*      */     } 
/*      */     
/* 2339 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2342 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2343 */       sQLException.fillInStackTrace();
/* 2344 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2348 */     Accessor accessor = null;
/* 2349 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2354 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2355 */       sQLException.fillInStackTrace();
/* 2356 */       throw sQLException;
/*      */     } 
/*      */     
/* 2359 */     this.lastIndex = paramInt;
/*      */     
/* 2361 */     if (this.streamList != null) {
/* 2362 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2365 */     return (Blob)accessor.getBLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 2375 */     if (this.closed) {
/*      */       
/* 2377 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2378 */       sQLException.fillInStackTrace();
/* 2379 */       throw sQLException;
/*      */     } 
/*      */     
/* 2382 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2385 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2386 */       sQLException.fillInStackTrace();
/* 2387 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2391 */     Accessor accessor = null;
/* 2392 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2397 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2398 */       sQLException.fillInStackTrace();
/* 2399 */       throw sQLException;
/*      */     } 
/*      */     
/* 2402 */     this.lastIndex = paramInt;
/*      */     
/* 2404 */     if (this.streamList != null) {
/* 2405 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2408 */     return (Clob)accessor.getCLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 2418 */     if (this.closed) {
/*      */       
/* 2420 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2421 */       sQLException.fillInStackTrace();
/* 2422 */       throw sQLException;
/*      */     } 
/*      */     
/* 2425 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2428 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2429 */       sQLException.fillInStackTrace();
/* 2430 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2434 */     Accessor accessor = null;
/* 2435 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2440 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2441 */       sQLException.fillInStackTrace();
/* 2442 */       throw sQLException;
/*      */     } 
/*      */     
/* 2445 */     this.lastIndex = paramInt;
/*      */     
/* 2447 */     if (this.streamList != null) {
/* 2448 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2451 */     return (Array)accessor.getARRAY(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 2461 */     if (this.closed) {
/*      */       
/* 2463 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2464 */       sQLException.fillInStackTrace();
/* 2465 */       throw sQLException;
/*      */     } 
/*      */     
/* 2468 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2471 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2472 */       sQLException.fillInStackTrace();
/* 2473 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2477 */     Accessor accessor = null;
/* 2478 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2483 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2484 */       sQLException.fillInStackTrace();
/* 2485 */       throw sQLException;
/*      */     } 
/*      */     
/* 2488 */     this.lastIndex = paramInt;
/*      */     
/* 2490 */     if (this.streamList != null) {
/* 2491 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2494 */     return accessor.getBigDecimal(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2504 */     if (this.closed) {
/*      */       
/* 2506 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2507 */       sQLException.fillInStackTrace();
/* 2508 */       throw sQLException;
/*      */     } 
/*      */     
/* 2511 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2514 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2515 */       sQLException.fillInStackTrace();
/* 2516 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2520 */     Accessor accessor = null;
/* 2521 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2526 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2527 */       sQLException.fillInStackTrace();
/* 2528 */       throw sQLException;
/*      */     } 
/*      */     
/* 2531 */     this.lastIndex = paramInt;
/*      */     
/* 2533 */     if (this.streamList != null) {
/* 2534 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2537 */     return accessor.getDate(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2547 */     if (this.closed) {
/*      */       
/* 2549 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2550 */       sQLException.fillInStackTrace();
/* 2551 */       throw sQLException;
/*      */     } 
/*      */     
/* 2554 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2557 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2558 */       sQLException.fillInStackTrace();
/* 2559 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2563 */     Accessor accessor = null;
/* 2564 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2569 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2570 */       sQLException.fillInStackTrace();
/* 2571 */       throw sQLException;
/*      */     } 
/*      */     
/* 2574 */     this.lastIndex = paramInt;
/*      */     
/* 2576 */     if (this.streamList != null) {
/* 2577 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2580 */     return accessor.getTime(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2590 */     if (this.closed) {
/*      */       
/* 2592 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2593 */       sQLException.fillInStackTrace();
/* 2594 */       throw sQLException;
/*      */     } 
/*      */     
/* 2597 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2600 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2601 */       sQLException.fillInStackTrace();
/* 2602 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2606 */     Accessor accessor = null;
/* 2607 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2612 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2613 */       sQLException.fillInStackTrace();
/* 2614 */       throw sQLException;
/*      */     } 
/*      */     
/* 2617 */     this.lastIndex = paramInt;
/*      */     
/* 2619 */     if (this.streamList != null) {
/* 2620 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2623 */     return accessor.getTimestamp(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBatch() throws SQLException {
/* 2669 */     if (this.currentRowBindAccessors != null) {
/*      */ 
/*      */       
/* 2672 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Stored procedure with out or inout parameters cannot be batched");
/* 2673 */       sQLException.fillInStackTrace();
/* 2674 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2678 */     super.addBatch();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void alwaysOnClose() throws SQLException {
/* 2688 */     this.sqlObject.resetNamedParameters();
/*      */ 
/*      */     
/* 2691 */     this.namedParameters = new String[8];
/* 2692 */     this.parameterCount = 0;
/* 2693 */     this.atLeastOneOrdinalParameter = false;
/* 2694 */     this.atLeastOneNamedParameter = false;
/*      */     
/* 2696 */     super.alwaysOnClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt) throws SQLException {
/* 2733 */     registerOutParameterInternal(paramString, paramInt, 0, -1, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 2766 */     registerOutParameterInternal(paramString, paramInt1, paramInt2, -1, (String)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 2811 */     registerOutParameterInternal(paramString1, paramInt, 0, -1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void registerOutParameterInternal(String paramString1, int paramInt1, int paramInt2, int paramInt3, String paramString2) throws SQLException {
/* 2819 */     int i = addNamedPara(paramString1);
/* 2820 */     registerOutParameterInternal(i, paramInt1, paramInt2, paramInt3, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 2845 */     if (this.closed) {
/*      */       
/* 2847 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2848 */       sQLException.fillInStackTrace();
/* 2849 */       throw sQLException;
/*      */     } 
/*      */     
/* 2852 */     if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 2855 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 2856 */       sQLException.fillInStackTrace();
/* 2857 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2861 */     Accessor accessor = null;
/* 2862 */     if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2867 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2868 */       sQLException.fillInStackTrace();
/* 2869 */       throw sQLException;
/*      */     } 
/*      */     
/* 2872 */     this.lastIndex = paramInt;
/*      */     
/* 2874 */     if (this.streamList != null) {
/* 2875 */       closeUsedStreams(paramInt);
/*      */     }
/*      */     
/* 2878 */     return accessor.getURL(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(String paramString1, String paramString2) throws SQLException {
/* 2905 */     int i = addNamedPara(paramString1);
/* 2906 */     if (paramString2 == null || paramString2.length() == 0) {
/*      */       
/* 2908 */       setNull(i, 2005);
/*      */       return;
/*      */     } 
/* 2911 */     setStringForClob(i, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(int paramInt, String paramString) throws SQLException {
/* 2930 */     if (paramString == null || paramString.length() == 0) {
/*      */       
/* 2932 */       setNull(paramInt, 2005);
/*      */       return;
/*      */     } 
/* 2935 */     synchronized (this.connection) {
/* 2936 */       setStringForClobCritical(paramInt, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 2961 */     int i = addNamedPara(paramString);
/* 2962 */     setBytesForBlob(i, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 2980 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/*      */       
/* 2982 */       setNull(paramInt, 2004);
/*      */       return;
/*      */     } 
/* 2985 */     synchronized (this.connection) {
/* 2986 */       setBytesForBlobCritical(paramInt, paramArrayOfbyte);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String paramString) throws SQLException {
/* 3015 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3018 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3019 */       sQLException.fillInStackTrace();
/* 3020 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3024 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3027 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3029 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3032 */     b++;
/*      */     
/* 3034 */     Accessor accessor = null;
/* 3035 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3040 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3041 */       sQLException.fillInStackTrace();
/* 3042 */       throw sQLException;
/*      */     } 
/*      */     
/* 3045 */     this.lastIndex = b;
/*      */     
/* 3047 */     if (this.streamList != null) {
/* 3048 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3051 */     return accessor.getString(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) throws SQLException {
/* 3072 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3075 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3076 */       sQLException.fillInStackTrace();
/* 3077 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3081 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3084 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3086 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3089 */     b++;
/*      */     
/* 3091 */     Accessor accessor = null;
/* 3092 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3097 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3098 */       sQLException.fillInStackTrace();
/* 3099 */       throw sQLException;
/*      */     } 
/*      */     
/* 3102 */     this.lastIndex = b;
/*      */     
/* 3104 */     if (this.streamList != null) {
/* 3105 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3108 */     return accessor.getBoolean(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) throws SQLException {
/* 3129 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3132 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3133 */       sQLException.fillInStackTrace();
/* 3134 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3138 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3141 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3143 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3146 */     b++;
/*      */     
/* 3148 */     Accessor accessor = null;
/* 3149 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3154 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3155 */       sQLException.fillInStackTrace();
/* 3156 */       throw sQLException;
/*      */     } 
/*      */     
/* 3159 */     this.lastIndex = b;
/*      */     
/* 3161 */     if (this.streamList != null) {
/* 3162 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3165 */     return accessor.getByte(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) throws SQLException {
/* 3186 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3189 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3190 */       sQLException.fillInStackTrace();
/* 3191 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3195 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3198 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3200 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3203 */     b++;
/*      */     
/* 3205 */     Accessor accessor = null;
/* 3206 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3211 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3212 */       sQLException.fillInStackTrace();
/* 3213 */       throw sQLException;
/*      */     } 
/*      */     
/* 3216 */     this.lastIndex = b;
/*      */     
/* 3218 */     if (this.streamList != null) {
/* 3219 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3222 */     return accessor.getShort(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String paramString) throws SQLException {
/* 3244 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3247 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3248 */       sQLException.fillInStackTrace();
/* 3249 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3253 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3256 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3258 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3261 */     b++;
/*      */     
/* 3263 */     Accessor accessor = null;
/* 3264 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3269 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3270 */       sQLException.fillInStackTrace();
/* 3271 */       throw sQLException;
/*      */     } 
/*      */     
/* 3274 */     this.lastIndex = b;
/*      */     
/* 3276 */     if (this.streamList != null) {
/* 3277 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3280 */     return accessor.getInt(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) throws SQLException {
/* 3302 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3305 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3306 */       sQLException.fillInStackTrace();
/* 3307 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3311 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3314 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3316 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3319 */     b++;
/*      */     
/* 3321 */     Accessor accessor = null;
/* 3322 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3327 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3328 */       sQLException.fillInStackTrace();
/* 3329 */       throw sQLException;
/*      */     } 
/*      */     
/* 3332 */     this.lastIndex = b;
/*      */     
/* 3334 */     if (this.streamList != null) {
/* 3335 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3338 */     return accessor.getLong(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) throws SQLException {
/* 3359 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3362 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3363 */       sQLException.fillInStackTrace();
/* 3364 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3368 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3371 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3373 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3376 */     b++;
/*      */     
/* 3378 */     Accessor accessor = null;
/* 3379 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3384 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3385 */       sQLException.fillInStackTrace();
/* 3386 */       throw sQLException;
/*      */     } 
/*      */     
/* 3389 */     this.lastIndex = b;
/*      */     
/* 3391 */     if (this.streamList != null) {
/* 3392 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3395 */     return accessor.getFloat(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) throws SQLException {
/* 3416 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3419 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3420 */       sQLException.fillInStackTrace();
/* 3421 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3425 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3428 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3430 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3433 */     b++;
/*      */     
/* 3435 */     Accessor accessor = null;
/* 3436 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3441 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3442 */       sQLException.fillInStackTrace();
/* 3443 */       throw sQLException;
/*      */     } 
/*      */     
/* 3446 */     this.lastIndex = b;
/*      */     
/* 3448 */     if (this.streamList != null) {
/* 3449 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3452 */     return accessor.getDouble(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String paramString) throws SQLException {
/* 3474 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3477 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3478 */       sQLException.fillInStackTrace();
/* 3479 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3483 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3486 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3488 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3491 */     b++;
/*      */     
/* 3493 */     Accessor accessor = null;
/* 3494 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3499 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3500 */       sQLException.fillInStackTrace();
/* 3501 */       throw sQLException;
/*      */     } 
/*      */     
/* 3504 */     this.lastIndex = b;
/*      */     
/* 3506 */     if (this.streamList != null) {
/* 3507 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3510 */     return accessor.getBytes(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) throws SQLException {
/* 3531 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3534 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3535 */       sQLException.fillInStackTrace();
/* 3536 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3540 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3543 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3545 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3548 */     b++;
/*      */     
/* 3550 */     Accessor accessor = null;
/* 3551 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3556 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3557 */       sQLException.fillInStackTrace();
/* 3558 */       throw sQLException;
/*      */     } 
/*      */     
/* 3561 */     this.lastIndex = b;
/*      */     
/* 3563 */     if (this.streamList != null) {
/* 3564 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3567 */     return accessor.getDate(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString) throws SQLException {
/* 3588 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3591 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3592 */       sQLException.fillInStackTrace();
/* 3593 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3597 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3600 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3602 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3605 */     b++;
/*      */     
/* 3607 */     Accessor accessor = null;
/* 3608 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3613 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3614 */       sQLException.fillInStackTrace();
/* 3615 */       throw sQLException;
/*      */     } 
/*      */     
/* 3618 */     this.lastIndex = b;
/*      */     
/* 3620 */     if (this.streamList != null) {
/* 3621 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3624 */     return accessor.getTime(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString) throws SQLException {
/* 3645 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3648 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3649 */       sQLException.fillInStackTrace();
/* 3650 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3654 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3657 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3659 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3662 */     b++;
/*      */     
/* 3664 */     Accessor accessor = null;
/* 3665 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3670 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3671 */       sQLException.fillInStackTrace();
/* 3672 */       throw sQLException;
/*      */     } 
/*      */     
/* 3675 */     this.lastIndex = b;
/*      */     
/* 3677 */     if (this.streamList != null) {
/* 3678 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3681 */     return accessor.getTimestamp(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString) throws SQLException {
/* 3709 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3712 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3713 */       sQLException.fillInStackTrace();
/* 3714 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3718 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3721 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3723 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3726 */     b++;
/*      */     
/* 3728 */     Accessor accessor = null;
/* 3729 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3734 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3735 */       sQLException.fillInStackTrace();
/* 3736 */       throw sQLException;
/*      */     } 
/*      */     
/* 3739 */     this.lastIndex = b;
/*      */     
/* 3741 */     if (this.streamList != null) {
/* 3742 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3745 */     return accessor.getObject(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLException {
/* 3767 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3770 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3771 */       sQLException.fillInStackTrace();
/* 3772 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3776 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3779 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3781 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3784 */     b++;
/*      */     
/* 3786 */     Accessor accessor = null;
/* 3787 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3792 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3793 */       sQLException.fillInStackTrace();
/* 3794 */       throw sQLException;
/*      */     } 
/*      */     
/* 3797 */     this.lastIndex = b;
/*      */     
/* 3799 */     if (this.streamList != null) {
/* 3800 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3803 */     return accessor.getBigDecimal(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/* 3812 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3815 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3816 */       sQLException.fillInStackTrace();
/* 3817 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3821 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3824 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3826 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3829 */     b++;
/*      */     
/* 3831 */     Accessor accessor = null;
/* 3832 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3837 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3838 */       sQLException.fillInStackTrace();
/* 3839 */       throw sQLException;
/*      */     } 
/*      */     
/* 3842 */     this.lastIndex = b;
/*      */     
/* 3844 */     if (this.streamList != null) {
/* 3845 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3848 */     return accessor.getBigDecimal(this.currentRank, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, Map paramMap) throws SQLException {
/* 3876 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3879 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3880 */       sQLException.fillInStackTrace();
/* 3881 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3885 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3888 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3890 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3893 */     b++;
/*      */     
/* 3895 */     Accessor accessor = null;
/* 3896 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3901 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3902 */       sQLException.fillInStackTrace();
/* 3903 */       throw sQLException;
/*      */     } 
/*      */     
/* 3906 */     this.lastIndex = b;
/*      */     
/* 3908 */     if (this.streamList != null) {
/* 3909 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3912 */     return accessor.getObject(this.currentRank, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(String paramString) throws SQLException {
/* 3934 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3937 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3938 */       sQLException.fillInStackTrace();
/* 3939 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3943 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 3946 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 3948 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 3951 */     b++;
/*      */     
/* 3953 */     Accessor accessor = null;
/* 3954 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3959 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3960 */       sQLException.fillInStackTrace();
/* 3961 */       throw sQLException;
/*      */     } 
/*      */     
/* 3964 */     this.lastIndex = b;
/*      */     
/* 3966 */     if (this.streamList != null) {
/* 3967 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 3970 */     return (Ref)accessor.getREF(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(String paramString) throws SQLException {
/* 3992 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 3995 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 3996 */       sQLException.fillInStackTrace();
/* 3997 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4001 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4004 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4006 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4009 */     b++;
/*      */     
/* 4011 */     Accessor accessor = null;
/* 4012 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4017 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4018 */       sQLException.fillInStackTrace();
/* 4019 */       throw sQLException;
/*      */     } 
/*      */     
/* 4022 */     this.lastIndex = b;
/*      */     
/* 4024 */     if (this.streamList != null) {
/* 4025 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4028 */     return (Blob)accessor.getBLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(String paramString) throws SQLException {
/* 4049 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4052 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4053 */       sQLException.fillInStackTrace();
/* 4054 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4058 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4061 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4063 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4066 */     b++;
/*      */     
/* 4068 */     Accessor accessor = null;
/* 4069 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4074 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4075 */       sQLException.fillInStackTrace();
/* 4076 */       throw sQLException;
/*      */     } 
/*      */     
/* 4079 */     this.lastIndex = b;
/*      */     
/* 4081 */     if (this.streamList != null) {
/* 4082 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4085 */     return (Clob)accessor.getCLOB(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(String paramString) throws SQLException {
/* 4107 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4110 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4111 */       sQLException.fillInStackTrace();
/* 4112 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4116 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4119 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4121 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4124 */     b++;
/*      */     
/* 4126 */     Accessor accessor = null;
/* 4127 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4132 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4133 */       sQLException.fillInStackTrace();
/* 4134 */       throw sQLException;
/*      */     } 
/*      */     
/* 4137 */     this.lastIndex = b;
/*      */     
/* 4139 */     if (this.streamList != null) {
/* 4140 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4143 */     return (Array)accessor.getARRAY(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
/* 4173 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4176 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4177 */       sQLException.fillInStackTrace();
/* 4178 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4182 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4185 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4187 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4190 */     b++;
/*      */     
/* 4192 */     Accessor accessor = null;
/* 4193 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4198 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4199 */       sQLException.fillInStackTrace();
/* 4200 */       throw sQLException;
/*      */     } 
/*      */     
/* 4203 */     this.lastIndex = b;
/*      */     
/* 4205 */     if (this.streamList != null) {
/* 4206 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4209 */     return accessor.getDate(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
/* 4239 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4242 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4243 */       sQLException.fillInStackTrace();
/* 4244 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4248 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4251 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4253 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4256 */     b++;
/*      */     
/* 4258 */     Accessor accessor = null;
/* 4259 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4264 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4265 */       sQLException.fillInStackTrace();
/* 4266 */       throw sQLException;
/*      */     } 
/*      */     
/* 4269 */     this.lastIndex = b;
/*      */     
/* 4271 */     if (this.streamList != null) {
/* 4272 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4275 */     return accessor.getTime(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
/* 4306 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4309 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4310 */       sQLException.fillInStackTrace();
/* 4311 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4315 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4318 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4320 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4323 */     b++;
/*      */     
/* 4325 */     Accessor accessor = null;
/* 4326 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4331 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4332 */       sQLException.fillInStackTrace();
/* 4333 */       throw sQLException;
/*      */     } 
/*      */     
/* 4336 */     this.lastIndex = b;
/*      */     
/* 4338 */     if (this.streamList != null) {
/* 4339 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4342 */     return accessor.getTimestamp(this.currentRank, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String paramString) throws SQLException {
/* 4366 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 4369 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4370 */       sQLException.fillInStackTrace();
/* 4371 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4375 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 4378 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 4380 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 4383 */     b++;
/*      */     
/* 4385 */     Accessor accessor = null;
/* 4386 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4391 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 4392 */       sQLException.fillInStackTrace();
/* 4393 */       throw sQLException;
/*      */     } 
/*      */     
/* 4396 */     this.lastIndex = b;
/*      */     
/* 4398 */     if (this.streamList != null) {
/* 4399 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 4402 */     return accessor.getURL(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String paramString) throws SQLException {
/* 4412 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 4413 */     sQLException.fillInStackTrace();
/* 4414 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 4453 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 4456 */       int i = paramInt1 - 1;
/* 4457 */       if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*      */         
/* 4459 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 4460 */         sQLException.fillInStackTrace();
/* 4461 */         throw sQLException;
/*      */       } 
/*      */       
/* 4464 */       int j = getInternalType(paramInt3);
/*      */       
/* 4466 */       resetBatch();
/* 4467 */       this.currentRowNeedToPrepareBinds = true;
/*      */       
/* 4469 */       if (this.currentRowBindAccessors == null) {
/* 4470 */         this.currentRowBindAccessors = new Accessor[this.numberOfBindPositions];
/*      */       }
/* 4472 */       this.currentRowBindAccessors[i] = allocateIndexTableAccessor(paramInt3, j, paramInt4, paramInt2, this.currentRowFormOfUse[i], true);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4480 */       this.hasIbtBind = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   PlsqlIndexTableAccessor allocateIndexTableAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, boolean paramBoolean) throws SQLException {
/* 4497 */     return new PlsqlIndexTableAccessor(this, paramInt1, paramInt2, paramInt3, paramInt4, paramShort, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt) throws SQLException {
/* 4521 */     synchronized (this.connection) {
/*      */       BigDecimal[] arrayOfBigDecimal;
/*      */       SQLException sQLException;
/* 4524 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*      */       
/* 4526 */       PlsqlIndexTableAccessor plsqlIndexTableAccessor = (PlsqlIndexTableAccessor)this.outBindAccessors[paramInt - 1];
/*      */ 
/*      */       
/* 4529 */       int i = plsqlIndexTableAccessor.elementInternalType;
/*      */       
/* 4531 */       String[] arrayOfString = null;
/*      */       
/* 4533 */       switch (i) {
/*      */         
/*      */         case 9:
/* 4536 */           arrayOfString = new String[arrayOfDatum.length];
/*      */           break;
/*      */         case 6:
/* 4539 */           arrayOfBigDecimal = new BigDecimal[arrayOfDatum.length];
/*      */           break;
/*      */         
/*      */         default:
/* 4543 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Invalid column type");
/* 4544 */           sQLException.fillInStackTrace();
/* 4545 */           throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 4549 */       for (byte b = 0; b < arrayOfBigDecimal.length; b++) {
/* 4550 */         arrayOfBigDecimal[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (BigDecimal)arrayOfDatum[b].toJdbc() : null;
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 4555 */       return arrayOfBigDecimal;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt, Class paramClass) throws SQLException {
/* 4575 */     synchronized (this.connection) {
/*      */       
/* 4577 */       Datum[] arrayOfDatum = getOraclePlsqlIndexTable(paramInt);
/*      */       
/* 4579 */       if (paramClass == null || !paramClass.isPrimitive()) {
/*      */         
/* 4581 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4582 */         sQLException1.fillInStackTrace();
/* 4583 */         throw sQLException1;
/*      */       } 
/*      */       
/* 4586 */       String str = paramClass.getName();
/*      */       
/* 4588 */       if (str.equals("byte")) {
/*      */         
/* 4590 */         byte[] arrayOfByte = new byte[arrayOfDatum.length];
/* 4591 */         for (byte b = 0; b < arrayOfDatum.length; b++)
/* 4592 */           arrayOfByte[b] = (arrayOfDatum[b] != null) ? arrayOfDatum[b].byteValue() : 0; 
/* 4593 */         return arrayOfByte;
/*      */       } 
/* 4595 */       if (str.equals("char")) {
/*      */         
/* 4597 */         char[] arrayOfChar = new char[arrayOfDatum.length];
/* 4598 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4599 */           arrayOfChar[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (char)arrayOfDatum[b].intValue() : Character.MIN_VALUE;
/*      */         }
/* 4601 */         return arrayOfChar;
/*      */       } 
/* 4603 */       if (str.equals("double")) {
/*      */         
/* 4605 */         double[] arrayOfDouble = new double[arrayOfDatum.length];
/* 4606 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4607 */           arrayOfDouble[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].doubleValue() : 0.0D;
/*      */         }
/* 4609 */         return arrayOfDouble;
/*      */       } 
/* 4611 */       if (str.equals("float")) {
/*      */         
/* 4613 */         float[] arrayOfFloat = new float[arrayOfDatum.length];
/* 4614 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4615 */           arrayOfFloat[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].floatValue() : 0.0F;
/*      */         }
/* 4617 */         return arrayOfFloat;
/*      */       } 
/* 4619 */       if (str.equals("int")) {
/*      */         
/* 4621 */         int[] arrayOfInt = new int[arrayOfDatum.length];
/* 4622 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4623 */           arrayOfInt[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].intValue() : 0;
/*      */         }
/* 4625 */         return arrayOfInt;
/*      */       } 
/* 4627 */       if (str.equals("long")) {
/*      */         
/* 4629 */         long[] arrayOfLong = new long[arrayOfDatum.length];
/* 4630 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4631 */           arrayOfLong[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].longValue() : 0L;
/*      */         }
/* 4633 */         return arrayOfLong;
/*      */       } 
/* 4635 */       if (str.equals("short")) {
/*      */         
/* 4637 */         short[] arrayOfShort = new short[arrayOfDatum.length];
/* 4638 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4639 */           arrayOfShort[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? (short)arrayOfDatum[b].intValue() : 0;
/*      */         }
/* 4641 */         return arrayOfShort;
/*      */       } 
/* 4643 */       if (str.equals("boolean")) {
/*      */         
/* 4645 */         boolean[] arrayOfBoolean = new boolean[arrayOfDatum.length];
/* 4646 */         for (byte b = 0; b < arrayOfDatum.length; b++) {
/* 4647 */           arrayOfBoolean[b] = (arrayOfDatum[b] != null && arrayOfDatum[b].getLength() != 0L) ? arrayOfDatum[b].booleanValue() : false;
/*      */         }
/* 4649 */         return arrayOfBoolean;
/*      */       } 
/*      */ 
/*      */       
/* 4653 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 4654 */       sQLException.fillInStackTrace();
/* 4655 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/* 4673 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4677 */       if (this.closed) {
/*      */         
/* 4679 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4680 */         sQLException.fillInStackTrace();
/* 4681 */         throw sQLException;
/*      */       } 
/*      */       
/* 4684 */       if (this.atLeastOneNamedParameter) {
/*      */ 
/*      */         
/* 4687 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4688 */         sQLException.fillInStackTrace();
/* 4689 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 4693 */       Accessor accessor = null;
/* 4694 */       if (paramInt <= 0 || paramInt > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[paramInt - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4699 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 4700 */         sQLException.fillInStackTrace();
/* 4701 */         throw sQLException;
/*      */       } 
/*      */       
/* 4704 */       this.lastIndex = paramInt;
/*      */       
/* 4706 */       if (this.streamList != null) {
/* 4707 */         closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 4710 */       return accessor.getOraclePlsqlIndexTable(this.currentRank);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute() throws SQLException {
/* 4725 */     synchronized (this.connection) {
/* 4726 */       ensureOpen();
/* 4727 */       if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
/*      */         
/* 4729 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4730 */         sQLException.fillInStackTrace();
/* 4731 */         throw sQLException;
/*      */       } 
/* 4733 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/* 4734 */         this.needToParse = true; 
/* 4735 */       return super.execute();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate() throws SQLException {
/* 4749 */     synchronized (this.connection) {
/*      */       
/* 4751 */       ensureOpen();
/* 4752 */       if (this.atLeastOneNamedParameter && this.atLeastOneOrdinalParameter) {
/*      */         
/* 4754 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 4755 */         sQLException.fillInStackTrace();
/* 4756 */         throw sQLException;
/*      */       } 
/* 4758 */       if (this.sqlObject.setNamedParameters(this.parameterCount, this.namedParameters))
/* 4759 */         this.needToParse = true; 
/* 4760 */       return super.executeUpdate();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/* 4767 */     if (this.outBindAccessors != null) {
/*      */       
/* 4769 */       int i = this.outBindAccessors.length;
/*      */       
/* 4771 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 4773 */         if (this.outBindAccessors[b] != null) {
/*      */           
/* 4775 */           (this.outBindAccessors[b]).rowSpaceByte = null;
/* 4776 */           (this.outBindAccessors[b]).rowSpaceChar = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 4781 */     super.releaseBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doLocalInitialization() {
/* 4788 */     if (this.outBindAccessors != null) {
/*      */       
/* 4790 */       int i = this.outBindAccessors.length;
/*      */       
/* 4792 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 4794 */         if (this.outBindAccessors[b] != null) {
/*      */           
/* 4796 */           (this.outBindAccessors[b]).rowSpaceByte = this.bindBytes;
/* 4797 */           (this.outBindAccessors[b]).rowSpaceChar = this.bindChars;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(int paramInt, Array paramArray) throws SQLException {
/* 4812 */     this.atLeastOneOrdinalParameter = true;
/* 4813 */     setArrayInternal(paramInt, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/* 4820 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4824 */       this.atLeastOneOrdinalParameter = true;
/* 4825 */       setBigDecimalInternal(paramInt, paramBigDecimal);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, Blob paramBlob) throws SQLException {
/* 4833 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4837 */       this.atLeastOneOrdinalParameter = true;
/* 4838 */       setBlobInternal(paramInt, paramBlob);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/* 4846 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4850 */       this.atLeastOneOrdinalParameter = true;
/* 4851 */       setBooleanInternal(paramInt, paramBoolean);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(int paramInt, byte paramByte) throws SQLException {
/* 4859 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4863 */       this.atLeastOneOrdinalParameter = true;
/* 4864 */       setByteInternal(paramInt, paramByte);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 4872 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4876 */       this.atLeastOneOrdinalParameter = true;
/* 4877 */       setBytesInternal(paramInt, paramArrayOfbyte);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Clob paramClob) throws SQLException {
/* 4885 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4889 */       this.atLeastOneOrdinalParameter = true;
/* 4890 */       setClobInternal(paramInt, paramClob);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate) throws SQLException {
/* 4898 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4902 */       this.atLeastOneOrdinalParameter = true;
/* 4903 */       setDateInternal(paramInt, paramDate);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 4911 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4915 */       this.atLeastOneOrdinalParameter = true;
/* 4916 */       setDateInternal(paramInt, paramDate, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(int paramInt, double paramDouble) throws SQLException {
/* 4924 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4928 */       this.atLeastOneOrdinalParameter = true;
/* 4929 */       setDoubleInternal(paramInt, paramDouble);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(int paramInt, float paramFloat) throws SQLException {
/* 4937 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4941 */       this.atLeastOneOrdinalParameter = true;
/* 4942 */       setFloatInternal(paramInt, paramFloat);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(int paramInt1, int paramInt2) throws SQLException {
/* 4950 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4954 */       this.atLeastOneOrdinalParameter = true;
/* 4955 */       setIntInternal(paramInt1, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(int paramInt, long paramLong) throws SQLException {
/* 4963 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 4967 */       this.atLeastOneOrdinalParameter = true;
/* 4968 */       setLongInternal(paramInt, paramLong);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt, Object paramObject) throws SQLException {
/* 4977 */     this.atLeastOneOrdinalParameter = true;
/* 4978 */     setObjectInternal(paramInt, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/* 4986 */     this.atLeastOneOrdinalParameter = true;
/* 4987 */     setObjectInternal(paramInt1, paramObject, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(int paramInt, Ref paramRef) throws SQLException {
/* 4995 */     this.atLeastOneOrdinalParameter = true;
/* 4996 */     setRefInternal(paramInt, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(int paramInt, short paramShort) throws SQLException {
/* 5003 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5007 */       this.atLeastOneOrdinalParameter = true;
/* 5008 */       setShortInternal(paramInt, paramShort);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(int paramInt, String paramString) throws SQLException {
/* 5016 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5020 */       this.atLeastOneOrdinalParameter = true;
/* 5021 */       setStringInternal(paramInt, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime) throws SQLException {
/* 5029 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5033 */       this.atLeastOneOrdinalParameter = true;
/* 5034 */       setTimeInternal(paramInt, paramTime);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 5042 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5046 */       this.atLeastOneOrdinalParameter = true;
/* 5047 */       setTimeInternal(paramInt, paramTime, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/* 5055 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5059 */       this.atLeastOneOrdinalParameter = true;
/* 5060 */       setTimestampInternal(paramInt, paramTimestamp);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 5068 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5072 */       this.atLeastOneOrdinalParameter = true;
/* 5073 */       setTimestampInternal(paramInt, paramTimestamp, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/* 5081 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5085 */       this.atLeastOneOrdinalParameter = true;
/* 5086 */       setURLInternal(paramInt, paramURL);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
/* 5095 */     this.atLeastOneOrdinalParameter = true;
/* 5096 */     setARRAYInternal(paramInt, paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
/* 5103 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5107 */       this.atLeastOneOrdinalParameter = true;
/* 5108 */       setBFILEInternal(paramInt, paramBFILE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException {
/* 5116 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5120 */       this.atLeastOneOrdinalParameter = true;
/* 5121 */       setBfileInternal(paramInt, paramBFILE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException {
/* 5129 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5133 */       this.atLeastOneOrdinalParameter = true;
/* 5134 */       setBinaryFloatInternal(paramInt, paramFloat);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 5142 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5146 */       this.atLeastOneOrdinalParameter = true;
/* 5147 */       setBinaryFloatInternal(paramInt, paramBINARY_FLOAT);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException {
/* 5155 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5159 */       this.atLeastOneOrdinalParameter = true;
/* 5160 */       setBinaryDoubleInternal(paramInt, paramDouble);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 5168 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5172 */       this.atLeastOneOrdinalParameter = true;
/* 5173 */       setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
/* 5181 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5185 */       this.atLeastOneOrdinalParameter = true;
/* 5186 */       setBLOBInternal(paramInt, paramBLOB);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
/* 5194 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5198 */       this.atLeastOneOrdinalParameter = true;
/* 5199 */       setCHARInternal(paramInt, paramCHAR);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
/* 5207 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5211 */       this.atLeastOneOrdinalParameter = true;
/* 5212 */       setCLOBInternal(paramInt, paramCLOB);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException {
/* 5220 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5224 */       this.atLeastOneOrdinalParameter = true;
/* 5225 */       setCursorInternal(paramInt, paramResultSet);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
/* 5234 */     this.atLeastOneOrdinalParameter = true;
/* 5235 */     setCustomDatumInternal(paramInt, paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(int paramInt, DATE paramDATE) throws SQLException {
/* 5242 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5246 */       this.atLeastOneOrdinalParameter = true;
/* 5247 */       setDATEInternal(paramInt, paramDATE);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(int paramInt, String paramString) throws SQLException {
/* 5255 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5259 */       this.atLeastOneOrdinalParameter = true;
/* 5260 */       setFixedCHARInternal(paramInt, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
/* 5268 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5272 */       this.atLeastOneOrdinalParameter = true;
/* 5273 */       setINTERVALDSInternal(paramInt, paramINTERVALDS);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
/* 5281 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5285 */       this.atLeastOneOrdinalParameter = true;
/* 5286 */       setINTERVALYMInternal(paramInt, paramINTERVALYM);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
/* 5294 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5298 */       this.atLeastOneOrdinalParameter = true;
/* 5299 */       setNUMBERInternal(paramInt, paramNUMBER);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
/* 5308 */     this.atLeastOneOrdinalParameter = true;
/* 5309 */     setOPAQUEInternal(paramInt, paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException {
/* 5317 */     this.atLeastOneOrdinalParameter = true;
/* 5318 */     setOracleObjectInternal(paramInt, paramDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(int paramInt, ORAData paramORAData) throws SQLException {
/* 5326 */     this.atLeastOneOrdinalParameter = true;
/* 5327 */     setORADataInternal(paramInt, paramORAData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(int paramInt, RAW paramRAW) throws SQLException {
/* 5334 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5338 */       this.atLeastOneOrdinalParameter = true;
/* 5339 */       setRAWInternal(paramInt, paramRAW);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(int paramInt, REF paramREF) throws SQLException {
/* 5348 */     this.atLeastOneOrdinalParameter = true;
/* 5349 */     setREFInternal(paramInt, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(int paramInt, REF paramREF) throws SQLException {
/* 5357 */     this.atLeastOneOrdinalParameter = true;
/* 5358 */     setRefTypeInternal(paramInt, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(int paramInt, ROWID paramROWID) throws SQLException {
/* 5365 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5369 */       this.atLeastOneOrdinalParameter = true;
/* 5370 */       setROWIDInternal(paramInt, paramROWID);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
/* 5379 */     this.atLeastOneOrdinalParameter = true;
/* 5380 */     setSTRUCTInternal(paramInt, paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 5387 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5391 */       this.atLeastOneOrdinalParameter = true;
/* 5392 */       setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 5400 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5404 */       this.atLeastOneOrdinalParameter = true;
/* 5405 */       setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 5413 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5417 */       this.atLeastOneOrdinalParameter = true;
/* 5418 */       setTIMESTAMPInternal(paramInt, paramTIMESTAMP);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 5426 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5430 */       this.atLeastOneOrdinalParameter = true;
/* 5431 */       setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 5439 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5443 */       this.atLeastOneOrdinalParameter = true;
/* 5444 */       setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/* 5452 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5456 */       this.atLeastOneOrdinalParameter = true;
/* 5457 */       setCharacterStreamInternal(paramInt1, paramReader, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 5465 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 5469 */       this.atLeastOneOrdinalParameter = true;
/* 5470 */       setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(String paramString, Array paramArray) throws SQLException {
/* 5482 */     int i = addNamedPara(paramString);
/* 5483 */     setArrayInternal(i, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/* 5493 */     int i = addNamedPara(paramString);
/* 5494 */     setBigDecimalInternal(i, paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, Blob paramBlob) throws SQLException {
/* 5504 */     int i = addNamedPara(paramString);
/* 5505 */     setBlobInternal(i, paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(String paramString, boolean paramBoolean) throws SQLException {
/* 5515 */     int i = addNamedPara(paramString);
/* 5516 */     setBooleanInternal(i, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(String paramString, byte paramByte) throws SQLException {
/* 5526 */     int i = addNamedPara(paramString);
/* 5527 */     setByteInternal(i, paramByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 5537 */     int i = addNamedPara(paramString);
/* 5538 */     setBytesInternal(i, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Clob paramClob) throws SQLException {
/* 5548 */     int i = addNamedPara(paramString);
/* 5549 */     setClobInternal(i, paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate) throws SQLException {
/* 5559 */     int i = addNamedPara(paramString);
/* 5560 */     setDateInternal(i, paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 5570 */     int i = addNamedPara(paramString);
/* 5571 */     setDateInternal(i, paramDate, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(String paramString, double paramDouble) throws SQLException {
/* 5581 */     int i = addNamedPara(paramString);
/* 5582 */     setDoubleInternal(i, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(String paramString, float paramFloat) throws SQLException {
/* 5592 */     int i = addNamedPara(paramString);
/* 5593 */     setFloatInternal(i, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(String paramString, int paramInt) throws SQLException {
/* 5603 */     int i = addNamedPara(paramString);
/* 5604 */     setIntInternal(i, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(String paramString, long paramLong) throws SQLException {
/* 5614 */     int i = addNamedPara(paramString);
/* 5615 */     setLongInternal(i, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject) throws SQLException {
/* 5625 */     int i = addNamedPara(paramString);
/* 5626 */     setObjectInternal(i, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt) throws SQLException {
/* 5636 */     int i = addNamedPara(paramString);
/* 5637 */     setObjectInternal(i, paramObject, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(String paramString, Ref paramRef) throws SQLException {
/* 5647 */     int i = addNamedPara(paramString);
/* 5648 */     setRefInternal(i, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(String paramString, short paramShort) throws SQLException {
/* 5658 */     int i = addNamedPara(paramString);
/* 5659 */     setShortInternal(i, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(String paramString1, String paramString2) throws SQLException {
/* 5669 */     int i = addNamedPara(paramString1);
/* 5670 */     setStringInternal(i, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime) throws SQLException {
/* 5680 */     int i = addNamedPara(paramString);
/* 5681 */     setTimeInternal(i, paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 5691 */     int i = addNamedPara(paramString);
/* 5692 */     setTimeInternal(i, paramTime, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
/* 5702 */     int i = addNamedPara(paramString);
/* 5703 */     setTimestampInternal(i, paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 5713 */     int i = addNamedPara(paramString);
/* 5714 */     setTimestampInternal(i, paramTimestamp, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(String paramString, URL paramURL) throws SQLException {
/* 5724 */     int i = addNamedPara(paramString);
/* 5725 */     setURLInternal(i, paramURL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(String paramString, ARRAY paramARRAY) throws SQLException {
/* 5735 */     int i = addNamedPara(paramString);
/* 5736 */     setARRAYInternal(i, paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(String paramString, BFILE paramBFILE) throws SQLException {
/* 5746 */     int i = addNamedPara(paramString);
/* 5747 */     setBFILEInternal(i, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(String paramString, BFILE paramBFILE) throws SQLException {
/* 5757 */     int i = addNamedPara(paramString);
/* 5758 */     setBfileInternal(i, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, float paramFloat) throws SQLException {
/* 5768 */     int i = addNamedPara(paramString);
/* 5769 */     setBinaryFloatInternal(i, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 5779 */     int i = addNamedPara(paramString);
/* 5780 */     setBinaryFloatInternal(i, paramBINARY_FLOAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, double paramDouble) throws SQLException {
/* 5790 */     int i = addNamedPara(paramString);
/* 5791 */     setBinaryDoubleInternal(i, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 5801 */     int i = addNamedPara(paramString);
/* 5802 */     setBinaryDoubleInternal(i, paramBINARY_DOUBLE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(String paramString, BLOB paramBLOB) throws SQLException {
/* 5812 */     int i = addNamedPara(paramString);
/* 5813 */     setBLOBInternal(i, paramBLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(String paramString, CHAR paramCHAR) throws SQLException {
/* 5823 */     int i = addNamedPara(paramString);
/* 5824 */     setCHARInternal(i, paramCHAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(String paramString, CLOB paramCLOB) throws SQLException {
/* 5834 */     int i = addNamedPara(paramString);
/* 5835 */     setCLOBInternal(i, paramCLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(String paramString, ResultSet paramResultSet) throws SQLException {
/* 5845 */     int i = addNamedPara(paramString);
/* 5846 */     setCursorInternal(i, paramResultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/* 5856 */     int i = addNamedPara(paramString);
/* 5857 */     setCustomDatumInternal(i, paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(String paramString, DATE paramDATE) throws SQLException {
/* 5867 */     int i = addNamedPara(paramString);
/* 5868 */     setDATEInternal(i, paramDATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(String paramString1, String paramString2) throws SQLException {
/* 5878 */     int i = addNamedPara(paramString1);
/* 5879 */     setFixedCHARInternal(i, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/* 5889 */     int i = addNamedPara(paramString);
/* 5890 */     setINTERVALDSInternal(i, paramINTERVALDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/* 5900 */     int i = addNamedPara(paramString);
/* 5901 */     setINTERVALYMInternal(i, paramINTERVALYM);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(String paramString, NUMBER paramNUMBER) throws SQLException {
/* 5911 */     int i = addNamedPara(paramString);
/* 5912 */     setNUMBERInternal(i, paramNUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/* 5922 */     int i = addNamedPara(paramString);
/* 5923 */     setOPAQUEInternal(i, paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(String paramString, Datum paramDatum) throws SQLException {
/* 5933 */     int i = addNamedPara(paramString);
/* 5934 */     setOracleObjectInternal(i, paramDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(String paramString, ORAData paramORAData) throws SQLException {
/* 5944 */     int i = addNamedPara(paramString);
/* 5945 */     setORADataInternal(i, paramORAData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(String paramString, RAW paramRAW) throws SQLException {
/* 5955 */     int i = addNamedPara(paramString);
/* 5956 */     setRAWInternal(i, paramRAW);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(String paramString, REF paramREF) throws SQLException {
/* 5966 */     int i = addNamedPara(paramString);
/* 5967 */     setREFInternal(i, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(String paramString, REF paramREF) throws SQLException {
/* 5977 */     int i = addNamedPara(paramString);
/* 5978 */     setRefTypeInternal(i, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(String paramString, ROWID paramROWID) throws SQLException {
/* 5988 */     int i = addNamedPara(paramString);
/* 5989 */     setROWIDInternal(i, paramROWID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(String paramString, STRUCT paramSTRUCT) throws SQLException {
/* 5999 */     int i = addNamedPara(paramString);
/* 6000 */     setSTRUCTInternal(i, paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 6010 */     int i = addNamedPara(paramString);
/* 6011 */     setTIMESTAMPLTZInternal(i, paramTIMESTAMPLTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 6021 */     int i = addNamedPara(paramString);
/* 6022 */     setTIMESTAMPTZInternal(i, paramTIMESTAMPTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 6032 */     int i = addNamedPara(paramString);
/* 6033 */     setTIMESTAMPInternal(i, paramTIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 6043 */     int i = addNamedPara(paramString);
/* 6044 */     setAsciiStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 6054 */     int i = addNamedPara(paramString);
/* 6055 */     setBinaryStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 6065 */     int i = addNamedPara(paramString);
/* 6066 */     setCharacterStreamInternal(i, paramReader, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 6076 */     int i = addNamedPara(paramString);
/* 6077 */     setUnicodeStreamInternal(i, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 6088 */     int i = addNamedPara(paramString1);
/* 6089 */     setNullInternal(i, paramInt, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString, int paramInt) throws SQLException {
/* 6100 */     int i = addNamedPara(paramString);
/* 6101 */     setNullInternal(i, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
/* 6110 */     int i = addNamedPara(paramString);
/* 6111 */     setStructDescriptorInternal(i, paramStructDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
/* 6122 */     int i = addNamedPara(paramString);
/* 6123 */     setObjectInternal(i, paramObject, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException {
/* 6135 */     synchronized (this.connection) {
/*      */       
/* 6137 */       this.atLeastOneOrdinalParameter = true;
/* 6138 */       setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int addNamedPara(String paramString) throws SQLException {
/* 6156 */     if (this.closed) {
/*      */       
/* 6158 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 6159 */       sQLException.fillInStackTrace();
/* 6160 */       throw sQLException;
/*      */     } 
/*      */     
/* 6163 */     String str = paramString.toUpperCase().intern();
/*      */     
/* 6165 */     for (byte b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6167 */       if (str == this.namedParameters[b]) {
/* 6168 */         return b + 1;
/*      */       }
/*      */     } 
/* 6171 */     if (this.parameterCount >= this.namedParameters.length) {
/*      */       
/* 6173 */       String[] arrayOfString = new String[this.namedParameters.length * 2];
/* 6174 */       System.arraycopy(this.namedParameters, 0, arrayOfString, 0, this.namedParameters.length);
/* 6175 */       this.namedParameters = arrayOfString;
/*      */     } 
/*      */     
/* 6178 */     this.namedParameters[this.parameterCount++] = str;
/*      */     
/* 6180 */     this.atLeastOneNamedParameter = true;
/* 6181 */     return this.parameterCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String paramString) throws SQLException {
/* 6191 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6194 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6195 */       sQLException.fillInStackTrace();
/* 6196 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6200 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6203 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6205 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6208 */     b++;
/*      */     
/* 6210 */     Accessor accessor = null;
/* 6211 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6216 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6217 */       sQLException.fillInStackTrace();
/* 6218 */       throw sQLException;
/*      */     } 
/*      */     
/* 6221 */     this.lastIndex = b;
/*      */     
/* 6223 */     if (this.streamList != null) {
/* 6224 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6227 */     return accessor.getCharacterStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(String paramString) throws SQLException {
/* 6235 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6238 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6239 */       sQLException.fillInStackTrace();
/* 6240 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6244 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6247 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6249 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6252 */     b++;
/*      */     
/* 6254 */     Accessor accessor = null;
/* 6255 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6260 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6261 */       sQLException.fillInStackTrace();
/* 6262 */       throw sQLException;
/*      */     } 
/*      */     
/* 6265 */     this.lastIndex = b;
/*      */     
/* 6267 */     if (this.streamList != null) {
/* 6268 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6271 */     return accessor.getUnicodeStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String paramString) throws SQLException {
/* 6279 */     if (!this.atLeastOneNamedParameter) {
/*      */ 
/*      */       
/* 6282 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "Ordinal binding and Named binding cannot be combined!");
/* 6283 */       sQLException.fillInStackTrace();
/* 6284 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 6288 */     String str = paramString.toUpperCase().intern();
/*      */     
/*      */     byte b;
/* 6291 */     for (b = 0; b < this.parameterCount; b++) {
/*      */       
/* 6293 */       if (str == this.namedParameters[b])
/*      */         break; 
/*      */     } 
/* 6296 */     b++;
/*      */     
/* 6298 */     Accessor accessor = null;
/* 6299 */     if (b <= 0 || b > this.numberOfBindPositions || this.outBindAccessors == null || (accessor = this.outBindAccessors[b - 1]) == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 6304 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 6305 */       sQLException.fillInStackTrace();
/* 6306 */       throw sQLException;
/*      */     } 
/*      */     
/* 6309 */     this.lastIndex = b;
/*      */     
/* 6311 */     if (this.streamList != null) {
/* 6312 */       closeUsedStreams(b);
/*      */     }
/*      */     
/* 6315 */     return accessor.getBinaryStream(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 6324 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/OracleCallableStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */