package oracle.jdbc;

import java.sql.Clob;
import java.sql.SQLException;

public interface OracleClob extends Clob {
  void open(LargeObjectAccessMode paramLargeObjectAccessMode) throws SQLException;
  
  void close() throws SQLException;
  
  boolean isOpen() throws SQLException;
  
  boolean isTemporary() throws SQLException;
  
  boolean isEmptyLob() throws SQLException;
  
  boolean isSecureFile() throws SQLException;
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/OracleClob.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */