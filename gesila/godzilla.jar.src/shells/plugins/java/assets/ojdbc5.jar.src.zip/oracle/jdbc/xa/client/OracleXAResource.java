/*      */ package oracle.jdbc.xa.client;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import javax.transaction.xa.XAException;
/*      */ import javax.transaction.xa.Xid;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.oracore.Util;
/*      */ import oracle.jdbc.xa.OracleXAConnection;
/*      */ import oracle.jdbc.xa.OracleXAException;
/*      */ import oracle.jdbc.xa.OracleXAResource;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleXAResource
/*      */   extends OracleXAResource
/*      */ {
/*   35 */   private short m_version = 0;
/*      */ 
/*      */   
/*      */   private boolean needStackingForCommitRollbackPrepare = false;
/*      */ 
/*      */   
/*   41 */   private static String xa_start_816 = "begin ? := JAVA_XA.xa_start(?,?,?,?); end;";
/*      */   
/*   43 */   private static String xa_start_post_816 = "begin ? := JAVA_XA.xa_start_new(?,?,?,?,?); end;";
/*      */ 
/*      */ 
/*      */   
/*   47 */   private static String xa_end_816 = "begin ? := JAVA_XA.xa_end(?,?); end;";
/*   48 */   private static String xa_end_post_816 = "begin ? := JAVA_XA.xa_end_new(?,?,?,?); end;";
/*      */ 
/*      */   
/*   51 */   private static String xa_commit_816 = "begin ? := JAVA_XA.xa_commit (?,?,?); end;";
/*      */   
/*   53 */   private static String xa_commit_post_816 = "begin ? := JAVA_XA.xa_commit_new (?,?,?,?); end;";
/*      */ 
/*      */   
/*   56 */   private static String xa_prepare_816 = "begin ? := JAVA_XA.xa_prepare (?,?); end;";
/*      */   
/*   58 */   private static String xa_prepare_post_816 = "begin ? := JAVA_XA.xa_prepare_new (?,?,?); end;";
/*      */ 
/*      */   
/*   61 */   private static String xa_rollback_816 = "begin ? := JAVA_XA.xa_rollback (?,?); end;";
/*      */   
/*   63 */   private static String xa_rollback_post_816 = "begin ? := JAVA_XA.xa_rollback_new (?,?,?); end;";
/*      */ 
/*      */   
/*   66 */   private static String xa_forget_816 = "begin ? := JAVA_XA.xa_forget (?,?); end;";
/*      */   
/*   68 */   private static String xa_forget_post_816 = "begin ? := JAVA_XA.xa_forget_new (?,?,?); end;";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isTransLoose = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleXAResource() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleXAResource(Connection paramConnection, OracleXAConnection paramOracleXAConnection) throws XAException {
/*   92 */     super(paramConnection, paramOracleXAConnection);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*   98 */       this.m_version = ((OracleConnection)paramConnection).getVersionNumber();
/*   99 */       this.needStackingForCommitRollbackPrepare = (this.m_version < 9000);
/*      */     }
/*  101 */     catch (SQLException sQLException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  106 */     if (this.m_version < 8170)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  112 */       throw new XAException(-6);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void start(Xid paramXid, int paramInt) throws XAException {
/*  150 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  155 */       int i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  162 */         if (paramXid == null)
/*      */         {
/*      */ 
/*      */           
/*  166 */           throw new XAException(-5);
/*      */         }
/*      */ 
/*      */         
/*  170 */         int j = paramInt & 0xFF00;
/*      */         
/*  172 */         paramInt &= 0xFFFF00FF;
/*      */         
/*  174 */         int k = paramInt & 0x10000 | (this.isTransLoose ? 65536 : 0);
/*      */         
/*  176 */         paramInt &= 0xFFFEFFFF;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  183 */         if ((paramInt & 0x8200002) != paramInt || (k != 0 && (k & 0x10000) != 65536))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  189 */           throw new XAException(-5);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  200 */         if ((j & 0xFF00) != 0 && j != 256 && j != 512 && j != 1024)
/*      */         {
/*      */ 
/*      */ 
/*      */           
/*  205 */           throw new XAException(-5);
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  210 */         if ((paramInt & 0x8200000) != 0 && ((j & 0xFF00) != 0 || (k & 0x10000) != 0))
/*      */         {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  216 */           throw new XAException(-5);
/*      */         }
/*      */ 
/*      */         
/*  220 */         paramInt |= j | k;
/*      */         
/*  222 */         saveAndAlterAutoCommitModeForGlobalTransaction();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         try {
/*  228 */           i = doStart(paramXid, paramInt);
/*      */         }
/*  230 */         catch (SQLException sQLException) {
/*      */ 
/*      */           
/*  233 */           checkError(sQLException, -3);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  240 */         checkError(i);
/*      */ 
/*      */ 
/*      */         
/*  244 */         boolean[] arrayOfBoolean = { false };
/*  245 */         createOrUpdateXid(paramXid, false, arrayOfBoolean);
/*      */ 
/*      */       
/*      */       }
/*  249 */       catch (XAException xAException) {
/*      */         
/*  251 */         restoreAutoCommitModeForGlobalTransaction();
/*      */         
/*  253 */         throw xAException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doStart(Xid paramXid, int paramInt) throws XAException, SQLException {
/*  265 */     int i = -1;
/*  266 */     CallableStatement callableStatement = null;
/*      */ 
/*      */     
/*      */     try {
/*  270 */       callableStatement = this.connection.prepareCall(xa_start_post_816);
/*      */       
/*  272 */       callableStatement.registerOutParameter(1, 2);
/*  273 */       callableStatement.setInt(2, paramXid.getFormatId());
/*  274 */       callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
/*  275 */       callableStatement.setBytes(4, paramXid.getBranchQualifier());
/*  276 */       callableStatement.setInt(5, this.timeout);
/*  277 */       callableStatement.setInt(6, paramInt);
/*      */       
/*  279 */       callableStatement.execute();
/*      */       
/*  281 */       i = callableStatement.getInt(1);
/*      */     }
/*  283 */     catch (SQLException sQLException) {
/*      */       
/*  285 */       i = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  292 */       if (i == 0) {
/*  293 */         throw new XAException(-6);
/*      */       }
/*      */       
/*  296 */       throw sQLException;
/*      */     } finally {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  302 */         if (callableStatement != null) {
/*  303 */           callableStatement.close();
/*      */         }
/*  305 */       } catch (SQLException sQLException) {}
/*      */       
/*  307 */       callableStatement = null;
/*      */     } 
/*      */     
/*  310 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void end(Xid paramXid, int paramInt) throws XAException {
/*  340 */     synchronized (this.connection) {
/*      */       
/*  342 */       int i = -1;
/*  343 */       boolean bool1 = false;
/*  344 */       boolean bool2 = false;
/*      */ 
/*      */       
/*      */       try {
/*  348 */         if (paramXid == null)
/*      */         {
/*      */ 
/*      */           
/*  352 */           throw new XAException(-5);
/*      */         }
/*      */ 
/*      */         
/*  356 */         int j = 638582786;
/*  357 */         if ((paramInt & j) != paramInt)
/*      */         {
/*      */ 
/*      */           
/*  361 */           throw new XAException(-5);
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  372 */         Xid xid = null;
/*  373 */         bool1 = ((paramInt & 0x4000000) != 0) ? true : false;
/*  374 */         bool2 = ((paramInt & 0x20000000) != 0) ? true : false;
/*      */ 
/*      */ 
/*      */         
/*  378 */         if (bool1 || bool2) {
/*  379 */           xid = suspendStacked(paramXid);
/*      */         }
/*      */         
/*      */         try {
/*  383 */           boolean bool = false;
/*  384 */           if (bool1 || bool2) {
/*      */ 
/*      */             
/*  387 */             bool = isXidSuspended(paramXid);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  398 */             if (bool) {
/*  399 */               resumeStacked(paramXid);
/*      */             }
/*      */             
/*  402 */             removeXidFromList(paramXid);
/*  403 */           } else if (paramInt == 33554432) {
/*      */             
/*  405 */             boolean[] arrayOfBoolean = { false };
/*  406 */             createOrUpdateXid(paramXid, true, arrayOfBoolean);
/*      */ 
/*      */             
/*  409 */             bool = arrayOfBoolean[0];
/*      */           } 
/*      */ 
/*      */           
/*  413 */           i = doEnd(paramXid, paramInt, bool);
/*      */         }
/*  415 */         catch (SQLException sQLException) {
/*      */ 
/*      */           
/*  418 */           checkError(sQLException, -3);
/*      */         } 
/*      */         
/*  421 */         if (xid != null) {
/*      */ 
/*      */           
/*  424 */           resumeStacked(xid);
/*  425 */         } else if (isXidListEmpty()) {
/*      */ 
/*      */ 
/*      */           
/*  429 */           exitGlobalTxnMode();
/*  430 */           this.activeXid = null;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  436 */         checkError(i);
/*      */         
/*  438 */         if ((bool1 && paramInt != 67108864) || (bool2 && paramInt != 536870912))
/*      */         {
/*      */           
/*  441 */           throw new XAException(-5);
/*      */         }
/*      */       }
/*      */       finally {
/*      */         
/*  446 */         restoreAutoCommitModeForGlobalTransaction();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doEnd(Xid paramXid, int paramInt, boolean paramBoolean) throws XAException, SQLException {
/*  459 */     CallableStatement callableStatement = null;
/*  460 */     int i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  466 */       callableStatement = this.connection.prepareCall(xa_end_post_816);
/*      */       
/*  468 */       callableStatement.registerOutParameter(1, 2);
/*  469 */       callableStatement.setInt(2, paramXid.getFormatId());
/*  470 */       callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
/*  471 */       callableStatement.setBytes(4, paramXid.getBranchQualifier());
/*  472 */       callableStatement.setInt(5, paramInt);
/*  473 */       callableStatement.execute();
/*      */       
/*  475 */       i = callableStatement.getInt(1);
/*      */     }
/*  477 */     catch (SQLException sQLException) {
/*      */       
/*  479 */       i = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  486 */       if (i == 0) {
/*  487 */         throw new XAException(-6);
/*      */       }
/*      */       
/*  490 */       throw sQLException;
/*      */     } finally {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  496 */         if (callableStatement != null) {
/*  497 */           callableStatement.close();
/*      */         }
/*  499 */       } catch (SQLException sQLException) {}
/*      */       
/*  501 */       callableStatement = null;
/*      */     } 
/*      */     
/*  504 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void commit(Xid paramXid, boolean paramBoolean) throws XAException {
/*  530 */     synchronized (this.connection) {
/*      */       
/*  532 */       if (paramXid == null)
/*      */       {
/*      */ 
/*      */         
/*  536 */         throw new XAException(-5);
/*      */       }
/*      */ 
/*      */       
/*  540 */       Xid xid = null;
/*  541 */       if (this.needStackingForCommitRollbackPrepare) {
/*  542 */         xid = suspendStacked(paramXid);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/*  550 */         removeXidFromList(paramXid);
/*      */         
/*  552 */         if (this.activeXid == null) {
/*  553 */           exitGlobalTxnMode();
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/*      */         try {
/*  560 */           doCommit(paramXid, paramBoolean);
/*      */         }
/*  562 */         catch (SQLException sQLException) {
/*      */ 
/*      */           
/*  565 */           checkError(sQLException, -3);
/*      */         }
/*      */       
/*  568 */       } catch (XAException xAException) {
/*      */         
/*  570 */         if (xAException.errorCode == -7) {
/*      */ 
/*      */           
/*      */           try {
/*  574 */             this.connection.close();
/*  575 */           } catch (SQLException sQLException) {}
/*      */ 
/*      */         
/*      */         }
/*  579 */         else if (this.needStackingForCommitRollbackPrepare) {
/*  580 */           resumeStacked(xid);
/*      */         } 
/*  582 */         throw xAException;
/*      */       } 
/*      */       
/*  585 */       if (this.needStackingForCommitRollbackPrepare) {
/*  586 */         resumeStacked(xid);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doCommit(Xid paramXid, boolean paramBoolean) throws XAException, SQLException {
/*  597 */     CallableStatement callableStatement = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  603 */       callableStatement = this.connection.prepareCall(xa_commit_post_816);
/*      */       
/*  605 */       callableStatement.registerOutParameter(1, 2);
/*  606 */       callableStatement.setInt(2, paramXid.getFormatId());
/*  607 */       callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
/*  608 */       callableStatement.setBytes(4, paramXid.getBranchQualifier());
/*  609 */       callableStatement.setInt(5, paramBoolean ? 1 : 0);
/*      */       
/*  611 */       callableStatement.execute();
/*      */       
/*  613 */       int i = callableStatement.getInt(1);
/*  614 */       checkError(i, -7);
/*      */     }
/*  616 */     catch (SQLException sQLException) {
/*      */       
/*  618 */       int i = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  625 */       if (i == 0) {
/*  626 */         throw new XAException(-6);
/*      */       }
/*      */       
/*  629 */       throw sQLException;
/*      */     } finally {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  635 */         if (callableStatement != null) {
/*  636 */           callableStatement.close();
/*      */         }
/*  638 */       } catch (SQLException sQLException) {}
/*      */       
/*  640 */       callableStatement = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int prepare(Xid paramXid) throws XAException {
/*  665 */     synchronized (this.connection) {
/*      */       
/*  667 */       int i = 0;
/*      */       
/*  669 */       if (paramXid == null)
/*      */       {
/*      */ 
/*      */         
/*  673 */         throw new XAException(-5);
/*      */       }
/*      */ 
/*      */       
/*  677 */       Xid xid = null;
/*  678 */       if (this.needStackingForCommitRollbackPrepare) {
/*  679 */         xid = suspendStacked(paramXid);
/*      */       }
/*      */ 
/*      */       
/*      */       try {
/*      */         try {
/*  685 */           i = doPrepare(paramXid);
/*  686 */           if (i != 0 && i != 3)
/*      */           {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  694 */             int j = OracleXAException.errorConvert(i);
/*      */             
/*  696 */             if (j != 0 && j != 3) {
/*      */               
/*  698 */               XAException xAException = OracleXAException.newXAException(getConnectionDuringExceptionHandling(), i);
/*  699 */               xAException.fillInStackTrace();
/*  700 */               throw xAException;
/*      */             } 
/*      */             
/*  703 */             i = j;
/*      */           }
/*      */         
/*  706 */         } catch (SQLException sQLException) {
/*      */ 
/*      */           
/*  709 */           checkError(sQLException, -3);
/*      */         }
/*      */       
/*  712 */       } catch (XAException xAException) {
/*      */         
/*  714 */         if (xAException.errorCode == -7) {
/*      */ 
/*      */           
/*      */           try {
/*  718 */             this.connection.close();
/*  719 */           } catch (SQLException sQLException) {}
/*      */ 
/*      */         
/*      */         }
/*  723 */         else if (this.needStackingForCommitRollbackPrepare) {
/*  724 */           resumeStacked(xid);
/*      */         } 
/*  726 */         throw xAException;
/*      */       } 
/*      */ 
/*      */       
/*  730 */       if (this.needStackingForCommitRollbackPrepare) {
/*  731 */         resumeStacked(xid);
/*      */       }
/*  733 */       return i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doPrepare(Xid paramXid) throws XAException, SQLException {
/*  743 */     int i = 0;
/*  744 */     CallableStatement callableStatement = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  750 */       callableStatement = this.connection.prepareCall(xa_prepare_post_816);
/*      */       
/*  752 */       callableStatement.registerOutParameter(1, 2);
/*  753 */       callableStatement.setInt(2, paramXid.getFormatId());
/*  754 */       callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
/*  755 */       callableStatement.setBytes(4, paramXid.getBranchQualifier());
/*      */       
/*  757 */       callableStatement.execute();
/*      */       
/*  759 */       i = callableStatement.getInt(1);
/*      */     }
/*  761 */     catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */       
/*  765 */       int j = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  772 */       if (j == 0) {
/*  773 */         throw new XAException(-6);
/*      */       }
/*      */       
/*  776 */       throw sQLException;
/*      */     } finally {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  782 */         if (callableStatement != null) {
/*  783 */           callableStatement.close();
/*      */         }
/*  785 */       } catch (SQLException sQLException) {}
/*      */       
/*  787 */       callableStatement = null;
/*      */     } 
/*  789 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void forget(Xid paramXid) throws XAException {
/*  804 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/*  808 */       int i = 0;
/*      */       
/*  810 */       if (paramXid == null)
/*      */       {
/*      */ 
/*      */         
/*  814 */         throw new XAException(-5);
/*      */       }
/*      */ 
/*      */       
/*  818 */       removeXidFromList(paramXid);
/*      */ 
/*      */       
/*      */       try {
/*  822 */         i = doForget(paramXid);
/*      */       }
/*  824 */       catch (SQLException sQLException) {
/*      */ 
/*      */         
/*  827 */         checkError(sQLException, -3);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  833 */       checkError(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doForget(Xid paramXid) throws XAException, SQLException {
/*  844 */     int i = 0;
/*  845 */     CallableStatement callableStatement = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  851 */       callableStatement = this.connection.prepareCall(xa_forget_post_816);
/*      */       
/*  853 */       callableStatement.registerOutParameter(1, 2);
/*  854 */       callableStatement.setInt(2, paramXid.getFormatId());
/*  855 */       callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
/*  856 */       callableStatement.setBytes(4, paramXid.getBranchQualifier());
/*      */       
/*  858 */       callableStatement.execute();
/*      */       
/*  860 */       i = callableStatement.getInt(1);
/*      */     }
/*  862 */     catch (SQLException sQLException) {
/*      */       
/*  864 */       i = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  871 */       if (i == 0) {
/*  872 */         throw new XAException(-6);
/*      */       }
/*      */       
/*  875 */       throw sQLException;
/*      */     } finally {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  881 */         if (callableStatement != null) {
/*  882 */           callableStatement.close();
/*      */         }
/*  884 */       } catch (SQLException sQLException) {}
/*      */       
/*  886 */       callableStatement = null;
/*      */     } 
/*      */     
/*  889 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rollback(Xid paramXid) throws XAException {
/*  907 */     synchronized (this.connection) {
/*      */       
/*  909 */       boolean bool = false;
/*      */       
/*  911 */       if (paramXid == null)
/*      */       {
/*      */ 
/*      */         
/*  915 */         throw new XAException(-5);
/*      */       }
/*      */ 
/*      */       
/*  919 */       Xid xid = null;
/*  920 */       if (this.needStackingForCommitRollbackPrepare) {
/*  921 */         xid = suspendStacked(paramXid);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/*  929 */         removeXidFromList(paramXid);
/*      */         
/*  931 */         if (this.activeXid == null) {
/*  932 */           exitGlobalTxnMode();
/*      */         }
/*      */       } 
/*      */       try {
/*  936 */         doRollback(paramXid);
/*      */       }
/*  938 */       catch (SQLException sQLException) {
/*      */ 
/*      */         
/*  941 */         checkError(sQLException, -3);
/*      */       } 
/*      */ 
/*      */       
/*  945 */       if (this.needStackingForCommitRollbackPrepare) {
/*  946 */         resumeStacked(xid);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  951 */       checkError(bool);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doRollback(Xid paramXid) throws XAException, SQLException {
/*  962 */     CallableStatement callableStatement = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  968 */       callableStatement = this.connection.prepareCall(xa_rollback_post_816);
/*      */       
/*  970 */       callableStatement.registerOutParameter(1, 2);
/*  971 */       callableStatement.setInt(2, paramXid.getFormatId());
/*  972 */       callableStatement.setBytes(3, paramXid.getGlobalTransactionId());
/*  973 */       callableStatement.setBytes(4, paramXid.getBranchQualifier());
/*      */       
/*  975 */       callableStatement.execute();
/*      */       
/*  977 */       int i = callableStatement.getInt(1);
/*      */       
/*  979 */       checkError(i, -7);
/*      */     }
/*  981 */     catch (SQLException sQLException) {
/*      */       
/*  983 */       int i = sQLException.getErrorCode();
/*      */ 
/*      */ 
/*      */       
/*  987 */       if (i == 0) {
/*  988 */         throw new XAException(-6);
/*      */       }
/*      */       
/*  991 */       throw sQLException;
/*      */     } finally {
/*      */ 
/*      */       
/*      */       try {
/*      */         
/*  997 */         if (callableStatement != null) {
/*  998 */           callableStatement.close();
/*      */         }
/* 1000 */       } catch (SQLException sQLException) {}
/*      */       
/* 1002 */       callableStatement = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doTwoPhaseAction(int paramInt1, int paramInt2, String[] paramArrayOfString, Xid[] paramArrayOfXid) throws XAException {
/* 1012 */     synchronized (this.connection) {
/*      */       
/* 1014 */       doDoTwoPhaseAction(paramInt1, paramInt2, paramArrayOfString, paramArrayOfXid);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int doDoTwoPhaseAction(int paramInt1, int paramInt2, String[] paramArrayOfString, Xid[] paramArrayOfXid) throws XAException {
/* 1024 */     throw new XAException(-6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static byte[] getSerializedBytes(Xid paramXid) {
/*      */     try {
/* 1040 */       return Util.serializeObject(paramXid);
/*      */     }
/* 1042 */     catch (IOException iOException) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1047 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1054 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/xa/client/OracleXAResource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */