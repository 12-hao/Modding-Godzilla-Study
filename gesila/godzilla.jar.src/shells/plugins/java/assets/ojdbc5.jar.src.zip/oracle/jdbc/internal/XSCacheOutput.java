package oracle.jdbc.internal;

public interface XSCacheOutput {}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/internal/XSCacheOutput.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */