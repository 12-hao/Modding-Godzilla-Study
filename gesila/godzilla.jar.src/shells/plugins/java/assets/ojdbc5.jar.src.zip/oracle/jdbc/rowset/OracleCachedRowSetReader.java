/*     */ package oracle.jdbc.rowset;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.sql.Connection;
/*     */ import java.sql.Date;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Properties;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.sql.DataSource;
/*     */ import javax.sql.RowSet;
/*     */ import javax.sql.RowSetInternal;
/*     */ import javax.sql.RowSetReader;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.driver.OracleDriver;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleCachedRowSetReader
/*     */   implements RowSetReader, Serializable
/*     */ {
/*     */   static final long serialVersionUID = -3565405169674271176L;
/*     */   static final transient int SETUNICODESTREAM_INTLENGTH = 1;
/*     */   static final transient int SETBINARYSTREAM_INTLENGTH = 2;
/*     */   static final transient int SETASCIISTREAM_INTLENGTH = 3;
/*     */   static final transient int SETCHARACTERSTREAM_INTLENGTH = 4;
/*     */   static final transient int TWO_PARAMETERS = 2;
/*     */   static final transient int THREE_PARAMETERS = 3;
/*     */   private static transient boolean driverManagerInitialized = false;
/*     */   
/*     */   Connection getConnection(RowSetInternal paramRowSetInternal) throws SQLException {
/* 117 */     Connection connection1 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 124 */     Connection connection2 = paramRowSetInternal.getConnection();
/* 125 */     if (connection2 != null && !connection2.isClosed()) {
/*     */       
/* 127 */       connection1 = connection2;
/*     */     }
/* 129 */     else if (((RowSet)paramRowSetInternal).getDataSourceName() != null) {
/*     */ 
/*     */       
/*     */       try {
/* 133 */         InitialContext initialContext = null;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         try {
/* 139 */           Properties properties = System.getProperties();
/* 140 */           initialContext = new InitialContext(properties);
/* 141 */         } catch (SecurityException securityException) {}
/*     */ 
/*     */         
/* 144 */         if (initialContext == null)
/* 145 */           initialContext = new InitialContext(); 
/* 146 */         DataSource dataSource = (DataSource)initialContext.lookup(((RowSet)paramRowSetInternal).getDataSourceName());
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 151 */         String str1 = ((RowSet)paramRowSetInternal).getUsername();
/* 152 */         String str2 = ((RowSet)paramRowSetInternal).getPassword();
/* 153 */         if (str1 == null && str2 == null)
/*     */         {
/* 155 */           connection1 = dataSource.getConnection();
/*     */         }
/*     */         else
/*     */         {
/* 159 */           connection1 = dataSource.getConnection(str1, str2);
/*     */         }
/*     */       
/* 162 */       } catch (NamingException namingException) {
/*     */ 
/*     */         
/* 165 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 300, namingException.getMessage());
/* 166 */         sQLException.fillInStackTrace();
/* 167 */         throw sQLException;
/*     */       }
/*     */     
/*     */     }
/* 171 */     else if (((RowSet)paramRowSetInternal).getUrl() != null) {
/*     */       
/* 173 */       if (!driverManagerInitialized) {
/*     */         
/* 175 */         DriverManager.registerDriver((Driver)new OracleDriver());
/* 176 */         driverManagerInitialized = true;
/*     */       } 
/* 178 */       String str1 = ((RowSet)paramRowSetInternal).getUrl();
/* 179 */       String str2 = ((RowSet)paramRowSetInternal).getUsername();
/* 180 */       String str3 = ((RowSet)paramRowSetInternal).getPassword();
/*     */ 
/*     */ 
/*     */       
/* 184 */       if (str1.equals("") || str2.equals("") || str3.equals("")) {
/*     */ 
/*     */         
/* 187 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 301);
/* 188 */         sQLException.fillInStackTrace();
/* 189 */         throw sQLException;
/*     */       } 
/*     */       
/* 192 */       connection1 = DriverManager.getConnection(str1, str2, str3);
/*     */     } 
/*     */     
/* 195 */     return connection1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setParams(Object[] paramArrayOfObject, PreparedStatement paramPreparedStatement) throws SQLException {
/* 208 */     for (byte b = 0; b < paramArrayOfObject.length; b++) {
/*     */       
/* 210 */       int i = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 215 */       if (paramArrayOfObject[b] instanceof byte[]) {
/*     */         
/* 217 */         paramPreparedStatement.setObject(b + 1, paramArrayOfObject[b]);
/*     */       } else {
/*     */ 
/*     */         
/*     */         try {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 227 */           i = Array.getLength(paramArrayOfObject[b]);
/*     */         }
/* 229 */         catch (IllegalArgumentException illegalArgumentException) {
/*     */           
/* 231 */           paramPreparedStatement.setObject(b + 1, paramArrayOfObject[b]);
/*     */         } 
/*     */ 
/*     */         
/* 235 */         Object[] arrayOfObject = (Object[])paramArrayOfObject[b];
/*     */ 
/*     */ 
/*     */         
/* 239 */         if (i == 2) {
/*     */           
/* 241 */           if (arrayOfObject[0] == null) {
/* 242 */             paramPreparedStatement.setNull(b + 1, ((Integer)arrayOfObject[1]).intValue());
/*     */           }
/* 244 */           else if (arrayOfObject[0] instanceof Date) {
/*     */             
/* 246 */             if (arrayOfObject[1] instanceof Calendar)
/*     */             {
/* 248 */               paramPreparedStatement.setDate(b + 1, (Date)arrayOfObject[0], (Calendar)arrayOfObject[1]);
/*     */             
/*     */             }
/*     */             else
/*     */             {
/*     */               
/* 254 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 255 */               sQLException.fillInStackTrace();
/* 256 */               throw sQLException;
/*     */             }
/*     */           
/*     */           }
/* 260 */           else if (arrayOfObject[0] instanceof Time) {
/*     */             
/* 262 */             if (arrayOfObject[1] instanceof Calendar)
/*     */             {
/* 264 */               paramPreparedStatement.setTime(b + 1, (Time)arrayOfObject[0], (Calendar)arrayOfObject[1]);
/*     */             
/*     */             }
/*     */             else
/*     */             {
/*     */               
/* 270 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 271 */               sQLException.fillInStackTrace();
/* 272 */               throw sQLException;
/*     */             }
/*     */           
/*     */           }
/* 276 */           else if (arrayOfObject[0] instanceof Timestamp) {
/*     */             
/* 278 */             if (arrayOfObject[1] instanceof Calendar)
/*     */             {
/* 280 */               paramPreparedStatement.setTimestamp(b + 1, (Timestamp)arrayOfObject[0], (Calendar)arrayOfObject[1]);
/*     */             
/*     */             }
/*     */             else
/*     */             {
/*     */               
/* 286 */               SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 287 */               sQLException.fillInStackTrace();
/* 288 */               throw sQLException;
/*     */ 
/*     */ 
/*     */             
/*     */             }
/*     */ 
/*     */ 
/*     */           
/*     */           }
/* 297 */           else if (arrayOfObject[1] instanceof Integer) {
/* 298 */             paramPreparedStatement.setObject(b + 1, arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 303 */         else if (i == 3) {
/*     */           
/* 305 */           if (arrayOfObject[0] == null) {
/*     */             
/* 307 */             paramPreparedStatement.setNull(b + 1, ((Integer)arrayOfObject[1]).intValue(), (String)arrayOfObject[2]);
/*     */ 
/*     */           
/*     */           }
/* 311 */           else if (arrayOfObject[0] instanceof Reader) {
/*     */             SQLException sQLException;
/* 313 */             switch (((Integer)arrayOfObject[2]).intValue()) {
/*     */               
/*     */               case 4:
/* 316 */                 paramPreparedStatement.setCharacterStream(b + 1, (Reader)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
/*     */                 break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               default:
/* 327 */                 sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 328 */                 sQLException.fillInStackTrace();
/* 329 */                 throw sQLException;
/*     */             } 
/*     */ 
/*     */           
/* 333 */           } else if (arrayOfObject[0] instanceof InputStream) {
/* 334 */             SQLException sQLException; switch (((Integer)arrayOfObject[2]).intValue()) {
/*     */               
/*     */               case 1:
/* 337 */                 paramPreparedStatement.setUnicodeStream(b + 1, (InputStream)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
/*     */                 break;
/*     */ 
/*     */ 
/*     */               
/*     */               case 2:
/* 343 */                 paramPreparedStatement.setBinaryStream(b + 1, (InputStream)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
/*     */                 break;
/*     */ 
/*     */ 
/*     */               
/*     */               case 3:
/* 349 */                 paramPreparedStatement.setAsciiStream(b + 1, (InputStream)arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue());
/*     */                 break;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               default:
/* 360 */                 sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 361 */                 sQLException.fillInStackTrace();
/* 362 */                 throw sQLException;
/*     */             } 
/*     */           
/* 365 */           } else if (arrayOfObject[1] instanceof Integer && arrayOfObject[2] instanceof Integer) {
/*     */ 
/*     */             
/* 368 */             paramPreparedStatement.setObject(b + 1, arrayOfObject[0], ((Integer)arrayOfObject[1]).intValue(), ((Integer)arrayOfObject[2]).intValue());
/*     */           
/*     */           }
/*     */           else {
/*     */ 
/*     */             
/* 374 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 375 */             sQLException.fillInStackTrace();
/* 376 */             throw sQLException;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void readData(RowSetInternal paramRowSetInternal) throws SQLException {
/* 392 */     OracleCachedRowSet oracleCachedRowSet = (OracleCachedRowSet)paramRowSetInternal;
/*     */     
/* 394 */     Connection connection = getConnection(paramRowSetInternal);
/*     */ 
/*     */ 
/*     */     
/* 398 */     if (connection == null || oracleCachedRowSet.getCommand() == null) {
/*     */       
/* 400 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 342);
/* 401 */       sQLException.fillInStackTrace();
/* 402 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 407 */       connection.setTransactionIsolation(oracleCachedRowSet.getTransactionIsolation());
/*     */     }
/* 409 */     catch (Exception exception) {}
/*     */ 
/*     */     
/* 412 */     PreparedStatement preparedStatement = connection.prepareStatement(oracleCachedRowSet.getCommand(), oracleCachedRowSet.getType(), oracleCachedRowSet.getConcurrency());
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 417 */     setParams(paramRowSetInternal.getParams(), preparedStatement);
/*     */     
/*     */     try {
/* 420 */       preparedStatement.setMaxRows(oracleCachedRowSet.getMaxRows());
/* 421 */       preparedStatement.setMaxFieldSize(oracleCachedRowSet.getMaxFieldSize());
/* 422 */       preparedStatement.setEscapeProcessing(oracleCachedRowSet.getEscapeProcessing());
/* 423 */       preparedStatement.setQueryTimeout(oracleCachedRowSet.getQueryTimeout());
/*     */     }
/* 425 */     catch (Exception exception) {}
/* 426 */     ResultSet resultSet = preparedStatement.executeQuery();
/* 427 */     oracleCachedRowSet.populate(resultSet, oracleCachedRowSet.getCurrentPage() * oracleCachedRowSet.getPageSize());
/* 428 */     resultSet.close();
/* 429 */     preparedStatement.close();
/*     */     
/*     */     try {
/* 432 */       connection.commit();
/* 433 */     } catch (SQLException sQLException) {}
/*     */ 
/*     */ 
/*     */     
/* 437 */     if (!oracleCachedRowSet.isConnectionStayingOpen())
/*     */     {
/* 439 */       connection.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 456 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 461 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/rowset/OracleCachedRowSetReader.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */