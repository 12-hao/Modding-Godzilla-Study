/*       */ package oracle.jdbc.driver;
/*       */ 
/*       */ import java.io.BufferedInputStream;
/*       */ import java.io.BufferedReader;
/*       */ import java.io.ByteArrayInputStream;
/*       */ import java.io.IOException;
/*       */ import java.io.InputStream;
/*       */ import java.io.Reader;
/*       */ import java.io.StringReader;
/*       */ import java.math.BigDecimal;
/*       */ import java.math.BigInteger;
/*       */ import java.net.URL;
/*       */ import java.sql.Array;
/*       */ import java.sql.BatchUpdateException;
/*       */ import java.sql.Blob;
/*       */ import java.sql.Clob;
/*       */ import java.sql.Connection;
/*       */ import java.sql.Date;
/*       */ import java.sql.ParameterMetaData;
/*       */ import java.sql.Ref;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.ResultSetMetaData;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.Statement;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.Calendar;
/*       */ import java.util.Locale;
/*       */ import java.util.TimeZone;
/*       */ import oracle.jdbc.OracleConnection;
/*       */ import oracle.jdbc.OracleData;
/*       */ import oracle.jdbc.OracleParameterMetaData;
/*       */ import oracle.jdbc.internal.OraclePreparedStatement;
/*       */ import oracle.jdbc.internal.OracleStatement;
/*       */ import oracle.jdbc.oracore.OracleTypeADT;
/*       */ import oracle.jdbc.oracore.OracleTypeCOLLECTION;
/*       */ import oracle.jdbc.oracore.OracleTypeNUMBER;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.ArrayDescriptor;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.CHAR;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CharacterSet;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.OPAQUE;
/*       */ import oracle.sql.ORAData;
/*       */ import oracle.sql.OpaqueDescriptor;
/*       */ import oracle.sql.RAW;
/*       */ import oracle.sql.REF;
/*       */ import oracle.sql.ROWID;
/*       */ import oracle.sql.STRUCT;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ abstract class OraclePreparedStatement
/*       */   extends OracleStatement
/*       */   implements OraclePreparedStatement, ScrollRsetStatement
/*       */ {
/*       */   int numberOfBindRowsAllocated;
/*   107 */   static Binder theStaticVarnumCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarnumCopyingBinder;
/*       */   
/*   109 */   static Binder theStaticVarnumNullBinder = OraclePreparedStatementReadOnly.theStaticVarnumNullBinder;
/*       */   
/*   111 */   Binder theVarnumNullBinder = theStaticVarnumNullBinder;
/*       */   
/*   113 */   static Binder theStaticBooleanBinder = OraclePreparedStatementReadOnly.theStaticBooleanBinder;
/*       */   
/*   115 */   Binder theBooleanBinder = theStaticBooleanBinder;
/*       */   
/*   117 */   static Binder theStaticByteBinder = OraclePreparedStatementReadOnly.theStaticByteBinder;
/*       */   
/*   119 */   Binder theByteBinder = theStaticByteBinder;
/*       */   
/*   121 */   static Binder theStaticShortBinder = OraclePreparedStatementReadOnly.theStaticShortBinder;
/*       */   
/*   123 */   Binder theShortBinder = theStaticShortBinder;
/*       */   
/*   125 */   static Binder theStaticIntBinder = OraclePreparedStatementReadOnly.theStaticIntBinder;
/*       */   
/*   127 */   Binder theIntBinder = theStaticIntBinder;
/*       */   
/*   129 */   static Binder theStaticLongBinder = OraclePreparedStatementReadOnly.theStaticLongBinder;
/*       */   
/*   131 */   Binder theLongBinder = theStaticLongBinder;
/*       */   
/*   133 */   static Binder theStaticFloatBinder = OraclePreparedStatementReadOnly.theStaticFloatBinder;
/*       */   
/*   135 */   Binder theFloatBinder = null;
/*       */   
/*   137 */   static Binder theStaticDoubleBinder = OraclePreparedStatementReadOnly.theStaticDoubleBinder;
/*       */   
/*   139 */   Binder theDoubleBinder = null;
/*       */   
/*   141 */   static Binder theStaticBigDecimalBinder = OraclePreparedStatementReadOnly.theStaticBigDecimalBinder;
/*       */   
/*   143 */   Binder theBigDecimalBinder = theStaticBigDecimalBinder;
/*       */   
/*   145 */   static Binder theStaticVarcharCopyingBinder = OraclePreparedStatementReadOnly.theStaticVarcharCopyingBinder;
/*       */   
/*   147 */   static Binder theStaticVarcharNullBinder = OraclePreparedStatementReadOnly.theStaticVarcharNullBinder;
/*       */   
/*   149 */   Binder theVarcharNullBinder = theStaticVarcharNullBinder;
/*       */   
/*   151 */   static Binder theStaticStringBinder = OraclePreparedStatementReadOnly.theStaticStringBinder;
/*       */   
/*   153 */   Binder theStringBinder = theStaticStringBinder;
/*       */   
/*   155 */   static Binder theStaticSetCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticSetCHARCopyingBinder;
/*       */   
/*   157 */   static Binder theStaticSetCHARBinder = OraclePreparedStatementReadOnly.theStaticSetCHARBinder;
/*       */   
/*   159 */   static Binder theStaticLittleEndianSetCHARBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianSetCHARBinder;
/*       */   
/*   161 */   static Binder theStaticSetCHARNullBinder = OraclePreparedStatementReadOnly.theStaticSetCHARNullBinder;
/*       */   
/*       */   Binder theSetCHARBinder;
/*   164 */   Binder theSetCHARNullBinder = theStaticSetCHARNullBinder;
/*       */   
/*   166 */   static Binder theStaticFixedCHARCopyingBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARCopyingBinder;
/*       */   
/*   168 */   static Binder theStaticFixedCHARBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARBinder;
/*       */   
/*   170 */   static Binder theStaticFixedCHARNullBinder = OraclePreparedStatementReadOnly.theStaticFixedCHARNullBinder;
/*       */   
/*   172 */   Binder theFixedCHARBinder = theStaticFixedCHARBinder;
/*   173 */   Binder theFixedCHARNullBinder = theStaticFixedCHARNullBinder;
/*       */   
/*   175 */   static Binder theStaticDateCopyingBinder = OraclePreparedStatementReadOnly.theStaticDateCopyingBinder;
/*       */   
/*   177 */   static Binder theStaticDateBinder = OraclePreparedStatementReadOnly.theStaticDateBinder;
/*       */   
/*   179 */   static Binder theStaticDateNullBinder = OraclePreparedStatementReadOnly.theStaticDateNullBinder;
/*       */   
/*   181 */   Binder theDateBinder = theStaticDateBinder;
/*   182 */   Binder theDateNullBinder = theStaticDateNullBinder;
/*       */   
/*   184 */   static Binder theStaticTimeCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimeCopyingBinder;
/*       */   
/*   186 */   static Binder theStaticTimeBinder = OraclePreparedStatementReadOnly.theStaticTimeBinder;
/*       */   
/*   188 */   Binder theTimeBinder = theStaticTimeBinder;
/*       */   
/*   190 */   static Binder theStaticTimestampCopyingBinder = OraclePreparedStatementReadOnly.theStaticTimestampCopyingBinder;
/*       */   
/*   192 */   static Binder theStaticTimestampBinder = OraclePreparedStatementReadOnly.theStaticTimestampBinder;
/*       */   
/*   194 */   static Binder theStaticTimestampNullBinder = OraclePreparedStatementReadOnly.theStaticTimestampNullBinder;
/*       */   
/*   196 */   Binder theTimestampBinder = theStaticTimestampBinder;
/*   197 */   Binder theTimestampNullBinder = theStaticTimestampNullBinder;
/*       */   
/*   199 */   static Binder theStaticOracleNumberBinder = OraclePreparedStatementReadOnly.theStaticOracleNumberBinder;
/*       */   
/*   201 */   Binder theOracleNumberBinder = theStaticOracleNumberBinder;
/*       */   
/*   203 */   static Binder theStaticOracleDateBinder = OraclePreparedStatementReadOnly.theStaticOracleDateBinder;
/*       */   
/*   205 */   Binder theOracleDateBinder = theStaticOracleDateBinder;
/*       */   
/*   207 */   static Binder theStaticOracleTimestampBinder = OraclePreparedStatementReadOnly.theStaticOracleTimestampBinder;
/*       */   
/*   209 */   Binder theOracleTimestampBinder = theStaticOracleTimestampBinder;
/*       */   
/*   211 */   static Binder theStaticTSTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSTZCopyingBinder;
/*       */   
/*   213 */   static Binder theStaticTSTZBinder = OraclePreparedStatementReadOnly.theStaticTSTZBinder;
/*       */   
/*   215 */   static Binder theStaticTSTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSTZNullBinder;
/*       */   
/*   217 */   Binder theTSTZBinder = theStaticTSTZBinder;
/*   218 */   Binder theTSTZNullBinder = theStaticTSTZNullBinder;
/*       */   
/*   220 */   static Binder theStaticTSLTZCopyingBinder = OraclePreparedStatementReadOnly.theStaticTSLTZCopyingBinder;
/*       */   
/*   222 */   static Binder theStaticTSLTZBinder = OraclePreparedStatementReadOnly.theStaticTSLTZBinder;
/*       */   
/*   224 */   static Binder theStaticTSLTZNullBinder = OraclePreparedStatementReadOnly.theStaticTSLTZNullBinder;
/*       */   
/*   226 */   Binder theTSLTZBinder = theStaticTSLTZBinder;
/*   227 */   Binder theTSLTZNullBinder = theStaticTSLTZNullBinder;
/*       */   
/*   229 */   static Binder theStaticRowidCopyingBinder = OraclePreparedStatementReadOnly.theStaticRowidCopyingBinder;
/*       */   
/*   231 */   static Binder theStaticRowidBinder = OraclePreparedStatementReadOnly.theStaticRowidBinder;
/*       */   
/*   233 */   static Binder theStaticLittleEndianRowidBinder = OraclePreparedStatementReadOnly.theStaticLittleEndianRowidBinder;
/*       */   
/*   235 */   static Binder theStaticRowidNullBinder = OraclePreparedStatementReadOnly.theStaticRowidNullBinder;
/*       */   
/*   237 */   static Binder theStaticURowidNullBinder = OraclePreparedStatementReadOnly.theStaticURowidNullBinder;
/*       */   
/*       */   Binder theRowidBinder;
/*   240 */   Binder theRowidNullBinder = theStaticRowidNullBinder;
/*       */   
/*       */   Binder theURowidBinder;
/*   243 */   Binder theURowidNullBinder = theStaticURowidNullBinder;
/*       */   
/*   245 */   static Binder theStaticIntervalDSCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSCopyingBinder;
/*       */   
/*   247 */   static Binder theStaticIntervalDSBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSBinder;
/*       */   
/*   249 */   static Binder theStaticIntervalDSNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalDSNullBinder;
/*       */   
/*   251 */   Binder theIntervalDSBinder = theStaticIntervalDSBinder;
/*   252 */   Binder theIntervalDSNullBinder = theStaticIntervalDSNullBinder;
/*       */   
/*   254 */   static Binder theStaticIntervalYMCopyingBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMCopyingBinder;
/*       */   
/*   256 */   static Binder theStaticIntervalYMBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMBinder;
/*       */   
/*   258 */   static Binder theStaticIntervalYMNullBinder = OraclePreparedStatementReadOnly.theStaticIntervalYMNullBinder;
/*       */   
/*   260 */   Binder theIntervalYMBinder = theStaticIntervalYMBinder;
/*   261 */   Binder theIntervalYMNullBinder = theStaticIntervalYMNullBinder;
/*       */   
/*   263 */   static Binder theStaticBfileCopyingBinder = OraclePreparedStatementReadOnly.theStaticBfileCopyingBinder;
/*       */   
/*   265 */   static Binder theStaticBfileBinder = OraclePreparedStatementReadOnly.theStaticBfileBinder;
/*       */   
/*   267 */   static Binder theStaticBfileNullBinder = OraclePreparedStatementReadOnly.theStaticBfileNullBinder;
/*       */   
/*   269 */   Binder theBfileBinder = theStaticBfileBinder;
/*   270 */   Binder theBfileNullBinder = theStaticBfileNullBinder;
/*       */   
/*   272 */   static Binder theStaticBlobCopyingBinder = OraclePreparedStatementReadOnly.theStaticBlobCopyingBinder;
/*       */   
/*   274 */   static Binder theStaticBlobBinder = OraclePreparedStatementReadOnly.theStaticBlobBinder;
/*       */   
/*   276 */   static Binder theStaticBlobNullBinder = OraclePreparedStatementReadOnly.theStaticBlobNullBinder;
/*       */   
/*   278 */   Binder theBlobBinder = theStaticBlobBinder;
/*   279 */   Binder theBlobNullBinder = theStaticBlobNullBinder;
/*       */   
/*   281 */   static Binder theStaticClobCopyingBinder = OraclePreparedStatementReadOnly.theStaticClobCopyingBinder;
/*       */   
/*   283 */   static Binder theStaticClobBinder = OraclePreparedStatementReadOnly.theStaticClobBinder;
/*       */   
/*   285 */   static Binder theStaticClobNullBinder = OraclePreparedStatementReadOnly.theStaticClobNullBinder;
/*       */   
/*   287 */   Binder theClobBinder = theStaticClobBinder;
/*   288 */   Binder theClobNullBinder = theStaticClobNullBinder;
/*       */   
/*   290 */   static Binder theStaticRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticRawCopyingBinder;
/*       */   
/*   292 */   static Binder theStaticRawBinder = OraclePreparedStatementReadOnly.theStaticRawBinder;
/*       */   
/*   294 */   static Binder theStaticRawNullBinder = OraclePreparedStatementReadOnly.theStaticRawNullBinder;
/*       */   
/*   296 */   Binder theRawBinder = theStaticRawBinder;
/*   297 */   Binder theRawNullBinder = theStaticRawNullBinder;
/*       */   
/*   299 */   static Binder theStaticPlsqlRawCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawCopyingBinder;
/*       */   
/*   301 */   static Binder theStaticPlsqlRawBinder = OraclePreparedStatementReadOnly.theStaticPlsqlRawBinder;
/*       */   
/*   303 */   Binder thePlsqlRawBinder = theStaticPlsqlRawBinder;
/*       */   
/*   305 */   static Binder theStaticBinaryFloatCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatCopyingBinder;
/*       */   
/*   307 */   static Binder theStaticBinaryFloatBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatBinder;
/*       */   
/*   309 */   static Binder theStaticBinaryFloatNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryFloatNullBinder;
/*       */   
/*   311 */   Binder theBinaryFloatBinder = theStaticBinaryFloatBinder;
/*   312 */   Binder theBinaryFloatNullBinder = theStaticBinaryFloatNullBinder;
/*       */   
/*   314 */   static Binder theStaticBINARY_FLOATCopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATCopyingBinder;
/*       */   
/*   316 */   static Binder theStaticBINARY_FLOATBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATBinder;
/*       */   
/*   318 */   static Binder theStaticBINARY_FLOATNullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_FLOATNullBinder;
/*       */   
/*   320 */   Binder theBINARY_FLOATBinder = theStaticBINARY_FLOATBinder;
/*   321 */   Binder theBINARY_FLOATNullBinder = theStaticBINARY_FLOATNullBinder;
/*       */   
/*   323 */   static Binder theStaticBinaryDoubleCopyingBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleCopyingBinder;
/*       */   
/*   325 */   static Binder theStaticBinaryDoubleBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleBinder;
/*       */   
/*   327 */   static Binder theStaticBinaryDoubleNullBinder = OraclePreparedStatementReadOnly.theStaticBinaryDoubleNullBinder;
/*       */   
/*   329 */   Binder theBinaryDoubleBinder = theStaticBinaryDoubleBinder;
/*   330 */   Binder theBinaryDoubleNullBinder = theStaticBinaryDoubleNullBinder;
/*       */   
/*   332 */   static Binder theStaticBINARY_DOUBLECopyingBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLECopyingBinder;
/*       */   
/*   334 */   static Binder theStaticBINARY_DOUBLEBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLEBinder;
/*       */   
/*   336 */   static Binder theStaticBINARY_DOUBLENullBinder = OraclePreparedStatementReadOnly.theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   338 */   Binder theBINARY_DOUBLEBinder = theStaticBINARY_DOUBLEBinder;
/*   339 */   Binder theBINARY_DOUBLENullBinder = theStaticBINARY_DOUBLENullBinder;
/*       */   
/*   341 */   static Binder theStaticLongStreamBinder = OraclePreparedStatementReadOnly.theStaticLongStreamBinder;
/*       */   
/*   343 */   Binder theLongStreamBinder = theStaticLongStreamBinder;
/*       */   
/*   345 */   static Binder theStaticLongStreamForStringBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringBinder;
/*       */   
/*   347 */   Binder theLongStreamForStringBinder = theStaticLongStreamForStringBinder;
/*   348 */   static Binder theStaticLongStreamForStringCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongStreamForStringCopyingBinder;
/*       */ 
/*       */   
/*   351 */   static Binder theStaticLongRawStreamBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamBinder;
/*       */   
/*   353 */   Binder theLongRawStreamBinder = theStaticLongRawStreamBinder;
/*       */   
/*   355 */   static Binder theStaticLongRawStreamForBytesBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesBinder;
/*       */   
/*   357 */   Binder theLongRawStreamForBytesBinder = theStaticLongRawStreamForBytesBinder;
/*   358 */   static Binder theStaticLongRawStreamForBytesCopyingBinder = OraclePreparedStatementReadOnly.theStaticLongRawStreamForBytesCopyingBinder;
/*       */ 
/*       */   
/*   361 */   static Binder theStaticNamedTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeCopyingBinder;
/*       */   
/*   363 */   static Binder theStaticNamedTypeBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeBinder;
/*       */   
/*   365 */   static Binder theStaticNamedTypeNullBinder = OraclePreparedStatementReadOnly.theStaticNamedTypeNullBinder;
/*       */   
/*   367 */   Binder theNamedTypeBinder = theStaticNamedTypeBinder;
/*   368 */   Binder theNamedTypeNullBinder = theStaticNamedTypeNullBinder;
/*       */   
/*   370 */   static Binder theStaticRefTypeCopyingBinder = OraclePreparedStatementReadOnly.theStaticRefTypeCopyingBinder;
/*       */   
/*   372 */   static Binder theStaticRefTypeBinder = OraclePreparedStatementReadOnly.theStaticRefTypeBinder;
/*       */   
/*   374 */   static Binder theStaticRefTypeNullBinder = OraclePreparedStatementReadOnly.theStaticRefTypeNullBinder;
/*       */   
/*   376 */   Binder theRefTypeBinder = theStaticRefTypeBinder;
/*   377 */   Binder theRefTypeNullBinder = theStaticRefTypeNullBinder;
/*       */   
/*   379 */   static Binder theStaticPlsqlIbtCopyingBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtCopyingBinder;
/*       */   
/*   381 */   static Binder theStaticPlsqlIbtBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtBinder;
/*       */   
/*   383 */   static Binder theStaticPlsqlIbtNullBinder = OraclePreparedStatementReadOnly.theStaticPlsqlIbtNullBinder;
/*       */   
/*   385 */   Binder thePlsqlIbtBinder = theStaticPlsqlIbtBinder;
/*   386 */   Binder thePlsqlNullBinder = theStaticPlsqlIbtNullBinder;
/*       */   
/*   388 */   static Binder theStaticOutBinder = OraclePreparedStatementReadOnly.theStaticOutBinder;
/*       */   
/*   390 */   Binder theOutBinder = theStaticOutBinder;
/*       */   
/*   392 */   static Binder theStaticReturnParamBinder = OraclePreparedStatementReadOnly.theStaticReturnParamBinder;
/*       */   
/*   394 */   Binder theReturnParamBinder = theStaticReturnParamBinder;
/*       */   
/*   396 */   static Binder theStaticT4CRowidBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidBinder;
/*       */   
/*   398 */   static Binder theStaticT4CURowidBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidBinder;
/*       */   
/*   400 */   static Binder theStaticT4CRowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CRowidNullBinder;
/*       */   
/*   402 */   static Binder theStaticT4CURowidNullBinder = OraclePreparedStatementReadOnly.theStaticT4CURowidNullBinder;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   409 */   private static final TimeZone UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");
/*   410 */   private static final Calendar UTC_US_CALENDAR = Calendar.getInstance(UTC_TIME_ZONE, Locale.US);
/*       */   
/*   412 */   protected Calendar cachedUTCUSCalendar = (Calendar)UTC_US_CALENDAR.clone();
/*       */   
/*       */   public static final int TypeBinder_BYTELEN = 24;
/*       */   
/*   416 */   char[] digits = new char[20];
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[][] binders;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[][] parameterInt;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   long[][] parameterLong;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   float[][] parameterFloat;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   double[][] parameterDouble;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   BigDecimal[][] parameterBigDecimal;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   String[][] parameterString;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Date[][] parameterDate;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Time[][] parameterTime;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Timestamp[][] parameterTimestamp;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[][][] parameterDatum;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTypeADT[][] parameterOtype;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   CLOB[] lastBoundClobs;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   BLOB[] lastBoundBlobs;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PlsqlIbtBindInfo[][] parameterPlsqlIbt;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[] currentRowBinders;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[] currentRowCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Accessor[] currentRowBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   short[] currentRowFormOfUse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean currentRowNeedToPrepareBinds = true;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int[] currentBatchCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Accessor[] currentBatchBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   short[] currentBatchFormOfUse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean currentBatchNeedToPrepareBinds;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PushedBatch pushedBatches;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   PushedBatch pushedBatchesTail;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   class PushedBatch
/*       */   {
/*       */     int[] currentBatchCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int[] lastBoundCharLens;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     Accessor[] currentBatchBindAccessors;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean lastBoundNeeded;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean need_to_parse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     boolean current_batch_need_to_prepare_binds;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int first_row_in_batch;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     int number_of_rows_to_be_bound;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     PushedBatch next;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   874 */   int cachedBindByteSize = 0;
/*   875 */   int cachedBindCharSize = 0;
/*   876 */   int cachedBindIndicatorSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindByteLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindCharLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int totalBindIndicatorLength;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BIND_POSITIONS_OFFSET = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_HI = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BIND_BUFFER_CAPACITY_OFFSET_LO = 2;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_HI = 3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NUMBER_OF_BOUND_ROWS_OFFSET_LO = 4;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_PER_POSITION_DATA_OFFSET = 5;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_TYPE_OFFSET = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_BYTE_PITCH_OFFSET = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_CHAR_PITCH_OFFSET = 2;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_HI = 3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_DATA_OFFSET_LO = 4;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_HI = 5;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_NULL_INDICATORS_OFFSET_LO = 6;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_HI = 7;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_VALUE_LENGTHS_OFFSET_LO = 8;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_FORM_OF_USE_OFFSET = 9;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BIND_METADATA_PER_POSITION_SIZE = 10;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int SETLOB_NO_LENGTH = -1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int bindBufferCapacity;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int numberOfBoundRows;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int indicatorsOffset;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int valueLengthsOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean preparedAllBinds;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean preparedCharBinds;
/*       */ 
/*       */ 
/*       */   
/*       */   Binder[] lastBinders;
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] lastBoundBytes;
/*       */ 
/*       */ 
/*       */   
/*       */   int lastBoundByteOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   char[] lastBoundChars;
/*       */ 
/*       */ 
/*       */   
/*       */   int lastBoundCharOffset;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundByteOffsets;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundCharOffsets;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundByteLens;
/*       */ 
/*       */ 
/*       */   
/*       */   int[] lastBoundCharLens;
/*       */ 
/*       */ 
/*       */   
/*       */   short[] lastBoundInds;
/*       */ 
/*       */ 
/*       */   
/*       */   short[] lastBoundLens;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean lastBoundNeeded = false;
/*       */ 
/*       */ 
/*       */   
/*       */   byte[][] lastBoundTypeBytes;
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTypeADT[] lastBoundTypeOtypes;
/*       */ 
/*       */ 
/*       */   
/*       */   InputStream[] lastBoundStream;
/*       */ 
/*       */ 
/*       */   
/*       */   private static final int STREAM_MAX_BYTES_SQL = 2147483647;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesPlsql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsCharsSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsNCharsSql;
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsBytesPlsql;
/*       */ 
/*       */ 
/*       */   
/*  1097 */   private int maxCharSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1103 */   private int maxNCharSize = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1111 */   private int charMaxCharsSql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1119 */   private int charMaxNCharsSql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1126 */   private int maxVcsCharsPlsql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1133 */   private int maxVcsNCharsPlsql = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1139 */   int maxIbtVarcharElementLength = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  1147 */   private int maxStreamCharsSql = 0; protected boolean isServerCharSetFixedWidth = false; private boolean isServerNCharSetFixedWidth = false; int minVcsBindSize; int prematureBatchCount; boolean checkBindTypes = true; boolean scrollRsetTypeSolved; private static final double MIN_NUMBER = 1.0E-130D; private static final double MAX_NUMBER = 1.0E126D; int SetBigStringTryClob; static final int BSTYLE_UNKNOWN = 0; static final int BSTYLE_ORACLE = 1; static final int BSTYLE_JDBC = 2; int m_batchStyle; void allocBinds(int paramInt) throws SQLException { boolean bool = (paramInt > this.numberOfBindRowsAllocated) ? true : false; initializeIndicatorSubRange(); int i = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10; int j = paramInt * this.numberOfBindPositions; int k = i + 2 * j; if (k > this.totalBindIndicatorLength) { short[] arrayOfShort = this.bindIndicators; int i2 = this.bindIndicatorOffset; this.bindIndicatorOffset = 0; this.bindIndicators = new short[k]; this.totalBindIndicatorLength = k; if (arrayOfShort != null && bool) System.arraycopy(arrayOfShort, i2, this.bindIndicators, this.bindIndicatorOffset, i);  }  this.bindIndicatorSubRange += this.bindIndicatorOffset; this.bindIndicators[this.bindIndicatorSubRange + 0] = (short)this.numberOfBindPositions; this.indicatorsOffset = this.bindIndicatorOffset + i; this.valueLengthsOffset = this.indicatorsOffset + j; int m = this.indicatorsOffset; int n = this.valueLengthsOffset; int i1 = this.bindIndicatorSubRange + 5; for (byte b = 0; b < this.numberOfBindPositions; b++) { this.bindIndicators[i1 + 5] = (short)(m >> 16); this.bindIndicators[i1 + 6] = (short)(m & 0xFFFF); this.bindIndicators[i1 + 7] = (short)(n >> 16); this.bindIndicators[i1 + 8] = (short)(n & 0xFFFF); m += paramInt; n += paramInt; i1 += 10; }  }
/*       */   void initializeBinds() throws SQLException { this.numberOfBindPositions = this.sqlObject.getParameterCount(); this.numReturnParams = this.sqlObject.getReturnParameterCount(); if (this.numberOfBindPositions == 0) { this.currentRowNeedToPrepareBinds = false; return; }  this.numberOfBindRowsAllocated = this.batch; this.binders = new Binder[this.numberOfBindRowsAllocated][this.numberOfBindPositions]; this.currentRowBinders = this.binders[0]; this.currentRowCharLens = new int[this.numberOfBindPositions]; this.currentBatchCharLens = new int[this.numberOfBindPositions]; this.currentRowFormOfUse = new short[this.numberOfBindPositions]; this.currentBatchFormOfUse = new short[this.numberOfBindPositions]; this.lastBoundClobs = new CLOB[this.numberOfBindPositions]; this.lastBoundBlobs = new BLOB[this.numberOfBindPositions]; byte b1 = 1; if (this.connection.defaultnchar) b1 = 2;  for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) { this.currentRowFormOfUse[b2] = b1; this.currentBatchFormOfUse[b2] = b1; }  this.lastBinders = new Binder[this.numberOfBindPositions]; this.lastBoundCharLens = new int[this.numberOfBindPositions]; this.lastBoundByteOffsets = new int[this.numberOfBindPositions]; this.lastBoundCharOffsets = new int[this.numberOfBindPositions]; this.lastBoundByteLens = new int[this.numberOfBindPositions]; this.lastBoundInds = new short[this.numberOfBindPositions]; this.lastBoundLens = new short[this.numberOfBindPositions]; this.lastBoundTypeBytes = new byte[this.numberOfBindPositions][]; this.lastBoundTypeOtypes = new OracleTypeADT[this.numberOfBindPositions]; allocBinds(this.numberOfBindRowsAllocated); }
/*       */   void growBinds(int paramInt) throws SQLException { Binder[][] arrayOfBinder = this.binders; this.binders = new Binder[paramInt][]; if (arrayOfBinder != null) System.arraycopy(arrayOfBinder, 0, this.binders, 0, this.numberOfBindRowsAllocated);  int i; for (i = this.numberOfBindRowsAllocated; i < paramInt; i++) this.binders[i] = new Binder[this.numberOfBindPositions];  allocBinds(paramInt); if (this.parameterInt != null) { int[][] arrayOfInt = this.parameterInt; this.parameterInt = new int[paramInt][]; System.arraycopy(arrayOfInt, 0, this.parameterInt, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterInt[i] = new int[this.numberOfBindPositions];  }  if (this.parameterLong != null) { long[][] arrayOfLong = this.parameterLong; this.parameterLong = new long[paramInt][]; System.arraycopy(arrayOfLong, 0, this.parameterLong, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterLong[i] = new long[this.numberOfBindPositions];  }  if (this.parameterFloat != null) { float[][] arrayOfFloat = this.parameterFloat; this.parameterFloat = new float[paramInt][]; System.arraycopy(arrayOfFloat, 0, this.parameterFloat, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterFloat[i] = new float[this.numberOfBindPositions];  }  if (this.parameterDouble != null) { double[][] arrayOfDouble = this.parameterDouble; this.parameterDouble = new double[paramInt][]; System.arraycopy(arrayOfDouble, 0, this.parameterDouble, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterDouble[i] = new double[this.numberOfBindPositions];  }  if (this.parameterBigDecimal != null) { BigDecimal[][] arrayOfBigDecimal = this.parameterBigDecimal; this.parameterBigDecimal = new BigDecimal[paramInt][]; System.arraycopy(arrayOfBigDecimal, 0, this.parameterBigDecimal, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterBigDecimal[i] = new BigDecimal[this.numberOfBindPositions];  }  if (this.parameterString != null) { String[][] arrayOfString = this.parameterString; this.parameterString = new String[paramInt][]; System.arraycopy(arrayOfString, 0, this.parameterString, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterString[i] = new String[this.numberOfBindPositions];  }  if (this.parameterDate != null) { Date[][] arrayOfDate = this.parameterDate; this.parameterDate = new Date[paramInt][]; System.arraycopy(arrayOfDate, 0, this.parameterDate, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterDate[i] = new Date[this.numberOfBindPositions];  }  if (this.parameterTime != null) { Time[][] arrayOfTime = this.parameterTime; this.parameterTime = new Time[paramInt][]; System.arraycopy(arrayOfTime, 0, this.parameterTime, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterTime[i] = new Time[this.numberOfBindPositions];  }  if (this.parameterTimestamp != null) { Timestamp[][] arrayOfTimestamp = this.parameterTimestamp; this.parameterTimestamp = new Timestamp[paramInt][]; System.arraycopy(arrayOfTimestamp, 0, this.parameterTimestamp, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterTimestamp[i] = new Timestamp[this.numberOfBindPositions];  }  if (this.parameterDatum != null) { byte[][][] arrayOfByte = this.parameterDatum; this.parameterDatum = new byte[paramInt][][]; System.arraycopy(arrayOfByte, 0, this.parameterDatum, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterDatum[i] = new byte[this.numberOfBindPositions][];  }  if (this.parameterOtype != null) { OracleTypeADT[][] arrayOfOracleTypeADT = this.parameterOtype; this.parameterOtype = new OracleTypeADT[paramInt][]; System.arraycopy(arrayOfOracleTypeADT, 0, this.parameterOtype, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterOtype[i] = new OracleTypeADT[this.numberOfBindPositions];  }  if (this.parameterStream != null) { InputStream[][] arrayOfInputStream = this.parameterStream; this.parameterStream = new InputStream[paramInt][]; System.arraycopy(arrayOfInputStream, 0, this.parameterStream, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterStream[i] = new InputStream[this.numberOfBindPositions];  }  if (this.userStream != null) { Object[][] arrayOfObject = this.userStream; this.userStream = new Object[paramInt][]; System.arraycopy(arrayOfObject, 0, this.userStream, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.userStream[i] = new Object[this.numberOfBindPositions];  }  if (this.parameterPlsqlIbt != null) { PlsqlIbtBindInfo[][] arrayOfPlsqlIbtBindInfo = this.parameterPlsqlIbt; this.parameterPlsqlIbt = new PlsqlIbtBindInfo[paramInt][]; System.arraycopy(arrayOfPlsqlIbtBindInfo, 0, this.parameterPlsqlIbt, 0, this.numberOfBindRowsAllocated); i = this.numberOfBindRowsAllocated; for (; i < paramInt; i++) this.parameterPlsqlIbt[i] = new PlsqlIbtBindInfo[this.numberOfBindPositions];  }  this.numberOfBindRowsAllocated = paramInt; this.currentRowNeedToPrepareBinds = true; }
/*       */   void processCompletedBindRow(int paramInt, boolean paramBoolean) throws SQLException { // Byte code:
/*       */     //   0: aload_0
/*       */     //   1: getfield numberOfBindPositions : I
/*       */     //   4: ifne -> 8
/*       */     //   7: return
/*       */     //   8: iconst_0
/*       */     //   9: istore #4
/*       */     //   11: iconst_0
/*       */     //   12: istore #5
/*       */     //   14: iconst_0
/*       */     //   15: istore #6
/*       */     //   17: aload_0
/*       */     //   18: getfield currentRank : I
/*       */     //   21: aload_0
/*       */     //   22: getfield firstRowInBatch : I
/*       */     //   25: if_icmpne -> 32
/*       */     //   28: iconst_1
/*       */     //   29: goto -> 33
/*       */     //   32: iconst_0
/*       */     //   33: istore #7
/*       */     //   35: aload_0
/*       */     //   36: getfield currentRank : I
/*       */     //   39: ifne -> 62
/*       */     //   42: aload_0
/*       */     //   43: getfield lastBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   46: iconst_0
/*       */     //   47: aaload
/*       */     //   48: ifnonnull -> 55
/*       */     //   51: aconst_null
/*       */     //   52: goto -> 73
/*       */     //   55: aload_0
/*       */     //   56: getfield lastBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   59: goto -> 73
/*       */     //   62: aload_0
/*       */     //   63: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   66: aload_0
/*       */     //   67: getfield currentRank : I
/*       */     //   70: iconst_1
/*       */     //   71: isub
/*       */     //   72: aaload
/*       */     //   73: astore #8
/*       */     //   75: aload_0
/*       */     //   76: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   79: ifnonnull -> 591
/*       */     //   82: aload_0
/*       */     //   83: getfield isAutoGeneratedKey : Z
/*       */     //   86: ifeq -> 100
/*       */     //   89: aload_0
/*       */     //   90: getfield clearParameters : Z
/*       */     //   93: ifeq -> 100
/*       */     //   96: iconst_1
/*       */     //   97: goto -> 101
/*       */     //   100: iconst_0
/*       */     //   101: istore #9
/*       */     //   103: aload #8
/*       */     //   105: ifnonnull -> 174
/*       */     //   108: iconst_0
/*       */     //   109: istore_3
/*       */     //   110: iload_3
/*       */     //   111: aload_0
/*       */     //   112: getfield numberOfBindPositions : I
/*       */     //   115: if_icmpge -> 565
/*       */     //   118: aload_0
/*       */     //   119: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   122: iload_3
/*       */     //   123: aaload
/*       */     //   124: ifnonnull -> 168
/*       */     //   127: iload #9
/*       */     //   129: ifeq -> 142
/*       */     //   132: aload_0
/*       */     //   133: invokevirtual registerReturnParamsForAutoKey : ()V
/*       */     //   136: iconst_0
/*       */     //   137: istore #9
/*       */     //   139: goto -> 168
/*       */     //   142: aload_0
/*       */     //   143: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   146: bipush #41
/*       */     //   148: iload_3
/*       */     //   149: iconst_1
/*       */     //   150: iadd
/*       */     //   151: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   154: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   157: astore #10
/*       */     //   159: aload #10
/*       */     //   161: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   164: pop
/*       */     //   165: aload #10
/*       */     //   167: athrow
/*       */     //   168: iinc #3, 1
/*       */     //   171: goto -> 110
/*       */     //   174: aload_0
/*       */     //   175: getfield checkBindTypes : Z
/*       */     //   178: ifeq -> 462
/*       */     //   181: aload_0
/*       */     //   182: getfield currentRank : I
/*       */     //   185: ifne -> 195
/*       */     //   188: aload_0
/*       */     //   189: getfield lastBoundTypeOtypes : [Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   192: goto -> 217
/*       */     //   195: aload_0
/*       */     //   196: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   199: ifnonnull -> 206
/*       */     //   202: aconst_null
/*       */     //   203: goto -> 217
/*       */     //   206: aload_0
/*       */     //   207: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   210: aload_0
/*       */     //   211: getfield currentRank : I
/*       */     //   214: iconst_1
/*       */     //   215: isub
/*       */     //   216: aaload
/*       */     //   217: astore #10
/*       */     //   219: iconst_0
/*       */     //   220: istore_3
/*       */     //   221: iload_3
/*       */     //   222: aload_0
/*       */     //   223: getfield numberOfBindPositions : I
/*       */     //   226: if_icmpge -> 459
/*       */     //   229: aload_0
/*       */     //   230: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   233: iload_3
/*       */     //   234: aaload
/*       */     //   235: ifnonnull -> 250
/*       */     //   238: iload #9
/*       */     //   240: ifeq -> 250
/*       */     //   243: aload_0
/*       */     //   244: invokevirtual registerReturnParamsForAutoKey : ()V
/*       */     //   247: iconst_0
/*       */     //   248: istore #9
/*       */     //   250: aload_0
/*       */     //   251: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   254: iload_3
/*       */     //   255: aaload
/*       */     //   256: astore #11
/*       */     //   258: aload #11
/*       */     //   260: ifnonnull -> 340
/*       */     //   263: aload_0
/*       */     //   264: getfield clearParameters : Z
/*       */     //   267: ifeq -> 296
/*       */     //   270: aload_0
/*       */     //   271: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   274: bipush #41
/*       */     //   276: iload_3
/*       */     //   277: iconst_1
/*       */     //   278: iadd
/*       */     //   279: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   282: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   285: astore #12
/*       */     //   287: aload #12
/*       */     //   289: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   292: pop
/*       */     //   293: aload #12
/*       */     //   295: athrow
/*       */     //   296: aload_0
/*       */     //   297: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   300: iload_3
/*       */     //   301: aload #8
/*       */     //   303: iload_3
/*       */     //   304: aaload
/*       */     //   305: invokevirtual copyingBinder : ()Loracle/jdbc/driver/Binder;
/*       */     //   308: aastore
/*       */     //   309: aload_0
/*       */     //   310: getfield currentRank : I
/*       */     //   313: ifne -> 327
/*       */     //   316: aload_0
/*       */     //   317: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   320: iload_3
/*       */     //   321: aaload
/*       */     //   322: aload_0
/*       */     //   323: iload_3
/*       */     //   324: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   327: aload_0
/*       */     //   328: getfield currentRowCharLens : [I
/*       */     //   331: iload_3
/*       */     //   332: iconst_m1
/*       */     //   333: iastore
/*       */     //   334: iconst_1
/*       */     //   335: istore #5
/*       */     //   337: goto -> 435
/*       */     //   340: aload #11
/*       */     //   342: getfield type : S
/*       */     //   345: istore #12
/*       */     //   347: iload #12
/*       */     //   349: aload #8
/*       */     //   351: iload_3
/*       */     //   352: aaload
/*       */     //   353: getfield type : S
/*       */     //   356: if_icmpne -> 432
/*       */     //   359: iload #12
/*       */     //   361: bipush #109
/*       */     //   363: if_icmpeq -> 373
/*       */     //   366: iload #12
/*       */     //   368: bipush #111
/*       */     //   370: if_icmpne -> 394
/*       */     //   373: aload_0
/*       */     //   374: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   377: aload_0
/*       */     //   378: getfield currentRank : I
/*       */     //   381: aaload
/*       */     //   382: iload_3
/*       */     //   383: aaload
/*       */     //   384: aload #10
/*       */     //   386: iload_3
/*       */     //   387: aaload
/*       */     //   388: invokevirtual isInHierarchyOf : (Loracle/jdbc/oracore/OracleType;)Z
/*       */     //   391: ifeq -> 432
/*       */     //   394: iload #12
/*       */     //   396: bipush #9
/*       */     //   398: if_icmpne -> 435
/*       */     //   401: aload #11
/*       */     //   403: getfield bytelen : I
/*       */     //   406: ifne -> 413
/*       */     //   409: iconst_1
/*       */     //   410: goto -> 414
/*       */     //   413: iconst_0
/*       */     //   414: aload #8
/*       */     //   416: iload_3
/*       */     //   417: aaload
/*       */     //   418: getfield bytelen : I
/*       */     //   421: ifne -> 428
/*       */     //   424: iconst_1
/*       */     //   425: goto -> 429
/*       */     //   428: iconst_0
/*       */     //   429: if_icmpeq -> 435
/*       */     //   432: iconst_1
/*       */     //   433: istore #4
/*       */     //   435: aload_0
/*       */     //   436: getfield currentBatchFormOfUse : [S
/*       */     //   439: iload_3
/*       */     //   440: saload
/*       */     //   441: aload_0
/*       */     //   442: getfield currentRowFormOfUse : [S
/*       */     //   445: iload_3
/*       */     //   446: saload
/*       */     //   447: if_icmpeq -> 453
/*       */     //   450: iconst_1
/*       */     //   451: istore #4
/*       */     //   453: iinc #3, 1
/*       */     //   456: goto -> 221
/*       */     //   459: goto -> 565
/*       */     //   462: iconst_0
/*       */     //   463: istore_3
/*       */     //   464: iload_3
/*       */     //   465: aload_0
/*       */     //   466: getfield numberOfBindPositions : I
/*       */     //   469: if_icmpge -> 565
/*       */     //   472: aload_0
/*       */     //   473: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   476: iload_3
/*       */     //   477: aaload
/*       */     //   478: astore #10
/*       */     //   480: aload #10
/*       */     //   482: ifnonnull -> 559
/*       */     //   485: aload_0
/*       */     //   486: getfield clearParameters : Z
/*       */     //   489: ifeq -> 518
/*       */     //   492: aload_0
/*       */     //   493: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   496: bipush #41
/*       */     //   498: iload_3
/*       */     //   499: iconst_1
/*       */     //   500: iadd
/*       */     //   501: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   504: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   507: astore #11
/*       */     //   509: aload #11
/*       */     //   511: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   514: pop
/*       */     //   515: aload #11
/*       */     //   517: athrow
/*       */     //   518: aload_0
/*       */     //   519: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   522: iload_3
/*       */     //   523: aload #8
/*       */     //   525: iload_3
/*       */     //   526: aaload
/*       */     //   527: invokevirtual copyingBinder : ()Loracle/jdbc/driver/Binder;
/*       */     //   530: aastore
/*       */     //   531: aload_0
/*       */     //   532: getfield currentRank : I
/*       */     //   535: ifne -> 549
/*       */     //   538: aload_0
/*       */     //   539: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   542: iload_3
/*       */     //   543: aaload
/*       */     //   544: aload_0
/*       */     //   545: iload_3
/*       */     //   546: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   549: aload_0
/*       */     //   550: getfield currentRowCharLens : [I
/*       */     //   553: iload_3
/*       */     //   554: iconst_m1
/*       */     //   555: iastore
/*       */     //   556: iconst_1
/*       */     //   557: istore #5
/*       */     //   559: iinc #3, 1
/*       */     //   562: goto -> 464
/*       */     //   565: iload #5
/*       */     //   567: ifeq -> 588
/*       */     //   570: iload #7
/*       */     //   572: ifne -> 583
/*       */     //   575: aload_0
/*       */     //   576: getfield m_batchStyle : I
/*       */     //   579: iconst_2
/*       */     //   580: if_icmpne -> 588
/*       */     //   583: aload_0
/*       */     //   584: iconst_1
/*       */     //   585: putfield lastBoundNeeded : Z
/*       */     //   588: goto -> 1259
/*       */     //   591: aload #8
/*       */     //   593: ifnonnull -> 729
/*       */     //   596: iconst_0
/*       */     //   597: istore_3
/*       */     //   598: iload_3
/*       */     //   599: aload_0
/*       */     //   600: getfield numberOfBindPositions : I
/*       */     //   603: if_icmpge -> 1244
/*       */     //   606: aload_0
/*       */     //   607: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   610: iload_3
/*       */     //   611: aaload
/*       */     //   612: astore #9
/*       */     //   614: aload_0
/*       */     //   615: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   618: iload_3
/*       */     //   619: aaload
/*       */     //   620: astore #10
/*       */     //   622: aload #9
/*       */     //   624: ifnonnull -> 671
/*       */     //   627: aload #10
/*       */     //   629: ifnonnull -> 658
/*       */     //   632: aload_0
/*       */     //   633: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   636: bipush #41
/*       */     //   638: iload_3
/*       */     //   639: iconst_1
/*       */     //   640: iadd
/*       */     //   641: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   644: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   647: astore #11
/*       */     //   649: aload #11
/*       */     //   651: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   654: pop
/*       */     //   655: aload #11
/*       */     //   657: athrow
/*       */     //   658: aload_0
/*       */     //   659: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   662: iload_3
/*       */     //   663: aload_0
/*       */     //   664: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   667: aastore
/*       */     //   668: goto -> 723
/*       */     //   671: aload #10
/*       */     //   673: ifnull -> 723
/*       */     //   676: aload #10
/*       */     //   678: getfield defineType : I
/*       */     //   681: aload #9
/*       */     //   683: getfield type : S
/*       */     //   686: if_icmpeq -> 723
/*       */     //   689: aload_0
/*       */     //   690: getfield connection : Loracle/jdbc/driver/PhysicalConnection;
/*       */     //   693: getfield permitTimestampDateMismatch : Z
/*       */     //   696: ifeq -> 720
/*       */     //   699: aload #9
/*       */     //   701: getfield type : S
/*       */     //   704: sipush #180
/*       */     //   707: if_icmpne -> 720
/*       */     //   710: aload #10
/*       */     //   712: getfield defineType : I
/*       */     //   715: bipush #12
/*       */     //   717: if_icmpeq -> 723
/*       */     //   720: iconst_1
/*       */     //   721: istore #6
/*       */     //   723: iinc #3, 1
/*       */     //   726: goto -> 598
/*       */     //   729: aload_0
/*       */     //   730: getfield checkBindTypes : Z
/*       */     //   733: ifeq -> 1117
/*       */     //   736: aload_0
/*       */     //   737: getfield currentRank : I
/*       */     //   740: ifne -> 750
/*       */     //   743: aload_0
/*       */     //   744: getfield lastBoundTypeOtypes : [Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   747: goto -> 772
/*       */     //   750: aload_0
/*       */     //   751: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   754: ifnonnull -> 761
/*       */     //   757: aconst_null
/*       */     //   758: goto -> 772
/*       */     //   761: aload_0
/*       */     //   762: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   765: aload_0
/*       */     //   766: getfield currentRank : I
/*       */     //   769: iconst_1
/*       */     //   770: isub
/*       */     //   771: aaload
/*       */     //   772: astore #9
/*       */     //   774: iconst_0
/*       */     //   775: istore_3
/*       */     //   776: iload_3
/*       */     //   777: aload_0
/*       */     //   778: getfield numberOfBindPositions : I
/*       */     //   781: if_icmpge -> 1114
/*       */     //   784: aload_0
/*       */     //   785: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   788: iload_3
/*       */     //   789: aaload
/*       */     //   790: astore #10
/*       */     //   792: aload_0
/*       */     //   793: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   796: iload_3
/*       */     //   797: aaload
/*       */     //   798: astore #11
/*       */     //   800: aload #10
/*       */     //   802: ifnonnull -> 885
/*       */     //   805: aload_0
/*       */     //   806: getfield clearParameters : Z
/*       */     //   809: ifeq -> 849
/*       */     //   812: aload #8
/*       */     //   814: iload_3
/*       */     //   815: aaload
/*       */     //   816: aload_0
/*       */     //   817: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   820: if_acmpeq -> 849
/*       */     //   823: aload_0
/*       */     //   824: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   827: bipush #41
/*       */     //   829: iload_3
/*       */     //   830: iconst_1
/*       */     //   831: iadd
/*       */     //   832: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   835: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   838: astore #12
/*       */     //   840: aload #12
/*       */     //   842: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   845: pop
/*       */     //   846: aload #12
/*       */     //   848: athrow
/*       */     //   849: aload #8
/*       */     //   851: iload_3
/*       */     //   852: aaload
/*       */     //   853: astore #10
/*       */     //   855: aload_0
/*       */     //   856: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   859: iload_3
/*       */     //   860: aload #10
/*       */     //   862: aastore
/*       */     //   863: aload_0
/*       */     //   864: getfield currentRowCharLens : [I
/*       */     //   867: iload_3
/*       */     //   868: iconst_m1
/*       */     //   869: iastore
/*       */     //   870: aload #10
/*       */     //   872: aload_0
/*       */     //   873: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   876: if_acmpeq -> 980
/*       */     //   879: iconst_1
/*       */     //   880: istore #5
/*       */     //   882: goto -> 980
/*       */     //   885: aload #10
/*       */     //   887: getfield type : S
/*       */     //   890: istore #12
/*       */     //   892: iload #12
/*       */     //   894: aload #8
/*       */     //   896: iload_3
/*       */     //   897: aaload
/*       */     //   898: getfield type : S
/*       */     //   901: if_icmpne -> 977
/*       */     //   904: iload #12
/*       */     //   906: bipush #109
/*       */     //   908: if_icmpeq -> 918
/*       */     //   911: iload #12
/*       */     //   913: bipush #111
/*       */     //   915: if_icmpne -> 939
/*       */     //   918: aload_0
/*       */     //   919: getfield parameterOtype : [[Loracle/jdbc/oracore/OracleTypeADT;
/*       */     //   922: aload_0
/*       */     //   923: getfield currentRank : I
/*       */     //   926: aaload
/*       */     //   927: iload_3
/*       */     //   928: aaload
/*       */     //   929: aload #9
/*       */     //   931: iload_3
/*       */     //   932: aaload
/*       */     //   933: invokevirtual isInHierarchyOf : (Loracle/jdbc/oracore/OracleType;)Z
/*       */     //   936: ifeq -> 977
/*       */     //   939: iload #12
/*       */     //   941: bipush #9
/*       */     //   943: if_icmpne -> 980
/*       */     //   946: aload #10
/*       */     //   948: getfield bytelen : I
/*       */     //   951: ifne -> 958
/*       */     //   954: iconst_1
/*       */     //   955: goto -> 959
/*       */     //   958: iconst_0
/*       */     //   959: aload #8
/*       */     //   961: iload_3
/*       */     //   962: aaload
/*       */     //   963: getfield bytelen : I
/*       */     //   966: ifne -> 973
/*       */     //   969: iconst_1
/*       */     //   970: goto -> 974
/*       */     //   973: iconst_0
/*       */     //   974: if_icmpeq -> 980
/*       */     //   977: iconst_1
/*       */     //   978: istore #4
/*       */     //   980: aload_0
/*       */     //   981: getfield currentBatchFormOfUse : [S
/*       */     //   984: iload_3
/*       */     //   985: saload
/*       */     //   986: aload_0
/*       */     //   987: getfield currentRowFormOfUse : [S
/*       */     //   990: iload_3
/*       */     //   991: saload
/*       */     //   992: if_icmpeq -> 998
/*       */     //   995: iconst_1
/*       */     //   996: istore #4
/*       */     //   998: aload_0
/*       */     //   999: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1002: iload_3
/*       */     //   1003: aaload
/*       */     //   1004: astore #12
/*       */     //   1006: aload #11
/*       */     //   1008: ifnonnull -> 1026
/*       */     //   1011: aload #12
/*       */     //   1013: astore #11
/*       */     //   1015: aload_0
/*       */     //   1016: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1019: iload_3
/*       */     //   1020: aload #11
/*       */     //   1022: aastore
/*       */     //   1023: goto -> 1047
/*       */     //   1026: aload #12
/*       */     //   1028: ifnull -> 1047
/*       */     //   1031: aload #11
/*       */     //   1033: getfield defineType : I
/*       */     //   1036: aload #12
/*       */     //   1038: getfield defineType : I
/*       */     //   1041: if_icmpeq -> 1047
/*       */     //   1044: iconst_1
/*       */     //   1045: istore #4
/*       */     //   1047: aload #11
/*       */     //   1049: ifnull -> 1108
/*       */     //   1052: aload #10
/*       */     //   1054: aload_0
/*       */     //   1055: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1058: if_acmpeq -> 1108
/*       */     //   1061: aload #11
/*       */     //   1063: getfield defineType : I
/*       */     //   1066: aload #10
/*       */     //   1068: getfield type : S
/*       */     //   1071: if_icmpeq -> 1108
/*       */     //   1074: aload_0
/*       */     //   1075: getfield connection : Loracle/jdbc/driver/PhysicalConnection;
/*       */     //   1078: getfield permitTimestampDateMismatch : Z
/*       */     //   1081: ifeq -> 1105
/*       */     //   1084: aload #10
/*       */     //   1086: getfield type : S
/*       */     //   1089: sipush #180
/*       */     //   1092: if_icmpne -> 1105
/*       */     //   1095: aload #11
/*       */     //   1097: getfield defineType : I
/*       */     //   1100: bipush #12
/*       */     //   1102: if_icmpeq -> 1108
/*       */     //   1105: iconst_1
/*       */     //   1106: istore #6
/*       */     //   1108: iinc #3, 1
/*       */     //   1111: goto -> 776
/*       */     //   1114: goto -> 1244
/*       */     //   1117: iconst_0
/*       */     //   1118: istore_3
/*       */     //   1119: iload_3
/*       */     //   1120: aload_0
/*       */     //   1121: getfield numberOfBindPositions : I
/*       */     //   1124: if_icmpge -> 1244
/*       */     //   1127: aload_0
/*       */     //   1128: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1131: iload_3
/*       */     //   1132: aaload
/*       */     //   1133: astore #9
/*       */     //   1135: aload #9
/*       */     //   1137: ifnonnull -> 1217
/*       */     //   1140: aload_0
/*       */     //   1141: getfield clearParameters : Z
/*       */     //   1144: ifeq -> 1184
/*       */     //   1147: aload #8
/*       */     //   1149: iload_3
/*       */     //   1150: aaload
/*       */     //   1151: aload_0
/*       */     //   1152: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1155: if_acmpeq -> 1184
/*       */     //   1158: aload_0
/*       */     //   1159: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   1162: bipush #41
/*       */     //   1164: iload_3
/*       */     //   1165: iconst_1
/*       */     //   1166: iadd
/*       */     //   1167: invokestatic valueOf : (I)Ljava/lang/Integer;
/*       */     //   1170: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;ILjava/lang/Object;)Ljava/sql/SQLException;
/*       */     //   1173: astore #10
/*       */     //   1175: aload #10
/*       */     //   1177: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   1180: pop
/*       */     //   1181: aload #10
/*       */     //   1183: athrow
/*       */     //   1184: aload #8
/*       */     //   1186: iload_3
/*       */     //   1187: aaload
/*       */     //   1188: astore #9
/*       */     //   1190: aload_0
/*       */     //   1191: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1194: iload_3
/*       */     //   1195: aload #9
/*       */     //   1197: aastore
/*       */     //   1198: aload_0
/*       */     //   1199: getfield currentRowCharLens : [I
/*       */     //   1202: iload_3
/*       */     //   1203: iconst_m1
/*       */     //   1204: iastore
/*       */     //   1205: aload #9
/*       */     //   1207: aload_0
/*       */     //   1208: getfield theOutBinder : Loracle/jdbc/driver/Binder;
/*       */     //   1211: if_acmpeq -> 1217
/*       */     //   1214: iconst_1
/*       */     //   1215: istore #5
/*       */     //   1217: aload_0
/*       */     //   1218: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1221: iload_3
/*       */     //   1222: aaload
/*       */     //   1223: ifnonnull -> 1238
/*       */     //   1226: aload_0
/*       */     //   1227: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1230: iload_3
/*       */     //   1231: aload_0
/*       */     //   1232: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1235: iload_3
/*       */     //   1236: aaload
/*       */     //   1237: aastore
/*       */     //   1238: iinc #3, 1
/*       */     //   1241: goto -> 1119
/*       */     //   1244: iload #5
/*       */     //   1246: ifeq -> 1259
/*       */     //   1249: iload #7
/*       */     //   1251: ifeq -> 1259
/*       */     //   1254: aload_0
/*       */     //   1255: iconst_1
/*       */     //   1256: putfield lastBoundNeeded : Z
/*       */     //   1259: iload #4
/*       */     //   1261: ifeq -> 1360
/*       */     //   1264: iload #7
/*       */     //   1266: ifne -> 1342
/*       */     //   1269: aload_0
/*       */     //   1270: getfield m_batchStyle : I
/*       */     //   1273: iconst_2
/*       */     //   1274: if_icmpne -> 1285
/*       */     //   1277: aload_0
/*       */     //   1278: iconst_0
/*       */     //   1279: invokevirtual pushBatch : (Z)V
/*       */     //   1282: goto -> 1342
/*       */     //   1285: aload_0
/*       */     //   1286: getfield validRows : I
/*       */     //   1289: istore #9
/*       */     //   1291: aload_0
/*       */     //   1292: aload_0
/*       */     //   1293: invokevirtual sendBatch : ()I
/*       */     //   1296: putfield prematureBatchCount : I
/*       */     //   1299: aload_0
/*       */     //   1300: iload #9
/*       */     //   1302: putfield validRows : I
/*       */     //   1305: iconst_0
/*       */     //   1306: istore_3
/*       */     //   1307: iload_3
/*       */     //   1308: aload_0
/*       */     //   1309: getfield numberOfBindPositions : I
/*       */     //   1312: if_icmpge -> 1332
/*       */     //   1315: aload_0
/*       */     //   1316: getfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1319: iload_3
/*       */     //   1320: aaload
/*       */     //   1321: aload_0
/*       */     //   1322: iload_3
/*       */     //   1323: invokevirtual lastBoundValueCleanup : (Loracle/jdbc/driver/OraclePreparedStatement;I)V
/*       */     //   1326: iinc #3, 1
/*       */     //   1329: goto -> 1307
/*       */     //   1332: iload #5
/*       */     //   1334: ifeq -> 1342
/*       */     //   1337: aload_0
/*       */     //   1338: iconst_1
/*       */     //   1339: putfield lastBoundNeeded : Z
/*       */     //   1342: aload_0
/*       */     //   1343: iconst_1
/*       */     //   1344: putfield needToParse : Z
/*       */     //   1347: aload_0
/*       */     //   1348: iconst_1
/*       */     //   1349: putfield currentRowNeedToPrepareBinds : Z
/*       */     //   1352: aload_0
/*       */     //   1353: iconst_1
/*       */     //   1354: putfield needToPrepareDefineBuffer : Z
/*       */     //   1357: goto -> 1379
/*       */     //   1360: iload_2
/*       */     //   1361: ifeq -> 1379
/*       */     //   1364: aload_0
/*       */     //   1365: iconst_0
/*       */     //   1366: invokevirtual pushBatch : (Z)V
/*       */     //   1369: aload_0
/*       */     //   1370: iconst_0
/*       */     //   1371: putfield needToParse : Z
/*       */     //   1374: aload_0
/*       */     //   1375: iconst_0
/*       */     //   1376: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1379: iload #6
/*       */     //   1381: ifeq -> 1404
/*       */     //   1384: aload_0
/*       */     //   1385: invokevirtual getConnectionDuringExceptionHandling : ()Loracle/jdbc/internal/OracleConnection;
/*       */     //   1388: bipush #12
/*       */     //   1390: invokestatic createSqlException : (Loracle/jdbc/internal/OracleConnection;I)Ljava/sql/SQLException;
/*       */     //   1393: astore #9
/*       */     //   1395: aload #9
/*       */     //   1397: invokevirtual fillInStackTrace : ()Ljava/lang/Throwable;
/*       */     //   1400: pop
/*       */     //   1401: aload #9
/*       */     //   1403: athrow
/*       */     //   1404: iconst_0
/*       */     //   1405: istore_3
/*       */     //   1406: iload_3
/*       */     //   1407: aload_0
/*       */     //   1408: getfield numberOfBindPositions : I
/*       */     //   1411: if_icmpge -> 1491
/*       */     //   1414: aload_0
/*       */     //   1415: getfield currentRowCharLens : [I
/*       */     //   1418: iload_3
/*       */     //   1419: iaload
/*       */     //   1420: istore #9
/*       */     //   1422: iload #9
/*       */     //   1424: iconst_m1
/*       */     //   1425: if_icmpne -> 1447
/*       */     //   1428: aload_0
/*       */     //   1429: getfield currentRank : I
/*       */     //   1432: aload_0
/*       */     //   1433: getfield firstRowInBatch : I
/*       */     //   1436: if_icmpne -> 1447
/*       */     //   1439: aload_0
/*       */     //   1440: getfield lastBoundCharLens : [I
/*       */     //   1443: iload_3
/*       */     //   1444: iaload
/*       */     //   1445: istore #9
/*       */     //   1447: aload_0
/*       */     //   1448: getfield currentBatchCharLens : [I
/*       */     //   1451: iload_3
/*       */     //   1452: iaload
/*       */     //   1453: iload #9
/*       */     //   1455: if_icmpge -> 1466
/*       */     //   1458: aload_0
/*       */     //   1459: getfield currentBatchCharLens : [I
/*       */     //   1462: iload_3
/*       */     //   1463: iload #9
/*       */     //   1465: iastore
/*       */     //   1466: aload_0
/*       */     //   1467: getfield currentRowCharLens : [I
/*       */     //   1470: iload_3
/*       */     //   1471: iconst_0
/*       */     //   1472: iastore
/*       */     //   1473: aload_0
/*       */     //   1474: getfield currentBatchFormOfUse : [S
/*       */     //   1477: iload_3
/*       */     //   1478: aload_0
/*       */     //   1479: getfield currentRowFormOfUse : [S
/*       */     //   1482: iload_3
/*       */     //   1483: saload
/*       */     //   1484: sastore
/*       */     //   1485: iinc #3, 1
/*       */     //   1488: goto -> 1406
/*       */     //   1491: aload_0
/*       */     //   1492: getfield currentRowNeedToPrepareBinds : Z
/*       */     //   1495: ifeq -> 1503
/*       */     //   1498: aload_0
/*       */     //   1499: iconst_1
/*       */     //   1500: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1503: aload_0
/*       */     //   1504: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1507: ifnull -> 1568
/*       */     //   1510: aload_0
/*       */     //   1511: getfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1514: astore #9
/*       */     //   1516: aload_0
/*       */     //   1517: aload_0
/*       */     //   1518: getfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1521: putfield currentBatchBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1524: aload #9
/*       */     //   1526: ifnonnull -> 1541
/*       */     //   1529: aload_0
/*       */     //   1530: getfield numberOfBindPositions : I
/*       */     //   1533: anewarray oracle/jdbc/driver/Accessor
/*       */     //   1536: astore #9
/*       */     //   1538: goto -> 1562
/*       */     //   1541: iconst_0
/*       */     //   1542: istore_3
/*       */     //   1543: iload_3
/*       */     //   1544: aload_0
/*       */     //   1545: getfield numberOfBindPositions : I
/*       */     //   1548: if_icmpge -> 1562
/*       */     //   1551: aload #9
/*       */     //   1553: iload_3
/*       */     //   1554: aconst_null
/*       */     //   1555: aastore
/*       */     //   1556: iinc #3, 1
/*       */     //   1559: goto -> 1543
/*       */     //   1562: aload_0
/*       */     //   1563: aload #9
/*       */     //   1565: putfield currentRowBindAccessors : [Loracle/jdbc/driver/Accessor;
/*       */     //   1568: aload_0
/*       */     //   1569: getfield currentRank : I
/*       */     //   1572: iconst_1
/*       */     //   1573: iadd
/*       */     //   1574: istore #9
/*       */     //   1576: iload #9
/*       */     //   1578: iload_1
/*       */     //   1579: if_icmpge -> 1652
/*       */     //   1582: iload #9
/*       */     //   1584: aload_0
/*       */     //   1585: getfield numberOfBindRowsAllocated : I
/*       */     //   1588: if_icmplt -> 1638
/*       */     //   1591: aload_0
/*       */     //   1592: getfield numberOfBindRowsAllocated : I
/*       */     //   1595: iconst_1
/*       */     //   1596: ishl
/*       */     //   1597: istore #10
/*       */     //   1599: iload #10
/*       */     //   1601: iload #9
/*       */     //   1603: if_icmpgt -> 1612
/*       */     //   1606: iload #9
/*       */     //   1608: iconst_1
/*       */     //   1609: iadd
/*       */     //   1610: istore #10
/*       */     //   1612: aload_0
/*       */     //   1613: iload #10
/*       */     //   1615: invokevirtual growBinds : (I)V
/*       */     //   1618: aload_0
/*       */     //   1619: iconst_1
/*       */     //   1620: putfield currentBatchNeedToPrepareBinds : Z
/*       */     //   1623: aload_0
/*       */     //   1624: getfield pushedBatches : Loracle/jdbc/driver/OraclePreparedStatement$PushedBatch;
/*       */     //   1627: ifnull -> 1638
/*       */     //   1630: aload_0
/*       */     //   1631: getfield pushedBatches : Loracle/jdbc/driver/OraclePreparedStatement$PushedBatch;
/*       */     //   1634: iconst_1
/*       */     //   1635: putfield current_batch_need_to_prepare_binds : Z
/*       */     //   1638: aload_0
/*       */     //   1639: aload_0
/*       */     //   1640: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   1643: iload #9
/*       */     //   1645: aaload
/*       */     //   1646: putfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1649: goto -> 1668
/*       */     //   1652: aload_0
/*       */     //   1653: iconst_0
/*       */     //   1654: iload_1
/*       */     //   1655: invokevirtual setupBindBuffers : (II)V
/*       */     //   1658: aload_0
/*       */     //   1659: aload_0
/*       */     //   1660: getfield binders : [[Loracle/jdbc/driver/Binder;
/*       */     //   1663: iconst_0
/*       */     //   1664: aaload
/*       */     //   1665: putfield currentRowBinders : [Loracle/jdbc/driver/Binder;
/*       */     //   1668: aload_0
/*       */     //   1669: iconst_0
/*       */     //   1670: putfield currentRowNeedToPrepareBinds : Z
/*       */     //   1673: aload_0
/*       */     //   1674: iconst_0
/*       */     //   1675: putfield clearParameters : Z
/*       */     //   1678: return
/*       */     // Line number table:
/*       */     //   Java source line number -> byte code offset
/*       */     //   #1800	-> 0
/*       */     //   #1803	-> 7
/*       */     //   #1806	-> 8
/*       */     //   #1807	-> 11
/*       */     //   #1808	-> 14
/*       */     //   #1809	-> 17
/*       */     //   #1816	-> 35
/*       */     //   #1820	-> 75
/*       */     //   #1822	-> 82
/*       */     //   #1825	-> 103
/*       */     //   #1829	-> 108
/*       */     //   #1830	-> 118
/*       */     //   #1832	-> 127
/*       */     //   #1834	-> 132
/*       */     //   #1835	-> 136
/*       */     //   #1838	-> 142
/*       */     //   #1839	-> 159
/*       */     //   #1840	-> 165
/*       */     //   #1829	-> 168
/*       */     //   #1844	-> 174
/*       */     //   #1849	-> 181
/*       */     //   #1853	-> 219
/*       */     //   #1855	-> 229
/*       */     //   #1857	-> 243
/*       */     //   #1858	-> 247
/*       */     //   #1860	-> 250
/*       */     //   #1862	-> 258
/*       */     //   #1867	-> 263
/*       */     //   #1869	-> 270
/*       */     //   #1870	-> 287
/*       */     //   #1871	-> 293
/*       */     //   #1880	-> 296
/*       */     //   #1883	-> 309
/*       */     //   #1884	-> 316
/*       */     //   #1891	-> 327
/*       */     //   #1897	-> 334
/*       */     //   #1901	-> 340
/*       */     //   #1903	-> 347
/*       */     //   #1912	-> 432
/*       */     //   #1915	-> 435
/*       */     //   #1919	-> 450
/*       */     //   #1853	-> 453
/*       */     //   #1922	-> 459
/*       */     //   #1928	-> 462
/*       */     //   #1930	-> 472
/*       */     //   #1932	-> 480
/*       */     //   #1937	-> 485
/*       */     //   #1939	-> 492
/*       */     //   #1940	-> 509
/*       */     //   #1941	-> 515
/*       */     //   #1950	-> 518
/*       */     //   #1953	-> 531
/*       */     //   #1954	-> 538
/*       */     //   #1960	-> 549
/*       */     //   #1966	-> 556
/*       */     //   #1928	-> 559
/*       */     //   #1971	-> 565
/*       */     //   #1973	-> 583
/*       */     //   #1974	-> 588
/*       */     //   #1979	-> 591
/*       */     //   #1985	-> 596
/*       */     //   #1987	-> 606
/*       */     //   #1988	-> 614
/*       */     //   #1990	-> 622
/*       */     //   #1995	-> 627
/*       */     //   #2000	-> 632
/*       */     //   #2001	-> 649
/*       */     //   #2002	-> 655
/*       */     //   #2008	-> 658
/*       */     //   #2010	-> 671
/*       */     //   #2018	-> 689
/*       */     //   #2022	-> 720
/*       */     //   #1985	-> 723
/*       */     //   #2027	-> 729
/*       */     //   #2034	-> 736
/*       */     //   #2038	-> 774
/*       */     //   #2040	-> 784
/*       */     //   #2041	-> 792
/*       */     //   #2043	-> 800
/*       */     //   #2049	-> 805
/*       */     //   #2052	-> 823
/*       */     //   #2053	-> 840
/*       */     //   #2054	-> 846
/*       */     //   #2065	-> 849
/*       */     //   #2066	-> 855
/*       */     //   #2067	-> 863
/*       */     //   #2069	-> 870
/*       */     //   #2075	-> 879
/*       */     //   #2079	-> 885
/*       */     //   #2081	-> 892
/*       */     //   #2090	-> 977
/*       */     //   #2093	-> 980
/*       */     //   #2097	-> 995
/*       */     //   #2099	-> 998
/*       */     //   #2101	-> 1006
/*       */     //   #2107	-> 1011
/*       */     //   #2108	-> 1015
/*       */     //   #2110	-> 1026
/*       */     //   #2115	-> 1044
/*       */     //   #2117	-> 1047
/*       */     //   #2126	-> 1074
/*       */     //   #2130	-> 1105
/*       */     //   #2038	-> 1108
/*       */     //   #2134	-> 1114
/*       */     //   #2141	-> 1117
/*       */     //   #2143	-> 1127
/*       */     //   #2145	-> 1135
/*       */     //   #2151	-> 1140
/*       */     //   #2153	-> 1158
/*       */     //   #2154	-> 1175
/*       */     //   #2155	-> 1181
/*       */     //   #2165	-> 1184
/*       */     //   #2166	-> 1190
/*       */     //   #2167	-> 1198
/*       */     //   #2169	-> 1205
/*       */     //   #2175	-> 1214
/*       */     //   #2178	-> 1217
/*       */     //   #2183	-> 1226
/*       */     //   #2141	-> 1238
/*       */     //   #2195	-> 1244
/*       */     //   #2196	-> 1254
/*       */     //   #2199	-> 1259
/*       */     //   #2203	-> 1264
/*       */     //   #2209	-> 1269
/*       */     //   #2216	-> 1277
/*       */     //   #2225	-> 1285
/*       */     //   #2227	-> 1291
/*       */     //   #2228	-> 1299
/*       */     //   #2233	-> 1305
/*       */     //   #2234	-> 1315
/*       */     //   #2233	-> 1326
/*       */     //   #2238	-> 1332
/*       */     //   #2239	-> 1337
/*       */     //   #2245	-> 1342
/*       */     //   #2249	-> 1347
/*       */     //   #2252	-> 1352
/*       */     //   #2254	-> 1360
/*       */     //   #2260	-> 1364
/*       */     //   #2264	-> 1369
/*       */     //   #2272	-> 1374
/*       */     //   #2275	-> 1379
/*       */     //   #2282	-> 1384
/*       */     //   #2283	-> 1395
/*       */     //   #2284	-> 1401
/*       */     //   #2296	-> 1404
/*       */     //   #2298	-> 1414
/*       */     //   #2300	-> 1422
/*       */     //   #2301	-> 1439
/*       */     //   #2303	-> 1447
/*       */     //   #2304	-> 1458
/*       */     //   #2306	-> 1466
/*       */     //   #2307	-> 1473
/*       */     //   #2296	-> 1485
/*       */     //   #2312	-> 1491
/*       */     //   #2313	-> 1498
/*       */     //   #2322	-> 1503
/*       */     //   #2324	-> 1510
/*       */     //   #2326	-> 1516
/*       */     //   #2328	-> 1524
/*       */     //   #2329	-> 1529
/*       */     //   #2331	-> 1541
/*       */     //   #2332	-> 1551
/*       */     //   #2331	-> 1556
/*       */     //   #2334	-> 1562
/*       */     //   #2337	-> 1568
/*       */     //   #2339	-> 1576
/*       */     //   #2344	-> 1582
/*       */     //   #2350	-> 1591
/*       */     //   #2352	-> 1599
/*       */     //   #2353	-> 1606
/*       */     //   #2355	-> 1612
/*       */     //   #2357	-> 1618
/*       */     //   #2359	-> 1623
/*       */     //   #2360	-> 1630
/*       */     //   #2364	-> 1638
/*       */     //   #2373	-> 1652
/*       */     //   #2380	-> 1658
/*       */     //   #2385	-> 1668
/*       */     //   #2387	-> 1673
/*       */     //   #2389	-> 1678 }
/*       */   void processPlsqlIndexTabBinds(int paramInt) throws SQLException { byte b1 = 0; int i = 0; int j = 0; int k = 0; Binder[] arrayOfBinder = this.binders[paramInt]; PlsqlIbtBindInfo[] arrayOfPlsqlIbtBindInfo = (this.parameterPlsqlIbt == null) ? null : this.parameterPlsqlIbt[paramInt]; int m; for (m = 0; m < this.numberOfBindPositions; m++) { Binder binder = arrayOfBinder[m]; Accessor accessor = (this.currentBatchBindAccessors == null) ? null : this.currentBatchBindAccessors[m]; PlsqlIndexTableAccessor plsqlIndexTableAccessor = (accessor == null || accessor.defineType != 998) ? null : (PlsqlIndexTableAccessor)accessor; if (binder.type == 998) { PlsqlIbtBindInfo plsqlIbtBindInfo = arrayOfPlsqlIbtBindInfo[m]; if (plsqlIndexTableAccessor != null) { if (plsqlIbtBindInfo.element_internal_type != plsqlIndexTableAccessor.elementInternalType) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12); sQLException.fillInStackTrace(); throw sQLException; }  if (plsqlIbtBindInfo.maxLen < plsqlIndexTableAccessor.maxNumberOfElements) plsqlIbtBindInfo.maxLen = plsqlIndexTableAccessor.maxNumberOfElements;  if (plsqlIbtBindInfo.elemMaxLen < plsqlIndexTableAccessor.elementMaxLen) plsqlIbtBindInfo.elemMaxLen = plsqlIndexTableAccessor.elementMaxLen;  if (plsqlIbtBindInfo.ibtByteLength > 0) { plsqlIbtBindInfo.ibtByteLength = plsqlIbtBindInfo.elemMaxLen * plsqlIbtBindInfo.maxLen; } else { plsqlIbtBindInfo.ibtCharLength = plsqlIbtBindInfo.elemMaxLen * plsqlIbtBindInfo.maxLen; }  }  b1++; j += plsqlIbtBindInfo.ibtByteLength; k += plsqlIbtBindInfo.ibtCharLength; i += plsqlIbtBindInfo.maxLen; } else if (plsqlIndexTableAccessor != null) { b1++; j += plsqlIndexTableAccessor.ibtByteLength; k += plsqlIndexTableAccessor.ibtCharLength; i += plsqlIndexTableAccessor.maxNumberOfElements; }  }  if (b1 == 0) return;  this.ibtBindIndicatorSize = 6 + b1 * 8 + i * 2; this.ibtBindIndicators = new short[this.ibtBindIndicatorSize]; this.ibtBindIndicatorOffset = 0; if (j > 0) this.ibtBindBytes = new byte[j];  this.ibtBindByteOffset = 0; if (k > 0)
/*       */       this.ibtBindChars = new char[k];  this.ibtBindCharOffset = 0; m = this.ibtBindByteOffset; int n = this.ibtBindCharOffset; int i1 = this.ibtBindIndicatorOffset; int i2 = i1 + 6 + b1 * 8; this.ibtBindIndicators[i1++] = (short)(b1 >> 16); this.ibtBindIndicators[i1++] = (short)(b1 & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(j >> 16); this.ibtBindIndicators[i1++] = (short)(j & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(k >> 16); this.ibtBindIndicators[i1++] = (short)(k & 0xFFFF); for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) { Binder binder = arrayOfBinder[b2]; Accessor accessor = (this.currentBatchBindAccessors == null) ? null : this.currentBatchBindAccessors[b2]; PlsqlIndexTableAccessor plsqlIndexTableAccessor = (accessor == null || accessor.defineType != 998) ? null : (PlsqlIndexTableAccessor)accessor; if (binder.type == 998) { int i3; PlsqlIbtBindInfo plsqlIbtBindInfo = arrayOfPlsqlIbtBindInfo[b2]; int i4 = plsqlIbtBindInfo.maxLen; this.ibtBindIndicators[i1++] = (short)plsqlIbtBindInfo.element_internal_type; this.ibtBindIndicators[i1++] = (short)plsqlIbtBindInfo.elemMaxLen; this.ibtBindIndicators[i1++] = (short)(i4 >> 16); this.ibtBindIndicators[i1++] = (short)(i4 & 0xFFFF); this.ibtBindIndicators[i1++] = (short)(plsqlIbtBindInfo.curLen >> 16); this.ibtBindIndicators[i1++] = (short)(plsqlIbtBindInfo.curLen & 0xFFFF); if (plsqlIbtBindInfo.ibtByteLength > 0) { i3 = m; m += plsqlIbtBindInfo.ibtByteLength; } else { i3 = n; n += plsqlIbtBindInfo.ibtCharLength; }  this.ibtBindIndicators[i1++] = (short)(i3 >> 16); this.ibtBindIndicators[i1++] = (short)(i3 & 0xFFFF); plsqlIbtBindInfo.ibtValueIndex = i3; plsqlIbtBindInfo.ibtIndicatorIndex = i2; plsqlIbtBindInfo.ibtLengthIndex = i2 + i4; if (plsqlIndexTableAccessor != null) { plsqlIndexTableAccessor.ibtIndicatorIndex = plsqlIbtBindInfo.ibtIndicatorIndex; plsqlIndexTableAccessor.ibtLengthIndex = plsqlIbtBindInfo.ibtLengthIndex; plsqlIndexTableAccessor.ibtMetaIndex = i1 - 8; plsqlIndexTableAccessor.ibtValueIndex = i3; }  i2 += 2 * i4; } else if (plsqlIndexTableAccessor != null) { int i3, i4 = plsqlIndexTableAccessor.maxNumberOfElements; this.ibtBindIndicators[i1++] = (short)plsqlIndexTableAccessor.elementInternalType; this.ibtBindIndicators[i1++] = (short)plsqlIndexTableAccessor.elementMaxLen; this.ibtBindIndicators[i1++] = (short)(i4 >> 16); this.ibtBindIndicators[i1++] = (short)(i4 & 0xFFFF); this.ibtBindIndicators[i1++] = 0; this.ibtBindIndicators[i1++] = 0; if (plsqlIndexTableAccessor.ibtByteLength > 0) { i3 = m; m += plsqlIndexTableAccessor.ibtByteLength; } else { i3 = n; n += plsqlIndexTableAccessor.ibtCharLength; }  this.ibtBindIndicators[i1++] = (short)(i3 >> 16); this.ibtBindIndicators[i1++] = (short)(i3 & 0xFFFF); plsqlIndexTableAccessor.ibtValueIndex = i3; plsqlIndexTableAccessor.ibtIndicatorIndex = i2; plsqlIndexTableAccessor.ibtLengthIndex = i2 + i4; plsqlIndexTableAccessor.ibtMetaIndex = i1 - 8; i2 += 2 * i4; }  }  }
/*       */   void initializeBindSubRanges(int paramInt1, int paramInt2) { this.bindByteSubRange = 0; this.bindCharSubRange = 0; }
/*       */   int calculateIndicatorSubRangeSize() { return 0; }
/*  1155 */   private int maxStreamNCharsSql = 0; short getInoutIndicator(int paramInt) { return 0; } void initializeIndicatorSubRange() { this.bindIndicatorSubRange = calculateIndicatorSubRangeSize(); } void prepareBindPreambles(int paramInt1, int paramInt2) {} void setupBindBuffers(int paramInt1, int paramInt2) throws SQLException { try { if (this.numberOfBindPositions == 0) { if (paramInt2 != 0) { if (this.bindIndicators == null)
/*       */             allocBinds(paramInt2);  this.numberOfBoundRows = paramInt2; this.bindIndicators[this.bindIndicatorSubRange + 3] = (short)((this.numberOfBoundRows & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 4] = (short)(this.numberOfBoundRows & 0xFFFF); }  return; }  this.preparedAllBinds = this.currentBatchNeedToPrepareBinds; this.preparedCharBinds = false; this.currentBatchNeedToPrepareBinds = false; this.numberOfBoundRows = paramInt2; this.bindIndicators[this.bindIndicatorSubRange + 3] = (short)((this.numberOfBoundRows & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 4] = (short)(this.numberOfBoundRows & 0xFFFF); int i = this.bindBufferCapacity; if (this.numberOfBoundRows > this.bindBufferCapacity) { i = this.numberOfBoundRows; this.preparedAllBinds = true; }  if (this.currentBatchBindAccessors != null) { if (this.outBindAccessors == null)
/*       */           this.outBindAccessors = new Accessor[this.numberOfBindPositions];  for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { Accessor accessor = this.currentBatchBindAccessors[b1]; this.outBindAccessors[b1] = accessor; if (accessor != null) { int i8 = accessor.charLength; if (i8 == 0 || this.currentBatchCharLens[b1] < i8)
/*       */               this.currentBatchCharLens[b1] = i8;  }  }  }  int j = 0; int k = 0; int m = this.bindIndicatorSubRange + 5; int n = m; if (this.preparedAllBinds) { this.preparedCharBinds = true; Binder[] arrayOfBinder1 = this.binders[paramInt1]; for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { short s; char c; Binder binder = arrayOfBinder1[b1]; int i8 = this.currentBatchCharLens[b1]; if (binder == this.theOutBinder) { Accessor accessor = this.currentBatchBindAccessors[b1]; c = accessor.byteLength; s = (short)accessor.defineType; } else { c = binder.bytelen; s = binder.type; }  if (binder == this.theRawNullBinder && this.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK)
/*       */             c = '翿';  k += c; j += i8; this.bindIndicators[n + 0] = s; this.bindIndicators[n + 1] = (short)c; this.bindIndicators[n + 2] = (short)i8; this.bindIndicators[n + 9] = this.currentBatchFormOfUse[b1]; n += 10; }  } else if (this.preparedCharBinds) { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { int i8 = this.currentBatchCharLens[b1]; j += i8; this.bindIndicators[n + 2] = (short)i8; n += 10; }  } else { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { int i8 = n + 2; int i9 = this.currentBatchCharLens[b1]; short s = this.bindIndicators[i8]; int i10 = (this.bindIndicators[n + 5] << 16) + (this.bindIndicators[n + 6] & 0xFFFF); boolean bool1 = (this.bindIndicators[i10] == -1) ? true : false; if (bool1 && i9 > 1)
/*       */             this.preparedCharBinds = true;  if (s >= i9 && !this.preparedCharBinds) { this.currentBatchCharLens[b1] = s; j += s; } else { this.bindIndicators[i8] = (short)i9; j += i9; this.preparedCharBinds = true; }  n += 10; }
/*       */          }
/*       */        if (this.preparedCharBinds)
/*       */         initializeBindSubRanges(this.numberOfBoundRows, i);  if (this.preparedAllBinds) { int i8 = this.bindByteSubRange + k * i; if (this.lastBoundNeeded || i8 > this.totalBindByteLength) { this.bindByteOffset = 0; this.bindBytes = this.connection.getByteBuffer(i8); this.totalBindByteLength = i8; }
/*       */          this.bindBufferCapacity = i; this.bindIndicators[this.bindIndicatorSubRange + 1] = (short)((this.bindBufferCapacity & 0xFFFF0000) >> 16); this.bindIndicators[this.bindIndicatorSubRange + 2] = (short)(this.bindBufferCapacity & 0xFFFF); }
/*       */        if (this.preparedCharBinds) { int i8 = this.bindCharSubRange + j * this.bindBufferCapacity; if (this.lastBoundNeeded || i8 > this.totalBindCharLength) { this.bindCharOffset = 0; this.bindChars = this.connection.getCharBuffer(i8); this.totalBindCharLength = i8; }
/*       */          this.bindByteSubRange += this.bindByteOffset; this.bindCharSubRange += this.bindCharOffset; }
/*       */        int i1 = this.bindByteSubRange; int i2 = this.bindCharSubRange; int i3 = this.indicatorsOffset; int i4 = this.valueLengthsOffset; n = m; if (this.preparedCharBinds) { if (this.currentBatchBindAccessors == null) { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { short s = this.bindIndicators[n + 1]; int i8 = this.currentBatchCharLens[b1]; int i9 = (i8 == 0) ? i1 : i2; this.bindIndicators[n + 3] = (short)(i9 >> 16); this.bindIndicators[n + 4] = (short)(i9 & 0xFFFF); i1 += s * this.bindBufferCapacity; i2 += i8 * this.bindBufferCapacity; n += 10; }
/*       */            }
/*       */         else { for (byte b1 = 0; b1 < this.numberOfBindPositions; b1++) { short s = this.bindIndicators[n + 1]; int i8 = this.currentBatchCharLens[b1]; int i9 = (i8 == 0) ? i1 : i2; this.bindIndicators[n + 3] = (short)(i9 >> 16); this.bindIndicators[n + 4] = (short)(i9 & 0xFFFF); Accessor accessor = this.currentBatchBindAccessors[b1]; if (accessor != null) { if (i8 > 0) { accessor.columnIndex = i2; accessor.charLength = i8; }
/*       */               else { accessor.columnIndex = i1; accessor.byteLength = s; }
/*       */                accessor.lengthIndex = i4; accessor.indicatorIndex = i3; accessor.rowSpaceByte = this.bindBytes; accessor.rowSpaceChar = this.bindChars; accessor.rowSpaceIndicator = this.bindIndicators; if (accessor.defineType == 109 || accessor.defineType == 111)
/*       */                 accessor.setOffsets(this.bindBufferCapacity);  }
/*       */              i1 += s * this.bindBufferCapacity; i2 += i8 * this.bindBufferCapacity; i3 += this.numberOfBindRowsAllocated; i4 += this.numberOfBindRowsAllocated; n += 10; }
/*       */            }
/*       */          i1 = this.bindByteSubRange; i2 = this.bindCharSubRange; i3 = this.indicatorsOffset; i4 = this.valueLengthsOffset; n = m; }
/*       */        int i5 = this.bindBufferCapacity - this.numberOfBoundRows; int i6 = this.numberOfBoundRows - 1; int i7 = i6 + paramInt1; Binder[] arrayOfBinder = this.binders[i7]; if (this.parameterOtype != null) { System.arraycopy(this.parameterDatum[i7], 0, this.lastBoundTypeBytes, 0, this.numberOfBindPositions); System.arraycopy(this.parameterOtype[i7], 0, this.lastBoundTypeOtypes, 0, this.numberOfBindPositions); }
/*       */        if (this.hasIbtBind)
/*       */         processPlsqlIndexTabBinds(paramInt1);  if (this.numReturnParams > 0 && (this.returnParamAccessors == null || this.returnParamAccessors.length < this.numReturnParams)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173); sQLException.fillInStackTrace(); throw sQLException; }
/*       */        if (this.returnParamAccessors != null)
/*       */         processDmlReturningBind();  boolean bool = (!this.sqlKind.isPlsqlOrCall() || this.currentRowBindAccessors == null) ? true : false; for (byte b = 0; b < this.numberOfBindPositions; b++) { short s = this.bindIndicators[n + 1]; int i8 = this.currentBatchCharLens[b]; this.lastBinders[b] = arrayOfBinder[b]; this.lastBoundByteLens[b] = s; for (byte b1 = 0; b1 < this.numberOfBoundRows; b1++) { int i9 = paramInt1 + b1; this.binders[i9][b].bind(this, b, b1, i9, this.bindBytes, this.bindChars, this.bindIndicators, s, i8, i1, i2, i4 + b1, i3 + b1, bool); this.binders[i9][b] = null; if (this.userStream != null)
/*       */             this.userStream[b1][b] = null;  i1 += s; i2 += i8; }
/*       */          this.lastBoundByteOffsets[b] = i1 - s; this.lastBoundCharOffsets[b] = i2 - i8; this.lastBoundInds[b] = this.bindIndicators[i3 + i6]; this.lastBoundLens[b] = this.bindIndicators[i4 + i6]; this.lastBoundCharLens[b] = 0; i1 += i5 * s; i2 += i5 * i8; i3 += this.numberOfBindRowsAllocated; i4 += this.numberOfBindRowsAllocated; n += 10; }
/*       */        this.lastBoundBytes = this.bindBytes; this.lastBoundByteOffset = this.bindByteOffset; this.lastBoundChars = this.bindChars; this.lastBoundCharOffset = this.bindCharOffset; if (this.parameterStream != null)
/*       */         this.lastBoundStream = this.parameterStream[paramInt1 + this.numberOfBoundRows - 1];  int[] arrayOfInt = this.currentBatchCharLens; this.currentBatchCharLens = this.lastBoundCharLens; this.lastBoundCharLens = arrayOfInt; this.lastBoundNeeded = false; prepareBindPreambles(this.numberOfBoundRows, this.bindBufferCapacity); }
/*       */     catch (NullPointerException nullPointerException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89); sQLException.fillInStackTrace(); throw sQLException; }
/*       */      }
/*       */   void releaseBuffers() { this.cachedBindCharSize = (this.bindChars != null) ? this.bindChars.length : 0; if (this.bindChars != this.lastBoundChars)
/*       */       this.connection.cacheBuffer(this.lastBoundChars);  this.lastBoundChars = null; this.connection.cacheBuffer(this.bindChars); this.bindChars = null; this.cachedBindByteSize = (this.bindBytes != null) ? this.bindBytes.length : 0; if (this.bindBytes != this.lastBoundBytes)
/*       */       this.connection.cacheBuffer(this.lastBoundBytes);  this.lastBoundBytes = null; this.connection.cacheBuffer(this.bindBytes); this.bindBytes = null; super.releaseBuffers(); }
/*       */   public void enterImplicitCache() throws SQLException { alwaysOnClose(); if (!this.connection.isClosed())
/*       */       cleanAllTempLobs();  if (this.connection.clearStatementMetaData) { this.lastBoundBytes = null; this.lastBoundChars = null; }
/*       */      clearParameters(); this.cacheState = 2; this.creationState = 1; this.currentResultSet = null; this.lastIndex = 0; this.queryTimeout = 0; this.autoRollback = 2; this.rowPrefetchChanged = false; this.currentRank = 0; this.currentRow = -1; this.validRows = 0; this.maxRows = 0; this.totalRowsVisited = 0; this.maxFieldSize = 0; this.gotLastBatch = false; this.clearParameters = true; this.scrollRset = null; this.defaultFetchDirection = 1000; this.defaultTimeZone = null; this.defaultCalendar = null; this.checkSum = 0L; this.checkSumComputationFailure = false; if (this.sqlKind.isOTHER()) { this.needToParse = true; this.needToPrepareDefineBuffer = true; this.columnsDefinedByUser = false; }
/*       */      releaseBuffers(); this.definedColumnType = null; this.definedColumnSize = null; this.definedColumnFormOfUse = null; if (this.accessors != null) { int i = this.accessors.length; for (byte b = 0; b < i; b++) { if (this.accessors[b] != null) { (this.accessors[b]).rowSpaceByte = null; (this.accessors[b]).rowSpaceChar = null; (this.accessors[b]).rowSpaceIndicator = null; if (this.columnsDefinedByUser)
/*       */             (this.accessors[b]).externalType = 0;  }
/*       */          }
/*       */        }
/*       */      this.fixedString = this.connection.getDefaultFixedString(); this.defaultRowPrefetch = this.rowPrefetch; this.rowPrefetchInLastFetch = -1; if (this.connection.clearStatementMetaData) { this.sqlStringChanged = true; this.needToParse = true; this.needToPrepareDefineBuffer = true; this.columnsDefinedByUser = false; if (this.userRsetType == 0) { this.userRsetType = 1; this.realRsetType = 1; }
/*       */        this.currentRowNeedToPrepareBinds = true; }
/*       */      }
/*       */   public void enterExplicitCache() throws SQLException { this.cacheState = 2; this.creationState = 2; this.defaultTimeZone = null; alwaysOnClose(); }
/*       */   public void exitImplicitCacheToActive() throws SQLException { this.cacheState = 1; this.closed = false; if (this.rowPrefetch != this.connection.getDefaultRowPrefetch())
/*       */       if (this.streamList == null) { this.rowPrefetch = this.connection.getDefaultRowPrefetch(); this.defaultRowPrefetch = this.rowPrefetch; this.rowPrefetchChanged = true; }
/*       */         if (this.batch != this.connection.getDefaultExecuteBatch())
/*       */       resetBatch();  this.processEscapes = this.connection.processEscapes; if (this.cachedDefineIndicatorSize != 0) { this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize); this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize); this.defineIndicators = new short[this.cachedDefineIndicatorSize]; if (this.accessors != null) { int i = this.accessors.length; for (byte b = 0; b < i; b++) { if (this.accessors[b] != null) { (this.accessors[b]).rowSpaceByte = this.defineBytes; (this.accessors[b]).rowSpaceChar = this.defineChars; (this.accessors[b]).rowSpaceIndicator = this.defineIndicators; }
/*       */            }
/*       */          doInitializationAfterDefineBufferRestore(); }
/*       */        }
/*       */      if (this.cachedBindCharSize != 0 || this.cachedBindByteSize != 0) { if (this.cachedBindByteSize > 0)
/*       */         this.bindBytes = this.connection.getByteBuffer(this.cachedBindByteSize);  if (this.cachedBindCharSize > 0)
/*       */         this.bindChars = this.connection.getCharBuffer(this.cachedBindCharSize);  doLocalInitialization(); }
/*       */      }
/*       */   void doLocalInitialization() {}
/*       */   void doInitializationAfterDefineBufferRestore() {}
/*       */   public void exitExplicitCacheToActive() throws SQLException { this.cacheState = 1; this.closed = false; }
/*       */   public void exitImplicitCacheToClose() throws SQLException { this.cacheState = 0; this.closed = false; synchronized (this.connection) { hardClose(); }
/*       */      }
/*       */   public void exitExplicitCacheToClose() throws SQLException { this.cacheState = 0; this.closed = false; synchronized (this.connection) { hardClose(); }
/*       */      }
/*       */   public void closeWithKey(String paramString) throws SQLException { synchronized (this.connection) { closeOrCache(paramString); }
/*       */      }
/*       */   int executeInternal() throws SQLException { this.noMoreUpdateCounts = false; this.checkSum = 0L; this.checkSumComputationFailure = false; ensureOpen(); if (this.currentRank > 0 && this.m_batchStyle == 2) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared"); sQLException.fillInStackTrace(); throw sQLException; }
/*       */      boolean bool1 = (this.userRsetType == 1) ? true : false; prepareForNewResults(true, false); processCompletedBindRow(this.sqlKind.isSELECT() ? 1 : this.batch, false); if (!bool1 && !this.scrollRsetTypeSolved)
/*       */       return doScrollPstmtExecuteUpdate() + this.prematureBatchCount;  doExecuteWithTimeout(); boolean bool2 = (this.prematureBatchCount != 0 && this.validRows > 0) ? true : false; if (!bool1) { this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType); if (!this.connection.accumulateBatchResult)
/*       */         bool2 = false;  }
/*       */      if (bool2) { this.validRows += this.prematureBatchCount; this.prematureBatchCount = 0; }
/*       */      if (this.sqlKind.isOTHER())
/*       */       this.needToParse = true;  return this.validRows; }
/*       */   public ResultSet executeQuery() throws SQLException { synchronized (this.connection) { this.executionType = 1; executeInternal(); if (this.userRsetType == 1) { this.currentResultSet = new OracleResultSetImpl(this.connection, this); return (ResultSet)this.currentResultSet; }
/*       */        if (this.scrollRset == null) { this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.scrollRset = this.currentResultSet; }
/*       */        return (ResultSet)this.scrollRset; }
/*       */      }
/*       */   public int executeUpdate() throws SQLException { synchronized (this.connection) { this.executionType = 2; return executeInternal(); }
/*       */      }
/*       */   public boolean execute() throws SQLException { synchronized (this.connection) { this.executionType = 3; executeInternal(); return this.sqlKind.isSELECT(); }
/*       */      }
/*       */   void slideDownCurrentRow(int paramInt) { if (this.binders != null) { this.binders[paramInt] = this.binders[0]; this.binders[0] = this.currentRowBinders; }
/*       */      if (this.parameterInt != null) { int[] arrayOfInt = this.parameterInt[0]; this.parameterInt[0] = this.parameterInt[paramInt]; this.parameterInt[paramInt] = arrayOfInt; }
/*       */      if (this.parameterLong != null) { long[] arrayOfLong = this.parameterLong[0]; this.parameterLong[0] = this.parameterLong[paramInt]; this.parameterLong[paramInt] = arrayOfLong; }
/*       */      if (this.parameterFloat != null) { float[] arrayOfFloat = this.parameterFloat[0]; this.parameterFloat[0] = this.parameterFloat[paramInt]; this.parameterFloat[paramInt] = arrayOfFloat; }
/*       */      if (this.parameterDouble != null) { double[] arrayOfDouble = this.parameterDouble[0]; this.parameterDouble[0] = this.parameterDouble[paramInt]; this.parameterDouble[paramInt] = arrayOfDouble; }
/*       */      if (this.parameterBigDecimal != null) { BigDecimal[] arrayOfBigDecimal = this.parameterBigDecimal[0]; this.parameterBigDecimal[0] = this.parameterBigDecimal[paramInt]; this.parameterBigDecimal[paramInt] = arrayOfBigDecimal; }
/*       */      if (this.parameterString != null) { String[] arrayOfString = this.parameterString[0]; this.parameterString[0] = this.parameterString[paramInt]; this.parameterString[paramInt] = arrayOfString; }
/*       */      if (this.parameterDate != null) { Date[] arrayOfDate = this.parameterDate[0]; this.parameterDate[0] = this.parameterDate[paramInt]; this.parameterDate[paramInt] = arrayOfDate; }
/*       */      if (this.parameterTime != null) { Time[] arrayOfTime = this.parameterTime[0]; this.parameterTime[0] = this.parameterTime[paramInt]; this.parameterTime[paramInt] = arrayOfTime; }
/*       */      if (this.parameterTimestamp != null) { Timestamp[] arrayOfTimestamp = this.parameterTimestamp[0]; this.parameterTimestamp[0] = this.parameterTimestamp[paramInt]; this.parameterTimestamp[paramInt] = arrayOfTimestamp; }
/*       */      if (this.parameterDatum != null) { byte[][] arrayOfByte = this.parameterDatum[0]; this.parameterDatum[0] = this.parameterDatum[paramInt]; this.parameterDatum[paramInt] = arrayOfByte; }
/*       */      if (this.parameterOtype != null) { OracleTypeADT[] arrayOfOracleTypeADT = this.parameterOtype[0]; this.parameterOtype[0] = this.parameterOtype[paramInt]; this.parameterOtype[paramInt] = arrayOfOracleTypeADT; }
/*       */      if (this.parameterStream != null) { InputStream[] arrayOfInputStream = this.parameterStream[0]; this.parameterStream[0] = this.parameterStream[paramInt]; this.parameterStream[paramInt] = arrayOfInputStream; }
/*       */      if (this.userStream != null) { Object[] arrayOfObject = this.userStream[0]; this.userStream[0] = this.userStream[paramInt]; this.userStream[paramInt] = arrayOfObject; }
/*       */      }
/*  1251 */   OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException { this(paramPhysicalConnection, paramString, paramInt1, paramInt2, 1003, 1007);
/*       */ 
/*       */     
/*  1254 */     this.cacheState = 1; }
/*       */   void resetBatch() { this.batch = this.connection.getDefaultExecuteBatch(); }
/*       */   public int sendBatch() throws SQLException { if (isJdbcBatchStyle()) return 0;  synchronized (this.connection) { if (!this.connection.isUsable() || this.bsendBatchInProgress) { clearBatch(); this.bsendBatchInProgress = false; return 0; }  try { ensureOpen(); if (this.currentRank <= 0) return this.connection.accumulateBatchResult ? 0 : this.validRows;  int i = this.batch; this.bsendBatchInProgress = true; try { int j = this.currentRank; if (this.batch != this.currentRank) this.batch = this.currentRank;  setupBindBuffers(0, this.currentRank); this.currentRank--; doExecuteWithTimeout(); slideDownCurrentRow(j); } finally { if (this.batch != i) this.batch = i;  }  if (this.connection.accumulateBatchResult) { this.validRows += this.prematureBatchCount; this.prematureBatchCount = 0; }  return this.validRows; } finally { this.currentRank = 0; this.bsendBatchInProgress = false; }  }  }
/*       */   public void setExecuteBatch(int paramInt) throws SQLException { synchronized (this.connection) { setOracleBatchStyle(); set_execute_batch(paramInt); }  }
/*       */   void set_execute_batch(int paramInt) throws SQLException { synchronized (this.connection) { if (paramInt <= 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt == this.batch) return;  if (this.currentRank > 0) { int j = this.validRows; this.prematureBatchCount = sendBatch(); this.validRows = j; }  int i = this.batch; this.batch = paramInt; if (this.numberOfBindRowsAllocated < this.batch) growBinds(this.batch);  }  }
/*       */   public final int getExecuteBatch() { return this.batch; }
/*       */   public void defineParameterTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { SQLException sQLException; if (paramInt3 < 0) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramInt1 < 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  switch (paramInt2) { case -7: case -6: case -5: case 2: case 3: case 4: case 5: case 6: case 7: case 8: paramInt2 = 6; break;case 1: paramInt2 = 96; break;case 12: paramInt2 = 1; break;case 91: case 92: paramInt2 = 12; break;case -103: paramInt2 = 182; break;case -104: paramInt2 = 183; break;case -100: case 93: paramInt2 = 180; break;case -101: paramInt2 = 181; break;case -102: paramInt2 = 231; break;case -3: case -2: paramInt2 = 23; break;case 100: paramInt2 = 100; break;case 101: paramInt2 = 101; break;case -8: paramInt2 = 104; break;case 2004: paramInt2 = 113; break;case 2005: paramInt2 = 112; break;case -13: paramInt2 = 114; break;case -10: paramInt2 = 102; break;case 0: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4); sQLException.fillInStackTrace(); throw sQLException;default: sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }  }  }
/*       */   public void defineParameterTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { int i = this.connection.getNlsRatio(); if (paramInt2 == 1 || paramInt2 == 12) { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3 * i); } else { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3); }  }  }
/*       */   public void defineParameterType(int paramInt1, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { defineParameterTypeBytes(paramInt1, paramInt2, paramInt3); }  }
/*       */   public ResultSetMetaData getMetaData() throws SQLException { if (this.sqlObject.getSqlKind().isSELECT()) return (ResultSetMetaData)new OracleResultSetMetaData(this.connection, this);  return null; }
/*       */   public void setNull(int paramInt1, int paramInt2, String paramString) throws SQLException { setNullInternal(paramInt1, paramInt2, paramString); }
/*       */   void setNullInternal(int paramInt1, int paramInt2, String paramString) throws SQLException { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt2 == 2002 || paramInt2 == 2008 || paramInt2 == 2003 || paramInt2 == 2007 || paramInt2 == 2006) { synchronized (this.connection) { setNullCritical(i, paramInt2, paramString); this.currentRowCharLens[i] = 0; }  } else { setNullInternal(paramInt1, paramInt2); return; }  }
/*  1266 */   void setNullInternal(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setNullCritical(paramInt1, paramInt2); }  } void setNullCritical(int paramInt1, int paramInt2, String paramString) throws SQLException { OracleTypeCOLLECTION oracleTypeCOLLECTION; OracleTypeADT oracleTypeADT1; StructDescriptor structDescriptor; ArrayDescriptor arrayDescriptor; OpaqueDescriptor opaqueDescriptor; OracleTypeADT oracleTypeADT2 = null; Binder binder = this.theNamedTypeNullBinder; switch (paramInt2) { case 2006: binder = this.theRefTypeNullBinder;case 2002: case 2008: structDescriptor = StructDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeADT2 = structDescriptor.getOracleTypeADT(); break;case 2003: arrayDescriptor = ArrayDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeCOLLECTION = arrayDescriptor.getOracleTypeCOLLECTION(); break;case 2007: opaqueDescriptor = OpaqueDescriptor.createDescriptor(paramString, (Connection)this.connection); oracleTypeADT1 = (OracleTypeADT)opaqueDescriptor.getPickler(); break; }  this.currentRowBinders[paramInt1] = binder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt1] = null; if (oracleTypeADT1 != null) oracleTypeADT1.getTOID();  if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt1] = oracleTypeADT1; } public void setNullAtName(String paramString1, int paramInt, String paramString2) throws SQLException { String str = paramString1.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setNullInternal(b + 1, paramInt, paramString2); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1); sQLException.fillInStackTrace(); throw sQLException; }  } public void setNull(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setNullCritical(paramInt1, paramInt2); }  } void setNullCritical(int paramInt1, int paramInt2) throws SQLException { SQLException sQLException; int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  Binder binder = null; int j = getInternalType(paramInt2); switch (j) { case 6: binder = this.theVarnumNullBinder; break;case 1: case 8: case 96: case 995: binder = this.theVarcharNullBinder; this.currentRowCharLens[i] = 1; break;case 999: binder = this.theFixedCHARNullBinder; break;case 12: binder = this.theDateNullBinder; break;case 180: binder = this.theTimestampNullBinder; break;case 181: binder = this.theTSTZNullBinder; break;case 231: binder = this.theTSLTZNullBinder; break;case 104: binder = getRowidNullBinder(i); break;case 183: binder = this.theIntervalDSNullBinder; break;case 182: binder = this.theIntervalYMNullBinder; break;case 23: case 24: binder = this.theRawNullBinder; break;case 100: binder = this.theBinaryFloatNullBinder; break;case 101: binder = this.theBinaryDoubleNullBinder; break;case 113: binder = this.theBlobNullBinder; break;case 112: binder = this.theClobNullBinder; break;case 114: binder = this.theBfileNullBinder; break;case 109: case 111: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "sqlType=" + paramInt2); sQLException.fillInStackTrace(); throw sQLException;default: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "sqlType=" + paramInt2); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = binder; } Binder getRowidNullBinder(int paramInt) { return this.theRowidNullBinder; } public void setNullAtName(String paramString, int paramInt) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setNull(b + 1, paramInt); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException { synchronized (this.connection) { setBooleanInternal(paramInt, paramBoolean); }  } void setBooleanInternal(int paramInt, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theBooleanBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramBoolean ? 1 : 0; } public void setByte(int paramInt, byte paramByte) throws SQLException { synchronized (this.connection) { setByteInternal(paramInt, paramByte); }  } void setByteInternal(int paramInt, byte paramByte) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theByteBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramByte; } public void setShort(int paramInt, short paramShort) throws SQLException { synchronized (this.connection) { setShortInternal(paramInt, paramShort); }  } void setShortInternal(int paramInt, short paramShort) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theShortBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramShort; } public void setInt(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { setIntInternal(paramInt1, paramInt2); }  } void setIntInternal(int paramInt1, int paramInt2) throws SQLException { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theIntBinder; if (this.parameterInt == null) this.parameterInt = new int[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterInt[this.currentRank][i] = paramInt2; } public void setLong(int paramInt, long paramLong) throws SQLException { synchronized (this.connection) { setLongInternal(paramInt, paramLong); }  } void setLongInternal(int paramInt, long paramLong) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theLongBinder; if (this.parameterLong == null) this.parameterLong = new long[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterLong[this.currentRank][i] = paramLong; } public void setFloat(int paramInt, float paramFloat) throws SQLException { synchronized (this.connection) { setFloatInternal(paramInt, paramFloat); }  } void setFloatInternal(int paramInt, float paramFloat) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.connection.setFloatAndDoubleUseBinary) if (Float.isNaN(paramFloat)) throw new IllegalArgumentException("NaN");   if (this.theFloatBinder == null) { this.theFloatBinder = theStaticFloatBinder; if (this.connection.setFloatAndDoubleUseBinary) this.theFloatBinder = theStaticBinaryFloatBinder;  }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theFloatBinder; if (this.theFloatBinder == theStaticFloatBinder) { if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterDouble[this.currentRank][i] = paramFloat; } else { if (this.parameterFloat == null) this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterFloat[this.currentRank][i] = paramFloat; }  } public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException { synchronized (this.connection) { setBinaryFloatInternal(paramInt, paramFloat); }  } void setBinaryFloatInternal(int paramInt, float paramFloat) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theBinaryFloatBinder; if (this.parameterFloat == null) this.parameterFloat = new float[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterFloat[this.currentRank][i] = paramFloat; } public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException { synchronized (this.connection) { setBinaryFloatInternal(paramInt, paramBINARY_FLOAT); }  } void setBinaryFloatInternal(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBINARY_FLOAT == null) { this.currentRowBinders[i] = this.theBINARY_FLOATNullBinder; } else { this.currentRowBinders[i] = this.theBINARY_FLOATBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBINARY_FLOAT.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException { synchronized (this.connection) { setBinaryDoubleInternal(paramInt, paramDouble); }  } void setBinaryDoubleInternal(int paramInt, double paramDouble) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.theBinaryDoubleBinder; if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.currentRowCharLens[i] = 0; this.parameterDouble[this.currentRank][i] = paramDouble; } public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException { synchronized (this.connection) { setBinaryDoubleInternal(paramInt, paramBINARY_DOUBLE); }  } void setBinaryDoubleInternal(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBINARY_DOUBLE == null) { this.currentRowBinders[i] = this.theBINARY_DOUBLENullBinder; } else { this.currentRowBinders[i] = this.theBINARY_DOUBLEBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBINARY_DOUBLE.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setDouble(int paramInt, double paramDouble) throws SQLException { synchronized (this.connection) { setDoubleInternal(paramInt, paramDouble); }  } void setDoubleInternal(int paramInt, double paramDouble) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.connection.setFloatAndDoubleUseBinary) { if (Double.isNaN(paramDouble)) throw new IllegalArgumentException("NaN");  double d = Math.abs(paramDouble); if (d != 0.0D && d < 1.0E-130D) throw new IllegalArgumentException("Underflow");  if (d >= 1.0E126D) throw new IllegalArgumentException("Overflow");  }  if (this.theDoubleBinder == null) { this.theDoubleBinder = theStaticDoubleBinder; if (this.connection.setFloatAndDoubleUseBinary) this.theDoubleBinder = theStaticBinaryDoubleBinder;  }  this.currentRowCharLens[i] = 0; this.currentRowBinders[i] = this.theDoubleBinder; if (this.parameterDouble == null) this.parameterDouble = new double[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterDouble[this.currentRank][i] = paramDouble; } public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException { synchronized (this.connection) { setBigDecimalInternal(paramInt, paramBigDecimal); }  } void setBigDecimalInternal(int paramInt, BigDecimal paramBigDecimal) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramBigDecimal == null) { this.currentRowBinders[i] = this.theVarnumNullBinder; } else { this.currentRowBinders[i] = this.theBigDecimalBinder; if (this.parameterBigDecimal == null) this.parameterBigDecimal = new BigDecimal[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterBigDecimal[this.currentRank][i] = paramBigDecimal; }  this.currentRowCharLens[i] = 0; } public void setString(int paramInt, String paramString) throws SQLException { setStringInternal(paramInt, paramString); } void setStringInternal(int paramInt, String paramString) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  byte b = (paramString != null) ? paramString.length() : 0; if (!b) { setNull(paramInt, 12); } else if (this.currentRowFormOfUse[paramInt - 1] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (b > this.maxVcsBytesPlsql || (b > this.maxVcsCharsPlsql && this.isServerCharSetFixedWidth)) { setStringForClobCritical(paramInt, paramString); } else if (b > this.maxVcsCharsPlsql) { int j = this.connection.conversion.encodedByteLength(paramString, false); if (j > this.maxVcsBytesPlsql) { setStringForClobCritical(paramInt, paramString); } else { basicBindString(paramInt, paramString); }  } else { basicBindString(paramInt, paramString); }  } else if (b <= this.maxVcsCharsSql) { basicBindString(paramInt, paramString); } else if (b <= this.maxStreamCharsSql) { basicBindCharacterStream(paramInt, new StringReader(paramString), b, true); } else { setStringForClobCritical(paramInt, paramString); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (b > this.maxVcsBytesPlsql || (b > this.maxVcsNCharsPlsql && this.isServerNCharSetFixedWidth)) { setStringForClobCritical(paramInt, paramString); } else if (b > this.maxVcsNCharsPlsql) { int j = this.connection.conversion.encodedByteLength(paramString, true); if (j > this.maxVcsBytesPlsql) { setStringForClobCritical(paramInt, paramString); } else { basicBindString(paramInt, paramString); }  } else { basicBindString(paramInt, paramString); }  } else if (b <= this.maxVcsCharsSql) { basicBindString(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } void basicBindNullString(int paramInt) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; this.currentRowBinders[i] = this.theVarcharNullBinder; if (this.sqlKind.isPlsqlOrCall()) { this.currentRowCharLens[i] = this.minVcsBindSize; } else { this.currentRowCharLens[i] = 1; }  }  } void basicBindString(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; this.currentRowBinders[i] = this.theStringBinder; int j = paramString.length(); if (this.sqlKind.isPlsqlOrCall()) { int k = this.connection.minVcsBindSize; int m = j + 1; this.currentRowCharLens[i] = (m < k) ? k : m; } else { this.currentRowCharLens[i] = j + 1; }  if (this.parameterString == null) this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterString[this.currentRank][i] = paramString; }  } public void setStringForClob(int paramInt, String paramString) throws SQLException { if (paramString == null) { setNull(paramInt, 1); return; }  int i = paramString.length(); if (i == 0) { setNull(paramInt, 1); return; }  if (this.sqlKind.isPlsqlOrCall()) { if (i <= this.maxVcsCharsPlsql) { setStringInternal(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } else if (i <= this.maxVcsCharsSql) { setStringInternal(paramInt, paramString); } else { setStringForClobCritical(paramInt, paramString); }  } void setStringForClobCritical(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); cLOB.setString(1L, paramString); addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  } void setReaderContentsForClobCritical(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramReader = isReaderEmpty(paramReader)) == null) { if (paramBoolean) throw new IOException(paramLong + " char of CLOB data cannot be read");  setCLOBInternal(paramInt, (CLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); OracleClobWriter oracleClobWriter = (OracleClobWriter)cLOB.setCharacterStream(1L); int i = cLOB.getBufferSize(); char[] arrayOfChar = new char[i]; long l = 0L; int j = 0; l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramReader.read(arrayOfChar); } else { j = paramReader.read(arrayOfChar, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " char of CLOB data cannot be read");  break; }  oracleClobWriter.write(arrayOfChar, 0, j); l -= j; }  oracleClobWriter.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  } void setAsciiStreamContentsForClobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null) { if (paramBoolean) throw new IOException(paramLong + " byte of CLOB data cannot be read");  setCLOBInternal(paramInt, (CLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, this.currentRowFormOfUse[paramInt - 1]); OracleClobWriter oracleClobWriter = (OracleClobWriter)cLOB.setCharacterStream(1L); int i = cLOB.getBufferSize(); byte[] arrayOfByte = new byte[i]; char[] arrayOfChar = new char[i]; int j = 0; long l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramInputStream.read(arrayOfByte); } else { j = paramInputStream.read(arrayOfByte, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " byte of CLOB data cannot be read");  break; }  DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar); oracleClobWriter.write(arrayOfChar, 0, j); l -= j; }  oracleClobWriter.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(cLOB); this.lastBoundClobs[paramInt - 1] = cLOB; setCLOBInternal(paramInt, cLOB); }  } OraclePreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { super(paramPhysicalConnection, paramInt1, paramInt2, paramInt3, paramInt4);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  5350 */     this.SetBigStringTryClob = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  9992 */     this.m_batchStyle = 0; this.cacheState = 1; if (paramInt1 > 1) setOracleBatchStyle();  this.theSetCHARBinder = paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianSetCHARBinder : theStaticSetCHARBinder; this.theURowidBinder = this.theRowidBinder = paramPhysicalConnection.useLittleEndianSetCHARBinder() ? theStaticLittleEndianRowidBinder : theStaticRowidBinder; this.statementType = 1; this.currentRow = -1; this.needToParse = true; this.processEscapes = paramPhysicalConnection.processEscapes; this.sqlObject.initialize(paramString); this.sqlKind = this.sqlObject.getSqlKind(); this.clearParameters = true; this.scrollRsetTypeSolved = false; this.prematureBatchCount = 0; initializeBinds(); this.minVcsBindSize = paramPhysicalConnection.minVcsBindSize; this.maxRawBytesSql = paramPhysicalConnection.maxRawBytesSql; this.maxRawBytesPlsql = paramPhysicalConnection.maxRawBytesPlsql; this.maxVcsCharsSql = paramPhysicalConnection.maxVcsCharsSql; this.maxVcsNCharsSql = paramPhysicalConnection.maxVcsNCharsSql; this.maxVcsBytesPlsql = paramPhysicalConnection.maxVcsBytesPlsql; this.maxIbtVarcharElementLength = paramPhysicalConnection.maxIbtVarcharElementLength; this.maxCharSize = this.connection.conversion.sMaxCharSize; this.maxNCharSize = this.connection.conversion.maxNCharSize; this.maxVcsCharsPlsql = this.maxVcsBytesPlsql / this.maxCharSize; this.maxVcsNCharsPlsql = this.maxVcsBytesPlsql / this.maxNCharSize; this.maxStreamCharsSql = Integer.MAX_VALUE / this.maxCharSize; this.maxStreamNCharsSql = this.maxRawBytesSql / this.maxNCharSize; this.isServerCharSetFixedWidth = this.connection.conversion.isServerCharSetFixedWidth; this.isServerNCharSetFixedWidth = this.connection.conversion.isServerNCharSetFixedWidth; }
/*       */   public void setStringForClobAtName(String paramString1, String paramString2) throws SQLException { String str = paramString1.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setStringForClob(b + 1, paramString2); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1); sQLException.fillInStackTrace(); throw sQLException; }  }
/*       */   public void setFixedCHAR(int paramInt, String paramString) throws SQLException { synchronized (this.connection) { setFixedCHARInternal(paramInt, paramString); }  }
/*       */   void setFixedCHARInternal(int paramInt, String paramString) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  int j = 0; if (paramString != null) j = paramString.length();  if (j > 32766) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 157); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString == null) { this.currentRowBinders[i] = this.theFixedCHARNullBinder; this.currentRowCharLens[i] = 1; } else { this.currentRowBinders[i] = this.theFixedCHARBinder; this.currentRowCharLens[i] = j + 1; if (this.parameterString == null) this.parameterString = new String[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterString[this.currentRank][i] = paramString; }  }
/*       */   public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException { synchronized (this.connection) { setCursorInternal(paramInt, paramResultSet); }  }
/*       */   void setCursorInternal(int paramInt, ResultSet paramResultSet) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void setROWID(int paramInt, ROWID paramROWID) throws SQLException { synchronized (this.connection) { setROWIDInternal(paramInt, paramROWID); }  }
/*       */   void setROWIDInternal(int paramInt, ROWID paramROWID) throws SQLException { if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) { if (paramROWID == null) { setNull(paramInt, 12); } else { setStringInternal(paramInt, paramROWID.stringValue()); }  return; }  int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramROWID == null || paramROWID.shareBytes() == null) { this.currentRowBinders[i] = this.theRowidNullBinder; } else { this.currentRowBinders[i] = T4CRowidAccessor.isUROWID(paramROWID.shareBytes(), 0) ? this.theURowidBinder : this.theRowidBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramROWID.getBytes(); }  this.currentRowCharLens[i] = 0; }
/*       */   public void setArray(int paramInt, Array paramArray) throws SQLException { setARRAYInternal(paramInt, (ARRAY)paramArray); }
/*       */   void setArrayInternal(int paramInt, Array paramArray) throws SQLException { setARRAYInternal(paramInt, (ARRAY)paramArray); }
/*       */   public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException { setARRAYInternal(paramInt, paramARRAY); }
/* 10003 */   void setARRAYInternal(int paramInt, ARRAY paramARRAY) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramARRAY == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setArrayCritical(i, paramARRAY); this.currentRowCharLens[i] = 0; }  } void setArrayCritical(int paramInt, ARRAY paramARRAY) throws SQLException { ArrayDescriptor arrayDescriptor = paramARRAY.getDescriptor(); if (arrayDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramARRAY.toBytes(); OracleTypeCOLLECTION oracleTypeCOLLECTION = arrayDescriptor.getOracleTypeCOLLECTION(); oracleTypeCOLLECTION.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = (OracleTypeADT)oracleTypeCOLLECTION; } public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException { setOPAQUEInternal(paramInt, paramOPAQUE); } void setOPAQUEInternal(int paramInt, OPAQUE paramOPAQUE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramOPAQUE == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setOPAQUECritical(i, paramOPAQUE); this.currentRowCharLens[i] = 0; }  } void setOPAQUECritical(int paramInt, OPAQUE paramOPAQUE) throws SQLException { OpaqueDescriptor opaqueDescriptor = paramOPAQUE.getDescriptor(); if (opaqueDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramOPAQUE.toBytes(); OracleTypeADT oracleTypeADT = (OracleTypeADT)opaqueDescriptor.getPickler(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } public void setStructDescriptor(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { setStructDescriptorInternal(paramInt, paramStructDescriptor); } void setStructDescriptorInternal(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramStructDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setStructDescriptorCritical(i, paramStructDescriptor); this.currentRowCharLens[i] = 0; }  } void setStructDescriptorCritical(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException { this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  OracleTypeADT oracleTypeADT = paramStructDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } public void setStructDescriptorAtName(String paramString, StructDescriptor paramStructDescriptor) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setStructDescriptorInternal(b + 1, paramStructDescriptor); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } void setPreBindsCompelete() throws SQLException {} public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException { setSTRUCTInternal(paramInt, paramSTRUCT); } void setSTRUCTInternal(int paramInt, STRUCT paramSTRUCT) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramSTRUCT == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { setSTRUCTCritical(i, paramSTRUCT); this.currentRowCharLens[i] = 0; }  } void setSTRUCTCritical(int paramInt, STRUCT paramSTRUCT) throws SQLException { StructDescriptor structDescriptor = paramSTRUCT.getDescriptor(); if (structDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 61); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theNamedTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramSTRUCT.toBytes(); OracleTypeADT oracleTypeADT = structDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } public void setRAW(int paramInt, RAW paramRAW) throws SQLException { setRAWInternal(paramInt, paramRAW); } void setRAWInternal(int paramInt, RAW paramRAW) throws SQLException { boolean bool = false; synchronized (this.connection) { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramRAW == null) { this.currentRowBinders[i] = this.theRawNullBinder; } else { bool = true; }  }  if (bool) setBytesInternal(paramInt, paramRAW.getBytes());  } final void setOracleBatchStyle() throws SQLException { if (this.m_batchStyle == 2) {
/*       */ 
/*       */       
/* 10006 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with JDBC-2.0-style batching");
/* 10007 */       sQLException.fillInStackTrace();
/* 10008 */       throw sQLException;
/*       */     } 
/*       */     
/* 10011 */     if (this.m_batchStyle == 0);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10016 */     this.m_batchStyle = 1; } public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException { synchronized (this.connection) { setCHARInternal(paramInt, paramCHAR); }  } void setCHARInternal(int paramInt, CHAR paramCHAR) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramCHAR == null || paramCHAR.getLength() == 0L) { this.currentRowBinders[i] = this.theSetCHARNullBinder; this.currentRowCharLens[i] = 1; } else { byte[] arrayOfByte; short s = (short)paramCHAR.oracleId(); this.currentRowBinders[i] = this.theSetCHARBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  CharacterSet characterSet = (this.currentRowFormOfUse[i] == 2) ? this.connection.setCHARNCharSetObj : this.connection.setCHARCharSetObj; if (characterSet != null && characterSet.getOracleId() != s) { byte[] arrayOfByte1 = paramCHAR.shareBytes(); arrayOfByte = characterSet.convert(paramCHAR.getCharacterSet(), arrayOfByte1, 0, arrayOfByte1.length); } else { arrayOfByte = paramCHAR.getBytes(); }  this.parameterDatum[this.currentRank][i] = arrayOfByte; this.currentRowCharLens[i] = (arrayOfByte.length + 1 >> 1) + 1; }  if (this.sqlKind.isPlsqlOrCall()) if (this.currentRowCharLens[i] < this.minVcsBindSize) this.currentRowCharLens[i] = this.minVcsBindSize;   } public void setDATE(int paramInt, DATE paramDATE) throws SQLException { synchronized (this.connection) { setDATEInternal(paramInt, paramDATE); }  } void setDATEInternal(int paramInt, DATE paramDATE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramDATE == null) { this.currentRowBinders[i] = this.theDateNullBinder; } else { this.currentRowBinders[i] = this.theOracleDateBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramDATE.getBytes(); }  } public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException { synchronized (this.connection) { setNUMBERInternal(paramInt, paramNUMBER); }  } void setNUMBERInternal(int paramInt, NUMBER paramNUMBER) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramNUMBER == null) { this.currentRowBinders[i] = this.theVarnumNullBinder; } else { this.currentRowBinders[i] = this.theOracleNumberBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramNUMBER.getBytes(); }  } public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException { synchronized (this.connection) { setBLOBInternal(paramInt, paramBLOB); }  } void setBLOBInternal(int paramInt, BLOB paramBLOB) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramBLOB == null) { this.currentRowBinders[i] = this.theBlobNullBinder; } else { this.currentRowBinders[i] = this.theBlobBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBLOB.getBytes(); }  } public void setBlob(int paramInt, Blob paramBlob) throws SQLException { synchronized (this.connection) { setBLOBInternal(paramInt, (BLOB)paramBlob); }  } void setBlobInternal(int paramInt, Blob paramBlob) throws SQLException { setBLOBInternal(paramInt, (BLOB)paramBlob); } public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException { synchronized (this.connection) { setCLOBInternal(paramInt, paramCLOB); }  } void setCLOBInternal(int paramInt, CLOB paramCLOB) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramCLOB == null) { this.currentRowBinders[i] = this.theClobNullBinder; } else { this.currentRowBinders[i] = this.theClobBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramCLOB.getBytes(); }  } public void setClob(int paramInt, Clob paramClob) throws SQLException { synchronized (this.connection) { setCLOBInternal(paramInt, (CLOB)paramClob); }  } void setClobInternal(int paramInt, Clob paramClob) throws SQLException { setCLOBInternal(paramInt, (CLOB)paramClob); } public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException { synchronized (this.connection) { setBFILEInternal(paramInt, paramBFILE); }  } void setBFILEInternal(int paramInt, BFILE paramBFILE) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowCharLens[i] = 0; if (paramBFILE == null) { this.currentRowBinders[i] = this.theBfileNullBinder; } else { this.currentRowBinders[i] = this.theBfileBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramBFILE.getBytes(); }  } public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException { synchronized (this.connection) { setBFILEInternal(paramInt, paramBFILE); }  } void setBfileInternal(int paramInt, BFILE paramBFILE) throws SQLException { setBFILEInternal(paramInt, paramBFILE); } public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException { setBytesInternal(paramInt, paramArrayOfbyte); } void setBytesInternal(int paramInt, byte[] paramArrayOfbyte) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  byte b = (paramArrayOfbyte != null) ? paramArrayOfbyte.length : 0; if (!b) { setNullInternal(paramInt, -2); } else if (this.sqlKind == OracleStatement.SqlKind.PLSQL_BLOCK) { if (b > this.maxRawBytesPlsql) { setBytesForBlobCritical(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } else if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) { if (b > this.maxRawBytesPlsql) { setBytesForBlobCritical(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } else if (b > this.maxRawBytesSql) { bindBytesAsStream(paramInt, paramArrayOfbyte); } else { basicBindBytes(paramInt, paramArrayOfbyte); }  } void bindBytesAsStream(int paramInt, byte[] paramArrayOfbyte) throws SQLException { int i = paramArrayOfbyte.length; byte[] arrayOfByte = new byte[i]; System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, i); set_execute_batch(1); basicBindBinaryStream(paramInt, new ByteArrayInputStream(arrayOfByte), i, true); } void basicBindBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; Binder binder = this.sqlKind.isPlsqlOrCall() ? this.thePlsqlRawBinder : this.theRawBinder; this.currentRowBinders[i] = binder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramArrayOfbyte; this.currentRowCharLens[i] = 0; }  } void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { basicBindBinaryStream(paramInt1, paramInputStream, paramInt2, false); } void basicBindBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (paramBoolean) { this.currentRowBinders[i] = this.theLongRawStreamForBytesBinder; } else { this.currentRowBinders[i] = this.theLongRawStreamBinder; }  if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramInputStream, 6, paramInt2) : this.connection.conversion.ConvertStream(paramInputStream, 6, paramInt2); this.currentRowCharLens[i] = 0; }  } public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException { if (paramArrayOfbyte == null) { setNull(paramInt, -2); return; }  int i = paramArrayOfbyte.length; if (i == 0) { setNull(paramInt, -2); return; }  if (this.sqlKind.isPlsqlOrCall()) { if (i <= this.maxRawBytesPlsql) { setBytes(paramInt, paramArrayOfbyte); } else { setBytesForBlobCritical(paramInt, paramArrayOfbyte); }  } else if (i <= this.maxRawBytesSql) { setBytes(paramInt, paramArrayOfbyte); } else { setBytesForBlobCritical(paramInt, paramArrayOfbyte); }  } void setBytesForBlobCritical(int paramInt, byte[] paramArrayOfbyte) throws SQLException { BLOB bLOB = BLOB.createTemporary((Connection)this.connection, true, 10); bLOB.putBytes(1L, paramArrayOfbyte); addToTempLobsToFree(bLOB); this.lastBoundBlobs[paramInt - 1] = bLOB; setBLOBInternal(paramInt, bLOB); } void setBinaryStreamContentsForBlobCritical(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { try { if ((paramInputStream = isInputStreamEmpty(paramInputStream)) == null) { if (paramBoolean) throw new IOException(paramLong + " byte of BLOB data cannot be read");  setBLOBInternal(paramInt, (BLOB)null); return; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  BLOB bLOB = BLOB.createTemporary((Connection)this.connection, true, 10); OracleBlobOutputStream oracleBlobOutputStream = (OracleBlobOutputStream)bLOB.setBinaryStream(1L); int i = bLOB.getBufferSize(); byte[] arrayOfByte = new byte[i]; long l = 0L; int j = 0; l = paramBoolean ? paramLong : Long.MAX_VALUE; try { while (l > 0L) { if (l >= i) { j = paramInputStream.read(arrayOfByte); } else { j = paramInputStream.read(arrayOfByte, 0, (int)l); }  if (j == -1) { if (paramBoolean) throw new IOException(l + " byte of BLOB data cannot be read");  break; }  oracleBlobOutputStream.write(arrayOfByte, 0, j); l -= j; }  oracleBlobOutputStream.flush(); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  addToTempLobsToFree(bLOB); this.lastBoundBlobs[paramInt - 1] = bLOB; setBLOBInternal(paramInt, bLOB); }  } public void setBytesForBlobAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setBytesForBlob(b + 1, paramArrayOfbyte); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  } public void setInternalBytes(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException { synchronized (this.connection) { setInternalBytesInternal(paramInt1, paramArrayOfbyte, paramInt2); }  } void setInternalBytesInternal(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void setDate(int paramInt, Date paramDate) throws SQLException { synchronized (this.connection) { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, getDefaultCalendar())); }  } void setDateInternal(int paramInt, Date paramDate) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, getDefaultCalendar())); } public void setTime(int paramInt, Time paramTime) throws SQLException { synchronized (this.connection) { setTimeInternal(paramInt, paramTime); }  } void setTimeInternal(int paramInt, Time paramTime) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTime == null) { this.currentRowBinders[i] = this.theDateNullBinder; } else { this.currentRowBinders[i] = this.theTimeBinder; if (this.parameterTime == null) this.parameterTime = new Time[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterTime[this.currentRank][i] = paramTime; }  this.currentRowCharLens[i] = 0; } public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException { synchronized (this.connection) { setTimestampInternal(paramInt, paramTimestamp); }  } void setTimestampInternal(int paramInt, Timestamp paramTimestamp) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTimestamp == null) { this.currentRowBinders[i] = this.theTimestampNullBinder; } else { this.currentRowBinders[i] = this.theTimestampBinder; if (this.parameterTimestamp == null) this.parameterTimestamp = new Timestamp[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterTimestamp[this.currentRank][i] = paramTimestamp; }  this.currentRowCharLens[i] = 0; } public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException { synchronized (this.connection) { setINTERVALYMInternal(paramInt, paramINTERVALYM); }  } void setINTERVALYMInternal(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramINTERVALYM == null) { this.currentRowBinders[i] = this.theIntervalYMNullBinder; } else { this.currentRowBinders[i] = this.theIntervalYMBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramINTERVALYM.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException { synchronized (this.connection) { setINTERVALDSInternal(paramInt, paramINTERVALDS); }  } void setINTERVALDSInternal(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramINTERVALDS == null) { this.currentRowBinders[i] = this.theIntervalDSNullBinder; } else { this.currentRowBinders[i] = this.theIntervalDSBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramINTERVALDS.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException { synchronized (this.connection) { setTIMESTAMPInternal(paramInt, paramTIMESTAMP); }  } void setTIMESTAMPInternal(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMP == null) { this.currentRowBinders[i] = this.theTimestampNullBinder; } else { this.currentRowBinders[i] = this.theOracleTimestampBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMP.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException { synchronized (this.connection) { setTIMESTAMPTZInternal(paramInt, paramTIMESTAMPTZ); }  } void setTIMESTAMPTZInternal(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMPTZ == null) { this.currentRowBinders[i] = this.theTSTZNullBinder; } else { this.currentRowBinders[i] = this.theTSTZBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMPTZ.getBytes(); }  this.currentRowCharLens[i] = 0; } public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException { synchronized (this.connection) { setTIMESTAMPLTZInternal(paramInt, paramTIMESTAMPLTZ); }  }
/*       */   void setTIMESTAMPLTZInternal(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException { if (this.connection.getSessionTimeZone() == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 105); sQLException.fillInStackTrace(); throw sQLException; }  int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramTIMESTAMPLTZ == null) { this.currentRowBinders[i] = this.theTSLTZNullBinder; } else { this.currentRowBinders[i] = this.theTSLTZBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][i] = paramTIMESTAMPLTZ.getBytes(); }  this.currentRowCharLens[i] = 0; }
/*       */   private Reader isReaderEmpty(Reader paramReader) throws IOException { if (!paramReader.markSupported()) paramReader = new BufferedReader(paramReader, 5);  paramReader.mark(100); int i; if ((i = paramReader.read()) == -1) return null;  paramReader.reset(); return paramReader; }
/*       */   private InputStream isInputStreamEmpty(InputStream paramInputStream) throws IOException { if (!paramInputStream.markSupported()) paramInputStream = new BufferedInputStream(paramInputStream, 5);  paramInputStream.mark(100); int i; if ((i = paramInputStream.read()) == -1) return null;  paramInputStream.reset(); return paramInputStream; }
/*       */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2); }  }
/*       */   void setAsciiStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setAsciiStreamInternal(paramInt1, paramInputStream, paramInt2, true); }
/*       */   void setAsciiStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { basicBindNullString(paramInt); } else { if (this.userRsetType != 1 && (paramLong > this.maxVcsCharsSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (this.currentRowFormOfUse[i] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (paramLong <= this.maxVcsCharsPlsql && !this.connection.retainV9BindBehavior) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  } else if (paramLong <= this.maxVcsCharsSql && !this.connection.retainV9BindBehavior) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else if (paramLong > 2147483647L) { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else { basicBindAsciiStream(paramInt, paramInputStream, (int)paramLong); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong <= this.maxVcsNCharsPlsql && !this.connection.retainV9BindBehavior) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  } else if (paramLong <= this.maxVcsNCharsSql && !this.connection.retainV9BindBehavior) { setAsciiStreamContentsForStringInternal(paramInt, paramInputStream, (int)paramLong); } else { setAsciiStreamContentsForClobCritical(paramInt, paramInputStream, paramLong, paramBoolean); }  }  }
/* 10023 */   boolean isOracleBatchStyle() { return (this.m_batchStyle == 1); } void basicBindAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { if (this.userRsetType != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  int i = paramInt1 - 1; this.currentRowBinders[i] = this.theLongStreamBinder; if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 5, paramInt2); this.currentRowCharLens[i] = 0; }  } void setAsciiStreamContentsForStringInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { byte[] arrayOfByte = new byte[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramInputStream.read(arrayOfByte, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  char[] arrayOfChar = new char[paramInt2]; DBConversion.asciiBytesToJavaChars(arrayOfByte, i, arrayOfChar); basicBindString(paramInt1, new String(arrayOfChar)); } public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2); } void setBinaryStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setBinaryStreamInternal(paramInt1, paramInputStream, paramInt2, true); } void checkUserStreamForDuplicates(Object paramObject, int paramInt) throws SQLException { if (paramObject == null) return;  if (this.userStream != null) { for (Object[] arrayOfObject : this.userStream) { for (Object object : arrayOfObject) { if (object == paramObject) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 270, Integer.valueOf(paramInt + 1)); sQLException.fillInStackTrace(); throw sQLException; }  }  }  } else { this.userStream = new Object[this.numberOfBindRowsAllocated][this.numberOfBindPositions]; }  this.userStream[this.currentRank][paramInt] = paramObject; } void setBinaryStreamInternal(int paramInt, InputStream paramInputStream, long paramLong, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { setRAWInternal(paramInt, (RAW)null); } else { if (this.userRsetType != 1 && (paramLong > this.maxRawBytesSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxRawBytesPlsql) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else { setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong); }  } else if (paramLong > 2147483647L) { setBinaryStreamContentsForBlobCritical(paramInt, paramInputStream, paramLong, paramBoolean); } else if (paramLong > this.maxRawBytesSql) { basicBindBinaryStream(paramInt, paramInputStream, (int)paramLong); } else { setBinaryStreamContentsForByteArrayInternal(paramInt, paramInputStream, (int)paramLong); }  }  }  } void setBinaryStreamContentsForByteArrayInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { byte[] arrayOfByte = new byte[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramInputStream.read(arrayOfByte, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { byte[] arrayOfByte1 = new byte[i]; System.arraycopy(arrayOfByte, 0, arrayOfByte1, 0, i); arrayOfByte = arrayOfByte1; }  setBytesInternal(paramInt1, arrayOfByte); } public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { setUnicodeStreamInternal(paramInt1, paramInputStream, paramInt2); } void setUnicodeStreamInternal(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramInputStream, i); if (paramInputStream == null) { setStringInternal(paramInt1, (String)null); } else { if (this.userRsetType != 1 && paramInt2 > this.maxVcsCharsSql) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (this.sqlKind.isPlsqlOrCall() || paramInt2 <= this.maxVcsCharsSql) { byte[] arrayOfByte = new byte[paramInt2]; int j = 0; int k = paramInt2; try { int m; while (k > 0 && (m = paramInputStream.read(arrayOfByte, j, k)) != -1) { j += m; k -= m; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  char[] arrayOfChar = new char[j >> 1]; DBConversion.ucs2BytesToJavaChars(arrayOfByte, j, arrayOfChar); setStringInternal(paramInt1, new String(arrayOfChar)); } else { this.currentRowBinders[i] = this.theLongStreamBinder; if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = this.connection.conversion.ConvertStream(paramInputStream, 4, paramInt2); this.currentRowCharLens[i] = 0; }  }  }  } public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException { synchronized (this.connection) { setObjectInternal(paramInt, this.connection.toDatum(paramCustomDatum)); }  } void setCustomDatumInternal(int paramInt, CustomDatum paramCustomDatum) throws SQLException { synchronized (this.connection) { Datum datum = this.connection.toDatum(paramCustomDatum); int i = sqlTypeForObject(datum); setObjectCritical(paramInt, datum, i, 0); }  } public void setORAData(int paramInt, ORAData paramORAData) throws SQLException { setORADataInternal(paramInt, paramORAData); } void setORADataInternal(int paramInt, ORAData paramORAData) throws SQLException { synchronized (this.connection) { Datum datum = paramORAData.toDatum((Connection)this.connection); int i = sqlTypeForObject(datum); setObjectCritical(paramInt, datum, i, 0); if (i == 2002 || i == 2008 || i == 2003) this.currentRowCharLens[paramInt - 1] = 0;  }  }
/*       */   void setOracleDataInternal(int paramInt, OracleData paramOracleData) throws SQLException { synchronized (this.connection) { Object object = paramOracleData.toJDBCObject((Connection)this.connection); int i = sqlTypeForObject(object); setObjectCritical(paramInt, object, i, 0); if (i == 2002 || i == 2008 || i == 2003) this.currentRowCharLens[paramInt - 1] = 0;  }  }
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { synchronized (this.connection) { setObjectInternal(paramInt1, paramObject, paramInt2, paramInt3); }  }
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { if (paramObject == null && paramInt2 != 2002 && paramInt2 != 2008 && paramInt2 != 2003 && paramInt2 != 2007 && paramInt2 != 2006) { setNullInternal(paramInt1, paramInt2); } else if (paramInt2 == 2002 || paramInt2 == 2008 || paramInt2 == 2003) { setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3); this.currentRowCharLens[paramInt1 - 1] = 0; } else { setObjectCritical(paramInt1, paramObject, paramInt2, paramInt3); }  }
/*       */   void setObjectCritical(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException { switch (paramInt2) { case 1: if (paramObject instanceof CHAR) { setCHARInternal(paramInt1, (CHAR)paramObject); } else if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 12: if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 999: setFixedCHARInternal(paramInt1, (String)paramObject); return;case -1: if (paramObject instanceof String) { setStringInternal(paramInt1, (String)paramObject); } else if (paramObject instanceof Boolean) { setStringInternal(paramInt1, "" + (((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof Integer) { setStringInternal(paramInt1, "" + ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setStringInternal(paramInt1, "" + ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setStringInternal(paramInt1, "" + ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setStringInternal(paramInt1, "" + ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setStringInternal(paramInt1, ((BigDecimal)paramObject).toString()); } else if (paramObject instanceof Date) { setStringInternal(paramInt1, "" + ((Date)paramObject).toString()); } else if (paramObject instanceof Time) { setStringInternal(paramInt1, "" + ((Time)paramObject).toString()); } else if (paramObject instanceof Timestamp) { setStringInternal(paramInt1, "" + ((Timestamp)paramObject).toString()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 2: if (paramObject instanceof NUMBER) { setNUMBERInternal(paramInt1, (NUMBER)paramObject); } else if (paramObject instanceof Integer) { setIntInternal(paramInt1, ((Integer)paramObject).intValue()); } else if (paramObject instanceof Long) { setLongInternal(paramInt1, ((Long)paramObject).longValue()); } else if (paramObject instanceof Float) { setFloatInternal(paramInt1, ((Float)paramObject).floatValue()); } else if (paramObject instanceof Double) { setDoubleInternal(paramInt1, ((Double)paramObject).doubleValue()); } else if (paramObject instanceof BigDecimal) { setBigDecimalInternal(paramInt1, (BigDecimal)paramObject); } else if (paramObject instanceof BigInteger) { setBigDecimalInternal(paramInt1, new BigDecimal((BigInteger)paramObject)); } else if (paramObject instanceof String) { setNUMBERInternal(paramInt1, new NUMBER((String)paramObject, paramInt3)); } else if (paramObject instanceof Boolean) { setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0); } else if (paramObject instanceof Short) { setShortInternal(paramInt1, ((Short)paramObject).shortValue()); } else if (paramObject instanceof Byte) { setByteInternal(paramInt1, ((Byte)paramObject).byteValue()); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 3: if (paramObject instanceof BigDecimal) { setBigDecimalInternal(paramInt1, (BigDecimal)paramObject); } else if (paramObject instanceof Number) { setBigDecimalInternal(paramInt1, new BigDecimal(((Number)paramObject).doubleValue())); } else if (paramObject instanceof NUMBER) { setBigDecimalInternal(paramInt1, ((NUMBER)paramObject).bigDecimalValue()); } else if (paramObject instanceof String) { setBigDecimalInternal(paramInt1, new BigDecimal((String)paramObject)); } else if (paramObject instanceof Boolean) { setBigDecimalInternal(paramInt1, new BigDecimal(((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -7: if (paramObject instanceof Boolean) { setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else if (paramObject instanceof String) { setByteInternal(paramInt1, (byte)(("true".equalsIgnoreCase((String)paramObject) || "1".equals(paramObject)) ? 1 : 0)); } else if (paramObject instanceof Number) { setIntInternal(paramInt1, (((Number)paramObject).byteValue() != 0) ? 1 : 0); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -6: if (paramObject instanceof Number) { setByteInternal(paramInt1, ((Number)paramObject).byteValue()); } else if (paramObject instanceof String) { setByteInternal(paramInt1, Byte.parseByte((String)paramObject)); } else if (paramObject instanceof Boolean) { setByteInternal(paramInt1, (byte)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 5: if (paramObject instanceof Number) { setShortInternal(paramInt1, ((Number)paramObject).shortValue()); } else if (paramObject instanceof String) { setShortInternal(paramInt1, Short.parseShort((String)paramObject)); } else if (paramObject instanceof Boolean) { setShortInternal(paramInt1, (short)(((Boolean)paramObject).booleanValue() ? 1 : 0)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 4: if (paramObject instanceof Number) { setIntInternal(paramInt1, ((Number)paramObject).intValue()); } else if (paramObject instanceof String) { setIntInternal(paramInt1, Integer.parseInt((String)paramObject)); } else if (paramObject instanceof Boolean) { setIntInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1 : 0); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -5: if (paramObject instanceof Number) { setLongInternal(paramInt1, ((Number)paramObject).longValue()); } else if (paramObject instanceof String) { setLongInternal(paramInt1, Long.parseLong((String)paramObject)); } else if (paramObject instanceof Boolean) { setLongInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1L : 0L); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 7: if (paramObject instanceof Number) { setFloatInternal(paramInt1, ((Number)paramObject).floatValue()); } else if (paramObject instanceof String) { setFloatInternal(paramInt1, Float.valueOf((String)paramObject).floatValue()); } else if (paramObject instanceof Boolean) { setFloatInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0F : 0.0F); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 6: case 8: if (paramObject instanceof Number) { setDoubleInternal(paramInt1, ((Number)paramObject).doubleValue()); } else if (paramObject instanceof String) { setDoubleInternal(paramInt1, Double.valueOf((String)paramObject).doubleValue()); } else if (paramObject instanceof Boolean) { setDoubleInternal(paramInt1, ((Boolean)paramObject).booleanValue() ? 1.0D : 0.0D); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -2: if (paramObject instanceof RAW) { setRAWInternal(paramInt1, (RAW)paramObject); } else { setBytesInternal(paramInt1, (byte[])paramObject); }  return;case -3: setBytesInternal(paramInt1, (byte[])paramObject); return;case -4: setBytesInternal(paramInt1, (byte[])paramObject); return;case 91: if (paramObject instanceof DATE) { setDATEInternal(paramInt1, (DATE)paramObject); } else if (paramObject instanceof Date) { setDATEInternal(paramInt1, new DATE(paramObject, getDefaultCalendar())); } else if (paramObject instanceof Timestamp) { setDATEInternal(paramInt1, new DATE((Timestamp)paramObject)); } else if (paramObject instanceof String) { setDateInternal(paramInt1, Date.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 92: if (paramObject instanceof Time) { setTimeInternal(paramInt1, (Time)paramObject); } else if (paramObject instanceof Timestamp) { setTimeInternal(paramInt1, new Time(((Timestamp)paramObject).getTime())); } else if (paramObject instanceof Date) { setTimeInternal(paramInt1, new Time(((Date)paramObject).getTime())); } else if (paramObject instanceof String) { setTimeInternal(paramInt1, Time.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case 93: if (paramObject instanceof TIMESTAMP) { setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject); } else if (paramObject instanceof Timestamp) { setTimestampInternal(paramInt1, (Timestamp)paramObject); } else if (paramObject instanceof Date) { setTIMESTAMPInternal(paramInt1, new TIMESTAMP((Date)paramObject)); } else if (paramObject instanceof DATE) { setTIMESTAMPInternal(paramInt1, new TIMESTAMP(((DATE)paramObject).timestampValue())); } else if (paramObject instanceof String) { setTimestampInternal(paramInt1, Timestamp.valueOf((String)paramObject)); } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 132); sQLException1.fillInStackTrace(); throw sQLException1; }  return;case -100: setTIMESTAMPInternal(paramInt1, (TIMESTAMP)paramObject); return;case -101: setTIMESTAMPTZInternal(paramInt1, (TIMESTAMPTZ)paramObject); return;case -102: setTIMESTAMPLTZInternal(paramInt1, (TIMESTAMPLTZ)paramObject); return;case -103: setINTERVALYMInternal(paramInt1, (INTERVALYM)paramObject); return;case -104: setINTERVALDSInternal(paramInt1, (INTERVALDS)paramObject); return;case -8: setROWIDInternal(paramInt1, (ROWID)paramObject); return;case 100: setBinaryFloatInternal(paramInt1, (BINARY_FLOAT)paramObject); return;case 101: setBinaryDoubleInternal(paramInt1, (BINARY_DOUBLE)paramObject); return;case 2004: setBLOBInternal(paramInt1, (BLOB)paramObject); return;case 2005: setCLOBInternal(paramInt1, (CLOB)paramObject); if (((CLOB)paramObject).isNCLOB()) setFormOfUse(paramInt1, (short)2);  return;case -13: setBFILEInternal(paramInt1, (BFILE)paramObject); return;case 2002: case 2008: setSTRUCTInternal(paramInt1, STRUCT.toSTRUCT(paramObject, (OracleConnection)this.connection)); return;case 2003: setARRAYInternal(paramInt1, ARRAY.toARRAY(paramObject, (OracleConnection)this.connection)); return;case 2007: setOPAQUEInternal(paramInt1, (OPAQUE)paramObject); return;case 2006: setREFInternal(paramInt1, (REF)paramObject); return; }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setObjectInternal(b + 1, paramObject); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  }
/*       */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException { setObjectInternal(paramInt1, paramObject, paramInt2, 0); }
/*       */   void setObjectInternal(int paramInt1, Object paramObject, int paramInt2) throws SQLException { setObjectInternal(paramInt1, paramObject, paramInt2, 0); }
/*       */   public void setRefType(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/*       */   void setRefTypeInternal(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/*       */   public void setRef(int paramInt, Ref paramRef) throws SQLException { setREFInternal(paramInt, (REF)paramRef); }
/*       */   void setRefInternal(int paramInt, Ref paramRef) throws SQLException { setREFInternal(paramInt, (REF)paramRef); }
/*       */   public void setREF(int paramInt, REF paramREF) throws SQLException { setREFInternal(paramInt, paramREF); }
/* 10036 */   final void setJdbcBatchStyle() throws SQLException { if (this.m_batchStyle == 1) {
/*       */ 
/*       */       
/* 10039 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90, "operation cannot be mixed with Oracle-style batching");
/* 10040 */       sQLException.fillInStackTrace();
/* 10041 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10045 */     this.m_batchStyle = 2; } void setREFInternal(int paramInt, REF paramREF) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  if (paramREF == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  setREFCritical(i, paramREF); this.currentRowCharLens[i] = 0; } void setREFCritical(int paramInt, REF paramREF) throws SQLException { StructDescriptor structDescriptor = paramREF.getDescriptor(); if (structDescriptor == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 52); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[paramInt] = this.theRefTypeBinder; if (this.parameterDatum == null) this.parameterDatum = new byte[this.numberOfBindRowsAllocated][this.numberOfBindPositions][];  this.parameterDatum[this.currentRank][paramInt] = paramREF.getBytes(); OracleTypeADT oracleTypeADT = structDescriptor.getOracleTypeADT(); oracleTypeADT.getTOID(); if (this.parameterOtype == null) this.parameterOtype = new OracleTypeADT[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterOtype[this.currentRank][paramInt] = oracleTypeADT; } public void setObject(int paramInt, Object paramObject) throws SQLException { setObjectInternal(paramInt, paramObject); } void setObjectInternal(int paramInt, Object paramObject) throws SQLException { if (paramObject instanceof ORAData) { setORADataInternal(paramInt, (ORAData)paramObject); } else if (paramObject instanceof CustomDatum) { setCustomDatumInternal(paramInt, (CustomDatum)paramObject); } else if (paramObject instanceof OracleData) { setOracleDataInternal(paramInt, (OracleData)paramObject); } else { int i = sqlTypeForObject(paramObject); setObjectInternal(paramInt, paramObject, i, 0); }  } public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException { setObjectInternal(paramInt, paramDatum); } void setOracleObjectInternal(int paramInt, Datum paramDatum) throws SQLException { setObjectInternal(paramInt, paramDatum); } public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException { synchronized (this.connection) { setPlsqlIndexTableInternal(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5); }  } void setPlsqlIndexTableInternal(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException { Datum[] arrayOfDatum; String[] arrayOfString2; SQLException sQLException; int k, i = paramInt1 - 1; if (i < 0 || paramInt1 > this.numberOfBindPositions) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramObject == null) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 271); sQLException1.fillInStackTrace(); throw sQLException1; }  int j = getInternalType(paramInt4); String[] arrayOfString1 = null; switch (j) { case 1: case 96: arrayOfString2 = null; k = 0; if (paramObject instanceof CHAR[]) { CHAR[] arrayOfCHAR = (CHAR[])paramObject; k = arrayOfCHAR.length; arrayOfString2 = new String[k]; for (byte b = 0; b < k; b++) { CHAR cHAR = arrayOfCHAR[b]; if (cHAR != null) arrayOfString2[b] = cHAR.getString();  }  } else if (paramObject instanceof String[]) { arrayOfString2 = (String[])paramObject; k = arrayOfString2.length; } else { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97); sQLException1.fillInStackTrace(); throw sQLException1; }  if (paramInt5 == 0 && arrayOfString2 != null) for (byte b = 0; b < k; b++) { String str = arrayOfString2[b]; if (str != null && paramInt5 < str.length()) paramInt5 = str.length();  }   arrayOfString1 = arrayOfString2; break;case 2: case 6: arrayOfDatum = OracleTypeNUMBER.toNUMBERArray(paramObject, this.connection, 1L, paramInt3); if (paramInt5 == 0 && arrayOfDatum != null) paramInt5 = 22;  this.currentRowCharLens[i] = 0; break;default: sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 97); sQLException.fillInStackTrace(); throw sQLException; }  if (arrayOfDatum.length == 0 && paramInt2 == 0) { sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 272); sQLException.fillInStackTrace(); throw sQLException; }  this.currentRowBinders[i] = this.thePlsqlIbtBinder; if (this.parameterPlsqlIbt == null) this.parameterPlsqlIbt = new PlsqlIbtBindInfo[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterPlsqlIbt[this.currentRank][i] = new PlsqlIbtBindInfo((Object[])arrayOfDatum, paramInt2, paramInt3, j, paramInt5); this.hasIbtBind = true; } public void setPlsqlIndexTableAtName(String paramString, Object paramObject, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { synchronized (this.connection) { String str = paramString.intern(); String[] arrayOfString = this.sqlObject.getParameterList(); boolean bool = false; int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length); for (byte b = 0; b < i; b++) { if (arrayOfString[b] == str) { setPlsqlIndexTableInternal(b + 1, paramObject, paramInt1, paramInt2, paramInt3, paramInt4); bool = true; }  }  if (!bool) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString); sQLException.fillInStackTrace(); throw sQLException; }  }  } void endOfResultSet(boolean paramBoolean) throws SQLException { if (!paramBoolean) prepareForNewResults(false, false);  this.rowPrefetchInLastFetch = -1; } int sqlTypeForObject(Object paramObject) { if (paramObject == null) return 0;  if (!(paramObject instanceof Datum)) { if (paramObject instanceof String) return this.fixedString ? 999 : 12;  if (paramObject instanceof BigDecimal) return 2;  if (paramObject instanceof BigInteger) return 2;  if (paramObject instanceof Boolean) return -7;  if (paramObject instanceof Integer) return 4;  if (paramObject instanceof Long) return -5;  if (paramObject instanceof Float) return 7;  if (paramObject instanceof Double) return 8;  if (paramObject instanceof byte[]) return -3;  if (paramObject instanceof Short) return 5;  if (paramObject instanceof Byte) return -6;  if (paramObject instanceof Date) return 91;  if (paramObject instanceof Time) return 92;  if (paramObject instanceof Timestamp) return 93;  if (paramObject instanceof java.sql.SQLData) return 2002;  if (paramObject instanceof oracle.jdbc.internal.ObjectData) return 2002;  } else { if (paramObject instanceof BINARY_FLOAT) return 100;  if (paramObject instanceof BINARY_DOUBLE) return 101;  if (paramObject instanceof BLOB) return 2004;  if (paramObject instanceof CLOB) return 2005;  if (paramObject instanceof BFILE) return -13;  if (paramObject instanceof ROWID) return -8;  if (paramObject instanceof NUMBER) return 2;  if (paramObject instanceof DATE) return 91;  if (paramObject instanceof TIMESTAMP) return 93;  if (paramObject instanceof TIMESTAMPTZ) return -101;  if (paramObject instanceof TIMESTAMPLTZ) return -102;  if (paramObject instanceof REF) return 2006;  if (paramObject instanceof CHAR) return 1;  if (paramObject instanceof RAW) return -2;  if (paramObject instanceof ARRAY) return 2003;  if (paramObject instanceof STRUCT) return 2002;  if (paramObject instanceof OPAQUE) return 2007;  if (paramObject instanceof INTERVALYM) return -103;  if (paramObject instanceof INTERVALDS) return -104;  }  return 1111; }
/*       */   public void clearParameters() throws SQLException { synchronized (this.connection) { this.clearParameters = true; for (byte b = 0; b < this.numberOfBindPositions; b++) this.currentRowBinders[b] = null;  }  }
/*       */   void printByteArray(byte[] paramArrayOfbyte) { if (paramArrayOfbyte != null) { int i = paramArrayOfbyte.length; for (byte b = 0; b < i; b++) { int j = paramArrayOfbyte[b] & 0xFF; if (j < 16); }  }  }
/*       */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { setCharacterStreamInternal(paramInt1, paramReader, paramInt2); }
/*       */   void setCharacterStreamInternal(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { setCharacterStreamInternal(paramInt1, paramReader, paramInt2, true); }
/*       */   void setCharacterStreamInternal(int paramInt, Reader paramReader, long paramLong, boolean paramBoolean) throws SQLException { int i = paramInt - 1; if (i < 0 || paramInt > this.numberOfBindPositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  set_execute_batch(1); checkUserStreamForDuplicates(paramReader, i); if (paramReader == null) { basicBindNullString(paramInt); } else { if (this.userRsetType != 1 && (paramLong > this.maxVcsCharsSql || !paramBoolean)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 169); sQLException.fillInStackTrace(); throw sQLException; }  if (!paramBoolean) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (this.currentRowFormOfUse[i] == 1) { if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxVcsBytesPlsql || (paramLong > this.maxVcsCharsPlsql && this.isServerCharSetFixedWidth)) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (paramLong <= this.maxVcsCharsPlsql && !this.connection.retainV9BindBehavior) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, false); }  } else if (paramLong <= this.maxVcsCharsSql && !this.connection.retainV9BindBehavior) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else if (paramLong > 2147483647L) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else { basicBindCharacterStream(paramInt, paramReader, (int)paramLong, false); }  } else if (this.sqlKind.isPlsqlOrCall()) { if (paramLong > this.maxVcsBytesPlsql || (paramLong > this.maxVcsNCharsPlsql && this.isServerCharSetFixedWidth)) { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); } else if (paramLong <= this.maxVcsNCharsPlsql && !this.connection.retainV9BindBehavior) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForStringOrClobInVariableWidthCase(paramInt, paramReader, (int)paramLong, true); }  } else if (paramLong <= this.maxVcsNCharsSql && !this.connection.retainV9BindBehavior) { setReaderContentsForStringInternal(paramInt, paramReader, (int)paramLong); } else { setReaderContentsForClobCritical(paramInt, paramReader, paramLong, paramBoolean); }  }  }
/*       */   void basicBindCharacterStream(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean) throws SQLException { synchronized (this.connection) { int i = paramInt1 - 1; if (paramBoolean) { this.currentRowBinders[i] = this.theLongStreamForStringBinder; } else { this.currentRowBinders[i] = this.theLongStreamBinder; }  if (this.parameterStream == null) this.parameterStream = new InputStream[this.numberOfBindRowsAllocated][this.numberOfBindPositions];  this.parameterStream[this.currentRank][i] = paramBoolean ? this.connection.conversion.ConvertStreamInternal(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]) : this.connection.conversion.ConvertStream(paramReader, 7, paramInt2, this.currentRowFormOfUse[i]); this.currentRowCharLens[i] = 0; }  }
/*       */   void setReaderContentsForStringOrClobInVariableWidthCase(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean) throws SQLException { char[] arrayOfChar = new char[paramInt2]; int i = 0; int j = paramInt2; try { int m; while (j > 0 && (m = paramReader.read(arrayOfChar, i, j)) != -1) { i += m; j -= m; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { char[] arrayOfChar1 = new char[i]; System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, i); arrayOfChar = arrayOfChar1; }  int k = this.connection.conversion.encodedByteLength(arrayOfChar, paramBoolean); if (k < this.maxVcsBytesPlsql && !this.connection.retainV9BindBehavior) { setStringInternal(paramInt1, new String(arrayOfChar)); } else { setStringForClobCritical(paramInt1, new String(arrayOfChar)); }  }
/*       */   void setReaderContentsForStringInternal(int paramInt1, Reader paramReader, int paramInt2) throws SQLException { char[] arrayOfChar = new char[paramInt2]; int i = 0; int j = paramInt2; try { int k; while (j > 0 && (k = paramReader.read(arrayOfChar, i, j)) != -1) { i += k; j -= k; }  } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  if (i != paramInt2) { char[] arrayOfChar1 = new char[i]; System.arraycopy(arrayOfChar, 0, arrayOfChar1, 0, i); arrayOfChar = arrayOfChar1; }  setStringInternal(paramInt1, new String(arrayOfChar)); }
/*       */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, paramCalendar)); }
/*       */   void setDateInternal(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramDate == null) ? null : new DATE(paramDate, paramCalendar)); }
/*       */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramTime == null) ? null : new DATE(paramTime, paramCalendar)); }
/*       */   void setTimeInternal(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException { setDATEInternal(paramInt, (paramTime == null) ? null : new DATE(paramTime, paramCalendar)); }
/*       */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { setTimestampInternal(paramInt, paramTimestamp, paramCalendar); }
/*       */   void setTimestampInternal(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { setTIMESTAMPInternal(paramInt, (paramTimestamp == null) ? null : new TIMESTAMP(paramTimestamp, paramCalendar)); }
/*       */   public void setCheckBindTypes(boolean paramBoolean) { this.checkBindTypes = paramBoolean; }
/* 10061 */   final void checkIfJdbcBatchExists() throws SQLException { if (doesJdbcBatchExist()) {
/*       */ 
/*       */       
/* 10064 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared");
/* 10065 */       sQLException.fillInStackTrace();
/* 10066 */       throw sQLException;
/*       */     }  }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean doesJdbcBatchExist() {
/* 10075 */     if (this.currentRank > 0 && this.m_batchStyle == 2) {
/* 10076 */       return true;
/*       */     }
/* 10078 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isJdbcBatchStyle() {
/* 10085 */     return (this.m_batchStyle == 2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void addBatch() throws SQLException {
/* 10106 */     synchronized (this.connection) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10121 */       setJdbcBatchStyle();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10131 */       processCompletedBindRow(this.currentRank + 2, (this.currentRank > 0 && this.sqlKind.isPlsqlOrCall()));
/*       */ 
/*       */ 
/*       */       
/* 10135 */       this.currentRank++;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void addBatch(String paramString) throws SQLException {
/* 10145 */     synchronized (this.connection) {
/*       */ 
/*       */       
/* 10148 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10149 */       sQLException.fillInStackTrace();
/* 10150 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearBatch() throws SQLException {
/* 10169 */     synchronized (this.connection) {
/*       */       
/* 10171 */       for (int i = this.currentRank - 1; i >= 0; i--) {
/* 10172 */         for (byte b = 0; b < this.numberOfBindPositions; b++)
/* 10173 */           this.binders[i][b] = null; 
/*       */       } 
/* 10175 */       this.currentRank = 0;
/*       */       
/* 10177 */       if (this.binders != null) {
/* 10178 */         this.currentRowBinders = this.binders[0];
/*       */       }
/* 10180 */       this.pushedBatches = null;
/* 10181 */       this.pushedBatchesTail = null;
/* 10182 */       this.firstRowInBatch = 0;
/*       */       
/* 10184 */       this.clearParameters = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void executeForRowsWithTimeout(boolean paramBoolean) throws SQLException {
/* 10197 */     if (this.queryTimeout > 0) {
/*       */ 
/*       */       
/*       */       try {
/* 10201 */         this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);
/* 10202 */         this.cancelLock.enterExecuting();
/* 10203 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally {
/*       */         
/* 10207 */         this.connection.getTimeout().cancelTimeout();
/* 10208 */         this.cancelLock.exitExecuting();
/*       */       } 
/*       */     } else {
/*       */ 
/*       */       
/*       */       try {
/*       */         
/* 10215 */         this.cancelLock.enterExecuting();
/* 10216 */         executeForRows(paramBoolean);
/*       */       }
/*       */       finally {
/*       */         
/* 10220 */         this.cancelLock.exitExecuting();
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int[] executeBatch() throws SQLException {
/* 10247 */     synchronized (this.connection) {
/*       */ 
/*       */       
/* 10250 */       int[] arrayOfInt = new int[this.currentRank];
/* 10251 */       this.checkSum = 0L;
/* 10252 */       this.checkSumComputationFailure = false;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10258 */       byte b = 0;
/*       */       
/* 10260 */       cleanOldTempLobs();
/* 10261 */       setJdbcBatchStyle();
/*       */       
/* 10263 */       if (this.currentRank > 0) {
/*       */ 
/*       */ 
/*       */         
/* 10267 */         ensureOpen();
/*       */ 
/*       */         
/* 10270 */         prepareForNewResults(true, true);
/*       */         
/* 10272 */         if (this.sqlKind.isSELECT()) {
/*       */ 
/*       */           
/* 10275 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(80, 0, (int[])null);
/* 10276 */           batchUpdateException.fillInStackTrace();
/* 10277 */           throw batchUpdateException;
/*       */         } 
/*       */ 
/*       */ 
/*       */         
/* 10282 */         this.noMoreUpdateCounts = false;
/*       */         
/* 10284 */         int i = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         try {
/* 10296 */           this.connection.registerHeartbeat();
/*       */           
/* 10298 */           this.connection.needLine();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10304 */           if (!this.isOpen) {
/*       */             
/* 10306 */             this.connection.open(this);
/*       */             
/* 10308 */             this.isOpen = true;
/*       */           } 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10314 */           int j = this.currentRank;
/*       */           
/* 10316 */           if (this.pushedBatches == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */             
/* 10321 */             setupBindBuffers(0, this.currentRank);
/* 10322 */             executeForRowsWithTimeout(false);
/*       */ 
/*       */           
/*       */           }
/*       */           else {
/*       */ 
/*       */ 
/*       */             
/* 10330 */             if (this.currentRank > this.firstRowInBatch)
/*       */             {
/*       */ 
/*       */               
/* 10334 */               pushBatch(true);
/*       */             }
/* 10336 */             boolean bool = this.needToParse;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */             
/*       */             do {
/* 10344 */               PushedBatch pushedBatch = this.pushedBatches;
/*       */               
/* 10346 */               this.currentBatchCharLens = pushedBatch.currentBatchCharLens;
/* 10347 */               this.lastBoundCharLens = pushedBatch.lastBoundCharLens;
/* 10348 */               this.lastBoundNeeded = pushedBatch.lastBoundNeeded;
/* 10349 */               this.currentBatchBindAccessors = pushedBatch.currentBatchBindAccessors;
/* 10350 */               this.needToParse = pushedBatch.need_to_parse;
/* 10351 */               this.currentBatchNeedToPrepareBinds = pushedBatch.current_batch_need_to_prepare_binds;
/*       */               
/* 10353 */               this.firstRowInBatch = pushedBatch.first_row_in_batch;
/*       */               
/* 10355 */               setupBindBuffers(pushedBatch.first_row_in_batch, pushedBatch.number_of_rows_to_be_bound);
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 10360 */               this.currentRank = pushedBatch.number_of_rows_to_be_bound;
/*       */               
/* 10362 */               executeForRowsWithTimeout(false);
/*       */               
/* 10364 */               i += this.validRows;
/* 10365 */               if (this.sqlKind.isPlsqlOrCall())
/*       */               {
/* 10367 */                 arrayOfInt[b++] = this.validRows;
/*       */               }
/*       */               
/* 10370 */               this.pushedBatches = pushedBatch.next;
/*       */             
/*       */             }
/* 10373 */             while (this.pushedBatches != null);
/*       */ 
/*       */             
/* 10376 */             this.pushedBatchesTail = null;
/* 10377 */             this.firstRowInBatch = 0;
/*       */             
/* 10379 */             this.needToParse = bool;
/*       */           } 
/*       */ 
/*       */ 
/*       */           
/* 10384 */           slideDownCurrentRow(j);
/*       */ 
/*       */         
/*       */         }
/* 10388 */         catch (SQLException sQLException) {
/*       */ 
/*       */ 
/*       */           
/* 10392 */           int j = this.currentRank;
/* 10393 */           clearBatch();
/* 10394 */           this.needToParse = true;
/*       */           
/* 10396 */           if (!this.sqlKind.isPlsqlOrCall())
/*       */           {
/*       */ 
/*       */ 
/*       */             
/* 10401 */             if (this.numberOfExecutedElementsInBatch != -1 && this.numberOfExecutedElementsInBatch != j) {
/*       */ 
/*       */ 
/*       */ 
/*       */               
/* 10406 */               arrayOfInt = new int[this.numberOfExecutedElementsInBatch];
/* 10407 */               for (b = 0; b < this.numberOfExecutedElementsInBatch; b++) {
/* 10408 */                 arrayOfInt[b] = -2;
/*       */               }
/*       */             } else {
/* 10411 */               for (b = 0; b < arrayOfInt.length; b++)
/* 10412 */                 arrayOfInt[b] = -3; 
/*       */             }  } 
/* 10414 */           resetCurrentRowBinders();
/*       */ 
/*       */           
/* 10417 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(sQLException, this.sqlKind.isPlsqlOrCall() ? b : arrayOfInt.length, arrayOfInt);
/* 10418 */           batchUpdateException.fillInStackTrace();
/* 10419 */           throw batchUpdateException;
/*       */         
/*       */         }
/*       */         finally {
/*       */           
/* 10424 */           if (this.sqlKind.isPlsqlOrCall() || i > this.validRows) {
/* 10425 */             this.validRows = i;
/*       */           }
/* 10427 */           checkValidRowsStatus();
/*       */           
/* 10429 */           this.currentRank = 0;
/*       */         } 
/*       */         
/* 10432 */         if (this.validRows < 0) {
/*       */           
/* 10434 */           for (b = 0; b < arrayOfInt.length; b++) {
/* 10435 */             arrayOfInt[b] = -3;
/*       */           }
/*       */           
/* 10438 */           BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(81, 0, arrayOfInt);
/* 10439 */           batchUpdateException.fillInStackTrace();
/* 10440 */           throw batchUpdateException;
/*       */         } 
/*       */         
/* 10443 */         if (!this.sqlKind.isPlsqlOrCall())
/*       */         {
/* 10445 */           for (b = 0; b < arrayOfInt.length; b++) {
/* 10446 */             arrayOfInt[b] = -2;
/*       */           }
/*       */         }
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10454 */       this.connection.registerHeartbeat();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10460 */       return arrayOfInt;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void pushBatch(boolean paramBoolean) {
/* 10468 */     PushedBatch pushedBatch = new PushedBatch();
/*       */     
/* 10470 */     pushedBatch.currentBatchCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 10472 */     System.arraycopy(this.currentBatchCharLens, 0, pushedBatch.currentBatchCharLens, 0, this.numberOfBindPositions);
/*       */ 
/*       */     
/* 10475 */     pushedBatch.lastBoundCharLens = new int[this.numberOfBindPositions];
/*       */     
/* 10477 */     System.arraycopy(this.lastBoundCharLens, 0, pushedBatch.lastBoundCharLens, 0, this.numberOfBindPositions);
/*       */ 
/*       */     
/* 10480 */     if (this.currentBatchBindAccessors != null) {
/*       */       
/* 10482 */       pushedBatch.currentBatchBindAccessors = new Accessor[this.numberOfBindPositions];
/*       */       
/* 10484 */       System.arraycopy(this.currentBatchBindAccessors, 0, pushedBatch.currentBatchBindAccessors, 0, this.numberOfBindPositions);
/*       */     } 
/*       */ 
/*       */     
/* 10488 */     pushedBatch.lastBoundNeeded = this.lastBoundNeeded;
/* 10489 */     pushedBatch.need_to_parse = this.needToParse;
/* 10490 */     pushedBatch.current_batch_need_to_prepare_binds = this.currentBatchNeedToPrepareBinds;
/* 10491 */     pushedBatch.first_row_in_batch = this.firstRowInBatch;
/* 10492 */     pushedBatch.number_of_rows_to_be_bound = this.currentRank - this.firstRowInBatch;
/*       */     
/* 10494 */     if (this.pushedBatches == null) {
/* 10495 */       this.pushedBatches = pushedBatch;
/*       */     } else {
/* 10497 */       this.pushedBatchesTail.next = pushedBatch;
/*       */     } 
/* 10499 */     this.pushedBatchesTail = pushedBatch;
/*       */     
/* 10501 */     if (!paramBoolean) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10507 */       int[] arrayOfInt = this.currentBatchCharLens;
/*       */       
/* 10509 */       this.currentBatchCharLens = this.lastBoundCharLens;
/* 10510 */       this.lastBoundCharLens = arrayOfInt;
/*       */       
/* 10512 */       this.lastBoundNeeded = false;
/*       */       
/* 10514 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/* 10515 */         this.currentBatchCharLens[b] = 0;
/*       */       }
/* 10517 */       this.firstRowInBatch = this.currentRank;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int doScrollPstmtExecuteUpdate() throws SQLException {
/* 10531 */     doScrollExecuteCommon();
/*       */     
/* 10533 */     if (this.sqlKind.isSELECT()) {
/* 10534 */       this.scrollRsetTypeSolved = true;
/*       */     }
/* 10536 */     return this.validRows;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int copyBinds(Statement paramStatement, int paramInt) throws SQLException {
/* 10551 */     if (this.numberOfBindPositions > 0) {
/*       */       
/* 10553 */       OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)paramStatement;
/*       */       
/* 10555 */       int i = this.bindIndicatorSubRange + 5;
/*       */       
/* 10557 */       int j = this.bindByteSubRange;
/* 10558 */       int k = this.bindCharSubRange;
/* 10559 */       int m = this.indicatorsOffset;
/* 10560 */       int n = this.valueLengthsOffset;
/*       */       
/* 10562 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*       */         
/* 10564 */         short s1 = this.bindIndicators[i + 0];
/*       */         
/* 10566 */         short s2 = this.bindIndicators[i + 1];
/*       */         
/* 10568 */         short s3 = this.bindIndicators[i + 2];
/*       */ 
/*       */         
/* 10571 */         int i1 = b + paramInt;
/*       */ 
/*       */ 
/*       */         
/* 10575 */         if (oraclePreparedStatement.parameterDatum == null) {
/* 10576 */           oraclePreparedStatement.parameterDatum = new byte[oraclePreparedStatement.numberOfBindRowsAllocated][oraclePreparedStatement.numberOfBindPositions][];
/*       */         }
/*       */         
/* 10579 */         if (oraclePreparedStatement.parameterOtype == null) {
/* 10580 */           oraclePreparedStatement.parameterOtype = new OracleTypeADT[oraclePreparedStatement.numberOfBindRowsAllocated][oraclePreparedStatement.numberOfBindPositions];
/*       */         }
/*       */         
/* 10583 */         if (this.bindIndicators[m] == -1) {
/*       */           
/* 10585 */           oraclePreparedStatement.currentRowBinders[i1] = copiedNullBinder(s1, s2);
/*       */           
/* 10587 */           if (s3 > 0) {
/* 10588 */             oraclePreparedStatement.currentRowCharLens[i1] = 1;
/*       */           }
/* 10590 */         } else if (s1 == 109 || s1 == 111) {
/*       */           
/* 10592 */           oraclePreparedStatement.currentRowBinders[i1] = (s1 == 109) ? this.theNamedTypeBinder : this.theRefTypeBinder;
/*       */ 
/*       */ 
/*       */ 
/*       */           
/* 10597 */           byte[] arrayOfByte1 = this.parameterDatum[0][b];
/* 10598 */           int i2 = arrayOfByte1.length;
/* 10599 */           byte[] arrayOfByte2 = new byte[i2];
/*       */           
/* 10601 */           oraclePreparedStatement.parameterDatum[0][i1] = arrayOfByte2;
/*       */           
/* 10603 */           System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i2);
/*       */           
/* 10605 */           oraclePreparedStatement.parameterOtype[0][i1] = this.parameterOtype[0][b];
/*       */         }
/* 10607 */         else if (s2 > 0) {
/*       */           
/* 10609 */           oraclePreparedStatement.currentRowBinders[i1] = copiedByteBinder(s1, this.bindBytes, j, s2, this.bindIndicators[n]);
/*       */         
/*       */         }
/* 10612 */         else if (s3 > 0) {
/*       */           
/* 10614 */           oraclePreparedStatement.currentRowBinders[i1] = copiedCharBinder(s1, this.bindChars, k, s3, this.bindIndicators[n], getInoutIndicator(b));
/*       */           
/* 10616 */           oraclePreparedStatement.currentRowCharLens[i1] = s3;
/*       */         }
/*       */         else {
/*       */           
/* 10620 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89, "copyBinds doesn't understand type " + s1);
/* 10621 */           sQLException.fillInStackTrace();
/* 10622 */           throw sQLException;
/*       */         } 
/*       */         
/* 10625 */         j += this.bindBufferCapacity * s2;
/* 10626 */         k += this.bindBufferCapacity * s3;
/* 10627 */         m += this.numberOfBindRowsAllocated;
/* 10628 */         n += this.numberOfBindRowsAllocated;
/* 10629 */         i += 10;
/*       */       } 
/*       */     } 
/*       */     
/* 10633 */     return this.numberOfBindPositions;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedNullBinder(short paramShort, int paramInt) throws SQLException {
/* 10640 */     return new CopiedNullBinder(paramShort, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedByteBinder(short paramShort1, byte[] paramArrayOfbyte, int paramInt1, int paramInt2, short paramShort2) throws SQLException {
/* 10648 */     byte[] arrayOfByte = new byte[paramInt2];
/*       */     
/* 10650 */     System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
/*       */     
/* 10652 */     return new CopiedByteBinder(paramShort1, paramInt2, arrayOfByte, paramShort2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Binder copiedCharBinder(short paramShort1, char[] paramArrayOfchar, int paramInt1, int paramInt2, short paramShort2, short paramShort3) throws SQLException {
/* 10660 */     char[] arrayOfChar = new char[paramInt2];
/*       */     
/* 10662 */     System.arraycopy(paramArrayOfchar, paramInt1, arrayOfChar, 0, paramInt2);
/*       */     
/* 10664 */     return new CopiedCharBinder(paramShort1, arrayOfChar, paramShort2, paramShort3);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected void hardClose() throws SQLException {
/* 10672 */     super.hardClose();
/*       */     
/* 10674 */     this.connection.cacheBuffer(this.bindBytes);
/* 10675 */     this.bindBytes = null;
/* 10676 */     this.connection.cacheBuffer(this.bindChars);
/* 10677 */     this.bindChars = null;
/* 10678 */     this.bindIndicators = null;
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10683 */     if (!this.connection.isClosed())
/*       */     {
/* 10685 */       cleanAllTempLobs();
/*       */     }
/*       */     
/* 10688 */     this.lastBoundBytes = null;
/* 10689 */     this.lastBoundChars = null;
/*       */     
/* 10691 */     clearParameters();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected void alwaysOnClose() throws SQLException {
/* 10703 */     if (this.currentRank > 0)
/*       */     {
/* 10705 */       if (this.m_batchStyle == 2) {
/* 10706 */         clearBatch();
/*       */       
/*       */       }
/*       */       else {
/*       */ 
/*       */         
/* 10712 */         int i = this.validRows;
/*       */         
/* 10714 */         this.prematureBatchCount = sendBatch();
/* 10715 */         this.validRows = i;
/*       */       } 
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10730 */     if (this.sqlKind.isSELECT()) {
/* 10731 */       OracleStatement oracleStatement = this.children;
/*       */       
/* 10733 */       while (oracleStatement != null) {
/* 10734 */         OracleStatement oracleStatement1 = oracleStatement.nextChild;
/*       */ 
/*       */         
/* 10737 */         if (oracleStatement.serverCursor) {
/* 10738 */           oracleStatement.cursorId = 0;
/*       */         }
/* 10740 */         oracleStatement = oracleStatement1;
/*       */       } 
/*       */     } 
/*       */     
/* 10744 */     super.alwaysOnClose();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDisableStmtCaching(boolean paramBoolean) {
/* 10757 */     synchronized (this.connection) {
/*       */       
/* 10759 */       if (paramBoolean == true) {
/* 10760 */         this.cacheState = 3;
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFormOfUse(int paramInt, short paramShort) {
/* 10770 */     synchronized (this.connection) {
/*       */ 
/*       */       
/* 10773 */       int i = paramInt - 1;
/*       */       
/* 10775 */       if (this.currentRowFormOfUse[i] != paramShort) {
/*       */         
/* 10777 */         this.currentRowFormOfUse[i] = paramShort;
/*       */ 
/*       */ 
/*       */         
/* 10781 */         if (this.currentRowBindAccessors != null) {
/*       */           
/* 10783 */           Accessor accessor = this.currentRowBindAccessors[i];
/*       */           
/* 10785 */           if (accessor != null) {
/* 10786 */             accessor.setFormOfUse(paramShort);
/*       */           }
/*       */         } 
/*       */         
/* 10790 */         if (this.returnParamAccessors != null) {
/*       */           
/* 10792 */           Accessor accessor = this.returnParamAccessors[i];
/*       */           
/* 10794 */           if (accessor != null) {
/* 10795 */             accessor.setFormOfUse(paramShort);
/*       */           }
/*       */         } 
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/* 10822 */     setURLInternal(paramInt, paramURL);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setURLInternal(int paramInt, URL paramURL) throws SQLException {
/* 10829 */     setStringInternal(paramInt, paramURL.toString());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ParameterMetaData getParameterMetaData() throws SQLException {
/* 10836 */     return (ParameterMetaData)new OracleParameterMetaData(this.sqlObject.getParameterCount());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleParameterMetaData OracleGetParameterMetaData() throws SQLException {
/* 10859 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 10860 */     sQLException.fillInStackTrace();
/* 10861 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2) throws SQLException {
/* 10871 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 10873 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10874 */       sQLException.fillInStackTrace();
/* 10875 */       throw sQLException;
/*       */     } 
/*       */     
/* 10878 */     if (this.numReturnParams <= 0) {
/*       */       
/* 10880 */       this.numReturnParams = this.sqlObject.getReturnParameterCount();
/* 10881 */       if (this.numReturnParams <= 0) {
/*       */         
/* 10883 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10884 */         sQLException.fillInStackTrace();
/* 10885 */         throw sQLException;
/*       */       } 
/*       */     } 
/*       */     
/* 10889 */     int i = paramInt1 - 1;
/* 10890 */     if (i < this.numberOfBindPositions - this.numReturnParams || paramInt1 > this.numberOfBindPositions) {
/*       */ 
/*       */       
/* 10893 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10894 */       sQLException.fillInStackTrace();
/* 10895 */       throw sQLException;
/*       */     } 
/*       */     
/* 10898 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 10900 */     short s = 0;
/* 10901 */     if (this.currentRowFormOfUse != null && this.currentRowFormOfUse[i] != 0) {
/* 10902 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 10904 */     registerReturnParameterInternal(i, j, paramInt2, -1, s, null);
/*       */ 
/*       */     
/* 10907 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 10918 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 10920 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10921 */       sQLException.fillInStackTrace();
/* 10922 */       throw sQLException;
/*       */     } 
/*       */     
/* 10925 */     int i = paramInt1 - 1;
/* 10926 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*       */       
/* 10928 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10929 */       sQLException.fillInStackTrace();
/* 10930 */       throw sQLException;
/*       */     } 
/*       */     
/* 10933 */     if (paramInt2 != 1 && paramInt2 != 12 && paramInt2 != -1 && paramInt2 != -2 && paramInt2 != -3 && paramInt2 != -4 && paramInt2 != 12) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/* 10942 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10943 */       sQLException.fillInStackTrace();
/* 10944 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10948 */     if (paramInt3 <= 0) {
/*       */ 
/*       */       
/* 10951 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10952 */       sQLException.fillInStackTrace();
/* 10953 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 10957 */     int j = getInternalTypeForDmlReturning(paramInt2);
/*       */     
/* 10959 */     short s = 0;
/* 10960 */     if (this.currentRowFormOfUse != null && this.currentRowFormOfUse[i] != 0) {
/* 10961 */       s = this.currentRowFormOfUse[i];
/*       */     }
/* 10963 */     registerReturnParameterInternal(i, j, paramInt2, paramInt3, s, null);
/*       */ 
/*       */     
/* 10966 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void registerReturnParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 10977 */     if (this.numberOfBindPositions <= 0) {
/*       */       
/* 10979 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 10980 */       sQLException.fillInStackTrace();
/* 10981 */       throw sQLException;
/*       */     } 
/*       */     
/* 10984 */     int i = paramInt1 - 1;
/* 10985 */     if (i < 0 || paramInt1 > this.numberOfBindPositions) {
/*       */       
/* 10987 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 10988 */       sQLException.fillInStackTrace();
/* 10989 */       throw sQLException;
/*       */     } 
/*       */     
/* 10992 */     int j = getInternalTypeForDmlReturning(paramInt2);
/* 10993 */     if (j != 111 && j != 109) {
/*       */ 
/*       */ 
/*       */       
/* 10997 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 10998 */       sQLException.fillInStackTrace();
/* 10999 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/* 11003 */     registerReturnParameterInternal(i, j, paramInt2, -1, (short)0, paramString);
/*       */ 
/*       */     
/* 11006 */     this.currentRowBinders[i] = this.theReturnParamBinder;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ResultSet getReturnResultSet() throws SQLException {
/* 11014 */     if (this.closed) {
/*       */       
/* 11016 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 11017 */       sQLException.fillInStackTrace();
/* 11018 */       throw sQLException;
/*       */     } 
/*       */     
/* 11021 */     if (this.returnParamAccessors == null || this.numReturnParams == 0) {
/*       */       
/* 11023 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144);
/* 11024 */       sQLException.fillInStackTrace();
/* 11025 */       throw sQLException;
/*       */     } 
/*       */     
/* 11028 */     if (this.returnResultSet == null || this.numReturnParams == 0 || !this.isOpen)
/*       */     {
/*       */ 
/*       */       
/* 11032 */       this.returnResultSet = new OracleReturnResultSet(this);
/*       */     }
/*       */     
/* 11035 */     return (ResultSet)this.returnResultSet;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int getInternalTypeForDmlReturning(int paramInt) throws SQLException {
/* 11049 */     char c = Character.MIN_VALUE;
/*       */     
/* 11051 */     switch (paramInt) {
/*       */       
/*       */       case -7:
/*       */       case -6:
/*       */       case -5:
/*       */       case 2:
/*       */       case 3:
/*       */       case 4:
/*       */       case 5:
/*       */       case 6:
/*       */       case 7:
/*       */       case 8:
/* 11063 */         c = '\006';
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/* 11175 */         return c;case 100: c = 'd'; return c;case 101: c = 'e'; return c;case 1: c = '`'; return c;case 12: c = '\001'; return c;case -1: c = '\b'; return c;case 91: case 92: c = '\f'; return c;case 93: c = '´'; return c;case -101: c = 'µ'; return c;case -102: c = 'ç'; return c;case -103: c = '¶'; return c;case -104: c = '·'; return c;case -3: case -2: c = '\027'; return c;case -4: c = '\030'; return c;case -8: c = 'h'; return c;case 2004: c = 'q'; return c;case 2005: c = 'p'; return c;case -13: c = 'r'; return c;case 2002: case 2003: case 2007: case 2008: c = 'm'; return c;case 2006: c = 'o'; return c;case 70: c = '\001'; return c;
/*       */     } 
/*       */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*       */     sQLException.fillInStackTrace();
/*       */     throw sQLException;
/*       */   }
/*       */   
/*       */   void registerReturnParamsForAutoKey() throws SQLException {
/* 11183 */     int[] arrayOfInt1 = this.autoKeyInfo.returnTypes;
/* 11184 */     short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses;
/* 11185 */     int[] arrayOfInt2 = this.autoKeyInfo.columnIndexes;
/*       */     
/* 11187 */     int i = arrayOfInt1.length;
/*       */ 
/*       */     
/* 11190 */     int j = this.numberOfBindPositions - i;
/*       */ 
/*       */     
/* 11193 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 11195 */       int k = j + b;
/* 11196 */       this.currentRowBinders[k] = this.theReturnParamBinder;
/*       */       
/* 11198 */       byte b1 = this.connection.defaultnchar ? 2 : 1;
/*       */ 
/*       */       
/* 11201 */       if (arrayOfShort != null && arrayOfInt2 != null)
/*       */       {
/* 11203 */         if (arrayOfShort[arrayOfInt2[b] - 1] == 2) {
/*       */ 
/*       */           
/* 11206 */           b1 = 2;
/* 11207 */           setFormOfUse(k + 1, b1);
/*       */         } 
/*       */       }
/*       */       
/* 11211 */       checkTypeForAutoKey(arrayOfInt1[b]);
/*       */       
/* 11213 */       String str = null;
/* 11214 */       if (arrayOfInt1[b] == 111) {
/* 11215 */         str = this.autoKeyInfo.tableTypeNames[arrayOfInt2[b] - 1];
/*       */       }
/* 11217 */       registerReturnParameterInternal(k, arrayOfInt1[b], arrayOfInt1[b], -1, b1, str);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanOldTempLobs() {
/* 11227 */     if (this.m_batchStyle != 1 || this.currentRank == this.batch - 1)
/*       */     {
/* 11229 */       super.cleanOldTempLobs();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   void resetOnExceptionDuringExecute() {
/* 11236 */     super.resetOnExceptionDuringExecute();
/* 11237 */     this.currentRank = 0;
/* 11238 */     this.currentBatchNeedToPrepareBinds = true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void resetCurrentRowBinders() {
/* 11247 */     Binder[] arrayOfBinder = this.currentRowBinders;
/* 11248 */     if (this.binders != null && this.currentRowBinders != null && arrayOfBinder != this.binders[0]) {
/*       */ 
/*       */ 
/*       */       
/* 11252 */       this.currentRowBinders = this.binders[0];
/* 11253 */       this.binders[this.numberOfBoundRows] = arrayOfBinder;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setArrayAtName(String paramString, Array paramArray) throws SQLException {
/* 11283 */     String str = paramString.intern();
/* 11284 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11285 */     boolean bool = false;
/* 11286 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11288 */     for (byte b = 0; b < i; b++) {
/* 11289 */       if (arrayOfString[b] == str) {
/*       */         
/* 11291 */         setArray(b + 1, paramArray);
/*       */         
/* 11293 */         bool = true;
/*       */       } 
/*       */     } 
/* 11296 */     if (!bool) {
/*       */       
/* 11298 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11299 */       sQLException.fillInStackTrace();
/* 11300 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBigDecimalAtName(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/* 11320 */     String str = paramString.intern();
/* 11321 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11322 */     boolean bool = false;
/* 11323 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11325 */     for (byte b = 0; b < i; b++) {
/* 11326 */       if (arrayOfString[b] == str) {
/*       */         
/* 11328 */         setBigDecimal(b + 1, paramBigDecimal);
/*       */         
/* 11330 */         bool = true;
/*       */       } 
/*       */     } 
/* 11333 */     if (!bool) {
/*       */       
/* 11335 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11336 */       sQLException.fillInStackTrace();
/* 11337 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBlobAtName(String paramString, Blob paramBlob) throws SQLException {
/* 11357 */     String str = paramString.intern();
/* 11358 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11359 */     boolean bool = false;
/* 11360 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11362 */     for (byte b = 0; b < i; b++) {
/* 11363 */       if (arrayOfString[b] == str) {
/*       */         
/* 11365 */         setBlob(b + 1, paramBlob);
/*       */         
/* 11367 */         bool = true;
/*       */       } 
/*       */     } 
/* 11370 */     if (!bool) {
/*       */       
/* 11372 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11373 */       sQLException.fillInStackTrace();
/* 11374 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBooleanAtName(String paramString, boolean paramBoolean) throws SQLException {
/* 11394 */     String str = paramString.intern();
/* 11395 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11396 */     boolean bool = false;
/* 11397 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11399 */     for (byte b = 0; b < i; b++) {
/* 11400 */       if (arrayOfString[b] == str) {
/*       */         
/* 11402 */         setBoolean(b + 1, paramBoolean);
/*       */         
/* 11404 */         bool = true;
/*       */       } 
/*       */     } 
/* 11407 */     if (!bool) {
/*       */       
/* 11409 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11410 */       sQLException.fillInStackTrace();
/* 11411 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setByteAtName(String paramString, byte paramByte) throws SQLException {
/* 11431 */     String str = paramString.intern();
/* 11432 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11433 */     boolean bool = false;
/* 11434 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11436 */     for (byte b = 0; b < i; b++) {
/* 11437 */       if (arrayOfString[b] == str) {
/*       */         
/* 11439 */         setByte(b + 1, paramByte);
/*       */         
/* 11441 */         bool = true;
/*       */       } 
/*       */     } 
/* 11444 */     if (!bool) {
/*       */       
/* 11446 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11447 */       sQLException.fillInStackTrace();
/* 11448 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBytesAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 11468 */     String str = paramString.intern();
/* 11469 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11470 */     boolean bool = false;
/* 11471 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11473 */     for (byte b = 0; b < i; b++) {
/* 11474 */       if (arrayOfString[b] == str) {
/*       */         
/* 11476 */         setBytes(b + 1, paramArrayOfbyte);
/*       */         
/* 11478 */         bool = true;
/*       */       } 
/*       */     } 
/* 11481 */     if (!bool) {
/*       */       
/* 11483 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11484 */       sQLException.fillInStackTrace();
/* 11485 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClobAtName(String paramString, Clob paramClob) throws SQLException {
/* 11505 */     String str = paramString.intern();
/* 11506 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11507 */     boolean bool = false;
/* 11508 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11510 */     for (byte b = 0; b < i; b++) {
/* 11511 */       if (arrayOfString[b] == str) {
/*       */         
/* 11513 */         setClob(b + 1, paramClob);
/*       */         
/* 11515 */         bool = true;
/*       */       } 
/*       */     } 
/* 11518 */     if (!bool) {
/*       */       
/* 11520 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11521 */       sQLException.fillInStackTrace();
/* 11522 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDateAtName(String paramString, Date paramDate) throws SQLException {
/* 11542 */     String str = paramString.intern();
/* 11543 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11544 */     boolean bool = false;
/* 11545 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11547 */     for (byte b = 0; b < i; b++) {
/* 11548 */       if (arrayOfString[b] == str) {
/*       */         
/* 11550 */         setDate(b + 1, paramDate);
/*       */         
/* 11552 */         bool = true;
/*       */       } 
/*       */     } 
/* 11555 */     if (!bool) {
/*       */       
/* 11557 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11558 */       sQLException.fillInStackTrace();
/* 11559 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDateAtName(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 11579 */     String str = paramString.intern();
/* 11580 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11581 */     boolean bool = false;
/* 11582 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11584 */     for (byte b = 0; b < i; b++) {
/* 11585 */       if (arrayOfString[b] == str) {
/*       */         
/* 11587 */         setDate(b + 1, paramDate, paramCalendar);
/*       */         
/* 11589 */         bool = true;
/*       */       } 
/*       */     } 
/* 11592 */     if (!bool) {
/*       */       
/* 11594 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11595 */       sQLException.fillInStackTrace();
/* 11596 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDoubleAtName(String paramString, double paramDouble) throws SQLException {
/* 11616 */     String str = paramString.intern();
/* 11617 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11618 */     boolean bool = false;
/* 11619 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11621 */     for (byte b = 0; b < i; b++) {
/* 11622 */       if (arrayOfString[b] == str) {
/*       */         
/* 11624 */         setDouble(b + 1, paramDouble);
/*       */         
/* 11626 */         bool = true;
/*       */       } 
/*       */     } 
/* 11629 */     if (!bool) {
/*       */       
/* 11631 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11632 */       sQLException.fillInStackTrace();
/* 11633 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFloatAtName(String paramString, float paramFloat) throws SQLException {
/* 11653 */     String str = paramString.intern();
/* 11654 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11655 */     boolean bool = false;
/* 11656 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11658 */     for (byte b = 0; b < i; b++) {
/* 11659 */       if (arrayOfString[b] == str) {
/*       */         
/* 11661 */         setFloat(b + 1, paramFloat);
/*       */         
/* 11663 */         bool = true;
/*       */       } 
/*       */     } 
/* 11666 */     if (!bool) {
/*       */       
/* 11668 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11669 */       sQLException.fillInStackTrace();
/* 11670 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setIntAtName(String paramString, int paramInt) throws SQLException {
/* 11690 */     String str = paramString.intern();
/* 11691 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11692 */     boolean bool = false;
/* 11693 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11695 */     for (byte b = 0; b < i; b++) {
/* 11696 */       if (arrayOfString[b] == str) {
/*       */         
/* 11698 */         setInt(b + 1, paramInt);
/*       */         
/* 11700 */         bool = true;
/*       */       } 
/*       */     } 
/* 11703 */     if (!bool) {
/*       */       
/* 11705 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11706 */       sQLException.fillInStackTrace();
/* 11707 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setLongAtName(String paramString, long paramLong) throws SQLException {
/* 11727 */     String str = paramString.intern();
/* 11728 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11729 */     boolean bool = false;
/* 11730 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11732 */     for (byte b = 0; b < i; b++) {
/* 11733 */       if (arrayOfString[b] == str) {
/*       */         
/* 11735 */         setLong(b + 1, paramLong);
/*       */         
/* 11737 */         bool = true;
/*       */       } 
/*       */     } 
/* 11740 */     if (!bool) {
/*       */       
/* 11742 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11743 */       sQLException.fillInStackTrace();
/* 11744 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObjectAtName(String paramString, Object paramObject) throws SQLException {
/* 11764 */     String str = paramString.intern();
/* 11765 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11766 */     boolean bool = false;
/* 11767 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11769 */     for (byte b = 0; b < i; b++) {
/* 11770 */       if (arrayOfString[b] == str) {
/*       */         
/* 11772 */         setObject(b + 1, paramObject);
/*       */         
/* 11774 */         bool = true;
/*       */       } 
/*       */     } 
/* 11777 */     if (!bool) {
/*       */       
/* 11779 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11780 */       sQLException.fillInStackTrace();
/* 11781 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setObjectAtName(String paramString, Object paramObject, int paramInt) throws SQLException {
/* 11801 */     String str = paramString.intern();
/* 11802 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11803 */     boolean bool = false;
/* 11804 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11806 */     for (byte b = 0; b < i; b++) {
/* 11807 */       if (arrayOfString[b] == str) {
/*       */         
/* 11809 */         setObject(b + 1, paramObject, paramInt);
/*       */         
/* 11811 */         bool = true;
/*       */       } 
/*       */     } 
/* 11814 */     if (!bool) {
/*       */       
/* 11816 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11817 */       sQLException.fillInStackTrace();
/* 11818 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRefAtName(String paramString, Ref paramRef) throws SQLException {
/* 11838 */     String str = paramString.intern();
/* 11839 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11840 */     boolean bool = false;
/* 11841 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11843 */     for (byte b = 0; b < i; b++) {
/* 11844 */       if (arrayOfString[b] == str) {
/*       */         
/* 11846 */         setRef(b + 1, paramRef);
/*       */         
/* 11848 */         bool = true;
/*       */       } 
/*       */     } 
/* 11851 */     if (!bool) {
/*       */       
/* 11853 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11854 */       sQLException.fillInStackTrace();
/* 11855 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setShortAtName(String paramString, short paramShort) throws SQLException {
/* 11875 */     String str = paramString.intern();
/* 11876 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11877 */     boolean bool = false;
/* 11878 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11880 */     for (byte b = 0; b < i; b++) {
/* 11881 */       if (arrayOfString[b] == str) {
/*       */         
/* 11883 */         setShort(b + 1, paramShort);
/*       */         
/* 11885 */         bool = true;
/*       */       } 
/*       */     } 
/* 11888 */     if (!bool) {
/*       */       
/* 11890 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11891 */       sQLException.fillInStackTrace();
/* 11892 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setStringAtName(String paramString1, String paramString2) throws SQLException {
/* 11912 */     String str = paramString1.intern();
/* 11913 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11914 */     boolean bool = false;
/* 11915 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11917 */     for (byte b = 0; b < i; b++) {
/* 11918 */       if (arrayOfString[b] == str) {
/*       */         
/* 11920 */         setString(b + 1, paramString2);
/*       */         
/* 11922 */         bool = true;
/*       */       } 
/*       */     } 
/* 11925 */     if (!bool) {
/*       */       
/* 11927 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 11928 */       sQLException.fillInStackTrace();
/* 11929 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimeAtName(String paramString, Time paramTime) throws SQLException {
/* 11949 */     String str = paramString.intern();
/* 11950 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11951 */     boolean bool = false;
/* 11952 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11954 */     for (byte b = 0; b < i; b++) {
/* 11955 */       if (arrayOfString[b] == str) {
/*       */         
/* 11957 */         setTime(b + 1, paramTime);
/*       */         
/* 11959 */         bool = true;
/*       */       } 
/*       */     } 
/* 11962 */     if (!bool) {
/*       */       
/* 11964 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 11965 */       sQLException.fillInStackTrace();
/* 11966 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimeAtName(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 11986 */     String str = paramString.intern();
/* 11987 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 11988 */     boolean bool = false;
/* 11989 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 11991 */     for (byte b = 0; b < i; b++) {
/* 11992 */       if (arrayOfString[b] == str) {
/*       */         
/* 11994 */         setTime(b + 1, paramTime, paramCalendar);
/*       */         
/* 11996 */         bool = true;
/*       */       } 
/*       */     } 
/* 11999 */     if (!bool) {
/*       */       
/* 12001 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12002 */       sQLException.fillInStackTrace();
/* 12003 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp) throws SQLException {
/* 12023 */     String str = paramString.intern();
/* 12024 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12025 */     boolean bool = false;
/* 12026 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12028 */     for (byte b = 0; b < i; b++) {
/* 12029 */       if (arrayOfString[b] == str) {
/*       */         
/* 12031 */         setTimestamp(b + 1, paramTimestamp);
/*       */         
/* 12033 */         bool = true;
/*       */       } 
/*       */     } 
/* 12036 */     if (!bool) {
/*       */       
/* 12038 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12039 */       sQLException.fillInStackTrace();
/* 12040 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 12060 */     String str = paramString.intern();
/* 12061 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12062 */     boolean bool = false;
/* 12063 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12065 */     for (byte b = 0; b < i; b++) {
/* 12066 */       if (arrayOfString[b] == str) {
/*       */         
/* 12068 */         setTimestamp(b + 1, paramTimestamp, paramCalendar);
/*       */         
/* 12070 */         bool = true;
/*       */       } 
/*       */     } 
/* 12073 */     if (!bool) {
/*       */       
/* 12075 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12076 */       sQLException.fillInStackTrace();
/* 12077 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setURLAtName(String paramString, URL paramURL) throws SQLException {
/* 12097 */     String str = paramString.intern();
/* 12098 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12099 */     boolean bool = false;
/* 12100 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12102 */     for (byte b = 0; b < i; b++) {
/* 12103 */       if (arrayOfString[b] == str) {
/*       */         
/* 12105 */         setURL(b + 1, paramURL);
/*       */         
/* 12107 */         bool = true;
/*       */       } 
/*       */     } 
/* 12110 */     if (!bool) {
/*       */       
/* 12112 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12113 */       sQLException.fillInStackTrace();
/* 12114 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setARRAYAtName(String paramString, ARRAY paramARRAY) throws SQLException {
/* 12134 */     String str = paramString.intern();
/* 12135 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12136 */     boolean bool = false;
/* 12137 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12139 */     for (byte b = 0; b < i; b++) {
/* 12140 */       if (arrayOfString[b] == str) {
/*       */         
/* 12142 */         setARRAY(b + 1, paramARRAY);
/*       */         
/* 12144 */         bool = true;
/*       */       } 
/*       */     } 
/* 12147 */     if (!bool) {
/*       */       
/* 12149 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12150 */       sQLException.fillInStackTrace();
/* 12151 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBFILEAtName(String paramString, BFILE paramBFILE) throws SQLException {
/* 12171 */     String str = paramString.intern();
/* 12172 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12173 */     boolean bool = false;
/* 12174 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12176 */     for (byte b = 0; b < i; b++) {
/* 12177 */       if (arrayOfString[b] == str) {
/*       */         
/* 12179 */         setBFILE(b + 1, paramBFILE);
/*       */         
/* 12181 */         bool = true;
/*       */       } 
/*       */     } 
/* 12184 */     if (!bool) {
/*       */       
/* 12186 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12187 */       sQLException.fillInStackTrace();
/* 12188 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBfileAtName(String paramString, BFILE paramBFILE) throws SQLException {
/* 12208 */     String str = paramString.intern();
/* 12209 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12210 */     boolean bool = false;
/* 12211 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12213 */     for (byte b = 0; b < i; b++) {
/* 12214 */       if (arrayOfString[b] == str) {
/*       */         
/* 12216 */         setBfile(b + 1, paramBFILE);
/*       */         
/* 12218 */         bool = true;
/*       */       } 
/*       */     } 
/* 12221 */     if (!bool) {
/*       */       
/* 12223 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12224 */       sQLException.fillInStackTrace();
/* 12225 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloatAtName(String paramString, float paramFloat) throws SQLException {
/* 12245 */     String str = paramString.intern();
/* 12246 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12247 */     boolean bool = false;
/* 12248 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12250 */     for (byte b = 0; b < i; b++) {
/* 12251 */       if (arrayOfString[b] == str) {
/*       */         
/* 12253 */         setBinaryFloat(b + 1, paramFloat);
/*       */         
/* 12255 */         bool = true;
/*       */       } 
/*       */     } 
/* 12258 */     if (!bool) {
/*       */       
/* 12260 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12261 */       sQLException.fillInStackTrace();
/* 12262 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryFloatAtName(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 12282 */     String str = paramString.intern();
/* 12283 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12284 */     boolean bool = false;
/* 12285 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12287 */     for (byte b = 0; b < i; b++) {
/* 12288 */       if (arrayOfString[b] == str) {
/*       */         
/* 12290 */         setBinaryFloat(b + 1, paramBINARY_FLOAT);
/*       */         
/* 12292 */         bool = true;
/*       */       } 
/*       */     } 
/* 12295 */     if (!bool) {
/*       */       
/* 12297 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12298 */       sQLException.fillInStackTrace();
/* 12299 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDoubleAtName(String paramString, double paramDouble) throws SQLException {
/* 12319 */     String str = paramString.intern();
/* 12320 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12321 */     boolean bool = false;
/* 12322 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12324 */     for (byte b = 0; b < i; b++) {
/* 12325 */       if (arrayOfString[b] == str) {
/*       */         
/* 12327 */         setBinaryDouble(b + 1, paramDouble);
/*       */         
/* 12329 */         bool = true;
/*       */       } 
/*       */     } 
/* 12332 */     if (!bool) {
/*       */       
/* 12334 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12335 */       sQLException.fillInStackTrace();
/* 12336 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryDoubleAtName(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 12356 */     String str = paramString.intern();
/* 12357 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12358 */     boolean bool = false;
/* 12359 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12361 */     for (byte b = 0; b < i; b++) {
/* 12362 */       if (arrayOfString[b] == str) {
/*       */         
/* 12364 */         setBinaryDouble(b + 1, paramBINARY_DOUBLE);
/*       */         
/* 12366 */         bool = true;
/*       */       } 
/*       */     } 
/* 12369 */     if (!bool) {
/*       */       
/* 12371 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12372 */       sQLException.fillInStackTrace();
/* 12373 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBLOBAtName(String paramString, BLOB paramBLOB) throws SQLException {
/* 12393 */     String str = paramString.intern();
/* 12394 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12395 */     boolean bool = false;
/* 12396 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12398 */     for (byte b = 0; b < i; b++) {
/* 12399 */       if (arrayOfString[b] == str) {
/*       */         
/* 12401 */         setBLOB(b + 1, paramBLOB);
/*       */         
/* 12403 */         bool = true;
/*       */       } 
/*       */     } 
/* 12406 */     if (!bool) {
/*       */       
/* 12408 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12409 */       sQLException.fillInStackTrace();
/* 12410 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCHARAtName(String paramString, CHAR paramCHAR) throws SQLException {
/* 12430 */     String str = paramString.intern();
/* 12431 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12432 */     boolean bool = false;
/* 12433 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12435 */     for (byte b = 0; b < i; b++) {
/* 12436 */       if (arrayOfString[b] == str) {
/*       */         
/* 12438 */         setCHAR(b + 1, paramCHAR);
/*       */         
/* 12440 */         bool = true;
/*       */       } 
/*       */     } 
/* 12443 */     if (!bool) {
/*       */       
/* 12445 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12446 */       sQLException.fillInStackTrace();
/* 12447 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCLOBAtName(String paramString, CLOB paramCLOB) throws SQLException {
/* 12467 */     String str = paramString.intern();
/* 12468 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12469 */     boolean bool = false;
/* 12470 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12472 */     for (byte b = 0; b < i; b++) {
/* 12473 */       if (arrayOfString[b] == str) {
/*       */         
/* 12475 */         setCLOB(b + 1, paramCLOB);
/*       */         
/* 12477 */         bool = true;
/*       */       } 
/*       */     } 
/* 12480 */     if (!bool) {
/*       */       
/* 12482 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12483 */       sQLException.fillInStackTrace();
/* 12484 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCursorAtName(String paramString, ResultSet paramResultSet) throws SQLException {
/* 12504 */     String str = paramString.intern();
/* 12505 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12506 */     boolean bool = false;
/* 12507 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12509 */     for (byte b = 0; b < i; b++) {
/* 12510 */       if (arrayOfString[b] == str) {
/*       */         
/* 12512 */         setCursor(b + 1, paramResultSet);
/*       */         
/* 12514 */         bool = true;
/*       */       } 
/*       */     } 
/* 12517 */     if (!bool) {
/*       */       
/* 12519 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12520 */       sQLException.fillInStackTrace();
/* 12521 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCustomDatumAtName(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/* 12541 */     String str = paramString.intern();
/* 12542 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12543 */     boolean bool = false;
/* 12544 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12546 */     for (byte b = 0; b < i; b++) {
/* 12547 */       if (arrayOfString[b] == str) {
/*       */         
/* 12549 */         setCustomDatum(b + 1, paramCustomDatum);
/*       */         
/* 12551 */         bool = true;
/*       */       } 
/*       */     } 
/* 12554 */     if (!bool) {
/*       */       
/* 12556 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12557 */       sQLException.fillInStackTrace();
/* 12558 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDATEAtName(String paramString, DATE paramDATE) throws SQLException {
/* 12578 */     String str = paramString.intern();
/* 12579 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12580 */     boolean bool = false;
/* 12581 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12583 */     for (byte b = 0; b < i; b++) {
/* 12584 */       if (arrayOfString[b] == str) {
/*       */         
/* 12586 */         setDATE(b + 1, paramDATE);
/*       */         
/* 12588 */         bool = true;
/*       */       } 
/*       */     } 
/* 12591 */     if (!bool) {
/*       */       
/* 12593 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12594 */       sQLException.fillInStackTrace();
/* 12595 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setFixedCHARAtName(String paramString1, String paramString2) throws SQLException {
/* 12615 */     String str = paramString1.intern();
/* 12616 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12617 */     boolean bool = false;
/* 12618 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12620 */     for (byte b = 0; b < i; b++) {
/* 12621 */       if (arrayOfString[b] == str) {
/*       */         
/* 12623 */         setFixedCHAR(b + 1, paramString2);
/*       */         
/* 12625 */         bool = true;
/*       */       } 
/*       */     } 
/* 12628 */     if (!bool) {
/*       */       
/* 12630 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString1);
/* 12631 */       sQLException.fillInStackTrace();
/* 12632 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALDSAtName(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/* 12652 */     String str = paramString.intern();
/* 12653 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12654 */     boolean bool = false;
/* 12655 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12657 */     for (byte b = 0; b < i; b++) {
/* 12658 */       if (arrayOfString[b] == str) {
/*       */         
/* 12660 */         setINTERVALDS(b + 1, paramINTERVALDS);
/*       */         
/* 12662 */         bool = true;
/*       */       } 
/*       */     } 
/* 12665 */     if (!bool) {
/*       */       
/* 12667 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12668 */       sQLException.fillInStackTrace();
/* 12669 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setINTERVALYMAtName(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/* 12689 */     String str = paramString.intern();
/* 12690 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12691 */     boolean bool = false;
/* 12692 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12694 */     for (byte b = 0; b < i; b++) {
/* 12695 */       if (arrayOfString[b] == str) {
/*       */         
/* 12697 */         setINTERVALYM(b + 1, paramINTERVALYM);
/*       */         
/* 12699 */         bool = true;
/*       */       } 
/*       */     } 
/* 12702 */     if (!bool) {
/*       */       
/* 12704 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12705 */       sQLException.fillInStackTrace();
/* 12706 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setNUMBERAtName(String paramString, NUMBER paramNUMBER) throws SQLException {
/* 12726 */     String str = paramString.intern();
/* 12727 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12728 */     boolean bool = false;
/* 12729 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12731 */     for (byte b = 0; b < i; b++) {
/* 12732 */       if (arrayOfString[b] == str) {
/*       */         
/* 12734 */         setNUMBER(b + 1, paramNUMBER);
/*       */         
/* 12736 */         bool = true;
/*       */       } 
/*       */     } 
/* 12739 */     if (!bool) {
/*       */       
/* 12741 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12742 */       sQLException.fillInStackTrace();
/* 12743 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOPAQUEAtName(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/* 12763 */     String str = paramString.intern();
/* 12764 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12765 */     boolean bool = false;
/* 12766 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12768 */     for (byte b = 0; b < i; b++) {
/* 12769 */       if (arrayOfString[b] == str) {
/*       */         
/* 12771 */         setOPAQUE(b + 1, paramOPAQUE);
/*       */         
/* 12773 */         bool = true;
/*       */       } 
/*       */     } 
/* 12776 */     if (!bool) {
/*       */       
/* 12778 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12779 */       sQLException.fillInStackTrace();
/* 12780 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setOracleObjectAtName(String paramString, Datum paramDatum) throws SQLException {
/* 12800 */     String str = paramString.intern();
/* 12801 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12802 */     boolean bool = false;
/* 12803 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12805 */     for (byte b = 0; b < i; b++) {
/* 12806 */       if (arrayOfString[b] == str) {
/*       */         
/* 12808 */         setOracleObject(b + 1, paramDatum);
/*       */         
/* 12810 */         bool = true;
/*       */       } 
/*       */     } 
/* 12813 */     if (!bool) {
/*       */       
/* 12815 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12816 */       sQLException.fillInStackTrace();
/* 12817 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setORADataAtName(String paramString, ORAData paramORAData) throws SQLException {
/* 12837 */     String str = paramString.intern();
/* 12838 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12839 */     boolean bool = false;
/* 12840 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12842 */     for (byte b = 0; b < i; b++) {
/* 12843 */       if (arrayOfString[b] == str) {
/*       */         
/* 12845 */         setORAData(b + 1, paramORAData);
/*       */         
/* 12847 */         bool = true;
/*       */       } 
/*       */     } 
/* 12850 */     if (!bool) {
/*       */       
/* 12852 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12853 */       sQLException.fillInStackTrace();
/* 12854 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRAWAtName(String paramString, RAW paramRAW) throws SQLException {
/* 12874 */     String str = paramString.intern();
/* 12875 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12876 */     boolean bool = false;
/* 12877 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12879 */     for (byte b = 0; b < i; b++) {
/* 12880 */       if (arrayOfString[b] == str) {
/*       */         
/* 12882 */         setRAW(b + 1, paramRAW);
/*       */         
/* 12884 */         bool = true;
/*       */       } 
/*       */     } 
/* 12887 */     if (!bool) {
/*       */       
/* 12889 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12890 */       sQLException.fillInStackTrace();
/* 12891 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setREFAtName(String paramString, REF paramREF) throws SQLException {
/* 12911 */     String str = paramString.intern();
/* 12912 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12913 */     boolean bool = false;
/* 12914 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12916 */     for (byte b = 0; b < i; b++) {
/* 12917 */       if (arrayOfString[b] == str) {
/*       */         
/* 12919 */         setREF(b + 1, paramREF);
/*       */         
/* 12921 */         bool = true;
/*       */       } 
/*       */     } 
/* 12924 */     if (!bool) {
/*       */       
/* 12926 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12927 */       sQLException.fillInStackTrace();
/* 12928 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRefTypeAtName(String paramString, REF paramREF) throws SQLException {
/* 12948 */     String str = paramString.intern();
/* 12949 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12950 */     boolean bool = false;
/* 12951 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12953 */     for (byte b = 0; b < i; b++) {
/* 12954 */       if (arrayOfString[b] == str) {
/*       */         
/* 12956 */         setRefType(b + 1, paramREF);
/*       */         
/* 12958 */         bool = true;
/*       */       } 
/*       */     } 
/* 12961 */     if (!bool) {
/*       */       
/* 12963 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 12964 */       sQLException.fillInStackTrace();
/* 12965 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setROWIDAtName(String paramString, ROWID paramROWID) throws SQLException {
/* 12985 */     String str = paramString.intern();
/* 12986 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 12987 */     boolean bool = false;
/* 12988 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 12990 */     for (byte b = 0; b < i; b++) {
/* 12991 */       if (arrayOfString[b] == str) {
/*       */         
/* 12993 */         setROWID(b + 1, paramROWID);
/*       */         
/* 12995 */         bool = true;
/*       */       } 
/*       */     } 
/* 12998 */     if (!bool) {
/*       */       
/* 13000 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13001 */       sQLException.fillInStackTrace();
/* 13002 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setSTRUCTAtName(String paramString, STRUCT paramSTRUCT) throws SQLException {
/* 13022 */     String str = paramString.intern();
/* 13023 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13024 */     boolean bool = false;
/* 13025 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13027 */     for (byte b = 0; b < i; b++) {
/* 13028 */       if (arrayOfString[b] == str) {
/*       */         
/* 13030 */         setSTRUCT(b + 1, paramSTRUCT);
/*       */         
/* 13032 */         bool = true;
/*       */       } 
/*       */     } 
/* 13035 */     if (!bool) {
/*       */       
/* 13037 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13038 */       sQLException.fillInStackTrace();
/* 13039 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPLTZAtName(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 13059 */     String str = paramString.intern();
/* 13060 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13061 */     boolean bool = false;
/* 13062 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13064 */     for (byte b = 0; b < i; b++) {
/* 13065 */       if (arrayOfString[b] == str) {
/*       */         
/* 13067 */         setTIMESTAMPLTZ(b + 1, paramTIMESTAMPLTZ);
/*       */         
/* 13069 */         bool = true;
/*       */       } 
/*       */     } 
/* 13072 */     if (!bool) {
/*       */       
/* 13074 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13075 */       sQLException.fillInStackTrace();
/* 13076 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPTZAtName(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 13096 */     String str = paramString.intern();
/* 13097 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13098 */     boolean bool = false;
/* 13099 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13101 */     for (byte b = 0; b < i; b++) {
/* 13102 */       if (arrayOfString[b] == str) {
/*       */         
/* 13104 */         setTIMESTAMPTZ(b + 1, paramTIMESTAMPTZ);
/*       */         
/* 13106 */         bool = true;
/*       */       } 
/*       */     } 
/* 13109 */     if (!bool) {
/*       */       
/* 13111 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13112 */       sQLException.fillInStackTrace();
/* 13113 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTIMESTAMPAtName(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 13133 */     String str = paramString.intern();
/* 13134 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13135 */     boolean bool = false;
/* 13136 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/*       */     
/* 13138 */     for (byte b = 0; b < i; b++) {
/* 13139 */       if (arrayOfString[b] == str) {
/*       */         
/* 13141 */         setTIMESTAMP(b + 1, paramTIMESTAMP);
/*       */         
/* 13143 */         bool = true;
/*       */       } 
/*       */     } 
/* 13146 */     if (!bool) {
/*       */       
/* 13148 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13149 */       sQLException.fillInStackTrace();
/* 13150 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 13172 */     String str = paramString.intern();
/* 13173 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13174 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13175 */     boolean bool = true;
/*       */     
/* 13177 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13179 */       if (arrayOfString[b] == str)
/*       */       {
/* 13181 */         if (bool) {
/*       */           
/* 13183 */           setAsciiStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 13185 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13190 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13191 */           sQLException.fillInStackTrace();
/* 13192 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13197 */     if (bool) {
/*       */       
/* 13199 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13200 */       sQLException.fillInStackTrace();
/* 13201 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 13221 */     String str = paramString.intern();
/* 13222 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13223 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13224 */     boolean bool = true;
/*       */     
/* 13226 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13228 */       if (arrayOfString[b] == str)
/*       */       {
/* 13230 */         if (bool) {
/*       */           
/* 13232 */           setBinaryStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 13234 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13239 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13240 */           sQLException.fillInStackTrace();
/* 13241 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13246 */     if (bool) {
/*       */       
/* 13248 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13249 */       sQLException.fillInStackTrace();
/* 13250 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCharacterStreamAtName(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 13270 */     String str = paramString.intern();
/* 13271 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13272 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13273 */     boolean bool = true;
/*       */     
/* 13275 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13277 */       if (arrayOfString[b] == str)
/*       */       {
/* 13279 */         if (bool) {
/*       */           
/* 13281 */           setCharacterStream(b + 1, paramReader, paramInt);
/*       */           
/* 13283 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13288 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13289 */           sQLException.fillInStackTrace();
/* 13290 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13295 */     if (bool) {
/*       */       
/* 13297 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13298 */       sQLException.fillInStackTrace();
/* 13299 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setUnicodeStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 13319 */     String str = paramString.intern();
/* 13320 */     String[] arrayOfString = this.sqlObject.getParameterList();
/* 13321 */     int i = Math.min(this.sqlObject.getParameterCount(), arrayOfString.length);
/* 13322 */     boolean bool = true;
/*       */     
/* 13324 */     for (byte b = 0; b < i; b++) {
/*       */       
/* 13326 */       if (arrayOfString[b] == str)
/*       */       {
/* 13328 */         if (bool) {
/*       */           
/* 13330 */           setUnicodeStream(b + 1, paramInputStream, paramInt);
/*       */           
/* 13332 */           bool = false;
/*       */         
/*       */         }
/*       */         else {
/*       */           
/* 13337 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 135);
/* 13338 */           sQLException.fillInStackTrace();
/* 13339 */           throw sQLException;
/*       */         } 
/*       */       }
/*       */     } 
/*       */     
/* 13344 */     if (bool) {
/*       */       
/* 13346 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 147, paramString);
/* 13347 */       sQLException.fillInStackTrace();
/* 13348 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/* 13357 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final boolean TRACE = false;
/*       */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/OraclePreparedStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */