/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleResultSet;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleResultSet
/*      */   implements OracleResultSet
/*      */ {
/*      */   static final boolean DEBUG = false;
/*      */   
/*      */   int getFirstUserColumnIndex() throws SQLException {
/*   87 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public abstract void closeStatementOnClose() throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract Array getArray(int paramInt) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract BigDecimal getBigDecimal(int paramInt) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract Blob getBlob(int paramInt) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract boolean getBoolean(int paramInt) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract byte getByte(int paramInt) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract byte[] getBytes(int paramInt) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract Clob getClob(int paramInt) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract Date getDate(int paramInt) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract Date getDate(int paramInt, Calendar paramCalendar) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract double getDouble(int paramInt) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract float getFloat(int paramInt) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract int getInt(int paramInt) throws SQLException;
/*      */ 
/*      */   
/*      */   public abstract long getLong(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract Object getObject(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract Object getObject(int paramInt, Map paramMap) throws SQLException;
/*      */   
/*      */   public abstract Ref getRef(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract short getShort(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract String getString(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract Time getTime(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract Time getTime(int paramInt, Calendar paramCalendar) throws SQLException;
/*      */   
/*      */   public abstract Timestamp getTimestamp(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException;
/*      */   
/*      */   public abstract URL getURL(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract ARRAY getARRAY(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract BFILE getBFILE(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract BFILE getBfile(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract BLOB getBLOB(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract CHAR getCHAR(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract CLOB getCLOB(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract ResultSet getCursor(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException;
/*      */   
/*      */   public abstract DATE getDATE(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract INTERVALDS getINTERVALDS(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract INTERVALYM getINTERVALYM(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract NUMBER getNUMBER(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract OPAQUE getOPAQUE(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract Datum getOracleObject(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException;
/*      */   
/*      */   public abstract Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException;
/*      */   
/*      */   public abstract RAW getRAW(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract REF getREF(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract ROWID getROWID(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract STRUCT getSTRUCT(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract InputStream getAsciiStream(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract InputStream getBinaryStream(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract Reader getCharacterStream(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract InputStream getUnicodeStream(int paramInt) throws SQLException;
/*      */   
/*      */   public abstract void updateArray(int paramInt, Array paramArray) throws SQLException;
/*      */   
/*      */   public abstract void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException;
/*      */   
/*      */   public abstract void updateBlob(int paramInt, Blob paramBlob) throws SQLException;
/*      */   
/*      */   public abstract void updateBoolean(int paramInt, boolean paramBoolean) throws SQLException;
/*      */   
/*      */   public abstract void updateByte(int paramInt, byte paramByte) throws SQLException;
/*      */   
/*      */   public abstract void updateBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException;
/*      */   
/*      */   public abstract void updateClob(int paramInt, Clob paramClob) throws SQLException;
/*      */   
/*      */   public abstract void updateDate(int paramInt, Date paramDate) throws SQLException;
/*      */   
/*      */   public abstract void updateDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException;
/*      */   
/*      */   public abstract void updateDouble(int paramInt, double paramDouble) throws SQLException;
/*      */   
/*      */   public abstract void updateFloat(int paramInt, float paramFloat) throws SQLException;
/*      */   
/*      */   public abstract void updateInt(int paramInt1, int paramInt2) throws SQLException;
/*      */   
/*      */   public abstract void updateLong(int paramInt, long paramLong) throws SQLException;
/*      */   
/*      */   public abstract void updateObject(int paramInt, Object paramObject) throws SQLException;
/*      */   
/*      */   public abstract void updateObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException;
/*      */   
/*      */   public abstract void updateRef(int paramInt, Ref paramRef) throws SQLException;
/*      */   
/*      */   public abstract void updateShort(int paramInt, short paramShort) throws SQLException;
/*      */   
/*      */   public abstract void updateString(int paramInt, String paramString) throws SQLException;
/*      */   
/*      */   public abstract void updateTime(int paramInt, Time paramTime) throws SQLException;
/*      */   
/*      */   public abstract void updateTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException;
/*      */   
/*      */   public abstract void updateTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException;
/*      */   
/*      */   public abstract void updateTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException;
/*      */   
/*      */   public abstract void updateURL(int paramInt, URL paramURL) throws SQLException;
/*      */   
/*      */   public abstract void updateARRAY(int paramInt, ARRAY paramARRAY) throws SQLException;
/*      */   
/*      */   public abstract void updateBFILE(int paramInt, BFILE paramBFILE) throws SQLException;
/*      */   
/*      */   public abstract void updateBfile(int paramInt, BFILE paramBFILE) throws SQLException;
/*      */   
/*      */   public abstract void updateBinaryFloat(int paramInt, float paramFloat) throws SQLException;
/*      */   
/*      */   public abstract void updateBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException;
/*      */   
/*      */   public abstract void updateBinaryDouble(int paramInt, double paramDouble) throws SQLException;
/*      */   
/*      */   public abstract void updateBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException;
/*      */   
/*      */   public abstract void updateBLOB(int paramInt, BLOB paramBLOB) throws SQLException;
/*      */   
/*      */   public abstract void updateCHAR(int paramInt, CHAR paramCHAR) throws SQLException;
/*      */   
/*      */   public abstract void updateCLOB(int paramInt, CLOB paramCLOB) throws SQLException;
/*      */   
/*      */   public abstract void updateCursor(int paramInt, ResultSet paramResultSet) throws SQLException;
/*      */   
/*      */   public abstract void updateCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException;
/*      */   
/*      */   public abstract void updateDATE(int paramInt, DATE paramDATE) throws SQLException;
/*      */   
/*      */   public abstract void updateFixedCHAR(int paramInt, String paramString) throws SQLException;
/*      */   
/*      */   public abstract void updateINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException;
/*      */   
/*      */   public abstract void updateINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException;
/*      */   
/*      */   public abstract void updateNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException;
/*      */   
/*      */   public abstract void updateOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException;
/*      */   
/*      */   public abstract void updateOracleObject(int paramInt, Datum paramDatum) throws SQLException;
/*      */   
/*      */   public abstract void updateORAData(int paramInt, ORAData paramORAData) throws SQLException;
/*      */   
/*      */   public abstract void updateRAW(int paramInt, RAW paramRAW) throws SQLException;
/*      */   
/*      */   public abstract void updateREF(int paramInt, REF paramREF) throws SQLException;
/*      */   
/*      */   public abstract void updateRefType(int paramInt, REF paramREF) throws SQLException;
/*      */   
/*      */   public abstract void updateROWID(int paramInt, ROWID paramROWID) throws SQLException;
/*      */   
/*      */   public abstract void updateSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException;
/*      */   
/*      */   public abstract void updateTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException;
/*      */   
/*      */   public abstract void updateTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException;
/*      */   
/*      */   public abstract void updateTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException;
/*      */   
/*      */   public abstract void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException;
/*      */   
/*      */   public abstract void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException;
/*      */   
/*      */   public abstract void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException;
/*      */   
/*      */   public abstract void updateUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException;
/*      */   
/*      */   public Array getArray(String paramString) throws SQLException {
/*  320 */     return getArray(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLException {
/*  326 */     return getBigDecimal(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/*  332 */     return getBigDecimal(findColumn(paramString), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(String paramString) throws SQLException {
/*  338 */     return getBlob(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) throws SQLException {
/*  344 */     return getBoolean(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) throws SQLException {
/*  350 */     return getByte(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String paramString) throws SQLException {
/*  356 */     return getBytes(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(String paramString) throws SQLException {
/*  362 */     return getClob(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) throws SQLException {
/*  368 */     return getDate(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
/*  374 */     return getDate(findColumn(paramString), paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) throws SQLException {
/*  380 */     return getDouble(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) throws SQLException {
/*  386 */     return getFloat(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String paramString) throws SQLException {
/*  392 */     return getInt(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) throws SQLException {
/*  398 */     return getLong(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString) throws SQLException {
/*  404 */     return getObject(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, Map paramMap) throws SQLException {
/*  410 */     return getObject(findColumn(paramString), paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(String paramString) throws SQLException {
/*  416 */     return getRef(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) throws SQLException {
/*  422 */     return getShort(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String paramString) throws SQLException {
/*  428 */     return getString(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString) throws SQLException {
/*  434 */     return getTime(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
/*  440 */     return getTime(findColumn(paramString), paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString) throws SQLException {
/*  446 */     return getTimestamp(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
/*  452 */     return getTimestamp(findColumn(paramString), paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String paramString) throws SQLException {
/*  458 */     return getURL(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(String paramString) throws SQLException {
/*  464 */     return getARRAY(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(String paramString) throws SQLException {
/*  470 */     return getBFILE(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(String paramString) throws SQLException {
/*  476 */     return getBfile(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(String paramString) throws SQLException {
/*  482 */     return getBLOB(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(String paramString) throws SQLException {
/*  488 */     return getCHAR(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(String paramString) throws SQLException {
/*  494 */     return getCLOB(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(String paramString) throws SQLException {
/*  500 */     return getCursor(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(String paramString, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/*  506 */     return getCustomDatum(findColumn(paramString), paramCustomDatumFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(String paramString) throws SQLException {
/*  512 */     return getDATE(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(String paramString) throws SQLException {
/*  518 */     return getINTERVALDS(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(String paramString) throws SQLException {
/*  524 */     return getINTERVALYM(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(String paramString) throws SQLException {
/*  530 */     return getNUMBER(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(String paramString) throws SQLException {
/*  536 */     return getOPAQUE(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(String paramString) throws SQLException {
/*  542 */     return getOracleObject(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(String paramString, ORADataFactory paramORADataFactory) throws SQLException {
/*  548 */     return getORAData(findColumn(paramString), paramORADataFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, OracleDataFactory paramOracleDataFactory) throws SQLException {
/*  554 */     return getObject(findColumn(paramString), paramOracleDataFactory);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(String paramString) throws SQLException {
/*  560 */     return getRAW(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(String paramString) throws SQLException {
/*  566 */     return getREF(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(String paramString) throws SQLException {
/*  572 */     return getROWID(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(String paramString) throws SQLException {
/*  578 */     return getSTRUCT(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(String paramString) throws SQLException {
/*  584 */     return getTIMESTAMPLTZ(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(String paramString) throws SQLException {
/*  590 */     return getTIMESTAMPTZ(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(String paramString) throws SQLException {
/*  596 */     return getTIMESTAMP(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String paramString) throws SQLException {
/*  602 */     return getAsciiStream(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String paramString) throws SQLException {
/*  608 */     return getBinaryStream(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String paramString) throws SQLException {
/*  614 */     return getCharacterStream(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(String paramString) throws SQLException {
/*  620 */     return getUnicodeStream(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateArray(String paramString, Array paramArray) throws SQLException {
/*  627 */     updateArray(findColumn(paramString), paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/*  633 */     updateBigDecimal(findColumn(paramString), paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(String paramString, Blob paramBlob) throws SQLException {
/*  639 */     updateBlob(findColumn(paramString), paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBoolean(String paramString, boolean paramBoolean) throws SQLException {
/*  645 */     updateBoolean(findColumn(paramString), paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateByte(String paramString, byte paramByte) throws SQLException {
/*  651 */     updateByte(findColumn(paramString), paramByte);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  657 */     updateBytes(findColumn(paramString), paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(String paramString, Clob paramClob) throws SQLException {
/*  663 */     updateClob(findColumn(paramString), paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(String paramString, Date paramDate) throws SQLException {
/*  669 */     updateDate(findColumn(paramString), paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  675 */     updateDate(findColumn(paramString), paramDate, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDouble(String paramString, double paramDouble) throws SQLException {
/*  681 */     updateDouble(findColumn(paramString), paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFloat(String paramString, float paramFloat) throws SQLException {
/*  687 */     updateFloat(findColumn(paramString), paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateInt(String paramString, int paramInt) throws SQLException {
/*  693 */     updateInt(findColumn(paramString), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateLong(String paramString, long paramLong) throws SQLException {
/*  699 */     updateLong(findColumn(paramString), paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String paramString, Object paramObject) throws SQLException {
/*  705 */     updateObject(findColumn(paramString), paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String paramString, Object paramObject, int paramInt) throws SQLException {
/*  711 */     updateObject(findColumn(paramString), paramObject, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRef(String paramString, Ref paramRef) throws SQLException {
/*  717 */     updateRef(findColumn(paramString), paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateShort(String paramString, short paramShort) throws SQLException {
/*  723 */     updateShort(findColumn(paramString), paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateString(String paramString1, String paramString2) throws SQLException {
/*  729 */     updateString(findColumn(paramString1), paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(String paramString, Time paramTime) throws SQLException {
/*  735 */     updateTime(findColumn(paramString), paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  741 */     updateTime(findColumn(paramString), paramTime, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
/*  747 */     updateTimestamp(findColumn(paramString), paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  753 */     updateTimestamp(findColumn(paramString), paramTimestamp, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateURL(String paramString, URL paramURL) throws SQLException {
/*  759 */     updateURL(findColumn(paramString), paramURL);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateARRAY(String paramString, ARRAY paramARRAY) throws SQLException {
/*  765 */     updateARRAY(findColumn(paramString), paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBFILE(String paramString, BFILE paramBFILE) throws SQLException {
/*  771 */     updateBFILE(findColumn(paramString), paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBfile(String paramString, BFILE paramBFILE) throws SQLException {
/*  777 */     updateBfile(findColumn(paramString), paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryFloat(String paramString, float paramFloat) throws SQLException {
/*  783 */     updateBinaryFloat(findColumn(paramString), paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/*  789 */     updateBinaryFloat(findColumn(paramString), paramBINARY_FLOAT);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryDouble(String paramString, double paramDouble) throws SQLException {
/*  795 */     updateBinaryDouble(findColumn(paramString), paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/*  801 */     updateBinaryDouble(findColumn(paramString), paramBINARY_DOUBLE);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBLOB(String paramString, BLOB paramBLOB) throws SQLException {
/*  807 */     updateBLOB(findColumn(paramString), paramBLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCHAR(String paramString, CHAR paramCHAR) throws SQLException {
/*  813 */     updateCHAR(findColumn(paramString), paramCHAR);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCLOB(String paramString, CLOB paramCLOB) throws SQLException {
/*  819 */     updateCLOB(findColumn(paramString), paramCLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCursor(String paramString, ResultSet paramResultSet) throws SQLException {
/*  825 */     updateCursor(findColumn(paramString), paramResultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCustomDatum(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/*  831 */     updateCustomDatum(findColumn(paramString), paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDATE(String paramString, DATE paramDATE) throws SQLException {
/*  837 */     updateDATE(findColumn(paramString), paramDATE);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFixedCHAR(String paramString1, String paramString2) throws SQLException {
/*  843 */     updateFixedCHAR(findColumn(paramString1), paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateINTERVALDS(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/*  849 */     updateINTERVALDS(findColumn(paramString), paramINTERVALDS);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateINTERVALYM(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/*  855 */     updateINTERVALYM(findColumn(paramString), paramINTERVALYM);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNUMBER(String paramString, NUMBER paramNUMBER) throws SQLException {
/*  861 */     updateNUMBER(findColumn(paramString), paramNUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateOPAQUE(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/*  867 */     updateOPAQUE(findColumn(paramString), paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateOracleObject(String paramString, Datum paramDatum) throws SQLException {
/*  873 */     updateOracleObject(findColumn(paramString), paramDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateORAData(String paramString, ORAData paramORAData) throws SQLException {
/*  879 */     updateORAData(findColumn(paramString), paramORAData);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRAW(String paramString, RAW paramRAW) throws SQLException {
/*  885 */     updateRAW(findColumn(paramString), paramRAW);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateREF(String paramString, REF paramREF) throws SQLException {
/*  891 */     updateREF(findColumn(paramString), paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRefType(String paramString, REF paramREF) throws SQLException {
/*  897 */     updateRefType(findColumn(paramString), paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateROWID(String paramString, ROWID paramROWID) throws SQLException {
/*  903 */     updateROWID(findColumn(paramString), paramROWID);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateSTRUCT(String paramString, STRUCT paramSTRUCT) throws SQLException {
/*  909 */     updateSTRUCT(findColumn(paramString), paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/*  915 */     updateTIMESTAMPLTZ(findColumn(paramString), paramTIMESTAMPLTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/*  921 */     updateTIMESTAMPTZ(findColumn(paramString), paramTIMESTAMPTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/*  927 */     updateTIMESTAMP(findColumn(paramString), paramTIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  933 */     updateAsciiStream(findColumn(paramString), paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  939 */     updateBinaryStream(findColumn(paramString), paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
/*  945 */     updateCharacterStream(findColumn(paramString), paramReader, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  951 */     updateUnicodeStream(findColumn(paramString), paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract oracle.jdbc.OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public oracle.jdbc.OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(String paramString) throws SQLException {
/*  965 */     return getAuthorizationIndicator(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void setAutoRefetch(boolean paramBoolean) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean getAutoRefetch() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract SQLWarning getWarnings() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void clearWarnings() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract String getCursorName() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract ResultSetMetaData getMetaData() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int findColumn(String paramString) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean next() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void close() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean wasNull() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isBeforeFirst() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isAfterLast() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isFirst() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean isLast() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void beforeFirst() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void afterLast() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean first() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean last() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getRow() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean absolute(int paramInt) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean relative(int paramInt) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean previous() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void setFetchDirection(int paramInt) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getFetchDirection() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void setFetchSize(int paramInt) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getFetchSize() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getType() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract int getConcurrency() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void insertRow() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void updateRow() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void deleteRow() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void refreshRow() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void moveToInsertRow() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void cancelRowUpdates() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void moveToCurrentRow() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract Statement getStatement() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean rowUpdated() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean rowInserted() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract boolean rowDeleted() throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public abstract void updateNull(int paramInt) throws SQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(String paramString) throws SQLException {
/* 1492 */     updateNull(findColumn(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1510 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1521 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */   abstract OracleStatement getOracleStatement() throws SQLException;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/OracleResultSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */