/*      */ package oracle.jdbc.rowset;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.CharArrayReader;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.PipedInputStream;
/*      */ import java.io.PipedOutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Serializable;
/*      */ import java.io.StringBufferInputStream;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.Driver;
/*      */ import java.sql.DriverManager;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.Date;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.TimeZone;
/*      */ import java.util.TreeMap;
/*      */ import java.util.Vector;
/*      */ import javax.naming.InitialContext;
/*      */ import javax.naming.NamingException;
/*      */ import javax.sql.DataSource;
/*      */ import javax.sql.RowSet;
/*      */ import javax.sql.RowSetEvent;
/*      */ import javax.sql.RowSetInternal;
/*      */ import javax.sql.RowSetMetaData;
/*      */ import javax.sql.RowSetReader;
/*      */ import javax.sql.RowSetWriter;
/*      */ import javax.sql.rowset.CachedRowSet;
/*      */ import javax.sql.rowset.RowSetWarning;
/*      */ import javax.sql.rowset.spi.SyncFactory;
/*      */ import javax.sql.rowset.spi.SyncFactoryException;
/*      */ import javax.sql.rowset.spi.SyncProvider;
/*      */ import javax.sql.rowset.spi.SyncProviderException;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.OracleSavepoint;
/*      */ import oracle.jdbc.driver.DBConversion;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.driver.OracleDriver;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleCachedRowSet
/*      */   extends OracleRowSet
/*      */   implements RowSet, RowSetInternal, Serializable, Cloneable, CachedRowSet
/*      */ {
/*      */   static final long serialVersionUID = -2066958142885801470L;
/*      */   private SQLWarning sqlWarning;
/*      */   private RowSetWarning rowsetWarning;
/*      */   protected int presentRow;
/*      */   private int currentPage;
/*      */   private boolean isPopulateDone;
/*      */   private boolean previousColumnWasNull;
/*      */   private OracleRow insertRow;
/*      */   private int insertRowPosition;
/*      */   private boolean insertRowFlag;
/*      */   private int updateRowPosition;
/*      */   private boolean updateRowFlag;
/*      */   protected ResultSetMetaData rowsetMetaData;
/*      */   private transient ResultSet resultSet;
/*      */   private transient Connection connection;
/*      */   private transient boolean isConnectionStayingOpenForTxnControl = false;
/*  317 */   private transient OracleSqlForRowSet osql = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Vector rows;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Vector param;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] metaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int colCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int rowCount;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RowSetReader reader;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private RowSetWriter writer;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int[] keyColumns;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int pageSize;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SyncProvider syncProvider;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final String DEFAULT_SYNCPROVIDER = "com.sun.rowset.providers.RIOptimisticProvider";
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String tableName;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean executeCalled = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean driverManagerInitialized = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MAX_CHAR_BUFFER_SIZE = 1024;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final int MAX_BYTE_BUFFER_SIZE = 1024;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleCachedRowSet() throws SQLException {
/*  427 */     this.insertRowFlag = false;
/*  428 */     this.updateRowFlag = false;
/*      */     
/*  430 */     this.presentRow = 0;
/*  431 */     this.previousColumnWasNull = false;
/*      */     
/*  433 */     this.param = new Vector();
/*      */     
/*  435 */     this.rows = new Vector();
/*      */     
/*  437 */     this.sqlWarning = new SQLWarning();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  443 */       this.syncProvider = SyncFactory.getInstance("com.sun.rowset.providers.RIOptimisticProvider");
/*      */ 
/*      */     
/*      */     }
/*  447 */     catch (SyncFactoryException syncFactoryException) {
/*      */ 
/*      */ 
/*      */       
/*  451 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 304);
/*  452 */       sQLException.fillInStackTrace();
/*  453 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  458 */     setReader(new OracleCachedRowSetReader());
/*  459 */     setWriter(new OracleCachedRowSetWriter());
/*      */     
/*  461 */     this.currentPage = 0;
/*  462 */     this.pageSize = 0;
/*  463 */     this.isPopulateDone = false;
/*      */     
/*  465 */     this.keyColumns = null;
/*  466 */     this.tableName = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection() throws SQLException {
/*  481 */     return getConnectionInternal();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Connection getConnectionInternal() throws SQLException {
/*  490 */     if (this.connection == null || this.connection.isClosed()) {
/*      */       
/*  492 */       String str1 = getUsername();
/*  493 */       String str2 = getPassword();
/*  494 */       if (getDataSourceName() != null) {
/*      */ 
/*      */         
/*      */         try {
/*  498 */           InitialContext initialContext = null;
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           try {
/*  504 */             Properties properties = System.getProperties();
/*  505 */             initialContext = new InitialContext(properties);
/*      */           }
/*  507 */           catch (SecurityException securityException) {}
/*      */ 
/*      */           
/*  510 */           if (initialContext == null)
/*  511 */             initialContext = new InitialContext(); 
/*  512 */           DataSource dataSource = (DataSource)initialContext.lookup(getDataSourceName());
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  517 */           if (this.username == null || str2 == null) {
/*  518 */             this.connection = dataSource.getConnection();
/*      */           } else {
/*  520 */             this.connection = dataSource.getConnection(this.username, str2);
/*      */           } 
/*  522 */         } catch (NamingException namingException) {
/*      */ 
/*      */           
/*  525 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 300, namingException.getMessage());
/*  526 */           sQLException.fillInStackTrace();
/*  527 */           throw sQLException;
/*      */         }
/*      */       
/*      */       }
/*  531 */       else if (getUrl() != null) {
/*      */         
/*  533 */         if (!this.driverManagerInitialized) {
/*      */           
/*  535 */           DriverManager.registerDriver((Driver)new OracleDriver());
/*  536 */           this.driverManagerInitialized = true;
/*      */         } 
/*  538 */         String str = getUrl();
/*      */ 
/*      */ 
/*      */         
/*  542 */         if (str.equals("") || str1.equals("") || str2.equals("")) {
/*      */ 
/*      */           
/*  545 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 301);
/*  546 */           sQLException.fillInStackTrace();
/*  547 */           throw sQLException;
/*      */         } 
/*      */         
/*  550 */         this.connection = DriverManager.getConnection(str, str1, str2);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  555 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 301);
/*  556 */         sQLException.fillInStackTrace();
/*  557 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  562 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLException {
/*  573 */     if (this.resultSet == null) {
/*      */ 
/*      */ 
/*      */       
/*  577 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 305);
/*  578 */       sQLException.fillInStackTrace();
/*  579 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  583 */     return this.resultSet.getStatement();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowSetReader getReader() {
/*  591 */     return this.reader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowSetWriter getWriter() {
/*  599 */     return this.writer;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {
/*      */     SQLException sQLException;
/*  632 */     if (this.rowsetType == 1005) {
/*      */       
/*  634 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 306);
/*  635 */       sQLException1.fillInStackTrace();
/*  636 */       throw sQLException1;
/*      */     } 
/*      */     
/*  639 */     switch (paramInt) {
/*      */       
/*      */       case 1000:
/*      */       case 1002:
/*  643 */         this.presentRow = 0;
/*      */         break;
/*      */       case 1001:
/*  646 */         if (this.rowsetType == 1003) {
/*      */           
/*  648 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 307);
/*  649 */           sQLException1.fillInStackTrace();
/*  650 */           throw sQLException1;
/*      */         } 
/*  652 */         this.presentRow = this.rowCount + 1;
/*      */         break;
/*      */       
/*      */       default:
/*  656 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 308);
/*  657 */         sQLException.fillInStackTrace();
/*  658 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  663 */     super.setFetchDirection(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCommand(String paramString) throws SQLException {
/*  673 */     super.setCommand(paramString);
/*  674 */     if (paramString == null || paramString.equals("")) {
/*  675 */       this.osql = null;
/*      */     } else {
/*  677 */       this.osql = new OracleSqlForRowSet(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setReader(RowSetReader paramRowSetReader) {
/*  686 */     this.reader = paramRowSetReader;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setWriter(RowSetWriter paramRowSetWriter) {
/*  695 */     this.writer = paramRowSetWriter;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final int getColumnIndex(String paramString) throws SQLException {
/*  718 */     if (paramString == null || paramString.equals("")) {
/*      */       
/*  720 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6, paramString);
/*  721 */       sQLException.fillInStackTrace();
/*  722 */       throw sQLException;
/*      */     } 
/*      */     
/*  725 */     paramString = paramString.toUpperCase();
/*  726 */     byte b = 0;
/*  727 */     for (; b < this.metaData.length; b++) {
/*      */       
/*  729 */       if (paramString.equals(this.metaData[b])) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  735 */     if (b >= this.metaData.length) {
/*      */       
/*  737 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6, paramString);
/*  738 */       sQLException.fillInStackTrace();
/*  739 */       throw sQLException;
/*      */     } 
/*      */     
/*  742 */     return b + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void checkColumnIndex(int paramInt) throws SQLException {
/*  757 */     if (this.readOnly) {
/*      */       
/*  759 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/*  760 */       sQLException.fillInStackTrace();
/*  761 */       throw sQLException;
/*      */     } 
/*  763 */     if (paramInt < 1 || paramInt > this.colCount) {
/*      */       
/*  765 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "" + paramInt);
/*  766 */       sQLException.fillInStackTrace();
/*  767 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final boolean isUpdated(int paramInt) throws SQLException {
/*  786 */     if (paramInt < 1 || paramInt > this.colCount) {
/*      */       
/*  788 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "" + paramInt);
/*  789 */       sQLException.fillInStackTrace();
/*  790 */       throw sQLException;
/*      */     } 
/*      */     
/*  793 */     return getCurrentRow().isColumnChanged(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void checkParamIndex(int paramInt) throws SQLException {
/*  807 */     if (paramInt < 1) {
/*      */       
/*  809 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 310, "" + paramInt);
/*  810 */       sQLException.fillInStackTrace();
/*  811 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void populateInit(ResultSet paramResultSet) throws SQLException {
/*  828 */     this.resultSet = paramResultSet;
/*  829 */     Statement statement = paramResultSet.getStatement();
/*      */ 
/*      */ 
/*      */     
/*  833 */     this.maxFieldSize = statement.getMaxFieldSize();
/*      */ 
/*      */     
/*  836 */     this.fetchSize = statement.getFetchSize();
/*  837 */     this.queryTimeout = statement.getQueryTimeout();
/*      */     
/*  839 */     this.connection = statement.getConnection();
/*      */ 
/*      */ 
/*      */     
/*  843 */     this.transactionIsolation = this.connection.getTransactionIsolation();
/*      */ 
/*      */ 
/*      */     
/*  847 */     this.typeMap = this.connection.getTypeMap();
/*  848 */     DatabaseMetaData databaseMetaData = this.connection.getMetaData();
/*      */ 
/*      */ 
/*      */     
/*  852 */     this.url = databaseMetaData.getURL();
/*  853 */     this.username = databaseMetaData.getUserName();
/*      */ 
/*      */ 
/*      */     
/*  857 */     this.presentRow = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized InputStream getStream(int paramInt) throws SQLException {
/*  874 */     Object object = getObject(paramInt);
/*      */ 
/*      */ 
/*      */     
/*  878 */     if (object == null) {
/*  879 */       return null;
/*      */     }
/*  881 */     if (object instanceof InputStream) {
/*  882 */       return (InputStream)object;
/*      */     }
/*  884 */     if (object instanceof String)
/*      */     {
/*  886 */       return new ByteArrayInputStream(((String)object).getBytes());
/*      */     }
/*  888 */     if (object instanceof byte[])
/*      */     {
/*  890 */       return new ByteArrayInputStream((byte[])object);
/*      */     }
/*  892 */     if (object instanceof OracleSerialClob)
/*  893 */       return ((OracleSerialClob)object).getAsciiStream(); 
/*  894 */     if (object instanceof OracleSerialBlob)
/*  895 */       return ((OracleSerialBlob)object).getBinaryStream(); 
/*  896 */     if (object instanceof Reader) {
/*      */       
/*  898 */       BufferedReader bufferedReader = null;
/*  899 */       PipedOutputStream pipedOutputStream = null;
/*      */       
/*      */       try {
/*  902 */         bufferedReader = new BufferedReader((Reader)object);
/*  903 */         int i = 0;
/*  904 */         PipedInputStream pipedInputStream = new PipedInputStream();
/*  905 */         pipedOutputStream = new PipedOutputStream(pipedInputStream);
/*  906 */         while ((i = bufferedReader.read()) != -1)
/*  907 */           pipedOutputStream.write(i); 
/*  908 */         return pipedInputStream;
/*      */       }
/*  910 */       catch (IOException iOException) {
/*      */ 
/*      */         
/*  913 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 311, iOException.getMessage());
/*  914 */         sQLException1.fillInStackTrace();
/*  915 */         throw sQLException1;
/*      */       } finally {
/*      */ 
/*      */         
/*      */         try {
/*  920 */           if (bufferedReader != null)
/*  921 */             bufferedReader.close(); 
/*  922 */         } catch (IOException iOException) {
/*      */ 
/*      */           
/*  925 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 311, iOException.getMessage());
/*  926 */           sQLException1.fillInStackTrace();
/*  927 */           throw sQLException1;
/*      */         } 
/*      */         
/*      */         try {
/*  931 */           if (pipedOutputStream != null)
/*  932 */             pipedOutputStream.close(); 
/*  933 */         } catch (IOException iOException) {
/*      */ 
/*      */           
/*  936 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 311, iOException.getMessage());
/*  937 */           sQLException1.fillInStackTrace();
/*  938 */           throw sQLException1;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  945 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 312);
/*  946 */     sQLException.fillInStackTrace();
/*  947 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private final Calendar getSessionCalendar(Connection paramConnection) {
/*      */     Calendar calendar;
/*  954 */     String str = ((OracleConnection)paramConnection).getSessionTimeZone();
/*      */ 
/*      */     
/*  957 */     if (str == null) {
/*  958 */       calendar = Calendar.getInstance();
/*      */     } else {
/*      */       
/*  961 */       TimeZone timeZone = TimeZone.getDefault();
/*  962 */       timeZone.setID(str);
/*  963 */       calendar = Calendar.getInstance(timeZone);
/*      */     } 
/*      */     
/*  966 */     return calendar;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isStreamType(int paramInt) {
/*  972 */     return (paramInt == 2004 || paramInt == 2005 || paramInt == -4 || paramInt == -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void notifyCursorMoved() {
/* 1002 */     if (this.insertRowFlag) {
/*      */       
/* 1004 */       this.insertRowFlag = false;
/* 1005 */       this.insertRow.setRowUpdated(false);
/* 1006 */       this.sqlWarning.setNextWarning(new SQLWarning("Cancelling insertion, due to cursor movement."));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1014 */     else if (this.updateRowFlag) {
/*      */ 
/*      */       
/*      */       try {
/* 1018 */         this.updateRowFlag = false;
/* 1019 */         int i = this.presentRow;
/* 1020 */         this.presentRow = this.updateRowPosition;
/* 1021 */         getCurrentRow().setRowUpdated(false);
/* 1022 */         this.presentRow = i;
/* 1023 */         this.sqlWarning.setNextWarning(new SQLWarning("Cancelling all updates, due to cursor movement."));
/*      */       
/*      */       }
/* 1026 */       catch (SQLException sQLException) {}
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1033 */     super.notifyCursorMoved();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void checkAndFilterObject(int paramInt, Object paramObject) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleRow getCurrentRow() throws SQLException {
/* 1063 */     int i = this.presentRow - 1;
/*      */ 
/*      */ 
/*      */     
/* 1067 */     if (this.presentRow < 1 || this.presentRow > this.rowCount) {
/*      */       
/* 1069 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 313);
/* 1070 */       sQLException.fillInStackTrace();
/* 1071 */       throw sQLException;
/*      */     } 
/*      */     
/* 1074 */     return this.rows.elementAt(this.presentRow - 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isExecuteCalled() {
/* 1084 */     return this.executeCalled;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getCurrentPage() {
/* 1093 */     return this.currentPage;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isConnectionStayingOpen() {
/* 1102 */     return this.isConnectionStayingOpenForTxnControl;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setOriginal() throws SQLException {
/* 1114 */     byte b = 1;
/*      */ 
/*      */     
/*      */     do {
/* 1118 */       boolean bool = setOriginalRowInternal(b);
/*      */       
/* 1120 */       if (bool)
/*      */         continue; 
/* 1122 */       b++;
/*      */     
/*      */     }
/* 1125 */     while (b <= this.rowCount);
/*      */     
/* 1127 */     notifyRowSetChanged();
/*      */ 
/*      */ 
/*      */     
/* 1131 */     this.presentRow = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean setOriginalRowInternal(int paramInt) throws SQLException {
/* 1144 */     if (paramInt < 1 || paramInt > this.rowCount) {
/*      */       
/* 1146 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 313);
/* 1147 */       sQLException.fillInStackTrace();
/* 1148 */       throw sQLException;
/*      */     } 
/*      */     
/* 1151 */     boolean bool = false;
/*      */     
/* 1153 */     OracleRow oracleRow = this.rows.elementAt(paramInt - 1);
/*      */     
/* 1155 */     if (oracleRow.isRowDeleted()) {
/*      */       
/* 1157 */       this.rows.remove(paramInt - 1);
/* 1158 */       this.rowCount--;
/* 1159 */       bool = true;
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1164 */       if (oracleRow.isRowInserted())
/*      */       {
/* 1166 */         oracleRow.setInsertedFlag(false);
/*      */       }
/*      */       
/* 1169 */       if (oracleRow.isRowUpdated())
/*      */       {
/* 1171 */         oracleRow.makeUpdatesOriginal();
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1178 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLException {
/* 1220 */     if (this.rowCount < 0)
/*      */     {
/* 1222 */       return false;
/*      */     }
/*      */     
/* 1225 */     if (this.fetchDirection == 1000 || this.fetchDirection == 1002) {
/*      */       
/* 1227 */       if (this.presentRow + 1 <= this.rowCount) {
/*      */         
/* 1229 */         this.presentRow++;
/* 1230 */         if (!this.showDeleted && getCurrentRow().isRowDeleted()) {
/* 1231 */           return next();
/*      */         }
/* 1233 */         notifyCursorMoved();
/* 1234 */         return true;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1241 */       this.presentRow = this.rowCount + 1;
/* 1242 */       return false;
/*      */     } 
/*      */     
/* 1245 */     if (this.fetchDirection == 1001) {
/*      */       
/* 1247 */       if (this.presentRow - 1 > 0) {
/*      */         
/* 1249 */         this.presentRow--;
/* 1250 */         if (!this.showDeleted && getCurrentRow().isRowDeleted()) {
/* 1251 */           return next();
/*      */         }
/* 1253 */         notifyCursorMoved();
/* 1254 */         return true;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1261 */       this.presentRow = 0;
/* 1262 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1268 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previous() throws SQLException {
/* 1283 */     if (this.rowCount < 0)
/*      */     {
/* 1285 */       return false;
/*      */     }
/*      */     
/* 1288 */     if (this.fetchDirection == 1001) {
/*      */       
/* 1290 */       if (this.presentRow + 1 <= this.rowCount) {
/*      */         
/* 1292 */         this.presentRow++;
/* 1293 */         if (!this.showDeleted && getCurrentRow().isRowDeleted()) {
/* 1294 */           return previous();
/*      */         }
/* 1296 */         notifyCursorMoved();
/* 1297 */         return true;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1304 */       this.presentRow = this.rowCount + 1;
/* 1305 */       return false;
/*      */     } 
/*      */ 
/*      */     
/* 1309 */     if (this.fetchDirection == 1000 || this.fetchDirection == 1002) {
/*      */       
/* 1311 */       if (this.presentRow - 1 > 0) {
/*      */         
/* 1313 */         this.presentRow--;
/* 1314 */         if (!this.showDeleted && getCurrentRow().isRowDeleted()) {
/* 1315 */           return previous();
/*      */         }
/* 1317 */         notifyCursorMoved();
/* 1318 */         return true;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1325 */       this.presentRow = 0;
/* 1326 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1332 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/* 1344 */     return (this.rowCount > 0 && this.presentRow == 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/* 1355 */     return (this.rowCount > 0 && this.presentRow == this.rowCount + 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/* 1364 */     return (this.presentRow == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/* 1375 */     return (this.presentRow == this.rowCount);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void beforeFirst() throws SQLException {
/* 1383 */     this.presentRow = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void afterLast() throws SQLException {
/* 1392 */     this.presentRow = this.rowCount + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean first() throws SQLException {
/* 1403 */     return absolute(1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean last() throws SQLException {
/* 1412 */     return absolute(-1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean absolute(int paramInt) throws SQLException {
/* 1429 */     if (this.rowsetType == 1003) {
/*      */       
/* 1431 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 314);
/* 1432 */       sQLException.fillInStackTrace();
/* 1433 */       throw sQLException;
/*      */     } 
/* 1435 */     if (paramInt == 0 || Math.abs(paramInt) > this.rowCount)
/* 1436 */       return false; 
/* 1437 */     this.presentRow = (paramInt < 0) ? (this.rowCount + paramInt + 1) : paramInt;
/* 1438 */     notifyCursorMoved();
/*      */     
/* 1440 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean relative(int paramInt) throws SQLException {
/* 1453 */     return absolute(this.presentRow + paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void populate(ResultSet paramResultSet) throws SQLException {
/*      */     int i;
/* 1490 */     if (this.rows == null) {
/*      */ 
/*      */       
/* 1493 */       this.rows = new Vector(50, 10);
/*      */     } else {
/*      */       
/* 1496 */       this.rows.clear();
/* 1497 */     }  this.rowsetMetaData = new OracleRowSetMetaData(paramResultSet.getMetaData());
/* 1498 */     this.metaData = new String[this.colCount = this.rowsetMetaData.getColumnCount()]; byte b;
/* 1499 */     for (b = 0; b < this.colCount; b++) {
/* 1500 */       this.metaData[b] = this.rowsetMetaData.getColumnName(b + 1);
/*      */     }
/*      */ 
/*      */     
/* 1504 */     if (!(paramResultSet instanceof OracleCachedRowSet)) {
/* 1505 */       populateInit(paramResultSet);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1515 */     b = (this.fetchDirection == 1000 || this.fetchDirection == 1002) ? 1 : 0;
/*      */ 
/*      */     
/* 1518 */     this.rowCount = 0;
/* 1519 */     OracleRow oracleRow = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1525 */     if (this.maxRows == 0 && this.pageSize == 0) {
/*      */       
/* 1527 */       i = Integer.MAX_VALUE;
/*      */     }
/* 1529 */     else if (this.maxRows == 0 || this.pageSize == 0) {
/*      */       
/* 1531 */       i = Math.max(this.maxRows, this.pageSize);
/*      */     }
/*      */     else {
/*      */       
/* 1535 */       i = Math.min(this.maxRows, this.pageSize);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1545 */     if (paramResultSet.getType() != 1003 && this.rows.size() == 0)
/*      */     {
/* 1547 */       if (b == 0)
/*      */       {
/* 1549 */         paramResultSet.afterLast();
/*      */       }
/*      */     }
/*      */     
/* 1553 */     boolean bool = false;
/*      */     
/* 1555 */     while (this.rowCount < i) {
/*      */       
/* 1557 */       if (b != 0) {
/*      */         
/* 1559 */         if (!paramResultSet.next()) {
/*      */           
/* 1561 */           bool = true;
/*      */ 
/*      */ 
/*      */           
/*      */           break;
/*      */         } 
/* 1567 */       } else if (!paramResultSet.previous()) {
/*      */         
/* 1569 */         bool = true;
/*      */         
/*      */         break;
/*      */       } 
/*      */       
/* 1574 */       oracleRow = new OracleRow(this.colCount);
/* 1575 */       for (byte b1 = 1; b1 <= this.colCount; b1++) {
/*      */         
/* 1577 */         Object object = null;
/*      */         
/*      */         try {
/* 1580 */           object = paramResultSet.getObject(b1, this.typeMap);
/*      */         }
/* 1582 */         catch (Exception exception) {
/*      */           
/* 1584 */           object = paramResultSet.getObject(b1);
/*      */         }
/* 1586 */         catch (AbstractMethodError abstractMethodError) {
/*      */           
/* 1588 */           object = paramResultSet.getObject(b1);
/*      */         } 
/*      */ 
/*      */         
/* 1592 */         if (object instanceof Clob || object instanceof oracle.sql.CLOB) {
/* 1593 */           oracleRow.setColumnValue(b1, new OracleSerialClob((Clob)object));
/*      */         }
/* 1595 */         else if (object instanceof Blob || object instanceof oracle.sql.BLOB) {
/* 1596 */           oracleRow.setColumnValue(b1, new OracleSerialBlob((Blob)object));
/*      */         } else {
/*      */           
/* 1599 */           oracleRow.setColumnValue(b1, object);
/*      */         } 
/* 1601 */         oracleRow.markOriginalNull(b1, paramResultSet.wasNull());
/*      */       } 
/*      */       
/* 1604 */       if (b != 0) {
/*      */         
/* 1606 */         this.rows.add(oracleRow);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1611 */         this.rows.add(1, oracleRow);
/*      */       } 
/*      */       
/* 1614 */       this.rowCount++;
/*      */     } 
/*      */     
/* 1617 */     if (bool || (b != 0 && paramResultSet.isAfterLast()) || (b == 0 && paramResultSet.isBeforeFirst()))
/*      */     {
/*      */ 
/*      */       
/* 1621 */       this.isPopulateDone = true;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1628 */     this.connection = null;
/*      */     
/* 1630 */     notifyRowSetChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/* 1641 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 1642 */     sQLException.fillInStackTrace();
/* 1643 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void clearParameters() throws SQLException {
/* 1653 */     this.param = null;
/* 1654 */     this.param = new Vector();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/* 1663 */     return this.previousColumnWasNull;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/* 1676 */     release();
/*      */     
/* 1678 */     this.isClosed = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/* 1688 */     return this.sqlWarning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/* 1697 */     this.sqlWarning = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 1707 */     return this.rowsetMetaData;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLException {
/* 1716 */     return getColumnIndex(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object[] getParams() throws SQLException {
/* 1725 */     return this.param.toArray();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMetaData(RowSetMetaData paramRowSetMetaData) throws SQLException {
/* 1734 */     this.rowsetMetaData = paramRowSetMetaData;
/*      */ 
/*      */ 
/*      */     
/* 1738 */     if (paramRowSetMetaData != null)
/*      */     {
/* 1740 */       this.colCount = paramRowSetMetaData.getColumnCount();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void execute() throws SQLException {
/* 1752 */     this.isConnectionStayingOpenForTxnControl = false;
/* 1753 */     getReader().readData(this);
/*      */     
/* 1755 */     this.executeCalled = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptChanges() throws SyncProviderException {
/*      */     try {
/* 1772 */       getWriter().writeData(this);
/*      */     }
/* 1774 */     catch (SQLException sQLException) {
/*      */       
/* 1776 */       throw new SyncProviderException(sQLException.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void acceptChanges(Connection paramConnection) throws SyncProviderException {
/* 1787 */     this.connection = paramConnection;
/*      */ 
/*      */ 
/*      */     
/* 1791 */     this.isConnectionStayingOpenForTxnControl = true;
/* 1792 */     acceptChanges();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object clone() throws CloneNotSupportedException {
/*      */     try {
/* 1806 */       return createCopy();
/*      */     }
/* 1808 */     catch (SQLException sQLException) {
/*      */       
/* 1810 */       throw new CloneNotSupportedException("SQL Error occured while cloning: " + sQLException.getMessage());
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CachedRowSet createCopy() throws SQLException {
/* 1820 */     OracleCachedRowSet oracleCachedRowSet = (OracleCachedRowSet)createShared();
/* 1821 */     int i = this.rows.size();
/* 1822 */     oracleCachedRowSet.rows = new Vector(i);
/* 1823 */     for (byte b = 0; b < i; b++) {
/* 1824 */       oracleCachedRowSet.rows.add(((OracleRow)this.rows.elementAt(b)).createCopy());
/*      */     }
/* 1826 */     return oracleCachedRowSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowSet createShared() throws SQLException {
/* 1835 */     OracleCachedRowSet oracleCachedRowSet = new OracleCachedRowSet();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1840 */     oracleCachedRowSet.rows = this.rows;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1846 */     oracleCachedRowSet.setDataSource(getDataSource());
/* 1847 */     oracleCachedRowSet.setDataSourceName(getDataSourceName());
/* 1848 */     oracleCachedRowSet.setUsername(getUsername());
/* 1849 */     oracleCachedRowSet.setPassword(getPassword());
/* 1850 */     oracleCachedRowSet.setUrl(getUrl());
/* 1851 */     oracleCachedRowSet.setTypeMap(getTypeMap());
/* 1852 */     oracleCachedRowSet.setMaxFieldSize(getMaxFieldSize());
/* 1853 */     oracleCachedRowSet.setMaxRows(getMaxRows());
/* 1854 */     oracleCachedRowSet.setQueryTimeout(getQueryTimeout());
/* 1855 */     oracleCachedRowSet.setFetchSize(getFetchSize());
/* 1856 */     oracleCachedRowSet.setEscapeProcessing(getEscapeProcessing());
/* 1857 */     oracleCachedRowSet.setConcurrency(getConcurrency());
/* 1858 */     oracleCachedRowSet.setReadOnly(this.readOnly);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1863 */     this.rowsetType = getType();
/* 1864 */     this.fetchDirection = getFetchDirection();
/* 1865 */     oracleCachedRowSet.setCommand(getCommand());
/* 1866 */     oracleCachedRowSet.setTransactionIsolation(getTransactionIsolation());
/*      */ 
/*      */     
/* 1869 */     oracleCachedRowSet.presentRow = this.presentRow;
/* 1870 */     oracleCachedRowSet.colCount = this.colCount;
/* 1871 */     oracleCachedRowSet.rowCount = this.rowCount;
/* 1872 */     oracleCachedRowSet.showDeleted = this.showDeleted;
/*      */     
/* 1874 */     oracleCachedRowSet.syncProvider = this.syncProvider;
/* 1875 */     oracleCachedRowSet.currentPage = this.currentPage;
/* 1876 */     oracleCachedRowSet.pageSize = this.pageSize;
/* 1877 */     oracleCachedRowSet.tableName = (this.tableName == null) ? null : this.tableName;
/* 1878 */     oracleCachedRowSet.keyColumns = (this.keyColumns == null) ? null : (int[])this.keyColumns.clone();
/*      */     
/* 1880 */     int i = this.listener.size(); byte b;
/* 1881 */     for (b = 0; b < i; b++) {
/* 1882 */       oracleCachedRowSet.listener.add(this.listener.elementAt(b));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1891 */     oracleCachedRowSet.rowsetMetaData = new OracleRowSetMetaData(this.rowsetMetaData);
/*      */     
/* 1893 */     i = this.param.size();
/* 1894 */     for (b = 0; b < i; b++) {
/* 1895 */       oracleCachedRowSet.param.add(this.param.elementAt(b));
/*      */     }
/* 1897 */     oracleCachedRowSet.metaData = new String[this.metaData.length];
/* 1898 */     System.arraycopy(this.metaData, 0, oracleCachedRowSet.metaData, 0, this.metaData.length);
/*      */ 
/*      */ 
/*      */     
/* 1902 */     return oracleCachedRowSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void release() throws SQLException {
/* 1911 */     this.rows = null;
/* 1912 */     this.rows = new Vector();
/* 1913 */     if (this.connection != null && !this.connection.isClosed())
/* 1914 */       this.connection.close(); 
/* 1915 */     this.rowCount = 0;
/* 1916 */     this.presentRow = 0;
/* 1917 */     notifyRowSetChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void restoreOriginal() throws SQLException {
/* 1927 */     boolean bool = false;
/* 1928 */     for (byte b = 0; b < this.rowCount; b++) {
/*      */       
/* 1930 */       OracleRow oracleRow = this.rows.elementAt(b);
/* 1931 */       if (oracleRow.isRowInserted()) {
/*      */         
/* 1933 */         this.rows.remove(b);
/* 1934 */         this.rowCount--;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1939 */         b--;
/* 1940 */         bool = true;
/*      */       }
/* 1942 */       else if (oracleRow.isRowUpdated()) {
/*      */         
/* 1944 */         oracleRow.setRowUpdated(false);
/* 1945 */         bool = true;
/*      */       }
/* 1947 */       else if (oracleRow.isRowDeleted()) {
/*      */         
/* 1949 */         oracleRow.setRowDeleted(false);
/* 1950 */         bool = true;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1956 */     if (!bool) {
/*      */       
/* 1958 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 315);
/* 1959 */       sQLException.fillInStackTrace();
/* 1960 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1964 */     notifyRowSetChanged();
/*      */ 
/*      */     
/* 1967 */     this.presentRow = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection toCollection() throws SQLException {
/* 1978 */     Map<?, ?> map = Collections.synchronizedMap(new TreeMap<Object, Object>());
/*      */ 
/*      */     
/*      */     try {
/* 1982 */       for (byte b = 0; b < this.rowCount; b++)
/*      */       {
/* 1984 */         map.put(Integer.valueOf(b), ((OracleRow)this.rows.elementAt(b)).toCollection());
/*      */       
/*      */       }
/*      */     }
/* 1988 */     catch (Exception exception) {
/*      */ 
/*      */       
/* 1991 */       map = null;
/*      */       
/* 1993 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 316);
/* 1994 */       sQLException.fillInStackTrace();
/* 1995 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2000 */     return map.values();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection toCollection(int paramInt) throws SQLException {
/* 2009 */     if (paramInt < 1 || paramInt > this.colCount) {
/*      */       
/* 2011 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "" + paramInt);
/* 2012 */       sQLException.fillInStackTrace();
/* 2013 */       throw sQLException;
/*      */     } 
/*      */     
/* 2016 */     Vector<Object> vector = new Vector(this.rowCount);
/* 2017 */     for (byte b = 0; b < this.rowCount; b++) {
/*      */       
/* 2019 */       OracleRow oracleRow = this.rows.elementAt(b);
/* 2020 */       Object object = oracleRow.isColumnChanged(paramInt) ? oracleRow.getModifiedColumn(paramInt) : oracleRow.getColumn(paramInt);
/*      */ 
/*      */       
/* 2023 */       vector.add(object);
/*      */     } 
/*      */     
/* 2026 */     return vector;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Collection toCollection(String paramString) throws SQLException {
/* 2035 */     return toCollection(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/* 2053 */     if (this.presentRow > this.rowCount) {
/* 2054 */       return this.rowCount;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2062 */     return this.presentRow;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancelRowInsert() throws SQLException {
/* 2071 */     if (getCurrentRow().isRowInserted()) {
/*      */       
/* 2073 */       this.rows.remove(--this.presentRow);
/* 2074 */       this.rowCount--;
/* 2075 */       notifyRowChanged();
/*      */     }
/*      */     else {
/*      */       
/* 2079 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 317);
/* 2080 */       sQLException.fillInStackTrace();
/* 2081 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancelRowDelete() throws SQLException {
/* 2092 */     if (getCurrentRow().isRowDeleted()) {
/*      */       
/* 2094 */       getCurrentRow().setRowDeleted(false);
/* 2095 */       notifyRowChanged();
/*      */     }
/*      */     else {
/*      */       
/* 2099 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 318);
/* 2100 */       sQLException.fillInStackTrace();
/* 2101 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancelRowUpdates() throws SQLException {
/* 2112 */     if (getCurrentRow().isRowUpdated()) {
/*      */       
/* 2114 */       this.updateRowFlag = false;
/* 2115 */       getCurrentRow().setRowUpdated(false);
/* 2116 */       notifyRowChanged();
/*      */     }
/*      */     else {
/*      */       
/* 2120 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 319);
/* 2121 */       sQLException.fillInStackTrace();
/* 2122 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertRow() throws SQLException {
/* 2135 */     if (isReadOnly()) {
/*      */       
/* 2137 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2138 */       sQLException.fillInStackTrace();
/* 2139 */       throw sQLException;
/*      */     } 
/*      */     
/* 2142 */     if (!this.insertRowFlag) {
/*      */       
/* 2144 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 317);
/* 2145 */       sQLException.fillInStackTrace();
/* 2146 */       throw sQLException;
/*      */     } 
/*      */     
/* 2149 */     if (!this.insertRow.isRowFullyPopulated()) {
/*      */       
/* 2151 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 320);
/* 2152 */       sQLException.fillInStackTrace();
/* 2153 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2159 */     this.insertRow.insertRow();
/* 2160 */     this.rows.insertElementAt(this.insertRow, this.insertRowPosition - 1);
/* 2161 */     this.insertRowFlag = false;
/* 2162 */     this.rowCount++;
/* 2163 */     notifyRowChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRow() throws SQLException {
/* 2175 */     if (isReadOnly()) {
/*      */       
/* 2177 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2178 */       sQLException.fillInStackTrace();
/* 2179 */       throw sQLException;
/*      */     } 
/*      */     
/* 2182 */     if (this.updateRowFlag) {
/*      */       
/* 2184 */       this.updateRowFlag = false;
/* 2185 */       getCurrentRow().setRowUpdated(true);
/* 2186 */       notifyRowChanged();
/*      */     }
/*      */     else {
/*      */       
/* 2190 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 319);
/* 2191 */       sQLException.fillInStackTrace();
/* 2192 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteRow() throws SQLException {
/* 2203 */     if (isReadOnly()) {
/*      */       
/* 2205 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2206 */       sQLException.fillInStackTrace();
/* 2207 */       throw sQLException;
/*      */     } 
/*      */     
/* 2210 */     getCurrentRow().setRowDeleted(true);
/* 2211 */     notifyRowChanged();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLException {
/* 2221 */     OracleRow oracleRow = getCurrentRow();
/* 2222 */     if (oracleRow.isRowUpdated()) {
/* 2223 */       oracleRow.cancelRowUpdates();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToInsertRow() throws SQLException {
/* 2235 */     if (isReadOnly()) {
/*      */       
/* 2237 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2238 */       sQLException.fillInStackTrace();
/* 2239 */       throw sQLException;
/*      */     } 
/*      */     
/* 2242 */     this.insertRow = new OracleRow(this.colCount, true);
/* 2243 */     this.insertRowFlag = true;
/*      */     
/* 2245 */     if (isAfterLast()) {
/* 2246 */       this.insertRowPosition = this.presentRow;
/*      */     } else {
/* 2248 */       this.insertRowPosition = this.presentRow + 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToCurrentRow() throws SQLException {
/* 2260 */     if (isReadOnly()) {
/*      */       
/* 2262 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 309);
/* 2263 */       sQLException.fillInStackTrace();
/* 2264 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2271 */     this.insertRowFlag = false;
/* 2272 */     this.updateRowFlag = false;
/* 2273 */     absolute(this.presentRow);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowUpdated() throws SQLException {
/* 2283 */     return getCurrentRow().isRowUpdated();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowInserted() throws SQLException {
/* 2292 */     return getCurrentRow().isRowInserted();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowDeleted() throws SQLException {
/* 2301 */     return getCurrentRow().isRowDeleted();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getOriginalRow() throws SQLException {
/* 2313 */     OracleCachedRowSet oracleCachedRowSet = new OracleCachedRowSet();
/* 2314 */     oracleCachedRowSet.rowsetMetaData = this.rowsetMetaData;
/* 2315 */     oracleCachedRowSet.rowCount = 1;
/* 2316 */     oracleCachedRowSet.colCount = this.colCount;
/* 2317 */     oracleCachedRowSet.presentRow = 0;
/* 2318 */     oracleCachedRowSet.setReader((RowSetReader)null);
/* 2319 */     oracleCachedRowSet.setWriter((RowSetWriter)null);
/* 2320 */     OracleRow oracleRow = new OracleRow(this.rowsetMetaData.getColumnCount(), getCurrentRow().getOriginalRow());
/*      */ 
/*      */     
/* 2323 */     oracleCachedRowSet.rows.add(oracleRow);
/*      */     
/* 2325 */     return oracleCachedRowSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getOriginal() throws SQLException {
/* 2337 */     OracleCachedRowSet oracleCachedRowSet = new OracleCachedRowSet();
/* 2338 */     oracleCachedRowSet.rowsetMetaData = this.rowsetMetaData;
/* 2339 */     oracleCachedRowSet.rowCount = this.rowCount;
/* 2340 */     oracleCachedRowSet.colCount = this.colCount;
/*      */ 
/*      */     
/* 2343 */     oracleCachedRowSet.presentRow = 0;
/*      */ 
/*      */     
/* 2346 */     oracleCachedRowSet.setType(1004);
/* 2347 */     oracleCachedRowSet.setConcurrency(1008);
/*      */     
/* 2349 */     oracleCachedRowSet.setReader((RowSetReader)null);
/* 2350 */     oracleCachedRowSet.setWriter((RowSetWriter)null);
/* 2351 */     int i = this.rowsetMetaData.getColumnCount();
/* 2352 */     OracleRow oracleRow = null;
/*      */     
/* 2354 */     Iterator<OracleRow> iterator = this.rows.iterator();
/* 2355 */     for (; iterator.hasNext(); 
/* 2356 */       oracleCachedRowSet.rows.add(oracleRow)) {
/* 2357 */       oracleRow = new OracleRow(i, ((OracleRow)iterator.next()).getOriginalRow());
/*      */     }
/* 2359 */     return oracleCachedRowSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int paramInt1, int paramInt2) throws SQLException {
/* 2373 */     checkParamIndex(paramInt1);
/*      */     
/* 2375 */     this.param.add(paramInt1 - 1, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 2385 */     checkParamIndex(paramInt1);
/* 2386 */     Object[] arrayOfObject = { Integer.valueOf(paramInt2), paramString };
/* 2387 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/* 2397 */     checkParamIndex(paramInt);
/* 2398 */     this.param.add(paramInt - 1, Boolean.valueOf(paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(int paramInt, byte paramByte) throws SQLException {
/* 2408 */     checkParamIndex(paramInt);
/* 2409 */     this.param.add(paramInt - 1, new Byte(paramByte));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(int paramInt, short paramShort) throws SQLException {
/* 2419 */     checkParamIndex(paramInt);
/* 2420 */     this.param.add(paramInt - 1, Short.valueOf(paramShort));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(int paramInt1, int paramInt2) throws SQLException {
/* 2430 */     checkParamIndex(paramInt1);
/* 2431 */     this.param.add(paramInt1 - 1, Integer.valueOf(paramInt2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(int paramInt, long paramLong) throws SQLException {
/* 2441 */     checkParamIndex(paramInt);
/* 2442 */     this.param.add(paramInt - 1, Long.valueOf(paramLong));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(int paramInt, float paramFloat) throws SQLException {
/* 2452 */     checkParamIndex(paramInt);
/* 2453 */     this.param.add(paramInt - 1, Float.valueOf(paramFloat));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(int paramInt, double paramDouble) throws SQLException {
/* 2463 */     checkParamIndex(paramInt);
/* 2464 */     this.param.add(paramInt - 1, Double.valueOf(paramDouble));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/* 2474 */     checkParamIndex(paramInt);
/* 2475 */     this.param.add(paramInt - 1, paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(int paramInt, String paramString) throws SQLException {
/* 2485 */     checkParamIndex(paramInt);
/* 2486 */     this.param.add(paramInt - 1, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 2496 */     checkParamIndex(paramInt);
/* 2497 */     this.param.add(paramInt - 1, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate) throws SQLException {
/* 2507 */     checkParamIndex(paramInt);
/* 2508 */     this.param.add(paramInt - 1, paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime) throws SQLException {
/* 2518 */     checkParamIndex(paramInt);
/* 2519 */     this.param.add(paramInt - 1, paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt, Object paramObject) throws SQLException {
/* 2529 */     checkParamIndex(paramInt);
/* 2530 */     this.param.add(paramInt - 1, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(int paramInt, Ref paramRef) throws SQLException {
/* 2540 */     checkParamIndex(paramInt);
/* 2541 */     this.param.add(paramInt - 1, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, Blob paramBlob) throws SQLException {
/* 2551 */     checkParamIndex(paramInt);
/* 2552 */     this.param.add(paramInt - 1, paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Clob paramClob) throws SQLException {
/* 2562 */     checkParamIndex(paramInt);
/* 2563 */     this.param.add(paramInt - 1, paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(int paramInt, Array paramArray) throws SQLException {
/* 2573 */     checkParamIndex(paramInt);
/* 2574 */     this.param.add(paramInt - 1, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 2585 */     checkParamIndex(paramInt1);
/* 2586 */     Object[] arrayOfObject = { paramInputStream, Integer.valueOf(paramInt2), Integer.valueOf(2) };
/*      */     
/* 2588 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 2598 */     checkParamIndex(paramInt);
/* 2599 */     Object[] arrayOfObject = { paramTime, paramCalendar };
/* 2600 */     this.param.add(paramInt - 1, arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 2610 */     checkParamIndex(paramInt);
/* 2611 */     Object[] arrayOfObject = { paramTimestamp, paramCalendar };
/* 2612 */     this.param.add(paramInt - 1, arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/* 2621 */     checkParamIndex(paramInt);
/* 2622 */     this.param.add(paramInt - 1, paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 2632 */     checkParamIndex(paramInt1);
/* 2633 */     Object[] arrayOfObject = { paramInputStream, Integer.valueOf(paramInt2), Integer.valueOf(3) };
/*      */     
/* 2635 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 2645 */     checkParamIndex(paramInt1);
/* 2646 */     Object[] arrayOfObject = { paramInputStream, Integer.valueOf(paramInt2), Integer.valueOf(1) };
/*      */     
/* 2648 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/* 2658 */     checkParamIndex(paramInt1);
/* 2659 */     Object[] arrayOfObject = { paramReader, Integer.valueOf(paramInt2), Integer.valueOf(4) };
/*      */     
/* 2661 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException {
/* 2671 */     checkParamIndex(paramInt1);
/* 2672 */     Object[] arrayOfObject = { paramObject, Integer.valueOf(paramInt2), Integer.valueOf(paramInt3) };
/* 2673 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/* 2683 */     checkParamIndex(paramInt1);
/* 2684 */     Object[] arrayOfObject = { paramObject, Integer.valueOf(paramInt2) };
/* 2685 */     this.param.add(paramInt1 - 1, arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 2695 */     checkParamIndex(paramInt);
/* 2696 */     Object[] arrayOfObject = { paramDate, paramCalendar };
/* 2697 */     this.param.add(paramInt - 1, arrayOfObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/* 2707 */     checkParamIndex(paramInt);
/* 2708 */     this.param.add(paramInt - 1, paramURL.toString());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Object getObject(int paramInt) throws SQLException {
/* 2728 */     int i = this.presentRow * this.colCount + paramInt - 1;
/* 2729 */     Object object = null;
/*      */     
/* 2731 */     if (!isUpdated(paramInt)) {
/* 2732 */       object = getCurrentRow().getColumn(paramInt);
/*      */     } else {
/* 2734 */       object = getCurrentRow().getModifiedColumn(paramInt);
/* 2735 */     }  this.previousColumnWasNull = (object == null);
/*      */     
/* 2737 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized Number getNumber(int paramInt) throws SQLException {
/* 2747 */     Object object = getObject(paramInt);
/*      */     
/* 2749 */     if (object == null || object instanceof BigDecimal || object instanceof Number)
/*      */     {
/*      */       
/* 2752 */       return (Number)object;
/*      */     }
/* 2754 */     if (object instanceof Boolean) {
/* 2755 */       return Integer.valueOf(((Boolean)object).booleanValue() ? 1 : 0);
/*      */     }
/* 2757 */     if (object instanceof String) {
/*      */       
/*      */       try {
/*      */         
/* 2761 */         return new BigDecimal((String)object);
/*      */       }
/* 2763 */       catch (NumberFormatException numberFormatException) {
/*      */ 
/*      */         
/* 2766 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 2767 */         sQLException1.fillInStackTrace();
/* 2768 */         throw sQLException1;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2775 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 2776 */     sQLException.fillInStackTrace();
/* 2777 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 2789 */     return getObject(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/* 2798 */     Object object = getObject(paramInt);
/*      */     
/* 2800 */     if (object == null) {
/* 2801 */       return false;
/*      */     }
/* 2803 */     if (object instanceof Boolean) {
/* 2804 */       return ((Boolean)object).booleanValue();
/*      */     }
/* 2806 */     if (object instanceof Number) {
/* 2807 */       return (((Number)object).doubleValue() != 0.0D);
/*      */     }
/*      */ 
/*      */     
/* 2811 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 2812 */     sQLException.fillInStackTrace();
/* 2813 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/* 2828 */     Object object = getObject(paramInt);
/*      */     
/* 2830 */     if (object == null) {
/* 2831 */       return 0;
/*      */     }
/* 2833 */     if (object instanceof BigDecimal) {
/*      */       
/* 2835 */       BigDecimal bigDecimal = (BigDecimal)object;
/* 2836 */       if (bigDecimal.compareTo(new BigDecimal(127)) == 1 || bigDecimal.compareTo(new BigDecimal(-128)) == -1) {
/*      */ 
/*      */         
/* 2839 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26);
/* 2840 */         sQLException1.fillInStackTrace();
/* 2841 */         throw sQLException1;
/*      */       } 
/*      */       
/* 2844 */       return bigDecimal.byteValue();
/*      */     } 
/*      */     
/* 2847 */     if (object instanceof Number) {
/* 2848 */       return ((Number)object).byteValue();
/*      */     }
/* 2850 */     if (object instanceof String) {
/* 2851 */       return ((String)object).getBytes()[0];
/*      */     }
/* 2853 */     if (object instanceof OracleSerialBlob) {
/*      */       
/* 2855 */       OracleSerialBlob oracleSerialBlob = (OracleSerialBlob)object;
/* 2856 */       return oracleSerialBlob.getBytes(1L, 1)[0];
/*      */     } 
/* 2858 */     if (object instanceof OracleSerialClob) {
/*      */       
/* 2860 */       OracleSerialClob oracleSerialClob = (OracleSerialClob)object;
/* 2861 */       return oracleSerialClob.getSubString(1L, 1).getBytes()[0];
/*      */     } 
/*      */ 
/*      */     
/* 2865 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 2866 */     sQLException.fillInStackTrace();
/* 2867 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/* 2878 */     Number number = getNumber(paramInt);
/*      */     
/* 2880 */     return (number == null) ? 0 : number.shortValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/* 2889 */     Number number = getNumber(paramInt);
/*      */     
/* 2891 */     return (number == null) ? 0 : number.intValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/* 2900 */     Number number = getNumber(paramInt);
/*      */     
/* 2902 */     return (number == null) ? 0L : number.longValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/* 2911 */     Number number = getNumber(paramInt);
/*      */     
/* 2913 */     return (number == null) ? 0.0F : number.floatValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/* 2922 */     Number number = getNumber(paramInt);
/*      */     
/* 2924 */     return (number == null) ? 0.0D : number.doubleValue();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 2933 */     Number number = getNumber(paramInt);
/*      */     
/* 2935 */     if (number == null || number instanceof BigDecimal) {
/* 2936 */       return (BigDecimal)number;
/*      */     }
/* 2938 */     return new BigDecimal(number.doubleValue());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/* 2948 */     return getBigDecimal(paramInt1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/* 2957 */     Object object = getObject(paramInt);
/*      */     
/* 2959 */     if (object == null) {
/* 2960 */       return (Date)object;
/*      */     }
/* 2962 */     if (object instanceof Time) {
/*      */       
/* 2964 */       Time time = (Time)object;
/* 2965 */       return new Date(time.getTime());
/*      */     } 
/*      */     
/* 2968 */     if (object instanceof Date) {
/*      */       
/* 2970 */       Date date = (Date)object;
/* 2971 */       return new Date(date.getYear(), date.getMonth(), date.getDate());
/*      */     } 
/*      */     
/* 2974 */     if (object instanceof TIMESTAMP) {
/* 2975 */       return ((TIMESTAMP)object).dateValue();
/*      */     }
/* 2977 */     if (object instanceof TIMESTAMPTZ) {
/* 2978 */       return ((TIMESTAMPTZ)object).dateValue(getConnectionInternal());
/*      */     }
/* 2980 */     if (object instanceof TIMESTAMPLTZ) {
/*      */       
/* 2982 */       Connection connection = getConnectionInternal();
/*      */       
/* 2984 */       return ((TIMESTAMPLTZ)object).dateValue(connection, getSessionCalendar(connection));
/*      */     } 
/*      */ 
/*      */     
/* 2988 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 2989 */     sQLException.fillInStackTrace();
/* 2990 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 3001 */     return getDate(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/* 3011 */     Object object = getObject(paramInt);
/*      */     
/* 3013 */     if (object == null) {
/* 3014 */       return (Time)object;
/*      */     }
/* 3016 */     if (object instanceof Date) {
/*      */       
/* 3018 */       Date date = (Date)object;
/* 3019 */       return new Time(date.getHours(), date.getMinutes(), date.getSeconds());
/*      */     } 
/*      */ 
/*      */     
/* 3023 */     if (object instanceof TIMESTAMP) {
/* 3024 */       return ((TIMESTAMP)object).timeValue();
/*      */     }
/* 3026 */     if (object instanceof TIMESTAMPTZ) {
/* 3027 */       return ((TIMESTAMPTZ)object).timeValue(getConnectionInternal());
/*      */     }
/* 3029 */     if (object instanceof TIMESTAMPLTZ) {
/*      */       
/* 3031 */       Connection connection = getConnectionInternal();
/*      */       
/* 3033 */       return ((TIMESTAMPLTZ)object).timeValue(connection, getSessionCalendar(connection));
/*      */     } 
/*      */ 
/*      */     
/* 3037 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3038 */     sQLException.fillInStackTrace();
/* 3039 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 3050 */     return getTime(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/* 3059 */     Object object = getObject(paramInt);
/*      */     
/* 3061 */     if (object == null || object instanceof Timestamp) {
/* 3062 */       return (Timestamp)object;
/*      */     }
/* 3064 */     if (object instanceof Date) {
/* 3065 */       return new Timestamp(((Date)object).getTime());
/*      */     }
/* 3067 */     if (object instanceof TIMESTAMP) {
/* 3068 */       return ((TIMESTAMP)object).timestampValue();
/*      */     }
/* 3070 */     if (object instanceof TIMESTAMPTZ) {
/* 3071 */       return ((TIMESTAMPTZ)object).timestampValue(getConnectionInternal());
/*      */     }
/* 3073 */     if (object instanceof TIMESTAMPLTZ) {
/*      */       
/* 3075 */       Connection connection = getConnectionInternal();
/*      */       
/* 3077 */       return ((TIMESTAMPLTZ)object).timestampValue(connection, getSessionCalendar(connection));
/*      */     } 
/*      */ 
/*      */     
/* 3081 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3082 */     sQLException.fillInStackTrace();
/* 3083 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 3094 */     return getTimestamp(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/* 3103 */     Object object = getObject(paramInt);
/*      */     
/* 3105 */     if (object == null) {
/* 3106 */       return (byte[])object;
/*      */     }
/* 3108 */     if (object instanceof byte[]) {
/* 3109 */       return (byte[])object;
/*      */     }
/* 3111 */     if (object instanceof String) {
/* 3112 */       return ((String)object).getBytes();
/*      */     }
/* 3114 */     if (object instanceof Number) {
/* 3115 */       return ((Number)object).toString().getBytes();
/*      */     }
/* 3117 */     if (object instanceof BigDecimal) {
/* 3118 */       return ((BigDecimal)object).toString().getBytes();
/*      */     }
/* 3120 */     if (object instanceof OracleSerialBlob) {
/*      */       
/* 3122 */       OracleSerialBlob oracleSerialBlob = (OracleSerialBlob)object;
/* 3123 */       return oracleSerialBlob.getBytes(1L, (int)oracleSerialBlob.length());
/*      */     } 
/* 3125 */     if (object instanceof OracleSerialClob) {
/*      */       
/* 3127 */       OracleSerialClob oracleSerialClob = (OracleSerialClob)object;
/* 3128 */       return oracleSerialClob.getSubString(1L, (int)oracleSerialClob.length()).getBytes();
/*      */     } 
/*      */ 
/*      */     
/* 3132 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 3133 */     sQLException.fillInStackTrace();
/* 3134 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 3145 */     Object object = getObject(paramInt);
/*      */     
/* 3147 */     if (object == null || object instanceof Ref) {
/* 3148 */       return (Ref)object;
/*      */     }
/*      */     
/* 3151 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3152 */     sQLException.fillInStackTrace();
/* 3153 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 3164 */     Object object = getObject(paramInt);
/*      */     
/* 3166 */     if (object == null || object instanceof OracleSerialBlob) {
/* 3167 */       return (Blob)object;
/*      */     }
/*      */     
/* 3170 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3171 */     sQLException.fillInStackTrace();
/* 3172 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 3183 */     Object object = getObject(paramInt);
/*      */     
/* 3185 */     if (object == null || object instanceof OracleSerialClob) {
/* 3186 */       return (Clob)object;
/*      */     }
/*      */     
/* 3189 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3190 */     sQLException.fillInStackTrace();
/* 3191 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 3202 */     Object object = getObject(paramInt);
/*      */     
/* 3204 */     if (object == null || object instanceof Array) {
/* 3205 */       return (Array)object;
/*      */     }
/*      */     
/* 3208 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 3209 */     sQLException.fillInStackTrace();
/* 3210 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/* 3220 */     Object object = getObject(paramInt);
/*      */     
/* 3222 */     if (object == null) {
/* 3223 */       return (String)object;
/*      */     }
/* 3225 */     if (object instanceof String) {
/* 3226 */       return (String)object;
/*      */     }
/* 3228 */     if (object instanceof Number || object instanceof BigDecimal) {
/* 3229 */       return object.toString();
/*      */     }
/* 3231 */     if (object instanceof Date) {
/* 3232 */       return object.toString();
/*      */     }
/* 3234 */     if (object instanceof Timestamp) {
/* 3235 */       return object.toString();
/*      */     }
/* 3237 */     if (object instanceof byte[]) {
/* 3238 */       return new String((byte[])object);
/*      */     }
/* 3240 */     if (object instanceof OracleSerialClob) {
/*      */       
/* 3242 */       OracleSerialClob oracleSerialClob = (OracleSerialClob)object;
/* 3243 */       return oracleSerialClob.getSubString(1L, (int)oracleSerialClob.length());
/*      */     } 
/*      */     
/* 3246 */     if (object instanceof OracleSerialBlob) {
/*      */       
/* 3248 */       OracleSerialBlob oracleSerialBlob = (OracleSerialBlob)object;
/* 3249 */       return new String(oracleSerialBlob.getBytes(1L, (int)oracleSerialBlob.length()));
/*      */     } 
/*      */ 
/*      */     
/* 3253 */     if (object instanceof URL) {
/* 3254 */       return ((URL)object).toString();
/*      */     }
/* 3256 */     if (object instanceof ROWID) {
/* 3257 */       return ((ROWID)object).stringValue();
/*      */     }
/* 3259 */     if (object instanceof Reader) {
/*      */       
/*      */       try {
/*      */         
/* 3263 */         Reader reader = (Reader)object;
/* 3264 */         char[] arrayOfChar = new char[1024];
/* 3265 */         int i = 0;
/* 3266 */         StringBuffer stringBuffer = new StringBuffer(1024);
/* 3267 */         while ((i = reader.read(arrayOfChar)) > 0)
/* 3268 */           stringBuffer.append(arrayOfChar, 0, i); 
/* 3269 */         return stringBuffer.substring(0, stringBuffer.length());
/*      */       }
/* 3271 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3274 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 321, iOException.getMessage());
/* 3275 */         sQLException1.fillInStackTrace();
/* 3276 */         throw sQLException1;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3282 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 3283 */     sQLException.fillInStackTrace();
/* 3284 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 3295 */     InputStream inputStream = getStream(paramInt);
/*      */     
/* 3297 */     return (inputStream == null) ? null : inputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 3306 */     Object object = getObject(paramInt);
/*      */     
/* 3308 */     if (object == null) {
/* 3309 */       return (InputStream)object;
/*      */     }
/*      */     
/* 3312 */     if (object instanceof String) {
/* 3313 */       return new StringBufferInputStream((String)object);
/*      */     }
/*      */     
/* 3316 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59);
/* 3317 */     sQLException.fillInStackTrace();
/* 3318 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 3330 */     InputStream inputStream = getStream(paramInt);
/*      */     
/* 3332 */     return (inputStream == null) ? null : inputStream;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Reader getCharacterStream(int paramInt) throws SQLException {
/*      */     try {
/* 3344 */       InputStream inputStream = getAsciiStream(paramInt);
/*      */       
/* 3346 */       if (inputStream == null) {
/* 3347 */         return null;
/*      */       }
/* 3349 */       StringBuffer stringBuffer = new StringBuffer();
/* 3350 */       int i = 0;
/* 3351 */       while ((i = inputStream.read()) != -1) {
/* 3352 */         stringBuffer.append((char)i);
/*      */       }
/*      */ 
/*      */       
/* 3356 */       char[] arrayOfChar = new char[stringBuffer.length()];
/* 3357 */       stringBuffer.getChars(0, stringBuffer.length(), arrayOfChar, 0);
/* 3358 */       CharArrayReader charArrayReader = new CharArrayReader(arrayOfChar);
/* 3359 */       arrayOfChar = null;
/*      */       
/* 3361 */       return charArrayReader;
/* 3362 */     } catch (IOException iOException) {
/*      */ 
/*      */ 
/*      */       
/* 3366 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 322);
/* 3367 */       sQLException.fillInStackTrace();
/* 3368 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Object getObject(String paramString) throws SQLException {
/* 3385 */     return getObject(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) throws SQLException {
/* 3394 */     return getBoolean(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) throws SQLException {
/* 3403 */     return getByte(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) throws SQLException {
/* 3412 */     return getShort(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String paramString) throws SQLException {
/* 3421 */     return getInt(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) throws SQLException {
/* 3430 */     return getLong(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) throws SQLException {
/* 3439 */     return getFloat(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) throws SQLException {
/* 3448 */     return getDouble(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/* 3457 */     return getBigDecimal(getColumnIndex(paramString), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String paramString) throws SQLException {
/* 3466 */     return getBytes(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) throws SQLException {
/* 3475 */     return getDate(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString) throws SQLException {
/* 3484 */     return getTime(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString) throws SQLException {
/* 3493 */     return getTimestamp(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
/* 3502 */     return getTime(getColumnIndex(paramString), paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
/* 3511 */     return getDate(getColumnIndex(paramString), paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String paramString) throws SQLException {
/* 3520 */     return getAsciiStream(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(String paramString) throws SQLException {
/* 3529 */     return getUnicodeStream(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String paramString) throws SQLException {
/* 3538 */     return getString(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String paramString) throws SQLException {
/* 3547 */     return getBinaryStream(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String paramString) throws SQLException {
/* 3556 */     return getCharacterStream(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLException {
/* 3565 */     return getBigDecimal(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
/* 3574 */     return getTimestamp(getColumnIndex(paramString), paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, Map paramMap) throws SQLException {
/* 3582 */     return getObject(getColumnIndex(paramString), paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(String paramString) throws SQLException {
/* 3591 */     return getRef(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(String paramString) throws SQLException {
/* 3600 */     return getBlob(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(String paramString) throws SQLException {
/* 3609 */     return getClob(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(String paramString) throws SQLException {
/* 3618 */     return getArray(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt, Object paramObject) throws SQLException {
/* 3632 */     updateObject(paramInt, paramObject, (int[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void updateObject(int paramInt, Object paramObject, int[] paramArrayOfint) throws SQLException {
/* 3650 */     checkColumnIndex(paramInt);
/* 3651 */     if (this.insertRowFlag) {
/*      */       
/* 3653 */       checkAndFilterObject(paramInt, paramObject);
/* 3654 */       this.insertRow.updateObject(paramInt, paramObject, paramArrayOfint);
/*      */     }
/* 3656 */     else if (!isBeforeFirst() && !isAfterLast()) {
/*      */ 
/*      */ 
/*      */       
/* 3660 */       this.updateRowFlag = true;
/* 3661 */       this.updateRowPosition = this.presentRow;
/* 3662 */       getCurrentRow().updateObject(paramInt, paramObject, paramArrayOfint);
/*      */     } else {
/*      */       
/* 3665 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90);
/* 3666 */       sQLException.fillInStackTrace();
/* 3667 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(int paramInt) throws SQLException {
/* 3678 */     updateObject(paramInt, (Object)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/* 3689 */     updateCharacterStreamInternal(paramInt1, paramReader, paramInt2, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void updateCharacterStreamInternal(int paramInt1, Reader paramReader, int paramInt2, boolean paramBoolean) throws SQLException {
/* 3700 */     checkColumnIndex(paramInt1);
/*      */     
/* 3702 */     if (paramInt2 < 0) {
/*      */       
/* 3704 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3705 */       sQLException.fillInStackTrace();
/* 3706 */       throw sQLException;
/*      */     } 
/*      */     
/* 3709 */     int i = getMetaData().getColumnType(paramInt1);
/* 3710 */     if (!isStreamType(i)) {
/*      */       
/*      */       try
/*      */       {
/* 3714 */         int j = 0;
/* 3715 */         int k = paramInt2;
/* 3716 */         char[] arrayOfChar = new char[1024];
/* 3717 */         StringBuilder stringBuilder = new StringBuilder(1024);
/*      */         
/* 3719 */         while (k > 0) {
/*      */           
/* 3721 */           if (k >= 1024) {
/* 3722 */             j = paramReader.read(arrayOfChar);
/*      */           } else {
/* 3724 */             j = paramReader.read(arrayOfChar, 0, k);
/*      */           } 
/*      */ 
/*      */           
/* 3728 */           if (j == -1) {
/*      */             break;
/*      */           }
/* 3731 */           stringBuilder.append(arrayOfChar, 0, j);
/* 3732 */           k -= j;
/*      */         } 
/*      */         
/* 3735 */         paramReader.close();
/* 3736 */         if (k == paramInt2) {
/*      */           
/* 3738 */           updateNull(paramInt1);
/*      */           
/*      */           return;
/*      */         } 
/* 3742 */         updateString(paramInt1, stringBuilder.toString());
/*      */       }
/* 3744 */       catch (IOException iOException)
/*      */       {
/*      */         
/* 3747 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3748 */         sQLException.fillInStackTrace();
/* 3749 */         throw sQLException;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 3755 */       byte b = paramBoolean ? 4 : 3;
/*      */ 
/*      */       
/* 3758 */       int[] arrayOfInt = { paramInt2, b };
/*      */       
/* 3760 */       updateObject(paramInt1, paramReader, arrayOfInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 3771 */     updateCharacterStream(getColumnIndex(paramString), paramReader, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
/* 3781 */     updateTimestamp(getColumnIndex(paramString), paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 3791 */     updateBinaryStream(getColumnIndex(paramString), paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 3802 */     checkColumnIndex(paramInt1);
/*      */     
/* 3804 */     if (paramInt2 < 0) {
/*      */       
/* 3806 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3807 */       sQLException.fillInStackTrace();
/* 3808 */       throw sQLException;
/*      */     } 
/*      */     
/* 3811 */     int i = getMetaData().getColumnType(paramInt1);
/* 3812 */     if (!isStreamType(i)) {
/*      */       
/*      */       try
/*      */       {
/* 3816 */         int j = 0;
/* 3817 */         int k = paramInt2;
/* 3818 */         byte[] arrayOfByte = new byte[1024];
/* 3819 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
/*      */ 
/*      */         
/* 3822 */         while (k > 0) {
/*      */           
/* 3824 */           if (k >= 1024) {
/* 3825 */             j = paramInputStream.read(arrayOfByte);
/*      */           } else {
/* 3827 */             j = paramInputStream.read(arrayOfByte, 0, k);
/*      */           } 
/*      */ 
/*      */           
/* 3831 */           if (j == -1) {
/*      */             break;
/*      */           }
/* 3834 */           byteArrayOutputStream.write(arrayOfByte, 0, j);
/* 3835 */           k -= j;
/*      */         } 
/*      */         
/* 3838 */         paramInputStream.close();
/* 3839 */         if (k == paramInt2) {
/*      */           
/* 3841 */           updateNull(paramInt1);
/*      */           
/*      */           return;
/*      */         } 
/* 3845 */         updateBytes(paramInt1, byteArrayOutputStream.toByteArray());
/*      */       }
/* 3847 */       catch (IOException iOException)
/*      */       {
/*      */         
/* 3850 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3851 */         sQLException.fillInStackTrace();
/* 3852 */         throw sQLException;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 3858 */       int[] arrayOfInt = { paramInt2, 2 };
/*      */       
/* 3860 */       updateObject(paramInt1, paramInputStream, arrayOfInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 3871 */     checkColumnIndex(paramInt1);
/*      */     
/* 3873 */     if (paramInt2 < 0) {
/*      */       
/* 3875 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3876 */       sQLException.fillInStackTrace();
/* 3877 */       throw sQLException;
/*      */     } 
/*      */     
/* 3880 */     int i = getMetaData().getColumnType(paramInt1);
/* 3881 */     if (!isStreamType(i)) {
/*      */       
/*      */       try
/*      */       {
/* 3885 */         int j = 0;
/* 3886 */         int k = paramInt2;
/* 3887 */         byte[] arrayOfByte = new byte[1024];
/* 3888 */         char[] arrayOfChar = new char[1024];
/* 3889 */         StringBuilder stringBuilder = new StringBuilder(1024);
/*      */         
/* 3891 */         while (k > 0) {
/*      */           
/* 3893 */           if (k >= 1024) {
/* 3894 */             j = paramInputStream.read(arrayOfByte);
/*      */           } else {
/* 3896 */             j = paramInputStream.read(arrayOfByte, 0, k);
/*      */           } 
/*      */ 
/*      */           
/* 3900 */           if (j == -1) {
/*      */             break;
/*      */           }
/* 3903 */           DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar);
/*      */           
/* 3905 */           stringBuilder.append(arrayOfChar, 0, j);
/* 3906 */           k -= j;
/*      */         } 
/*      */         
/* 3909 */         paramInputStream.close();
/* 3910 */         if (k == paramInt2) {
/*      */           
/* 3912 */           updateNull(paramInt1);
/*      */           
/*      */           return;
/*      */         } 
/* 3916 */         updateString(paramInt1, stringBuilder.toString());
/*      */       }
/* 3918 */       catch (IOException iOException)
/*      */       {
/*      */         
/* 3921 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3922 */         sQLException.fillInStackTrace();
/* 3923 */         throw sQLException;
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 3929 */       int[] arrayOfInt = { paramInt2, 1 };
/*      */       
/* 3931 */       updateObject(paramInt1, paramInputStream, arrayOfInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/* 3942 */     updateObject(paramInt, paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/* 3952 */     updateObject(paramInt, Boolean.valueOf(paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateByte(int paramInt, byte paramByte) throws SQLException {
/* 3962 */     updateObject(paramInt, new Byte(paramByte));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateShort(int paramInt, short paramShort) throws SQLException {
/* 3972 */     updateObject(paramInt, Short.valueOf(paramShort));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateInt(int paramInt1, int paramInt2) throws SQLException {
/* 3982 */     updateObject(paramInt1, Integer.valueOf(paramInt2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateLong(int paramInt, long paramLong) throws SQLException {
/* 3992 */     updateObject(paramInt, Long.valueOf(paramLong));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFloat(int paramInt, float paramFloat) throws SQLException {
/* 4002 */     updateObject(paramInt, Float.valueOf(paramFloat));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDouble(int paramInt, double paramDouble) throws SQLException {
/* 4012 */     updateObject(paramInt, Double.valueOf(paramDouble));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/* 4022 */     updateObject(paramInt, paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateString(int paramInt, String paramString) throws SQLException {
/* 4032 */     updateObject(paramInt, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 4042 */     updateObject(paramInt, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(int paramInt, Date paramDate) throws SQLException {
/* 4052 */     updateObject(paramInt, paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(int paramInt, Time paramTime) throws SQLException {
/* 4062 */     updateObject(paramInt, new Timestamp(0, 0, 0, paramTime.getHours(), paramTime.getMinutes(), paramTime.getSeconds(), 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/* 4074 */     if (!(paramObject instanceof Number)) {
/*      */       
/* 4076 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 323);
/* 4077 */       sQLException.fillInStackTrace();
/* 4078 */       throw sQLException;
/*      */     } 
/*      */     
/* 4081 */     updateObject(paramInt1, new BigDecimal(new BigInteger(((Number)paramObject).toString()), paramInt2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNull(String paramString) throws SQLException {
/* 4097 */     updateNull(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 4107 */     updateAsciiStream(getColumnIndex(paramString), paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBoolean(String paramString, boolean paramBoolean) throws SQLException {
/* 4117 */     updateBoolean(getColumnIndex(paramString), paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateByte(String paramString, byte paramByte) throws SQLException {
/* 4127 */     updateByte(getColumnIndex(paramString), paramByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateShort(String paramString, short paramShort) throws SQLException {
/* 4137 */     updateShort(getColumnIndex(paramString), paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateInt(String paramString, int paramInt) throws SQLException {
/* 4147 */     updateInt(getColumnIndex(paramString), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateLong(String paramString, long paramLong) throws SQLException {
/* 4157 */     updateLong(getColumnIndex(paramString), paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFloat(String paramString, float paramFloat) throws SQLException {
/* 4167 */     updateFloat(getColumnIndex(paramString), paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDouble(String paramString, double paramDouble) throws SQLException {
/* 4177 */     updateDouble(getColumnIndex(paramString), paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/* 4187 */     updateBigDecimal(getColumnIndex(paramString), paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateString(String paramString1, String paramString2) throws SQLException {
/* 4197 */     updateString(getColumnIndex(paramString1), paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 4207 */     updateBytes(getColumnIndex(paramString), paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(String paramString, Date paramDate) throws SQLException {
/* 4217 */     updateDate(getColumnIndex(paramString), paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(String paramString, Time paramTime) throws SQLException {
/* 4227 */     updateTime(getColumnIndex(paramString), paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String paramString, Object paramObject) throws SQLException {
/* 4238 */     updateObject(getColumnIndex(paramString), paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(String paramString, Object paramObject, int paramInt) throws SQLException {
/* 4248 */     updateObject(getColumnIndex(paramString), paramObject, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 4275 */     Object object = getObject(paramInt);
/*      */     
/* 4277 */     if (object == null) {
/* 4278 */       return (URL)object;
/*      */     }
/* 4280 */     if (object instanceof URL) {
/* 4281 */       return (URL)object;
/*      */     }
/* 4283 */     if (object instanceof String) {
/*      */       
/*      */       try {
/*      */         
/* 4287 */         return new URL((String)object);
/*      */       }
/* 4289 */       catch (MalformedURLException malformedURLException) {
/*      */ 
/*      */         
/* 4292 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136);
/* 4293 */         sQLException1.fillInStackTrace();
/* 4294 */         throw sQLException1;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 4300 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 4301 */     sQLException.fillInStackTrace();
/* 4302 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String paramString) throws SQLException {
/* 4328 */     return getURL(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRef(int paramInt, Ref paramRef) throws SQLException {
/* 4351 */     updateObject(paramInt, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRef(String paramString, Ref paramRef) throws SQLException {
/* 4375 */     updateRef(getColumnIndex(paramString), paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(int paramInt, Blob paramBlob) throws SQLException {
/* 4399 */     updateObject(paramInt, paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(String paramString, Blob paramBlob) throws SQLException {
/* 4423 */     updateBlob(getColumnIndex(paramString), paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int paramInt, Clob paramClob) throws SQLException {
/* 4447 */     updateObject(paramInt, paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(String paramString, Clob paramClob) throws SQLException {
/* 4471 */     updateClob(getColumnIndex(paramString), paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateArray(int paramInt, Array paramArray) throws SQLException {
/* 4495 */     updateObject(paramInt, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateArray(String paramString, Array paramArray) throws SQLException {
/* 4519 */     updateArray(getColumnIndex(paramString), paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] getKeyColumns() throws SQLException {
/* 4545 */     return this.keyColumns;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setKeyColumns(int[] paramArrayOfint) throws SQLException {
/* 4570 */     int i = 0;
/*      */     
/* 4572 */     if (this.rowsetMetaData != null) {
/*      */       
/* 4574 */       i = this.rowsetMetaData.getColumnCount();
/* 4575 */       if (paramArrayOfint == null || paramArrayOfint.length > i) {
/*      */ 
/*      */         
/* 4578 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 324);
/* 4579 */         sQLException.fillInStackTrace();
/* 4580 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 4585 */     int j = paramArrayOfint.length;
/* 4586 */     this.keyColumns = new int[j];
/*      */     
/* 4588 */     for (byte b = 0; b < j; b++) {
/*      */       
/* 4590 */       if (paramArrayOfint[b] <= 0 || paramArrayOfint[b] > i) {
/*      */ 
/*      */         
/* 4593 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "" + paramArrayOfint[b]);
/* 4594 */         sQLException.fillInStackTrace();
/* 4595 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 4599 */       this.keyColumns[b] = paramArrayOfint[b];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getPageSize() {
/* 4614 */     return this.pageSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPageSize(int paramInt) throws SQLException {
/* 4634 */     if (paramInt < 0 || (this.maxRows > 0 && paramInt > this.maxRows)) {
/*      */ 
/*      */ 
/*      */       
/* 4638 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 325);
/* 4639 */       sQLException.fillInStackTrace();
/* 4640 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4644 */     this.pageSize = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SyncProvider getSyncProvider() throws SQLException {
/* 4662 */     return this.syncProvider;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSyncProvider(String paramString) throws SQLException {
/* 4680 */     this.syncProvider = SyncFactory.getInstance(paramString);
/* 4681 */     this.reader = this.syncProvider.getRowSetReader();
/* 4682 */     this.writer = this.syncProvider.getRowSetWriter();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getTableName() throws SQLException {
/* 4702 */     return this.tableName;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTableName(String paramString) throws SQLException {
/* 4721 */     this.tableName = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CachedRowSet createCopyNoConstraints() throws SQLException {
/* 4749 */     OracleCachedRowSet oracleCachedRowSet = (OracleCachedRowSet)createCopy();
/*      */ 
/*      */ 
/*      */     
/* 4753 */     oracleCachedRowSet.initializeProperties();
/*      */ 
/*      */     
/* 4756 */     oracleCachedRowSet.listener = new Vector();
/*      */ 
/*      */     
/*      */     try {
/* 4760 */       oracleCachedRowSet.unsetMatchColumn(oracleCachedRowSet.getMatchColumnIndexes());
/* 4761 */       oracleCachedRowSet.unsetMatchColumn(oracleCachedRowSet.getMatchColumnNames());
/*      */     }
/* 4763 */     catch (SQLException sQLException) {}
/*      */ 
/*      */ 
/*      */     
/* 4767 */     return oracleCachedRowSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CachedRowSet createCopySchema() throws SQLException {
/* 4790 */     OracleCachedRowSet oracleCachedRowSet = (OracleCachedRowSet)createCopy();
/*      */ 
/*      */     
/* 4793 */     oracleCachedRowSet.rows = null;
/* 4794 */     oracleCachedRowSet.rowCount = 0;
/* 4795 */     oracleCachedRowSet.currentPage = 0;
/*      */     
/* 4797 */     return oracleCachedRowSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean columnUpdated(int paramInt) throws SQLException {
/* 4816 */     if (this.insertRowFlag) {
/*      */ 
/*      */       
/* 4819 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 326);
/* 4820 */       sQLException.fillInStackTrace();
/* 4821 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 4825 */     return getCurrentRow().isColumnChanged(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean columnUpdated(String paramString) throws SQLException {
/* 4844 */     return columnUpdated(getColumnIndex(paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void execute(Connection paramConnection) throws SQLException {
/* 4876 */     this.connection = paramConnection;
/* 4877 */     execute();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void commit() throws SQLException {
/* 4905 */     getConnectionInternal().commit();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rollback() throws SQLException {
/* 4925 */     getConnectionInternal().rollback();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rollback(Savepoint paramSavepoint) throws SQLException {
/* 4948 */     Connection connection = getConnectionInternal();
/* 4949 */     boolean bool = connection.getAutoCommit();
/*      */     
/*      */     try {
/* 4952 */       connection.setAutoCommit(false);
/* 4953 */       connection.rollback(paramSavepoint);
/*      */     } finally {
/*      */       
/* 4956 */       connection.setAutoCommit(bool);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void oracleRollback(OracleSavepoint paramOracleSavepoint) throws SQLException {
/* 4982 */     ((OracleConnection)getConnectionInternal()).oracleRollback(paramOracleSavepoint);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOriginalRow() throws SQLException {
/* 5004 */     if (this.insertRowFlag) {
/*      */ 
/*      */       
/* 5007 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 327);
/* 5008 */       sQLException.fillInStackTrace();
/* 5009 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 5014 */     setOriginalRowInternal(this.presentRow);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int size() {
/* 5029 */     return this.rowCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean nextPage() throws SQLException {
/* 5050 */     if (this.fetchDirection == 1001 && this.resultSet != null && this.resultSet.getType() == 1003) {
/*      */ 
/*      */       
/* 5053 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 328);
/* 5054 */       sQLException.fillInStackTrace();
/* 5055 */       throw sQLException;
/*      */     } 
/*      */     
/* 5058 */     if (this.rows.size() == 0 && !this.isPopulateDone) {
/*      */       
/* 5060 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 329);
/* 5061 */       sQLException.fillInStackTrace();
/* 5062 */       throw sQLException;
/*      */     } 
/*      */     
/* 5065 */     if ((isExecuteCalled() || this.isPopulateDone) && this.rowCount < this.pageSize) {
/* 5066 */       return false;
/*      */     }
/* 5068 */     if (isExecuteCalled()) {
/*      */       
/* 5070 */       this.currentPage++;
/* 5071 */       execute();
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 5076 */       populate(this.resultSet);
/* 5077 */       this.currentPage++;
/*      */     } 
/*      */     
/* 5080 */     return !this.isPopulateDone;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean previousPage() throws SQLException {
/* 5101 */     if (this.resultSet != null && this.resultSet.getType() == 1003) {
/*      */       
/* 5103 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 328);
/* 5104 */       sQLException.fillInStackTrace();
/* 5105 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 5109 */     if (this.rows.size() == 0 && !this.isPopulateDone) {
/*      */       
/* 5111 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 329);
/* 5112 */       sQLException.fillInStackTrace();
/* 5113 */       throw sQLException;
/*      */     } 
/*      */     
/* 5116 */     if (this.currentPage == 0) {
/* 5117 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 5121 */     if (this.fetchDirection == 1001) {
/*      */       
/* 5123 */       this.resultSet.relative(this.pageSize * 2);
/*      */     }
/*      */     else {
/*      */       
/* 5127 */       this.resultSet.relative(-2 * this.pageSize);
/*      */     } 
/*      */     
/* 5130 */     populate(this.resultSet);
/*      */     
/* 5132 */     if (this.currentPage > 0)
/*      */     {
/* 5134 */       this.currentPage--;
/*      */     }
/*      */     
/* 5137 */     return (this.currentPage != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rowSetPopulated(RowSetEvent paramRowSetEvent, int paramInt) throws SQLException {
/* 5146 */     if (paramInt <= 0 || paramInt < this.fetchSize) {
/*      */ 
/*      */       
/* 5149 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 330);
/* 5150 */       sQLException.fillInStackTrace();
/* 5151 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 5155 */     if (this.rowCount % paramInt == 0) {
/*      */       
/* 5157 */       this.rowsetEvent = new RowSetEvent(this);
/* 5158 */       notifyRowSetChanged();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RowSetWarning getRowSetWarnings() throws SQLException {
/* 5169 */     return this.rowsetWarning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void populate(ResultSet paramResultSet, int paramInt) throws SQLException {
/* 5178 */     if (paramInt < 0) {
/*      */       
/* 5180 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 331);
/* 5181 */       sQLException.fillInStackTrace();
/* 5182 */       throw sQLException;
/*      */     } 
/*      */     
/* 5185 */     if (paramResultSet == null) {
/*      */       
/* 5187 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 332);
/* 5188 */       sQLException.fillInStackTrace();
/* 5189 */       throw sQLException;
/*      */     } 
/*      */     
/* 5192 */     int i = paramResultSet.getType();
/*      */     
/* 5194 */     if (i == 1003) {
/*      */       
/* 5196 */       byte b = 0;
/* 5197 */       boolean bool = false;
/* 5198 */       while (b < paramInt) {
/*      */         
/* 5200 */         if (!paramResultSet.next()) {
/*      */           
/* 5202 */           bool = true;
/*      */           break;
/*      */         } 
/* 5205 */         b++;
/*      */       } 
/*      */       
/* 5208 */       if (b < paramInt && paramInt > 0 && bool)
/*      */       {
/* 5210 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 333);
/* 5211 */         sQLException.fillInStackTrace();
/* 5212 */         throw sQLException;
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 5217 */     else if (paramInt == 0) {
/* 5218 */       paramResultSet.beforeFirst();
/*      */     } else {
/* 5220 */       paramResultSet.absolute(paramInt);
/*      */     } 
/*      */     
/* 5223 */     populate(paramResultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void undoDelete() throws SQLException {
/* 5233 */     cancelRowDelete();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void undoInsert() throws SQLException {
/* 5243 */     cancelRowInsert();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void undoUpdate() throws SQLException {
/* 5253 */     cancelRowUpdates();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 5263 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/rowset/OracleCachedRowSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */