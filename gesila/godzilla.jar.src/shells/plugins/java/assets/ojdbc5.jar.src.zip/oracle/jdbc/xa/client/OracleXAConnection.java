/*     */ package oracle.jdbc.xa.client;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import oracle.jdbc.xa.OracleXAConnection;
/*     */ import oracle.jdbc.xa.OracleXAResource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleXAConnection
/*     */   extends OracleXAConnection
/*     */ {
/*     */   protected boolean isXAResourceTransLoose = false;
/*     */   
/*     */   public OracleXAConnection() throws XAException {}
/*     */   
/*     */   public OracleXAConnection(Connection paramConnection) throws XAException {
/*  63 */     super(paramConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized XAResource getXAResource() {
/*     */     try {
/*  81 */       if (this.xaResource == null)
/*     */       {
/*  83 */         this.xaResource = (XAResource)new OracleXAResource((Connection)this.physicalConn, this);
/*  84 */         ((OracleXAResource)this.xaResource).isTransLoose = this.isXAResourceTransLoose;
/*     */         
/*  86 */         if (this.logicalHandle != null)
/*     */         {
/*     */ 
/*     */           
/*  90 */           ((OracleXAResource)this.xaResource).setLogicalConnection((Connection)this.logicalHandle);
/*     */         }
/*     */       }
/*     */     
/*  94 */     } catch (XAException xAException) {
/*     */       
/*  96 */       this.xaResource = null;
/*     */     } 
/*     */     
/*  99 */     return this.xaResource;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 104 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/xa/client/OracleXAConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */