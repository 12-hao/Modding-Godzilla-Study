/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CNumberAccessor
/*     */   extends NumberAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   boolean underlyingLongRaw = false;
/*     */   final int[] meta;
/*     */   
/*     */   T4CNumberAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  45 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; } T4CNumberAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, (paramInt1 == -1) ? paramInt8 : paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) {
/*     */       this.definedColumnType = 0;
/*     */       this.definedColumnSize = 0;
/*     */     } else {
/*     */       this.definedColumnType = paramInt7;
/*     */       this.definedColumnSize = paramInt8;
/*     */     } 
/*     */     if (paramInt1 == -1) {
/*     */       this.underlyingLongRaw = true;
/*     */     } }
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/*     */     String str = super.getString(paramInt);
/*     */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/*     */       str = str.substring(0, this.definedColumnSize); 
/*     */     return str;
/*     */   }
/*     */   
/*     */   boolean unmarshalOneRow() throws SQLException, IOException {
/* 152 */     if (this.isUseLess) {
/*     */       
/* 154 */       this.lastRowProcessed++;
/*     */       
/* 156 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 161 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 165 */       byte[] arrayOfByte = new byte[16000];
/*     */       
/* 167 */       this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/* 168 */       processIndicator(this.meta[0]);
/*     */       
/* 170 */       this.lastRowProcessed++;
/*     */       
/* 172 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 176 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 177 */     int j = this.lengthIndex + this.lastRowProcessed;
/*     */ 
/*     */ 
/*     */     
/* 181 */     if (this.isNullByDescribe) {
/*     */       
/* 183 */       this.rowSpaceIndicator[i] = -1;
/* 184 */       this.rowSpaceIndicator[j] = 0;
/* 185 */       this.lastRowProcessed++;
/*     */       
/* 187 */       if (this.statement.connection.versionNumber < 9200) {
/* 188 */         processIndicator(0);
/*     */       }
/* 190 */       return false;
/*     */     } 
/*     */     
/* 193 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*     */ 
/*     */ 
/*     */     
/* 197 */     this.mare.unmarshalCLR(this.rowSpaceByte, k + 1, this.meta, this.byteLength - 1);
/*     */ 
/*     */ 
/*     */     
/* 201 */     this.rowSpaceByte[k] = (byte)this.meta[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 207 */     processIndicator(this.meta[0]);
/*     */     
/* 209 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 213 */       this.rowSpaceIndicator[i] = -1;
/* 214 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 218 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 223 */       this.rowSpaceIndicator[i] = 0;
/*     */     } 
/*     */     
/* 226 */     this.lastRowProcessed++;
/*     */     
/* 228 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copyRow() throws SQLException, IOException {
/*     */     int i;
/* 238 */     if (this.lastRowProcessed == 0) {
/* 239 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 241 */       i = this.lastRowProcessed - 1;
/*     */     } 
/*     */     
/* 244 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/* 245 */     int k = this.columnIndex + i * this.byteLength;
/* 246 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 247 */     int n = this.indicatorIndex + i;
/* 248 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 249 */     int i2 = this.lengthIndex + i;
/* 250 */     short s = this.rowSpaceIndicator[i2];
/* 251 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 253 */     int i4 = this.metaDataIndex + i * 1;
/*     */ 
/*     */ 
/*     */     
/* 257 */     this.rowSpaceIndicator[i1] = (short)s;
/* 258 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */ 
/*     */     
/* 261 */     if (!this.isNullByDescribe)
/*     */     {
/* 263 */       System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s + 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 268 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*     */ 
/*     */     
/* 271 */     this.lastRowProcessed++; } void processIndicator(int paramInt) throws IOException, SQLException {
/*     */     if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2();
/*     */       this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     } 
/*     */   } void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/* 283 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*     */     
/* 285 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*     */     
/* 287 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 288 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 289 */     int n = this.lengthIndex + paramInt2 - 1;
/* 290 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 291 */     short s = paramArrayOfshort[i1];
/*     */     
/* 293 */     this.rowSpaceIndicator[n] = (short)s;
/* 294 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*     */ 
/*     */     
/* 297 */     if (s != 0)
/*     */     {
/* 299 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 312 */     if (this.definedColumnType == 0) {
/* 313 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 316 */     Object object = null;
/*     */     
/* 318 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 320 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 321 */       sQLException.fillInStackTrace();
/* 322 */       throw sQLException;
/*     */     } 
/*     */     
/* 325 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 327 */       switch (this.definedColumnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case -1:
/*     */         case 1:
/*     */         case 12:
/* 338 */           return getString(paramInt);
/*     */ 
/*     */         
/*     */         case 2:
/*     */         case 3:
/* 343 */           return getBigDecimal(paramInt);
/*     */         
/*     */         case 4:
/* 346 */           return Integer.valueOf(getInt(paramInt));
/*     */         
/*     */         case -6:
/* 349 */           return Byte.valueOf(getByte(paramInt));
/*     */         
/*     */         case 5:
/* 352 */           return Short.valueOf(getShort(paramInt));
/*     */ 
/*     */         
/*     */         case -7:
/*     */         case 16:
/* 357 */           return Boolean.valueOf(getBoolean(paramInt));
/*     */         
/*     */         case -5:
/* 360 */           return Long.valueOf(getLong(paramInt));
/*     */         
/*     */         case 7:
/* 363 */           return Float.valueOf(getFloat(paramInt));
/*     */ 
/*     */         
/*     */         case 6:
/*     */         case 8:
/* 368 */           return Double.valueOf(getDouble(paramInt));
/*     */         
/*     */         case 91:
/* 371 */           return getDate(paramInt);
/*     */         
/*     */         case 92:
/* 374 */           return getTime(paramInt);
/*     */         
/*     */         case 93:
/* 377 */           return getTimestamp(paramInt);
/*     */ 
/*     */ 
/*     */         
/*     */         case -4:
/*     */         case -3:
/*     */         case -2:
/* 384 */           return getBytes(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 388 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 389 */       sQLException.fillInStackTrace();
/* 390 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 396 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 402 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/T4CNumberAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */