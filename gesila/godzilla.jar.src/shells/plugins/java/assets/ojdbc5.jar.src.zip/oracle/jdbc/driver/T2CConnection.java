/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.ByteOrder;
/*      */ import java.nio.CharBuffer;
/*      */ import java.security.AccessController;
/*      */ import java.security.PrivilegedAction;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Properties;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.OracleOCIFailover;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.jdbc.oracore.OracleTypeADT;
/*      */ import oracle.jdbc.oracore.OracleTypeCLOB;
/*      */ import oracle.jdbc.pool.OracleOCIConnectionPool;
/*      */ import oracle.jdbc.pool.OraclePooledConnection;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.BfileDBAccess;
/*      */ import oracle.sql.BlobDBAccess;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.ClobDBAccess;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.LobPlsqlUtil;
/*      */ import oracle.sql.NCLOB;
/*      */ import oracle.sql.SQLName;
/*      */ import oracle.sql.ZONEIDMAP;
/*      */ import oracle.sql.converter.CharacterSetMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class T2CConnection
/*      */   extends PhysicalConnection
/*      */   implements BfileDBAccess, BlobDBAccess, ClobDBAccess
/*      */ {
/*   60 */   static final long JDBC_OCI_LIBRARY_VERSION = Long.parseLong("11.2.0.4.0".replaceAll("\\.", ""));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   66 */   short[] queryMetaData1 = null;
/*   67 */   byte[] queryMetaData2 = null;
/*   68 */   int queryMetaData1Offset = 0;
/*   69 */   int queryMetaData2Offset = 0;
/*      */   private String password;
/*   71 */   int fatalErrorNumber = 0;
/*   72 */   String fatalErrorMessage = null;
/*      */   
/*      */   static final int QMD_dbtype = 0;
/*      */   
/*      */   static final int QMD_dbsize = 1;
/*      */   
/*      */   static final int QMD_nullok = 2;
/*      */   
/*      */   static final int QMD_precision = 3;
/*      */   
/*      */   static final int QMD_scale = 4;
/*      */   
/*      */   static final int QMD_formOfUse = 5;
/*      */   
/*      */   static final int QMD_columnNameLength = 6;
/*      */   
/*      */   static final int QMD_tdo0 = 7;
/*      */   
/*      */   static final int QMD_tdo1 = 8;
/*      */   
/*      */   static final int QMD_tdo2 = 9;
/*      */   
/*      */   static final int QMD_tdo3 = 10;
/*      */   
/*      */   static final int QMD_charLength = 11;
/*      */   
/*      */   static final int QMD_typeNameLength = 12;
/*      */   
/*      */   static final int T2C_LOCATOR_MAX_LEN = 16;
/*      */   static final int T2C_LINEARIZED_LOCATOR_MAX_LEN = 4000;
/*      */   static final int T2C_LINEARIZED_BFILE_LOCATOR_MAX_LEN = 530;
/*      */   static final int METADATA1_INDICES_PER_COLUMN = 13;
/*      */   protected static final int SIZEOF_QUERYMETADATA2 = 8;
/*      */   static final String defaultDriverNameAttribute = "jdbcoci";
/*  106 */   int queryMetaData1Size = 100;
/*  107 */   int queryMetaData2Size = 800;
/*      */   
/*      */   long m_nativeState;
/*      */   
/*      */   short m_clientCharacterSet;
/*      */   
/*      */   byte byteAlign;
/*      */   
/*      */   private static final int EOJ_SUCCESS = 0;
/*      */   
/*      */   private static final int EOJ_ERROR = -1;
/*      */   
/*      */   private static final int EOJ_WARNING = 1;
/*      */   
/*      */   private static final int EOJ_GET_STORAGE_ERROR = -4;
/*      */   
/*      */   private static final int EOJ_ORA3113_SERVER_NORMAL = -6;
/*      */   
/*      */   private static final String OCILIBRARY = "ocijdbc11";
/*  126 */   private int logon_mode = 0;
/*      */   
/*      */   static final int LOGON_MODE_DEFAULT = 0;
/*      */   
/*      */   static final int LOGON_MODE_SYSDBA = 2;
/*      */   
/*      */   static final int LOGON_MODE_SYSOPER = 4;
/*      */   
/*      */   static final int LOGON_MODE_SYSASM = 32768;
/*      */   
/*      */   static final int LOGON_MODE_SYSBKP = 131072;
/*      */   
/*      */   static final int LOGON_MODE_SYSDGD = 262144;
/*      */   
/*      */   static final int LOGON_MODE_SYSKMT = 524288;
/*      */   
/*      */   static final int LOGON_MODE_CONNECTION_POOL = 5;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_CONNECTION = 6;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_PROXY_CONNECTION = 7;
/*      */   
/*      */   static final int LOGON_MODE_CONNPOOL_ALIASED_CONNECTION = 8;
/*      */   static final int T2C_PROXYTYPE_NONE = 0;
/*      */   static final int T2C_PROXYTYPE_USER_NAME = 1;
/*      */   static final int T2C_PROXYTYPE_DISTINGUISHED_NAME = 2;
/*      */   static final int T2C_PROXYTYPE_CERTIFICATE = 3;
/*      */   static final int T2C_CONNECTION_FLAG_DEFAULT_LOB_PREFETCH = 0;
/*      */   static final int T2C_CONNECTION_FLAG_PRELIM_AUTH = 1;
/*      */   private static boolean isLibraryLoaded;
/*  156 */   OracleOCIFailover appCallback = null;
/*  157 */   Object appCallbackObject = null;
/*      */   
/*      */   private Properties nativeInfo;
/*      */   
/*      */   ByteBuffer nioBufferForLob;
/*      */ 
/*      */   
/*      */   protected T2CConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException {
/*  165 */     super(paramString, paramProperties, paramOracleDriverExtension);
/*      */ 
/*      */     
/*  168 */     initialize();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void initializePassword(String paramString) throws SQLException {
/*  175 */     this.password = paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void initialize() {
/*  182 */     allocQueryMetaDataBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void allocQueryMetaDataBuffers() {
/*  214 */     this.queryMetaData1Offset = 0;
/*  215 */     this.queryMetaData1 = new short[this.queryMetaData1Size * 13];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  220 */     this.queryMetaData2Offset = 0;
/*  221 */     this.queryMetaData2 = new byte[this.queryMetaData2Size];
/*      */     
/*  223 */     this.namedTypeAccessorByteLen = 0;
/*  224 */     this.refTypeAccessorByteLen = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reallocateQueryMetaData(int paramInt1, int paramInt2) {
/*  231 */     this.queryMetaData1 = null;
/*  232 */     this.queryMetaData2 = null;
/*      */     
/*  234 */     this.queryMetaData1Size = Math.max(paramInt1, this.queryMetaData1Size);
/*  235 */     this.queryMetaData2Size = Math.max(paramInt2, this.queryMetaData2Size);
/*      */     
/*  237 */     allocQueryMetaDataBuffers();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logon() throws SQLException {
/*  261 */     if (this.database == null) {
/*      */       
/*  263 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 64);
/*  264 */       sQLException.fillInStackTrace();
/*  265 */       throw sQLException;
/*      */     } 
/*      */     
/*  268 */     if (!isLibraryLoaded) {
/*  269 */       loadNativeLibrary();
/*      */     }
/*      */ 
/*      */     
/*  273 */     if (this.ociConnectionPoolIsPooling) {
/*      */       
/*  275 */       processOCIConnectionPooling();
/*      */     }
/*      */     else {
/*      */       
/*  279 */       long l1 = this.ociSvcCtxHandle;
/*  280 */       long l2 = this.ociEnvHandle;
/*  281 */       long l3 = this.ociErrHandle;
/*      */ 
/*      */       
/*  284 */       if (l1 != 0L && l2 != 0L) {
/*      */ 
/*      */         
/*  287 */         if (this.ociDriverCharset != null) {
/*  288 */           this.m_clientCharacterSet = (new Integer(this.ociDriverCharset)).shortValue();
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  293 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  294 */           sQLException.fillInStackTrace();
/*  295 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  301 */         this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */         
/*  304 */         short[] arrayOfShort1 = new short[5];
/*  305 */         long[] arrayOfLong1 = { this.defaultLobPrefetchSize };
/*      */         
/*  307 */         this.sqlWarning = checkError(t2cUseConnection(this.m_nativeState, l2, l1, l3, arrayOfShort1, arrayOfLong1), this.sqlWarning);
/*      */ 
/*      */ 
/*      */         
/*  311 */         this.conversion = new DBConversion(arrayOfShort1[0], this.m_clientCharacterSet, arrayOfShort1[1]);
/*  312 */         this.byteAlign = (byte)(arrayOfShort1[2] & 0xFF);
/*  313 */         this.timeZoneVersionNumber = (arrayOfShort1[3] << 16) + (arrayOfShort1[4] & 0xFFFF);
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */ 
/*      */       
/*  320 */       if (this.internalLogon == null) {
/*  321 */         this.logon_mode = 0;
/*  322 */       } else if (this.internalLogon.equalsIgnoreCase("SYSDBA")) {
/*  323 */         this.logon_mode = 2;
/*  324 */       } else if (this.internalLogon.equalsIgnoreCase("SYSOPER")) {
/*  325 */         this.logon_mode = 4;
/*  326 */       } else if (this.internalLogon.equalsIgnoreCase("SYSASM")) {
/*  327 */         this.logon_mode = 32768;
/*  328 */       } else if (this.internalLogon.equalsIgnoreCase("SYSBACKUP")) {
/*  329 */         this.logon_mode = 131072;
/*  330 */       } else if (this.internalLogon.equalsIgnoreCase("SYSDG")) {
/*  331 */         this.logon_mode = 262144;
/*  332 */       } else if (this.internalLogon.equalsIgnoreCase("SYSKM")) {
/*  333 */         this.logon_mode = 524288;
/*      */       } 
/*  335 */       byte[] arrayOfByte1 = null;
/*  336 */       byte[] arrayOfByte2 = null;
/*  337 */       byte[] arrayOfByte3 = null;
/*  338 */       String str1 = this.setNewPassword;
/*  339 */       byte[] arrayOfByte4 = new byte[0];
/*  340 */       byte[] arrayOfByte5 = new byte[0];
/*  341 */       byte[] arrayOfByte6 = new byte[0];
/*      */       
/*  343 */       if (this.nlsLangBackdoor) {
/*      */ 
/*      */         
/*  346 */         this.m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG();
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  351 */         this.m_clientCharacterSet = getClientCharSetId();
/*      */       } 
/*      */       
/*  354 */       if (str1 != null) {
/*  355 */         arrayOfByte4 = DBConversion.stringToDriverCharBytes(str1, this.m_clientCharacterSet);
/*      */       }
/*  357 */       if (this.editionName != null) {
/*  358 */         arrayOfByte5 = DBConversion.stringToDriverCharBytes(this.editionName, this.m_clientCharacterSet);
/*      */       }
/*  360 */       if (this.driverNameAttribute == null) {
/*  361 */         arrayOfByte6 = DBConversion.stringToDriverCharBytes("jdbcoci", this.m_clientCharacterSet);
/*      */       } else {
/*  363 */         arrayOfByte6 = DBConversion.stringToDriverCharBytes(this.driverNameAttribute, this.m_clientCharacterSet);
/*      */       } 
/*  365 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */       
/*  368 */       arrayOfByte2 = (this.proxyClientName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.proxyClientName, this.m_clientCharacterSet);
/*      */ 
/*      */       
/*  371 */       arrayOfByte3 = (this.password == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.password, this.m_clientCharacterSet);
/*      */ 
/*      */       
/*  374 */       byte[] arrayOfByte7 = DBConversion.stringToDriverCharBytes(this.database, this.m_clientCharacterSet);
/*      */       
/*  376 */       short[] arrayOfShort = new short[5];
/*  377 */       String str2 = null;
/*  378 */       byte[] arrayOfByte8 = ((str2 = CharacterSetMetaData.getNLSLanguage(ClassRef.LOCALE.getDefault())) != null) ? str2.getBytes() : null;
/*      */       
/*  380 */       byte[] arrayOfByte9 = ((str2 = CharacterSetMetaData.getNLSTerritory(ClassRef.LOCALE.getDefault())) != null) ? str2.getBytes() : null;
/*      */ 
/*      */       
/*  383 */       if (arrayOfByte8 == null || arrayOfByte9 == null) {
/*      */         
/*  385 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/*  386 */         sQLException.fillInStackTrace();
/*  387 */         throw sQLException;
/*      */       } 
/*      */       
/*  390 */       TimeZone timeZone = TimeZone.getDefault();
/*  391 */       String str3 = timeZone.getID();
/*      */       
/*  393 */       if (!ZONEIDMAP.isValidRegion(str3) || !this.timezoneAsRegion) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  402 */         int i = timeZone.getOffset(System.currentTimeMillis());
/*  403 */         int j = i / 3600000;
/*  404 */         int k = i / 60000 % 60;
/*      */         
/*  406 */         str3 = ((j < 0) ? ("" + j) : ("+" + j)) + ((k < 10) ? (":0" + k) : (":" + k));
/*      */       } 
/*      */ 
/*      */       
/*  410 */       doSetSessionTimeZone(str3);
/*      */ 
/*      */       
/*  413 */       this.sessionTimeZone = str3;
/*      */ 
/*      */       
/*  416 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/*  419 */       long[] arrayOfLong = { this.defaultLobPrefetchSize, (this.prelimAuth ? 1L : 0L) };
/*      */       
/*  421 */       if (this.m_nativeState == 0L) {
/*      */         
/*  423 */         this.sqlWarning = checkError(t2cCreateState(arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, arrayOfByte6, arrayOfByte6.length, arrayOfByte7, arrayOfByte7.length, this.m_clientCharacterSet, this.logon_mode, arrayOfShort, arrayOfByte8, arrayOfByte9, this.retainV9BindBehavior, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  440 */         this.sqlWarning = checkError(t2cLogon(this.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, arrayOfByte6, arrayOfByte6.length, arrayOfByte7, arrayOfByte7.length, this.logon_mode, arrayOfShort, arrayOfByte8, arrayOfByte9, arrayOfLong), this.sqlWarning);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  454 */       this.conversion = new DBConversion(arrayOfShort[0], this.m_clientCharacterSet, arrayOfShort[1]);
/*  455 */       this.byteAlign = (byte)(arrayOfShort[2] & 0xFF);
/*  456 */       this.timeZoneVersionNumber = (arrayOfShort[3] << 16) + (arrayOfShort[4] & 0xFFFF);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void logoff() throws SQLException {
/*      */     try {
/*  475 */       if (this.lifecycle == 2)
/*      */       {
/*  477 */         checkError(t2cLogoff(this.m_nativeState));
/*      */       }
/*  479 */     } catch (NullPointerException nullPointerException) {}
/*      */ 
/*      */     
/*  482 */     this.m_nativeState = 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void open(OracleStatement paramOracleStatement) throws SQLException {
/*  500 */     byte[] arrayOfByte = paramOracleStatement.sqlObject.getSql(paramOracleStatement.processEscapes, paramOracleStatement.convertNcharLiterals).getBytes();
/*      */ 
/*      */     
/*  503 */     checkError(t2cCreateStatement(this.m_nativeState, 0L, arrayOfByte, arrayOfByte.length, paramOracleStatement, false, paramOracleStatement.rowPrefetch));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cancelOperationOnServer(boolean paramBoolean) throws SQLException {
/*  519 */     checkError(t2cCancel(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cAbort(long paramLong);
/*      */ 
/*      */   
/*      */   void doAbort() throws SQLException {
/*  528 */     checkError(t2cAbort(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doSetAutoCommit(boolean paramBoolean) throws SQLException {
/*  545 */     checkError(t2cSetAutoCommit(this.m_nativeState, paramBoolean));
/*  546 */     this.autocommit = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doCommit(int paramInt) throws SQLException {
/*  562 */     checkError(t2cCommit(this.m_nativeState, paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doRollback() throws SQLException {
/*  578 */     checkError(t2cRollback(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized int doPingDatabase() throws SQLException {
/*  585 */     if (t2cPingDatabase(this.m_nativeState) == 0) {
/*  586 */       return 0;
/*      */     }
/*  588 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected String doGetDatabaseProductVersion() throws SQLException {
/*  595 */     byte[] arrayOfByte = t2cGetProductionVersion(this.m_nativeState);
/*      */     
/*  597 */     return this.conversion.CharBytesToString(arrayOfByte, arrayOfByte.length);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected short doGetVersionNumber() throws SQLException {
/*  604 */     short s = 0;
/*      */ 
/*      */     
/*      */     try {
/*  608 */       String str1 = doGetDatabaseProductVersion();
/*      */       
/*  610 */       StringTokenizer stringTokenizer = new StringTokenizer(str1.trim(), " .", false);
/*  611 */       String str2 = null;
/*  612 */       byte b = 0;
/*  613 */       short s1 = 0;
/*      */       
/*  615 */       while (stringTokenizer.hasMoreTokens())
/*      */       {
/*  617 */         str2 = stringTokenizer.nextToken();
/*      */ 
/*      */         
/*      */         try {
/*  621 */           s1 = Integer.decode(str2).shortValue();
/*  622 */           s = (short)(s * 10 + s1);
/*  623 */           b++;
/*      */ 
/*      */           
/*  626 */           if (b == 4) {
/*      */             break;
/*      */           }
/*  629 */         } catch (NumberFormatException numberFormatException) {}
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*  635 */     catch (NoSuchElementException noSuchElementException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  641 */     if (s == -1) {
/*  642 */       s = 0;
/*      */     }
/*      */     
/*  645 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ClobDBAccess createClobDBAccess() {
/*  652 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BlobDBAccess createBlobDBAccess() {
/*  659 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BfileDBAccess createBfileDBAccess() {
/*  666 */     return this;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected SQLWarning checkError(int paramInt) throws SQLException {
/*  673 */     return checkError(paramInt, (SQLWarning)null);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected SQLWarning checkError(int paramInt, SQLWarning paramSQLWarning) throws SQLException {
/*      */     T2CError t2CError;
/*      */     SQLException sQLException;
/*      */     int i;
/*      */     String str;
/*  683 */     switch (paramInt) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -1:
/*      */       case 1:
/*  691 */         t2CError = new T2CError();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  697 */         i = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  702 */         if (this.lifecycle == 1 || this.lifecycle == 16) {
/*      */           
/*  704 */           i = t2cDescribeError(this.m_nativeState, t2CError, t2CError.m_errorMessage);
/*      */         } else {
/*      */           
/*  707 */           if (this.fatalErrorNumber != 0) {
/*      */ 
/*      */             
/*  710 */             SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 269);
/*  711 */             sQLException2.fillInStackTrace();
/*  712 */             throw sQLException2;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  717 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  718 */           sQLException1.fillInStackTrace();
/*  719 */           throw sQLException1;
/*      */         } 
/*      */         
/*  722 */         str = null;
/*  723 */         if (i != -1) {
/*      */ 
/*      */ 
/*      */           
/*  727 */           byte b = 0;
/*      */           
/*  729 */           while (b < t2CError.m_errorMessage.length && t2CError.m_errorMessage[b] != 0) {
/*  730 */             b++;
/*      */           }
/*  732 */           if (this.conversion == null) throw new Error("conversion == null"); 
/*  733 */           if (t2CError == null) throw new Error("l_error == null"); 
/*  734 */           str = this.conversion.CharBytesToString(t2CError.m_errorMessage, b, true);
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  741 */         switch (t2CError.m_errorNumber) {
/*      */           
/*      */           case 28:
/*      */           case 600:
/*      */           case 1012:
/*      */           case 1041:
/*  747 */             internalClose();
/*      */             break;
/*      */ 
/*      */           
/*      */           case 902:
/*  752 */             removeAllDescriptor();
/*      */             break;
/*      */           
/*      */           case 3113:
/*      */           case 3114:
/*  757 */             setUsable(false);
/*  758 */             close();
/*      */             break;
/*      */           case -6:
/*  761 */             t2CError.m_errorNumber = 3113;
/*      */             break;
/*      */         } 
/*      */ 
/*      */         
/*  766 */         if (i == -1) {
/*      */           
/*  768 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Fetch error message failed!");
/*  769 */           sQLException1.fillInStackTrace();
/*  770 */           throw sQLException1;
/*      */         } 
/*      */         
/*  773 */         if (paramInt == -1) {
/*      */ 
/*      */           
/*  776 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), str, t2CError.m_errorNumber);
/*  777 */           sQLException1.fillInStackTrace();
/*  778 */           throw sQLException1;
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  783 */         paramSQLWarning = DatabaseError.addSqlWarning(paramSQLWarning, str, t2CError.m_errorNumber);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case -4:
/*  790 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 254);
/*  791 */         sQLException.fillInStackTrace();
/*  792 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  799 */     return paramSQLWarning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException {
/*  807 */     T2CStatement t2CStatement = new T2CStatement(this, 1, this.defaultRowPrefetch, -1, -1);
/*      */     
/*  809 */     t2CStatement.needToParse = false;
/*  810 */     t2CStatement.serverCursor = true;
/*  811 */     t2CStatement.isOpen = true;
/*  812 */     t2CStatement.processEscapes = false;
/*      */     
/*  814 */     t2CStatement.prepareForNewResults(true, false);
/*  815 */     t2CStatement.sqlObject.initialize("select unknown as ref cursor from whatever");
/*      */     
/*  817 */     t2CStatement.sqlKind = OracleStatement.SqlKind.SELECT;
/*      */     
/*  819 */     checkError(t2cCreateStatement(this.m_nativeState, paramOracleStatement.c_state, paramArrayOfbyte, paramArrayOfbyte.length, t2CStatement, true, this.defaultRowPrefetch));
/*      */ 
/*      */ 
/*      */     
/*  823 */     paramOracleStatement.addChild(t2CStatement);
/*  824 */     return t2CStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt) throws SQLException {
/*  833 */     boolean bool = false;
/*      */     
/*  835 */     if (paramOracleTypeCLOB != null) {
/*      */       
/*  837 */       String[] arrayOfString1 = new String[1];
/*  838 */       String[] arrayOfString2 = new String[1];
/*      */       
/*  840 */       SQLName.parse(paramOracleTypeADT.getFullName(), arrayOfString1, arrayOfString2, true);
/*      */       
/*  842 */       String str = "\"" + arrayOfString1[0] + "\".\"" + arrayOfString2[0] + "\"";
/*      */ 
/*      */       
/*  845 */       byte[] arrayOfByte = this.conversion.StringToCharBytes(str);
/*      */       
/*  847 */       int i = t2cGetFormOfUse(this.m_nativeState, paramOracleTypeCLOB, arrayOfByte, arrayOfByte.length, paramInt);
/*      */ 
/*      */ 
/*      */       
/*  851 */       if (i < 0) {
/*  852 */         checkError(i);
/*      */       }
/*      */       
/*  855 */       paramOracleTypeCLOB.setForm(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getTdoCState(String paramString1, String paramString2) throws SQLException {
/*  870 */     String str = "\"" + paramString1 + "\".\"" + paramString2 + "\"";
/*  871 */     byte[] arrayOfByte = this.conversion.StringToCharBytes(str);
/*  872 */     int[] arrayOfInt = new int[1];
/*  873 */     long l = t2cGetTDO(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfInt);
/*  874 */     if (l == 0L)
/*      */     {
/*  876 */       checkError(arrayOfInt[0]);
/*      */     }
/*  878 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getDBAccessProperties() throws SQLException {
/*  894 */     return getOCIHandles();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Properties getOCIHandles() throws SQLException {
/*  901 */     if (this.lifecycle != 1) {
/*      */       
/*  903 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  904 */       sQLException.fillInStackTrace();
/*  905 */       throw sQLException;
/*      */     } 
/*      */     
/*  908 */     if (this.nativeInfo == null) {
/*      */       
/*  910 */       long[] arrayOfLong = new long[3];
/*      */ 
/*      */       
/*  913 */       checkError(t2cGetHandles(this.m_nativeState, arrayOfLong));
/*      */ 
/*      */       
/*  916 */       this.nativeInfo = new Properties();
/*      */       
/*  918 */       this.nativeInfo.put("OCIEnvHandle", String.valueOf(arrayOfLong[0]));
/*  919 */       this.nativeInfo.put("OCISvcCtxHandle", String.valueOf(arrayOfLong[1]));
/*  920 */       this.nativeInfo.put("OCIErrHandle", String.valueOf(arrayOfLong[2]));
/*  921 */       this.nativeInfo.put("ClientCharSet", String.valueOf(this.m_clientCharacterSet));
/*      */     } 
/*      */     
/*  924 */     return this.nativeInfo;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getServerSessionInfo() throws SQLException {
/*  931 */     if (this.lifecycle != 1) {
/*      */       
/*  933 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  934 */       sQLException.fillInStackTrace();
/*  935 */       throw sQLException;
/*      */     } 
/*      */     
/*  938 */     if (this.sessionProperties == null) {
/*  939 */       this.sessionProperties = new Properties();
/*      */     }
/*      */ 
/*      */     
/*  943 */     if (getVersionNumber() < 10200) {
/*  944 */       queryFCFProperties(this.sessionProperties);
/*      */     } else {
/*  946 */       checkError(t2cGetServerSessionInfo(this.m_nativeState, this.sessionProperties));
/*      */     } 
/*  948 */     return this.sessionProperties;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException {
/*  954 */     byte b = 0;
/*  955 */     if (paramInstanceProperty == OracleConnection.InstanceProperty.ASM_VOLUME_SUPPORTED) {
/*      */       
/*  957 */       b = t2cGetAsmVolProperty(this.m_nativeState);
/*      */     }
/*  959 */     else if (paramInstanceProperty == OracleConnection.InstanceProperty.INSTANCE_TYPE) {
/*      */       
/*  961 */       b = t2cGetInstanceType(this.m_nativeState);
/*      */     } 
/*  963 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Properties getConnectionPoolInfo() throws SQLException {
/*  973 */     if (this.lifecycle != 1) {
/*      */       
/*  975 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  976 */       sQLException.fillInStackTrace();
/*  977 */       throw sQLException;
/*      */     } 
/*  979 */     Properties properties = new Properties();
/*      */     
/*  981 */     checkError(t2cGetConnPoolInfo(this.m_nativeState, properties));
/*      */     
/*  983 */     return properties;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnectionPoolInfo(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) throws SQLException {
/*  993 */     checkError(t2cSetConnPoolInfo(this.m_nativeState, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void ociPasswordChange(String paramString1, String paramString2, String paramString3) throws SQLException {
/* 1003 */     if (this.lifecycle != 1) {
/*      */       
/* 1005 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 1006 */       sQLException.fillInStackTrace();
/* 1007 */       throw sQLException;
/*      */     } 
/* 1009 */     byte[] arrayOfByte1 = (paramString1 == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString1, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */     
/* 1013 */     byte[] arrayOfByte2 = (paramString2 == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString2, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1016 */     byte[] arrayOfByte3 = (paramString3 == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(paramString3, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1019 */     this.sqlWarning = checkError(t2cPasswordChange(this.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length), this.sqlWarning);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processOCIConnectionPooling() throws SQLException {
/* 1030 */     if (this.lifecycle != 1) {
/*      */       
/* 1032 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 1033 */       sQLException.fillInStackTrace();
/* 1034 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1038 */     T2CConnection t2CConnection = null;
/*      */     
/* 1040 */     if (this.ociConnectionPoolLogonMode == "connection_pool") {
/*      */       
/* 1042 */       if (this.nlsLangBackdoor) {
/*      */ 
/*      */         
/* 1045 */         this.m_clientCharacterSet = getDriverCharSetIdFromNLS_LANG();
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1050 */         this.m_clientCharacterSet = getClientCharSetId();
/*      */       } 
/*      */     } else {
/*      */       
/* 1054 */       t2CConnection = (T2CConnection)this.ociConnectionPoolObject;
/* 1055 */       this.m_clientCharacterSet = t2CConnection.m_clientCharacterSet;
/*      */     } 
/*      */     
/* 1058 */     byte[] arrayOfByte1 = null;
/*      */     
/* 1060 */     byte[] arrayOfByte2 = (this.password == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.password, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1063 */     byte[] arrayOfByte3 = (this.editionName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.editionName, this.m_clientCharacterSet);
/*      */ 
/*      */     
/* 1066 */     byte[] arrayOfByte4 = DBConversion.stringToDriverCharBytes((this.driverNameAttribute == null) ? "jdbcoci" : this.driverNameAttribute, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */     
/* 1070 */     byte[] arrayOfByte5 = DBConversion.stringToDriverCharBytes(this.database, this.m_clientCharacterSet);
/*      */     
/* 1072 */     byte[] arrayOfByte6 = CharacterSetMetaData.getNLSLanguage(ClassRef.LOCALE.getDefault()).getBytes();
/*      */     
/* 1074 */     byte[] arrayOfByte7 = CharacterSetMetaData.getNLSTerritory(ClassRef.LOCALE.getDefault()).getBytes();
/*      */ 
/*      */ 
/*      */     
/* 1078 */     if (arrayOfByte6 == null || arrayOfByte7 == null) {
/*      */       
/* 1080 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 176);
/* 1081 */       sQLException.fillInStackTrace();
/* 1082 */       throw sQLException;
/*      */     } 
/*      */     
/* 1085 */     short[] arrayOfShort = new short[5];
/* 1086 */     long[] arrayOfLong = { this.defaultLobPrefetchSize };
/*      */     
/* 1088 */     if (this.ociConnectionPoolLogonMode == "connection_pool") {
/*      */       
/* 1090 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1096 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1099 */       this.logon_mode = 5;
/*      */       
/* 1101 */       if (this.lifecycle == 1)
/*      */       {
/* 1103 */         int[] arrayOfInt = new int[6];
/*      */         
/* 1105 */         OracleOCIConnectionPool.readPoolConfig(this.ociConnectionPoolMinLimit, this.ociConnectionPoolMaxLimit, this.ociConnectionPoolIncrement, this.ociConnectionPoolTimeout, this.ociConnectionPoolNoWait, this.ociConnectionPoolTransactionDistributed, arrayOfInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1113 */         this.sqlWarning = checkError(t2cCreateConnPool(arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte5, arrayOfByte5.length, this.m_clientCharacterSet, this.logon_mode, arrayOfInt[0], arrayOfInt[1], arrayOfInt[2], arrayOfInt[3], arrayOfInt[4], arrayOfInt[5]), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1124 */         this.versionNumber = 10000;
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*      */         
/* 1130 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 0, "Internal Error: ");
/* 1131 */         sQLException.fillInStackTrace();
/* 1132 */         throw sQLException;
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 1137 */     else if (this.ociConnectionPoolLogonMode == "connpool_connection") {
/*      */       
/* 1139 */       this.logon_mode = 6;
/*      */       
/* 1141 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1147 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1150 */       this.sqlWarning = checkError(t2cConnPoolLogon(t2CConnection.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, 0, 0, (String[])null, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, arrayOfShort, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1183 */     else if (this.ociConnectionPoolLogonMode == "connpool_alias_connection") {
/*      */       
/* 1185 */       this.logon_mode = 8;
/*      */ 
/*      */       
/* 1188 */       byte[] arrayOfByte = null;
/*      */       
/* 1190 */       arrayOfByte = (byte[])this.ociConnectionPoolConnID;
/*      */ 
/*      */       
/* 1193 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1199 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1202 */       this.sqlWarning = checkError(t2cConnPoolLogon(t2CConnection.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, 0, 0, (String[])null, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, (byte[])null, 0, arrayOfByte, (arrayOfByte == null) ? 0 : arrayOfByte.length, arrayOfShort, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 1235 */     else if (this.ociConnectionPoolLogonMode == "connpool_proxy_connection") {
/*      */       
/* 1237 */       this.logon_mode = 7;
/*      */ 
/*      */       
/* 1240 */       String str = this.ociConnectionPoolProxyType;
/*      */ 
/*      */       
/* 1243 */       int i = this.ociConnectionPoolProxyNumRoles.intValue();
/*      */       
/* 1245 */       String[] arrayOfString = null;
/*      */       
/* 1247 */       if (i > 0)
/*      */       {
/* 1249 */         arrayOfString = (String[])this.ociConnectionPoolProxyRoles;
/*      */       }
/*      */ 
/*      */       
/* 1253 */       byte[] arrayOfByte8 = null;
/* 1254 */       byte[] arrayOfByte9 = null;
/* 1255 */       byte[] arrayOfByte10 = null;
/* 1256 */       byte[] arrayOfByte11 = null;
/*      */ 
/*      */       
/* 1259 */       byte b = 0;
/*      */ 
/*      */       
/* 1262 */       if (str == "proxytype_user_name") {
/*      */         
/* 1264 */         b = 1;
/*      */         
/* 1266 */         String str1 = this.ociConnectionPoolProxyUserName;
/*      */         
/* 1268 */         if (str1 != null) {
/* 1269 */           arrayOfByte8 = str1.getBytes();
/*      */         }
/* 1271 */         str1 = this.ociConnectionPoolProxyPassword;
/*      */         
/* 1273 */         if (str1 != null) {
/* 1274 */           arrayOfByte9 = str1.getBytes();
/*      */         }
/* 1276 */       } else if (str == "proxytype_distinguished_name") {
/*      */ 
/*      */         
/* 1279 */         b = 2;
/*      */         
/* 1281 */         String str1 = this.ociConnectionPoolProxyDistinguishedName;
/*      */         
/* 1283 */         if (str1 != null) {
/* 1284 */           arrayOfByte10 = str1.getBytes();
/*      */         }
/* 1286 */       } else if (str == "proxytype_certificate") {
/*      */         
/* 1288 */         b = 3;
/*      */         
/* 1290 */         arrayOfByte11 = (byte[])this.ociConnectionPoolProxyCertificate;
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 1296 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 107);
/* 1297 */         sQLException.fillInStackTrace();
/* 1298 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1303 */       arrayOfByte1 = (this.userName == null) ? new byte[0] : DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1309 */       this.conversion = new DBConversion(this.m_clientCharacterSet, this.m_clientCharacterSet, this.m_clientCharacterSet);
/*      */ 
/*      */       
/* 1312 */       this.sqlWarning = checkError(t2cConnPoolLogon(t2CConnection.m_nativeState, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, arrayOfByte5, arrayOfByte5.length, this.logon_mode, b, i, arrayOfString, arrayOfByte8, (arrayOfByte8 == null) ? 0 : arrayOfByte8.length, arrayOfByte9, (arrayOfByte9 == null) ? 0 : arrayOfByte9.length, arrayOfByte10, (arrayOfByte10 == null) ? 0 : arrayOfByte10.length, arrayOfByte11, (arrayOfByte11 == null) ? 0 : arrayOfByte11.length, (byte[])null, 0, arrayOfShort, arrayOfByte6, arrayOfByte7, arrayOfLong), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1339 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "connection-pool-logon");
/* 1340 */       sQLException.fillInStackTrace();
/* 1341 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1345 */     this.conversion = new DBConversion(arrayOfShort[0], this.m_clientCharacterSet, arrayOfShort[1]);
/* 1346 */     this.byteAlign = (byte)(arrayOfShort[2] & 0xFF);
/* 1347 */     this.timeZoneVersionNumber = (arrayOfShort[3] << 16) + (arrayOfShort[4] & 0xFFFF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isDescriptorSharable(OracleConnection paramOracleConnection) throws SQLException {
/* 1363 */     T2CConnection t2CConnection = this;
/* 1364 */     PhysicalConnection physicalConnection = (PhysicalConnection)paramOracleConnection.getPhysicalConnection();
/*      */     
/* 1366 */     return (t2CConnection == physicalConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cBlobRead(long paramLong1, byte[] paramArrayOfbyte1, int paramInt1, long paramLong2, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, boolean paramBoolean, ByteBuffer paramByteBuffer);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cClobRead(long paramLong1, byte[] paramArrayOfbyte, int paramInt1, long paramLong2, int paramInt2, char[] paramArrayOfchar, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, ByteBuffer paramByteBuffer);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cBlobWrite(long paramLong1, byte[] paramArrayOfbyte1, int paramInt1, long paramLong2, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, byte[][] paramArrayOfbyte);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cClobWrite(long paramLong1, byte[] paramArrayOfbyte, int paramInt1, long paramLong2, int paramInt2, char[] paramArrayOfchar, int paramInt3, byte[][] paramArrayOfbyte1, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   native long t2cLobGetLength(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cBfileOpen(long paramLong, byte[] paramArrayOfbyte, int paramInt, byte[][] paramArrayOfbyte1);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cBfileIsOpen(long paramLong, byte[] paramArrayOfbyte, int paramInt, boolean[] paramArrayOfboolean);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cBfileExists(long paramLong, byte[] paramArrayOfbyte, int paramInt, boolean[] paramArrayOfboolean);
/*      */ 
/*      */ 
/*      */   
/*      */   native String t2cBfileGetName(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   native String t2cBfileGetDirAlias(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cBfileClose(long paramLong, byte[] paramArrayOfbyte, int paramInt, byte[][] paramArrayOfbyte1);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cLobGetChunkSize(long paramLong, byte[] paramArrayOfbyte, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cLobTrim(long paramLong1, int paramInt1, long paramLong2, byte[] paramArrayOfbyte, int paramInt2, byte[][] paramArrayOfbyte1);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cLobCreateTemporary(long paramLong, int paramInt1, boolean paramBoolean, int paramInt2, short paramShort, byte[][] paramArrayOfbyte);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cLobFreeTemporary(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, byte[][] paramArrayOfbyte1);
/*      */ 
/*      */   
/*      */   native int t2cLobIsTemporary(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, boolean[] paramArrayOfboolean);
/*      */ 
/*      */   
/*      */   native int t2cLobOpen(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3, byte[][] paramArrayOfbyte1);
/*      */ 
/*      */   
/*      */   native int t2cLobIsOpen(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, boolean[] paramArrayOfboolean);
/*      */ 
/*      */   
/*      */   native int t2cLobClose(long paramLong, int paramInt1, byte[] paramArrayOfbyte, int paramInt2, byte[][] paramArrayOfbyte1);
/*      */ 
/*      */   
/*      */   private long lobLength(byte[] paramArrayOfbyte) throws SQLException {
/* 1443 */     long l = 0L;
/* 1444 */     l = t2cLobGetLength(this.m_nativeState, paramArrayOfbyte, paramArrayOfbyte.length);
/*      */     
/* 1446 */     checkError((int)l);
/*      */     
/* 1448 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int blobRead(byte[] paramArrayOfbyte1, long paramLong, int paramInt, byte[] paramArrayOfbyte2, boolean paramBoolean, ByteBuffer paramByteBuffer) throws SQLException {
/* 1463 */     int i = 0;
/*      */     
/* 1465 */     i = t2cBlobRead(this.m_nativeState, paramArrayOfbyte1, paramArrayOfbyte1.length, paramLong, paramInt, paramArrayOfbyte2, paramArrayOfbyte2.length, paramBoolean, paramByteBuffer);
/*      */ 
/*      */     
/* 1468 */     checkError(i);
/*      */     
/* 1470 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int blobWrite(byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 1485 */     int i = 0;
/*      */     
/* 1487 */     i = t2cBlobWrite(this.m_nativeState, paramArrayOfbyte1, paramArrayOfbyte1.length, paramLong, paramInt2, paramArrayOfbyte2, paramInt1, paramArrayOfbyte);
/*      */ 
/*      */     
/* 1490 */     checkError(i);
/*      */     
/* 1492 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int clobWrite(byte[] paramArrayOfbyte, long paramLong, char[] paramArrayOfchar, byte[][] paramArrayOfbyte1, boolean paramBoolean, int paramInt1, int paramInt2) throws SQLException {
/* 1508 */     int i = 0;
/*      */     
/* 1510 */     i = t2cClobWrite(this.m_nativeState, paramArrayOfbyte, paramArrayOfbyte.length, paramLong, paramInt2, paramArrayOfchar, paramInt1, paramArrayOfbyte1, paramBoolean);
/*      */ 
/*      */     
/* 1513 */     checkError(i);
/*      */     
/* 1515 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int lobGetChunkSize(byte[] paramArrayOfbyte) throws SQLException {
/* 1523 */     int i = 0;
/* 1524 */     i = t2cLobGetChunkSize(this.m_nativeState, paramArrayOfbyte, paramArrayOfbyte.length);
/*      */     
/* 1526 */     checkError(i);
/*      */     
/* 1528 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(BFILE paramBFILE) throws SQLException {
/* 1541 */     byte[] arrayOfByte = null;
/*      */     
/* 1543 */     checkTrue((this.lifecycle == 1), 8);
/* 1544 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1547 */     return lobLength(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BFILE paramBFILE, byte[] paramArrayOfbyte, long paramLong) throws SQLException {
/* 1565 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 1568 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1569 */       sQLException.fillInStackTrace();
/* 1570 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1574 */     long l = LobPlsqlUtil.hasPattern(paramBFILE, paramArrayOfbyte, paramLong);
/*      */     
/* 1576 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 1578 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BFILE paramBFILE1, BFILE paramBFILE2, long paramLong) throws SQLException {
/* 1596 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 1599 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 1600 */       sQLException.fillInStackTrace();
/* 1601 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 1605 */     long l = LobPlsqlUtil.isSubLob(paramBFILE1, paramBFILE2, paramLong);
/*      */     
/* 1607 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 1609 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getBytes(BFILE paramBFILE, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1625 */     byte[] arrayOfByte = null;
/*      */     
/* 1627 */     checkTrue((this.lifecycle == 1), 8);
/* 1628 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1631 */     if (paramInt <= 0 || paramArrayOfbyte == null) {
/* 1632 */       return 0;
/*      */     }
/* 1634 */     if (paramInt > paramArrayOfbyte.length) {
/* 1635 */       paramInt = paramArrayOfbyte.length;
/*      */     }
/* 1637 */     if (this.useNio) {
/*      */       
/* 1639 */       int j = paramArrayOfbyte.length;
/* 1640 */       if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < j) {
/* 1641 */         this.nioBufferForLob = ByteBuffer.allocateDirect(j);
/*      */       } else {
/* 1643 */         this.nioBufferForLob.rewind();
/*      */       } 
/*      */     } 
/* 1646 */     int i = blobRead(arrayOfByte, paramLong, paramInt, paramArrayOfbyte, this.useNio, this.nioBufferForLob);
/* 1647 */     if (this.useNio)
/*      */     {
/* 1649 */       this.nioBufferForLob.get(paramArrayOfbyte);
/*      */     }
/*      */     
/* 1652 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getName(BFILE paramBFILE) throws SQLException {
/* 1666 */     byte[] arrayOfByte = null;
/* 1667 */     String str = null;
/*      */     
/* 1669 */     checkTrue((this.lifecycle == 1), 8);
/* 1670 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1673 */     str = t2cBfileGetName(this.m_nativeState, arrayOfByte, arrayOfByte.length);
/*      */     
/* 1675 */     checkError(str.length());
/*      */     
/* 1677 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized String getDirAlias(BFILE paramBFILE) throws SQLException {
/* 1691 */     byte[] arrayOfByte = null;
/* 1692 */     String str = null;
/*      */     
/* 1694 */     checkTrue((this.lifecycle == 1), 8);
/* 1695 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1698 */     str = t2cBfileGetDirAlias(this.m_nativeState, arrayOfByte, arrayOfByte.length);
/*      */     
/* 1700 */     checkError(str.length());
/*      */     
/* 1702 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void openFile(BFILE paramBFILE) throws SQLException {
/* 1715 */     byte[] arrayOfByte = null;
/*      */     
/* 1717 */     checkTrue((this.lifecycle == 1), 8);
/* 1718 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1721 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1723 */     checkError(t2cBfileOpen(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 1726 */     paramBFILE.setLocator(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isFileOpen(BFILE paramBFILE) throws SQLException {
/* 1743 */     byte[] arrayOfByte = null;
/*      */     
/* 1745 */     checkTrue((this.lifecycle == 1), 8);
/* 1746 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1749 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 1751 */     checkError(t2cBfileIsOpen(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/* 1753 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean fileExists(BFILE paramBFILE) throws SQLException {
/* 1769 */     byte[] arrayOfByte = null;
/*      */     
/* 1771 */     checkTrue((this.lifecycle == 1), 8);
/* 1772 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1775 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 1777 */     checkError(t2cBfileExists(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */     
/* 1779 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void closeFile(BFILE paramBFILE) throws SQLException {
/* 1792 */     byte[] arrayOfByte = null;
/*      */     
/* 1794 */     checkTrue((this.lifecycle == 1), 8);
/* 1795 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1798 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1800 */     checkError(t2cBfileClose(this.m_nativeState, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 1803 */     paramBFILE.setLocator(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(BFILE paramBFILE, int paramInt) throws SQLException {
/* 1818 */     byte[] arrayOfByte = null;
/*      */     
/* 1820 */     checkTrue((this.lifecycle == 1), 8);
/* 1821 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 1824 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1826 */     checkError(t2cLobOpen(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */ 
/*      */     
/* 1829 */     paramBFILE.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(BFILE paramBFILE) throws SQLException {
/* 1842 */     byte[] arrayOfByte = null;
/*      */     
/* 1844 */     checkTrue((this.lifecycle == 1), 8);
/* 1845 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 1848 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 1850 */     checkError(t2cLobClose(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 1853 */     paramBFILE.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(BFILE paramBFILE) throws SQLException {
/* 1867 */     byte[] arrayOfByte = null;
/*      */     
/* 1869 */     checkTrue((this.lifecycle == 1), 8);
/* 1870 */     checkTrue((paramBFILE != null && (arrayOfByte = paramBFILE.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 1873 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 1875 */     checkError(t2cLobIsOpen(this.m_nativeState, 114, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 1878 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BFILE paramBFILE, int paramInt, long paramLong) throws SQLException {
/* 1898 */     if (paramLong == 0L)
/*      */     {
/* 1900 */       return new OracleBlobInputStream(paramBFILE, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 1904 */     return new OracleBlobInputStream(paramBFILE, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(BFILE paramBFILE, int paramInt) throws SQLException {
/* 1924 */     checkTrue((paramBFILE != null && paramBFILE.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 1927 */     return new OracleConversionInputStream(this.conversion, paramBFILE.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(BFILE paramBFILE, int paramInt) throws SQLException {
/* 1949 */     checkTrue((paramBFILE != null && paramBFILE.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 1952 */     return new OracleConversionReader(this.conversion, paramBFILE.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(BLOB paramBLOB) throws SQLException {
/* 1968 */     byte[] arrayOfByte = null;
/*      */     
/* 1970 */     checkTrue((this.lifecycle == 1), 8);
/* 1971 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 1974 */     return lobLength(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BLOB paramBLOB, byte[] paramArrayOfbyte, long paramLong) throws SQLException {
/* 1993 */     checkTrue((this.lifecycle == 1), 8);
/* 1994 */     checkTrue((paramBLOB != null && paramBLOB.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 1997 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 2000 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2001 */       sQLException.fillInStackTrace();
/* 2002 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2006 */     long l = LobPlsqlUtil.hasPattern(paramBLOB, paramArrayOfbyte, paramLong);
/*      */     
/* 2008 */     l = (l == 0L) ? -1L : l;
/* 2009 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(BLOB paramBLOB1, BLOB paramBLOB2, long paramLong) throws SQLException {
/* 2026 */     checkTrue((this.lifecycle == 1), 8);
/* 2027 */     checkTrue((paramBLOB1 != null && paramBLOB1.shareBytes() != null), 54);
/*      */     
/* 2029 */     checkTrue((paramBLOB2 != null && paramBLOB2.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2032 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 2035 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2036 */       sQLException.fillInStackTrace();
/* 2037 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2041 */     long l = LobPlsqlUtil.isSubLob(paramBLOB1, paramBLOB2, paramLong);
/*      */     
/* 2043 */     l = (l == 0L) ? -1L : l;
/* 2044 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getBytes(BLOB paramBLOB, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 2061 */     byte[] arrayOfByte = null;
/* 2062 */     int i = 0;
/*      */     
/* 2064 */     checkTrue((this.lifecycle == 1), 8);
/* 2065 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2068 */     if (paramInt <= 0 || paramArrayOfbyte == null) {
/* 2069 */       return 0;
/*      */     }
/* 2071 */     if (paramInt > paramArrayOfbyte.length) {
/* 2072 */       paramInt = paramArrayOfbyte.length;
/*      */     }
/* 2074 */     long l = -1L;
/*      */     
/* 2076 */     if (paramBLOB.isActivePrefetch()) {
/*      */       
/* 2078 */       byte[] arrayOfByte1 = paramBLOB.getPrefetchedData();
/* 2079 */       l = paramBLOB.length();
/* 2080 */       if (arrayOfByte1 != null && arrayOfByte1 != null && paramLong <= arrayOfByte1.length) {
/*      */ 
/*      */         
/* 2083 */         int j = Math.min(arrayOfByte1.length - (int)paramLong + 1, paramInt);
/*      */         
/* 2085 */         System.arraycopy(arrayOfByte1, (int)paramLong - 1, paramArrayOfbyte, 0, j);
/*      */         
/* 2087 */         i += j;
/*      */       } 
/*      */     } 
/*      */     
/* 2091 */     if (i < paramInt && (l == -1L || paramLong - 1L + i < l)) {
/*      */ 
/*      */ 
/*      */       
/* 2095 */       byte[] arrayOfByte1 = paramArrayOfbyte;
/* 2096 */       int j = i;
/* 2097 */       int k = ((l > 0L && l < paramInt) ? (int)l : paramInt) - i;
/*      */       
/* 2099 */       if (i > 0)
/*      */       {
/* 2101 */         arrayOfByte1 = new byte[k];
/*      */       }
/*      */       
/* 2104 */       if (this.useNio) {
/*      */         
/* 2106 */         int m = paramArrayOfbyte.length;
/* 2107 */         if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < m) {
/*      */           
/* 2109 */           this.nioBufferForLob = ByteBuffer.allocateDirect(m);
/*      */         } else {
/* 2111 */           this.nioBufferForLob.rewind();
/*      */         } 
/*      */       } 
/* 2114 */       i += blobRead(arrayOfByte, paramLong + i, k, arrayOfByte1, this.useNio, this.nioBufferForLob);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2120 */       if (this.useNio)
/*      */       {
/* 2122 */         this.nioBufferForLob.get(arrayOfByte1);
/*      */       }
/*      */ 
/*      */ 
/*      */       
/* 2127 */       if (j > 0)
/*      */       {
/* 2129 */         System.arraycopy(arrayOfByte1, 0, paramArrayOfbyte, j, arrayOfByte1.length);
/*      */       }
/*      */     } 
/*      */     
/* 2133 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int putBytes(BLOB paramBLOB, long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/* 2155 */     checkTrue((paramLong != 0L || paramInt2 > 0), 68);
/*      */     
/* 2157 */     checkTrue((paramLong >= 0L), 68);
/* 2158 */     if (paramArrayOfbyte == null || paramInt2 <= 0) {
/* 2159 */       return 0;
/*      */     }
/* 2161 */     int i = 0;
/*      */     
/* 2163 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0 || paramInt2 <= 0) {
/* 2164 */       i = 0;
/*      */     } else {
/*      */       
/* 2167 */       byte[] arrayOfByte = null;
/*      */       
/* 2169 */       checkTrue((this.lifecycle == 1), 8);
/* 2170 */       checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */       
/* 2173 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 2175 */       paramBLOB.setActivePrefetch(false);
/* 2176 */       paramBLOB.clearCachedData();
/* 2177 */       i = blobWrite(arrayOfByte, paramLong, paramArrayOfbyte, arrayOfByte1, paramInt1, paramInt2);
/*      */ 
/*      */       
/* 2180 */       paramBLOB.setLocator(arrayOfByte1[0]);
/*      */     } 
/*      */     
/* 2183 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChunkSize(BLOB paramBLOB) throws SQLException {
/* 2195 */     byte[] arrayOfByte = null;
/*      */     
/* 2197 */     checkTrue((this.lifecycle == 1), 8);
/* 2198 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2201 */     return lobGetChunkSize(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void trim(BLOB paramBLOB, long paramLong) throws SQLException {
/* 2215 */     byte[] arrayOfByte = null;
/*      */     
/* 2217 */     checkTrue((this.lifecycle == 1), 8);
/* 2218 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2221 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2223 */     paramBLOB.setActivePrefetch(false);
/* 2224 */     paramBLOB.clearCachedData();
/* 2225 */     checkError(t2cLobTrim(this.m_nativeState, 113, paramLong, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2228 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException {
/* 2247 */     BLOB bLOB = null;
/*      */     
/* 2249 */     checkTrue((this.lifecycle == 1), 8);
/*      */     
/* 2251 */     bLOB = new BLOB((OracleConnection)paramConnection);
/*      */     
/* 2253 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/* 2255 */     checkError(t2cLobCreateTemporary(this.m_nativeState, 113, paramBoolean, paramInt, (short)0, arrayOfByte));
/*      */ 
/*      */     
/* 2258 */     bLOB.setShareBytes(arrayOfByte[0]);
/*      */     
/* 2260 */     return bLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(BLOB paramBLOB, boolean paramBoolean) throws SQLException {
/*      */     try {
/* 2276 */       byte[] arrayOfByte = null;
/*      */       
/* 2278 */       checkTrue((this.lifecycle == 1), 8);
/* 2279 */       checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */       
/* 2282 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 2284 */       checkError(t2cLobFreeTemporary(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */       
/* 2287 */       paramBLOB.setShareBytes(arrayOfByte1[0]);
/* 2288 */     } catch (SQLException sQLException) {
/*      */       
/* 2290 */       if ((paramBoolean & ((sQLException.getErrorCode() == 64201) ? 1 : 0)) != 0) {
/* 2291 */         LobPlsqlUtil.freeTemporaryLob((Connection)this, (Datum)paramBLOB, 2004);
/*      */       } else {
/* 2293 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isTemporary(BLOB paramBLOB) throws SQLException {
/* 2309 */     byte[] arrayOfByte = null;
/*      */     
/* 2311 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2314 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2316 */     checkError(t2cLobIsTemporary(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 2319 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2332 */     byte[] arrayOfByte = null;
/*      */     
/* 2334 */     checkTrue((this.lifecycle == 1), 8);
/* 2335 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2338 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2340 */     checkError(t2cLobOpen(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */ 
/*      */     
/* 2343 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(BLOB paramBLOB) throws SQLException {
/* 2356 */     byte[] arrayOfByte = null;
/*      */     
/* 2358 */     checkTrue((this.lifecycle == 1), 8);
/* 2359 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2362 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2364 */     checkError(t2cLobClose(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2367 */     paramBLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(BLOB paramBLOB) throws SQLException {
/* 2381 */     byte[] arrayOfByte = null;
/*      */     
/* 2383 */     checkTrue((this.lifecycle == 1), 8);
/* 2384 */     checkTrue((paramBLOB != null && (arrayOfByte = paramBLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2387 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2389 */     checkError(t2cLobIsOpen(this.m_nativeState, 113, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 2392 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
/* 2411 */     if (paramLong == 0L)
/*      */     {
/* 2413 */       return new OracleBlobInputStream(paramBLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 2417 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(BLOB paramBLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 2442 */     if (paramLong == 0L) {
/*      */       
/* 2444 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 2447 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2448 */         sQLException.fillInStackTrace();
/* 2449 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2454 */       return new OracleBlobOutputStream(paramBLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2459 */     return new OracleBlobOutputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2480 */     checkTrue((paramBLOB != null && paramBLOB.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2483 */     return new OracleConversionInputStream(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2504 */     checkTrue((paramBLOB != null && paramBLOB.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2507 */     return new OracleConversionReader(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(CLOB paramCLOB) throws SQLException {
/* 2527 */     byte[] arrayOfByte = null;
/*      */     
/* 2529 */     checkTrue((this.lifecycle == 1), 8);
/* 2530 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2533 */     return lobLength(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(CLOB paramCLOB, String paramString, long paramLong) throws SQLException {
/* 2551 */     if (paramString == null) {
/*      */       
/* 2553 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2554 */       sQLException.fillInStackTrace();
/* 2555 */       throw sQLException;
/*      */     } 
/*      */     
/* 2558 */     checkTrue((this.lifecycle == 1), 8);
/* 2559 */     checkTrue((paramCLOB != null && paramCLOB.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2562 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 2565 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2566 */       sQLException.fillInStackTrace();
/* 2567 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2571 */     char[] arrayOfChar = new char[paramString.length()];
/*      */     
/* 2573 */     paramString.getChars(0, arrayOfChar.length, arrayOfChar, 0);
/*      */     
/* 2575 */     long l = LobPlsqlUtil.hasPattern(paramCLOB, arrayOfChar, paramLong);
/*      */     
/* 2577 */     l = (l == 0L) ? -1L : l;
/* 2578 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long position(CLOB paramCLOB1, CLOB paramCLOB2, long paramLong) throws SQLException {
/* 2595 */     checkTrue((this.lifecycle == 1), 8);
/* 2596 */     checkTrue((paramCLOB1 != null && paramCLOB1.shareBytes() != null), 54);
/*      */     
/* 2598 */     checkTrue((paramCLOB2 != null && paramCLOB2.shareBytes() != null), 54);
/*      */ 
/*      */     
/* 2601 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 2604 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 2605 */       sQLException.fillInStackTrace();
/* 2606 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 2610 */     long l = LobPlsqlUtil.isSubLob(paramCLOB1, paramCLOB2, paramLong);
/*      */     
/* 2612 */     l = (l == 0L) ? -1L : l;
/* 2613 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChars(CLOB paramCLOB, long paramLong, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 2630 */     byte[] arrayOfByte = null;
/*      */     
/* 2632 */     checkTrue((this.lifecycle == 1), 8);
/* 2633 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2636 */     if (paramInt <= 0 || paramArrayOfchar == null) {
/* 2637 */       return 0;
/*      */     }
/* 2639 */     if (paramInt > paramArrayOfchar.length) {
/* 2640 */       paramInt = paramArrayOfchar.length;
/*      */     }
/* 2642 */     int i = 0;
/*      */ 
/*      */     
/* 2645 */     long l = -1L;
/*      */ 
/*      */     
/* 2648 */     if (paramCLOB.isActivePrefetch()) {
/*      */       
/* 2650 */       l = paramCLOB.length();
/* 2651 */       char[] arrayOfChar = paramCLOB.getPrefetchedData();
/* 2652 */       if (arrayOfChar != null && paramLong <= arrayOfChar.length) {
/*      */ 
/*      */         
/* 2655 */         int j = Math.min(arrayOfChar.length - (int)paramLong + 1, paramInt);
/*      */ 
/*      */         
/* 2658 */         System.arraycopy(arrayOfChar, (int)paramLong - 1, paramArrayOfchar, 0, j);
/*      */         
/* 2660 */         i += j;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 2665 */     if (i < paramInt && (l == -1L || paramLong - 1L + i < l)) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2670 */       char[] arrayOfChar = paramArrayOfchar;
/* 2671 */       int j = i;
/* 2672 */       int k = ((l > 0L && l < paramInt) ? (int)l : paramInt) - i;
/*      */       
/* 2674 */       if (i > 0)
/*      */       {
/* 2676 */         arrayOfChar = new char[k];
/*      */       }
/*      */       
/* 2679 */       if (this.useNio) {
/*      */ 
/*      */ 
/*      */         
/* 2683 */         int m = paramArrayOfchar.length * 2;
/* 2684 */         if (this.nioBufferForLob == null || this.nioBufferForLob.capacity() < m) {
/* 2685 */           this.nioBufferForLob = ByteBuffer.allocateDirect(m);
/*      */         } else {
/* 2687 */           this.nioBufferForLob.rewind();
/*      */         } 
/*      */       } 
/* 2690 */       i += t2cClobRead(this.m_nativeState, arrayOfByte, arrayOfByte.length, paramLong + i, k, arrayOfChar, arrayOfChar.length, paramCLOB.isNCLOB(), this.useNio, this.nioBufferForLob);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2702 */       if (this.useNio) {
/*      */         
/* 2704 */         ByteBuffer byteBuffer = this.nioBufferForLob.order(ByteOrder.LITTLE_ENDIAN);
/* 2705 */         CharBuffer charBuffer = byteBuffer.asCharBuffer();
/* 2706 */         charBuffer.get(arrayOfChar);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2711 */       if (j > 0)
/*      */       {
/* 2713 */         System.arraycopy(arrayOfChar, 0, paramArrayOfchar, j, arrayOfChar.length);
/*      */       }
/*      */       
/* 2716 */       checkError(i);
/*      */     } 
/*      */     
/* 2719 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int putChars(CLOB paramCLOB, long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
/* 2740 */     byte[] arrayOfByte = null;
/*      */     
/* 2742 */     checkTrue((this.lifecycle == 1), 8);
/* 2743 */     checkTrue((paramLong >= 0L), 68);
/*      */     
/* 2745 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2748 */     if (paramArrayOfchar == null) {
/* 2749 */       return 0;
/*      */     }
/* 2751 */     byte[][] arrayOfByte1 = new byte[1][];
/* 2752 */     paramCLOB.setActivePrefetch(false);
/* 2753 */     paramCLOB.clearCachedData();
/* 2754 */     int i = clobWrite(arrayOfByte, paramLong, paramArrayOfchar, arrayOfByte1, paramCLOB.isNCLOB(), paramInt1, paramInt2);
/*      */ 
/*      */     
/* 2757 */     paramCLOB.setLocator(arrayOfByte1[0]);
/*      */     
/* 2759 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChunkSize(CLOB paramCLOB) throws SQLException {
/* 2771 */     byte[] arrayOfByte = null;
/*      */     
/* 2773 */     checkTrue((this.lifecycle == 1), 8);
/* 2774 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.getLocator()) != null), 54);
/*      */ 
/*      */     
/* 2777 */     return lobGetChunkSize(arrayOfByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void trim(CLOB paramCLOB, long paramLong) throws SQLException {
/* 2791 */     byte[] arrayOfByte = null;
/*      */     
/* 2793 */     checkTrue((this.lifecycle == 1), 8);
/* 2794 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2797 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2799 */     paramCLOB.setActivePrefetch(false);
/* 2800 */     paramCLOB.clearCachedData();
/* 2801 */     checkError(t2cLobTrim(this.m_nativeState, 112, paramLong, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2804 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException {
/*      */     NCLOB nCLOB;
/* 2824 */     CLOB cLOB = null;
/*      */     
/* 2826 */     checkTrue((this.lifecycle == 1), 8);
/*      */     
/* 2828 */     if (paramShort == 1) {
/* 2829 */       cLOB = new CLOB((OracleConnection)paramConnection);
/*      */     } else {
/*      */       
/* 2832 */       nCLOB = new NCLOB((OracleConnection)paramConnection);
/*      */     } 
/*      */     
/* 2835 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/* 2837 */     checkError(t2cLobCreateTemporary(this.m_nativeState, 112, paramBoolean, paramInt, paramShort, arrayOfByte));
/*      */ 
/*      */     
/* 2840 */     nCLOB.setShareBytes(arrayOfByte[0]);
/*      */     
/* 2842 */     return (CLOB)nCLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(CLOB paramCLOB, boolean paramBoolean) throws SQLException {
/*      */     try {
/* 2857 */       byte[] arrayOfByte = null;
/*      */       
/* 2859 */       checkTrue((this.lifecycle == 1), 8);
/* 2860 */       checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */       
/* 2863 */       byte[][] arrayOfByte1 = new byte[1][];
/*      */       
/* 2865 */       checkError(t2cLobFreeTemporary(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */       
/* 2868 */       paramCLOB.setShareBytes(arrayOfByte1[0]);
/* 2869 */     } catch (SQLException sQLException) {
/*      */       
/* 2871 */       if ((paramBoolean & ((sQLException.getErrorCode() == 64201) ? 1 : 0)) != 0) {
/* 2872 */         LobPlsqlUtil.freeTemporaryLob((Connection)this, (Datum)paramCLOB, 2005);
/*      */       } else {
/* 2874 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isTemporary(CLOB paramCLOB) throws SQLException {
/* 2891 */     byte[] arrayOfByte = null;
/*      */     
/* 2893 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2896 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2898 */     checkError(t2cLobIsTemporary(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 2901 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(CLOB paramCLOB, int paramInt) throws SQLException {
/* 2914 */     byte[] arrayOfByte = null;
/*      */     
/* 2916 */     checkTrue((this.lifecycle == 1), 8);
/* 2917 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2920 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2922 */     checkError(t2cLobOpen(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, paramInt, arrayOfByte1));
/*      */ 
/*      */     
/* 2925 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(CLOB paramCLOB) throws SQLException {
/* 2938 */     byte[] arrayOfByte = null;
/*      */     
/* 2940 */     checkTrue((this.lifecycle == 1), 8);
/* 2941 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2944 */     byte[][] arrayOfByte1 = new byte[1][];
/*      */     
/* 2946 */     checkError(t2cLobClose(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfByte1));
/*      */ 
/*      */     
/* 2949 */     paramCLOB.setShareBytes(arrayOfByte1[0]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(CLOB paramCLOB) throws SQLException {
/* 2963 */     byte[] arrayOfByte = null;
/*      */     
/* 2965 */     checkTrue((this.lifecycle == 1), 8);
/* 2966 */     checkTrue((paramCLOB != null && (arrayOfByte = paramCLOB.shareBytes()) != null), 54);
/*      */ 
/*      */     
/* 2969 */     boolean[] arrayOfBoolean = new boolean[1];
/*      */     
/* 2971 */     checkError(t2cLobIsOpen(this.m_nativeState, 112, arrayOfByte, arrayOfByte.length, arrayOfBoolean));
/*      */ 
/*      */     
/* 2974 */     return arrayOfBoolean[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 2994 */     if (paramLong == 0L)
/*      */     {
/* 2996 */       return new OracleClobInputStream(paramCLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3000 */     return new OracleClobInputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3021 */     if (paramLong == 0L) {
/*      */       
/* 3023 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3026 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3027 */         sQLException.fillInStackTrace();
/* 3028 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3033 */       return new OracleClobOutputStream(paramCLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3038 */     return new OracleClobOutputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 3058 */     if (paramLong == 0L)
/*      */     {
/* 3060 */       return new OracleClobReader(paramCLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3064 */     return new OracleClobReader(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 3085 */     return new OracleClobReader(paramCLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer newWriter(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3105 */     if (paramLong == 0L) {
/*      */       
/* 3107 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3110 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3111 */         sQLException.fillInStackTrace();
/* 3112 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3117 */       return new OracleClobWriter(paramCLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3122 */     return new OracleClobWriter(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void registerTAFCallback(OracleOCIFailover paramOracleOCIFailover, Object paramObject) throws SQLException {
/* 3149 */     this.appCallback = paramOracleOCIFailover;
/* 3150 */     this.appCallbackObject = paramObject;
/*      */     
/* 3152 */     checkError(t2cRegisterTAFCallback(this.m_nativeState));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized int callTAFCallbackMethod(int paramInt1, int paramInt2) {
/* 3162 */     int i = 0;
/*      */ 
/*      */     
/* 3165 */     if (this.appCallback != null) {
/* 3166 */       i = this.appCallback.callbackFn((Connection)this, this.appCallbackObject, paramInt1, paramInt2);
/*      */     }
/* 3168 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getHeapAllocSize() throws SQLException {
/* 3182 */     if (this.lifecycle != 1) {
/*      */       
/* 3184 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 3185 */       sQLException.fillInStackTrace();
/* 3186 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3191 */     int i = t2cGetHeapAllocSize(this.m_nativeState);
/*      */     
/* 3193 */     if (i < 0) {
/*      */       
/* 3195 */       if (i == -999) {
/*      */         
/* 3197 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 3198 */         sQLException1.fillInStackTrace();
/* 3199 */         throw sQLException1;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3205 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 3206 */       sQLException.fillInStackTrace();
/* 3207 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3211 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getOCIEnvHeapAllocSize() throws SQLException {
/* 3224 */     if (this.lifecycle != 1) {
/*      */       
/* 3226 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 3227 */       sQLException.fillInStackTrace();
/* 3228 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3233 */     int i = t2cGetOciEnvHeapAllocSize(this.m_nativeState);
/*      */     
/* 3235 */     if (i < 0) {
/*      */       
/* 3237 */       if (i == -999) {
/*      */         
/* 3239 */         SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 3240 */         sQLException1.fillInStackTrace();
/* 3241 */         throw sQLException1;
/*      */       } 
/*      */       
/* 3244 */       checkError(i);
/*      */ 
/*      */ 
/*      */       
/* 3248 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 3249 */       sQLException.fillInStackTrace();
/* 3250 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3254 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final short getClientCharSetId() {
/* 3263 */     return 871;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static short getDriverCharSetIdFromNLS_LANG() throws SQLException {
/* 3278 */     if (!isLibraryLoaded) {
/* 3279 */       loadNativeLibrary();
/*      */     }
/*      */     
/* 3282 */     short s = t2cGetDriverCharSetFromNlsLang();
/*      */ 
/*      */     
/* 3285 */     if (s < 0) {
/*      */       
/* 3287 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 8);
/* 3288 */       sQLException.fillInStackTrace();
/* 3289 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3293 */     return s;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doProxySession(int paramInt, Properties paramProperties) throws SQLException {
/*      */     String str1, str2;
/*      */     Object object;
/* 3306 */     byte[][] arrayOfByte = (byte[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3312 */     int i = 0;
/*      */     
/* 3314 */     this.savedUser = this.userName;
/* 3315 */     this.userName = null;
/*      */     
/* 3317 */     byte[] arrayOfByte4 = new byte[0], arrayOfByte3 = arrayOfByte4, arrayOfByte2 = arrayOfByte3, arrayOfByte1 = arrayOfByte2;
/*      */     
/* 3319 */     switch (paramInt) {
/*      */       
/*      */       case 1:
/* 3322 */         this.userName = paramProperties.getProperty("PROXY_USER_NAME");
/* 3323 */         str1 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/* 3324 */         if (this.userName != null) {
/* 3325 */           arrayOfByte1 = DBConversion.stringToDriverCharBytes(this.userName, this.m_clientCharacterSet);
/*      */         }
/* 3327 */         if (str1 != null)
/* 3328 */           arrayOfByte2 = DBConversion.stringToDriverCharBytes(str1, this.m_clientCharacterSet); 
/*      */         break;
/*      */       case 2:
/* 3331 */         str2 = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/* 3332 */         if (str2 != null) {
/* 3333 */           arrayOfByte3 = DBConversion.stringToDriverCharBytes(str2, this.m_clientCharacterSet);
/*      */         }
/*      */         break;
/*      */       case 3:
/* 3337 */         object = paramProperties.get("PROXY_CERTIFICATE");
/* 3338 */         arrayOfByte4 = (byte[])object;
/*      */         break;
/*      */     } 
/* 3341 */     String[] arrayOfString = (String[])paramProperties.get("PROXY_ROLES");
/*      */     
/* 3343 */     if (arrayOfString != null) {
/*      */       
/* 3345 */       i = arrayOfString.length;
/* 3346 */       arrayOfByte = new byte[i][];
/* 3347 */       for (byte b = 0; b < i; b++) {
/*      */         
/* 3349 */         if (arrayOfString[b] == null) {
/*      */           
/* 3351 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/* 3352 */           sQLException.fillInStackTrace();
/* 3353 */           throw sQLException;
/*      */         } 
/*      */         
/* 3356 */         arrayOfByte[b] = DBConversion.stringToDriverCharBytes(arrayOfString[b], this.m_clientCharacterSet);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3361 */     this.sqlWarning = checkError(t2cDoProxySession(this.m_nativeState, paramInt, arrayOfByte1, arrayOfByte1.length, arrayOfByte2, arrayOfByte2.length, arrayOfByte3, arrayOfByte3.length, arrayOfByte4, arrayOfByte4.length, i, arrayOfByte), this.sqlWarning);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3375 */     this.isProxy = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeProxySession() throws SQLException {
/* 3382 */     checkError(t2cCloseProxySession(this.m_nativeState));
/* 3383 */     this.userName = this.savedUser;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException {
/*      */     boolean bool;
/*      */     int i;
/* 3391 */     String str = paramAutoKeyInfo.getTableName();
/*      */     
/* 3393 */     byte[] arrayOfByte = DBConversion.stringToDriverCharBytes(str, this.m_clientCharacterSet);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     do {
/* 3401 */       bool = false;
/* 3402 */       i = t2cDescribeTable(this.m_nativeState, arrayOfByte, arrayOfByte.length, this.queryMetaData1, this.queryMetaData2, this.queryMetaData1Offset, this.queryMetaData2Offset, this.queryMetaData1Size, this.queryMetaData2Size);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 3412 */       if (i == -1)
/*      */       {
/* 3414 */         checkError(i);
/*      */       }
/*      */ 
/*      */       
/* 3418 */       if (i != T2CStatement.T2C_EXTEND_BUFFER)
/*      */         continue; 
/* 3420 */       bool = true;
/*      */       
/* 3422 */       reallocateQueryMetaData(this.queryMetaData1Size * 2, this.queryMetaData2Size * 2);
/*      */     
/*      */     }
/* 3425 */     while (bool);
/*      */     
/* 3427 */     processDescribeTableData(i, paramAutoKeyInfo);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void processDescribeTableData(int paramInt, AutoKeyInfo paramAutoKeyInfo) throws SQLException {
/* 3436 */     short[] arrayOfShort = this.queryMetaData1;
/* 3437 */     byte[] arrayOfByte = this.queryMetaData2;
/* 3438 */     int i = this.queryMetaData1Offset;
/* 3439 */     int j = this.queryMetaData2Offset;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3453 */     paramAutoKeyInfo.allocateSpaceForDescribedData(paramInt);
/*      */     
/* 3455 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/* 3457 */       short s2 = arrayOfShort[i + 0];
/* 3458 */       short s1 = arrayOfShort[i + 6];
/* 3459 */       String str1 = bytes2String(arrayOfByte, j, s1, this.conversion);
/*      */ 
/*      */       
/* 3462 */       short s3 = arrayOfShort[i + 1];
/* 3463 */       short s4 = arrayOfShort[i + 11];
/* 3464 */       boolean bool = (arrayOfShort[i + 2] != 0) ? true : false;
/* 3465 */       short s5 = arrayOfShort[i + 5];
/* 3466 */       short s6 = arrayOfShort[i + 3];
/* 3467 */       short s7 = arrayOfShort[i + 4];
/* 3468 */       short s8 = arrayOfShort[i + 12];
/*      */       
/* 3470 */       j += s1;
/* 3471 */       i += 13;
/*      */       
/* 3473 */       String str2 = null;
/* 3474 */       if (s8 > 0) {
/*      */         
/* 3476 */         str2 = bytes2String(arrayOfByte, j, s8, this.conversion);
/*      */         
/* 3478 */         j += s8;
/*      */       } 
/*      */ 
/*      */       
/* 3482 */       paramAutoKeyInfo.fillDescribedData(b, str1, s2, (s4 > 0) ? s4 : s3, bool, s5, s6, s7, str2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException {
/* 3496 */     checkError(t2cSetApplicationContext(this.m_nativeState, paramString1, paramString2, paramString3));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClearAllApplicationContext(String paramString) throws SQLException {
/* 3505 */     checkError(t2cClearAllApplicationContext(this.m_nativeState, paramString));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doStartup(int paramInt) throws SQLException {
/* 3513 */     checkError(t2cStartupDatabase(this.m_nativeState, paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doShutdown(int paramInt) throws SQLException {
/* 3521 */     checkError(t2cShutdownDatabase(this.m_nativeState, paramInt));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final void loadNativeLibrary() throws SQLException {
/* 3533 */     synchronized (T2CConnection.class) {
/*      */       
/* 3535 */       if (!isLibraryLoaded) {
/*      */         
/* 3537 */         AccessController.doPrivileged(new PrivilegedAction()
/*      */             {
/*      */               public Object run()
/*      */               {
/* 3541 */                 System.loadLibrary("ocijdbc11");
/* 3542 */                 int i = T2CConnection.getLibraryVersionNumber();
/* 3543 */                 if (i != T2CConnection.JDBC_OCI_LIBRARY_VERSION) {
/* 3544 */                   throw new Error("Incompatible version of libocijdbc[Jdbc:" + T2CConnection.JDBC_OCI_LIBRARY_VERSION + ", Jdbc-OCI:" + i);
/*      */                 }
/*      */                 
/* 3547 */                 return null;
/*      */               }
/*      */             });
/* 3550 */         isLibraryLoaded = true;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private final void checkTrue(boolean paramBoolean, int paramInt) throws SQLException {
/* 3560 */     if (!paramBoolean) {
/*      */       
/* 3562 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), paramInt);
/* 3563 */       sQLException.fillInStackTrace();
/* 3564 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean useLittleEndianSetCHARBinder() throws SQLException {
/* 3572 */     return t2cPlatformIsLittleEndian(this.m_nativeState);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 3580 */     getPropertyForPooledConnection(paramOraclePooledConnection, this.password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final char[] getCharArray(String paramString) {
/* 3587 */     char[] arrayOfChar = null;
/*      */     
/* 3589 */     if (paramString == null) {
/*      */       
/* 3591 */       arrayOfChar = new char[0];
/*      */     }
/*      */     else {
/*      */       
/* 3595 */       arrayOfChar = new char[paramString.length()];
/*      */       
/* 3597 */       paramString.getChars(0, paramString.length(), arrayOfChar, 0);
/*      */     } 
/*      */     
/* 3600 */     return arrayOfChar;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static String bytes2String(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, DBConversion paramDBConversion) throws SQLException {
/* 3610 */     byte[] arrayOfByte = new byte[paramInt2];
/* 3611 */     System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, 0, paramInt2);
/*      */     
/* 3613 */     return paramDBConversion.CharBytesToString(arrayOfByte, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void disableNio() {
/* 3621 */     this.useNio = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static synchronized void doSetSessionTimeZone(String paramString) throws SQLException {
/* 3629 */     t2cSetSessionTimeZone(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static native int getLibraryVersionNumber();
/*      */ 
/*      */ 
/*      */   
/*      */   static native short t2cGetServerSessionInfo(long paramLong, Properties paramProperties);
/*      */ 
/*      */ 
/*      */   
/*      */   static native short t2cGetDriverCharSetFromNlsLang();
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cDescribeError(long paramLong, T2CError paramT2CError, byte[] paramArrayOfbyte);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cCreateState(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, byte[] paramArrayOfbyte4, int paramInt4, byte[] paramArrayOfbyte5, int paramInt5, byte[] paramArrayOfbyte6, int paramInt6, byte[] paramArrayOfbyte7, int paramInt7, short paramShort, int paramInt8, short[] paramArrayOfshort, byte[] paramArrayOfbyte8, byte[] paramArrayOfbyte9, boolean paramBoolean, long[] paramArrayOflong);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cLogon(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, byte[] paramArrayOfbyte4, int paramInt4, byte[] paramArrayOfbyte5, int paramInt5, byte[] paramArrayOfbyte6, int paramInt6, byte[] paramArrayOfbyte7, int paramInt7, int paramInt8, short[] paramArrayOfshort, byte[] paramArrayOfbyte8, byte[] paramArrayOfbyte9, long[] paramArrayOflong);
/*      */ 
/*      */ 
/*      */   
/*      */   private native int t2cLogoff(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   private native int t2cCancel(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   private native byte t2cGetAsmVolProperty(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   private native byte t2cGetInstanceType(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   private native int t2cCreateStatement(long paramLong1, long paramLong2, byte[] paramArrayOfbyte, int paramInt1, OracleStatement paramOracleStatement, boolean paramBoolean, int paramInt2);
/*      */ 
/*      */ 
/*      */   
/*      */   private native int t2cSetAutoCommit(long paramLong, boolean paramBoolean);
/*      */ 
/*      */ 
/*      */   
/*      */   private native int t2cCommit(long paramLong, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   private native int t2cRollback(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   private native int t2cPingDatabase(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   private native byte[] t2cGetProductionVersion(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   private native int t2cGetVersionNumber(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   private native int t2cGetDefaultStreamChunkSize(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cGetFormOfUse(long paramLong, OracleTypeCLOB paramOracleTypeCLOB, byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
/*      */ 
/*      */ 
/*      */   
/*      */   native long t2cGetTDO(long paramLong, byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cCreateConnPool(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, short paramShort, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cConnPoolLogon(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3, byte[] paramArrayOfbyte4, int paramInt4, byte[] paramArrayOfbyte5, int paramInt5, int paramInt6, int paramInt7, int paramInt8, String[] paramArrayOfString, byte[] paramArrayOfbyte6, int paramInt9, byte[] paramArrayOfbyte7, int paramInt10, byte[] paramArrayOfbyte8, int paramInt11, byte[] paramArrayOfbyte9, int paramInt12, byte[] paramArrayOfbyte10, int paramInt13, short[] paramArrayOfshort, byte[] paramArrayOfbyte11, byte[] paramArrayOfbyte12, long[] paramArrayOflong);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cGetConnPoolInfo(long paramLong, Properties paramProperties);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cSetConnPoolInfo(long paramLong, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cPasswordChange(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, byte[] paramArrayOfbyte3, int paramInt3);
/*      */ 
/*      */ 
/*      */   
/*      */   protected native byte[] t2cGetConnectionId(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cGetHandles(long paramLong, long[] paramArrayOflong);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cUseConnection(long paramLong1, long paramLong2, long paramLong3, long paramLong4, short[] paramArrayOfshort, long[] paramArrayOflong);
/*      */ 
/*      */ 
/*      */   
/*      */   native boolean t2cPlatformIsLittleEndian(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cRegisterTAFCallback(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cGetHeapAllocSize(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cGetOciEnvHeapAllocSize(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cDoProxySession(long paramLong, int paramInt1, byte[] paramArrayOfbyte1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3, byte[] paramArrayOfbyte3, int paramInt4, byte[] paramArrayOfbyte4, int paramInt5, int paramInt6, byte[][] paramArrayOfbyte);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cCloseProxySession(long paramLong);
/*      */ 
/*      */ 
/*      */   
/*      */   static native int t2cDescribeTable(long paramLong, byte[] paramArrayOfbyte1, int paramInt1, short[] paramArrayOfshort, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cSetApplicationContext(long paramLong, String paramString1, String paramString2, String paramString3);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cClearAllApplicationContext(long paramLong, String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cStartupDatabase(long paramLong, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   native int t2cShutdownDatabase(long paramLong, int paramInt);
/*      */ 
/*      */ 
/*      */   
/*      */   static native void t2cSetSessionTimeZone(String paramString);
/*      */ 
/*      */ 
/*      */   
/*      */   public void incrementTempLobReferenceCount(byte[] paramArrayOfbyte) throws SQLException {}
/*      */ 
/*      */ 
/*      */   
/*      */   public int decrementTempLobReferenceCount(byte[] paramArrayOfbyte) throws SQLException {
/* 3800 */     return 0;
/*      */   }
/* 3802 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/T2CConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */