/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleParameterMetaData;
/*      */ import oracle.jdbc.OracleResultSetCache;
/*      */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*      */ import oracle.jdbc.internal.OracleCallableStatement;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class OracleClosedStatement
/*      */   implements OracleCallableStatement
/*      */ {
/*      */   private OracleStatement wrapper;
/*      */   
/*      */   public void setArray(int paramInt, Array paramArray) throws SQLException {
/*   78 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   79 */     sQLException.fillInStackTrace();
/*   80 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArrayAtName(String paramString, Array paramArray) throws SQLException {
/*   88 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   89 */     sQLException.fillInStackTrace();
/*   90 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(String paramString, Array paramArray) throws SQLException {
/*   98 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*   99 */     sQLException.fillInStackTrace();
/*  100 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/*  109 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  110 */     sQLException.fillInStackTrace();
/*  111 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimalAtName(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/*  119 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  120 */     sQLException.fillInStackTrace();
/*  121 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/*  129 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  130 */     sQLException.fillInStackTrace();
/*  131 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, Blob paramBlob) throws SQLException {
/*  140 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  141 */     sQLException.fillInStackTrace();
/*  142 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlobAtName(String paramString, Blob paramBlob) throws SQLException {
/*  150 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  151 */     sQLException.fillInStackTrace();
/*  152 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(String paramString, Blob paramBlob) throws SQLException {
/*  160 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  161 */     sQLException.fillInStackTrace();
/*  162 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/*  171 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  172 */     sQLException.fillInStackTrace();
/*  173 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBooleanAtName(String paramString, boolean paramBoolean) throws SQLException {
/*  181 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  182 */     sQLException.fillInStackTrace();
/*  183 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(String paramString, boolean paramBoolean) throws SQLException {
/*  191 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  192 */     sQLException.fillInStackTrace();
/*  193 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(int paramInt, byte paramByte) throws SQLException {
/*  202 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  203 */     sQLException.fillInStackTrace();
/*  204 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByteAtName(String paramString, byte paramByte) throws SQLException {
/*  212 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  213 */     sQLException.fillInStackTrace();
/*  214 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(String paramString, byte paramByte) throws SQLException {
/*  222 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  223 */     sQLException.fillInStackTrace();
/*  224 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/*  233 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  234 */     sQLException.fillInStackTrace();
/*  235 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  243 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  244 */     sQLException.fillInStackTrace();
/*  245 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  253 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  254 */     sQLException.fillInStackTrace();
/*  255 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Clob paramClob) throws SQLException {
/*  264 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  265 */     sQLException.fillInStackTrace();
/*  266 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClobAtName(String paramString, Clob paramClob) throws SQLException {
/*  274 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  275 */     sQLException.fillInStackTrace();
/*  276 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(String paramString, Clob paramClob) throws SQLException {
/*  284 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  285 */     sQLException.fillInStackTrace();
/*  286 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate) throws SQLException {
/*  295 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  296 */     sQLException.fillInStackTrace();
/*  297 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateAtName(String paramString, Date paramDate) throws SQLException {
/*  305 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  306 */     sQLException.fillInStackTrace();
/*  307 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate) throws SQLException {
/*  315 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  316 */     sQLException.fillInStackTrace();
/*  317 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  326 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  327 */     sQLException.fillInStackTrace();
/*  328 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateAtName(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  336 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  337 */     sQLException.fillInStackTrace();
/*  338 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  346 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  347 */     sQLException.fillInStackTrace();
/*  348 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(int paramInt, double paramDouble) throws SQLException {
/*  357 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  358 */     sQLException.fillInStackTrace();
/*  359 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDoubleAtName(String paramString, double paramDouble) throws SQLException {
/*  367 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  368 */     sQLException.fillInStackTrace();
/*  369 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(String paramString, double paramDouble) throws SQLException {
/*  377 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  378 */     sQLException.fillInStackTrace();
/*  379 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(int paramInt, float paramFloat) throws SQLException {
/*  388 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  389 */     sQLException.fillInStackTrace();
/*  390 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloatAtName(String paramString, float paramFloat) throws SQLException {
/*  398 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  399 */     sQLException.fillInStackTrace();
/*  400 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(String paramString, float paramFloat) throws SQLException {
/*  408 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  409 */     sQLException.fillInStackTrace();
/*  410 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(int paramInt1, int paramInt2) throws SQLException {
/*  419 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  420 */     sQLException.fillInStackTrace();
/*  421 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIntAtName(String paramString, int paramInt) throws SQLException {
/*  429 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  430 */     sQLException.fillInStackTrace();
/*  431 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(String paramString, int paramInt) throws SQLException {
/*  439 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  440 */     sQLException.fillInStackTrace();
/*  441 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(int paramInt, long paramLong) throws SQLException {
/*  450 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  451 */     sQLException.fillInStackTrace();
/*  452 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLongAtName(String paramString, long paramLong) throws SQLException {
/*  460 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  461 */     sQLException.fillInStackTrace();
/*  462 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(String paramString, long paramLong) throws SQLException {
/*  470 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  471 */     sQLException.fillInStackTrace();
/*  472 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt, Object paramObject) throws SQLException {
/*  481 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  482 */     sQLException.fillInStackTrace();
/*  483 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObjectAtName(String paramString, Object paramObject) throws SQLException {
/*  491 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  492 */     sQLException.fillInStackTrace();
/*  493 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject) throws SQLException {
/*  501 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  502 */     sQLException.fillInStackTrace();
/*  503 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/*  512 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  513 */     sQLException.fillInStackTrace();
/*  514 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObjectAtName(String paramString, Object paramObject, int paramInt) throws SQLException {
/*  522 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  523 */     sQLException.fillInStackTrace();
/*  524 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt) throws SQLException {
/*  532 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  533 */     sQLException.fillInStackTrace();
/*  534 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(int paramInt, Ref paramRef) throws SQLException {
/*  543 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  544 */     sQLException.fillInStackTrace();
/*  545 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefAtName(String paramString, Ref paramRef) throws SQLException {
/*  553 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  554 */     sQLException.fillInStackTrace();
/*  555 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(String paramString, Ref paramRef) throws SQLException {
/*  563 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  564 */     sQLException.fillInStackTrace();
/*  565 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(int paramInt, short paramShort) throws SQLException {
/*  574 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  575 */     sQLException.fillInStackTrace();
/*  576 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShortAtName(String paramString, short paramShort) throws SQLException {
/*  584 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  585 */     sQLException.fillInStackTrace();
/*  586 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(String paramString, short paramShort) throws SQLException {
/*  594 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  595 */     sQLException.fillInStackTrace();
/*  596 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(int paramInt, String paramString) throws SQLException {
/*  605 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  606 */     sQLException.fillInStackTrace();
/*  607 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringAtName(String paramString1, String paramString2) throws SQLException {
/*  615 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  616 */     sQLException.fillInStackTrace();
/*  617 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(String paramString1, String paramString2) throws SQLException {
/*  625 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  626 */     sQLException.fillInStackTrace();
/*  627 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime) throws SQLException {
/*  636 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  637 */     sQLException.fillInStackTrace();
/*  638 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimeAtName(String paramString, Time paramTime) throws SQLException {
/*  646 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  647 */     sQLException.fillInStackTrace();
/*  648 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime) throws SQLException {
/*  656 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  657 */     sQLException.fillInStackTrace();
/*  658 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  667 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  668 */     sQLException.fillInStackTrace();
/*  669 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimeAtName(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  677 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  678 */     sQLException.fillInStackTrace();
/*  679 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  687 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  688 */     sQLException.fillInStackTrace();
/*  689 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/*  698 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  699 */     sQLException.fillInStackTrace();
/*  700 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp) throws SQLException {
/*  708 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  709 */     sQLException.fillInStackTrace();
/*  710 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp) throws SQLException {
/*  718 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  719 */     sQLException.fillInStackTrace();
/*  720 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  729 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  730 */     sQLException.fillInStackTrace();
/*  731 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  739 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  740 */     sQLException.fillInStackTrace();
/*  741 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  749 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  750 */     sQLException.fillInStackTrace();
/*  751 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/*  760 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  761 */     sQLException.fillInStackTrace();
/*  762 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURLAtName(String paramString, URL paramURL) throws SQLException {
/*  770 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  771 */     sQLException.fillInStackTrace();
/*  772 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(String paramString, URL paramURL) throws SQLException {
/*  780 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  781 */     sQLException.fillInStackTrace();
/*  782 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
/*  791 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  792 */     sQLException.fillInStackTrace();
/*  793 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAYAtName(String paramString, ARRAY paramARRAY) throws SQLException {
/*  801 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  802 */     sQLException.fillInStackTrace();
/*  803 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(String paramString, ARRAY paramARRAY) throws SQLException {
/*  811 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  812 */     sQLException.fillInStackTrace();
/*  813 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
/*  822 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  823 */     sQLException.fillInStackTrace();
/*  824 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILEAtName(String paramString, BFILE paramBFILE) throws SQLException {
/*  832 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  833 */     sQLException.fillInStackTrace();
/*  834 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(String paramString, BFILE paramBFILE) throws SQLException {
/*  842 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  843 */     sQLException.fillInStackTrace();
/*  844 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException {
/*  853 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  854 */     sQLException.fillInStackTrace();
/*  855 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfileAtName(String paramString, BFILE paramBFILE) throws SQLException {
/*  863 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  864 */     sQLException.fillInStackTrace();
/*  865 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(String paramString, BFILE paramBFILE) throws SQLException {
/*  873 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  874 */     sQLException.fillInStackTrace();
/*  875 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException {
/*  884 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  885 */     sQLException.fillInStackTrace();
/*  886 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloatAtName(String paramString, float paramFloat) throws SQLException {
/*  894 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  895 */     sQLException.fillInStackTrace();
/*  896 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, float paramFloat) throws SQLException {
/*  904 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  905 */     sQLException.fillInStackTrace();
/*  906 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/*  915 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  916 */     sQLException.fillInStackTrace();
/*  917 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloatAtName(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/*  925 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  926 */     sQLException.fillInStackTrace();
/*  927 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/*  935 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  936 */     sQLException.fillInStackTrace();
/*  937 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException {
/*  946 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  947 */     sQLException.fillInStackTrace();
/*  948 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDoubleAtName(String paramString, double paramDouble) throws SQLException {
/*  956 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  957 */     sQLException.fillInStackTrace();
/*  958 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, double paramDouble) throws SQLException {
/*  966 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  967 */     sQLException.fillInStackTrace();
/*  968 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/*  977 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  978 */     sQLException.fillInStackTrace();
/*  979 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDoubleAtName(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/*  987 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  988 */     sQLException.fillInStackTrace();
/*  989 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/*  997 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/*  998 */     sQLException.fillInStackTrace();
/*  999 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
/* 1008 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1009 */     sQLException.fillInStackTrace();
/* 1010 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOBAtName(String paramString, BLOB paramBLOB) throws SQLException {
/* 1018 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1019 */     sQLException.fillInStackTrace();
/* 1020 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(String paramString, BLOB paramBLOB) throws SQLException {
/* 1028 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1029 */     sQLException.fillInStackTrace();
/* 1030 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
/* 1039 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1040 */     sQLException.fillInStackTrace();
/* 1041 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHARAtName(String paramString, CHAR paramCHAR) throws SQLException {
/* 1049 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1050 */     sQLException.fillInStackTrace();
/* 1051 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(String paramString, CHAR paramCHAR) throws SQLException {
/* 1059 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1060 */     sQLException.fillInStackTrace();
/* 1061 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
/* 1070 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1071 */     sQLException.fillInStackTrace();
/* 1072 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOBAtName(String paramString, CLOB paramCLOB) throws SQLException {
/* 1080 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1081 */     sQLException.fillInStackTrace();
/* 1082 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(String paramString, CLOB paramCLOB) throws SQLException {
/* 1090 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1091 */     sQLException.fillInStackTrace();
/* 1092 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException {
/* 1101 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1102 */     sQLException.fillInStackTrace();
/* 1103 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursorAtName(String paramString, ResultSet paramResultSet) throws SQLException {
/* 1111 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1112 */     sQLException.fillInStackTrace();
/* 1113 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(String paramString, ResultSet paramResultSet) throws SQLException {
/* 1121 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1122 */     sQLException.fillInStackTrace();
/* 1123 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
/* 1132 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1133 */     sQLException.fillInStackTrace();
/* 1134 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatumAtName(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/* 1142 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1143 */     sQLException.fillInStackTrace();
/* 1144 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/* 1152 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1153 */     sQLException.fillInStackTrace();
/* 1154 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(int paramInt, DATE paramDATE) throws SQLException {
/* 1163 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1164 */     sQLException.fillInStackTrace();
/* 1165 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATEAtName(String paramString, DATE paramDATE) throws SQLException {
/* 1173 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1174 */     sQLException.fillInStackTrace();
/* 1175 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(String paramString, DATE paramDATE) throws SQLException {
/* 1183 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1184 */     sQLException.fillInStackTrace();
/* 1185 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(int paramInt, String paramString) throws SQLException {
/* 1194 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1195 */     sQLException.fillInStackTrace();
/* 1196 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHARAtName(String paramString1, String paramString2) throws SQLException {
/* 1204 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1205 */     sQLException.fillInStackTrace();
/* 1206 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(String paramString1, String paramString2) throws SQLException {
/* 1214 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1215 */     sQLException.fillInStackTrace();
/* 1216 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
/* 1225 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1226 */     sQLException.fillInStackTrace();
/* 1227 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDSAtName(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/* 1235 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1236 */     sQLException.fillInStackTrace();
/* 1237 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/* 1245 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1246 */     sQLException.fillInStackTrace();
/* 1247 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
/* 1256 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1257 */     sQLException.fillInStackTrace();
/* 1258 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYMAtName(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/* 1266 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1267 */     sQLException.fillInStackTrace();
/* 1268 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/* 1276 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1277 */     sQLException.fillInStackTrace();
/* 1278 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
/* 1287 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1288 */     sQLException.fillInStackTrace();
/* 1289 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBERAtName(String paramString, NUMBER paramNUMBER) throws SQLException {
/* 1297 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1298 */     sQLException.fillInStackTrace();
/* 1299 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(String paramString, NUMBER paramNUMBER) throws SQLException {
/* 1307 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1308 */     sQLException.fillInStackTrace();
/* 1309 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
/* 1318 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1319 */     sQLException.fillInStackTrace();
/* 1320 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUEAtName(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/* 1328 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1329 */     sQLException.fillInStackTrace();
/* 1330 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/* 1338 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1339 */     sQLException.fillInStackTrace();
/* 1340 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException {
/* 1349 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1350 */     sQLException.fillInStackTrace();
/* 1351 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObjectAtName(String paramString, Datum paramDatum) throws SQLException {
/* 1359 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1360 */     sQLException.fillInStackTrace();
/* 1361 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(String paramString, Datum paramDatum) throws SQLException {
/* 1369 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1370 */     sQLException.fillInStackTrace();
/* 1371 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(int paramInt, ORAData paramORAData) throws SQLException {
/* 1380 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1381 */     sQLException.fillInStackTrace();
/* 1382 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORADataAtName(String paramString, ORAData paramORAData) throws SQLException {
/* 1390 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1391 */     sQLException.fillInStackTrace();
/* 1392 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(String paramString, ORAData paramORAData) throws SQLException {
/* 1400 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1401 */     sQLException.fillInStackTrace();
/* 1402 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(int paramInt, RAW paramRAW) throws SQLException {
/* 1411 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1412 */     sQLException.fillInStackTrace();
/* 1413 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAWAtName(String paramString, RAW paramRAW) throws SQLException {
/* 1421 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1422 */     sQLException.fillInStackTrace();
/* 1423 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(String paramString, RAW paramRAW) throws SQLException {
/* 1431 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1432 */     sQLException.fillInStackTrace();
/* 1433 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(int paramInt, REF paramREF) throws SQLException {
/* 1442 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1443 */     sQLException.fillInStackTrace();
/* 1444 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREFAtName(String paramString, REF paramREF) throws SQLException {
/* 1452 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1453 */     sQLException.fillInStackTrace();
/* 1454 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(String paramString, REF paramREF) throws SQLException {
/* 1462 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1463 */     sQLException.fillInStackTrace();
/* 1464 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(int paramInt, REF paramREF) throws SQLException {
/* 1473 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1474 */     sQLException.fillInStackTrace();
/* 1475 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefTypeAtName(String paramString, REF paramREF) throws SQLException {
/* 1483 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1484 */     sQLException.fillInStackTrace();
/* 1485 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(String paramString, REF paramREF) throws SQLException {
/* 1493 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1494 */     sQLException.fillInStackTrace();
/* 1495 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(int paramInt, ROWID paramROWID) throws SQLException {
/* 1504 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1505 */     sQLException.fillInStackTrace();
/* 1506 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWIDAtName(String paramString, ROWID paramROWID) throws SQLException {
/* 1514 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1515 */     sQLException.fillInStackTrace();
/* 1516 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(String paramString, ROWID paramROWID) throws SQLException {
/* 1524 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1525 */     sQLException.fillInStackTrace();
/* 1526 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
/* 1535 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1536 */     sQLException.fillInStackTrace();
/* 1537 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCTAtName(String paramString, STRUCT paramSTRUCT) throws SQLException {
/* 1545 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1546 */     sQLException.fillInStackTrace();
/* 1547 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(String paramString, STRUCT paramSTRUCT) throws SQLException {
/* 1555 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1556 */     sQLException.fillInStackTrace();
/* 1557 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 1566 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1567 */     sQLException.fillInStackTrace();
/* 1568 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZAtName(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 1576 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1577 */     sQLException.fillInStackTrace();
/* 1578 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 1586 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1587 */     sQLException.fillInStackTrace();
/* 1588 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 1597 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1598 */     sQLException.fillInStackTrace();
/* 1599 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZAtName(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 1607 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1608 */     sQLException.fillInStackTrace();
/* 1609 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 1617 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1618 */     sQLException.fillInStackTrace();
/* 1619 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 1628 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1629 */     sQLException.fillInStackTrace();
/* 1630 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPAtName(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 1638 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1639 */     sQLException.fillInStackTrace();
/* 1640 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 1648 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1649 */     sQLException.fillInStackTrace();
/* 1650 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 1659 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1660 */     sQLException.fillInStackTrace();
/* 1661 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 1669 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1670 */     sQLException.fillInStackTrace();
/* 1671 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 1679 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1680 */     sQLException.fillInStackTrace();
/* 1681 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 1690 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1691 */     sQLException.fillInStackTrace();
/* 1692 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 1700 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1701 */     sQLException.fillInStackTrace();
/* 1702 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 1710 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1711 */     sQLException.fillInStackTrace();
/* 1712 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/* 1721 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1722 */     sQLException.fillInStackTrace();
/* 1723 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStreamAtName(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 1731 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1732 */     sQLException.fillInStackTrace();
/* 1733 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(String paramString, Reader paramReader, int paramInt) throws SQLException {
/* 1741 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1742 */     sQLException.fillInStackTrace();
/* 1743 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 1752 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1753 */     sQLException.fillInStackTrace();
/* 1754 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 1762 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1763 */     sQLException.fillInStackTrace();
/* 1764 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/* 1772 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1773 */     sQLException.fillInStackTrace();
/* 1774 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/* 1785 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1786 */     sQLException.fillInStackTrace();
/* 1787 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(String paramString) throws SQLException {
/* 1795 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1796 */     sQLException.fillInStackTrace();
/* 1797 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/* 1805 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1806 */     sQLException.fillInStackTrace();
/* 1807 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString) throws SQLException {
/* 1815 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1816 */     sQLException.fillInStackTrace();
/* 1817 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/* 1825 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1826 */     sQLException.fillInStackTrace();
/* 1827 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(String paramString, int paramInt) throws SQLException {
/* 1835 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1836 */     sQLException.fillInStackTrace();
/* 1837 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/* 1845 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1846 */     sQLException.fillInStackTrace();
/* 1847 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(String paramString) throws SQLException {
/* 1855 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1856 */     sQLException.fillInStackTrace();
/* 1857 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/* 1865 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1866 */     sQLException.fillInStackTrace();
/* 1867 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(String paramString) throws SQLException {
/* 1875 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1876 */     sQLException.fillInStackTrace();
/* 1877 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/* 1885 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1886 */     sQLException.fillInStackTrace();
/* 1887 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(String paramString) throws SQLException {
/* 1895 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1896 */     sQLException.fillInStackTrace();
/* 1897 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/* 1905 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1906 */     sQLException.fillInStackTrace();
/* 1907 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(String paramString) throws SQLException {
/* 1915 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1916 */     sQLException.fillInStackTrace();
/* 1917 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/* 1925 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1926 */     sQLException.fillInStackTrace();
/* 1927 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(String paramString) throws SQLException {
/* 1935 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1936 */     sQLException.fillInStackTrace();
/* 1937 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/* 1945 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1946 */     sQLException.fillInStackTrace();
/* 1947 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString) throws SQLException {
/* 1955 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1956 */     sQLException.fillInStackTrace();
/* 1957 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1965 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1966 */     sQLException.fillInStackTrace();
/* 1967 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(String paramString, Calendar paramCalendar) throws SQLException {
/* 1975 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1976 */     sQLException.fillInStackTrace();
/* 1977 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/* 1985 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1986 */     sQLException.fillInStackTrace();
/* 1987 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(String paramString) throws SQLException {
/* 1995 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 1996 */     sQLException.fillInStackTrace();
/* 1997 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/* 2005 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2006 */     sQLException.fillInStackTrace();
/* 2007 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(String paramString) throws SQLException {
/* 2015 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2016 */     sQLException.fillInStackTrace();
/* 2017 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/* 2025 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2026 */     sQLException.fillInStackTrace();
/* 2027 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(String paramString) throws SQLException {
/* 2035 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2036 */     sQLException.fillInStackTrace();
/* 2037 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/* 2045 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2046 */     sQLException.fillInStackTrace();
/* 2047 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(String paramString) throws SQLException {
/* 2055 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2056 */     sQLException.fillInStackTrace();
/* 2057 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/* 2065 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2066 */     sQLException.fillInStackTrace();
/* 2067 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString) throws SQLException {
/* 2075 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2076 */     sQLException.fillInStackTrace();
/* 2077 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 2085 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2086 */     sQLException.fillInStackTrace();
/* 2087 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, Map paramMap) throws SQLException {
/* 2095 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2096 */     sQLException.fillInStackTrace();
/* 2097 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 2105 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2106 */     sQLException.fillInStackTrace();
/* 2107 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(String paramString) throws SQLException {
/* 2115 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2116 */     sQLException.fillInStackTrace();
/* 2117 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/* 2125 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2126 */     sQLException.fillInStackTrace();
/* 2127 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(String paramString) throws SQLException {
/* 2135 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2136 */     sQLException.fillInStackTrace();
/* 2137 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/* 2145 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2146 */     sQLException.fillInStackTrace();
/* 2147 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(String paramString) throws SQLException {
/* 2155 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2156 */     sQLException.fillInStackTrace();
/* 2157 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/* 2165 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2166 */     sQLException.fillInStackTrace();
/* 2167 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString) throws SQLException {
/* 2175 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2176 */     sQLException.fillInStackTrace();
/* 2177 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2185 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2186 */     sQLException.fillInStackTrace();
/* 2187 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(String paramString, Calendar paramCalendar) throws SQLException {
/* 2195 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2196 */     sQLException.fillInStackTrace();
/* 2197 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/* 2205 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2206 */     sQLException.fillInStackTrace();
/* 2207 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString) throws SQLException {
/* 2215 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2216 */     sQLException.fillInStackTrace();
/* 2217 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 2225 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2226 */     sQLException.fillInStackTrace();
/* 2227 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(String paramString, Calendar paramCalendar) throws SQLException {
/* 2235 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2236 */     sQLException.fillInStackTrace();
/* 2237 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 2245 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2246 */     sQLException.fillInStackTrace();
/* 2247 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(String paramString) throws SQLException {
/* 2255 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2256 */     sQLException.fillInStackTrace();
/* 2257 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/* 2265 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2266 */     sQLException.fillInStackTrace();
/* 2267 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(String paramString) throws SQLException {
/* 2275 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2276 */     sQLException.fillInStackTrace();
/* 2277 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 2285 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2286 */     sQLException.fillInStackTrace();
/* 2287 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(String paramString) throws SQLException {
/* 2295 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2296 */     sQLException.fillInStackTrace();
/* 2297 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 2305 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2306 */     sQLException.fillInStackTrace();
/* 2307 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(String paramString) throws SQLException {
/* 2315 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2316 */     sQLException.fillInStackTrace();
/* 2317 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 2325 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2326 */     sQLException.fillInStackTrace();
/* 2327 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(String paramString) throws SQLException {
/* 2335 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2336 */     sQLException.fillInStackTrace();
/* 2337 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 2345 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2346 */     sQLException.fillInStackTrace();
/* 2347 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(String paramString) throws SQLException {
/* 2355 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2356 */     sQLException.fillInStackTrace();
/* 2357 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 2365 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2366 */     sQLException.fillInStackTrace();
/* 2367 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(String paramString) throws SQLException {
/* 2375 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2376 */     sQLException.fillInStackTrace();
/* 2377 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/* 2385 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2386 */     sQLException.fillInStackTrace();
/* 2387 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(String paramString) throws SQLException {
/* 2395 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2396 */     sQLException.fillInStackTrace();
/* 2397 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 2405 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2406 */     sQLException.fillInStackTrace();
/* 2407 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(String paramString, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 2415 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2416 */     sQLException.fillInStackTrace();
/* 2417 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/* 2425 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2426 */     sQLException.fillInStackTrace();
/* 2427 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(String paramString) throws SQLException {
/* 2435 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2436 */     sQLException.fillInStackTrace();
/* 2437 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 2445 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2446 */     sQLException.fillInStackTrace();
/* 2447 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(String paramString) throws SQLException {
/* 2455 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2456 */     sQLException.fillInStackTrace();
/* 2457 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 2465 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2466 */     sQLException.fillInStackTrace();
/* 2467 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(String paramString) throws SQLException {
/* 2475 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2476 */     sQLException.fillInStackTrace();
/* 2477 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/* 2485 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2486 */     sQLException.fillInStackTrace();
/* 2487 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(String paramString) throws SQLException {
/* 2495 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2496 */     sQLException.fillInStackTrace();
/* 2497 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 2505 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2506 */     sQLException.fillInStackTrace();
/* 2507 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(String paramString) throws SQLException {
/* 2515 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2516 */     sQLException.fillInStackTrace();
/* 2517 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/* 2525 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2526 */     sQLException.fillInStackTrace();
/* 2527 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(String paramString) throws SQLException {
/* 2535 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2536 */     sQLException.fillInStackTrace();
/* 2537 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 2545 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2546 */     sQLException.fillInStackTrace();
/* 2547 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(String paramString, ORADataFactory paramORADataFactory) throws SQLException {
/* 2555 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2556 */     sQLException.fillInStackTrace();
/* 2557 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 2565 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2566 */     sQLException.fillInStackTrace();
/* 2567 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(String paramString, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 2575 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2576 */     sQLException.fillInStackTrace();
/* 2577 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 2585 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2586 */     sQLException.fillInStackTrace();
/* 2587 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(String paramString) throws SQLException {
/* 2595 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2596 */     sQLException.fillInStackTrace();
/* 2597 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/* 2605 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2606 */     sQLException.fillInStackTrace();
/* 2607 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(String paramString) throws SQLException {
/* 2615 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2616 */     sQLException.fillInStackTrace();
/* 2617 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/* 2625 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2626 */     sQLException.fillInStackTrace();
/* 2627 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(String paramString) throws SQLException {
/* 2635 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2636 */     sQLException.fillInStackTrace();
/* 2637 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 2645 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2646 */     sQLException.fillInStackTrace();
/* 2647 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(String paramString) throws SQLException {
/* 2655 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2656 */     sQLException.fillInStackTrace();
/* 2657 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 2665 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2666 */     sQLException.fillInStackTrace();
/* 2667 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(String paramString) throws SQLException {
/* 2675 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2676 */     sQLException.fillInStackTrace();
/* 2677 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 2685 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2686 */     sQLException.fillInStackTrace();
/* 2687 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(String paramString) throws SQLException {
/* 2695 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2696 */     sQLException.fillInStackTrace();
/* 2697 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 2705 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2706 */     sQLException.fillInStackTrace();
/* 2707 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(String paramString) throws SQLException {
/* 2715 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2716 */     sQLException.fillInStackTrace();
/* 2717 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 2725 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2726 */     sQLException.fillInStackTrace();
/* 2727 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(String paramString) throws SQLException {
/* 2735 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2736 */     sQLException.fillInStackTrace();
/* 2737 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 2745 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2746 */     sQLException.fillInStackTrace();
/* 2747 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(String paramString) throws SQLException {
/* 2755 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2756 */     sQLException.fillInStackTrace();
/* 2757 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 2765 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2766 */     sQLException.fillInStackTrace();
/* 2767 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(String paramString) throws SQLException {
/* 2775 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2776 */     sQLException.fillInStackTrace();
/* 2777 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 2785 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2786 */     sQLException.fillInStackTrace();
/* 2787 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(String paramString) throws SQLException {
/* 2795 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2796 */     sQLException.fillInStackTrace();
/* 2797 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int paramInt1, int paramInt2) throws SQLException {
/* 2806 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2807 */     sQLException.fillInStackTrace();
/* 2808 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString, int paramInt) throws SQLException {
/* 2815 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2816 */     sQLException.fillInStackTrace();
/* 2817 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 2824 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2825 */     sQLException.fillInStackTrace();
/* 2826 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 2833 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2834 */     sQLException.fillInStackTrace();
/* 2835 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNullAtName(String paramString, int paramInt) throws SQLException {
/* 2842 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2843 */     sQLException.fillInStackTrace();
/* 2844 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNullAtName(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 2851 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2852 */     sQLException.fillInStackTrace();
/* 2853 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException {
/* 2864 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2865 */     sQLException.fillInStackTrace();
/* 2866 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
/* 2877 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2878 */     sQLException.fillInStackTrace();
/* 2879 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObjectAtName(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
/* 2890 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2891 */     sQLException.fillInStackTrace();
/* 2892 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/* 2905 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2906 */     sQLException.fillInStackTrace();
/* 2907 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 2915 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2916 */     sQLException.fillInStackTrace();
/* 2917 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxFieldSize() throws SQLException {
/* 2925 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2926 */     sQLException.fillInStackTrace();
/* 2927 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxRows() throws SQLException {
/* 2935 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2936 */     sQLException.fillInStackTrace();
/* 2937 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getQueryTimeout() throws SQLException {
/* 2945 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2946 */     sQLException.fillInStackTrace();
/* 2947 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetConcurrency() throws SQLException {
/* 2955 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2956 */     sQLException.fillInStackTrace();
/* 2957 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetHoldability() throws SQLException {
/* 2965 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2966 */     sQLException.fillInStackTrace();
/* 2967 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetType() throws SQLException {
/* 2975 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2976 */     sQLException.fillInStackTrace();
/* 2977 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUpdateCount() throws SQLException {
/* 2985 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2986 */     sQLException.fillInStackTrace();
/* 2987 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancel() throws SQLException {
/* 2995 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 2996 */     sQLException.fillInStackTrace();
/* 2997 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearBatch() throws SQLException {
/* 3005 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3006 */     sQLException.fillInStackTrace();
/* 3007 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/* 3015 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3016 */     sQLException.fillInStackTrace();
/* 3017 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMoreResults() throws SQLException {
/* 3030 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3031 */     sQLException.fillInStackTrace();
/* 3032 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int[] executeBatch() throws SQLException {
/* 3040 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3041 */     sQLException.fillInStackTrace();
/* 3042 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {
/* 3050 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3051 */     sQLException.fillInStackTrace();
/* 3052 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 3060 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3061 */     sQLException.fillInStackTrace();
/* 3062 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxFieldSize(int paramInt) throws SQLException {
/* 3070 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3071 */     sQLException.fillInStackTrace();
/* 3072 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxRows(int paramInt) throws SQLException {
/* 3080 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3081 */     sQLException.fillInStackTrace();
/* 3082 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQueryTimeout(int paramInt) throws SQLException {
/* 3090 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3091 */     sQLException.fillInStackTrace();
/* 3092 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMoreResults(int paramInt) throws SQLException {
/* 3100 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3101 */     sQLException.fillInStackTrace();
/* 3102 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEscapeProcessing(boolean paramBoolean) throws SQLException {
/* 3110 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3111 */     sQLException.fillInStackTrace();
/* 3112 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String paramString) throws SQLException {
/* 3120 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3121 */     sQLException.fillInStackTrace();
/* 3122 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBatch(String paramString) throws SQLException {
/* 3130 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3131 */     sQLException.fillInStackTrace();
/* 3132 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursorName(String paramString) throws SQLException {
/* 3140 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3141 */     sQLException.fillInStackTrace();
/* 3142 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String paramString) throws SQLException {
/* 3150 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3151 */     sQLException.fillInStackTrace();
/* 3152 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String paramString, int paramInt) throws SQLException {
/* 3160 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3161 */     sQLException.fillInStackTrace();
/* 3162 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String paramString, int paramInt) throws SQLException {
/* 3170 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3171 */     sQLException.fillInStackTrace();
/* 3172 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String paramString, int[] paramArrayOfint) throws SQLException {
/* 3180 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3181 */     sQLException.fillInStackTrace();
/* 3182 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String paramString, int[] paramArrayOfint) throws SQLException {
/* 3190 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3191 */     sQLException.fillInStackTrace();
/* 3192 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection() throws SQLException {
/* 3200 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3201 */     sQLException.fillInStackTrace();
/* 3202 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getGeneratedKeys() throws SQLException {
/* 3210 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3211 */     sQLException.fillInStackTrace();
/* 3212 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getResultSet() throws SQLException {
/* 3220 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3221 */     sQLException.fillInStackTrace();
/* 3222 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/* 3230 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3231 */     sQLException.fillInStackTrace();
/* 3232 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String paramString, String[] paramArrayOfString) throws SQLException {
/* 3240 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3241 */     sQLException.fillInStackTrace();
/* 3242 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String paramString, String[] paramArrayOfString) throws SQLException {
/* 3250 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3251 */     sQLException.fillInStackTrace();
/* 3252 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery(String paramString) throws SQLException {
/* 3260 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3261 */     sQLException.fillInStackTrace();
/* 3262 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/* 3276 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3277 */     sQLException.fillInStackTrace();
/* 3278 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2) throws SQLException {
/* 3286 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3287 */     sQLException.fillInStackTrace();
/* 3288 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3296 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3297 */     sQLException.fillInStackTrace();
/* 3298 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3, short paramShort) throws SQLException {
/* 3306 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3307 */     sQLException.fillInStackTrace();
/* 3308 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3316 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3317 */     sQLException.fillInStackTrace();
/* 3318 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3326 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3327 */     sQLException.fillInStackTrace();
/* 3328 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 3336 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3337 */     sQLException.fillInStackTrace();
/* 3338 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRowPrefetch() {
/* 3344 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResultSetCache(OracleResultSetCache paramOracleResultSetCache) throws SQLException {
/* 3351 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3352 */     sQLException.fillInStackTrace();
/* 3353 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowPrefetch(int paramInt) throws SQLException {
/* 3361 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3362 */     sQLException.fillInStackTrace();
/* 3363 */     throw sQLException;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getLobPrefetchSize() {
/* 3368 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLobPrefetchSize(int paramInt) throws SQLException {
/* 3374 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3375 */     sQLException.fillInStackTrace();
/* 3376 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeWithKey(String paramString) throws SQLException {
/* 3384 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3385 */     sQLException.fillInStackTrace();
/* 3386 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int creationState() {
/* 3392 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isNCHAR(int paramInt) throws SQLException {
/* 3399 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3400 */     sQLException.fillInStackTrace();
/* 3401 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate() throws SQLException {
/* 3413 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3414 */     sQLException.fillInStackTrace();
/* 3415 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBatch() throws SQLException {
/* 3423 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3424 */     sQLException.fillInStackTrace();
/* 3425 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearParameters() throws SQLException {
/* 3433 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3434 */     sQLException.fillInStackTrace();
/* 3435 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute() throws SQLException {
/* 3443 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3444 */     sQLException.fillInStackTrace();
/* 3445 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParameterMetaData getParameterMetaData() throws SQLException {
/* 3453 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3454 */     sQLException.fillInStackTrace();
/* 3455 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery() throws SQLException {
/* 3463 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3464 */     sQLException.fillInStackTrace();
/* 3465 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 3473 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3474 */     sQLException.fillInStackTrace();
/* 3475 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getReturnResultSet() throws SQLException {
/* 3483 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3484 */     sQLException.fillInStackTrace();
/* 3485 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineParameterTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3496 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3497 */     sQLException.fillInStackTrace();
/* 3498 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineParameterTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3506 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3507 */     sQLException.fillInStackTrace();
/* 3508 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineParameterType(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3516 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3517 */     sQLException.fillInStackTrace();
/* 3518 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getExecuteBatch() {
/* 3524 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sendBatch() throws SQLException {
/* 3531 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3532 */     sQLException.fillInStackTrace();
/* 3533 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExecuteBatch(int paramInt) throws SQLException {
/* 3541 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3542 */     sQLException.fillInStackTrace();
/* 3543 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException {
/* 3551 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3552 */     sQLException.fillInStackTrace();
/* 3553 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFormOfUse(int paramInt, short paramShort) {}
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisableStmtCaching(boolean paramBoolean) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleParameterMetaData OracleGetParameterMetaData() throws SQLException {
/* 3569 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3570 */     sQLException.fillInStackTrace();
/* 3571 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerReturnParameter(int paramInt1, int paramInt2) throws SQLException {
/* 3579 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3580 */     sQLException.fillInStackTrace();
/* 3581 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerReturnParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3589 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3590 */     sQLException.fillInStackTrace();
/* 3591 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerReturnParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 3599 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3600 */     sQLException.fillInStackTrace();
/* 3601 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 3609 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3610 */     sQLException.fillInStackTrace();
/* 3611 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlobAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 3619 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3620 */     sQLException.fillInStackTrace();
/* 3621 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(int paramInt, String paramString) throws SQLException {
/* 3630 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3631 */     sQLException.fillInStackTrace();
/* 3632 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClobAtName(String paramString1, String paramString2) throws SQLException {
/* 3640 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3641 */     sQLException.fillInStackTrace();
/* 3642 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException {
/* 3651 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3652 */     sQLException.fillInStackTrace();
/* 3653 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
/* 3662 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3663 */     sQLException.fillInStackTrace();
/* 3664 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptorAtName(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
/* 3673 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3674 */     sQLException.fillInStackTrace();
/* 3675 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getAnyDataEmbeddedObject(int paramInt) throws SQLException {
/* 3689 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3690 */     sQLException.fillInStackTrace();
/* 3691 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 3699 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3700 */     sQLException.fillInStackTrace();
/* 3701 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 3709 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3710 */     sQLException.fillInStackTrace();
/* 3711 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3719 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3720 */     sQLException.fillInStackTrace();
/* 3721 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(int paramInt1, int paramInt2) throws SQLException {
/* 3729 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3730 */     sQLException.fillInStackTrace();
/* 3731 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterBytes(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 3739 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3740 */     sQLException.fillInStackTrace();
/* 3741 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameterChars(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 3749 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3750 */     sQLException.fillInStackTrace();
/* 3751 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt) throws SQLException {
/* 3759 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3760 */     sQLException.fillInStackTrace();
/* 3761 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getPlsqlIndexTable(int paramInt, Class paramClass) throws SQLException {
/* 3769 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3770 */     sQLException.fillInStackTrace();
/* 3771 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum[] getOraclePlsqlIndexTable(int paramInt) throws SQLException {
/* 3779 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3780 */     sQLException.fillInStackTrace();
/* 3781 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerIndexTableOutParameter(int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException {
/* 3789 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3790 */     sQLException.fillInStackTrace();
/* 3791 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(String paramString1, String paramString2) throws SQLException {
/* 3799 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3800 */     sQLException.fillInStackTrace();
/* 3801 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 3809 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3810 */     sQLException.fillInStackTrace();
/* 3811 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 3819 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3820 */     sQLException.fillInStackTrace();
/* 3821 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/* 3830 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3831 */     sQLException.fillInStackTrace();
/* 3832 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt) throws SQLException {
/* 3840 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3841 */     sQLException.fillInStackTrace();
/* 3842 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString, int paramInt1, int paramInt2) throws SQLException {
/* 3850 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3851 */     sQLException.fillInStackTrace();
/* 3852 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerOutParameter(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 3860 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3861 */     sQLException.fillInStackTrace();
/* 3862 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] privateGetBytes(int paramInt) throws SQLException {
/* 3870 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3871 */     sQLException.fillInStackTrace();
/* 3872 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDatabaseChangeRegistration(DatabaseChangeRegistration paramDatabaseChangeRegistration) throws SQLException {
/* 3881 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3882 */     sQLException.fillInStackTrace();
/* 3883 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedString(boolean paramBoolean) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getFixedString() {
/* 3903 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean getserverCursor() {
/* 3908 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getcacheState() {
/* 3913 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   public int getstatementType() {
/* 3918 */     return 3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheckBindTypes(boolean paramBoolean) {}
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInternalBytes(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException {
/* 3929 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3930 */     sQLException.fillInStackTrace();
/* 3931 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enterImplicitCache() throws SQLException {
/* 3939 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3940 */     sQLException.fillInStackTrace();
/* 3941 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enterExplicitCache() throws SQLException {
/* 3949 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3950 */     sQLException.fillInStackTrace();
/* 3951 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitImplicitCacheToActive() throws SQLException {
/* 3959 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3960 */     sQLException.fillInStackTrace();
/* 3961 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitExplicitCacheToActive() throws SQLException {
/* 3969 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3970 */     sQLException.fillInStackTrace();
/* 3971 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitImplicitCacheToClose() throws SQLException {
/* 3979 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3980 */     sQLException.fillInStackTrace();
/* 3981 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitExplicitCacheToClose() throws SQLException {
/* 3989 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 3990 */     sQLException.fillInStackTrace();
/* 3991 */     throw sQLException;
/*      */   }
/*      */ 
/*      */   
/*      */   public String[] getRegisteredTableNames() throws SQLException {
/* 3996 */     return null;
/*      */   }
/*      */   
/*      */   public long getRegisteredQueryId() throws SQLException {
/* 4000 */     return -1L;
/*      */   }
/*      */ 
/*      */   
/*      */   public String getOriginalSql() throws SQLException {
/* 4005 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4006 */     sQLException.fillInStackTrace();
/* 4007 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSnapshotSCN(long paramLong) throws SQLException {
/* 4014 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4015 */     sQLException.fillInStackTrace();
/* 4016 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 4031 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleStatement.SqlKind getSqlKind() throws SQLException {
/* 4039 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4040 */     sQLException.fillInStackTrace();
/* 4041 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getChecksum() throws SQLException {
/* 4050 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4051 */     sQLException.fillInStackTrace();
/* 4052 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 4058 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/OracleClosedStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */