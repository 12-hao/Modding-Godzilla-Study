/*     */ package oracle.jdbc.rowset;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.rowset.FilteredRowSet;
/*     */ import javax.sql.rowset.Predicate;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleFilteredRowSet
/*     */   extends OracleWebRowSet
/*     */   implements FilteredRowSet
/*     */ {
/*     */   private Predicate predicate;
/*     */   
/*     */   public void setFilter(Predicate paramPredicate) throws SQLException {
/*  74 */     this.predicate = paramPredicate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Predicate getFilter() {
/*  90 */     return this.predicate;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean next() throws SQLException {
/* 100 */     if (this.rowCount <= 0) {
/* 101 */       return false;
/*     */     }
/* 103 */     if (this.presentRow >= this.rowCount) {
/* 104 */       return false;
/*     */     }
/* 106 */     boolean bool = false;
/*     */ 
/*     */     
/*     */     do {
/* 110 */       this.presentRow++;
/*     */       
/* 112 */       if (this.predicate == null || (this.predicate != null && this.predicate.evaluate(this))) {
/*     */ 
/*     */         
/* 115 */         bool = true;
/*     */         
/*     */         break;
/*     */       } 
/* 119 */     } while (this.presentRow <= this.rowCount);
/*     */     
/* 121 */     if (bool) {
/*     */       
/* 123 */       notifyCursorMoved();
/* 124 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 128 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean previous() throws SQLException {
/* 140 */     if (this.rowsetType == 1003) {
/*     */       
/* 142 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 344);
/* 143 */       sQLException.fillInStackTrace();
/* 144 */       throw sQLException;
/*     */     } 
/*     */     
/* 147 */     if (this.rowCount <= 0) {
/* 148 */       return false;
/*     */     }
/* 150 */     if (this.presentRow <= 1) {
/* 151 */       return false;
/*     */     }
/* 153 */     boolean bool = false;
/*     */ 
/*     */     
/*     */     do {
/* 157 */       this.presentRow--;
/*     */       
/* 159 */       if (this.predicate == null || (this.predicate != null && this.predicate.evaluate(this))) {
/*     */ 
/*     */         
/* 162 */         bool = true;
/*     */         
/*     */         break;
/*     */       } 
/* 166 */     } while (this.presentRow >= 1);
/*     */     
/* 168 */     if (bool) {
/*     */       
/* 170 */       notifyCursorMoved();
/* 171 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 175 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean absolute(int paramInt) throws SQLException {
/* 188 */     if (this.rowsetType == 1003) {
/*     */       
/* 190 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 344);
/* 191 */       sQLException.fillInStackTrace();
/* 192 */       throw sQLException;
/*     */     } 
/*     */     
/* 195 */     if (paramInt == 0 || Math.abs(paramInt) > this.rowCount) {
/* 196 */       return false;
/*     */     }
/*     */     
/* 199 */     int i = (paramInt < 0) ? (this.rowCount + paramInt + 1) : paramInt;
/*     */     
/* 201 */     byte b = 0;
/* 202 */     this.presentRow = 0;
/*     */ 
/*     */     
/* 205 */     while (b < i && this.presentRow <= this.rowCount) {
/*     */       
/* 207 */       if (next()) {
/* 208 */         b++; continue;
/*     */       } 
/* 210 */       return false;
/*     */     } 
/*     */     
/* 213 */     if (b == i) {
/*     */       
/* 215 */       notifyCursorMoved();
/* 216 */       return true;
/*     */     } 
/*     */     
/* 219 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void checkAndFilterObject(int paramInt, Object paramObject) throws SQLException {
/* 230 */     if (this.predicate != null && !this.predicate.evaluate(paramObject, paramInt)) {
/*     */       
/* 232 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 345);
/* 233 */       sQLException.fillInStackTrace();
/* 234 */       throw sQLException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 241 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/rowset/OracleFilteredRowSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */