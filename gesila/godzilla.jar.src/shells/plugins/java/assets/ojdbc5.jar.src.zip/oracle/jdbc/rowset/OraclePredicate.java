package oracle.jdbc.rowset;

import java.sql.SQLException;
import javax.sql.RowSet;
import javax.sql.rowset.Predicate;

public interface OraclePredicate extends Predicate {
  boolean evaluate(RowSet paramRowSet);
  
  boolean evaluate(Object paramObject, int paramInt) throws SQLException;
  
  boolean evaluate(Object paramObject, String paramString) throws SQLException;
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/rowset/OraclePredicate.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */