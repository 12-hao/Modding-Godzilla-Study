/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.BLOB;
/*     */ import oracle.sql.Datum;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleTypeBLOB
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   static final long serialVersionUID = -2311211431562030662L;
/*  33 */   static int fixedDataSize = 86;
/*     */ 
/*     */ 
/*     */   
/*     */   transient OracleConnection connection;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleTypeBLOB() {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleTypeBLOB(OracleConnection paramOracleConnection) {
/*  48 */     this.connection = paramOracleConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/*  62 */     BLOB bLOB = null;
/*     */     
/*  64 */     if (paramObject != null)
/*     */     {
/*  66 */       if (paramObject instanceof BLOB) {
/*  67 */         bLOB = (BLOB)paramObject;
/*     */       } else {
/*     */         
/*  70 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramObject);
/*  71 */         sQLException.fillInStackTrace();
/*  72 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */     
/*  76 */     return (Datum)bLOB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeCode() {
/*  86 */     return 2004;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Object toObject(byte[] paramArrayOfbyte, int paramInt, Map paramMap) throws SQLException {
/* 111 */     if (paramArrayOfbyte == null || paramArrayOfbyte.length == 0) {
/* 112 */       return null;
/*     */     }
/* 114 */     switch (paramInt) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 2:
/* 122 */         return this.connection.createBlobWithUnpickledBytes(paramArrayOfbyte);
/*     */ 
/*     */       
/*     */       case 3:
/* 126 */         return paramArrayOfbyte;
/*     */     } 
/*     */ 
/*     */     
/* 130 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 59, paramArrayOfbyte);
/* 131 */     sQLException.fillInStackTrace();
/* 132 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
/* 158 */     this.connection = paramOracleConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 173 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 210 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/oracore/OracleTypeBLOB.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */