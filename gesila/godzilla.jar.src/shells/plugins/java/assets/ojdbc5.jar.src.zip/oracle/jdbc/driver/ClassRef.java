/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.SQLException;
/*     */ import oracle.sql.OPAQUE;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ClassRef
/*     */ {
/*  42 */   static final XMLTypeClassRef XMLTYPE = XMLTypeClassRef.newInstance();
/*  43 */   public static final Locale LOCALE = Locale.newInstance();
/*     */ 
/*     */ 
/*     */   
/*     */   private final String className;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final ClassRef newInstance(String paramString) throws ClassNotFoundException {
/*  53 */     return new ClassRef(paramString);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ClassRef(String paramString) throws ClassNotFoundException {
/*  72 */     this.className = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Class get() {
/*     */     try {
/*  92 */       return Class.forName(this.className, true, Thread.currentThread().getContextClassLoader());
/*     */     }
/*  94 */     catch (ClassNotFoundException classNotFoundException) {
/*  95 */       NoClassDefFoundError noClassDefFoundError = new NoClassDefFoundError(classNotFoundException.getMessage());
/*  96 */       noClassDefFoundError.initCause(classNotFoundException);
/*  97 */       throw noClassDefFoundError;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   static class XMLTypeClassRef
/*     */     extends ClassRef
/*     */   {
/*     */     protected final Method CREATEXML;
/*     */     
/*     */     static final XMLTypeClassRef newInstance() {
/*     */       
/* 109 */       try { return new XMLTypeClassRef(); }
/*     */       
/* 111 */       catch (ClassNotFoundException classNotFoundException) {  }
/* 112 */       catch (NoClassDefFoundError noClassDefFoundError) {}
/* 113 */       return null;
/*     */     }
/*     */     
/*     */     private XMLTypeClassRef() throws ClassNotFoundException {
/* 117 */       super("oracle.xdb.XMLType");
/* 118 */       Method method = null;
/*     */       try {
/* 120 */         method = get().getDeclaredMethod("createXML", new Class[] { OPAQUE.class });
/*     */       }
/* 122 */       catch (NoSuchMethodException noSuchMethodException) {}
/* 123 */       this.CREATEXML = method;
/*     */     }
/*     */ 
/*     */     
/*     */     OPAQUE createXML(OPAQUE param1OPAQUE) throws SQLException {
/* 128 */       get();
/*     */       
/* 130 */       try { return (OPAQUE)this.CREATEXML.invoke(null, new Object[] { param1OPAQUE }); }
/*     */       
/* 132 */       catch (IllegalAccessException illegalAccessException) {  }
/* 133 */       catch (InvocationTargetException invocationTargetException) {}
/* 134 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static class LocaleCategoryClassRef
/*     */     extends ClassRef
/*     */   {
/*     */     static final LocaleCategoryClassRef newInstance() {
/*     */       
/* 149 */       try { return new LocaleCategoryClassRef(); }
/*     */       
/* 151 */       catch (ClassNotFoundException classNotFoundException) {  }
/* 152 */       catch (NoClassDefFoundError noClassDefFoundError) {}
/* 153 */       return null;
/*     */     }
/*     */     
/*     */     private LocaleCategoryClassRef() throws ClassNotFoundException {
/* 157 */       super("java.util.Locale$Category");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static class Locale
/*     */   {
/*     */     protected final Method localeJDK7getDefault;
/*     */ 
/*     */     
/*     */     protected final Object localeCategoryEnumFORMAT;
/*     */ 
/*     */ 
/*     */     
/*     */     static final Locale newInstance() {
/*     */       try {
/* 174 */         return new Locale();
/*     */       }
/* 176 */       catch (Exception exception) {
/* 177 */         return null;
/*     */       } 
/*     */     }
/*     */     
/*     */     private Locale() {
/* 182 */       ClassRef.LocaleCategoryClassRef localeCategoryClassRef = ClassRef.LocaleCategoryClassRef.newInstance();
/* 183 */       Method method = null;
/* 184 */       Object object = null;
/*     */       
/* 186 */       if (localeCategoryClassRef != null) {
/*     */         
/*     */         try {
/*     */ 
/*     */           
/* 191 */           Object[] arrayOfObject = localeCategoryClassRef.get().getEnumConstants();
/* 192 */           for (Object object1 : arrayOfObject) { if (((Enum)object1).name() == "FORMAT") { object = object1; break; }  }
/* 193 */            method = java.util.Locale.class.getDeclaredMethod("getDefault", new Class[] { localeCategoryClassRef.get() });
/*     */         }
/* 195 */         catch (Throwable throwable) {
/* 196 */           method = null;
/* 197 */           object = null;
/*     */         } 
/*     */       }
/* 200 */       this.localeJDK7getDefault = method;
/* 201 */       this.localeCategoryEnumFORMAT = object;
/*     */     }
/*     */     
/*     */     public java.util.Locale getDefault() {
/*     */       
/* 206 */       try { if (this.localeJDK7getDefault == null) {
/* 207 */           return java.util.Locale.getDefault();
/*     */         }
/* 209 */         return (java.util.Locale)this.localeJDK7getDefault.invoke(null, new Object[] { this.localeCategoryEnumFORMAT }); }
/*     */       
/* 211 */       catch (IllegalAccessException illegalAccessException) {  }
/* 212 */       catch (InvocationTargetException invocationTargetException) {}
/* 213 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/* 218 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/ClassRef.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */