/*      */ package oracle.jdbc.oracore;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.io.Serializable;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleCallableStatement;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.ArrayDescriptor;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.SQLName;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TypeDescriptor;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OracleTypeCOLLECTION
/*      */   extends OracleTypeADT
/*      */   implements Serializable
/*      */ {
/*      */   static final long serialVersionUID = -7279638692691669378L;
/*      */   public static final int TYPE_PLSQL_INDEX_TABLE = 1;
/*      */   public static final int TYPE_NESTED_TABLE = 2;
/*      */   public static final int TYPE_VARRAY = 3;
/*   59 */   int userCode = 0;
/*   60 */   long maxSize = 0L;
/*   61 */   OracleType elementType = null;
/*      */   static final int CURRENT_USER_OBJECT = 0;
/*      */   static final int CURRENT_USER_SYNONYM = 1;
/*      */   static final int CURRENT_USER_SYNONYM_10g = 2;
/*      */   static final int CURRENT_USER_PUBLIC_SYNONYM = 3;
/*      */   static final int CURRENT_USER_PUBLIC_SYNONYM_10g = 4;
/*      */   static final int POSSIBLY_OTHER_USER_OBJECT = 5;
/*      */   
/*      */   public OracleTypeCOLLECTION(String paramString, OracleConnection paramOracleConnection) throws SQLException {
/*   70 */     super(paramString, (Connection)paramOracleConnection);
/*      */   }
/*      */   
/*      */   static final int POSSIBLY_OTHER_USER_OBJECT_10g = 6;
/*      */   static final int OTHER_USER_OBJECT = 7;
/*      */   static final int OTHER_USER_SYNONYM = 8;
/*      */   
/*      */   public OracleTypeCOLLECTION(OracleTypeADT paramOracleTypeADT, int paramInt, OracleConnection paramOracleConnection) throws SQLException {
/*   78 */     super(paramOracleTypeADT, paramInt, (Connection)paramOracleConnection);
/*      */   }
/*      */ 
/*      */   
/*      */   static final int PUBLIC_SYNONYM = 9;
/*      */   
/*      */   static final int PUBLIC_SYNONYM_10g = 10;
/*      */   
/*      */   static final int BREAK = 11;
/*      */   
/*      */   public OracleTypeCOLLECTION(SQLName paramSQLName, byte[] paramArrayOfbyte1, int paramInt, byte[] paramArrayOfbyte2, OracleConnection paramOracleConnection) throws SQLException {
/*   89 */     super(paramSQLName, paramArrayOfbyte1, paramInt, paramArrayOfbyte2, paramOracleConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum toDatum(Object paramObject, OracleConnection paramOracleConnection) throws SQLException {
/*  105 */     if (paramObject != null) {
/*      */       
/*  107 */       if (paramObject instanceof ARRAY) {
/*  108 */         return (Datum)paramObject;
/*      */       }
/*      */       
/*  111 */       ArrayDescriptor arrayDescriptor = createArrayDescriptor();
/*      */       
/*  113 */       return (Datum)new ARRAY(arrayDescriptor, (Connection)this.connection, paramObject);
/*      */     } 
/*      */ 
/*      */     
/*  117 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getTypeCode() {
/*  129 */     return 2003;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInHierarchyOf(OracleType paramOracleType) throws SQLException {
/*  140 */     if (paramOracleType == null) {
/*  141 */       return false;
/*      */     }
/*  143 */     if (paramOracleType == this) {
/*  144 */       return true;
/*      */     }
/*  146 */     if (paramOracleType.getClass() != getClass()) {
/*  147 */       return false;
/*      */     }
/*  149 */     return paramOracleType.getTypeDescriptor().getName().equals(this.descriptor.getName());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isInHierarchyOf(StructDescriptor paramStructDescriptor) throws SQLException {
/*  158 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isObjectType() {
/*  165 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void parseTDSrec(TDSReader paramTDSReader) throws SQLException {
/*  179 */     long l = paramTDSReader.readLong();
/*      */ 
/*      */ 
/*      */     
/*  183 */     this.maxSize = paramTDSReader.readLong();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  189 */     this.userCode = paramTDSReader.readByte();
/*      */ 
/*      */     
/*  192 */     paramTDSReader.addSimplePatch(l, this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong, Datum paramDatum, int paramInt, Map paramMap) throws SQLException {
/*  204 */     return unlinearize(paramArrayOfbyte, paramLong, paramDatum, 1L, -1, paramInt, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong1, Datum paramDatum, long paramLong2, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/*  213 */     OracleConnection oracleConnection = getConnection();
/*  214 */     Datum datum = null;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  219 */     if (oracleConnection == null) {
/*      */       
/*  221 */       datum = unlinearizeInternal(paramArrayOfbyte, paramLong1, paramDatum, paramLong2, paramInt1, paramInt2, paramMap);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  226 */       synchronized (oracleConnection) {
/*      */         
/*  228 */         datum = unlinearizeInternal(paramArrayOfbyte, paramLong1, paramDatum, paramLong2, paramInt1, paramInt2, paramMap);
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/*  233 */     return datum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Datum unlinearizeInternal(byte[] paramArrayOfbyte, long paramLong1, Datum paramDatum, long paramLong2, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/*  245 */     if (paramArrayOfbyte == null) {
/*  246 */       return null;
/*      */     }
/*      */     
/*  249 */     PickleContext pickleContext = new PickleContext(paramArrayOfbyte, paramLong1);
/*      */     
/*  251 */     return (Datum)unpickle81(pickleContext, (ARRAY)paramDatum, paramLong2, paramInt1, 1, paramInt2, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isInlineImage(byte[] paramArrayOfbyte, int paramInt) throws SQLException {
/*  262 */     if (paramArrayOfbyte == null) {
/*  263 */       return false;
/*      */     }
/*      */ 
/*      */     
/*  267 */     if (PickleContext.isCollectionImage_pctx(paramArrayOfbyte[paramInt]))
/*  268 */       return true; 
/*  269 */     if (PickleContext.isDegenerateImage_pctx(paramArrayOfbyte[paramInt])) {
/*  270 */       return false;
/*      */     }
/*      */     
/*  273 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not a collection image");
/*  274 */     sQLException.fillInStackTrace();
/*  275 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected int pickle81(PickleContext paramPickleContext, Datum paramDatum) throws SQLException {
/*  289 */     ARRAY aRRAY = (ARRAY)paramDatum;
/*      */     
/*  291 */     boolean bool = aRRAY.hasDataSeg();
/*  292 */     int i = 0;
/*  293 */     int j = paramPickleContext.offset() + 2;
/*      */     
/*  295 */     if (bool) {
/*      */       
/*  297 */       if (!this.metaDataInitialized) {
/*  298 */         copy_properties((OracleTypeCOLLECTION)aRRAY.getDescriptor().getPickler());
/*      */       }
/*  300 */       Datum[] arrayOfDatum = aRRAY.getOracleArray();
/*      */ 
/*      */       
/*  303 */       if (this.userCode == 3)
/*      */       {
/*  305 */         if (arrayOfDatum.length > this.maxSize) {
/*      */           
/*  307 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 71, null);
/*  308 */           sQLException.fillInStackTrace();
/*  309 */           throw sQLException;
/*      */         } 
/*      */       }
/*      */       
/*  313 */       i += paramPickleContext.writeCollImageHeader(arrayOfDatum.length, this.typeVersion);
/*      */       
/*  315 */       for (byte b = 0; b < arrayOfDatum.length; b++)
/*      */       {
/*  317 */         if (arrayOfDatum[b] == null) {
/*  318 */           i += paramPickleContext.writeElementNull();
/*      */         } else {
/*  320 */           i += this.elementType.pickle81(paramPickleContext, arrayOfDatum[b]);
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  327 */       i += paramPickleContext.writeCollImageHeader(aRRAY.getLocator());
/*      */     } 
/*      */     
/*  330 */     paramPickleContext.patchImageLen(j, i);
/*      */     
/*  332 */     return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ARRAY unpickle81(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/*  343 */     return unpickle81(paramPickleContext, paramARRAY, 1L, -1, paramInt1, paramInt2, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ARRAY unpickle81(PickleContext paramPickleContext, ARRAY paramARRAY, long paramLong, int paramInt1, int paramInt2, int paramInt3, Map paramMap) throws SQLException {
/*  357 */     ARRAY aRRAY = paramARRAY;
/*      */     
/*  359 */     if (aRRAY == null) {
/*      */       
/*  361 */       ArrayDescriptor arrayDescriptor = createArrayDescriptor();
/*      */       
/*  363 */       aRRAY = new ARRAY(arrayDescriptor, (byte[])null, (Connection)this.connection);
/*      */     } 
/*      */     
/*  366 */     if (unpickle81ImgHeader(paramPickleContext, aRRAY, paramInt2, paramInt3))
/*      */     {
/*  368 */       if (paramLong == 1L && paramInt1 == -1) {
/*  369 */         unpickle81ImgBody(paramPickleContext, aRRAY, paramInt3, paramMap);
/*      */       } else {
/*  371 */         unpickle81ImgBody(paramPickleContext, aRRAY, paramLong, paramInt1, paramInt3, paramMap);
/*      */       } 
/*      */     }
/*      */     
/*  375 */     return aRRAY;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean unpickle81ImgHeader(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2) throws SQLException {
/*  383 */     boolean bool = true;
/*      */     
/*  385 */     if (paramInt1 == 3)
/*      */     {
/*  387 */       paramARRAY.setImage(paramPickleContext.image(), paramPickleContext.absoluteOffset(), 0L);
/*      */     }
/*      */     
/*  390 */     byte b = paramPickleContext.readByte();
/*      */     
/*  392 */     if (!PickleContext.is81format(b)) {
/*      */       
/*  394 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not in 8.1 format");
/*  395 */       sQLException.fillInStackTrace();
/*  396 */       throw sQLException;
/*      */     } 
/*      */     
/*  399 */     if (!PickleContext.hasPrefix(b)) {
/*      */       
/*  401 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image has no prefix segment");
/*  402 */       sQLException.fillInStackTrace();
/*  403 */       throw sQLException;
/*      */     } 
/*      */     
/*  406 */     if (PickleContext.isCollectionImage_pctx(b)) {
/*  407 */       bool = true;
/*  408 */     } else if (PickleContext.isDegenerateImage_pctx(b)) {
/*  409 */       bool = false;
/*      */     } else {
/*      */       
/*  412 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Image is not a collection image");
/*  413 */       sQLException.fillInStackTrace();
/*  414 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  418 */     paramPickleContext.readByte();
/*      */ 
/*      */     
/*  421 */     if (paramInt1 == 9) {
/*      */       
/*  423 */       paramPickleContext.skipBytes(paramPickleContext.readLength(true) - 2);
/*      */       
/*  425 */       return false;
/*      */     } 
/*  427 */     if (paramInt1 == 3) {
/*      */       
/*  429 */       long l = paramPickleContext.readLength();
/*      */       
/*  431 */       paramARRAY.setImageLength(l);
/*  432 */       paramPickleContext.skipTo(paramARRAY.getImageOffset() + l);
/*      */       
/*  434 */       return false;
/*      */     } 
/*      */     
/*  437 */     paramPickleContext.skipLength();
/*      */ 
/*      */     
/*  440 */     int i = paramPickleContext.readLength();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  445 */     paramARRAY.setPrefixFlag(paramPickleContext.readByte());
/*      */     
/*  447 */     if (paramARRAY.isInline()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  454 */       paramPickleContext.readDataValue(i - 1);
/*      */     }
/*      */     else {
/*      */       
/*  458 */       paramARRAY.setLocator(paramPickleContext.readDataValue(i - 1));
/*      */     } 
/*      */     
/*  461 */     return paramARRAY.isInline();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unpickle81ImgBody(PickleContext paramPickleContext, ARRAY paramARRAY, long paramLong, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/*  473 */     paramPickleContext.readByte();
/*      */ 
/*      */     
/*  476 */     int i = paramPickleContext.readLength();
/*      */     
/*  478 */     paramARRAY.setLength(i);
/*      */     
/*  480 */     if (paramInt2 == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  485 */     int j = (int)getAccessLength(i, paramLong, paramInt1);
/*  486 */     boolean bool = (ArrayDescriptor.getCacheStyle(paramARRAY) == 1) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  491 */     if (paramLong > 1L && j > 0) {
/*      */       
/*  493 */       long l = paramARRAY.getLastIndex();
/*      */       
/*  495 */       if (l < paramLong) {
/*      */         
/*  497 */         if (l > 0L) {
/*  498 */           paramPickleContext.skipTo(paramARRAY.getLastOffset());
/*      */         } else {
/*  500 */           l = 1L;
/*      */         } 
/*  502 */         if (bool) {
/*      */           long l1;
/*  504 */           for (l1 = l; l1 < paramLong; l1++) {
/*      */             
/*  506 */             paramARRAY.setIndexOffset(l1, paramPickleContext.offset());
/*  507 */             this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */           } 
/*      */         } else {
/*      */           long l1;
/*      */           
/*  512 */           for (l1 = l; l1 < paramLong; l1++) {
/*  513 */             this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */           }
/*      */         } 
/*  516 */       } else if (l > paramLong) {
/*      */         
/*  518 */         long l1 = paramARRAY.getOffset(paramLong);
/*      */         
/*  520 */         if (l1 != -1L) {
/*      */           
/*  522 */           paramPickleContext.skipTo(l1);
/*      */ 
/*      */         
/*      */         }
/*  526 */         else if (bool) {
/*      */           
/*  528 */           for (byte b = 1; b < paramLong; b++)
/*      */           {
/*  530 */             paramARRAY.setIndexOffset(b, paramPickleContext.offset());
/*  531 */             this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  536 */           for (byte b = 1; b < paramLong; b++) {
/*  537 */             this.elementType.unpickle81rec(paramPickleContext, 9, null);
/*      */           }
/*      */         } 
/*      */       } else {
/*      */         
/*  542 */         paramPickleContext.skipTo(paramARRAY.getLastOffset());
/*      */       } 
/*  544 */       paramARRAY.setLastIndexOffset(paramLong, paramPickleContext.offset());
/*      */     } 
/*      */ 
/*      */     
/*  548 */     unpickle81ImgBodyElements(paramPickleContext, paramARRAY, (int)paramLong, j, paramInt2, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void unpickle81ImgBody(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt, Map paramMap) throws SQLException {
/*  560 */     paramPickleContext.readByte();
/*      */ 
/*      */     
/*  563 */     int i = paramPickleContext.readLength();
/*      */     
/*  565 */     paramARRAY.setLength(i);
/*      */     
/*  567 */     if (paramInt == 0) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  572 */     unpickle81ImgBodyElements(paramPickleContext, paramARRAY, 1, i, paramInt, paramMap);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void unpickle81ImgBodyElements(PickleContext paramPickleContext, ARRAY paramARRAY, int paramInt1, int paramInt2, int paramInt3, Map paramMap) throws SQLException {
/*      */     Datum[] arrayOfDatum;
/*      */     Object[] arrayOfObject;
/*      */     SQLException sQLException;
/*  583 */     boolean bool = (ArrayDescriptor.getCacheStyle(paramARRAY) == 1) ? true : false;
/*      */ 
/*      */ 
/*      */     
/*  587 */     switch (paramInt3) {
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  592 */         arrayOfDatum = new Datum[paramInt2];
/*      */         
/*  594 */         if (bool) {
/*      */           
/*  596 */           for (byte b = 0; b < paramInt2; b++)
/*      */           {
/*  598 */             paramARRAY.setIndexOffset((paramInt1 + b), paramPickleContext.offset());
/*      */             
/*  600 */             arrayOfDatum[b] = (Datum)this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
/*      */           }
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  606 */           for (byte b = 0; b < paramInt2; b++) {
/*  607 */             arrayOfDatum[b] = (Datum)this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
/*      */           }
/*      */         } 
/*      */         
/*  611 */         paramARRAY.setDatumArray(arrayOfDatum);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  618 */         arrayOfObject = ArrayDescriptor.makeJavaArray(paramInt2, this.elementType.getTypeCode());
/*      */ 
/*      */         
/*  621 */         if (bool) {
/*      */           
/*  623 */           for (byte b = 0; b < paramInt2; b++)
/*      */           {
/*  625 */             paramARRAY.setIndexOffset((paramInt1 + b), paramPickleContext.offset());
/*      */             
/*  627 */             arrayOfObject[b] = this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/*  632 */           for (byte b = 0; b < paramInt2; b++) {
/*  633 */             arrayOfObject[b] = this.elementType.unpickle81rec(paramPickleContext, paramInt3, paramMap);
/*      */           }
/*      */         } 
/*  636 */         paramARRAY.setObjArray(arrayOfObject);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*  651 */         if (this.elementType instanceof OracleTypeNUMBER || this.elementType instanceof OracleTypeFLOAT) {
/*      */ 
/*      */           
/*  654 */           paramARRAY.setObjArray(OracleTypeNUMBER.unpickle81NativeArray(paramPickleContext, 1L, paramInt2, paramInt3));
/*      */           
/*      */           break;
/*      */         } 
/*      */         
/*  659 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "This feature is limited to numeric collection");
/*  660 */         sQLException.fillInStackTrace();
/*  661 */         throw sQLException;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       default:
/*  669 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "Invalid conversion type " + this.elementType);
/*  670 */         sQLException.fillInStackTrace();
/*  671 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  676 */     paramARRAY.setLastIndexOffset((paramInt1 + paramInt2), paramPickleContext.offset());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  699 */   static final String[] sqlString = new String[] { "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME = :1", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME in (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :1 CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :1 FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM USER_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM ALL_SYNONYMS START WITH SYNONYM_NAME = :1 AND  OWNER = 'PUBLIC' CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER UNION SELECT :2  FROM DUAL) ", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL)", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE TYPE_NAME IN (SELECT TABLE_NAME FROM USER_SYNONYMS START WITH SYNONYM_NAME = :tname CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME UNION SELECT :tname FROM DUAL)", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE OWNER = :1 AND TYPE_NAME = :2", "SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES WHERE OWNER = (SELECT TABLE_OWNER FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:1) AND TYPE_NAME = (SELECT TABLE_NAME FROM ALL_SYNONYMS WHERE SYNONYM_NAME=:2) ", "DECLARE   the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;", "DECLARE   the_owner VARCHAR2(100);   the_type  VARCHAR2(100); begin  SELECT TABLE_NAME, TABLE_OWNER INTO THE_TYPE, THE_OWNER  FROM ALL_SYNONYMS  WHERE TABLE_NAME IN (SELECT TYPE_NAME FROM ALL_TYPES)  START WITH SYNONYM_NAME = :1 AND OWNER = 'PUBLIC'  CONNECT BY NOCYCLE PRIOR TABLE_NAME = SYNONYM_NAME AND TABLE_OWNER = OWNER; OPEN :2 FOR SELECT ELEM_TYPE_NAME, ELEM_TYPE_OWNER FROM ALL_COLL_TYPES  WHERE TYPE_NAME = THE_TYPE and OWNER = THE_OWNER; END;" };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initCollElemTypeName() throws SQLException {
/*  805 */     if (this.connection == null)
/*      */       return; 
/*  807 */     synchronized (this.connection) {
/*  808 */       if (this.sqlName == null) {
/*  809 */         getFullName();
/*      */       }
/*  811 */       CallableStatement callableStatement = null;
/*  812 */       PreparedStatement preparedStatement = null;
/*  813 */       ResultSet resultSet = null;
/*      */       try {
/*  815 */         byte b = this.sqlName.getSchema().equalsIgnoreCase(this.connection.getDefaultSchemaNameForNamedTypes()) ? 0 : 7;
/*      */ 
/*      */         
/*  818 */         while (b != 11) {
/*      */           
/*  820 */           switch (b) {
/*      */ 
/*      */             
/*      */             case false:
/*  824 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  825 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/*  826 */               preparedStatement.setFetchSize(1);
/*  827 */               resultSet = preparedStatement.executeQuery();
/*  828 */               b = 1;
/*      */               break;
/*      */             
/*      */             case true:
/*  832 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/*  834 */                 b = 2;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/*  839 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  840 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/*  841 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/*  842 */               preparedStatement.setFetchSize(1);
/*  843 */               resultSet = preparedStatement.executeQuery();
/*  844 */               b = 3;
/*      */               break;
/*      */             
/*      */             case true:
/*  848 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/*  850 */                 b = 4;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/*  855 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  856 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/*  857 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/*  858 */               preparedStatement.setFetchSize(1);
/*  859 */               resultSet = preparedStatement.executeQuery();
/*  860 */               b = 5;
/*      */               break;
/*      */             
/*      */             case true:
/*  864 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/*  866 */                 b = 6;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/*  871 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  872 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/*  873 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/*  874 */               preparedStatement.setFetchSize(1);
/*  875 */               resultSet = preparedStatement.executeQuery();
/*  876 */               b = 8;
/*      */               break;
/*      */ 
/*      */             
/*      */             case true:
/*  881 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  882 */               preparedStatement.setString(1, this.sqlName.getSchema());
/*  883 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/*  884 */               preparedStatement.setFetchSize(1);
/*  885 */               resultSet = preparedStatement.executeQuery();
/*  886 */               b = 8;
/*      */               break;
/*      */ 
/*      */             
/*      */             case true:
/*  891 */               preparedStatement = this.connection.prepareStatement(getSqlHint() + sqlString[b]);
/*  892 */               preparedStatement.setString(1, this.sqlName.getSimpleName());
/*  893 */               preparedStatement.setString(2, this.sqlName.getSimpleName());
/*  894 */               preparedStatement.setFetchSize(1);
/*  895 */               resultSet = preparedStatement.executeQuery();
/*  896 */               b = 9;
/*      */               break;
/*      */             
/*      */             case true:
/*  900 */               if (this.connection.getVersionNumber() >= 10000)
/*      */               {
/*  902 */                 b = 10;
/*      */               }
/*      */ 
/*      */             
/*      */             case true:
/*  907 */               callableStatement = this.connection.prepareCall(getSqlHint() + sqlString[b]);
/*  908 */               callableStatement.setString(1, this.sqlName.getSimpleName());
/*  909 */               callableStatement.registerOutParameter(2, -10);
/*  910 */               callableStatement.execute();
/*  911 */               resultSet = ((OracleCallableStatement)callableStatement).getCursor(2);
/*  912 */               b = 11;
/*      */               break;
/*      */           } 
/*      */           
/*  916 */           if (resultSet.next()) {
/*      */             
/*  918 */             if (this.attrTypeNames == null) {
/*  919 */               this.attrTypeNames = new String[1];
/*      */             }
/*  921 */             this.attrTypeNames[0] = resultSet.getString(2) + "." + resultSet.getString(1);
/*  922 */             b = 11; continue;
/*  923 */           }  if (b == 11) {
/*      */             
/*  925 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*  926 */             sQLException.fillInStackTrace();
/*  927 */             throw sQLException;
/*      */           } 
/*      */         } 
/*  930 */         while (b != 11);
/*      */       } finally {
/*      */         
/*  933 */         if (resultSet != null)
/*  934 */           resultSet.close(); 
/*  935 */         if (preparedStatement != null)
/*  936 */           preparedStatement.close(); 
/*  937 */         if (callableStatement != null) {
/*  938 */           callableStatement.close();
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeName(int paramInt) throws SQLException {
/*  948 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1);
/*  949 */     sQLException.fillInStackTrace();
/*  950 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeName(int paramInt, boolean paramBoolean) throws SQLException {
/*  958 */     return getAttributeName(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeType(int paramInt) throws SQLException {
/*  971 */     if (paramInt != 1) {
/*      */       
/*  973 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  974 */       sQLException.fillInStackTrace();
/*  975 */       throw sQLException;
/*      */     } 
/*      */     
/*  978 */     if (this.sqlName == null) {
/*  979 */       getFullName();
/*      */     }
/*  981 */     if (this.attrTypeNames == null) {
/*  982 */       initCollElemTypeName();
/*      */     }
/*  984 */     return this.attrTypeNames[0];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAttributeType(int paramInt, boolean paramBoolean) throws SQLException {
/*  991 */     if (paramBoolean) {
/*  992 */       return getAttributeType(paramInt);
/*      */     }
/*      */     
/*  995 */     if (paramInt != 1) {
/*      */       
/*  997 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  998 */       sQLException.fillInStackTrace();
/*  999 */       throw sQLException;
/*      */     } 
/*      */     
/* 1002 */     if (this.sqlName != null && this.attrTypeNames != null) {
/* 1003 */       return this.attrTypeNames[0];
/*      */     }
/* 1005 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getNumAttrs() throws SQLException {
/* 1013 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleType getAttrTypeAt(int paramInt) throws SQLException {
/* 1020 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayDescriptor createArrayDescriptor() throws SQLException {
/* 1027 */     return new ArrayDescriptor(this, (Connection)this.connection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayDescriptor createArrayDescriptorWithItsOwnTree() throws SQLException {
/* 1034 */     if (this.descriptor == null)
/*      */     {
/* 1036 */       if (this.sqlName == null && getFullName(false) == null) {
/*      */         
/* 1038 */         this.descriptor = (TypeDescriptor)new ArrayDescriptor(this, (Connection)this.connection);
/*      */       }
/*      */       else {
/*      */         
/* 1042 */         this.descriptor = (TypeDescriptor)ArrayDescriptor.createDescriptor(this.sqlName, (Connection)this.connection);
/*      */       } 
/*      */     }
/*      */     
/* 1046 */     return (ArrayDescriptor)this.descriptor;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleType getElementType() throws SQLException {
/* 1053 */     return this.elementType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUserCode() throws SQLException {
/* 1060 */     return this.userCode;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getMaxLength() throws SQLException {
/* 1067 */     return this.maxSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private long getAccessLength(long paramLong1, long paramLong2, int paramInt) throws SQLException {
/* 1075 */     if (paramLong2 > paramLong1) {
/* 1076 */       return 0L;
/*      */     }
/* 1078 */     if (paramInt < 0)
/*      */     {
/* 1080 */       return paramLong1 - paramLong2 + 1L;
/*      */     }
/*      */ 
/*      */     
/* 1084 */     return Math.min(paramLong1 - paramLong2 + 1L, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/* 1096 */     paramObjectOutputStream.writeInt(this.userCode);
/* 1097 */     paramObjectOutputStream.writeLong(this.maxSize);
/* 1098 */     paramObjectOutputStream.writeObject(this.elementType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 1106 */     this.userCode = paramObjectInputStream.readInt();
/* 1107 */     this.maxSize = paramObjectInputStream.readLong();
/* 1108 */     this.elementType = (OracleType)paramObjectInputStream.readObject();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
/* 1115 */     this.connection = paramOracleConnection;
/*      */     
/* 1117 */     this.elementType.setConnection(paramOracleConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void initMetadataRecursively() throws SQLException {
/* 1124 */     initMetadata(this.connection);
/* 1125 */     if (this.elementType != null) this.elementType.initMetadataRecursively();
/*      */   
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void initChildNamesRecursively(Map paramMap) throws SQLException {
/* 1132 */     TypeTreeElement typeTreeElement = (TypeTreeElement)paramMap.get(this.sqlName);
/*      */     
/* 1134 */     if (this.elementType != null) {
/*      */       
/* 1136 */       this.elementType.setNames(typeTreeElement.getChildSchemaName(0), typeTreeElement.getChildTypeName(0));
/* 1137 */       this.elementType.initChildNamesRecursively(paramMap);
/* 1138 */       this.elementType.cacheDescriptor();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cacheDescriptor() throws SQLException {
/* 1146 */     this.descriptor = (TypeDescriptor)ArrayDescriptor.createDescriptor(this);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void printXML(PrintWriter paramPrintWriter, int paramInt) throws SQLException {
/* 1153 */     printXML(paramPrintWriter, paramInt, false);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void printXML(PrintWriter paramPrintWriter, int paramInt, boolean paramBoolean) throws SQLException {
/*      */     byte b;
/* 1160 */     for (b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
/* 1161 */      paramPrintWriter.println("<OracleTypeCOLLECTION sqlName=\"" + this.sqlName + "\" " + ">");
/*      */ 
/*      */     
/* 1164 */     if (this.elementType != null)
/* 1165 */       this.elementType.printXML(paramPrintWriter, paramInt + 1, paramBoolean); 
/* 1166 */     for (b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
/* 1167 */      paramPrintWriter.println("</OracleTypeCOLLECTION>");
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1172 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/oracore/OracleTypeCOLLECTION.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */