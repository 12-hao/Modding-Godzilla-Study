/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CVarnumAccessor
/*     */   extends VarnumAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   boolean underlyingLongRaw = false;
/*     */   final int[] meta;
/*     */   
/*     */   T4CVarnumAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  43 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 107 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; } T4CVarnumAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, (paramInt1 == -1) ? paramInt8 : paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     if (paramOracleStatement != null && paramOracleStatement.implicitDefineForLobPrefetchDone) {
/*     */       this.definedColumnType = 0;
/*     */       this.definedColumnSize = 0;
/*     */     } else {
/*     */       this.definedColumnType = paramInt7;
/*     */       this.definedColumnSize = paramInt8;
/*     */     } 
/*     */     if (paramInt1 == -1)
/*     */       this.underlyingLongRaw = true;  } void processIndicator(int paramInt) throws IOException, SQLException {
/*     */     if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2();
/*     */       this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     } 
/*     */   } boolean unmarshalOneRow() throws SQLException, IOException {
/* 129 */     if (this.isUseLess) {
/*     */       
/* 131 */       this.lastRowProcessed++;
/*     */       
/* 133 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 138 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 142 */       byte[] arrayOfByte = new byte[16000];
/*     */       
/* 144 */       this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/* 145 */       processIndicator(this.meta[0]);
/*     */       
/* 147 */       this.lastRowProcessed++;
/*     */       
/* 149 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 153 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 154 */     int j = this.lengthIndex + this.lastRowProcessed;
/*     */ 
/*     */ 
/*     */     
/* 158 */     if (this.isNullByDescribe) {
/*     */       
/* 160 */       this.rowSpaceIndicator[i] = -1;
/* 161 */       this.rowSpaceIndicator[j] = 0;
/* 162 */       this.lastRowProcessed++;
/*     */       
/* 164 */       if (this.statement.connection.versionNumber < 9200) {
/* 165 */         processIndicator(0);
/*     */       }
/* 167 */       return false;
/*     */     } 
/*     */     
/* 170 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*     */ 
/*     */ 
/*     */     
/* 174 */     this.mare.unmarshalCLR(this.rowSpaceByte, k + 1, this.meta, this.byteLength - 1);
/*     */ 
/*     */ 
/*     */     
/* 178 */     this.rowSpaceByte[k] = (byte)this.meta[0];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     processIndicator(this.meta[0]);
/*     */     
/* 186 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 190 */       this.rowSpaceIndicator[i] = -1;
/* 191 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 195 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 200 */       this.rowSpaceIndicator[i] = 0;
/*     */     } 
/*     */     
/* 203 */     this.lastRowProcessed++;
/*     */     
/* 205 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copyRow() throws SQLException, IOException {
/*     */     int i;
/* 215 */     if (this.lastRowProcessed == 0) {
/* 216 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 218 */       i = this.lastRowProcessed - 1;
/*     */     } 
/*     */     
/* 221 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/* 222 */     int k = this.columnIndex + i * this.byteLength;
/* 223 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 224 */     int n = this.indicatorIndex + i;
/* 225 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 226 */     int i2 = this.lengthIndex + i;
/* 227 */     short s = this.rowSpaceIndicator[i2];
/* 228 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 230 */     int i4 = this.metaDataIndex + i * 1;
/*     */ 
/*     */ 
/*     */     
/* 234 */     this.rowSpaceIndicator[i1] = (short)s;
/* 235 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */ 
/*     */     
/* 238 */     if (!this.isNullByDescribe)
/*     */     {
/* 240 */       System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s + 1);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 245 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*     */ 
/*     */     
/* 248 */     this.lastRowProcessed++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/* 260 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*     */     
/* 262 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*     */     
/* 264 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 265 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 266 */     int n = this.lengthIndex + paramInt2 - 1;
/* 267 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 268 */     short s = paramArrayOfshort[i1];
/*     */     
/* 270 */     this.rowSpaceIndicator[n] = (short)s;
/* 271 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*     */ 
/*     */     
/* 274 */     if (s != 0)
/*     */     {
/* 276 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s + 1);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 294 */     String str = super.getString(paramInt);
/*     */     
/* 296 */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/*     */     {
/* 298 */       str = str.substring(0, this.definedColumnSize);
/*     */     }
/* 300 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 309 */     if (this.definedColumnType == 0) {
/* 310 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 313 */     Object object = null;
/*     */     
/* 315 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 317 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 318 */       sQLException.fillInStackTrace();
/* 319 */       throw sQLException;
/*     */     } 
/*     */     
/* 322 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 324 */       switch (this.definedColumnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case -1:
/*     */         case 1:
/*     */         case 12:
/* 332 */           return getString(paramInt);
/*     */ 
/*     */         
/*     */         case 2:
/*     */         case 3:
/* 337 */           return getBigDecimal(paramInt);
/*     */         
/*     */         case 4:
/* 340 */           return Integer.valueOf(getInt(paramInt));
/*     */         
/*     */         case -6:
/* 343 */           return Byte.valueOf(getByte(paramInt));
/*     */         
/*     */         case 5:
/* 346 */           return Short.valueOf(getShort(paramInt));
/*     */ 
/*     */         
/*     */         case -7:
/*     */         case 16:
/* 351 */           return Boolean.valueOf(getBoolean(paramInt));
/*     */         
/*     */         case -5:
/* 354 */           return Long.valueOf(getLong(paramInt));
/*     */         
/*     */         case 7:
/* 357 */           return Float.valueOf(getFloat(paramInt));
/*     */ 
/*     */         
/*     */         case 6:
/*     */         case 8:
/* 362 */           return Double.valueOf(getDouble(paramInt));
/*     */         
/*     */         case 91:
/* 365 */           return getDate(paramInt);
/*     */         
/*     */         case 92:
/* 368 */           return getTime(paramInt);
/*     */         
/*     */         case 93:
/* 371 */           return getTimestamp(paramInt);
/*     */ 
/*     */ 
/*     */         
/*     */         case -4:
/*     */         case -3:
/*     */         case -2:
/* 378 */           return getBytes(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 382 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 383 */       sQLException.fillInStackTrace();
/* 384 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 390 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 396 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/T4CVarnumAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */