/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ import javax.sql.ConnectionEvent;
/*     */ import javax.sql.ConnectionEventListener;
/*     */ import javax.sql.PooledConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleConnectionCacheEventListener
/*     */   implements ConnectionEventListener, Serializable
/*     */ {
/*     */   static final int CONNECTION_CLOSED_EVENT = 101;
/*     */   static final int CONNECTION_ERROROCCURED_EVENT = 102;
/*  41 */   protected OracleImplicitConnectionCache implicitCache = null;
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleConnectionCacheEventListener() {
/*  46 */     this(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleConnectionCacheEventListener(OracleImplicitConnectionCache paramOracleImplicitConnectionCache) {
/*  55 */     this.implicitCache = paramOracleImplicitConnectionCache;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionClosed(ConnectionEvent paramConnectionEvent) {
/*     */     try {
/*  72 */       if (this.implicitCache != null)
/*     */       {
/*  74 */         this.implicitCache.reusePooledConnection((PooledConnection)paramConnectionEvent.getSource());
/*     */       }
/*     */     }
/*  77 */     catch (SQLException sQLException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void connectionErrorOccurred(ConnectionEvent paramConnectionEvent) {
/*     */     try {
/*  92 */       if (this.implicitCache != null)
/*     */       {
/*  94 */         this.implicitCache.closePooledConnection((PooledConnection)paramConnectionEvent.getSource());
/*     */       }
/*     */     }
/*  97 */     catch (SQLException sQLException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/pool/OracleConnectionCacheEventListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */