/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CPreparedStatement
/*      */   extends OraclePreparedStatement
/*      */ {
/*      */   T4CPreparedStatement(PhysicalConnection paramPhysicalConnection, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*   30 */     super(paramPhysicalConnection, paramString, paramPhysicalConnection.defaultExecuteBatch, paramPhysicalConnection.defaultRowPrefetch, paramInt1, paramInt2);
/*      */ 
/*      */     
/*   33 */     this.nbPostPonedColumns = new int[1];
/*   34 */     this.nbPostPonedColumns[0] = 0;
/*   35 */     this.indexOfPostPonedColumn = new int[1][3];
/*   36 */     this.t4Connection = (T4CConnection)paramPhysicalConnection;
/*      */     
/*   38 */     this.theRowidBinder = theStaticT4CRowidBinder;
/*   39 */     this.theRowidNullBinder = theStaticT4CRowidNullBinder;
/*   40 */     this.theURowidBinder = theStaticT4CURowidBinder;
/*   41 */     this.theURowidNullBinder = theStaticT4CURowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   48 */   static final byte[] EMPTY_BYTE = new byte[0];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   T4CConnection t4Connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doOall8(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5) throws SQLException, IOException {
/*   68 */     if (paramBoolean1 || paramBoolean4 || !paramBoolean2) {
/*   69 */       this.oacdefSent = null;
/*      */     }
/*   71 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.doOall8");
/*      */     
/*   73 */     if (this.sqlKind == OracleStatement.SqlKind.UNINITIALIZED) {
/*      */ 
/*      */ 
/*      */       
/*   77 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 439, "sqlKind = " + this.sqlKind);
/*   78 */       sQLException.fillInStackTrace();
/*   79 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*   83 */     if (paramBoolean3) {
/*   84 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     }
/*   86 */     int i = this.numberOfDefinePositions;
/*      */     
/*   88 */     if (this.sqlKind.isDML()) {
/*   89 */       i = 0;
/*      */     }
/*      */     
/*   92 */     if (this.accessors != null)
/*   93 */       for (byte b = 0; b < this.accessors.length; b++) {
/*   94 */         if (this.accessors[b] != null)
/*   95 */           (this.accessors[b]).lastRowProcessed = 0; 
/*   96 */       }   if (this.outBindAccessors != null)
/*   97 */       for (byte b = 0; b < this.outBindAccessors.length; b++) {
/*   98 */         if (this.outBindAccessors[b] != null)
/*   99 */           (this.outBindAccessors[b]).lastRowProcessed = 0; 
/*  100 */       }   if (this.returnParamAccessors != null) {
/*  101 */       for (byte b = 0; b < this.returnParamAccessors.length; b++) {
/*  102 */         if (this.returnParamAccessors[b] != null) {
/*  103 */           (this.returnParamAccessors[b]).lastRowProcessed = 0;
/*      */         }
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  110 */     if (this.bindIndicators != null) {
/*      */       
/*  112 */       int j = ((this.bindIndicators[this.bindIndicatorSubRange + 3] & 0xFFFF) << 16) + (this.bindIndicators[this.bindIndicatorSubRange + 4] & 0xFFFF);
/*      */ 
/*      */       
/*  115 */       int k = 0;
/*      */       
/*  117 */       if (this.ibtBindChars != null) {
/*  118 */         k = this.ibtBindChars.length * this.connection.conversion.cMaxCharSize;
/*      */       }
/*  120 */       for (byte b = 0; b < this.numberOfBindPositions; b++) {
/*      */         
/*  122 */         int m = this.bindIndicatorSubRange + 5 + 10 * b;
/*      */ 
/*      */ 
/*      */         
/*  126 */         int n = this.bindIndicators[m + 2] & 0xFFFF;
/*      */ 
/*      */ 
/*      */         
/*  130 */         if (n != 0) {
/*      */ 
/*      */           
/*  133 */           int i1 = this.bindIndicators[m + 9] & 0xFFFF;
/*      */ 
/*      */ 
/*      */           
/*  137 */           if (i1 == 2) {
/*      */             
/*  139 */             k = Math.max(n * this.connection.conversion.maxNCharSize, k);
/*      */           
/*      */           }
/*      */           else {
/*      */             
/*  144 */             k = Math.max(n * this.connection.conversion.cMaxCharSize, k);
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  150 */       if (this.tmpBindsByteArray == null)
/*      */       {
/*  152 */         this.tmpBindsByteArray = new byte[k];
/*      */       }
/*  154 */       else if (this.tmpBindsByteArray.length < k)
/*      */       {
/*  156 */         this.tmpBindsByteArray = null;
/*  157 */         this.tmpBindsByteArray = new byte[k];
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */ 
/*      */       
/*  169 */       this.tmpBindsByteArray = null;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  174 */     int[] arrayOfInt1 = this.definedColumnType;
/*  175 */     int[] arrayOfInt2 = this.definedColumnSize;
/*  176 */     int[] arrayOfInt3 = this.definedColumnFormOfUse;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  182 */     if (paramBoolean5 && paramBoolean4 && this.sqlObject.includeRowid) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  187 */       arrayOfInt1 = new int[this.definedColumnType.length + 1];
/*  188 */       System.arraycopy(this.definedColumnType, 0, arrayOfInt1, 1, this.definedColumnType.length);
/*  189 */       arrayOfInt1[0] = -8;
/*  190 */       arrayOfInt2 = new int[this.definedColumnSize.length + 1];
/*  191 */       System.arraycopy(this.definedColumnSize, 0, arrayOfInt2, 1, this.definedColumnSize.length);
/*  192 */       arrayOfInt3 = new int[this.definedColumnFormOfUse.length + 1];
/*  193 */       System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt3, 1, this.definedColumnFormOfUse.length);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  199 */     allocateTmpByteArray();
/*      */     
/*  201 */     T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */     
/*  203 */     this.t4Connection.sendPiggyBackedMessages();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  208 */       t4C8Oall.doOALL(paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4, paramBoolean5, this.sqlKind, this.cursorId, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals), this.rowPrefetch, this.outBindAccessors, this.numberOfBindPositions, this.accessors, i, this.bindBytes, this.bindChars, this.bindIndicators, this.bindIndicatorSubRange, this.connection.conversion, this.tmpBindsByteArray, this.parameterStream, this.parameterDatum, this.parameterOtype, this, this.ibtBindBytes, this.ibtBindChars, this.ibtBindIndicators, this.oacdefSent, arrayOfInt1, arrayOfInt2, arrayOfInt3, this.registration);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  220 */       int j = t4C8Oall.getCursorId();
/*  221 */       if (j != 0) {
/*  222 */         this.cursorId = j;
/*      */       }
/*  224 */       this.oacdefSent = t4C8Oall.oacdefBindsSent;
/*      */     }
/*  226 */     catch (SQLException sQLException) {
/*      */       
/*  228 */       int j = t4C8Oall.getCursorId();
/*  229 */       if (j != 0) {
/*  230 */         this.cursorId = j;
/*      */       }
/*  232 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/*  235 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/*  240 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {
/*  250 */     if (this.tmpByteArray == null) {
/*      */ 
/*      */       
/*  253 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     }
/*  255 */     else if (this.sizeTmpByteArray > this.tmpByteArray.length) {
/*      */ 
/*      */ 
/*      */       
/*  259 */       this.tmpByteArray = new byte[this.sizeTmpByteArray];
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void releaseBuffers() {
/*  271 */     super.releaseBuffers();
/*  272 */     this.tmpByteArray = null;
/*  273 */     this.tmpBindsByteArray = null;
/*      */     
/*  275 */     this.t4Connection.all8.bindChars = null;
/*  276 */     this.t4Connection.all8.bindBytes = null;
/*  277 */     this.t4Connection.all8.tmpBindsByteArray = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateRowidAccessor() throws SQLException {
/*  284 */     this.accessors[0] = new T4CRowidAccessor(this, 128, (short)1, -8, false, this.t4Connection.mare);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {
/*  297 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/*  308 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  319 */     if (paramInt1 < 1) {
/*      */       
/*  321 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  322 */       sQLException.fillInStackTrace();
/*  323 */       throw sQLException;
/*      */     } 
/*  325 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */       
/*  329 */       if (paramInt2 == 1 || paramInt2 == 12)
/*      */       {
/*      */ 
/*      */         
/*  333 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */ 
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  339 */     else if (paramInt3 < 0) {
/*      */       
/*  341 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/*  342 */       sQLException.fillInStackTrace();
/*  343 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  347 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/*  349 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/*  350 */       sQLException.fillInStackTrace();
/*  351 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  358 */     int i = paramInt1 - 1;
/*      */     
/*  360 */     if (this.definedColumnType == null || this.definedColumnType.length <= i)
/*      */     {
/*  362 */       if (this.definedColumnType == null) {
/*      */         
/*  364 */         this.definedColumnType = new int[(i + 1) * 4];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  376 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  378 */         System.arraycopy(this.definedColumnType, 0, arrayOfInt, 0, this.definedColumnType.length);
/*      */ 
/*      */         
/*  381 */         this.definedColumnType = arrayOfInt;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  387 */     this.definedColumnType[i] = paramInt2;
/*      */     
/*  389 */     if (this.definedColumnSize == null || this.definedColumnSize.length <= i)
/*      */     {
/*  391 */       if (this.definedColumnSize == null) {
/*  392 */         this.definedColumnSize = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  395 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  397 */         System.arraycopy(this.definedColumnSize, 0, arrayOfInt, 0, this.definedColumnSize.length);
/*      */ 
/*      */         
/*  400 */         this.definedColumnSize = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  404 */     this.definedColumnSize[i] = paramInt3;
/*      */     
/*  406 */     if (this.definedColumnFormOfUse == null || this.definedColumnFormOfUse.length <= i)
/*      */     {
/*  408 */       if (this.definedColumnFormOfUse == null) {
/*  409 */         this.definedColumnFormOfUse = new int[(i + 1) * 4];
/*      */       } else {
/*      */         
/*  412 */         int[] arrayOfInt = new int[(i + 1) * 4];
/*      */         
/*  414 */         System.arraycopy(this.definedColumnFormOfUse, 0, arrayOfInt, 0, this.definedColumnFormOfUse.length);
/*      */ 
/*      */         
/*  417 */         this.definedColumnFormOfUse = arrayOfInt;
/*      */       } 
/*      */     }
/*      */     
/*  421 */     this.definedColumnFormOfUse[i] = paramShort;
/*      */     
/*  423 */     if (this.accessors != null && i < this.accessors.length && this.accessors[i] != null) {
/*      */       
/*  425 */       (this.accessors[i]).definedColumnSize = paramInt3;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  430 */       if (((this.accessors[i]).internalType == 96 || (this.accessors[i]).internalType == 1) && (paramInt2 == 1 || paramInt2 == 12))
/*      */       {
/*      */ 
/*      */         
/*  434 */         if (paramInt3 <= (this.accessors[i]).oacmxl) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  440 */           this.needToPrepareDefineBuffer = true;
/*  441 */           this.columnsDefinedByUser = true;
/*      */           
/*  443 */           this.accessors[i].initForDataAccess(paramInt2, paramInt3, null);
/*  444 */           this.accessors[i].calculateSizeTmpByteArray();
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/*  453 */     synchronized (this.connection) {
/*      */       
/*  455 */       super.clearDefines();
/*  456 */       this.definedColumnType = null;
/*  457 */       this.definedColumnSize = null;
/*  458 */       this.definedColumnFormOfUse = null;
/*  459 */       this.t4Connection.all8.definesAccessors = null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDefineBuffersIfRequired(char[] paramArrayOfchar, byte[] paramArrayOfbyte, short[] paramArrayOfshort, boolean paramBoolean) throws SQLException {
/*  477 */     boolean bool = (this.rowPrefetchInLastFetch < this.rowPrefetch) ? true : false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  506 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  515 */       paramArrayOfshort = new short[this.defineIndicators.length];
/*  516 */       int j = (this.accessors[0]).lengthIndexLastRow;
/*  517 */       int k = (this.accessors[0]).indicatorIndexLastRow;
/*      */       
/*  519 */       int m = bool ? this.accessors.length : 1;
/*  520 */       for (; bool ? (m >= 1) : (m <= this.accessors.length); 
/*  521 */         m += bool ? -1 : 1) {
/*      */         
/*  523 */         int n = j + this.rowPrefetchInLastFetch * m - 1;
/*  524 */         int i1 = k + this.rowPrefetchInLastFetch * m - 1;
/*  525 */         paramArrayOfshort[i1] = this.defineIndicators[i1];
/*  526 */         paramArrayOfshort[n] = this.defineIndicators[n];
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  533 */     int i = bool ? (this.accessors.length - 1) : 0;
/*  534 */     for (; bool ? (i > -1) : (i < this.accessors.length); 
/*  535 */       i += bool ? -1 : 1)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  542 */       this.accessors[i].saveDataFromOldDefineBuffers(paramArrayOfbyte, paramArrayOfchar, paramArrayOfshort, (this.rowPrefetchInLastFetch != -1) ? this.rowPrefetchInLastFetch : this.rowPrefetch, this.rowPrefetch);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  549 */     super.saveDefineBuffersIfRequired(paramArrayOfchar, paramArrayOfbyte, paramArrayOfshort, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  559 */     this.inScn = paramLong; } Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException { T4CVarcharAccessor t4CVarcharAccessor;
/*      */     T4CNumberAccessor t4CNumberAccessor;
/*      */     T4CVarnumAccessor t4CVarnumAccessor;
/*      */     T4CRawAccessor t4CRawAccessor;
/*      */     T4CBinaryFloatAccessor t4CBinaryFloatAccessor;
/*      */     T4CBinaryDoubleAccessor t4CBinaryDoubleAccessor;
/*      */     T4CRowidAccessor t4CRowidAccessor;
/*      */     T4CResultSetAccessor t4CResultSetAccessor;
/*      */     T4CDateAccessor t4CDateAccessor;
/*      */     T4CBlobAccessor t4CBlobAccessor;
/*      */     T4CClobAccessor t4CClobAccessor;
/*      */     T4CBfileAccessor t4CBfileAccessor;
/*      */     T4CNamedTypeAccessor t4CNamedTypeAccessor;
/*      */     T4CRefTypeAccessor t4CRefTypeAccessor;
/*      */     T4CTimestampAccessor t4CTimestampAccessor;
/*      */     T4CTimestamptzAccessor t4CTimestamptzAccessor;
/*      */     T4CTimestampltzAccessor t4CTimestampltzAccessor;
/*      */     T4CIntervalymAccessor t4CIntervalymAccessor;
/*      */     T4CIntervaldsAccessor t4CIntervaldsAccessor;
/*      */     SQLException sQLException;
/*  579 */     T4CCharAccessor t4CCharAccessor = null;
/*      */     
/*  581 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/*  585 */         t4CCharAccessor = new T4CCharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 8:
/*  591 */         if (!paramBoolean) {
/*      */           
/*  593 */           T4CLongAccessor t4CLongAccessor = new T4CLongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 1:
/*  601 */         t4CVarcharAccessor = new T4CVarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 2:
/*  607 */         t4CNumberAccessor = new T4CNumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 6:
/*  613 */         t4CVarnumAccessor = new T4CVarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 24:
/*  619 */         if (!paramBoolean) {
/*      */           
/*  621 */           T4CLongRawAccessor t4CLongRawAccessor = new T4CLongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/*  629 */         if (paramBoolean && paramString != null) {
/*      */           
/*  631 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/*  632 */           sQLException1.fillInStackTrace();
/*  633 */           throw sQLException1;
/*      */         } 
/*      */         
/*  636 */         if (paramBoolean) {
/*  637 */           T4COutRawAccessor t4COutRawAccessor = new T4COutRawAccessor(this, paramInt4, paramShort, paramInt2, this.t4Connection.mare);
/*      */           break;
/*      */         } 
/*  640 */         t4CRawAccessor = new T4CRawAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 100:
/*  646 */         t4CBinaryFloatAccessor = new T4CBinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  652 */         t4CBinaryDoubleAccessor = new T4CBinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 104:
/*  658 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  664 */           T4CVarcharAccessor t4CVarcharAccessor1 = new T4CVarcharAccessor(this, 18, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */ 
/*      */           
/*  668 */           t4CVarcharAccessor1.definedColumnType = -8;
/*      */           break;
/*      */         } 
/*  671 */         t4CRowidAccessor = new T4CRowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  678 */         t4CResultSetAccessor = new T4CResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 12:
/*  684 */         t4CDateAccessor = new T4CDateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 113:
/*  690 */         t4CBlobAccessor = new T4CBlobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 112:
/*  696 */         t4CClobAccessor = new T4CClobAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 114:
/*  702 */         t4CBfileAccessor = new T4CBfileAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/*  708 */         t4CNamedTypeAccessor = new T4CNamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  711 */         t4CNamedTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */       
/*      */       case 111:
/*  716 */         t4CRefTypeAccessor = new T4CRefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */ 
/*      */         
/*  719 */         t4CRefTypeAccessor.initMetadata();
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/*  726 */         t4CTimestampAccessor = new T4CTimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 181:
/*  732 */         t4CTimestamptzAccessor = new T4CTimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 231:
/*  738 */         t4CTimestampltzAccessor = new T4CTimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 182:
/*  744 */         t4CIntervalymAccessor = new T4CIntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */       
/*      */       case 183:
/*  750 */         t4CIntervaldsAccessor = new T4CIntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean, this.t4Connection.mare);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/*  766 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/*  767 */         sQLException.fillInStackTrace();
/*  768 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  772 */     return t4CIntervaldsAccessor; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doDescribe(boolean paramBoolean) throws SQLException {
/*  799 */     if (!this.isOpen) {
/*      */ 
/*      */       
/*  802 */       this.connection.open(this);
/*  803 */       this.isOpen = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  809 */       this.t4Connection.needLine();
/*  810 */       this.t4Connection.sendPiggyBackedMessages();
/*  811 */       this.t4Connection.describe.doODNY(this, 0, this.accessors, this.sqlObject.getSqlBytes(this.processEscapes, this.convertNcharLiterals));
/*  812 */       this.accessors = this.t4Connection.describe.getAccessors();
/*      */       
/*  814 */       this.numberOfDefinePositions = this.t4Connection.describe.numuds;
/*      */       
/*  816 */       for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  817 */         this.accessors[b].initMetadata();
/*      */       }
/*  819 */     } catch (IOException iOException) {
/*      */       
/*  821 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */ 
/*      */       
/*  824 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  825 */       sQLException.fillInStackTrace();
/*  826 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  830 */     this.describedWithNames = true;
/*  831 */     this.described = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForDescribe() throws SQLException {
/*  866 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.execute_for_describe");
/*      */     
/*      */     try {
/*  869 */       if (this.t4Connection.useFetchSizeWithLongColumn)
/*      */       {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  875 */         doOall8(true, true, true, true, false);
/*      */       }
/*      */       else
/*      */       {
/*  879 */         doOall8(true, true, false, true, (this.definedColumnType != null));
/*      */       }
/*      */     
/*  882 */     } catch (SQLException sQLException) {
/*      */ 
/*      */       
/*  885 */       throw sQLException;
/*      */     }
/*  887 */     catch (IOException iOException) {
/*      */       
/*  889 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/*  891 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  892 */       sQLException.fillInStackTrace();
/*  893 */       throw sQLException;
/*      */     
/*      */     }
/*      */     finally {
/*      */       
/*  898 */       this.rowsProcessed = this.t4Connection.all8.rowsProcessed;
/*  899 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     } 
/*      */     
/*  902 */     this.needToParse = false;
/*      */ 
/*      */     
/*  905 */     if (this.connection.calculateChecksum) {
/*  906 */       if (this.validRows > 0) {
/*  907 */         calculateCheckSum();
/*  908 */       } else if (this.rowsProcessed > 0) {
/*  909 */         long l = CRC64.updateChecksum(this.checkSum, this.rowsProcessed);
/*      */         
/*  911 */         this.checkSum = l;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  921 */     if (this.definedColumnType == null) {
/*  922 */       this.implicitDefineForLobPrefetchDone = false;
/*      */     }
/*  924 */     this.aFetchWasDoneDuringDescribe = false;
/*  925 */     if (this.t4Connection.all8.aFetchWasDone) {
/*      */       
/*  927 */       this.aFetchWasDoneDuringDescribe = true;
/*  928 */       this.rowPrefetchInLastFetch = this.rowPrefetch;
/*      */     } 
/*      */ 
/*      */     
/*  932 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*  933 */       this.accessors[b].initMetadata();
/*      */     }
/*  935 */     this.needToPrepareDefineBuffer = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeForRows(boolean paramBoolean) throws SQLException {
/*      */     try {
/*      */       try {
/*  977 */         boolean bool = false;
/*  978 */         if (this.columnsDefinedByUser) {
/*  979 */           this.needToPrepareDefineBuffer = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*  999 */         else if (this.t4Connection.useLobPrefetch && this.accessors != null && this.defaultLobPrefetchSize != -1 && !this.implicitDefineForLobPrefetchDone && !this.aFetchWasDoneDuringDescribe && this.definedColumnType == null) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1007 */           boolean bool1 = false;
/* 1008 */           int[] arrayOfInt1 = new int[this.accessors.length];
/* 1009 */           int[] arrayOfInt2 = new int[this.accessors.length];
/*      */           
/* 1011 */           for (byte b = 0; b < this.accessors.length; b++) {
/*      */ 
/*      */ 
/*      */ 
/*      */             
/* 1016 */             arrayOfInt1[b] = getJDBCType((this.accessors[b]).internalType);
/* 1017 */             if ((this.accessors[b]).internalType == 113 || (this.accessors[b]).internalType == 112 || (this.accessors[b]).internalType == 114) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1023 */               bool1 = true;
/* 1024 */               (this.accessors[b]).lobPrefetchSizeForThisColumn = this.defaultLobPrefetchSize;
/* 1025 */               arrayOfInt2[b] = this.defaultLobPrefetchSize;
/*      */             } 
/*      */           } 
/*      */           
/* 1029 */           if (bool1) {
/*      */             
/* 1031 */             this.definedColumnType = arrayOfInt1;
/* 1032 */             this.definedColumnSize = arrayOfInt2;
/* 1033 */             bool = true;
/*      */           } 
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1039 */         doOall8(this.needToParse, !paramBoolean, true, false, bool);
/*      */         
/* 1041 */         this.needToParse = false;
/* 1042 */         if (bool) {
/* 1043 */           this.implicitDefineForLobPrefetchDone = true;
/*      */         }
/*      */       } finally {
/*      */         
/* 1047 */         this.validRows = this.t4Connection.all8.getNumRows();
/*      */       }
/*      */     
/* 1050 */     } catch (SQLException sQLException) {
/*      */       
/* 1052 */       throw sQLException;
/*      */     }
/* 1054 */     catch (IOException iOException) {
/*      */       
/* 1056 */       ((T4CConnection)this.connection).handleIOException(iOException);
/* 1057 */       calculateCheckSum();
/*      */       
/* 1059 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1060 */       sQLException.fillInStackTrace();
/* 1061 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void fetch() throws SQLException {
/* 1088 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 1092 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 1096 */           this.nextStream.close();
/*      */         }
/* 1098 */         catch (IOException iOException) {
/*      */           
/* 1100 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1102 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1103 */           sQLException.fillInStackTrace();
/* 1104 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1108 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1114 */       doOall8(false, false, true, false, false);
/*      */       
/* 1116 */       this.validRows = this.t4Connection.all8.getNumRows();
/*      */     }
/* 1118 */     catch (IOException iOException) {
/*      */       
/* 1120 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1122 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1123 */       sQLException.fillInStackTrace();
/* 1124 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1130 */     calculateCheckSum();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*      */     try {
/* 1145 */       if (!this.connection.useFetchSizeWithLongColumn)
/*      */       {
/* 1147 */         T4C8Oall t4C8Oall = this.t4Connection.all8;
/*      */         
/* 1149 */         t4C8Oall.continueReadRow(paramInt, this);
/*      */       }
/*      */     
/* 1152 */     } catch (IOException iOException) {
/*      */       
/* 1154 */       ((T4CConnection)this.connection).handleIOException(iOException);
/*      */       
/* 1156 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1157 */       sQLException.fillInStackTrace();
/* 1158 */       throw sQLException;
/*      */     
/*      */     }
/* 1161 */     catch (SQLException sQLException) {
/*      */       
/* 1163 */       if (sQLException.getErrorCode() == DatabaseError.getVendorCode(110)) {
/*      */ 
/*      */         
/* 1166 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 110);
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 1171 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClose() throws SQLException {
/* 1195 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.do_close");
/*      */     
/* 1197 */     if (this.cursorId != 0) {
/* 1198 */       this.t4Connection.closeCursor(this.cursorId);
/*      */     }
/*      */     
/* 1201 */     this.tmpByteArray = null;
/* 1202 */     this.tmpBindsByteArray = null;
/* 1203 */     this.definedColumnType = null;
/* 1204 */     this.definedColumnSize = null;
/* 1205 */     this.definedColumnFormOfUse = null;
/* 1206 */     this.oacdefSent = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeQuery() throws SQLException {
/* 1226 */     this.t4Connection.assertLoggedOn("oracle.jdbc.driver.T4CPreparedStatement.closeQuery");
/*      */     
/* 1228 */     if (this.streamList != null)
/*      */     {
/* 1230 */       while (this.nextStream != null) {
/*      */         try {
/* 1232 */           this.nextStream.close();
/*      */         }
/* 1234 */         catch (IOException iOException) {
/* 1235 */           ((T4CConnection)this.connection).handleIOException(iOException);
/*      */           
/* 1237 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 1238 */           sQLException.fillInStackTrace();
/* 1239 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 1243 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Binder getRowidNullBinder(int paramInt) {
/* 1256 */     if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */ 
/*      */       
/* 1259 */       this.currentRowCharLens[paramInt] = 1;
/* 1260 */       return this.theVarcharNullBinder;
/*      */     } 
/*      */     
/* 1263 */     return this.theRowidNullBinder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doLocalInitialization() {
/* 1272 */     super.doLocalInitialization();
/*      */     
/* 1274 */     this.t4Connection.all8.bindChars = this.bindChars;
/* 1275 */     this.t4Connection.all8.bindBytes = this.bindBytes;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1281 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/T4CPreparedStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */