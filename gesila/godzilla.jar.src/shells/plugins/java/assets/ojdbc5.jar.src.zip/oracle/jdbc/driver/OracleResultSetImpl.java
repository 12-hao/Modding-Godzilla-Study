/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class OracleResultSetImpl
/*      */   extends BaseResultSet
/*      */ {
/*      */   PhysicalConnection connection;
/*      */   OracleStatement statement;
/*      */   boolean explicitly_closed;
/*      */   boolean m_emptyRset;
/*      */   boolean isServerCursorPeeked = false;
/*      */   
/*      */   OracleResultSetImpl(PhysicalConnection paramPhysicalConnection, OracleStatement paramOracleStatement) throws SQLException {
/*   70 */     this.connection = paramPhysicalConnection;
/*   71 */     this.statement = paramOracleStatement;
/*   72 */     this.close_statement_on_close = false;
/*   73 */     this.explicitly_closed = false;
/*   74 */     this.m_emptyRset = false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/*   84 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*   87 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/*   88 */       sQLException.fillInStackTrace();
/*   89 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*  101 */     synchronized (this.connection) {
/*      */       
/*  103 */       internal_close(false);
/*  104 */       this.statement.totalRowsVisited = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  111 */       this.statement.closeCursorOnPlainStatement();
/*      */ 
/*      */       
/*  114 */       if (this.close_statement_on_close) {
/*      */         
/*      */         try {
/*      */           
/*  118 */           this.statement.close();
/*      */         }
/*  120 */         catch (SQLException sQLException) {}
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  125 */       this.explicitly_closed = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean wasNull() throws SQLException {
/*  132 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  135 */       if (this.explicitly_closed) {
/*      */         
/*  137 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "wasNull");
/*  138 */         sQLException.fillInStackTrace();
/*  139 */         throw sQLException;
/*      */       } 
/*      */       
/*  142 */       if (this.statement.closed) {
/*      */         
/*  144 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "wasNull");
/*  145 */         sQLException.fillInStackTrace();
/*  146 */         throw sQLException;
/*      */       } 
/*      */       
/*  149 */       return this.statement.wasNullValue();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/*  156 */     synchronized (this.connection) {
/*      */       
/*  158 */       if (this.explicitly_closed) {
/*      */         
/*  160 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "getMetaData");
/*  161 */         sQLException.fillInStackTrace();
/*  162 */         throw sQLException;
/*      */       } 
/*      */       
/*  165 */       if (this.statement.closed) {
/*      */         
/*  167 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getMetaData");
/*  168 */         sQLException.fillInStackTrace();
/*  169 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  175 */       if (!this.statement.isOpen) {
/*      */         
/*  177 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144, "getMetaData");
/*  178 */         sQLException.fillInStackTrace();
/*  179 */         throw sQLException;
/*      */       } 
/*      */       
/*  182 */       return (ResultSetMetaData)new OracleResultSetMetaData(this.connection, this.statement);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Statement getStatement() throws SQLException {
/*  190 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/*  194 */       return (this.statement.wrapper == null) ? (Statement)this.statement : (Statement)this.statement.wrapper;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement getOracleStatement() throws SQLException {
/*  205 */     synchronized (this.connection) {
/*      */       
/*  207 */       return this.statement;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean next() throws SQLException {
/*  226 */     synchronized (this.connection) {
/*      */       
/*  228 */       boolean bool = true;
/*      */       
/*  230 */       this.isServerCursorPeeked = true;
/*      */ 
/*      */       
/*  233 */       PhysicalConnection physicalConnection = this.statement.connection;
/*      */       
/*  235 */       if (this.explicitly_closed) {
/*      */         
/*  237 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10, "next");
/*  238 */         sQLException.fillInStackTrace();
/*  239 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  244 */       if (physicalConnection == null || physicalConnection.lifecycle != 1) {
/*      */         
/*  246 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "next");
/*  247 */         sQLException.fillInStackTrace();
/*  248 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  253 */       if (this.statement.closed) {
/*      */         
/*  255 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "next");
/*  256 */         sQLException.fillInStackTrace();
/*  257 */         throw sQLException;
/*      */       } 
/*      */       
/*  260 */       if (this.statement.sqlKind.isPlsqlOrCall()) {
/*      */         
/*  262 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 166, "next");
/*  263 */         sQLException.fillInStackTrace();
/*  264 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  269 */       if (this.closed) {
/*  270 */         return false;
/*      */       }
/*  272 */       this.statement.currentRow++;
/*  273 */       this.statement.totalRowsVisited++;
/*      */       
/*  275 */       if (this.statement.maxRows != 0 && this.statement.totalRowsVisited > this.statement.maxRows) {
/*      */ 
/*      */         
/*  278 */         internal_close(false);
/*  279 */         this.statement.currentRow--;
/*  280 */         this.statement.totalRowsVisited = 0;
/*      */         
/*  282 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 275);
/*      */         
/*  284 */         return false;
/*      */       } 
/*      */       
/*  287 */       if (this.statement.currentRow >= this.statement.validRows) {
/*  288 */         bool = close_or_fetch_from_next(false);
/*      */       }
/*  290 */       if (bool && physicalConnection.useFetchSizeWithLongColumn) {
/*  291 */         this.statement.reopenStreams();
/*      */       }
/*  293 */       if (!bool) {
/*      */         
/*  295 */         this.statement.currentRow--;
/*  296 */         this.statement.totalRowsVisited = 0;
/*      */       } 
/*      */       
/*  299 */       return bool;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean close_or_fetch_from_next(boolean paramBoolean) throws SQLException {
/*  310 */     if (paramBoolean) {
/*      */       
/*  312 */       internal_close(false);
/*      */       
/*  314 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  321 */     if (this.statement.gotLastBatch) {
/*      */       
/*  323 */       internal_close(false);
/*      */       
/*  325 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  332 */     this.statement.check_row_prefetch_changed();
/*      */     
/*  334 */     PhysicalConnection physicalConnection = this.statement.connection;
/*      */     
/*  336 */     if (physicalConnection.protocolId == 3) {
/*  337 */       this.sqlWarning = null;
/*      */     }
/*      */     else {
/*      */       
/*  341 */       if (this.statement.streamList != null)
/*      */       {
/*      */ 
/*      */         
/*  345 */         while (this.statement.nextStream != null) {
/*      */ 
/*      */           
/*      */           try {
/*  349 */             this.statement.nextStream.close();
/*      */           }
/*  351 */           catch (IOException iOException) {
/*      */ 
/*      */             
/*  354 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/*  355 */             sQLException.fillInStackTrace();
/*  356 */             throw sQLException;
/*      */           } 
/*      */ 
/*      */           
/*  360 */           this.statement.nextStream = this.statement.nextStream.nextStream;
/*      */         } 
/*      */       }
/*      */       
/*  364 */       clearWarnings();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  373 */       physicalConnection.registerHeartbeat();
/*      */       
/*  375 */       physicalConnection.needLine();
/*      */     } 
/*      */ 
/*      */     
/*  379 */     synchronized (physicalConnection) {
/*      */ 
/*      */       
/*      */       try {
/*  383 */         this.statement.cancelLock.enterExecuting();
/*  384 */         this.statement.fetch();
/*      */       } finally {
/*      */         
/*  387 */         this.statement.cancelLock.exitExecuting();
/*      */       } 
/*      */     } 
/*      */     
/*  391 */     if (this.statement.validRows == 0) {
/*      */       
/*  393 */       internal_close(false);
/*      */       
/*  395 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  399 */     this.statement.currentRow = 0;
/*      */     
/*  401 */     this.statement.checkValidRowsStatus();
/*      */     
/*  403 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isBeforeFirst() throws SQLException {
/*  415 */     if (this.explicitly_closed) {
/*      */       
/*  417 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  418 */       sQLException.fillInStackTrace();
/*  419 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  423 */     if (this.statement.connection.protocolId == 3 && this.statement.serverCursor) {
/*      */       
/*  425 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  426 */       sQLException.fillInStackTrace();
/*  427 */       throw sQLException;
/*      */     } 
/*      */     
/*  430 */     return (!isEmptyResultSet() && this.statement.currentRow == -1 && !this.closed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isAfterLast() throws SQLException {
/*  437 */     if (this.explicitly_closed) {
/*      */       
/*  439 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  440 */       sQLException.fillInStackTrace();
/*  441 */       throw sQLException;
/*      */     } 
/*      */     
/*  444 */     return (!isEmptyResultSet() && this.closed);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isFirst() throws SQLException {
/*  451 */     if (this.explicitly_closed) {
/*      */       
/*  453 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  454 */       sQLException.fillInStackTrace();
/*  455 */       throw sQLException;
/*      */     } 
/*  457 */     return (getRow() == 1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isLast() throws SQLException {
/*  464 */     if (this.explicitly_closed) {
/*      */       
/*  466 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  467 */       sQLException1.fillInStackTrace();
/*  468 */       throw sQLException1;
/*      */     } 
/*      */     
/*  471 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "isLast");
/*  472 */     sQLException.fillInStackTrace();
/*  473 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRow() throws SQLException {
/*  481 */     if (this.explicitly_closed) {
/*      */       
/*  483 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10);
/*  484 */       sQLException.fillInStackTrace();
/*  485 */       throw sQLException;
/*      */     } 
/*  487 */     return this.statement.totalRowsVisited;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Array getArray(int paramInt) throws SQLException {
/*  505 */     synchronized (this.connection) {
/*      */       
/*  507 */       return (Array)getARRAY(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt) throws SQLException {
/*  515 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  518 */       if (this.closed) {
/*      */         
/*  520 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  521 */         sQLException.fillInStackTrace();
/*  522 */         throw sQLException;
/*      */       } 
/*      */       
/*  525 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  527 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  528 */         sQLException.fillInStackTrace();
/*  529 */         throw sQLException;
/*      */       } 
/*      */       
/*  532 */       int i = this.statement.currentRow;
/*      */       
/*  534 */       if (i < 0) {
/*      */         
/*  536 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  537 */         sQLException.fillInStackTrace();
/*  538 */         throw sQLException;
/*      */       } 
/*      */       
/*  541 */       this.statement.lastIndex = paramInt;
/*      */       
/*  543 */       if (this.statement.streamList != null)
/*      */       {
/*  545 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  548 */       return this.statement.accessors[paramInt - 1].getBigDecimal(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException {
/*  556 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  559 */       if (this.closed) {
/*      */         
/*  561 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  562 */         sQLException.fillInStackTrace();
/*  563 */         throw sQLException;
/*      */       } 
/*      */       
/*  566 */       if (paramInt1 <= 0 || paramInt1 > this.statement.numberOfDefinePositions) {
/*      */         
/*  568 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  569 */         sQLException.fillInStackTrace();
/*  570 */         throw sQLException;
/*      */       } 
/*      */       
/*  573 */       int i = this.statement.currentRow;
/*      */       
/*  575 */       if (i < 0) {
/*      */         
/*  577 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  578 */         sQLException.fillInStackTrace();
/*  579 */         throw sQLException;
/*      */       } 
/*      */       
/*  582 */       this.statement.lastIndex = paramInt1;
/*      */       
/*  584 */       if (this.statement.streamList != null)
/*      */       {
/*  586 */         this.statement.closeUsedStreams(paramInt1);
/*      */       }
/*      */       
/*  589 */       return this.statement.accessors[paramInt1 - 1].getBigDecimal(i, paramInt2);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Blob getBlob(int paramInt) throws SQLException {
/*  597 */     synchronized (this.connection) {
/*      */       
/*  599 */       return (Blob)getBLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getBoolean(int paramInt) throws SQLException {
/*  607 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  610 */       if (this.closed) {
/*      */         
/*  612 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  613 */         sQLException.fillInStackTrace();
/*  614 */         throw sQLException;
/*      */       } 
/*      */       
/*  617 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  619 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  620 */         sQLException.fillInStackTrace();
/*  621 */         throw sQLException;
/*      */       } 
/*      */       
/*  624 */       int i = this.statement.currentRow;
/*      */       
/*  626 */       if (i < 0) {
/*      */         
/*  628 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  629 */         sQLException.fillInStackTrace();
/*  630 */         throw sQLException;
/*      */       } 
/*      */       
/*  633 */       this.statement.lastIndex = paramInt;
/*      */       
/*  635 */       if (this.statement.streamList != null)
/*      */       {
/*  637 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  640 */       return this.statement.accessors[paramInt - 1].getBoolean(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte getByte(int paramInt) throws SQLException {
/*  648 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  651 */       if (this.closed) {
/*      */         
/*  653 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  654 */         sQLException.fillInStackTrace();
/*  655 */         throw sQLException;
/*      */       } 
/*      */       
/*  658 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  660 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  661 */         sQLException.fillInStackTrace();
/*  662 */         throw sQLException;
/*      */       } 
/*      */       
/*  665 */       int i = this.statement.currentRow;
/*      */       
/*  667 */       if (i < 0) {
/*      */         
/*  669 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  670 */         sQLException.fillInStackTrace();
/*  671 */         throw sQLException;
/*      */       } 
/*      */       
/*  674 */       this.statement.lastIndex = paramInt;
/*      */       
/*  676 */       if (this.statement.streamList != null)
/*      */       {
/*  678 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  681 */       return this.statement.accessors[paramInt - 1].getByte(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public byte[] getBytes(int paramInt) throws SQLException {
/*  689 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  692 */       if (this.closed) {
/*      */         
/*  694 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  695 */         sQLException.fillInStackTrace();
/*  696 */         throw sQLException;
/*      */       } 
/*      */       
/*  699 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  701 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  702 */         sQLException.fillInStackTrace();
/*  703 */         throw sQLException;
/*      */       } 
/*      */       
/*  706 */       int i = this.statement.currentRow;
/*      */       
/*  708 */       if (i < 0) {
/*      */         
/*  710 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  711 */         sQLException.fillInStackTrace();
/*  712 */         throw sQLException;
/*      */       } 
/*      */       
/*  715 */       this.statement.lastIndex = paramInt;
/*      */       
/*  717 */       if (this.statement.streamList != null)
/*      */       {
/*  719 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  722 */       return this.statement.accessors[paramInt - 1].getBytes(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Clob getClob(int paramInt) throws SQLException {
/*  730 */     synchronized (this.connection) {
/*      */       
/*  732 */       return (Clob)getCLOB(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt) throws SQLException {
/*  740 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  743 */       if (this.closed) {
/*      */         
/*  745 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  746 */         sQLException.fillInStackTrace();
/*  747 */         throw sQLException;
/*      */       } 
/*      */       
/*  750 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  752 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  753 */         sQLException.fillInStackTrace();
/*  754 */         throw sQLException;
/*      */       } 
/*      */       
/*  757 */       int i = this.statement.currentRow;
/*      */       
/*  759 */       if (i < 0) {
/*      */         
/*  761 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  762 */         sQLException.fillInStackTrace();
/*  763 */         throw sQLException;
/*      */       } 
/*      */       
/*  766 */       this.statement.lastIndex = paramInt;
/*      */       
/*  768 */       if (this.statement.streamList != null)
/*      */       {
/*  770 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  773 */       return this.statement.accessors[paramInt - 1].getDate(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException {
/*  781 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  784 */       if (this.closed) {
/*      */         
/*  786 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  787 */         sQLException.fillInStackTrace();
/*  788 */         throw sQLException;
/*      */       } 
/*      */       
/*  791 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  793 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  794 */         sQLException.fillInStackTrace();
/*  795 */         throw sQLException;
/*      */       } 
/*      */       
/*  798 */       int i = this.statement.currentRow;
/*      */       
/*  800 */       if (i < 0) {
/*      */         
/*  802 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  803 */         sQLException.fillInStackTrace();
/*  804 */         throw sQLException;
/*      */       } 
/*      */       
/*  807 */       this.statement.lastIndex = paramInt;
/*      */       
/*  809 */       if (this.statement.streamList != null)
/*      */       {
/*  811 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  814 */       return this.statement.accessors[paramInt - 1].getDate(i, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public double getDouble(int paramInt) throws SQLException {
/*  822 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  825 */       if (this.closed) {
/*      */         
/*  827 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  828 */         sQLException.fillInStackTrace();
/*  829 */         throw sQLException;
/*      */       } 
/*      */       
/*  832 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  834 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  835 */         sQLException.fillInStackTrace();
/*  836 */         throw sQLException;
/*      */       } 
/*      */       
/*  839 */       int i = this.statement.currentRow;
/*      */       
/*  841 */       if (i < 0) {
/*      */         
/*  843 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  844 */         sQLException.fillInStackTrace();
/*  845 */         throw sQLException;
/*      */       } 
/*      */       
/*  848 */       this.statement.lastIndex = paramInt;
/*      */       
/*  850 */       if (this.statement.streamList != null)
/*      */       {
/*  852 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  855 */       return this.statement.accessors[paramInt - 1].getDouble(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getFloat(int paramInt) throws SQLException {
/*  863 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  866 */       if (this.closed) {
/*      */         
/*  868 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  869 */         sQLException.fillInStackTrace();
/*  870 */         throw sQLException;
/*      */       } 
/*      */       
/*  873 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  875 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  876 */         sQLException.fillInStackTrace();
/*  877 */         throw sQLException;
/*      */       } 
/*      */       
/*  880 */       int i = this.statement.currentRow;
/*      */       
/*  882 */       if (i < 0) {
/*      */         
/*  884 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  885 */         sQLException.fillInStackTrace();
/*  886 */         throw sQLException;
/*      */       } 
/*      */       
/*  889 */       this.statement.lastIndex = paramInt;
/*      */       
/*  891 */       if (this.statement.streamList != null)
/*      */       {
/*  893 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  896 */       return this.statement.accessors[paramInt - 1].getFloat(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getInt(int paramInt) throws SQLException {
/*  909 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  912 */       if (this.closed) {
/*      */         
/*  914 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  915 */         sQLException.fillInStackTrace();
/*  916 */         throw sQLException;
/*      */       } 
/*      */       
/*  919 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  921 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  922 */         sQLException.fillInStackTrace();
/*  923 */         throw sQLException;
/*      */       } 
/*      */       
/*  926 */       int i = this.statement.currentRow;
/*      */       
/*  928 */       if (i < 0) {
/*      */         
/*  930 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  931 */         sQLException.fillInStackTrace();
/*  932 */         throw sQLException;
/*      */       } 
/*      */       
/*  935 */       this.statement.lastIndex = paramInt;
/*      */       
/*  937 */       if (this.statement.streamList != null)
/*      */       {
/*  939 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  942 */       return this.statement.accessors[paramInt - 1].getInt(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLong(int paramInt) throws SQLException {
/*  952 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  955 */       if (this.closed) {
/*      */         
/*  957 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  958 */         sQLException.fillInStackTrace();
/*  959 */         throw sQLException;
/*      */       } 
/*      */       
/*  962 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/*  964 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/*  965 */         sQLException.fillInStackTrace();
/*  966 */         throw sQLException;
/*      */       } 
/*      */       
/*  969 */       int i = this.statement.currentRow;
/*      */       
/*  971 */       if (i < 0) {
/*      */         
/*  973 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/*  974 */         sQLException.fillInStackTrace();
/*  975 */         throw sQLException;
/*      */       } 
/*      */       
/*  978 */       this.statement.lastIndex = paramInt;
/*      */       
/*  980 */       if (this.statement.streamList != null)
/*      */       {
/*  982 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/*  985 */       return this.statement.accessors[paramInt - 1].getLong(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt) throws SQLException {
/*  993 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*  996 */       if (this.closed) {
/*      */         
/*  998 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/*  999 */         sQLException.fillInStackTrace();
/* 1000 */         throw sQLException;
/*      */       } 
/*      */       
/* 1003 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1005 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1006 */         sQLException.fillInStackTrace();
/* 1007 */         throw sQLException;
/*      */       } 
/*      */       
/* 1010 */       int i = this.statement.currentRow;
/*      */       
/* 1012 */       if (i < 0) {
/*      */         
/* 1014 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1015 */         sQLException.fillInStackTrace();
/* 1016 */         throw sQLException;
/*      */       } 
/*      */       
/* 1019 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1021 */       if (this.statement.streamList != null)
/*      */       {
/* 1023 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1026 */       return this.statement.accessors[paramInt - 1].getObject(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 1034 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1037 */       if (this.closed) {
/*      */         
/* 1039 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1040 */         sQLException.fillInStackTrace();
/* 1041 */         throw sQLException;
/*      */       } 
/*      */       
/* 1044 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1046 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1047 */         sQLException.fillInStackTrace();
/* 1048 */         throw sQLException;
/*      */       } 
/*      */       
/* 1051 */       int i = this.statement.currentRow;
/*      */       
/* 1053 */       if (i < 0) {
/*      */         
/* 1055 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1056 */         sQLException.fillInStackTrace();
/* 1057 */         throw sQLException;
/*      */       } 
/*      */       
/* 1060 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1062 */       if (this.statement.streamList != null)
/*      */       {
/* 1064 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1067 */       return this.statement.accessors[paramInt - 1].getObject(i, paramMap);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Ref getRef(int paramInt) throws SQLException {
/* 1075 */     synchronized (this.connection) {
/*      */       
/* 1077 */       return (Ref)getREF(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public short getShort(int paramInt) throws SQLException {
/* 1085 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1088 */       if (this.closed) {
/*      */         
/* 1090 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1091 */         sQLException.fillInStackTrace();
/* 1092 */         throw sQLException;
/*      */       } 
/*      */       
/* 1095 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1097 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1098 */         sQLException.fillInStackTrace();
/* 1099 */         throw sQLException;
/*      */       } 
/*      */       
/* 1102 */       int i = this.statement.currentRow;
/*      */       
/* 1104 */       if (i < 0) {
/*      */         
/* 1106 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1107 */         sQLException.fillInStackTrace();
/* 1108 */         throw sQLException;
/*      */       } 
/*      */       
/* 1111 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1113 */       if (this.statement.streamList != null)
/*      */       {
/* 1115 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1118 */       return this.statement.accessors[paramInt - 1].getShort(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getString(int paramInt) throws SQLException {
/* 1131 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1134 */       if (this.closed) {
/*      */         
/* 1136 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1137 */         sQLException.fillInStackTrace();
/* 1138 */         throw sQLException;
/*      */       } 
/*      */       
/* 1141 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1143 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1144 */         sQLException.fillInStackTrace();
/* 1145 */         throw sQLException;
/*      */       } 
/*      */       
/* 1148 */       int i = this.statement.currentRow;
/*      */       
/* 1150 */       if (i < 0) {
/*      */         
/* 1152 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1153 */         sQLException.fillInStackTrace();
/* 1154 */         throw sQLException;
/*      */       } 
/*      */       
/* 1157 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1159 */       if (this.statement.streamList != null)
/*      */       {
/* 1161 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1164 */       return this.statement.accessors[paramInt - 1].getString(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt) throws SQLException {
/* 1174 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1177 */       if (this.closed) {
/*      */         
/* 1179 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1180 */         sQLException.fillInStackTrace();
/* 1181 */         throw sQLException;
/*      */       } 
/*      */       
/* 1184 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1186 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1187 */         sQLException.fillInStackTrace();
/* 1188 */         throw sQLException;
/*      */       } 
/*      */       
/* 1191 */       int i = this.statement.currentRow;
/*      */       
/* 1193 */       if (i < 0) {
/*      */         
/* 1195 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1196 */         sQLException.fillInStackTrace();
/* 1197 */         throw sQLException;
/*      */       } 
/*      */       
/* 1200 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1202 */       if (this.statement.streamList != null)
/*      */       {
/* 1204 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1207 */       return this.statement.accessors[paramInt - 1].getTime(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1215 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1218 */       if (this.closed) {
/*      */         
/* 1220 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1221 */         sQLException.fillInStackTrace();
/* 1222 */         throw sQLException;
/*      */       } 
/*      */       
/* 1225 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1227 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1228 */         sQLException.fillInStackTrace();
/* 1229 */         throw sQLException;
/*      */       } 
/*      */       
/* 1232 */       int i = this.statement.currentRow;
/*      */       
/* 1234 */       if (i < 0) {
/*      */         
/* 1236 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1237 */         sQLException.fillInStackTrace();
/* 1238 */         throw sQLException;
/*      */       } 
/*      */       
/* 1241 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1243 */       if (this.statement.streamList != null)
/*      */       {
/* 1245 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1248 */       return this.statement.accessors[paramInt - 1].getTime(i, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt) throws SQLException {
/* 1256 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1259 */       if (this.closed) {
/*      */         
/* 1261 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1262 */         sQLException.fillInStackTrace();
/* 1263 */         throw sQLException;
/*      */       } 
/*      */       
/* 1266 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1268 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1269 */         sQLException.fillInStackTrace();
/* 1270 */         throw sQLException;
/*      */       } 
/*      */       
/* 1273 */       int i = this.statement.currentRow;
/*      */       
/* 1275 */       if (i < 0) {
/*      */         
/* 1277 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1278 */         sQLException.fillInStackTrace();
/* 1279 */         throw sQLException;
/*      */       } 
/*      */       
/* 1282 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1284 */       if (this.statement.streamList != null)
/*      */       {
/* 1286 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1289 */       return this.statement.accessors[paramInt - 1].getTimestamp(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException {
/* 1297 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1300 */       if (this.closed) {
/*      */         
/* 1302 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1303 */         sQLException.fillInStackTrace();
/* 1304 */         throw sQLException;
/*      */       } 
/*      */       
/* 1307 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1309 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1310 */         sQLException.fillInStackTrace();
/* 1311 */         throw sQLException;
/*      */       } 
/*      */       
/* 1314 */       int i = this.statement.currentRow;
/*      */       
/* 1316 */       if (i < 0) {
/*      */         
/* 1318 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1319 */         sQLException.fillInStackTrace();
/* 1320 */         throw sQLException;
/*      */       } 
/*      */       
/* 1323 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1325 */       if (this.statement.streamList != null)
/*      */       {
/* 1327 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1330 */       return this.statement.accessors[paramInt - 1].getTimestamp(i, paramCalendar);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public URL getURL(int paramInt) throws SQLException {
/* 1338 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1341 */       if (this.closed) {
/*      */         
/* 1343 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1344 */         sQLException.fillInStackTrace();
/* 1345 */         throw sQLException;
/*      */       } 
/*      */       
/* 1348 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1350 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1351 */         sQLException.fillInStackTrace();
/* 1352 */         throw sQLException;
/*      */       } 
/*      */       
/* 1355 */       int i = this.statement.currentRow;
/*      */       
/* 1357 */       if (i < 0) {
/*      */         
/* 1359 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1360 */         sQLException.fillInStackTrace();
/* 1361 */         throw sQLException;
/*      */       } 
/*      */       
/* 1364 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1366 */       if (this.statement.streamList != null)
/*      */       {
/* 1368 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1371 */       return this.statement.accessors[paramInt - 1].getURL(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ARRAY getARRAY(int paramInt) throws SQLException {
/* 1379 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1382 */       if (this.closed) {
/*      */         
/* 1384 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1385 */         sQLException.fillInStackTrace();
/* 1386 */         throw sQLException;
/*      */       } 
/*      */       
/* 1389 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1391 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1392 */         sQLException.fillInStackTrace();
/* 1393 */         throw sQLException;
/*      */       } 
/*      */       
/* 1396 */       int i = this.statement.currentRow;
/*      */       
/* 1398 */       if (i < 0) {
/*      */         
/* 1400 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1401 */         sQLException.fillInStackTrace();
/* 1402 */         throw sQLException;
/*      */       } 
/*      */       
/* 1405 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1407 */       if (this.statement.streamList != null)
/*      */       {
/* 1409 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1412 */       return this.statement.accessors[paramInt - 1].getARRAY(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBFILE(int paramInt) throws SQLException {
/* 1420 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1423 */       if (this.closed) {
/*      */         
/* 1425 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1426 */         sQLException.fillInStackTrace();
/* 1427 */         throw sQLException;
/*      */       } 
/*      */       
/* 1430 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1432 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1433 */         sQLException.fillInStackTrace();
/* 1434 */         throw sQLException;
/*      */       } 
/*      */       
/* 1437 */       int i = this.statement.currentRow;
/*      */       
/* 1439 */       if (i < 0) {
/*      */         
/* 1441 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1442 */         sQLException.fillInStackTrace();
/* 1443 */         throw sQLException;
/*      */       } 
/*      */       
/* 1446 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1448 */       if (this.statement.streamList != null)
/*      */       {
/* 1450 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1453 */       return this.statement.accessors[paramInt - 1].getBFILE(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BFILE getBfile(int paramInt) throws SQLException {
/* 1461 */     synchronized (this.connection) {
/*      */       
/* 1463 */       return getBFILE(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public BLOB getBLOB(int paramInt) throws SQLException {
/* 1471 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1474 */       if (this.closed) {
/*      */         
/* 1476 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1477 */         sQLException.fillInStackTrace();
/* 1478 */         throw sQLException;
/*      */       } 
/*      */       
/* 1481 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1483 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1484 */         sQLException.fillInStackTrace();
/* 1485 */         throw sQLException;
/*      */       } 
/*      */       
/* 1488 */       int i = this.statement.currentRow;
/*      */       
/* 1490 */       if (i < 0) {
/*      */         
/* 1492 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1493 */         sQLException.fillInStackTrace();
/* 1494 */         throw sQLException;
/*      */       } 
/*      */       
/* 1497 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1499 */       if (this.statement.streamList != null)
/*      */       {
/* 1501 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1504 */       return this.statement.accessors[paramInt - 1].getBLOB(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CHAR getCHAR(int paramInt) throws SQLException {
/* 1512 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1515 */       if (this.closed) {
/*      */         
/* 1517 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1518 */         sQLException.fillInStackTrace();
/* 1519 */         throw sQLException;
/*      */       } 
/*      */       
/* 1522 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1524 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1525 */         sQLException.fillInStackTrace();
/* 1526 */         throw sQLException;
/*      */       } 
/*      */       
/* 1529 */       int i = this.statement.currentRow;
/*      */       
/* 1531 */       if (i < 0) {
/*      */         
/* 1533 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1534 */         sQLException.fillInStackTrace();
/* 1535 */         throw sQLException;
/*      */       } 
/*      */       
/* 1538 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1540 */       if (this.statement.streamList != null)
/*      */       {
/* 1542 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1545 */       return this.statement.accessors[paramInt - 1].getCHAR(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CLOB getCLOB(int paramInt) throws SQLException {
/* 1553 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1556 */       if (this.closed) {
/*      */         
/* 1558 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1559 */         sQLException.fillInStackTrace();
/* 1560 */         throw sQLException;
/*      */       } 
/*      */       
/* 1563 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1565 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1566 */         sQLException.fillInStackTrace();
/* 1567 */         throw sQLException;
/*      */       } 
/*      */       
/* 1570 */       int i = this.statement.currentRow;
/*      */       
/* 1572 */       if (i < 0) {
/*      */         
/* 1574 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1575 */         sQLException.fillInStackTrace();
/* 1576 */         throw sQLException;
/*      */       } 
/*      */       
/* 1579 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1581 */       if (this.statement.streamList != null)
/*      */       {
/* 1583 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1586 */       return this.statement.accessors[paramInt - 1].getCLOB(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getCursor(int paramInt) throws SQLException {
/* 1594 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1597 */       if (this.closed) {
/*      */         
/* 1599 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1600 */         sQLException.fillInStackTrace();
/* 1601 */         throw sQLException;
/*      */       } 
/*      */       
/* 1604 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1606 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1607 */         sQLException.fillInStackTrace();
/* 1608 */         throw sQLException;
/*      */       } 
/*      */       
/* 1611 */       int i = this.statement.currentRow;
/*      */       
/* 1613 */       if (i < 0) {
/*      */         
/* 1615 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1616 */         sQLException.fillInStackTrace();
/* 1617 */         throw sQLException;
/*      */       } 
/*      */       
/* 1620 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1622 */       if (this.statement.streamList != null)
/*      */       {
/* 1624 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1627 */       return this.statement.accessors[paramInt - 1].getCursor(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException {
/* 1635 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1638 */       if (this.closed) {
/*      */         
/* 1640 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1641 */         sQLException.fillInStackTrace();
/* 1642 */         throw sQLException;
/*      */       } 
/*      */       
/* 1645 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1647 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1648 */         sQLException.fillInStackTrace();
/* 1649 */         throw sQLException;
/*      */       } 
/*      */       
/* 1652 */       int i = this.statement.currentRow;
/*      */       
/* 1654 */       if (i < 0) {
/*      */         
/* 1656 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1657 */         sQLException.fillInStackTrace();
/* 1658 */         throw sQLException;
/*      */       } 
/*      */       
/* 1661 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1663 */       if (this.statement.streamList != null)
/*      */       {
/* 1665 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1668 */       return this.statement.accessors[paramInt - 1].getCustomDatum(i, paramCustomDatumFactory);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public DATE getDATE(int paramInt) throws SQLException {
/* 1676 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1679 */       if (this.closed) {
/*      */         
/* 1681 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1682 */         sQLException.fillInStackTrace();
/* 1683 */         throw sQLException;
/*      */       } 
/*      */       
/* 1686 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1688 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1689 */         sQLException.fillInStackTrace();
/* 1690 */         throw sQLException;
/*      */       } 
/*      */       
/* 1693 */       int i = this.statement.currentRow;
/*      */       
/* 1695 */       if (i < 0) {
/*      */         
/* 1697 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1698 */         sQLException.fillInStackTrace();
/* 1699 */         throw sQLException;
/*      */       } 
/*      */       
/* 1702 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1704 */       if (this.statement.streamList != null)
/*      */       {
/* 1706 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1709 */       return this.statement.accessors[paramInt - 1].getDATE(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALDS getINTERVALDS(int paramInt) throws SQLException {
/* 1717 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1720 */       if (this.closed) {
/*      */         
/* 1722 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1723 */         sQLException.fillInStackTrace();
/* 1724 */         throw sQLException;
/*      */       } 
/*      */       
/* 1727 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1729 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1730 */         sQLException.fillInStackTrace();
/* 1731 */         throw sQLException;
/*      */       } 
/*      */       
/* 1734 */       int i = this.statement.currentRow;
/*      */       
/* 1736 */       if (i < 0) {
/*      */         
/* 1738 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1739 */         sQLException.fillInStackTrace();
/* 1740 */         throw sQLException;
/*      */       } 
/*      */       
/* 1743 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1745 */       if (this.statement.streamList != null)
/*      */       {
/* 1747 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1750 */       return this.statement.accessors[paramInt - 1].getINTERVALDS(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public INTERVALYM getINTERVALYM(int paramInt) throws SQLException {
/* 1758 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1761 */       if (this.closed) {
/*      */         
/* 1763 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1764 */         sQLException.fillInStackTrace();
/* 1765 */         throw sQLException;
/*      */       } 
/*      */       
/* 1768 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1770 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1771 */         sQLException.fillInStackTrace();
/* 1772 */         throw sQLException;
/*      */       } 
/*      */       
/* 1775 */       int i = this.statement.currentRow;
/*      */       
/* 1777 */       if (i < 0) {
/*      */         
/* 1779 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1780 */         sQLException.fillInStackTrace();
/* 1781 */         throw sQLException;
/*      */       } 
/*      */       
/* 1784 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1786 */       if (this.statement.streamList != null)
/*      */       {
/* 1788 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1791 */       return this.statement.accessors[paramInt - 1].getINTERVALYM(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException {
/* 1799 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1802 */       if (this.closed) {
/*      */         
/* 1804 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1805 */         sQLException.fillInStackTrace();
/* 1806 */         throw sQLException;
/*      */       } 
/*      */       
/* 1809 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1811 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1812 */         sQLException.fillInStackTrace();
/* 1813 */         throw sQLException;
/*      */       } 
/*      */       
/* 1816 */       int i = this.statement.currentRow;
/*      */       
/* 1818 */       if (i < 0) {
/*      */         
/* 1820 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1821 */         sQLException.fillInStackTrace();
/* 1822 */         throw sQLException;
/*      */       } 
/*      */       
/* 1825 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1827 */       if (this.statement.streamList != null)
/*      */       {
/* 1829 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1832 */       return this.statement.accessors[paramInt - 1].getNUMBER(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OPAQUE getOPAQUE(int paramInt) throws SQLException {
/* 1840 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1843 */       if (this.closed) {
/*      */         
/* 1845 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1846 */         sQLException.fillInStackTrace();
/* 1847 */         throw sQLException;
/*      */       } 
/*      */       
/* 1850 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1852 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1853 */         sQLException.fillInStackTrace();
/* 1854 */         throw sQLException;
/*      */       } 
/*      */       
/* 1857 */       int i = this.statement.currentRow;
/*      */       
/* 1859 */       if (i < 0) {
/*      */         
/* 1861 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1862 */         sQLException.fillInStackTrace();
/* 1863 */         throw sQLException;
/*      */       } 
/*      */       
/* 1866 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1868 */       if (this.statement.streamList != null)
/*      */       {
/* 1870 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1873 */       return this.statement.accessors[paramInt - 1].getOPAQUE(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Datum getOracleObject(int paramInt) throws SQLException {
/* 1881 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1884 */       if (this.closed) {
/*      */         
/* 1886 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1887 */         sQLException.fillInStackTrace();
/* 1888 */         throw sQLException;
/*      */       } 
/*      */       
/* 1891 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1893 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1894 */         sQLException.fillInStackTrace();
/* 1895 */         throw sQLException;
/*      */       } 
/*      */       
/* 1898 */       int i = this.statement.currentRow;
/*      */       
/* 1900 */       if (i < 0) {
/*      */         
/* 1902 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1903 */         sQLException.fillInStackTrace();
/* 1904 */         throw sQLException;
/*      */       } 
/*      */       
/* 1907 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1909 */       if (this.statement.streamList != null)
/*      */       {
/* 1911 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1914 */       return this.statement.accessors[paramInt - 1].getOracleObject(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException {
/* 1922 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1925 */       if (this.closed) {
/*      */         
/* 1927 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1928 */         sQLException.fillInStackTrace();
/* 1929 */         throw sQLException;
/*      */       } 
/*      */       
/* 1932 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1934 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1935 */         sQLException.fillInStackTrace();
/* 1936 */         throw sQLException;
/*      */       } 
/*      */       
/* 1939 */       int i = this.statement.currentRow;
/*      */       
/* 1941 */       if (i < 0) {
/*      */         
/* 1943 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1944 */         sQLException.fillInStackTrace();
/* 1945 */         throw sQLException;
/*      */       } 
/*      */       
/* 1948 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1950 */       if (this.statement.streamList != null)
/*      */       {
/* 1952 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1955 */       return this.statement.accessors[paramInt - 1].getORAData(i, paramORADataFactory);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException {
/* 1963 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 1966 */       if (this.closed) {
/*      */         
/* 1968 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 1969 */         sQLException.fillInStackTrace();
/* 1970 */         throw sQLException;
/*      */       } 
/*      */       
/* 1973 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 1975 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 1976 */         sQLException.fillInStackTrace();
/* 1977 */         throw sQLException;
/*      */       } 
/*      */       
/* 1980 */       int i = this.statement.currentRow;
/*      */       
/* 1982 */       if (i < 0) {
/*      */         
/* 1984 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 1985 */         sQLException.fillInStackTrace();
/* 1986 */         throw sQLException;
/*      */       } 
/*      */       
/* 1989 */       this.statement.lastIndex = paramInt;
/*      */       
/* 1991 */       if (this.statement.streamList != null)
/*      */       {
/* 1993 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 1996 */       return this.statement.accessors[paramInt - 1].getObject(i, paramOracleDataFactory);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public RAW getRAW(int paramInt) throws SQLException {
/* 2004 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2007 */       if (this.closed) {
/*      */         
/* 2009 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2010 */         sQLException.fillInStackTrace();
/* 2011 */         throw sQLException;
/*      */       } 
/*      */       
/* 2014 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2016 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2017 */         sQLException.fillInStackTrace();
/* 2018 */         throw sQLException;
/*      */       } 
/*      */       
/* 2021 */       int i = this.statement.currentRow;
/*      */       
/* 2023 */       if (i < 0) {
/*      */         
/* 2025 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2026 */         sQLException.fillInStackTrace();
/* 2027 */         throw sQLException;
/*      */       } 
/*      */       
/* 2030 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2032 */       if (this.statement.streamList != null)
/*      */       {
/* 2034 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2037 */       return this.statement.accessors[paramInt - 1].getRAW(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public REF getREF(int paramInt) throws SQLException {
/* 2045 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2048 */       if (this.closed) {
/*      */         
/* 2050 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2051 */         sQLException.fillInStackTrace();
/* 2052 */         throw sQLException;
/*      */       } 
/*      */       
/* 2055 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2057 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2058 */         sQLException.fillInStackTrace();
/* 2059 */         throw sQLException;
/*      */       } 
/*      */       
/* 2062 */       int i = this.statement.currentRow;
/*      */       
/* 2064 */       if (i < 0) {
/*      */         
/* 2066 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2067 */         sQLException.fillInStackTrace();
/* 2068 */         throw sQLException;
/*      */       } 
/*      */       
/* 2071 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2073 */       if (this.statement.streamList != null)
/*      */       {
/* 2075 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2078 */       return this.statement.accessors[paramInt - 1].getREF(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ROWID getROWID(int paramInt) throws SQLException {
/* 2086 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2089 */       if (this.closed) {
/*      */         
/* 2091 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2092 */         sQLException.fillInStackTrace();
/* 2093 */         throw sQLException;
/*      */       } 
/*      */       
/* 2096 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2098 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2099 */         sQLException.fillInStackTrace();
/* 2100 */         throw sQLException;
/*      */       } 
/*      */       
/* 2103 */       int i = this.statement.currentRow;
/*      */       
/* 2105 */       if (i < 0) {
/*      */         
/* 2107 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2108 */         sQLException.fillInStackTrace();
/* 2109 */         throw sQLException;
/*      */       } 
/*      */       
/* 2112 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2114 */       if (this.statement.streamList != null)
/*      */       {
/* 2116 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2119 */       return this.statement.accessors[paramInt - 1].getROWID(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public STRUCT getSTRUCT(int paramInt) throws SQLException {
/* 2127 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2130 */       if (this.closed) {
/*      */         
/* 2132 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2133 */         sQLException.fillInStackTrace();
/* 2134 */         throw sQLException;
/*      */       } 
/*      */       
/* 2137 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2139 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2140 */         sQLException.fillInStackTrace();
/* 2141 */         throw sQLException;
/*      */       } 
/*      */       
/* 2144 */       int i = this.statement.currentRow;
/*      */       
/* 2146 */       if (i < 0) {
/*      */         
/* 2148 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2149 */         sQLException.fillInStackTrace();
/* 2150 */         throw sQLException;
/*      */       } 
/*      */       
/* 2153 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2155 */       if (this.statement.streamList != null)
/*      */       {
/* 2157 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2160 */       return this.statement.accessors[paramInt - 1].getSTRUCT(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException {
/* 2168 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2171 */       if (this.closed) {
/*      */         
/* 2173 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2174 */         sQLException.fillInStackTrace();
/* 2175 */         throw sQLException;
/*      */       } 
/*      */       
/* 2178 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2180 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2181 */         sQLException.fillInStackTrace();
/* 2182 */         throw sQLException;
/*      */       } 
/*      */       
/* 2185 */       int i = this.statement.currentRow;
/*      */       
/* 2187 */       if (i < 0) {
/*      */         
/* 2189 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2190 */         sQLException.fillInStackTrace();
/* 2191 */         throw sQLException;
/*      */       } 
/*      */       
/* 2194 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2196 */       if (this.statement.streamList != null)
/*      */       {
/* 2198 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2201 */       return this.statement.accessors[paramInt - 1].getTIMESTAMPLTZ(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException {
/* 2209 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2212 */       if (this.closed) {
/*      */         
/* 2214 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2215 */         sQLException.fillInStackTrace();
/* 2216 */         throw sQLException;
/*      */       } 
/*      */       
/* 2219 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2221 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2222 */         sQLException.fillInStackTrace();
/* 2223 */         throw sQLException;
/*      */       } 
/*      */       
/* 2226 */       int i = this.statement.currentRow;
/*      */       
/* 2228 */       if (i < 0) {
/*      */         
/* 2230 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2231 */         sQLException.fillInStackTrace();
/* 2232 */         throw sQLException;
/*      */       } 
/*      */       
/* 2235 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2237 */       if (this.statement.streamList != null)
/*      */       {
/* 2239 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2242 */       return this.statement.accessors[paramInt - 1].getTIMESTAMPTZ(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException {
/* 2250 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2253 */       if (this.closed) {
/*      */         
/* 2255 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2256 */         sQLException.fillInStackTrace();
/* 2257 */         throw sQLException;
/*      */       } 
/*      */       
/* 2260 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2262 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2263 */         sQLException.fillInStackTrace();
/* 2264 */         throw sQLException;
/*      */       } 
/*      */       
/* 2267 */       int i = this.statement.currentRow;
/*      */       
/* 2269 */       if (i < 0) {
/*      */         
/* 2271 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2272 */         sQLException.fillInStackTrace();
/* 2273 */         throw sQLException;
/*      */       } 
/*      */       
/* 2276 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2278 */       if (this.statement.streamList != null)
/*      */       {
/* 2280 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2283 */       return this.statement.accessors[paramInt - 1].getTIMESTAMP(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getAsciiStream(int paramInt) throws SQLException {
/* 2291 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2294 */       if (this.closed) {
/*      */         
/* 2296 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2297 */         sQLException.fillInStackTrace();
/* 2298 */         throw sQLException;
/*      */       } 
/*      */       
/* 2301 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2303 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2304 */         sQLException.fillInStackTrace();
/* 2305 */         throw sQLException;
/*      */       } 
/*      */       
/* 2308 */       int i = this.statement.currentRow;
/*      */       
/* 2310 */       if (i < 0) {
/*      */         
/* 2312 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2313 */         sQLException.fillInStackTrace();
/* 2314 */         throw sQLException;
/*      */       } 
/*      */       
/* 2317 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2319 */       if (this.statement.streamList != null)
/*      */       {
/* 2321 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2324 */       return this.statement.accessors[paramInt - 1].getAsciiStream(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getBinaryStream(int paramInt) throws SQLException {
/* 2332 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2335 */       if (this.closed) {
/*      */         
/* 2337 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2338 */         sQLException.fillInStackTrace();
/* 2339 */         throw sQLException;
/*      */       } 
/*      */       
/* 2342 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2344 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2345 */         sQLException.fillInStackTrace();
/* 2346 */         throw sQLException;
/*      */       } 
/*      */       
/* 2349 */       int i = this.statement.currentRow;
/*      */       
/* 2351 */       if (i < 0) {
/*      */         
/* 2353 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2354 */         sQLException.fillInStackTrace();
/* 2355 */         throw sQLException;
/*      */       } 
/*      */       
/* 2358 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2360 */       if (this.statement.streamList != null)
/*      */       {
/* 2362 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2365 */       return this.statement.accessors[paramInt - 1].getBinaryStream(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader getCharacterStream(int paramInt) throws SQLException {
/* 2373 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2376 */       if (this.closed) {
/*      */         
/* 2378 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2379 */         sQLException.fillInStackTrace();
/* 2380 */         throw sQLException;
/*      */       } 
/*      */       
/* 2383 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2385 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2386 */         sQLException.fillInStackTrace();
/* 2387 */         throw sQLException;
/*      */       } 
/*      */       
/* 2390 */       int i = this.statement.currentRow;
/*      */       
/* 2392 */       if (i < 0) {
/*      */         
/* 2394 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2395 */         sQLException.fillInStackTrace();
/* 2396 */         throw sQLException;
/*      */       } 
/*      */       
/* 2399 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2401 */       if (this.statement.streamList != null)
/*      */       {
/* 2403 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2406 */       return this.statement.accessors[paramInt - 1].getCharacterStream(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream getUnicodeStream(int paramInt) throws SQLException {
/* 2414 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2417 */       if (this.closed) {
/*      */         
/* 2419 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2420 */         sQLException.fillInStackTrace();
/* 2421 */         throw sQLException;
/*      */       } 
/*      */       
/* 2424 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2426 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2427 */         sQLException.fillInStackTrace();
/* 2428 */         throw sQLException;
/*      */       } 
/*      */       
/* 2431 */       int i = this.statement.currentRow;
/*      */       
/* 2433 */       if (i < 0) {
/*      */         
/* 2435 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2436 */         sQLException.fillInStackTrace();
/* 2437 */         throw sQLException;
/*      */       } 
/*      */       
/* 2440 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2442 */       if (this.statement.streamList != null)
/*      */       {
/* 2444 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */       
/* 2447 */       return this.statement.accessors[paramInt - 1].getUnicodeStream(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException {
/* 2459 */     synchronized (this.connection) {
/*      */       
/* 2461 */       if (this.closed) {
/*      */         
/* 2463 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2464 */         sQLException.fillInStackTrace();
/* 2465 */         throw sQLException;
/*      */       } 
/*      */       
/* 2468 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2470 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2471 */         sQLException.fillInStackTrace();
/* 2472 */         throw sQLException;
/*      */       } 
/*      */       
/* 2475 */       int i = this.statement.currentRow;
/*      */       
/* 2477 */       if (i < 0) {
/*      */         
/* 2479 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2480 */         sQLException.fillInStackTrace();
/* 2481 */         throw sQLException;
/*      */       } 
/*      */       
/* 2484 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2486 */       if (this.statement.streamList != null)
/*      */       {
/* 2488 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/* 2490 */       return this.statement.accessors[paramInt - 1].getAuthorizationIndicator(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] privateGetBytes(int paramInt) throws SQLException {
/* 2507 */     synchronized (this.connection) {
/*      */       
/* 2509 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2511 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2512 */         sQLException.fillInStackTrace();
/* 2513 */         throw sQLException;
/*      */       } 
/*      */       
/* 2516 */       if (this.closed) {
/*      */         
/* 2518 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 11);
/* 2519 */         sQLException.fillInStackTrace();
/* 2520 */         throw sQLException;
/*      */       } 
/*      */       
/* 2523 */       if (paramInt <= 0 || paramInt > this.statement.numberOfDefinePositions) {
/*      */         
/* 2525 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2526 */         sQLException.fillInStackTrace();
/* 2527 */         throw sQLException;
/*      */       } 
/*      */       
/* 2530 */       int i = this.statement.currentRow;
/*      */       
/* 2532 */       if (i < 0) {
/*      */         
/* 2534 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 14);
/* 2535 */         sQLException.fillInStackTrace();
/* 2536 */         throw sQLException;
/*      */       } 
/*      */       
/* 2539 */       this.statement.lastIndex = paramInt;
/*      */       
/* 2541 */       if (this.statement.streamList != null)
/*      */       {
/* 2543 */         this.statement.closeUsedStreams(paramInt);
/*      */       }
/*      */ 
/*      */       
/* 2547 */       return this.statement.accessors[paramInt - 1].privateGetBytes(i);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 2561 */     this.statement.setPrefetchInternal(paramInt, false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 2569 */     return this.statement.getPrefetchInternal(false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void internal_close(boolean paramBoolean) throws SQLException {
/* 2580 */     if (this.closed)
/*      */       return; 
/* 2582 */     super.close();
/*      */     
/* 2584 */     if (this.statement.gotLastBatch && this.statement.validRows == 0) {
/* 2585 */       this.m_emptyRset = true;
/*      */     }
/*      */     
/* 2588 */     PhysicalConnection physicalConnection = this.statement.connection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2599 */       physicalConnection.registerHeartbeat();
/*      */ 
/*      */       
/* 2602 */       physicalConnection.needLine();
/*      */       
/* 2604 */       synchronized (physicalConnection)
/*      */       {
/*      */         
/* 2607 */         this.statement.closeQuery();
/*      */       }
/*      */     
/* 2610 */     } catch (SQLException sQLException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2616 */     this.statement.endOfResultSet(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLException {
/* 2623 */     synchronized (this.connection) {
/*      */       
/* 2625 */       return this.statement.getColumnIndex(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isEmptyResultSet() throws SQLException {
/* 2642 */     if (this.statement != null && !this.statement.closed && this.statement.serverCursor && this.statement.connection.protocolId != 3 && !this.isServerCursorPeeked && !this.closed) {
/*      */ 
/*      */ 
/*      */       
/* 2646 */       close_or_fetch_from_next(false);
/*      */       
/* 2648 */       if (this.statement.validRows > 0) {
/* 2649 */         this.statement.currentRow = -1;
/*      */       } else {
/* 2651 */         this.m_emptyRset = true;
/*      */       } 
/* 2653 */       this.isServerCursorPeeked = true;
/*      */     } 
/*      */     
/* 2656 */     return (this.m_emptyRset || (!this.m_emptyRset && this.statement.gotLastBatch && this.statement.validRows == 0));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getValidRows() {
/* 2665 */     return this.statement.validRows;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 2680 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 2685 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/OracleResultSetImpl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */