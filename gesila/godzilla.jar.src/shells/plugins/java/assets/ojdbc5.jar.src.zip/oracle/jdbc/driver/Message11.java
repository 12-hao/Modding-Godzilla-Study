/*    */ package oracle.jdbc.driver;
/*    */ 
/*    */ import java.util.ResourceBundle;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Message11
/*    */   implements Message
/*    */ {
/*    */   private static ResourceBundle bundle;
/*    */   private static final String messageFile = "oracle.jdbc.driver.Messages";
/*    */   
/*    */   public String msg(String paramString, Object paramObject) {
/* 32 */     if (bundle == null) {
/*    */       
/*    */       try {
/*    */         
/* 36 */         bundle = ResourceBundle.getBundle("oracle.jdbc.driver.Messages");
/*    */       }
/* 38 */       catch (Exception exception) {
/*    */ 
/*    */         
/* 41 */         return "Message file 'oracle.jdbc.driver.Messages' is missing.";
/*    */       } 
/*    */     }
/*    */ 
/*    */ 
/*    */     
/*    */     try {
/* 48 */       if (paramObject != null) {
/* 49 */         return bundle.getString(paramString) + ": " + paramObject;
/*    */       }
/* 51 */       return bundle.getString(paramString);
/*    */     }
/* 53 */     catch (Exception exception) {
/*    */       
/* 55 */       return "Message [" + paramString + "] not found in '" + "oracle.jdbc.driver.Messages" + "'.";
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 61 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/Message11.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */