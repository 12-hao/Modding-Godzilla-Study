package oracle.jdbc;

import java.io.InputStream;
import java.sql.SQLException;

public interface OracleBfile {
  long length() throws SQLException;
  
  byte[] getBytes(long paramLong, int paramInt) throws SQLException;
  
  int getBytes(long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException;
  
  InputStream getBinaryStream() throws SQLException;
  
  InputStream getBinaryStream(long paramLong) throws SQLException;
  
  long position(byte[] paramArrayOfbyte, long paramLong) throws SQLException;
  
  long position(OracleBfile paramOracleBfile, long paramLong) throws SQLException;
  
  String getName() throws SQLException;
  
  String getDirAlias() throws SQLException;
  
  void openFile() throws SQLException;
  
  boolean isFileOpen() throws SQLException;
  
  boolean fileExists() throws SQLException;
  
  void closeFile() throws SQLException;
  
  void open(LargeObjectAccessMode paramLargeObjectAccessMode) throws SQLException;
  
  void close() throws SQLException;
  
  boolean isOpen() throws SQLException;
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/OracleBfile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */