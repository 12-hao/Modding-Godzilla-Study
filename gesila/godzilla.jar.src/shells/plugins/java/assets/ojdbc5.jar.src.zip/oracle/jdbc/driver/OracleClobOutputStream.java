/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.CLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleClobOutputStream
/*     */   extends OutputStream
/*     */ {
/*     */   long lobOffset;
/*     */   CLOB clob;
/*     */   byte[] buf;
/*     */   int count;
/*     */   int bufSize;
/*     */   boolean isClosed;
/*     */   
/*     */   public OracleClobOutputStream(CLOB paramCLOB, int paramInt) throws SQLException {
/*  44 */     this(paramCLOB, paramInt, 1L);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleClobOutputStream(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/*  60 */     if (paramCLOB == null || paramInt <= 0 || paramLong < 1L)
/*     */     {
/*  62 */       throw new IllegalArgumentException();
/*     */     }
/*     */     
/*  65 */     this.clob = paramCLOB;
/*  66 */     this.lobOffset = paramLong;
/*     */     
/*  68 */     PhysicalConnection physicalConnection = (PhysicalConnection)paramCLOB.getInternalConnection();
/*  69 */     synchronized (physicalConnection) {
/*  70 */       this.buf = physicalConnection.getByteBuffer(paramInt);
/*     */     } 
/*  72 */     this.count = 0;
/*  73 */     this.bufSize = paramInt;
/*     */     
/*  75 */     this.isClosed = false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(int paramInt) throws IOException {
/*  89 */     ensureOpen();
/*     */     
/*  91 */     if (this.count >= this.bufSize) {
/*  92 */       flushBuffer();
/*     */     }
/*  94 */     this.buf[this.count++] = (byte)paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 111 */     ensureOpen();
/*     */     
/* 113 */     int i = paramInt1;
/* 114 */     int j = Math.min(paramInt2, paramArrayOfbyte.length - paramInt1);
/*     */     
/* 116 */     if (j >= 2 * this.bufSize) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 123 */       if (this.count > 0) flushBuffer();
/*     */       
/*     */       try {
/* 126 */         char[] arrayOfChar = new char[j];
/*     */         
/* 128 */         for (byte b = 0; b < j; b++) {
/* 129 */           arrayOfChar[b] = (char)paramArrayOfbyte[b + paramInt1];
/*     */         }
/* 131 */         this.lobOffset += this.clob.putChars(this.lobOffset, arrayOfChar);
/*     */       }
/* 133 */       catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 136 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 137 */         iOException.fillInStackTrace();
/* 138 */         throw iOException;
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 144 */     int k = i + j;
/*     */     
/* 146 */     while (i < k) {
/*     */       
/* 148 */       int m = Math.min(this.bufSize - this.count, k - i);
/*     */       
/* 150 */       System.arraycopy(paramArrayOfbyte, i, this.buf, this.count, m);
/*     */       
/* 152 */       i += m;
/* 153 */       this.count += m;
/*     */       
/* 155 */       if (this.count >= this.bufSize) {
/* 156 */         flushBuffer();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() throws IOException {
/* 173 */     ensureOpen();
/*     */     
/* 175 */     flushBuffer();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws IOException {
/* 189 */     if (this.isClosed) {
/*     */       return;
/*     */     }
/*     */     
/*     */     try {
/* 194 */       this.isClosed = true;
/* 195 */       flushBuffer();
/*     */     } finally {
/*     */ 
/*     */       
/*     */       try {
/* 200 */         PhysicalConnection physicalConnection = (PhysicalConnection)this.clob.getInternalConnection();
/* 201 */         synchronized (physicalConnection) {
/*     */           
/* 203 */           if (this.buf != null) {
/*     */             
/* 205 */             physicalConnection.cacheBuffer(this.buf);
/* 206 */             this.buf = null;
/*     */           } 
/*     */         } 
/* 209 */       } catch (SQLException sQLException) {
/*     */ 
/*     */         
/* 212 */         IOException iOException = DatabaseError.createIOException(sQLException);
/* 213 */         iOException.fillInStackTrace();
/* 214 */         throw iOException;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void flushBuffer() throws IOException {
/*     */     try {
/* 232 */       if (this.count > 0)
/*     */       {
/* 234 */         char[] arrayOfChar = new char[this.count];
/*     */         
/* 236 */         for (byte b = 0; b < this.count; b++) {
/* 237 */           arrayOfChar[b] = (char)this.buf[b];
/*     */         }
/* 239 */         this.lobOffset += this.clob.putChars(this.lobOffset, arrayOfChar);
/*     */         
/* 241 */         this.count = 0;
/*     */       }
/*     */     
/* 244 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 247 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 248 */       iOException.fillInStackTrace();
/* 249 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void ensureOpen() throws IOException {
/*     */     try {
/* 266 */       if (this.isClosed)
/*     */       {
/* 268 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 57, (Object)null);
/* 269 */         sQLException.fillInStackTrace();
/* 270 */         throw sQLException;
/*     */       }
/*     */     
/* 273 */     } catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 276 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 277 */       iOException.fillInStackTrace();
/* 278 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*     */     try {
/* 298 */       return this.clob.getInternalConnection();
/*     */     }
/* 300 */     catch (Exception exception) {
/*     */       
/* 302 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 309 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/OracleClobOutputStream.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */