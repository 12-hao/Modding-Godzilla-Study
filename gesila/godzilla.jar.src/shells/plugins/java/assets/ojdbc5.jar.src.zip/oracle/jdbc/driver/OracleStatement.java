/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Vector;
/*      */ import oracle.jdbc.OracleResultSetCache;
/*      */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CLOB;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ abstract class OracleStatement
/*      */   implements OracleStatement, ScrollRsetStatement
/*      */ {
/*      */   static final int PLAIN_STMT = 0;
/*      */   static final int PREP_STMT = 1;
/*      */   static final int CALL_STMT = 2;
/*      */   int cursorId;
/*      */   int numberOfDefinePositions;
/*      */   int definesBatchSize;
/*      */   Accessor[] accessors;
/*      */   int defineByteSubRange;
/*      */   int defineCharSubRange;
/*      */   int defineIndicatorSubRange;
/*      */   int defineLengthSubRange;
/*      */   byte[] defineBytes;
/*      */   char[] defineChars;
/*      */   short[] defineIndicators;
/*      */   
/*      */   void continueReadRow(int paramInt) throws SQLException {
/*  292 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "continueReadRow is only implemented by the T4C statements.");
/*  293 */     sQLException.fillInStackTrace();
/*  294 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int cursorIfRefCursor() throws SQLException {
/*  330 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "cursorIfRefCursor not implemented");
/*  331 */     sQLException.fillInStackTrace();
/*  332 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeCursorOnPlainStatement() throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean described = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean describedWithNames = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] defineMetaData;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int defineMetaDataSubRange;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int METADATALENGTH = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int rowsProcessed;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  381 */   int cachedDefineByteSize = 0;
/*  382 */   int cachedDefineCharSize = 0;
/*  383 */   int cachedDefineIndicatorSize = 0;
/*  384 */   int cachedDefineMetaDataSize = 0;
/*      */ 
/*      */   
/*  387 */   OracleStatement children = null;
/*  388 */   OracleStatement parent = null;
/*      */ 
/*      */   
/*  391 */   OracleStatement nextChild = null;
/*      */ 
/*      */   
/*      */   OracleStatement next;
/*      */ 
/*      */   
/*      */   OracleStatement prev;
/*      */ 
/*      */   
/*      */   long c_state;
/*      */ 
/*      */   
/*      */   int numberOfBindPositions;
/*      */ 
/*      */   
/*      */   byte[] bindBytes;
/*      */ 
/*      */   
/*      */   char[] bindChars;
/*      */ 
/*      */   
/*      */   short[] bindIndicators;
/*      */ 
/*      */   
/*      */   int bindByteOffset;
/*      */ 
/*      */   
/*      */   int bindCharOffset;
/*      */ 
/*      */   
/*      */   int bindIndicatorOffset;
/*      */ 
/*      */   
/*      */   int bindByteSubRange;
/*      */ 
/*      */   
/*      */   int bindCharSubRange;
/*      */ 
/*      */   
/*      */   int bindIndicatorSubRange;
/*      */ 
/*      */   
/*      */   Accessor[] outBindAccessors;
/*      */   
/*      */   InputStream[][] parameterStream;
/*      */   
/*      */   Object[][] userStream;
/*      */   
/*      */   int firstRowInBatch;
/*      */   
/*      */   boolean hasIbtBind = false;
/*      */   
/*      */   byte[] ibtBindBytes;
/*      */   
/*      */   char[] ibtBindChars;
/*      */   
/*      */   short[] ibtBindIndicators;
/*      */   
/*      */   int ibtBindByteOffset;
/*      */   
/*      */   int ibtBindCharOffset;
/*      */   
/*      */   int ibtBindIndicatorOffset;
/*      */   
/*      */   int ibtBindIndicatorSize;
/*      */   
/*  457 */   ByteBuffer[] nioBuffers = null;
/*  458 */   Object[] lobPrefetchMetaData = null;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean hasStream;
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] tmpByteArray;
/*      */ 
/*      */   
/*  469 */   int sizeTmpByteArray = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   byte[] tmpBindsByteArray;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean needToSendOalToFetch = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  484 */   int[] definedColumnType = null;
/*  485 */   int[] definedColumnSize = null;
/*  486 */   int[] definedColumnFormOfUse = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  492 */   T4CTTIoac[] oacdefSent = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  499 */   int[] nbPostPonedColumns = null;
/*  500 */   int[][] indexOfPostPonedColumn = (int[][])null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean aFetchWasDoneDuringDescribe = false;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean implicitDefineForLobPrefetchDone = false;
/*      */ 
/*      */ 
/*      */   
/*  513 */   long checkSum = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean checkSumComputationFailure = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  536 */   int accessorByteOffset = 0;
/*  537 */   int accessorCharOffset = 0;
/*  538 */   int accessorShortOffset = 0;
/*      */ 
/*      */ 
/*      */   
/*      */   static final int VALID_ROWS_UNINIT = -999;
/*      */ 
/*      */ 
/*      */   
/*      */   PhysicalConnection connection;
/*      */ 
/*      */   
/*      */   OracleInputStream streamList;
/*      */ 
/*      */   
/*      */   OracleInputStream nextStream;
/*      */ 
/*      */   
/*      */   OracleResultSetImpl currentResultSet;
/*      */ 
/*      */   
/*      */   boolean processEscapes;
/*      */ 
/*      */   
/*      */   boolean convertNcharLiterals;
/*      */ 
/*      */   
/*      */   int queryTimeout;
/*      */ 
/*      */   
/*      */   int batch;
/*      */ 
/*      */   
/*  570 */   int numberOfExecutedElementsInBatch = -1;
/*      */   
/*      */   int currentRank;
/*      */   
/*      */   boolean bsendBatchInProgress = false;
/*      */   
/*      */   int currentRow;
/*      */   
/*      */   int validRows;
/*      */   
/*      */   int maxFieldSize;
/*      */   
/*      */   int maxRows;
/*      */   
/*      */   int totalRowsVisited;
/*      */   
/*      */   int rowPrefetch;
/*  587 */   int rowPrefetchInLastFetch = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int defaultRowPrefetch;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean rowPrefetchChanged;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int defaultLobPrefetchSize;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean gotLastBatch;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean clearParameters;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean closed;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean sqlStringChanged;
/*      */ 
/*      */ 
/*      */   
/*      */   OracleSql sqlObject;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean needToParse;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean needToPrepareDefineBuffer;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean columnsDefinedByUser;
/*      */ 
/*      */ 
/*      */   
/*  638 */   OracleStatement.SqlKind sqlKind = OracleStatement.SqlKind.SELECT;
/*  639 */   byte sqlKindByte = 1;
/*      */ 
/*      */ 
/*      */   
/*      */   int autoRollback;
/*      */ 
/*      */ 
/*      */   
/*      */   int defaultFetchDirection;
/*      */ 
/*      */ 
/*      */   
/*      */   boolean serverCursor;
/*      */ 
/*      */   
/*      */   boolean fixedString = false;
/*      */ 
/*      */   
/*      */   boolean noMoreUpdateCounts = false;
/*      */ 
/*      */   
/*  660 */   protected CancelLock cancelLock = new CancelLock();
/*      */   
/*      */   OracleStatementWrapper wrapper;
/*      */   
/*      */   static final byte EXECUTE_NONE = -1;
/*      */   
/*      */   static final byte EXECUTE_QUERY = 1;
/*      */   
/*      */   static final byte EXECUTE_UPDATE = 2;
/*      */   
/*      */   static final byte EXECUTE_NORMAL = 3;
/*  671 */   byte executionType = -1;
/*      */ 
/*      */   
/*      */   OracleResultSet scrollRset;
/*      */ 
/*      */   
/*      */   OracleResultSetCache rsetCache;
/*      */   
/*      */   int userRsetType;
/*      */   
/*      */   int realRsetType;
/*      */   
/*      */   boolean needToAddIdentifier;
/*      */   
/*      */   SQLWarning sqlWarning;
/*      */   
/*  687 */   int cacheState = 3;
/*      */ 
/*      */   
/*  690 */   int creationState = 0;
/*      */ 
/*      */   
/*      */   boolean isOpen = false;
/*      */ 
/*      */   
/*  696 */   int statementType = 0;
/*      */   
/*      */   boolean columnSetNull = false;
/*      */   
/*      */   int[] returnParamMeta;
/*      */   
/*      */   static final int DMLR_METADATA_PREFIX_SIZE = 3;
/*      */   
/*      */   static final int DMLR_METADATA_NUM_OF_RETURN_PARAMS = 0;
/*      */   
/*      */   static final int DMLR_METADATA_ROW_BIND_BYTES = 1;
/*      */   
/*      */   static final int DMLR_METADATA_ROW_BIND_CHARS = 2;
/*      */   
/*      */   static final int DMLR_METADATA_TYPE_OFFSET = 0;
/*      */   
/*      */   static final int DMLR_METADATA_IS_CHAR_TYPE_OFFSET = 1;
/*      */   
/*      */   static final int DMLR_METADATA_BIND_SIZE_OFFSET = 2;
/*      */   
/*      */   static final int DMLR_METADATA_FORM_OF_USE_OFFSET = 3;
/*      */   
/*      */   static final int DMLR_METADATA_PER_POSITION_SIZE = 4;
/*      */   
/*      */   Accessor[] returnParamAccessors;
/*      */   
/*      */   boolean returnParamsFetched;
/*      */   
/*      */   int rowsDmlReturned;
/*      */   
/*      */   int numReturnParams;
/*      */   
/*      */   byte[] returnParamBytes;
/*      */   
/*      */   char[] returnParamChars;
/*      */   
/*      */   short[] returnParamIndicators;
/*      */   
/*      */   int returnParamRowBytes;
/*      */   
/*      */   int returnParamRowChars;
/*      */   OracleReturnResultSet returnResultSet;
/*      */   boolean isAutoGeneratedKey;
/*      */   AutoKeyInfo autoKeyInfo;
/*  740 */   TimeZone defaultTimeZone = null;
/*  741 */   String defaultTimeZoneName = null;
/*      */   
/*  743 */   Calendar defaultCalendar = null;
/*  744 */   Calendar gmtCalendar = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  756 */   long inScn = 0L; int lastIndex; Vector m_batchItems; ArrayList tempClobsToFree; ArrayList tempBlobsToFree; ArrayList oldTempClobsToFree; ArrayList oldTempBlobsToFree; NTFDCNRegistration registration; String[] dcnTableName; long dcnQueryId; long _checkSum; static final byte IS_UNINITIALIZED = 0; static final byte IS_SELECT = 1; static final byte IS_DELETE = 2; static final byte IS_INSERT = 4; static final byte IS_MERGE = 8; static final byte IS_UPDATE = 16; static final byte IS_PLSQL_BLOCK = 32; static final byte IS_CALL_BLOCK = 64; static final byte IS_OTHER = -128; static final byte IS_DML = 30;
/*      */   static final byte IS_PLSQL = 96;
/*      */   
/*      */   public void setSnapshotSCN(long paramLong) throws SQLException {
/*  760 */     doSetSnapshotSCN(paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/*  766 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  767 */     sQLException.fillInStackTrace();
/*  768 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2) throws SQLException {
/*  790 */     this(paramPhysicalConnection, paramInt1, paramInt2, -1, -1);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void initializeDefineSubRanges() {
/*  890 */     this.defineByteSubRange = 0;
/*  891 */     this.defineCharSubRange = 0;
/*  892 */     this.defineIndicatorSubRange = 0;
/*  893 */     this.defineMetaDataSubRange = 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prepareDefinePreambles() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prepareAccessors() throws SQLException {
/*  926 */     byte[] arrayOfByte1 = null;
/*  927 */     char[] arrayOfChar = null;
/*  928 */     short[] arrayOfShort = null;
/*  929 */     boolean bool = false;
/*  930 */     byte[] arrayOfByte2 = null;
/*      */     
/*  932 */     if (this.accessors == null) {
/*      */       
/*  934 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  935 */       sQLException.fillInStackTrace();
/*  936 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  942 */     int i = 0;
/*  943 */     int j = 0;
/*  944 */     int k = 0; int m;
/*  945 */     for (m = 0; m < this.numberOfDefinePositions; m++) {
/*      */       
/*  947 */       Accessor accessor = this.accessors[m];
/*      */       
/*  949 */       if (accessor == null) {
/*      */         
/*  951 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  952 */         sQLException.fillInStackTrace();
/*  953 */         throw sQLException;
/*      */       } 
/*  955 */       switch (accessor.internalType) {
/*      */         
/*      */         case 8:
/*      */         case 24:
/*  959 */           this.hasStream = true;
/*      */           break;
/*      */       } 
/*      */       
/*  963 */       i += accessor.byteLength;
/*  964 */       j += accessor.charLength;
/*  965 */       k++;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  970 */     if (this.streamList != null && !this.connection.useFetchSizeWithLongColumn) {
/*  971 */       this.rowPrefetch = 1;
/*      */     }
/*  973 */     m = this.rowPrefetch;
/*      */     
/*  975 */     this.definesBatchSize = m;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  983 */     initializeDefineSubRanges();
/*      */ 
/*      */     
/*  986 */     int n = k * m;
/*  987 */     if (this.defineMetaData == null || this.defineMetaData.length < n) {
/*      */       
/*  989 */       if (this.defineMetaData != null)
/*  990 */         arrayOfByte2 = this.defineMetaData; 
/*  991 */       this.defineMetaData = new byte[n];
/*      */     } 
/*      */ 
/*      */     
/*  995 */     this.cachedDefineByteSize = this.defineByteSubRange + i * m;
/*      */     
/*  997 */     if (this.defineBytes == null || this.defineBytes.length < this.cachedDefineByteSize) {
/*      */       
/*  999 */       if (this.defineBytes != null) arrayOfByte1 = this.defineBytes; 
/* 1000 */       this.defineBytes = this.connection.getByteBuffer(this.cachedDefineByteSize);
/*      */     } 
/*      */     
/* 1003 */     this.defineByteSubRange += this.accessorByteOffset;
/*      */ 
/*      */     
/* 1006 */     this.cachedDefineCharSize = this.defineCharSubRange + j * m;
/*      */     
/* 1008 */     if ((this.defineChars == null || this.defineChars.length < this.cachedDefineCharSize) && this.cachedDefineCharSize > 0) {
/*      */ 
/*      */       
/* 1011 */       if (this.defineChars != null) arrayOfChar = this.defineChars;
/*      */       
/* 1013 */       this.defineChars = this.connection.getCharBuffer(this.cachedDefineCharSize);
/*      */     } 
/*      */     
/* 1016 */     this.defineCharSubRange += this.accessorCharOffset;
/*      */ 
/*      */ 
/*      */     
/* 1020 */     int i1 = this.numberOfDefinePositions * m;
/* 1021 */     int i2 = this.defineIndicatorSubRange + i1 + i1;
/*      */ 
/*      */     
/* 1024 */     if (this.defineIndicators == null || this.defineIndicators.length < i2) {
/*      */ 
/*      */       
/* 1027 */       if (this.defineIndicators != null) arrayOfShort = this.defineIndicators; 
/* 1028 */       this.defineIndicators = new short[i2];
/* 1029 */     } else if (this.defineIndicators.length >= i2) {
/*      */       
/* 1031 */       bool = true;
/* 1032 */       arrayOfShort = this.defineIndicators;
/*      */     } 
/*      */     
/* 1035 */     this.defineIndicatorSubRange += this.accessorShortOffset;
/*      */     
/* 1037 */     int i3 = this.defineIndicatorSubRange + i1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1043 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*      */       
/* 1045 */       Accessor accessor = this.accessors[b];
/*      */       
/* 1047 */       accessor.lengthIndexLastRow = accessor.lengthIndex;
/* 1048 */       accessor.indicatorIndexLastRow = accessor.indicatorIndex;
/* 1049 */       accessor.columnIndexLastRow = accessor.columnIndex;
/*      */       
/* 1051 */       accessor.setOffsets(m);
/*      */       
/* 1053 */       accessor.lengthIndex = i3;
/* 1054 */       accessor.indicatorIndex = this.defineIndicatorSubRange;
/* 1055 */       accessor.metaDataIndex = this.defineMetaDataSubRange;
/* 1056 */       accessor.rowSpaceByte = this.defineBytes;
/* 1057 */       accessor.rowSpaceChar = this.defineChars;
/* 1058 */       accessor.rowSpaceIndicator = this.defineIndicators;
/* 1059 */       accessor.rowSpaceMetaData = this.defineMetaData;
/* 1060 */       this.defineIndicatorSubRange += m;
/* 1061 */       i3 += m;
/* 1062 */       this.defineMetaDataSubRange += m * 1;
/*      */     } 
/*      */     
/* 1065 */     prepareDefinePreambles();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1073 */     if (this.rowPrefetchInLastFetch != -1 && this.rowPrefetch != this.rowPrefetchInLastFetch) {
/*      */       
/* 1075 */       if (arrayOfChar == null) arrayOfChar = this.defineChars; 
/* 1076 */       if (arrayOfByte1 == null) arrayOfByte1 = this.defineBytes; 
/* 1077 */       if (arrayOfShort == null) arrayOfShort = this.defineIndicators; 
/* 1078 */       saveDefineBuffersIfRequired(arrayOfChar, arrayOfByte1, arrayOfShort, bool);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean checkAccessorsUsable() throws SQLException {
/* 1094 */     int i = this.accessors.length;
/*      */     
/* 1096 */     if (i < this.numberOfDefinePositions) {
/* 1097 */       return false;
/*      */     }
/* 1099 */     boolean bool1 = true;
/* 1100 */     boolean bool2 = false;
/* 1101 */     boolean bool3 = false;
/*      */     
/* 1103 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/*      */       
/* 1105 */       Accessor accessor = this.accessors[b];
/*      */       
/* 1107 */       if (accessor == null || accessor.externalType == 0) {
/* 1108 */         bool1 = false;
/*      */       } else {
/* 1110 */         bool2 = true;
/*      */       } 
/*      */     } 
/* 1113 */     if (bool1)
/*      */     
/*      */     { 
/* 1116 */       bool3 = true; }
/* 1117 */     else { if (bool2) {
/*      */ 
/*      */ 
/*      */         
/* 1121 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 1122 */         sQLException.fillInStackTrace();
/* 1123 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1129 */       this.columnsDefinedByUser = false; }
/*      */     
/* 1131 */     return bool3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void executeMaybeDescribe() throws SQLException {
/* 1140 */     boolean bool1 = true;
/*      */     
/* 1142 */     if (this.rowPrefetchChanged) {
/*      */       
/* 1144 */       if (this.streamList == null && this.rowPrefetch != this.definesBatchSize) {
/* 1145 */         this.needToPrepareDefineBuffer = true;
/*      */       }
/* 1147 */       this.rowPrefetchChanged = false;
/*      */     } 
/*      */     
/* 1150 */     if (!this.needToPrepareDefineBuffer)
/*      */     {
/*      */ 
/*      */       
/* 1154 */       if (this.accessors == null) {
/*      */ 
/*      */ 
/*      */         
/* 1158 */         this.needToPrepareDefineBuffer = true;
/* 1159 */       } else if (this.columnsDefinedByUser) {
/* 1160 */         this.needToPrepareDefineBuffer = !checkAccessorsUsable();
/*      */       } 
/*      */     }
/* 1163 */     boolean bool2 = false;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1168 */       this.cancelLock.enterExecuting();
/*      */       
/* 1170 */       if (this.needToPrepareDefineBuffer) {
/*      */ 
/*      */         
/* 1173 */         if (!this.columnsDefinedByUser) {
/*      */           
/* 1175 */           executeForDescribe();
/*      */           
/* 1177 */           bool2 = true;
/*      */ 
/*      */ 
/*      */           
/* 1181 */           if (this.aFetchWasDoneDuringDescribe) {
/* 1182 */             bool1 = false;
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/* 1188 */         if (this.needToPrepareDefineBuffer)
/*      */         {
/*      */ 
/*      */           
/* 1192 */           prepareAccessors();
/*      */         }
/*      */       } 
/*      */ 
/*      */       
/* 1197 */       int i = this.accessors.length;
/*      */       
/* 1199 */       for (int j = this.numberOfDefinePositions; j < i; j++) {
/*      */         
/* 1201 */         Accessor accessor = this.accessors[j];
/*      */         
/* 1203 */         if (accessor != null)
/* 1204 */           accessor.rowSpaceIndicator = null; 
/*      */       } 
/* 1206 */       if (bool1) {
/* 1207 */         executeForRows(bool2);
/*      */       }
/*      */     }
/* 1210 */     catch (SQLException sQLException) {
/*      */       
/* 1212 */       this.needToParse = true;
/* 1213 */       throw sQLException;
/*      */     }
/*      */     finally {
/*      */       
/* 1217 */       this.cancelLock.exitExecuting();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void adjustGotLastBatch() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doExecuteWithTimeout() throws SQLException {
/*      */     try {
/* 1253 */       cleanOldTempLobs();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1260 */       this.connection.registerHeartbeat();
/*      */ 
/*      */       
/* 1263 */       this.rowsProcessed = 0;
/*      */       
/* 1265 */       if (this.sqlKind.isSELECT()) {
/*      */         
/* 1267 */         if (this.connection.j2ee13Compliant && this.executionType == 2) {
/*      */           
/* 1269 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 129);
/* 1270 */           sQLException.fillInStackTrace();
/* 1271 */           throw sQLException;
/*      */         } 
/*      */         
/* 1274 */         this.connection.needLine();
/*      */         
/* 1276 */         if (!this.isOpen) {
/*      */           
/* 1278 */           this.connection.open(this);
/*      */           
/* 1280 */           this.isOpen = true;
/*      */         } 
/*      */         
/* 1283 */         if (this.queryTimeout != 0) {
/*      */ 
/*      */           
/*      */           try {
/* 1287 */             this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);
/* 1288 */             executeMaybeDescribe();
/*      */           }
/*      */           finally {
/*      */             
/* 1292 */             this.connection.getTimeout().cancelTimeout();
/*      */           } 
/*      */         } else {
/*      */           
/* 1296 */           executeMaybeDescribe();
/*      */         } 
/* 1298 */         checkValidRowsStatus();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1303 */         if (this.serverCursor) {
/* 1304 */           adjustGotLastBatch();
/*      */         }
/*      */       } else {
/*      */         
/* 1308 */         if (this.connection.j2ee13Compliant && !this.sqlKind.isPlsqlOrCall() && this.executionType == 1) {
/*      */ 
/*      */           
/* 1311 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 128);
/* 1312 */           sQLException.fillInStackTrace();
/* 1313 */           throw sQLException;
/*      */         } 
/*      */         
/* 1316 */         this.currentRank++;
/*      */         
/* 1318 */         if (this.currentRank >= this.batch) {
/*      */           try
/*      */           {
/*      */             
/* 1322 */             this.connection.needLine();
/*      */             
/* 1324 */             this.cancelLock.enterExecuting();
/*      */             
/* 1326 */             if (!this.isOpen) {
/*      */               
/* 1328 */               this.connection.open(this);
/*      */               
/* 1330 */               this.isOpen = true;
/*      */             } 
/*      */             
/* 1333 */             if (this.queryTimeout != 0) {
/* 1334 */               this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);
/*      */             }
/* 1336 */             executeForRows(false);
/*      */           }
/* 1338 */           catch (SQLException sQLException)
/*      */           {
/* 1340 */             this.needToParse = true;
/* 1341 */             if (this.batch > 1) {
/*      */               int[] arrayOfInt;
/* 1343 */               clearBatch();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/* 1349 */               if (this.numberOfExecutedElementsInBatch != -1 && this.numberOfExecutedElementsInBatch < this.batch) {
/*      */ 
/*      */                 
/* 1352 */                 arrayOfInt = new int[this.numberOfExecutedElementsInBatch];
/* 1353 */                 for (byte b = 0; b < arrayOfInt.length; b++) {
/* 1354 */                   arrayOfInt[b] = -2;
/*      */                 }
/*      */               } else {
/*      */                 
/* 1358 */                 arrayOfInt = new int[this.batch];
/* 1359 */                 for (byte b = 0; b < arrayOfInt.length; b++) {
/* 1360 */                   arrayOfInt[b] = -3;
/*      */                 }
/*      */               } 
/* 1363 */               BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(sQLException, arrayOfInt.length, arrayOfInt);
/* 1364 */               batchUpdateException.fillInStackTrace();
/* 1365 */               throw batchUpdateException;
/*      */             } 
/*      */             
/* 1368 */             resetCurrentRowBinders();
/*      */             
/* 1370 */             throw sQLException;
/*      */           }
/*      */           finally
/*      */           {
/* 1374 */             if (this.queryTimeout != 0) {
/* 1375 */               this.connection.getTimeout().cancelTimeout();
/*      */             }
/* 1377 */             this.currentRank = 0;
/* 1378 */             this.cancelLock.exitExecuting();
/*      */             
/* 1380 */             checkValidRowsStatus();
/*      */ 
/*      */           
/*      */           }
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/* 1393 */     catch (SQLException sQLException) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1398 */       resetOnExceptionDuringExecute();
/* 1399 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1409 */     this.connection.registerHeartbeat();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetOnExceptionDuringExecute() {
/* 1418 */     this.needToParse = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void resetCurrentRowBinders() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void open() throws SQLException {
/* 1440 */     if (!this.isOpen) {
/*      */       
/* 1442 */       this.connection.needLine();
/* 1443 */       this.connection.open(this);
/*      */       
/* 1445 */       this.isOpen = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery(String paramString) throws SQLException {
/* 1464 */     synchronized (this.connection) {
/*      */       
/* 1466 */       OracleResultSet oracleResultSet = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1474 */         this.executionType = 1;
/*      */ 
/*      */ 
/*      */         
/* 1478 */         this.noMoreUpdateCounts = false;
/*      */         
/* 1480 */         ensureOpen();
/* 1481 */         checkIfJdbcBatchExists();
/*      */         
/* 1483 */         sendBatch();
/*      */ 
/*      */         
/* 1486 */         this.hasStream = false;
/*      */ 
/*      */         
/* 1489 */         this.sqlObject.initialize(paramString);
/*      */         
/* 1491 */         this.sqlKind = this.sqlObject.getSqlKind();
/* 1492 */         this.needToParse = true;
/*      */         
/* 1494 */         prepareForNewResults(true, true);
/*      */         
/* 1496 */         if (this.userRsetType == 1) {
/*      */           
/* 1498 */           doExecuteWithTimeout();
/*      */           
/* 1500 */           this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 1501 */           oracleResultSet = this.currentResultSet;
/*      */         }
/*      */         else {
/*      */           
/* 1505 */           oracleResultSet = doScrollStmtExecuteQuery();
/*      */           
/* 1507 */           if (oracleResultSet == null)
/*      */           {
/* 1509 */             this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/* 1510 */             oracleResultSet = this.currentResultSet;
/*      */           }
/*      */         
/*      */         } 
/*      */       } finally {
/*      */         
/* 1516 */         this.executionType = -1;
/*      */       } 
/*      */       
/* 1519 */       return (ResultSet)oracleResultSet;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeWithKey(String paramString) throws SQLException {
/* 1532 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 1533 */     sQLException.fillInStackTrace();
/* 1534 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/* 1566 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 1570 */       closeOrCache(null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void closeOrCache(String paramString) throws SQLException {
/* 1578 */     if (this.closed) {
/*      */       return;
/*      */     }
/*      */     
/* 1582 */     if (this.connection.lifecycle == 2) {
/* 1583 */       this.connection.needLineUnchecked();
/*      */     } else {
/* 1585 */       this.connection.needLine();
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1594 */     if (this.statementType != 0 && this.cacheState != 0 && this.cacheState != 3 && this.connection.isStatementCacheInitialized()) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1605 */       if (paramString == null)
/*      */       {
/* 1607 */         if (this.connection.getImplicitCachingEnabled())
/*      */         {
/* 1609 */           this.connection.cacheImplicitStatement((OraclePreparedStatement)this, this.sqlObject.getOriginalSql(), this.statementType, this.userRsetType);
/*      */ 
/*      */ 
/*      */         
/*      */         }
/*      */         else
/*      */         {
/*      */ 
/*      */           
/* 1618 */           this.cacheState = 0;
/*      */           
/* 1620 */           hardClose();
/*      */         
/*      */         }
/*      */ 
/*      */       
/*      */       }
/* 1626 */       else if (this.connection.getExplicitCachingEnabled())
/*      */       {
/* 1628 */         this.connection.cacheExplicitStatement((OraclePreparedStatement)this, paramString);
/*      */ 
/*      */       
/*      */       }
/*      */       else
/*      */       {
/*      */ 
/*      */         
/* 1636 */         this.cacheState = 0;
/*      */         
/* 1638 */         hardClose();
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 1647 */       hardClose();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void hardClose() throws SQLException {
/* 1657 */     hardClose(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void hardClose(boolean paramBoolean) throws SQLException {
/* 1668 */     alwaysOnClose();
/*      */     
/* 1670 */     this.describedWithNames = false;
/* 1671 */     this.described = false;
/*      */ 
/*      */     
/* 1674 */     this.connection.removeStatement(this);
/*      */     
/* 1676 */     cleanupDefines();
/*      */     
/* 1678 */     if (this.isOpen && paramBoolean && (this.connection.lifecycle == 1 || this.connection.lifecycle == 16 || this.connection.lifecycle == 2)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1687 */       this.connection.registerHeartbeat();
/*      */ 
/*      */       
/* 1690 */       doClose();
/*      */       
/* 1692 */       this.isOpen = false;
/*      */     } 
/*      */     
/* 1695 */     this.sqlObject = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void alwaysOnClose() throws SQLException {
/* 1712 */     OracleStatement oracleStatement = this.children;
/*      */     
/* 1714 */     while (oracleStatement != null) {
/*      */       
/* 1716 */       OracleStatement oracleStatement1 = oracleStatement.nextChild;
/*      */       
/* 1718 */       oracleStatement.close();
/*      */       
/* 1720 */       oracleStatement = oracleStatement1;
/*      */     } 
/*      */     
/* 1723 */     if (this.parent != null)
/*      */     {
/* 1725 */       this.parent.removeChild(this);
/*      */     }
/*      */     
/* 1728 */     this.closed = true;
/*      */ 
/*      */     
/* 1731 */     if (this.connection.lifecycle == 1 || this.connection.lifecycle == 2) {
/*      */ 
/*      */ 
/*      */       
/* 1735 */       if (this.currentResultSet != null) {
/*      */         
/* 1737 */         this.currentResultSet.internal_close(false);
/*      */         
/* 1739 */         this.currentResultSet = null;
/*      */       } 
/*      */       
/* 1742 */       if (this.scrollRset != null) {
/*      */         
/* 1744 */         this.scrollRset.close();
/*      */         
/* 1746 */         this.scrollRset = null;
/*      */       } 
/*      */       
/* 1749 */       if (this.returnResultSet != null) {
/*      */         
/* 1751 */         this.returnResultSet.close();
/* 1752 */         this.returnResultSet = null;
/*      */       } 
/*      */     } 
/*      */     
/* 1756 */     clearWarnings();
/*      */     
/* 1758 */     this.m_batchItems = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeLeaveCursorOpen() throws SQLException {
/* 1774 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1780 */       if (this.closed) {
/*      */         return;
/*      */       }
/*      */ 
/*      */       
/* 1785 */       hardClose(false);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate(String paramString) throws SQLException {
/* 1804 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1809 */       setNonAutoKey();
/* 1810 */       return executeUpdateInternal(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int executeUpdateInternal(String paramString) throws SQLException {
/*      */     try {
/* 1821 */       if (this.executionType == -1) {
/* 1822 */         this.executionType = 2;
/*      */       }
/*      */       
/* 1825 */       this.noMoreUpdateCounts = false;
/*      */       
/* 1827 */       ensureOpen();
/* 1828 */       checkIfJdbcBatchExists();
/*      */       
/* 1830 */       sendBatch();
/*      */ 
/*      */       
/* 1833 */       this.hasStream = false;
/*      */ 
/*      */       
/* 1836 */       this.sqlObject.initialize(paramString);
/*      */       
/* 1838 */       this.sqlKind = this.sqlObject.getSqlKind();
/* 1839 */       this.needToParse = true;
/*      */       
/* 1841 */       prepareForNewResults(true, true);
/*      */       
/* 1843 */       if (this.userRsetType == 1) {
/*      */         
/* 1845 */         doExecuteWithTimeout();
/*      */       }
/*      */       else {
/*      */         
/* 1849 */         doScrollStmtExecuteQuery();
/*      */       } 
/*      */       
/* 1852 */       return this.validRows;
/*      */     }
/*      */     finally {
/*      */       
/* 1856 */       this.executionType = -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute(String paramString) throws SQLException {
/* 1872 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1877 */       setNonAutoKey();
/* 1878 */       return executeInternal(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean executeInternal(String paramString) throws SQLException {
/*      */     try {
/* 1889 */       this.executionType = 3;
/*      */       
/* 1891 */       this.checkSum = 0L;
/* 1892 */       this.checkSumComputationFailure = false;
/*      */ 
/*      */       
/* 1895 */       this.noMoreUpdateCounts = false;
/*      */       
/* 1897 */       ensureOpen();
/* 1898 */       checkIfJdbcBatchExists();
/*      */       
/* 1900 */       sendBatch();
/*      */ 
/*      */ 
/*      */       
/* 1904 */       this.hasStream = false;
/*      */ 
/*      */       
/* 1907 */       this.sqlObject.initialize(paramString);
/*      */       
/* 1909 */       this.sqlKind = this.sqlObject.getSqlKind();
/* 1910 */       this.needToParse = true;
/*      */       
/* 1912 */       prepareForNewResults(true, true);
/*      */       
/* 1914 */       if (this.userRsetType == 1) {
/*      */         
/* 1916 */         doExecuteWithTimeout();
/*      */       }
/*      */       else {
/*      */         
/* 1920 */         doScrollStmtExecuteQuery();
/*      */       } 
/*      */       
/* 1923 */       return this.sqlKind.isSELECT();
/*      */     }
/*      */     finally {
/*      */       
/* 1927 */       this.executionType = -1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getNumberOfColumns() throws SQLException {
/* 1935 */     ensureOpen();
/* 1936 */     if (!this.described)
/*      */     {
/* 1938 */       synchronized (this.connection) {
/* 1939 */         doDescribe(false);
/*      */         
/* 1941 */         this.described = true;
/*      */       } 
/*      */     }
/*      */     
/* 1945 */     return this.numberOfDefinePositions;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor[] getDescription() throws SQLException {
/* 1952 */     ensureOpen();
/* 1953 */     if (!this.described)
/*      */     {
/* 1955 */       synchronized (this.connection) {
/* 1956 */         doDescribe(false);
/*      */         
/* 1958 */         this.described = true;
/*      */       } 
/*      */     }
/*      */     
/* 1962 */     return this.accessors;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor[] getDescriptionWithNames() throws SQLException {
/* 1969 */     ensureOpen();
/* 1970 */     if (!this.describedWithNames)
/*      */     {
/* 1972 */       synchronized (this.connection) {
/* 1973 */         doDescribe(true);
/*      */         
/* 1975 */         this.described = true;
/* 1976 */         this.describedWithNames = true;
/*      */       } 
/*      */     }
/*      */     
/* 1980 */     return this.accessors;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleStatement.SqlKind getSqlKind() throws SQLException {
/* 1993 */     return this.sqlObject.getSqlKind();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearDefines() throws SQLException {
/* 2013 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2016 */       freeLine();
/*      */       
/* 2018 */       this.streamList = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2025 */       this.columnsDefinedByUser = false;
/* 2026 */       this.needToPrepareDefineBuffer = true;
/*      */ 
/*      */       
/* 2029 */       this.numberOfDefinePositions = 0;
/* 2030 */       this.definesBatchSize = 0;
/*      */       
/* 2032 */       this.described = false;
/* 2033 */       this.describedWithNames = false;
/*      */       
/* 2035 */       cleanupDefines();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reparseOnRedefineIfNeeded() throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, String paramString) throws SQLException {
/* 2057 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, (short)1, paramBoolean, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void defineColumnTypeInternal(int paramInt1, int paramInt2, int paramInt3, short paramShort, boolean paramBoolean, String paramString) throws SQLException {
/* 2068 */     if (this.connection.disableDefinecolumntype) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/* 2073 */     if (paramInt1 < 1) {
/*      */       
/* 2075 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3);
/* 2076 */       sQLException.fillInStackTrace();
/* 2077 */       throw sQLException;
/*      */     } 
/*      */     
/* 2080 */     if (paramInt2 == 0) {
/*      */       
/* 2082 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 2083 */       sQLException.fillInStackTrace();
/* 2084 */       throw sQLException;
/*      */     } 
/*      */     
/* 2087 */     int i = paramInt1 - 1;
/* 2088 */     int j = (this.maxFieldSize > 0) ? this.maxFieldSize : -1;
/*      */     
/* 2090 */     if (paramBoolean) {
/*      */ 
/*      */ 
/*      */       
/* 2094 */       if (paramInt2 == 1 || paramInt2 == 12)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/* 2099 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 108);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2106 */       if (paramInt3 < 0) {
/*      */         
/* 2108 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 53);
/* 2109 */         sQLException.fillInStackTrace();
/* 2110 */         throw sQLException;
/*      */       } 
/*      */       
/* 2113 */       if ((j == -1 && paramInt3 > 0) || (j && paramInt3 < j))
/*      */       {
/* 2115 */         j = paramInt3;
/*      */       }
/*      */     } 
/* 2118 */     if (this.currentResultSet != null && !this.currentResultSet.closed) {
/*      */       
/* 2120 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 28);
/* 2121 */       sQLException.fillInStackTrace();
/* 2122 */       throw sQLException;
/*      */     } 
/*      */     
/* 2125 */     if (!this.columnsDefinedByUser) {
/*      */ 
/*      */ 
/*      */       
/* 2129 */       clearDefines();
/*      */       
/* 2131 */       this.columnsDefinedByUser = true;
/*      */     } 
/*      */     
/* 2134 */     if (this.numberOfDefinePositions < paramInt1) {
/*      */       
/* 2136 */       if (this.accessors == null || this.accessors.length < paramInt1) {
/*      */         
/* 2138 */         Accessor[] arrayOfAccessor = new Accessor[paramInt1 << 1];
/*      */         
/* 2140 */         if (this.accessors != null) {
/* 2141 */           System.arraycopy(this.accessors, 0, arrayOfAccessor, 0, this.numberOfDefinePositions);
/*      */         }
/* 2143 */         this.accessors = arrayOfAccessor;
/*      */       } 
/*      */       
/* 2146 */       this.numberOfDefinePositions = paramInt1;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2153 */     int k = getInternalType(paramInt2);
/*      */     
/* 2155 */     if ((k == 109 || k == 111) && (paramString == null || paramString.equals(""))) {
/*      */ 
/*      */       
/* 2158 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Invalid arguments");
/* 2159 */       sQLException.fillInStackTrace();
/* 2160 */       throw sQLException;
/*      */     } 
/*      */     
/* 2163 */     Accessor accessor = this.accessors[i];
/* 2164 */     boolean bool = true;
/*      */     
/* 2166 */     if (accessor != null) {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2171 */       int m = accessor.useForDataAccessIfPossible(k, paramInt2, j, paramString);
/*      */ 
/*      */       
/* 2174 */       if (m == 0) {
/*      */         
/* 2176 */         paramShort = accessor.formOfUse;
/* 2177 */         accessor = null;
/*      */         
/* 2179 */         reparseOnRedefineIfNeeded();
/*      */       }
/* 2181 */       else if (m == 1) {
/*      */         
/* 2183 */         accessor = null;
/*      */         
/* 2185 */         reparseOnRedefineIfNeeded();
/*      */       }
/* 2187 */       else if (m == 2) {
/* 2188 */         bool = false;
/*      */       } 
/*      */     } 
/* 2191 */     if (bool) {
/* 2192 */       this.needToPrepareDefineBuffer = true;
/*      */     }
/* 2194 */     if (accessor == null) {
/*      */       
/* 2196 */       this.accessors[i] = allocateAccessor(k, paramInt2, paramInt1, j, paramShort, paramString, false);
/*      */       
/* 2198 */       this.described = false;
/* 2199 */       this.describedWithNames = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Accessor allocateAccessor(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString, boolean paramBoolean) throws SQLException {
/*      */     BlobAccessor blobAccessor;
/*      */     ClobAccessor clobAccessor;
/*      */     BfileAccessor bfileAccessor;
/*      */     NamedTypeAccessor namedTypeAccessor;
/*      */     RefTypeAccessor refTypeAccessor;
/* 2241 */     switch (paramInt1) {
/*      */ 
/*      */       
/*      */       case 96:
/* 2245 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2247 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2248 */           sQLException1.fillInStackTrace();
/* 2249 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2252 */         return new CharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 8:
/* 2255 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2257 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2258 */           sQLException1.fillInStackTrace();
/* 2259 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2262 */         if (!paramBoolean) {
/* 2263 */           return new LongAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */         }
/*      */ 
/*      */       
/*      */       case 1:
/* 2268 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2270 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2271 */           sQLException1.fillInStackTrace();
/* 2272 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2275 */         return new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 2:
/* 2278 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2280 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2281 */           sQLException1.fillInStackTrace();
/* 2282 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2285 */         return new NumberAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 6:
/* 2288 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2290 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2291 */           sQLException1.fillInStackTrace();
/* 2292 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2295 */         return new VarnumAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 24:
/* 2298 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2300 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2301 */           sQLException1.fillInStackTrace();
/* 2302 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2305 */         if (!paramBoolean) {
/* 2306 */           return new LongRawAccessor(this, paramInt3, paramInt4, paramShort, paramInt2);
/*      */         }
/*      */ 
/*      */ 
/*      */       
/*      */       case 23:
/* 2312 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2314 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2315 */           sQLException1.fillInStackTrace();
/* 2316 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2319 */         if (paramBoolean) {
/* 2320 */           return new OutRawAccessor(this, paramInt4, paramShort, paramInt2);
/*      */         }
/* 2322 */         return new RawAccessor(this, paramInt4, paramShort, paramInt2, false);
/*      */       
/*      */       case 100:
/* 2325 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2327 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2328 */           sQLException1.fillInStackTrace();
/* 2329 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2332 */         return new BinaryFloatAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 101:
/* 2336 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2338 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2339 */           sQLException1.fillInStackTrace();
/* 2340 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2343 */         return new BinaryDoubleAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 104:
/* 2347 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2349 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2350 */           sQLException1.fillInStackTrace();
/* 2351 */           throw sQLException1;
/*      */         } 
/* 2353 */         if (this.sqlKind == OracleStatement.SqlKind.CALL_BLOCK) {
/*      */           
/* 2355 */           paramInt4 = 18;
/* 2356 */           VarcharAccessor varcharAccessor = new VarcharAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/* 2357 */           varcharAccessor.definedColumnType = -8;
/* 2358 */           return varcharAccessor;
/*      */         } 
/* 2360 */         return new RowidAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 102:
/* 2363 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2365 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2366 */           sQLException1.fillInStackTrace();
/* 2367 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2370 */         return new ResultSetAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 12:
/* 2373 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2375 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2376 */           sQLException1.fillInStackTrace();
/* 2377 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2380 */         return new DateAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */       
/*      */       case 113:
/* 2383 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2385 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2386 */           sQLException1.fillInStackTrace();
/* 2387 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2390 */         blobAccessor = new BlobAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/* 2391 */         if (!paramBoolean)
/* 2392 */           blobAccessor.lobPrefetchSizeForThisColumn = paramInt4; 
/* 2393 */         return blobAccessor;
/*      */       
/*      */       case 112:
/* 2396 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2398 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2399 */           sQLException1.fillInStackTrace();
/* 2400 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2403 */         clobAccessor = new ClobAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/* 2404 */         if (!paramBoolean)
/* 2405 */           clobAccessor.lobPrefetchSizeForThisColumn = paramInt4; 
/* 2406 */         return clobAccessor;
/*      */       
/*      */       case 114:
/* 2409 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2411 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2412 */           sQLException1.fillInStackTrace();
/* 2413 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2416 */         return new BfileAccessor(this, -1, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 109:
/* 2423 */         if (paramString == null) {
/* 2424 */           if (paramBoolean) {
/*      */             
/* 2426 */             SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2427 */             sQLException2.fillInStackTrace();
/* 2428 */             throw sQLException2;
/*      */           } 
/*      */ 
/*      */           
/* 2432 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
/* 2433 */           sQLException1.fillInStackTrace();
/* 2434 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2437 */         namedTypeAccessor = new NamedTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */         
/* 2440 */         namedTypeAccessor.initMetadata();
/*      */         
/* 2442 */         return namedTypeAccessor;
/*      */       
/*      */       case 111:
/* 2445 */         if (paramString == null) {
/* 2446 */           if (paramBoolean) {
/*      */             
/* 2448 */             SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2449 */             sQLException2.fillInStackTrace();
/* 2450 */             throw sQLException2;
/*      */           } 
/*      */ 
/*      */           
/* 2454 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 60, "Unable to resolve type \"null\"");
/* 2455 */           sQLException1.fillInStackTrace();
/* 2456 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2459 */         refTypeAccessor = new RefTypeAccessor(this, paramString, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */         
/* 2462 */         refTypeAccessor.initMetadata();
/*      */         
/* 2464 */         return refTypeAccessor;
/*      */ 
/*      */ 
/*      */       
/*      */       case 180:
/* 2469 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2471 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2472 */           sQLException1.fillInStackTrace();
/* 2473 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2476 */         return new TimestampAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 181:
/* 2480 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2482 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2483 */           sQLException1.fillInStackTrace();
/* 2484 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2487 */         return new TimestamptzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 231:
/* 2491 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2493 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2494 */           sQLException1.fillInStackTrace();
/* 2495 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2498 */         return new TimestampltzAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 182:
/* 2502 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2504 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2505 */           sQLException1.fillInStackTrace();
/* 2506 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2509 */         return new IntervalymAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */       
/*      */       case 183:
/* 2513 */         if (paramBoolean && paramString != null) {
/*      */           
/* 2515 */           SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 12, "sqlType=" + paramInt2);
/* 2516 */           sQLException1.fillInStackTrace();
/* 2517 */           throw sQLException1;
/*      */         } 
/*      */         
/* 2520 */         return new IntervaldsAccessor(this, paramInt4, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 995:
/* 2539 */         sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 89);
/* 2540 */         sQLException.fillInStackTrace();
/* 2541 */         throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2546 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 2547 */     sQLException.fillInStackTrace();
/* 2548 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2) throws SQLException {
/* 2600 */     synchronized (this.connection) {
/*      */       
/* 2602 */       defineColumnTypeInternal(paramInt1, paramInt2, -1, true, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 2618 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, int paramInt3, short paramShort) throws SQLException {
/* 2637 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, paramShort, false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 2708 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2711 */       defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 2782 */     defineColumnTypeInternal(paramInt1, paramInt2, paramInt3, false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineColumnType(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 2822 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2828 */       defineColumnTypeInternal(paramInt1, paramInt2, -1, true, paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setCursorId(int paramInt) throws SQLException {
/* 2844 */     this.cursorId = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setPrefetchInternal(int paramInt, boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
/* 2859 */     if (paramBoolean1) {
/*      */       
/* 2861 */       if (paramInt <= 0)
/*      */       {
/* 2863 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
/* 2864 */         sQLException.fillInStackTrace();
/* 2865 */         throw sQLException;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/* 2870 */       if (paramInt < 0) {
/*      */         
/* 2872 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchSize");
/* 2873 */         sQLException.fillInStackTrace();
/* 2874 */         throw sQLException;
/*      */       } 
/* 2876 */       if (paramInt == 0) {
/* 2877 */         paramInt = this.connection.getDefaultRowPrefetch();
/*      */       }
/*      */     } 
/*      */     
/* 2881 */     if (paramBoolean2) {
/*      */       
/* 2883 */       if (paramInt != this.defaultRowPrefetch)
/*      */       {
/* 2885 */         this.defaultRowPrefetch = paramInt;
/*      */ 
/*      */ 
/*      */         
/* 2889 */         if (this.currentResultSet == null || this.currentResultSet.closed) {
/* 2890 */           this.rowPrefetchChanged = true;
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/* 2897 */     else if (paramInt != this.rowPrefetch && this.streamList == null) {
/*      */ 
/*      */       
/* 2900 */       this.rowPrefetch = paramInt;
/* 2901 */       this.rowPrefetchChanged = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRowPrefetch(int paramInt) throws SQLException {
/* 2928 */     synchronized (this.connection) {
/*      */ 
/*      */ 
/*      */       
/* 2932 */       setPrefetchInternal(paramInt, true, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLobPrefetchSize(int paramInt) throws SQLException {
/* 2945 */     synchronized (this.connection) {
/*      */       
/* 2947 */       if (paramInt < -1) {
/*      */         
/* 2949 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
/* 2950 */         sQLException.fillInStackTrace();
/* 2951 */         throw sQLException;
/*      */       } 
/* 2953 */       this.defaultLobPrefetchSize = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getLobPrefetchSize() {
/* 2961 */     return this.defaultLobPrefetchSize;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getPrefetchInternal(boolean paramBoolean) {
/* 2978 */     return paramBoolean ? this.defaultRowPrefetch : this.rowPrefetch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getRowPrefetch() {
/* 2995 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 2998 */       return getPrefetchInternal(true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedString(boolean paramBoolean) {
/* 3025 */     this.fixedString = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getFixedString() {
/* 3050 */     return this.fixedString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void check_row_prefetch_changed() throws SQLException {
/* 3065 */     if (this.rowPrefetchChanged) {
/*      */       
/* 3067 */       if (this.streamList == null) {
/*      */         
/* 3069 */         prepareAccessors();
/*      */         
/* 3071 */         this.needToPrepareDefineBuffer = true;
/*      */       } 
/*      */       
/* 3074 */       this.rowPrefetchChanged = false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void setDefinesInitialized(boolean paramBoolean) {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void printState(String paramString) throws SQLException {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void checkValidRowsStatus() throws SQLException {
/* 3111 */     if (this.validRows == -2) {
/*      */ 
/*      */ 
/*      */       
/* 3115 */       this.validRows = 1;
/* 3116 */       this.connection.holdLine(this);
/*      */ 
/*      */       
/* 3119 */       OracleInputStream oracleInputStream = this.streamList;
/*      */       
/* 3121 */       while (oracleInputStream != null) {
/*      */         
/* 3123 */         if (oracleInputStream.hasBeenOpen) {
/* 3124 */           oracleInputStream = oracleInputStream.accessor.initForNewRow();
/*      */         }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3131 */         oracleInputStream.closed = false;
/* 3132 */         oracleInputStream.hasBeenOpen = true;
/*      */ 
/*      */ 
/*      */         
/* 3136 */         oracleInputStream = oracleInputStream.nextStream;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3141 */       this.nextStream = this.streamList;
/*      */     
/*      */     }
/* 3144 */     else if (this.sqlKind.isSELECT()) {
/*      */       
/* 3146 */       if (this.validRows < this.rowPrefetch) {
/* 3147 */         this.gotLastBatch = true;
/*      */       }
/* 3149 */     } else if (!this.sqlKind.isPlsqlOrCall()) {
/*      */       
/* 3151 */       this.rowsProcessed = this.validRows;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cleanupDefines() {
/* 3159 */     if (this.accessors != null)
/* 3160 */       for (byte b = 0; b < this.accessors.length; b++) {
/* 3161 */         this.accessors[b] = null;
/*      */       } 
/* 3163 */     this.accessors = null;
/*      */ 
/*      */     
/* 3166 */     this.connection.cacheBuffer(this.defineBytes);
/* 3167 */     this.defineBytes = null;
/* 3168 */     this.connection.cacheBuffer(this.defineChars);
/* 3169 */     this.defineChars = null;
/* 3170 */     this.defineIndicators = null;
/* 3171 */     this.defineMetaData = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxFieldSize() throws SQLException {
/* 3178 */     synchronized (this.connection) {
/*      */       
/* 3180 */       return this.maxFieldSize;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxFieldSize(int paramInt) throws SQLException {
/* 3187 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 3190 */       if (paramInt < 0) {
/*      */         
/* 3192 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3193 */         sQLException.fillInStackTrace();
/* 3194 */         throw sQLException;
/*      */       } 
/*      */       
/* 3197 */       this.maxFieldSize = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getMaxRows() throws SQLException {
/* 3205 */     return this.maxRows;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMaxRows(int paramInt) throws SQLException {
/* 3211 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 3214 */       if (paramInt < 0) {
/*      */         
/* 3216 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3217 */         sQLException.fillInStackTrace();
/* 3218 */         throw sQLException;
/*      */       } 
/*      */       
/* 3221 */       this.maxRows = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setEscapeProcessing(boolean paramBoolean) throws SQLException {
/* 3229 */     synchronized (this.connection) {
/*      */       
/* 3231 */       this.processEscapes = paramBoolean;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getQueryTimeout() throws SQLException {
/* 3245 */     synchronized (this.connection) {
/*      */       
/* 3247 */       return this.queryTimeout;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setQueryTimeout(int paramInt) throws SQLException {
/* 3262 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 3265 */       if (paramInt < 0) {
/*      */         
/* 3267 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3268 */         sQLException.fillInStackTrace();
/* 3269 */         throw sQLException;
/*      */       } 
/*      */       
/* 3272 */       this.queryTimeout = paramInt;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancel() throws SQLException {
/* 3285 */     doCancel();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean doCancel() throws SQLException {
/* 3292 */     boolean bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3297 */     if (this.closed) {
/* 3298 */       return bool;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3310 */     if (this.connection.statementHoldingLine != null) {
/* 3311 */       freeLine();
/* 3312 */     } else if (this.cancelLock.enterCanceling()) {
/*      */       
/*      */       try {
/* 3315 */         bool = true;
/* 3316 */         this.connection.cancelOperationOnServer(true);
/*      */       } finally {
/*      */         
/* 3319 */         this.cancelLock.exitCanceling();
/*      */       } 
/*      */     } else {
/*      */       
/* 3323 */       return bool;
/*      */     } 
/* 3325 */     OracleStatement oracleStatement = this.children;
/* 3326 */     while (oracleStatement != null) {
/* 3327 */       bool = (bool || oracleStatement.doCancel()) ? true : false;
/* 3328 */       oracleStatement = oracleStatement.nextChild;
/*      */     } 
/*      */     
/* 3331 */     this.connection.releaseLineForCancel();
/* 3332 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SQLWarning getWarnings() throws SQLException {
/* 3349 */     return this.sqlWarning;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearWarnings() throws SQLException {
/* 3359 */     this.sqlWarning = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void foundPlsqlCompilerWarning() throws SQLException {
/* 3367 */     SQLWarning sQLWarning = DatabaseError.addSqlWarning(this.sqlWarning, "Found Plsql compiler warnings.", 24439);
/*      */     
/* 3369 */     if (this.sqlWarning != null) {
/*      */       
/* 3371 */       this.sqlWarning.setNextWarning(sQLWarning);
/*      */     }
/*      */     else {
/*      */       
/* 3375 */       this.sqlWarning = sQLWarning;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursorName(String paramString) throws SQLException {
/* 3387 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 3388 */     sQLException.fillInStackTrace();
/* 3389 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getResultSet() throws SQLException {
/* 3402 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 3405 */       if (this.userRsetType == 1) {
/*      */         
/* 3407 */         if (this.sqlKind.isSELECT())
/*      */         {
/* 3409 */           if (this.currentResultSet == null) {
/* 3410 */             this.currentResultSet = new OracleResultSetImpl(this.connection, this);
/*      */           }
/* 3412 */           return (ResultSet)this.currentResultSet;
/*      */         }
/*      */       
/*      */       } else {
/*      */         
/* 3417 */         return (ResultSet)this.scrollRset;
/*      */       } 
/*      */       
/* 3420 */       return null;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getUpdateCount() throws SQLException {
/* 3437 */     synchronized (this.connection) {
/*      */       
/* 3439 */       int i = -1;
/*      */       
/* 3441 */       switch (this.sqlKind) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case ALTER_SESSION:
/*      */         case OTHER:
/* 3452 */           if (!this.noMoreUpdateCounts) {
/* 3453 */             i = this.rowsProcessed;
/*      */           }
/* 3455 */           this.noMoreUpdateCounts = true;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case PLSQL_BLOCK:
/*      */         case CALL_BLOCK:
/* 3463 */           this.noMoreUpdateCounts = true;
/*      */           break;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case DELETE:
/*      */         case INSERT:
/*      */         case MERGE:
/*      */         case UPDATE:
/* 3473 */           if (!this.noMoreUpdateCounts) {
/* 3474 */             i = this.rowsProcessed;
/*      */           }
/* 3476 */           this.noMoreUpdateCounts = true;
/*      */           break;
/*      */       } 
/*      */ 
/*      */       
/* 3481 */       return i;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getMoreResults() throws SQLException {
/* 3493 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sendBatch() throws SQLException {
/* 3504 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prepareForNewResults(boolean paramBoolean1, boolean paramBoolean2) throws SQLException {
/* 3515 */     clearWarnings();
/*      */     
/* 3517 */     if (this.streamList != null) {
/*      */ 
/*      */ 
/*      */       
/* 3521 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 3525 */           this.nextStream.close();
/*      */         }
/* 3527 */         catch (IOException iOException) {
/*      */ 
/*      */           
/* 3530 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3531 */           sQLException.fillInStackTrace();
/* 3532 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 3536 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */       
/* 3539 */       if (paramBoolean2) {
/*      */ 
/*      */         
/* 3542 */         OracleInputStream oracleInputStream1 = this.streamList;
/* 3543 */         OracleInputStream oracleInputStream2 = null;
/*      */         
/* 3545 */         this.streamList = null;
/*      */         
/* 3547 */         while (oracleInputStream1 != null) {
/*      */           
/* 3549 */           if (!oracleInputStream1.hasBeenOpen) {
/*      */             
/* 3551 */             if (oracleInputStream2 == null) {
/* 3552 */               this.streamList = oracleInputStream1;
/*      */             } else {
/* 3554 */               oracleInputStream2.nextStream = oracleInputStream1;
/*      */             } 
/* 3556 */             oracleInputStream2 = oracleInputStream1;
/*      */           } 
/*      */           
/* 3559 */           oracleInputStream1 = oracleInputStream1.nextStream;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 3564 */     if (this.currentResultSet != null) {
/*      */       
/* 3566 */       this.currentResultSet.internal_close(true);
/*      */       
/* 3568 */       this.currentResultSet = null;
/*      */     } 
/*      */     
/* 3571 */     this.currentRow = -1;
/* 3572 */     this.checkSum = 0L;
/* 3573 */     this.checkSumComputationFailure = false;
/* 3574 */     this.validRows = 0;
/* 3575 */     if (paramBoolean1)
/* 3576 */       this.totalRowsVisited = 0; 
/* 3577 */     this.gotLastBatch = false;
/*      */     
/* 3579 */     if (this.needToParse && !this.columnsDefinedByUser) {
/*      */       
/* 3581 */       if (paramBoolean2 && this.numberOfDefinePositions != 0) {
/* 3582 */         this.numberOfDefinePositions = 0;
/*      */       }
/* 3584 */       this.needToPrepareDefineBuffer = true;
/*      */     } 
/*      */ 
/*      */     
/* 3588 */     if (paramBoolean1 && this.rowPrefetch != this.defaultRowPrefetch && this.streamList == null) {
/*      */ 
/*      */ 
/*      */       
/* 3592 */       this.rowPrefetch = this.defaultRowPrefetch;
/* 3593 */       this.rowPrefetchChanged = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void reopenStreams() throws SQLException {
/* 3607 */     OracleInputStream oracleInputStream = this.streamList;
/*      */     
/* 3609 */     while (oracleInputStream != null) {
/*      */       
/* 3611 */       if (oracleInputStream.hasBeenOpen) {
/* 3612 */         oracleInputStream = oracleInputStream.accessor.initForNewRow();
/*      */       }
/* 3614 */       oracleInputStream.closed = false;
/* 3615 */       oracleInputStream.hasBeenOpen = true;
/* 3616 */       oracleInputStream = oracleInputStream.nextStream;
/*      */     } 
/*      */     
/* 3619 */     this.nextStream = this.streamList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void endOfResultSet(boolean paramBoolean) throws SQLException {
/* 3631 */     if (!paramBoolean)
/*      */     {
/*      */       
/* 3634 */       prepareForNewResults(false, false);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3639 */     clearDefines();
/* 3640 */     this.rowPrefetchInLastFetch = -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean wasNullValue() throws SQLException {
/* 3665 */     if (this.lastIndex == 0) {
/*      */       
/* 3667 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24);
/* 3668 */       sQLException.fillInStackTrace();
/* 3669 */       throw sQLException;
/*      */     } 
/*      */     
/* 3672 */     if (this.sqlKind.isSELECT()) {
/* 3673 */       return this.accessors[this.lastIndex - 1].isNull(this.currentRow);
/*      */     }
/* 3675 */     return this.outBindAccessors[this.lastIndex - 1].isNull(this.currentRank);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getColumnIndex(String paramString) throws SQLException {
/* 3689 */     ensureOpen();
/* 3690 */     if (!this.describedWithNames)
/*      */     {
/* 3692 */       synchronized (this.connection) {
/* 3693 */         doDescribe(true);
/*      */         
/* 3695 */         this.described = true;
/* 3696 */         this.describedWithNames = true;
/*      */       } 
/*      */     }
/*      */     
/* 3700 */     for (byte b = 0; b < this.numberOfDefinePositions; b++) {
/* 3701 */       if ((this.accessors[b]).columnName.equalsIgnoreCase(paramString)) {
/* 3702 */         return b + 1;
/*      */       }
/*      */     } 
/* 3705 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 6);
/* 3706 */     sQLException.fillInStackTrace();
/* 3707 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getJDBCType(int paramInt) throws SQLException {
/* 3715 */     int i = 0;
/* 3716 */     switch (paramInt)
/*      */     
/*      */     { case 6:
/* 3719 */         i = 2;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3794 */         return i;case 100: i = 100; return i;case 101: i = 101; return i;case 999: i = 999; return i;case 96: i = 1; return i;case 1: i = 12; return i;case 8: i = -1; return i;case 12: i = 91; return i;case 180: i = 93; return i;case 181: i = -101; return i;case 231: i = -102; return i;case 182: i = -103; return i;case 183: i = -104; return i;case 23: i = -2; return i;case 24: i = -4; return i;case 104: i = -8; return i;case 113: i = 2004; return i;case 112: i = 2005; return i;case 114: i = -13; return i;case 102: i = -10; return i;case 109: i = 2002; return i;case 111: i = 2006; return i;case 998: i = -14; return i;case 995: i = 0; return i; }  i = paramInt; return i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getInternalType(int paramInt) throws SQLException {
/* 3801 */     char c = Character.MIN_VALUE;
/*      */     
/* 3803 */     switch (paramInt) {
/*      */       
/*      */       case -7:
/*      */       case -6:
/*      */       case -5:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/* 3815 */         c = '\006';
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 3941 */         return c;case 100: c = 'd'; return c;case 101: c = 'e'; return c;case 999: c = 'ϧ'; return c;case 1: c = '`'; return c;case 12: c = '\001'; return c;case -1: c = '\b'; return c;case 91: case 92: c = '\f'; return c;case -100: case 93: c = '´'; return c;case -101: c = 'µ'; return c;case -102: c = 'ç'; return c;case -103: c = '¶'; return c;case -104: c = '·'; return c;case -3: case -2: c = '\027'; return c;case -4: c = '\030'; return c;case -8: c = 'h'; return c;case 2004: c = 'q'; return c;case 2005: c = 'p'; return c;case -13: c = 'r'; return c;case -10: c = 'f'; return c;case 2002: case 2003: case 2007: case 2008: c = 'm'; return c;case 2006: c = 'o'; return c;case -14: c = 'Ϧ'; return c;case 70: c = '\001'; return c;case 0: c = 'ϣ'; return c;
/*      */     } 
/*      */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, Integer.toString(paramInt));
/*      */     sQLException.fillInStackTrace();
/*      */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void describe() throws SQLException {
/* 3959 */     synchronized (this.connection) {
/*      */       
/* 3961 */       ensureOpen();
/* 3962 */       if (!this.described)
/*      */       {
/* 3964 */         doDescribe(false);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void freeLine() throws SQLException {
/* 3973 */     if (this.streamList != null)
/*      */     {
/*      */ 
/*      */       
/* 3977 */       while (this.nextStream != null) {
/*      */ 
/*      */         
/*      */         try {
/* 3981 */           this.nextStream.close();
/*      */         }
/* 3983 */         catch (IOException iOException) {
/*      */ 
/*      */           
/* 3986 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3987 */           sQLException.fillInStackTrace();
/* 3988 */           throw sQLException;
/*      */         } 
/*      */ 
/*      */         
/* 3992 */         this.nextStream = this.nextStream.nextStream;
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void closeUsedStreams(int paramInt) throws SQLException {
/* 4005 */     while (this.nextStream != null && this.nextStream.columnIndex < paramInt) {
/*      */ 
/*      */       
/*      */       try {
/*      */ 
/*      */         
/* 4011 */         this.nextStream.close();
/*      */       }
/* 4013 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 4016 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4017 */         sQLException.fillInStackTrace();
/* 4018 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 4022 */       this.nextStream = this.nextStream.nextStream;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void ensureOpen() throws SQLException {
/* 4034 */     if (this.connection.lifecycle != 1) {
/*      */       
/* 4036 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 4037 */       sQLException.fillInStackTrace();
/* 4038 */       throw sQLException;
/*      */     } 
/* 4040 */     if (this.closed) {
/*      */       
/* 4042 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9);
/* 4043 */       sQLException.fillInStackTrace();
/* 4044 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void allocateTmpByteArray() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {
/* 4078 */     synchronized (this.connection) {
/*      */       
/* 4080 */       if (paramInt == 1000) {
/*      */ 
/*      */         
/* 4083 */         this.defaultFetchDirection = paramInt;
/*      */       }
/* 4085 */       else if (paramInt == 1001 || paramInt == 1002) {
/*      */ 
/*      */         
/* 4088 */         this.defaultFetchDirection = 1000;
/* 4089 */         this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 87);
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */         
/* 4095 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
/* 4096 */         sQLException.fillInStackTrace();
/* 4097 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/* 4120 */     return this.defaultFetchDirection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 4139 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 4142 */       setPrefetchInternal(paramInt, false, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 4165 */     return getPrefetchInternal(true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetConcurrency() throws SQLException {
/* 4177 */     return ResultSetUtil.getUpdateConcurrency(this.userRsetType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getResultSetType() throws SQLException {
/* 4189 */     return ResultSetUtil.getScrollType(this.userRsetType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getConnection() throws SQLException {
/* 4204 */     return (Connection)this.connection.getWrapper();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResultSetCache(OracleResultSetCache paramOracleResultSetCache) throws SQLException {
/* 4217 */     synchronized (this.connection) {
/*      */ 
/*      */       
/*      */       try {
/* 4221 */         if (paramOracleResultSetCache == null) {
/*      */           
/* 4223 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4224 */           sQLException.fillInStackTrace();
/* 4225 */           throw sQLException;
/*      */         } 
/*      */         
/* 4228 */         if (this.rsetCache != null) {
/* 4229 */           this.rsetCache.close();
/*      */         }
/* 4231 */         this.rsetCache = paramOracleResultSetCache;
/*      */       }
/* 4233 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 4236 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4237 */         sQLException.fillInStackTrace();
/* 4238 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setResultSetCache(OracleResultSetCache paramOracleResultSetCache) throws SQLException {
/* 4255 */     synchronized (this.connection) {
/*      */       
/* 4257 */       setResultSetCache((OracleResultSetCache)paramOracleResultSetCache);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleResultSetCache getResultSetCache() throws SQLException {
/* 4268 */     synchronized (this.connection) {
/*      */       
/* 4270 */       return (OracleResultSetCache)this.rsetCache;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isOracleBatchStyle() {
/* 4279 */     return false;
/*      */   }
/*      */   void initBatch() {}
/*      */   int getBatchSize() { if (this.m_batchItems == null) return 0;  return this.m_batchItems.size(); }
/*      */   void addBatchItem(String paramString) { if (this.m_batchItems == null) this.m_batchItems = new Vector();  this.m_batchItems.addElement(paramString); }
/*      */   String getBatchItem(int paramInt) { return this.m_batchItems.elementAt(paramInt); }
/*      */   void clearBatchItems() { this.m_batchItems.removeAllElements(); }
/*      */   void checkIfJdbcBatchExists() throws SQLException { if (getBatchSize() > 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 81, "batch must be either executed or cleared"); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   public void addBatch(String paramString) throws SQLException { synchronized (this.connection) { addBatchItem(paramString); }  }
/*      */   public void clearBatch() throws SQLException { synchronized (this.connection) { clearBatchItems(); }  }
/*      */   public int[] executeBatch() throws SQLException { synchronized (this.connection) { cleanOldTempLobs(); byte b = 0; int i = getBatchSize(); this.checkSum = 0L; this.checkSumComputationFailure = false; if (i <= 0) return new int[0];  int[] arrayOfInt = new int[i]; ensureOpen(); prepareForNewResults(true, true); int j = this.numberOfDefinePositions; String str = this.sqlObject.getOriginalSql(); OracleStatement.SqlKind sqlKind = this.sqlKind; this.noMoreUpdateCounts = false; int k = 0; try { this.connection.registerHeartbeat(); this.connection.needLine(); for (b = 0; b < i; b++) { this.sqlObject.initialize(getBatchItem(b)); this.sqlKind = this.sqlObject.getSqlKind(); this.needToParse = true; this.numberOfDefinePositions = 0; this.rowsProcessed = 0; this.currentRank = 1; if (this.sqlKind.isSELECT()) { BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(80, "invalid SELECT batch command " + b, b, arrayOfInt); batchUpdateException.fillInStackTrace(); throw batchUpdateException; }  if (!this.isOpen) { this.connection.open(this); this.isOpen = true; }  int m = -1; try { if (this.queryTimeout != 0) this.connection.getTimeout().setTimeout((this.queryTimeout * 1000), this);  this.cancelLock.enterExecuting(); executeForRows(false); if (this.validRows > 0) k += this.validRows;  m = this.validRows; } catch (SQLException sQLException) { this.needToParse = true; resetCurrentRowBinders(); throw sQLException; } finally { if (this.queryTimeout != 0) this.connection.getTimeout().cancelTimeout();  this.validRows = k; this.cancelLock.exitExecuting(); checkValidRowsStatus(); }  arrayOfInt[b] = m; if (arrayOfInt[b] < 0) { BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(81, "command return value " + arrayOfInt[b], b, arrayOfInt); batchUpdateException.fillInStackTrace(); throw batchUpdateException; }  }  } catch (SQLException sQLException) { if (sQLException instanceof BatchUpdateException) throw sQLException;  BatchUpdateException batchUpdateException = DatabaseError.createBatchUpdateException(81, sQLException.getMessage(), b, arrayOfInt); batchUpdateException.fillInStackTrace(); throw batchUpdateException; } finally { clearBatchItems(); this.numberOfDefinePositions = j; if (str != null) { this.sqlObject.initialize(str); this.sqlKind = sqlKind; }  this.currentRank = 0; }  this.connection.registerHeartbeat(); return arrayOfInt; }  }
/*      */   public int copyBinds(Statement paramStatement, int paramInt) throws SQLException { return 0; }
/*      */   public void notifyCloseRset() throws SQLException { this.scrollRset = null; endOfResultSet(false); }
/*      */   public String getOriginalSql() throws SQLException { return this.sqlObject.getOriginalSql(); }
/*      */   void doScrollExecuteCommon() throws SQLException { if (this.scrollRset != null) { this.scrollRset.close(); this.scrollRset = null; }  if (!this.sqlKind.isSELECT()) { doExecuteWithTimeout(); return; }  if (!this.needToAddIdentifier) { doExecuteWithTimeout(); this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.realRsetType = this.userRsetType; } else { try { this.sqlObject.setIncludeRowid(true); this.needToParse = true; prepareForNewResults(true, false); if (this.columnsDefinedByUser) { Accessor[] arrayOfAccessor = this.accessors; if (this.accessors == null || this.accessors.length <= this.numberOfDefinePositions) this.accessors = new Accessor[this.numberOfDefinePositions + 1];  if (arrayOfAccessor != null) for (int i = this.numberOfDefinePositions; i > 0; i--) { Accessor accessor = arrayOfAccessor[i - 1]; this.accessors[i] = accessor; if (accessor.isColumnNumberAware) accessor.updateColumnNumber(i);  }   allocateRowidAccessor(); this.numberOfDefinePositions++; }  doExecuteWithTimeout(); this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.realRsetType = this.userRsetType; } catch (SQLException sQLException) { if (this.userRsetType > 3) { this.realRsetType = 3; } else { this.realRsetType = 1; }  this.sqlObject.setIncludeRowid(false); this.needToParse = true; prepareForNewResults(true, false); if (this.columnsDefinedByUser) { this.needToPrepareDefineBuffer = true; this.numberOfDefinePositions--; System.arraycopy(this.accessors, 1, this.accessors, 0, this.numberOfDefinePositions); this.accessors[this.numberOfDefinePositions] = null; for (byte b = 0; b < this.numberOfDefinePositions; b++) { Accessor accessor = this.accessors[b]; if (accessor.isColumnNumberAware) accessor.updateColumnNumber(b);  }  }  moveAllTempLobsToFree(); doExecuteWithTimeout(); this.currentResultSet = new OracleResultSetImpl(this.connection, this); this.sqlWarning = DatabaseError.addSqlWarning(this.sqlWarning, 91, sQLException.getMessage()); }  }  this.scrollRset = ResultSetUtil.createScrollResultSet(this, this.currentResultSet, this.realRsetType); }
/*      */   void allocateRowidAccessor() throws SQLException { this.accessors[0] = new RowidAccessor(this, 128, (short)1, -8, false); }
/*      */   OracleResultSet doScrollStmtExecuteQuery() throws SQLException { doScrollExecuteCommon(); return this.scrollRset; }
/*      */   void processDmlReturningBind() throws SQLException { if (this.returnResultSet != null) this.returnResultSet.close();  this.returnParamsFetched = false; this.returnParamRowBytes = 0; this.returnParamRowChars = 0; byte b1 = 0; for (byte b2 = 0; b2 < this.numberOfBindPositions; b2++) { Accessor accessor = this.returnParamAccessors[b2]; if (accessor != null) { b1++; if (accessor.charLength > 0) { this.returnParamRowChars += accessor.charLength; } else { this.returnParamRowBytes += accessor.byteLength; }  }  }  if (this.isAutoGeneratedKey) { this.numReturnParams = b1; } else { if (this.numReturnParams <= 0) this.numReturnParams = this.sqlObject.getReturnParameterCount();  if (this.numReturnParams != b1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 173); sQLException.fillInStackTrace(); throw sQLException; }  }  this.returnParamMeta[0] = this.numReturnParams; this.returnParamMeta[1] = this.returnParamRowBytes; this.returnParamMeta[2] = this.returnParamRowChars; }
/*      */   void allocateDmlReturnStorage() { if (this.rowsDmlReturned == 0) return;  int i = this.returnParamRowBytes * this.rowsDmlReturned; int j = this.returnParamRowChars * this.rowsDmlReturned; int k = 2 * this.numReturnParams * this.rowsDmlReturned; this.returnParamBytes = new byte[i]; this.returnParamChars = new char[j]; this.returnParamIndicators = new short[k]; for (byte b = 0; b < this.numberOfBindPositions; b++) { Accessor accessor = this.returnParamAccessors[b]; if (accessor != null && (accessor.internalType == 111 || accessor.internalType == 109)) { TypeAccessor typeAccessor = (TypeAccessor)accessor; if (typeAccessor.pickledBytes == null || typeAccessor.pickledBytes.length < this.rowsDmlReturned) typeAccessor.pickledBytes = new byte[this.rowsDmlReturned][];  }  }  }
/*      */   void fetchDmlReturnParams() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*      */   void setupReturnParamAccessors() { if (this.rowsDmlReturned == 0) return;  int i = 0; int j = 0; int k = 0; int m = this.numReturnParams * this.rowsDmlReturned; for (byte b = 0; b < this.numberOfBindPositions; b++) { Accessor accessor = this.returnParamAccessors[b]; if (accessor != null) { if (accessor.charLength > 0) { accessor.rowSpaceChar = this.returnParamChars; accessor.columnIndex = j; j += this.rowsDmlReturned * accessor.charLength; } else { accessor.rowSpaceByte = this.returnParamBytes; accessor.columnIndex = i; i += this.rowsDmlReturned * accessor.byteLength; }  accessor.rowSpaceIndicator = this.returnParamIndicators; accessor.indicatorIndex = k; k += this.rowsDmlReturned; accessor.lengthIndex = m; m += this.rowsDmlReturned; }  }  }
/*      */   void registerReturnParameterInternal(int paramInt1, int paramInt2, int paramInt3, int paramInt4, short paramShort, String paramString) throws SQLException { if (this.returnParamAccessors == null) this.returnParamAccessors = new Accessor[this.numberOfBindPositions];  if (this.returnParamMeta == null) this.returnParamMeta = new int[3 + this.numberOfBindPositions * 4];  Accessor accessor = allocateAccessor(paramInt2, paramInt3, paramInt1 + 1, paramInt4, paramShort, paramString, true); accessor.isDMLReturnedParam = true; this.returnParamAccessors[paramInt1] = accessor; boolean bool = (accessor.charLength > 0) ? true : false; this.returnParamMeta[3 + paramInt1 * 4 + 0] = accessor.defineType; this.returnParamMeta[3 + paramInt1 * 4 + 1] = bool ? 1 : 0; this.returnParamMeta[3 + paramInt1 * 4 + 2] = bool ? accessor.charLength : accessor.byteLength; this.returnParamMeta[3 + paramInt1 * 4 + 3] = paramShort; }
/*      */   public int creationState() { synchronized (this.connection) { return this.creationState; }  }
/*      */   public boolean isColumnSetNull(int paramInt) { return this.columnSetNull; } public boolean isNCHAR(int paramInt) throws SQLException { if (!this.described)
/* 4303 */       describe();  int i = paramInt - 1; if (i < 0 || i >= this.numberOfDefinePositions) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3); sQLException.fillInStackTrace(); throw sQLException; }  return ((this.accessors[i]).formOfUse == 2); } void addChild(OracleStatement paramOracleStatement) { paramOracleStatement.nextChild = this.children; this.children = paramOracleStatement; paramOracleStatement.parent = this; } OracleStatement(PhysicalConnection paramPhysicalConnection, int paramInt1, int paramInt2, int paramInt3, int paramInt4) throws SQLException { this.m_batchItems = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 5798 */     this.tempClobsToFree = null;
/* 5799 */     this.tempBlobsToFree = null;
/*      */     
/* 5801 */     this.oldTempClobsToFree = null;
/* 5802 */     this.oldTempBlobsToFree = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6003 */     this.registration = null;
/* 6004 */     this.dcnTableName = null;
/* 6005 */     this.dcnQueryId = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 6136 */     this._checkSum = 0L; this.connection = paramPhysicalConnection; this.connection.needLine(); this.connection.registerHeartbeat(); this.connection.addStatement(this); this.sqlObject = new OracleSql(this.connection.conversion); this.processEscapes = this.connection.processEscapes; this.convertNcharLiterals = this.connection.convertNcharLiterals; this.autoRollback = 2; this.gotLastBatch = false; this.closed = false; this.clearParameters = true; this.serverCursor = false; this.needToAddIdentifier = false; this.defaultFetchDirection = 1000; this.fixedString = this.connection.getDefaultFixedString(); this.rowPrefetchChanged = false; this.rowPrefetch = paramInt2; this.defaultRowPrefetch = paramInt2; if (this.connection.getVersionNumber() >= 11000) { this.defaultLobPrefetchSize = this.connection.defaultLobPrefetchSize; } else { this.defaultLobPrefetchSize = -1; }  this.batch = paramInt1; this.sqlStringChanged = true; this.needToParse = true; this.needToPrepareDefineBuffer = true; this.columnsDefinedByUser = false; if (paramInt3 != -1 || paramInt4 != -1) { this.realRsetType = 0; this.userRsetType = ResultSetUtil.getRsetTypeCode(paramInt3, paramInt4); this.needToAddIdentifier = ResultSetUtil.needIdentifier(this.userRsetType); } else { this.userRsetType = 1; this.realRsetType = 1; }  }
/*      */   void removeChild(OracleStatement paramOracleStatement) { if (paramOracleStatement == this.children) { this.children = paramOracleStatement.nextChild; } else { OracleStatement oracleStatement = this.children; while (oracleStatement.nextChild != paramOracleStatement) oracleStatement = oracleStatement.nextChild;  oracleStatement.nextChild = paramOracleStatement.nextChild; }  paramOracleStatement.parent = null; paramOracleStatement.nextChild = null; }
/*      */   public boolean getMoreResults(int paramInt) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/* 6139 */   public ResultSet getGeneratedKeys() throws SQLException { if (this.closed) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9); sQLException.fillInStackTrace(); throw sQLException; }  if (!this.isAutoGeneratedKey) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 90); sQLException.fillInStackTrace(); throw sQLException; }  if (this.returnParamAccessors == null || this.numReturnParams == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 144); sQLException.fillInStackTrace(); throw sQLException; }  if (this.returnResultSet == null) this.returnResultSet = new OracleReturnResultSet(this);  return (ResultSet)this.returnResultSet; } public int executeUpdate(String paramString, int paramInt) throws SQLException { this.autoKeyInfo = new AutoKeyInfo(paramString); if (paramInt == 2 || !this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return executeUpdate(paramString); }  if (paramInt != 1) { this.autoKeyInfo = null; SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { this.isAutoGeneratedKey = true; String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = 1; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeUpdateInternal(str); }  } public int executeUpdate(String paramString, int[] paramArrayOfint) throws SQLException { if (paramArrayOfint == null || paramArrayOfint.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfint); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return executeUpdate(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfint.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeUpdateInternal(str); }  } public int executeUpdate(String paramString, String[] paramArrayOfString) throws SQLException { if (paramArrayOfString == null || paramArrayOfString.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return executeUpdate(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfString.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeUpdateInternal(str); }  } public boolean execute(String paramString, int paramInt) throws SQLException { this.autoKeyInfo = new AutoKeyInfo(paramString); if (paramInt == 2 || !this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return execute(paramString); }  if (paramInt != 1) { this.autoKeyInfo = null; SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  synchronized (this.connection) { this.isAutoGeneratedKey = true; String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = 1; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeInternal(str); }  } public boolean execute(String paramString, int[] paramArrayOfint) throws SQLException { if (paramArrayOfint == null || paramArrayOfint.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfint); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return execute(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfint.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeInternal(str); }  } void calculateCheckSum() throws SQLException { if (!this.connection.calculateChecksum) {
/*      */       return;
/*      */     }
/* 6142 */     this._checkSum = this.checkSum;
/* 6143 */     if (this.accessors != null) {
/* 6144 */       accessorChecksum(this.accessors);
/*      */     }
/* 6146 */     if (this.outBindAccessors != null) {
/* 6147 */       accessorChecksum(this.outBindAccessors);
/*      */     }
/* 6149 */     if (this.returnParamAccessors != null && this.returnParamsFetched) {
/* 6150 */       accessorChecksum(this.returnParamAccessors);
/*      */     }
/* 6152 */     this._checkSum = CRC64.updateChecksum(this._checkSum, this.validRows);
/* 6153 */     this.checkSum = this._checkSum;
/* 6154 */     this._checkSum = 0L; } public boolean execute(String paramString, String[] paramArrayOfString) throws SQLException { if (paramArrayOfString == null || paramArrayOfString.length == 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString); if (!this.autoKeyInfo.isInsertSqlStmt()) { this.autoKeyInfo = null; return execute(paramString); }  synchronized (this.connection) { this.isAutoGeneratedKey = true; this.connection.doDescribeTable(this.autoKeyInfo); String str = this.autoKeyInfo.getNewSql(); this.numberOfBindPositions = paramArrayOfString.length; autoKeyRegisterReturnParams(); processDmlReturningBind(); return executeInternal(str); }  } public int getResultSetHoldability() throws SQLException { return 1; } public int getcacheState() { return this.cacheState; } public int getstatementType() { return this.statementType; } public boolean getserverCursor() { return this.serverCursor; } void initializeIndicatorSubRange() { this.bindIndicatorSubRange = 0; } private void autoKeyRegisterReturnParams() throws SQLException { initializeIndicatorSubRange(); int i = this.bindIndicatorSubRange + 5 + this.numberOfBindPositions * 10; int j = i + 2 * this.numberOfBindPositions; this.bindIndicators = new short[j]; int k = this.bindIndicatorSubRange; this.bindIndicators[k + 0] = (short)this.numberOfBindPositions; this.bindIndicators[k + 1] = 0; this.bindIndicators[k + 2] = 1; this.bindIndicators[k + 3] = 0; this.bindIndicators[k + 4] = 1; k += 5; short[] arrayOfShort = this.autoKeyInfo.tableFormOfUses; int[] arrayOfInt = this.autoKeyInfo.columnIndexes; for (byte b = 0; b < this.numberOfBindPositions; b++) { this.bindIndicators[k + 0] = 994; byte b1 = this.connection.defaultnchar ? 2 : 1; if (arrayOfShort != null && arrayOfInt != null) if (arrayOfShort[arrayOfInt[b] - 1] == 2) { b1 = 2; this.bindIndicators[k + 9] = b1; }   k += 10; checkTypeForAutoKey(this.autoKeyInfo.returnTypes[b]); String str = null; if (this.autoKeyInfo.returnTypes[b] == 111) str = this.autoKeyInfo.tableTypeNames[arrayOfInt[b] - 1];  registerReturnParameterInternal(b, this.autoKeyInfo.returnTypes[b], this.autoKeyInfo.returnTypes[b], -1, b1, str); }  } private final void setNonAutoKey() { this.isAutoGeneratedKey = false; this.numberOfBindPositions = 0; this.bindIndicators = null; this.returnParamMeta = null; } void saveDefineBuffersIfRequired(char[] paramArrayOfchar, byte[] paramArrayOfbyte, short[] paramArrayOfshort, boolean paramBoolean) throws SQLException { if (paramArrayOfchar != this.defineChars) this.connection.cacheBuffer(paramArrayOfchar);  if (paramArrayOfbyte != this.defineBytes) this.connection.cacheBuffer(paramArrayOfbyte);  } final void checkTypeForAutoKey(int paramInt) throws SQLException { if (paramInt == 109) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 5); sQLException.fillInStackTrace(); throw sQLException; }  } void moveAllTempLobsToFree() { if (this.oldTempClobsToFree != null) { if (this.tempClobsToFree == null) { this.tempClobsToFree = this.oldTempClobsToFree; } else { this.tempClobsToFree.add(this.oldTempClobsToFree); }  this.oldTempClobsToFree = null; }  if (this.oldTempBlobsToFree != null) { if (this.tempBlobsToFree == null) { this.tempBlobsToFree = this.oldTempBlobsToFree; } else { this.tempBlobsToFree.add(this.oldTempBlobsToFree); }  this.oldTempBlobsToFree = null; }  } void moveTempLobsToFree(CLOB paramCLOB) { int i; if (this.oldTempClobsToFree != null && (i = this.oldTempClobsToFree.indexOf(paramCLOB)) != -1) { addToTempLobsToFree(paramCLOB); this.oldTempClobsToFree.remove(i); }  } void moveTempLobsToFree(BLOB paramBLOB) { int i; if (this.oldTempBlobsToFree != null && (i = this.oldTempBlobsToFree.indexOf(paramBLOB)) != -1) { addToTempLobsToFree(paramBLOB); this.oldTempBlobsToFree.remove(i); }  } void addToTempLobsToFree(CLOB paramCLOB) { if (this.tempClobsToFree == null) this.tempClobsToFree = new ArrayList();  this.tempClobsToFree.add(paramCLOB); } void addToTempLobsToFree(BLOB paramBLOB) { if (this.tempBlobsToFree == null) this.tempBlobsToFree = new ArrayList();  this.tempBlobsToFree.add(paramBLOB); } void addToOldTempLobsToFree(CLOB paramCLOB) { if (this.oldTempClobsToFree == null) this.oldTempClobsToFree = new ArrayList();  this.oldTempClobsToFree.add(paramCLOB); } void addToOldTempLobsToFree(BLOB paramBLOB) { if (this.oldTempBlobsToFree == null) this.oldTempBlobsToFree = new ArrayList();  this.oldTempBlobsToFree.add(paramBLOB); } void cleanAllTempLobs() { cleanTempClobs(this.tempClobsToFree); this.tempClobsToFree = null; cleanTempBlobs(this.tempBlobsToFree); this.tempBlobsToFree = null; cleanTempClobs(this.oldTempClobsToFree); this.oldTempClobsToFree = null; cleanTempBlobs(this.oldTempBlobsToFree); this.oldTempBlobsToFree = null; } void cleanOldTempLobs() { cleanTempClobs(this.oldTempClobsToFree); cleanTempBlobs(this.oldTempBlobsToFree); this.oldTempClobsToFree = this.tempClobsToFree; this.tempClobsToFree = null; this.oldTempBlobsToFree = this.tempBlobsToFree; this.tempBlobsToFree = null; } void cleanTempClobs(ArrayList paramArrayList) { if (paramArrayList != null) { Iterator<CLOB> iterator = paramArrayList.iterator(); while (iterator.hasNext()) { try { ((CLOB)iterator.next()).freeTemporary(); } catch (SQLException sQLException) {} }  }  } void cleanTempBlobs(ArrayList paramArrayList) { if (paramArrayList != null) { Iterator<BLOB> iterator = paramArrayList.iterator(); while (iterator.hasNext()) { try { ((BLOB)iterator.next()).freeTemporary(); } catch (SQLException sQLException) {} }  }  } TimeZone getDefaultTimeZone() throws SQLException { return getDefaultTimeZone(false); } TimeZone getDefaultTimeZone(boolean paramBoolean) throws SQLException { if (this.defaultTimeZone == null) { try { this.defaultTimeZone = this.connection.getDefaultTimeZone(); } catch (SQLException sQLException) {} if (this.defaultTimeZone == null) this.defaultTimeZone = TimeZone.getDefault();  }  return this.defaultTimeZone; } public void setDatabaseChangeRegistration(DatabaseChangeRegistration paramDatabaseChangeRegistration) throws SQLException { this.registration = (NTFDCNRegistration)paramDatabaseChangeRegistration; } public String[] getRegisteredTableNames() throws SQLException { return this.dcnTableName; } public long getRegisteredQueryId() throws SQLException { return this.dcnQueryId; } Calendar getDefaultCalendar() throws SQLException { if (this.defaultCalendar == null) this.defaultCalendar = Calendar.getInstance(getDefaultTimeZone(), Locale.US);  return this.defaultCalendar; } void releaseBuffers() { this.cachedDefineIndicatorSize = (this.defineIndicators != null) ? this.defineIndicators.length : 0; this.cachedDefineMetaDataSize = (this.defineMetaData != null) ? this.defineMetaData.length : 0; this.connection.cacheBuffer(this.defineChars); this.defineChars = null; this.connection.cacheBuffer(this.defineBytes); this.defineBytes = null; this.defineIndicators = null; this.defineMetaData = null; } protected OracleConnection getConnectionDuringExceptionHandling() { return this.connection; }
/*      */   Calendar getGMTCalendar() { if (this.gmtCalendar == null) this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.US);  return this.gmtCalendar; }
/*      */   void extractNioDefineBuffers(int paramInt) throws SQLException {}
/*      */   void processLobPrefetchMetaData(Object[] paramArrayOfObject) {}
/*      */   void internalClose() throws SQLException { this.closed = true; if (this.currentResultSet != null) this.currentResultSet.closed = true;  cleanupDefines(); this.bindBytes = null; this.bindChars = null; this.bindIndicators = null; this.outBindAccessors = null; this.parameterStream = (InputStream[][])null; this.userStream = (Object[][])null; this.ibtBindBytes = null; this.ibtBindChars = null; this.ibtBindIndicators = null; this.lobPrefetchMetaData = null; this.tmpByteArray = null; this.definedColumnType = null; this.definedColumnSize = null; this.definedColumnFormOfUse = null; if (this.wrapper != null) this.wrapper.close();  }
/* 6159 */   void accessorChecksum(Accessor[] paramArrayOfAccessor) throws SQLException { byte b = 0;
/* 6160 */     boolean bool = false;
/*      */ 
/*      */     
/* 6163 */     for (Accessor accessor : paramArrayOfAccessor) {
/*      */       
/* 6165 */       if (accessor != null) {
/*      */         byte b1;
/* 6167 */         switch (accessor.internalType) {
/*      */           
/*      */           case 112:
/*      */           case 113:
/*      */           case 114:
/* 6172 */             if (!b) {
/* 6173 */               bool = true;
/*      */             }
/*      */             break;
/*      */ 
/*      */           
/*      */           case 8:
/*      */           case 24:
/* 6180 */             bool = false;
/*      */             break;
/*      */ 
/*      */           
/*      */           default:
/* 6185 */             bool = false;
/*      */ 
/*      */ 
/*      */             
/* 6189 */             b++;
/* 6190 */             for (b1 = 0; b1 < this.validRows; b1++) {
/*      */               
/* 6192 */               if (accessor.rowSpaceIndicator != null)
/* 6193 */                 this._checkSum = accessor.updateChecksum(this._checkSum, b1); 
/*      */             }  break;
/*      */         } 
/*      */       } 
/*      */     } 
/* 6198 */     if (bool) {
/* 6199 */       this.checkSumComputationFailure = true;
/*      */     } }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getChecksum() throws SQLException {
/* 6207 */     if (this.checkSumComputationFailure) {
/*      */       
/* 6209 */       SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 6210 */       sQLException.fillInStackTrace();
/* 6211 */       throw sQLException;
/*      */     } 
/*      */     
/* 6214 */     return this.checkSum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte convertSqlKindEnumToByte(OracleStatement.SqlKind paramSqlKind) {
/* 6231 */     switch (paramSqlKind) {
/*      */       
/*      */       case DELETE:
/* 6234 */         return 2;
/*      */       
/*      */       case INSERT:
/* 6237 */         return 4;
/*      */       
/*      */       case MERGE:
/* 6240 */         return 8;
/*      */       
/*      */       case UPDATE:
/* 6243 */         return 16;
/*      */       
/*      */       case ALTER_SESSION:
/*      */       case OTHER:
/* 6247 */         return Byte.MIN_VALUE;
/*      */       
/*      */       case PLSQL_BLOCK:
/* 6250 */         return 32;
/*      */       
/*      */       case CALL_BLOCK:
/* 6253 */         return 64;
/*      */       
/*      */       case SELECT_FOR_UPDATE:
/*      */       case SELECT:
/* 6257 */         return 1;
/*      */     } 
/*      */     
/* 6260 */     if (paramSqlKind.isPlsqlOrCall())
/* 6261 */       return 96; 
/* 6262 */     if (paramSqlKind.isDML()) {
/* 6263 */       return 30;
/*      */     }
/* 6265 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   static final OracleStatement.SqlKind convertSqlKindByteToEnum(byte paramByte) {
/* 6270 */     switch (paramByte) {
/*      */       
/*      */       case 2:
/* 6273 */         return OracleStatement.SqlKind.DELETE;
/*      */       
/*      */       case 4:
/* 6276 */         return OracleStatement.SqlKind.INSERT;
/*      */       
/*      */       case 8:
/* 6279 */         return OracleStatement.SqlKind.MERGE;
/*      */       
/*      */       case 16:
/* 6282 */         return OracleStatement.SqlKind.UPDATE;
/*      */       
/*      */       case -128:
/* 6285 */         return OracleStatement.SqlKind.OTHER;
/*      */       
/*      */       case 32:
/* 6288 */         return OracleStatement.SqlKind.PLSQL_BLOCK;
/*      */       
/*      */       case 64:
/* 6291 */         return OracleStatement.SqlKind.CALL_BLOCK;
/*      */       
/*      */       case 1:
/* 6294 */         return OracleStatement.SqlKind.SELECT;
/*      */     } 
/*      */ 
/*      */     
/* 6298 */     return OracleStatement.SqlKind.UNINITIALIZED;
/*      */   }
/*      */ 
/*      */   
/* 6302 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */   
/*      */   abstract void doDescribe(boolean paramBoolean) throws SQLException;
/*      */   
/*      */   abstract void executeForDescribe() throws SQLException;
/*      */   
/*      */   abstract void executeForRows(boolean paramBoolean) throws SQLException;
/*      */   
/*      */   abstract void fetch() throws SQLException;
/*      */   
/*      */   abstract void doClose() throws SQLException;
/*      */   
/*      */   abstract void closeQuery() throws SQLException;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/OracleStatement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */