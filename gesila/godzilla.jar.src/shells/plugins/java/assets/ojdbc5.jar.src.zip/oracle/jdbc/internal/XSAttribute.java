/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XSAttribute
/*    */ {
/*    */   public static final XSAttribute constructXSAttribute() throws SQLException {
/* 46 */     return (XSAttribute)InternalFactory.createXSAttribute();
/*    */   }
/*    */   
/*    */   public abstract void setAttributeName(String paramString) throws SQLException;
/*    */   
/*    */   public abstract void setAttributeValue(String paramString) throws SQLException;
/*    */   
/*    */   public abstract void setAttributeDefaultValue(String paramString) throws SQLException;
/*    */   
/*    */   public abstract void setFlag(long paramLong) throws SQLException;
/*    */   
/*    */   public abstract String getAttributeName();
/*    */   
/*    */   public abstract String getAttributeValue();
/*    */   
/*    */   public abstract String getAttributeDefaultValue();
/*    */   
/*    */   public abstract long getFlag();
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/internal/XSAttribute.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */