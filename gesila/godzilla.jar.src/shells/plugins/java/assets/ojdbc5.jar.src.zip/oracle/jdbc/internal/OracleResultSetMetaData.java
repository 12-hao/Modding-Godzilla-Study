package oracle.jdbc.internal;

import oracle.jdbc.OracleResultSetMetaData;

public interface OracleResultSetMetaData extends OracleResultSetMetaData {}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/internal/OracleResultSetMetaData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */