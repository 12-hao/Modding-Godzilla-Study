package oracle.jdbc.aq;

import java.sql.SQLException;

public interface AQAgent {
  void setAddress(String paramString) throws SQLException;
  
  String getAddress();
  
  void setName(String paramString) throws SQLException;
  
  String getName();
  
  void setProtocol(int paramInt) throws SQLException;
  
  int getProtocol();
  
  String toString();
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/aq/AQAgent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */