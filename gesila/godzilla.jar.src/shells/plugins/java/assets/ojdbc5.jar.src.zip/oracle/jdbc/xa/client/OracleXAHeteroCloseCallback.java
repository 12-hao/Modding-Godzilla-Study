/*     */ package oracle.jdbc.xa.client;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.driver.OracleCloseCallback;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleXAHeteroCloseCallback
/*     */   implements OracleCloseCallback
/*     */ {
/*     */   public synchronized void beforeClose(OracleConnection paramOracleConnection, Object paramObject) {}
/*     */   
/*     */   public synchronized void afterClose(Object paramObject) {
/*  53 */     int i = ((OracleXAHeteroConnection)paramObject).getRmid();
/*  54 */     String str = ((OracleXAHeteroConnection)paramObject).getXaCloseString();
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  59 */       int j = t2cDoXaClose(str, i, 0, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  65 */       if (j != 0)
/*     */       {
/*     */         
/*  68 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), -1 * j);
/*  69 */         sQLException.fillInStackTrace();
/*  70 */         throw sQLException;
/*     */       }
/*     */     
/*     */     }
/*  74 */     catch (SQLException sQLException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */   
/*     */   private native int t2cDoXaClose(String paramString, int paramInt1, int paramInt2, int paramInt3);
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/xa/client/OracleXAHeteroCloseCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */