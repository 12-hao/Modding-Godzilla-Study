/*     */ package oracle.jdbc.oracore;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Serializable;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.SQLName;
/*     */ import oracle.sql.TypeDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OracleNamedType
/*     */   extends OracleType
/*     */   implements Serializable
/*     */ {
/*     */   transient OracleConnection connection;
/*  35 */   SQLName sqlName = null;
/*  36 */   transient OracleTypeADT parent = null;
/*     */   transient int idx;
/*  38 */   transient TypeDescriptor descriptor = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullName() throws SQLException {
/*  68 */     return getFullName(false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getFullName(boolean paramBoolean) throws SQLException {
/*  76 */     String str = null;
/*     */     
/*  78 */     if (paramBoolean || this.sqlName == null)
/*     */     {
/*     */       
/*  81 */       if (this.parent != null && (str = this.parent.getAttributeType(this.idx)) != null) {
/*     */ 
/*     */         
/*  84 */         this.sqlName = new SQLName(str, (OracleConnection)this.connection);
/*     */       }
/*     */       else {
/*     */         
/*  88 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Unable to resolve name");
/*  89 */         sQLException.fillInStackTrace();
/*  90 */         throw sQLException;
/*     */       } 
/*     */     }
/*  93 */     return this.sqlName.getName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSchemaName() throws SQLException {
/* 100 */     if (this.sqlName == null) getFullName(); 
/* 101 */     return this.sqlName.getSchema();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSimpleName() throws SQLException {
/* 108 */     if (this.sqlName == null) getFullName(); 
/* 109 */     return this.sqlName.getSimpleName();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean hasName() throws SQLException {
/* 116 */     return (this.sqlName != null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleTypeADT getParent() throws SQLException {
/* 123 */     return this.parent;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setParent(OracleTypeADT paramOracleTypeADT) throws SQLException {
/* 130 */     this.parent = paramOracleTypeADT;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getOrder() throws SQLException {
/* 137 */     return this.idx;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrder(int paramInt) throws SQLException {
/* 144 */     this.idx = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleConnection getConnection() throws SQLException {
/* 158 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnection(OracleConnection paramOracleConnection) throws SQLException {
/* 173 */     setConnectionInternal(paramOracleConnection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setConnectionInternal(OracleConnection paramOracleConnection) {
/* 180 */     this.connection = paramOracleConnection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong, Datum paramDatum, int paramInt, Map paramMap) throws SQLException {
/* 199 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 200 */     sQLException.fillInStackTrace();
/* 201 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Datum unlinearize(byte[] paramArrayOfbyte, long paramLong1, Datum paramDatum, long paramLong2, int paramInt1, int paramInt2, Map paramMap) throws SQLException {
/* 221 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 222 */     sQLException.fillInStackTrace();
/* 223 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] linearize(Datum paramDatum) throws SQLException {
/* 236 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 237 */     sQLException.fillInStackTrace();
/* 238 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public TypeDescriptor getDescriptor() throws SQLException {
/* 246 */     return this.descriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDescriptor(TypeDescriptor paramTypeDescriptor) throws SQLException {
/* 253 */     this.descriptor = paramTypeDescriptor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getTypeVersion() {
/* 260 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/*     */     try {
/* 274 */       paramObjectOutputStream.writeUTF(getFullName());
/*     */     }
/* 276 */     catch (SQLException sQLException) {
/*     */ 
/*     */       
/* 279 */       IOException iOException = DatabaseError.createIOException(sQLException);
/* 280 */       iOException.fillInStackTrace();
/* 281 */       throw iOException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException {
/* 291 */     String str = paramObjectInputStream.readUTF(); 
/* 292 */     try { this.sqlName = new SQLName(str, null); } catch (SQLException sQLException) {}
/* 293 */     this.parent = null;
/* 294 */     this.idx = -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void fixupConnection(OracleConnection paramOracleConnection) throws SQLException {
/* 302 */     if (this.connection == null) setConnection(paramOracleConnection);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printXML(PrintWriter paramPrintWriter, int paramInt) throws SQLException {
/* 314 */     printXML(paramPrintWriter, paramInt, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void printXML(PrintWriter paramPrintWriter, int paramInt, boolean paramBoolean) throws SQLException {
/* 320 */     for (byte b = 0; b < paramInt; ) { paramPrintWriter.print("  "); b++; }
/* 321 */      paramPrintWriter.println("<OracleNamedType/>");
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void initNamesRecursively() throws SQLException {
/* 328 */     Map map = createTypesTreeMap();
/* 329 */     if (map.size() > 0) {
/* 330 */       initChildNamesRecursively(map);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void setNames(String paramString1, String paramString2) throws SQLException {
/* 337 */     this.sqlName = new SQLName(paramString1, paramString2, (OracleConnection)this.connection);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setSqlName(SQLName paramSQLName) {
/* 344 */     this.sqlName = paramSQLName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Map createTypesTreeMap() throws SQLException {
/* 358 */     Map map = null;
/* 359 */     String str = this.connection.getDefaultSchemaNameForNamedTypes();
/* 360 */     if (this.sqlName.getSchema().equals(str)) {
/* 361 */       map = getNodeMapFromUserTypes();
/*     */     }
/* 363 */     if (map == null)
/* 364 */       map = getNodeMapFromAllTypes(); 
/* 365 */     return map;
/*     */   }
/*     */ 
/*     */   
/* 369 */   static String getUserTypeTreeSql = "select level depth, parent_type, child_type, ATTR_NO, child_type_owner from  (select TYPE_NAME parent_type, ELEM_TYPE_NAME child_type, 0 ATTR_NO,       ELEM_TYPE_OWNER child_type_owner     from USER_COLL_TYPES  union   select TYPE_NAME parent_type, ATTR_TYPE_NAME child_type, ATTR_NO,       ATTR_TYPE_OWNER child_type_owner     from USER_TYPE_ATTRS  ) start with parent_type  = ?  connect by prior  child_type = parent_type";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String sqlHint;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleNamedType() {
/* 384 */     this.sqlHint = null; } public OracleNamedType(String paramString, OracleConnection paramOracleConnection) throws SQLException { this.sqlHint = null; setConnectionInternal(paramOracleConnection); this.sqlName = new SQLName(paramString, (OracleConnection)paramOracleConnection); } protected OracleNamedType(OracleTypeADT paramOracleTypeADT, int paramInt, OracleConnection paramOracleConnection) { this.sqlHint = null;
/*     */     setConnectionInternal(paramOracleConnection);
/*     */     this.parent = paramOracleTypeADT;
/*     */     this.idx = paramInt; } String getSqlHint() throws SQLException {
/* 388 */     if (this.sqlHint == null)
/*     */     {
/* 390 */       if (this.connection.getVersionNumber() >= 11000) {
/* 391 */         this.sqlHint = "";
/*     */       } else {
/* 393 */         this.sqlHint = "/*+RULE*/";
/*     */       }  } 
/* 395 */     return this.sqlHint;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map getNodeMapFromUserTypes() throws SQLException {
/* 403 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 404 */     PreparedStatement preparedStatement = null;
/* 405 */     ResultSet resultSet = null;
/*     */     
/*     */     try {
/* 408 */       preparedStatement = this.connection.prepareStatement(getSqlHint() + getUserTypeTreeSql);
/* 409 */       preparedStatement.setString(1, this.sqlName.getSimpleName());
/* 410 */       resultSet = preparedStatement.executeQuery();
/*     */       
/* 412 */       while (resultSet.next()) {
/*     */         
/* 414 */         int i = resultSet.getInt(1);
/* 415 */         String str1 = resultSet.getString(2);
/* 416 */         String str2 = resultSet.getString(3);
/* 417 */         int j = resultSet.getInt(4);
/* 418 */         String str3 = resultSet.getString(5);
/* 419 */         if (str3 != null && !str3.equals(this.sqlName.getSchema())) {
/*     */           
/* 421 */           hashMap = null;
/*     */           break;
/*     */         } 
/* 424 */         if (str1.length() > 0) {
/*     */           
/* 426 */           SQLName sQLName = new SQLName(this.sqlName.getSchema(), str1, (OracleConnection)this.connection);
/* 427 */           TypeTreeElement typeTreeElement = null;
/* 428 */           if (hashMap.containsKey(sQLName)) {
/* 429 */             typeTreeElement = (TypeTreeElement)hashMap.get(sQLName);
/*     */           } else {
/*     */             
/* 432 */             typeTreeElement = new TypeTreeElement(this.sqlName.getSchema(), str1);
/* 433 */             hashMap.put(sQLName, typeTreeElement);
/*     */           } 
/* 435 */           typeTreeElement.putChild(this.sqlName.getSchema(), str2, j);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 439 */       if (resultSet != null) resultSet.close();  if (preparedStatement != null) preparedStatement.close(); 
/* 440 */     }  return hashMap;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 445 */   static String getAllTypeTreeSql = "select parent_type, parent_type_owner, child_type, ATTR_NO, child_type_owner from ( select TYPE_NAME parent_type,  OWNER parent_type_owner,     ELEM_TYPE_NAME child_type, 0 ATTR_NO,     ELEM_TYPE_OWNER child_type_owner   from ALL_COLL_TYPES union   select TYPE_NAME parent_type, OWNER parent_type_owner,     ATTR_TYPE_NAME child_type, ATTR_NO,     ATTR_TYPE_OWNER child_type_owner   from ALL_TYPE_ATTRS ) start with parent_type  = ?  and parent_type_owner = ? connect by prior child_type = parent_type   and ( child_type_owner = parent_type_owner or child_type_owner is null )";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Map getNodeMapFromAllTypes() throws SQLException {
/* 463 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 464 */     PreparedStatement preparedStatement = null;
/* 465 */     ResultSet resultSet = null;
/*     */     
/*     */     try {
/* 468 */       preparedStatement = this.connection.prepareStatement(getSqlHint() + getAllTypeTreeSql);
/* 469 */       preparedStatement.setString(1, this.sqlName.getSimpleName());
/* 470 */       preparedStatement.setString(2, this.sqlName.getSchema());
/* 471 */       resultSet = preparedStatement.executeQuery();
/*     */       
/* 473 */       while (resultSet.next()) {
/*     */         
/* 475 */         String str1 = resultSet.getString(1);
/* 476 */         String str2 = resultSet.getString(2);
/* 477 */         String str3 = resultSet.getString(3);
/* 478 */         int i = resultSet.getInt(4);
/* 479 */         String str4 = resultSet.getString(5);
/* 480 */         if (str4 == null) str4 = "SYS"; 
/* 481 */         if (str1.length() > 0) {
/*     */           
/* 483 */           SQLName sQLName = new SQLName(str2, str1, (OracleConnection)this.connection);
/* 484 */           TypeTreeElement typeTreeElement = null;
/* 485 */           if (hashMap.containsKey(sQLName)) {
/* 486 */             typeTreeElement = (TypeTreeElement)hashMap.get(sQLName);
/*     */           } else {
/*     */             
/* 489 */             typeTreeElement = new TypeTreeElement(str2, str1);
/* 490 */             hashMap.put(sQLName, typeTreeElement);
/*     */           } 
/* 492 */           typeTreeElement.putChild(str4, str3, i);
/*     */         } 
/*     */       } 
/*     */     } finally {
/* 496 */       if (resultSet != null) resultSet.close();  if (preparedStatement != null) preparedStatement.close(); 
/* 497 */     }  return hashMap;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 512 */     return this.connection;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 558 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/oracore/OracleNamedType.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */