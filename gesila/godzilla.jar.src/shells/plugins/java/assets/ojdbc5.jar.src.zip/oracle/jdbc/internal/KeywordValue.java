/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ import oracle.jdbc.driver.InternalFactory;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class KeywordValue
/*    */ {
/*    */   public abstract int getKeyword() throws SQLException;
/*    */   
/*    */   public abstract byte[] getBinaryValue() throws SQLException;
/*    */   
/*    */   public abstract String getTextValue() throws SQLException;
/*    */   
/*    */   public static final KeywordValue constructKeywordValue(int paramInt, String paramString) throws SQLException {
/* 52 */     return (KeywordValue)InternalFactory.createKeywordValue(paramInt, paramString, null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static final KeywordValue constructKeywordValue(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 64 */     return (KeywordValue)InternalFactory.createKeywordValue(paramInt, null, paramArrayOfbyte);
/*    */   }
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/internal/KeywordValue.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */