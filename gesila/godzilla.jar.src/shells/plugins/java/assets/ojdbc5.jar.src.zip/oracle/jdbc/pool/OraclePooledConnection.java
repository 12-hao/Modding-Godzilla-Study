/*      */ package oracle.jdbc.pool;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Connection;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Enumeration;
/*      */ import java.util.HashMap;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import javax.sql.ConnectionEvent;
/*      */ import javax.sql.ConnectionEventListener;
/*      */ import javax.sql.PooledConnection;
/*      */ import javax.transaction.xa.XAResource;
/*      */ import oracle.jdbc.driver.DatabaseError;
/*      */ import oracle.jdbc.driver.OracleCloseCallback;
/*      */ import oracle.jdbc.driver.OracleDriver;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class OraclePooledConnection
/*      */   implements PooledConnection, Serializable
/*      */ {
/*      */   static final long serialVersionUID = -203725628718322873L;
/*      */   public static final String url_string = "connection_url";
/*      */   public static final String pool_auto_commit_string = "pool_auto_commit";
/*      */   public static final String object_type_map = "obj_type_map";
/*      */   public static final String transaction_isolation = "trans_isolation";
/*      */   public static final String statement_cache_size = "stmt_cache_size";
/*      */   public static final String isClearMetaData = "stmt_cache_clear_metadata";
/*      */   public static final String ImplicitStatementCachingEnabled = "ImplicitStatementCachingEnabled";
/*      */   public static final String ExplicitStatementCachingEnabled = "ExplicitStatementCachingEnabled";
/*      */   public static final String LoginTimeout = "LoginTimeout";
/*      */   public static final String connect_auto_commit_string = "connect_auto_commit";
/*      */   public static final String implicit_caching_enabled = "implicit_cache_enabled";
/*      */   public static final String explicit_caching_enabled = "explict_cache_enabled";
/*      */   public static final String connection_properties_string = "connection_properties";
/*      */   public static final String event_listener_string = "event_listener";
/*      */   public static final String sql_exception_string = "sql_exception";
/*      */   public static final String close_callback_string = "close_callback";
/*      */   public static final String private_data = "private_data";
/*      */   static final int CONNECTION_CLOSED_EVENT = 101;
/*      */   static final int CONNECTION_ERROROCCURED_EVENT = 102;
/*   82 */   private Hashtable eventListeners = null;
/*   83 */   private SQLException sqlException = null;
/*      */ 
/*      */   
/*      */   protected boolean autoCommit = true;
/*      */   
/*   88 */   private ConnectionEventListener iccEventListener = null;
/*      */ 
/*      */   
/*   91 */   protected transient OracleConnection logicalHandle = null;
/*      */ 
/*      */   
/*   94 */   protected transient OracleConnection physicalConn = null;
/*      */   
/*   96 */   private Hashtable connectionProperty = null;
/*      */   
/*   98 */   public Properties cachedConnectionAttributes = null;
/*   99 */   public Properties unMatchedCachedConnAttr = null;
/*  100 */   public int closeOption = 0;
/*      */   
/*  102 */   private String pcKey = null;
/*      */ 
/*      */   
/*  105 */   private OracleCloseCallback closeCallback = null;
/*  106 */   private Object privateData = null;
/*      */ 
/*      */   
/*  109 */   private long lastAccessedTime = 0L;
/*      */ 
/*      */   
/*  112 */   protected String dataSourceInstanceNameKey = null;
/*  113 */   protected String dataSourceHostNameKey = null;
/*  114 */   protected String dataSourceDbUniqNameKey = null;
/*      */   
/*      */   protected boolean connectionMarkedDown = false;
/*      */   protected boolean needToAbort = false;
/*  118 */   protected transient OracleDriver oracleDriver = new OracleDriver();
/*      */   
/*      */   boolean localTxnCommitOnClose = false;
/*      */ 
/*      */   
/*      */   public OraclePooledConnection() {
/*  124 */     this((Connection)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OraclePooledConnection(String paramString) throws SQLException {
/*  137 */     Connection connection = this.oracleDriver.connect(paramString, new Properties());
/*      */     
/*  139 */     if (connection == null) {
/*      */       
/*  141 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
/*  142 */       sQLException.fillInStackTrace();
/*  143 */       throw sQLException;
/*      */     } 
/*      */     
/*  146 */     initialize(connection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OraclePooledConnection(String paramString1, String paramString2, String paramString3) throws SQLException {
/*  161 */     Properties properties = new Properties();
/*      */     
/*  163 */     properties.put("user", paramString2);
/*  164 */     properties.put("password", paramString3);
/*  165 */     Connection connection = this.oracleDriver.connect(paramString1, properties);
/*  166 */     if (connection == null) {
/*      */       
/*  168 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67);
/*  169 */       sQLException.fillInStackTrace();
/*  170 */       throw sQLException;
/*      */     } 
/*      */     
/*  173 */     initialize(connection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OraclePooledConnection(Connection paramConnection) {
/*  185 */     initialize(paramConnection);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OraclePooledConnection(Connection paramConnection, boolean paramBoolean) {
/*  197 */     this(paramConnection);
/*      */     
/*  199 */     this.autoCommit = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void initialize(Connection paramConnection) {
/*  208 */     this.physicalConn = (OracleConnection)paramConnection;
/*  209 */     this.eventListeners = new Hashtable<Object, Object>(10);
/*      */     
/*  211 */     this.closeCallback = null;
/*  212 */     this.privateData = null;
/*  213 */     this.lastAccessedTime = 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void addConnectionEventListener(ConnectionEventListener paramConnectionEventListener) {
/*  228 */     if (this.eventListeners == null) {
/*  229 */       this.sqlException = new SQLException("Listener Hashtable Null");
/*      */     } else {
/*  231 */       this.eventListeners.put(paramConnectionEventListener, paramConnectionEventListener);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close() throws SQLException {
/*  245 */     if (this.closeCallback != null) {
/*  246 */       this.closeCallback.beforeClose(this.physicalConn, this.privateData);
/*      */     }
/*  248 */     if (this.physicalConn != null) {
/*      */ 
/*      */       
/*      */       try {
/*  252 */         this.physicalConn.close();
/*  253 */       } catch (SQLException sQLException) {}
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  258 */       this.physicalConn = null;
/*      */     } 
/*      */     
/*  261 */     if (this.closeCallback != null) {
/*  262 */       this.closeCallback.afterClose(this.privateData);
/*      */     }
/*      */     
/*  265 */     this.lastAccessedTime = 0L;
/*  266 */     this.iccEventListener = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized Connection getConnection() throws SQLException {
/*  283 */     if (this.physicalConn == null) {
/*      */       
/*  285 */       this.sqlException = new SQLException("Physical Connection doesn't exist");
/*      */ 
/*      */       
/*  288 */       callListener(102);
/*      */ 
/*      */       
/*  291 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  292 */       sQLException.fillInStackTrace();
/*  293 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  301 */       if (this.logicalHandle != null)
/*      */       {
/*      */ 
/*      */ 
/*      */         
/*  306 */         this.logicalHandle.closeInternal(false);
/*      */       }
/*      */ 
/*      */       
/*  310 */       this.logicalHandle = (OracleConnection)this.physicalConn.getLogicalConnection(this, this.autoCommit);
/*      */ 
/*      */     
/*      */     }
/*  314 */     catch (SQLException sQLException1) {
/*      */       
/*  316 */       this.sqlException = sQLException1;
/*      */       
/*  318 */       callListener(102);
/*      */       
/*  320 */       callImplicitCacheListener(102);
/*      */       
/*  322 */       SQLException sQLException2 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8, "OraclePooledConnection.getConnection() - SQLException Ocurred:" + sQLException1.getMessage());
/*      */       
/*  324 */       sQLException2.fillInStackTrace();
/*  325 */       throw sQLException2;
/*      */     } 
/*      */ 
/*      */     
/*  329 */     return (Connection)this.logicalHandle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getLogicalHandle() throws SQLException {
/*  343 */     return (Connection)this.logicalHandle;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Connection getPhysicalHandle() throws SQLException {
/*  350 */     return (Connection)this.physicalConn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setLastAccessedTime(long paramLong) throws SQLException {
/*  366 */     this.lastAccessedTime = paramLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long getLastAccessedTime() throws SQLException {
/*  380 */     return this.lastAccessedTime;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void registerCloseCallback(OracleCloseCallback paramOracleCloseCallback, Object paramObject) {
/*  395 */     this.closeCallback = paramOracleCloseCallback;
/*  396 */     this.privateData = paramObject;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void removeConnectionEventListener(ConnectionEventListener paramConnectionEventListener) {
/*  410 */     if (this.eventListeners == null) {
/*  411 */       this.sqlException = new SQLException("Listener Hashtable Null");
/*      */     } else {
/*  413 */       this.eventListeners.remove(paramConnectionEventListener);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void registerImplicitCacheConnectionEventListener(ConnectionEventListener paramConnectionEventListener) {
/*  427 */     if (this.iccEventListener != null) {
/*  428 */       this.sqlException = new SQLException("Implicit cache listeneralready registered");
/*      */     } else {
/*      */       
/*  431 */       this.iccEventListener = paramConnectionEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logicalCloseForImplicitConnectionCache() {
/*  454 */     if (this.closeOption == 4096) {
/*      */       
/*  456 */       callImplicitCacheListener(102);
/*      */     }
/*      */     else {
/*      */       
/*  460 */       callImplicitCacheListener(101);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void logicalClose() {
/*  474 */     if (this.cachedConnectionAttributes != null) {
/*      */       
/*  476 */       logicalCloseForImplicitConnectionCache();
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  481 */       callListener(101);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void callListener(int paramInt) {
/*  496 */     if (this.eventListeners == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  501 */     Enumeration<ConnectionEventListener> enumeration = this.eventListeners.keys();
/*      */     
/*  503 */     ConnectionEvent connectionEvent = new ConnectionEvent(this, this.sqlException);
/*      */     
/*  505 */     while (enumeration.hasMoreElements()) {
/*      */       
/*  507 */       ConnectionEventListener connectionEventListener1 = enumeration.nextElement();
/*      */       
/*  509 */       ConnectionEventListener connectionEventListener2 = (ConnectionEventListener)this.eventListeners.get(connectionEventListener1);
/*      */ 
/*      */ 
/*      */       
/*  513 */       if (paramInt == 101) {
/*  514 */         connectionEventListener2.connectionClosed(connectionEvent); continue;
/*  515 */       }  if (paramInt == 102) {
/*  516 */         connectionEventListener2.connectionErrorOccurred(connectionEvent);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void callImplicitCacheListener(int paramInt) {
/*  530 */     if (this.iccEventListener == null) {
/*      */       return;
/*      */     }
/*  533 */     ConnectionEvent connectionEvent = new ConnectionEvent(this, this.sqlException);
/*      */ 
/*      */     
/*  536 */     switch (paramInt) {
/*      */ 
/*      */ 
/*      */       
/*      */       case 101:
/*  541 */         this.iccEventListener.connectionClosed(connectionEvent);
/*      */         break;
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       case 102:
/*  548 */         this.iccEventListener.connectionErrorOccurred(connectionEvent);
/*      */         break;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setStmtCacheSize(int paramInt) throws SQLException {
/*  577 */     setStmtCacheSize(paramInt, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void setStmtCacheSize(int paramInt, boolean paramBoolean) throws SQLException {
/*  603 */     if (paramInt < 0) {
/*      */       
/*  605 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  606 */       sQLException.fillInStackTrace();
/*  607 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/*  611 */     if (this.physicalConn != null) {
/*  612 */       this.physicalConn.setStmtCacheSize(paramInt, paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getStmtCacheSize() {
/*  627 */     if (this.physicalConn != null) {
/*  628 */       return this.physicalConn.getStmtCacheSize();
/*      */     }
/*  630 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStatementCacheSize(int paramInt) throws SQLException {
/*  649 */     if (this.physicalConn != null) {
/*  650 */       this.physicalConn.setStatementCacheSize(paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getStatementCacheSize() throws SQLException {
/*  667 */     if (this.physicalConn != null) {
/*  668 */       return this.physicalConn.getStatementCacheSize();
/*      */     }
/*  670 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setImplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/*  691 */     if (this.physicalConn != null) {
/*  692 */       this.physicalConn.setImplicitCachingEnabled(paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getImplicitCachingEnabled() throws SQLException {
/*  708 */     if (this.physicalConn != null) {
/*  709 */       return this.physicalConn.getImplicitCachingEnabled();
/*      */     }
/*  711 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/*  732 */     if (this.physicalConn != null) {
/*  733 */       this.physicalConn.setExplicitCachingEnabled(paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean getExplicitCachingEnabled() throws SQLException {
/*  749 */     if (this.physicalConn != null) {
/*  750 */       return this.physicalConn.getExplicitCachingEnabled();
/*      */     }
/*      */     
/*  753 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void purgeImplicitCache() throws SQLException {
/*  770 */     if (this.physicalConn != null) {
/*  771 */       this.physicalConn.purgeImplicitCache();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void purgeExplicitCache() throws SQLException {
/*  788 */     if (this.physicalConn != null) {
/*  789 */       this.physicalConn.purgeExplicitCache();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public PreparedStatement getStatementWithKey(String paramString) throws SQLException {
/*  810 */     if (this.physicalConn != null) {
/*  811 */       return this.physicalConn.getStatementWithKey(paramString);
/*      */     }
/*      */     
/*  814 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public CallableStatement getCallWithKey(String paramString) throws SQLException {
/*  835 */     if (this.physicalConn != null) {
/*  836 */       return this.physicalConn.getCallWithKey(paramString);
/*      */     }
/*      */     
/*  839 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isStatementCacheInitialized() {
/*  852 */     if (this.physicalConn != null) {
/*  853 */       return this.physicalConn.isStatementCacheInitialized();
/*      */     }
/*      */     
/*  856 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setProperties(Hashtable paramHashtable) {
/*  864 */     this.connectionProperty = paramHashtable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public final void setUserName(String paramString1, String paramString2) {
/*  874 */     this.pcKey = generateKey(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final String generateKey(String paramString1, String paramString2) {
/*  881 */     return paramString1.toUpperCase() + paramString2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final OracleConnectionCacheEntry addToImplicitCache(HashMap<String, OracleConnectionCacheEntry> paramHashMap, OracleConnectionCacheEntry paramOracleConnectionCacheEntry) {
/*  892 */     return paramHashMap.put(this.pcKey, paramOracleConnectionCacheEntry);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final OracleConnectionCacheEntry removeFromImplictCache(HashMap paramHashMap) {
/*  903 */     return (OracleConnectionCacheEntry)paramHashMap.get(this.pcKey);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean isSameUser(String paramString1, String paramString2) {
/*  914 */     return (paramString1 != null && paramString2 != null && this.pcKey.equalsIgnoreCase(paramString1 + paramString2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public XAResource getXAResource() throws SQLException {
/*  930 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  931 */     sQLException.fillInStackTrace();
/*  932 */     throw sQLException;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void writeObject(ObjectOutputStream paramObjectOutputStream) throws IOException {
/*  945 */     paramObjectOutputStream.defaultWriteObject();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  954 */       this.physicalConn.getPropertyForPooledConnection(this);
/*      */       
/*  956 */       if (this.eventListeners != null) {
/*  957 */         this.connectionProperty.put("event_listener", this.eventListeners);
/*      */       }
/*  959 */       if (this.sqlException != null) {
/*  960 */         this.connectionProperty.put("sql_exception", this.sqlException);
/*      */       }
/*  962 */       this.connectionProperty.put("pool_auto_commit", "" + this.autoCommit);
/*      */       
/*  964 */       if (this.closeCallback != null) {
/*  965 */         this.connectionProperty.put("close_callback", this.closeCallback);
/*      */       }
/*  967 */       if (this.privateData != null) {
/*  968 */         this.connectionProperty.put("private_data", this.privateData);
/*      */       }
/*  970 */       paramObjectOutputStream.writeObject(this.connectionProperty);
/*  971 */       this.physicalConn.close();
/*      */     }
/*  973 */     catch (SQLException sQLException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void readObject(ObjectInputStream paramObjectInputStream) throws IOException, ClassNotFoundException, SQLException {
/*  989 */     paramObjectInputStream.defaultReadObject();
/*      */     
/*  991 */     this.connectionProperty = (Hashtable)paramObjectInputStream.readObject();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  998 */       Properties properties = (Properties)this.connectionProperty.get("connection_properties");
/*      */       
/* 1000 */       String str1 = properties.getProperty("connection_url");
/*      */       
/* 1002 */       this.oracleDriver = new OracleDriver();
/*      */       
/* 1004 */       Connection connection = this.oracleDriver.connect(str1, properties);
/*      */ 
/*      */ 
/*      */       
/* 1008 */       initialize(connection);
/*      */       
/* 1010 */       this.eventListeners = (Hashtable)this.connectionProperty.get("event_listener");
/*      */       
/* 1012 */       this.sqlException = (SQLException)this.connectionProperty.get("sql_exception");
/*      */       
/* 1014 */       this.autoCommit = ((String)this.connectionProperty.get("pool_auto_commit")).equals("true");
/*      */       
/* 1016 */       this.closeCallback = (OracleCloseCallback)this.connectionProperty.get("close_callback");
/*      */       
/* 1018 */       this.privateData = this.connectionProperty.get("private_data");
/*      */       
/* 1020 */       Map map = (Map)this.connectionProperty.get("obj_type_map");
/*      */ 
/*      */       
/* 1023 */       if (map != null) {
/* 1024 */         ((OracleConnection)connection).setTypeMap(map);
/*      */       }
/* 1026 */       String str2 = properties.getProperty("trans_isolation");
/*      */       
/* 1028 */       connection.setTransactionIsolation(Integer.parseInt(str2));
/*      */       
/* 1030 */       str2 = properties.getProperty("stmt_cache_size");
/*      */       
/* 1032 */       int i = Integer.parseInt(str2);
/*      */       
/* 1034 */       if (i != -1) {
/*      */         
/* 1036 */         setStatementCacheSize(i);
/*      */         
/* 1038 */         str2 = properties.getProperty("implicit_cache_enabled");
/* 1039 */         if (str2 != null && str2.equalsIgnoreCase("true")) {
/* 1040 */           setImplicitCachingEnabled(true);
/*      */         } else {
/* 1042 */           setImplicitCachingEnabled(false);
/*      */         } 
/* 1044 */         str2 = properties.getProperty("explict_cache_enabled");
/* 1045 */         if (str2 != null && str2.equalsIgnoreCase("true")) {
/* 1046 */           setExplicitCachingEnabled(true);
/*      */         } else {
/* 1048 */           setExplicitCachingEnabled(false);
/*      */         } 
/* 1050 */       }  this.physicalConn.setAutoCommit(((String)properties.get("connect_auto_commit")).equals("true"));
/*      */     }
/* 1052 */     catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 1075 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1080 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/pool/OraclePooledConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */