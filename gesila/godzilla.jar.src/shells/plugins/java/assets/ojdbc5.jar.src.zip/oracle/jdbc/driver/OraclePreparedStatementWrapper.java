/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import oracle.jdbc.OracleParameterMetaData;
/*      */ import oracle.jdbc.OraclePreparedStatement;
/*      */ import oracle.jdbc.OracleStatement;
/*      */ import oracle.jdbc.internal.OraclePreparedStatement;
/*      */ import oracle.jdbc.internal.OracleStatement;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BINARY_DOUBLE;
/*      */ import oracle.sql.BINARY_FLOAT;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.StructDescriptor;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class OraclePreparedStatementWrapper
/*      */   extends OracleStatementWrapper
/*      */   implements OraclePreparedStatement
/*      */ {
/*   70 */   protected OraclePreparedStatement preparedStatement = null;
/*      */ 
/*      */   
/*      */   OraclePreparedStatementWrapper(OraclePreparedStatement paramOraclePreparedStatement) throws SQLException {
/*   74 */     super((OracleStatement)paramOraclePreparedStatement);
/*   75 */     this.preparedStatement = (OraclePreparedStatement)paramOraclePreparedStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void close() throws SQLException {
/*   82 */     super.close();
/*   83 */     this.preparedStatement = (OraclePreparedStatement)OracleStatementWrapper.closedStatement;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void closeWithKey(String paramString) throws SQLException {
/*   90 */     this.preparedStatement.closeWithKey(paramString);
/*   91 */     this.statement = (OracleStatement)(this.preparedStatement = (OraclePreparedStatement)closedStatement);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArray(int paramInt, Array paramArray) throws SQLException {
/*  114 */     this.preparedStatement.setArray(paramInt, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/*  122 */     this.preparedStatement.setBigDecimal(paramInt, paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlob(int paramInt, Blob paramBlob) throws SQLException {
/*  130 */     this.preparedStatement.setBlob(paramInt, paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/*  138 */     this.preparedStatement.setBoolean(paramInt, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByte(int paramInt, byte paramByte) throws SQLException {
/*  146 */     this.preparedStatement.setByte(paramInt, paramByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/*  154 */     this.preparedStatement.setBytes(paramInt, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClob(int paramInt, Clob paramClob) throws SQLException {
/*  162 */     this.preparedStatement.setClob(paramInt, paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate) throws SQLException {
/*  170 */     this.preparedStatement.setDate(paramInt, paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  178 */     this.preparedStatement.setDate(paramInt, paramDate, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDouble(int paramInt, double paramDouble) throws SQLException {
/*  186 */     this.preparedStatement.setDouble(paramInt, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloat(int paramInt, float paramFloat) throws SQLException {
/*  194 */     this.preparedStatement.setFloat(paramInt, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInt(int paramInt1, int paramInt2) throws SQLException {
/*  202 */     this.preparedStatement.setInt(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLong(int paramInt, long paramLong) throws SQLException {
/*  210 */     this.preparedStatement.setLong(paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt, Object paramObject) throws SQLException {
/*  218 */     this.preparedStatement.setObject(paramInt, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/*  226 */     this.preparedStatement.setObject(paramInt1, paramObject, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRef(int paramInt, Ref paramRef) throws SQLException {
/*  234 */     this.preparedStatement.setRef(paramInt, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShort(int paramInt, short paramShort) throws SQLException {
/*  242 */     this.preparedStatement.setShort(paramInt, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setString(int paramInt, String paramString) throws SQLException {
/*  250 */     this.preparedStatement.setString(paramInt, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime) throws SQLException {
/*  258 */     this.preparedStatement.setTime(paramInt, paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  266 */     this.preparedStatement.setTime(paramInt, paramTime, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/*  274 */     this.preparedStatement.setTimestamp(paramInt, paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  282 */     this.preparedStatement.setTimestamp(paramInt, paramTimestamp, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURL(int paramInt, URL paramURL) throws SQLException {
/*  290 */     this.preparedStatement.setURL(paramInt, paramURL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
/*  298 */     this.preparedStatement.setARRAY(paramInt, paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
/*  306 */     this.preparedStatement.setBFILE(paramInt, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfile(int paramInt, BFILE paramBFILE) throws SQLException {
/*  314 */     this.preparedStatement.setBfile(paramInt, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, float paramFloat) throws SQLException {
/*  322 */     this.preparedStatement.setBinaryFloat(paramInt, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/*  330 */     this.preparedStatement.setBinaryFloat(paramInt, paramBINARY_FLOAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, double paramDouble) throws SQLException {
/*  338 */     this.preparedStatement.setBinaryDouble(paramInt, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/*  346 */     this.preparedStatement.setBinaryDouble(paramInt, paramBINARY_DOUBLE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
/*  354 */     this.preparedStatement.setBLOB(paramInt, paramBLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
/*  362 */     this.preparedStatement.setCHAR(paramInt, paramCHAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
/*  370 */     this.preparedStatement.setCLOB(paramInt, paramCLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursor(int paramInt, ResultSet paramResultSet) throws SQLException {
/*  378 */     this.preparedStatement.setCursor(paramInt, paramResultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
/*  386 */     this.preparedStatement.setCustomDatum(paramInt, paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATE(int paramInt, DATE paramDATE) throws SQLException {
/*  394 */     this.preparedStatement.setDATE(paramInt, paramDATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHAR(int paramInt, String paramString) throws SQLException {
/*  402 */     this.preparedStatement.setFixedCHAR(paramInt, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
/*  410 */     this.preparedStatement.setINTERVALDS(paramInt, paramINTERVALDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
/*  418 */     this.preparedStatement.setINTERVALYM(paramInt, paramINTERVALYM);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
/*  426 */     this.preparedStatement.setNUMBER(paramInt, paramNUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
/*  434 */     this.preparedStatement.setOPAQUE(paramInt, paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObject(int paramInt, Datum paramDatum) throws SQLException {
/*  442 */     this.preparedStatement.setOracleObject(paramInt, paramDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORAData(int paramInt, ORAData paramORAData) throws SQLException {
/*  450 */     this.preparedStatement.setORAData(paramInt, paramORAData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAW(int paramInt, RAW paramRAW) throws SQLException {
/*  458 */     this.preparedStatement.setRAW(paramInt, paramRAW);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREF(int paramInt, REF paramREF) throws SQLException {
/*  466 */     this.preparedStatement.setREF(paramInt, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefType(int paramInt, REF paramREF) throws SQLException {
/*  474 */     this.preparedStatement.setRefType(paramInt, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWID(int paramInt, ROWID paramROWID) throws SQLException {
/*  482 */     this.preparedStatement.setROWID(paramInt, paramROWID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
/*  490 */     this.preparedStatement.setSTRUCT(paramInt, paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/*  498 */     this.preparedStatement.setTIMESTAMPLTZ(paramInt, paramTIMESTAMPLTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/*  506 */     this.preparedStatement.setTIMESTAMPTZ(paramInt, paramTIMESTAMPTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
/*  514 */     this.preparedStatement.setTIMESTAMP(paramInt, paramTIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/*  522 */     this.preparedStatement.setAsciiStream(paramInt1, paramInputStream, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/*  530 */     this.preparedStatement.setBinaryStream(paramInt1, paramInputStream, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/*  538 */     this.preparedStatement.setCharacterStream(paramInt1, paramReader, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/*  546 */     this.preparedStatement.setUnicodeStream(paramInt1, paramInputStream, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setArrayAtName(String paramString, Array paramArray) throws SQLException {
/*  555 */     this.preparedStatement.setArrayAtName(paramString, paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBigDecimalAtName(String paramString, BigDecimal paramBigDecimal) throws SQLException {
/*  563 */     this.preparedStatement.setBigDecimalAtName(paramString, paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBlobAtName(String paramString, Blob paramBlob) throws SQLException {
/*  571 */     this.preparedStatement.setBlobAtName(paramString, paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBooleanAtName(String paramString, boolean paramBoolean) throws SQLException {
/*  579 */     this.preparedStatement.setBooleanAtName(paramString, paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setByteAtName(String paramString, byte paramByte) throws SQLException {
/*  587 */     this.preparedStatement.setByteAtName(paramString, paramByte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/*  595 */     this.preparedStatement.setBytesAtName(paramString, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setClobAtName(String paramString, Clob paramClob) throws SQLException {
/*  603 */     this.preparedStatement.setClobAtName(paramString, paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateAtName(String paramString, Date paramDate) throws SQLException {
/*  611 */     this.preparedStatement.setDateAtName(paramString, paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDateAtName(String paramString, Date paramDate, Calendar paramCalendar) throws SQLException {
/*  619 */     this.preparedStatement.setDateAtName(paramString, paramDate, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDoubleAtName(String paramString, double paramDouble) throws SQLException {
/*  627 */     this.preparedStatement.setDoubleAtName(paramString, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFloatAtName(String paramString, float paramFloat) throws SQLException {
/*  635 */     this.preparedStatement.setFloatAtName(paramString, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setIntAtName(String paramString, int paramInt) throws SQLException {
/*  643 */     this.preparedStatement.setIntAtName(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLongAtName(String paramString, long paramLong) throws SQLException {
/*  651 */     this.preparedStatement.setLongAtName(paramString, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObjectAtName(String paramString, Object paramObject) throws SQLException {
/*  659 */     this.preparedStatement.setObjectAtName(paramString, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObjectAtName(String paramString, Object paramObject, int paramInt) throws SQLException {
/*  667 */     this.preparedStatement.setObjectAtName(paramString, paramObject, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefAtName(String paramString, Ref paramRef) throws SQLException {
/*  675 */     this.preparedStatement.setRefAtName(paramString, paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setShortAtName(String paramString, short paramShort) throws SQLException {
/*  683 */     this.preparedStatement.setShortAtName(paramString, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringAtName(String paramString1, String paramString2) throws SQLException {
/*  691 */     this.preparedStatement.setStringAtName(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimeAtName(String paramString, Time paramTime) throws SQLException {
/*  699 */     this.preparedStatement.setTimeAtName(paramString, paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimeAtName(String paramString, Time paramTime, Calendar paramCalendar) throws SQLException {
/*  707 */     this.preparedStatement.setTimeAtName(paramString, paramTime, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp) throws SQLException {
/*  715 */     this.preparedStatement.setTimestampAtName(paramString, paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTimestampAtName(String paramString, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/*  723 */     this.preparedStatement.setTimestampAtName(paramString, paramTimestamp, paramCalendar);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setURLAtName(String paramString, URL paramURL) throws SQLException {
/*  731 */     this.preparedStatement.setURLAtName(paramString, paramURL);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setARRAYAtName(String paramString, ARRAY paramARRAY) throws SQLException {
/*  739 */     this.preparedStatement.setARRAYAtName(paramString, paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBFILEAtName(String paramString, BFILE paramBFILE) throws SQLException {
/*  747 */     this.preparedStatement.setBFILEAtName(paramString, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBfileAtName(String paramString, BFILE paramBFILE) throws SQLException {
/*  755 */     this.preparedStatement.setBfileAtName(paramString, paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloatAtName(String paramString, float paramFloat) throws SQLException {
/*  763 */     this.preparedStatement.setBinaryFloatAtName(paramString, paramFloat);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryFloatAtName(String paramString, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/*  771 */     this.preparedStatement.setBinaryFloatAtName(paramString, paramBINARY_FLOAT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDoubleAtName(String paramString, double paramDouble) throws SQLException {
/*  779 */     this.preparedStatement.setBinaryDoubleAtName(paramString, paramDouble);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryDoubleAtName(String paramString, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/*  787 */     this.preparedStatement.setBinaryDoubleAtName(paramString, paramBINARY_DOUBLE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBLOBAtName(String paramString, BLOB paramBLOB) throws SQLException {
/*  795 */     this.preparedStatement.setBLOBAtName(paramString, paramBLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCHARAtName(String paramString, CHAR paramCHAR) throws SQLException {
/*  803 */     this.preparedStatement.setCHARAtName(paramString, paramCHAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCLOBAtName(String paramString, CLOB paramCLOB) throws SQLException {
/*  811 */     this.preparedStatement.setCLOBAtName(paramString, paramCLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCursorAtName(String paramString, ResultSet paramResultSet) throws SQLException {
/*  819 */     this.preparedStatement.setCursorAtName(paramString, paramResultSet);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCustomDatumAtName(String paramString, CustomDatum paramCustomDatum) throws SQLException {
/*  827 */     this.preparedStatement.setCustomDatumAtName(paramString, paramCustomDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDATEAtName(String paramString, DATE paramDATE) throws SQLException {
/*  835 */     this.preparedStatement.setDATEAtName(paramString, paramDATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFixedCHARAtName(String paramString1, String paramString2) throws SQLException {
/*  843 */     this.preparedStatement.setFixedCHARAtName(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALDSAtName(String paramString, INTERVALDS paramINTERVALDS) throws SQLException {
/*  851 */     this.preparedStatement.setINTERVALDSAtName(paramString, paramINTERVALDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setINTERVALYMAtName(String paramString, INTERVALYM paramINTERVALYM) throws SQLException {
/*  859 */     this.preparedStatement.setINTERVALYMAtName(paramString, paramINTERVALYM);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNUMBERAtName(String paramString, NUMBER paramNUMBER) throws SQLException {
/*  867 */     this.preparedStatement.setNUMBERAtName(paramString, paramNUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOPAQUEAtName(String paramString, OPAQUE paramOPAQUE) throws SQLException {
/*  875 */     this.preparedStatement.setOPAQUEAtName(paramString, paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setOracleObjectAtName(String paramString, Datum paramDatum) throws SQLException {
/*  883 */     this.preparedStatement.setOracleObjectAtName(paramString, paramDatum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setORADataAtName(String paramString, ORAData paramORAData) throws SQLException {
/*  891 */     this.preparedStatement.setORADataAtName(paramString, paramORAData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRAWAtName(String paramString, RAW paramRAW) throws SQLException {
/*  899 */     this.preparedStatement.setRAWAtName(paramString, paramRAW);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setREFAtName(String paramString, REF paramREF) throws SQLException {
/*  907 */     this.preparedStatement.setREFAtName(paramString, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setRefTypeAtName(String paramString, REF paramREF) throws SQLException {
/*  915 */     this.preparedStatement.setRefTypeAtName(paramString, paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setROWIDAtName(String paramString, ROWID paramROWID) throws SQLException {
/*  923 */     this.preparedStatement.setROWIDAtName(paramString, paramROWID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setSTRUCTAtName(String paramString, STRUCT paramSTRUCT) throws SQLException {
/*  931 */     this.preparedStatement.setSTRUCTAtName(paramString, paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPLTZAtName(String paramString, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/*  939 */     this.preparedStatement.setTIMESTAMPLTZAtName(paramString, paramTIMESTAMPLTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPTZAtName(String paramString, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/*  947 */     this.preparedStatement.setTIMESTAMPTZAtName(paramString, paramTIMESTAMPTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTIMESTAMPAtName(String paramString, TIMESTAMP paramTIMESTAMP) throws SQLException {
/*  955 */     this.preparedStatement.setTIMESTAMPAtName(paramString, paramTIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAsciiStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  963 */     this.preparedStatement.setAsciiStreamAtName(paramString, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBinaryStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  971 */     this.preparedStatement.setBinaryStreamAtName(paramString, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCharacterStreamAtName(String paramString, Reader paramReader, int paramInt) throws SQLException {
/*  979 */     this.preparedStatement.setCharacterStreamAtName(paramString, paramReader, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setUnicodeStreamAtName(String paramString, InputStream paramInputStream, int paramInt) throws SQLException {
/*  987 */     this.preparedStatement.setUnicodeStreamAtName(paramString, paramInputStream, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int paramInt1, int paramInt2) throws SQLException {
/*  997 */     this.preparedStatement.setNull(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNull(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 1004 */     this.preparedStatement.setNull(paramInt1, paramInt2, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNullAtName(String paramString, int paramInt) throws SQLException {
/* 1011 */     this.preparedStatement.setNullAtName(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setNullAtName(String paramString1, int paramInt, String paramString2) throws SQLException {
/* 1018 */     this.preparedStatement.setNullAtName(paramString1, paramInt, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObject(int paramInt1, Object paramObject, int paramInt2, int paramInt3) throws SQLException {
/* 1029 */     this.preparedStatement.setObject(paramInt1, paramObject, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setObjectAtName(String paramString, Object paramObject, int paramInt1, int paramInt2) throws SQLException {
/* 1040 */     this.preparedStatement.setObjectAtName(paramString, paramObject, paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptor(int paramInt, StructDescriptor paramStructDescriptor) throws SQLException {
/* 1049 */     this.preparedStatement.setStructDescriptor(paramInt, paramStructDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStructDescriptorAtName(String paramString, StructDescriptor paramStructDescriptor) throws SQLException {
/* 1058 */     this.preparedStatement.setStructDescriptorAtName(paramString, paramStructDescriptor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int executeUpdate() throws SQLException {
/* 1066 */     return this.preparedStatement.executeUpdate();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addBatch() throws SQLException {
/* 1074 */     this.preparedStatement.addBatch();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void clearParameters() throws SQLException {
/* 1082 */     this.preparedStatement.clearParameters();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean execute() throws SQLException {
/* 1090 */     return this.preparedStatement.execute();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setCheckBindTypes(boolean paramBoolean) {
/* 1097 */     this.preparedStatement.setCheckBindTypes(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet getReturnResultSet() throws SQLException {
/* 1105 */     return this.preparedStatement.getReturnResultSet();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineParameterTypeBytes(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1113 */     this.preparedStatement.defineParameterTypeBytes(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineParameterTypeChars(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1121 */     this.preparedStatement.defineParameterTypeChars(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void defineParameterType(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1129 */     this.preparedStatement.defineParameterType(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getExecuteBatch() {
/* 1136 */     return this.preparedStatement.getExecuteBatch();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int sendBatch() throws SQLException {
/* 1144 */     return this.preparedStatement.sendBatch();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPlsqlIndexTable(int paramInt1, Object paramObject, int paramInt2, int paramInt3, int paramInt4, int paramInt5) throws SQLException {
/* 1153 */     this.preparedStatement.setPlsqlIndexTable(paramInt1, paramObject, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFormOfUse(int paramInt, short paramShort) {
/* 1160 */     this.preparedStatement.setFormOfUse(paramInt, paramShort);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDisableStmtCaching(boolean paramBoolean) {
/* 1167 */     this.preparedStatement.setDisableStmtCaching(paramBoolean);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OracleParameterMetaData OracleGetParameterMetaData() throws SQLException {
/* 1175 */     return this.preparedStatement.OracleGetParameterMetaData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerReturnParameter(int paramInt1, int paramInt2) throws SQLException {
/* 1183 */     this.preparedStatement.registerReturnParameter(paramInt1, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerReturnParameter(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/* 1191 */     this.preparedStatement.registerReturnParameter(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void registerReturnParameter(int paramInt1, int paramInt2, String paramString) throws SQLException {
/* 1199 */     this.preparedStatement.registerReturnParameter(paramInt1, paramInt2, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSet executeQuery() throws SQLException {
/* 1207 */     return this.preparedStatement.executeQuery();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 1215 */     return this.preparedStatement.getMetaData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlob(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 1224 */     this.preparedStatement.setBytesForBlob(paramInt, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setBytesForBlobAtName(String paramString, byte[] paramArrayOfbyte) throws SQLException {
/* 1232 */     this.preparedStatement.setBytesForBlobAtName(paramString, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClob(int paramInt, String paramString) throws SQLException {
/* 1241 */     this.preparedStatement.setStringForClob(paramInt, paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setStringForClobAtName(String paramString1, String paramString2) throws SQLException {
/* 1249 */     this.preparedStatement.setStringForClobAtName(paramString1, paramString2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ParameterMetaData getParameterMetaData() throws SQLException {
/* 1257 */     return this.preparedStatement.getParameterMetaData();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setExecuteBatch(int paramInt) throws SQLException {
/* 1266 */     this.preparedStatement.setExecuteBatch(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setInternalBytes(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) throws SQLException {
/* 1281 */     this.preparedStatement.setInternalBytes(paramInt1, paramArrayOfbyte, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enterImplicitCache() throws SQLException {
/* 1289 */     this.preparedStatement.enterImplicitCache();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void enterExplicitCache() throws SQLException {
/* 1297 */     this.preparedStatement.enterExplicitCache();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitImplicitCacheToActive() throws SQLException {
/* 1305 */     this.preparedStatement.exitImplicitCacheToActive();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitExplicitCacheToActive() throws SQLException {
/* 1313 */     this.preparedStatement.exitExplicitCacheToActive();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitImplicitCacheToClose() throws SQLException {
/* 1321 */     this.preparedStatement.exitImplicitCacheToClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void exitExplicitCacheToClose() throws SQLException {
/* 1329 */     this.preparedStatement.exitExplicitCacheToClose();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getOriginalSql() throws SQLException {
/* 1336 */     return this.preparedStatement.getOriginalSql();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 1341 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/OraclePreparedStatementWrapper.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */