/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Map;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class TimestampAccessor
/*     */   extends DateTimeCommonAccessor
/*     */ {
/*     */   TimestampAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean) throws SQLException {
/*  28 */     init(paramOracleStatement, 180, 180, paramShort, paramBoolean);
/*  29 */     initForDataAccess(paramInt2, paramInt1, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   TimestampAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort) throws SQLException {
/*  38 */     init(paramOracleStatement, 180, 180, paramShort, false);
/*  39 */     initForDescribe(180, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort, null);
/*     */     
/*  41 */     initForDataAccess(0, paramInt1, (String)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void initForDataAccess(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  49 */     if (paramInt1 != 0) {
/*  50 */       this.externalType = paramInt1;
/*     */     }
/*  52 */     this.internalTypeMaxLength = 11;
/*     */     
/*  54 */     if (paramInt2 > 0 && paramInt2 < this.internalTypeMaxLength) {
/*  55 */       this.internalTypeMaxLength = paramInt2;
/*     */     }
/*  57 */     this.byteLength = this.internalTypeMaxLength;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/*  65 */     String str = null;
/*     */     
/*  67 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/*  71 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  72 */       sQLException.fillInStackTrace();
/*  73 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/*  81 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/*  82 */       int i = this.columnIndex + this.byteLength * paramInt;
/*  83 */       int j = oracleYear(i);
/*  84 */       int k = -1;
/*     */       
/*  86 */       if (s == 11)
/*     */       {
/*  88 */         k = oracleNanos(i);
/*     */       }
/*     */       
/*  91 */       int m = 0;
/*  92 */       str = toText(j, this.rowSpaceByte[2 + i], this.rowSpaceByte[3 + i], m = this.rowSpaceByte[4 + i] - 1, this.rowSpaceByte[5 + i] - 1, this.rowSpaceByte[6 + i] - 1, k, (m < 12), (String)null);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 102 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/*     */     TIMESTAMP tIMESTAMP;
/* 110 */     Timestamp timestamp = null;
/*     */     
/* 112 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 116 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 117 */       sQLException.fillInStackTrace();
/* 118 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 123 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1)
/*     */     {
/* 125 */       if (this.externalType == 0) {
/*     */         
/* 127 */         if (this.statement.connection.j2ee13Compliant)
/*     */         {
/*     */           
/* 130 */           timestamp = getTimestamp(paramInt);
/*     */         }
/*     */         else
/*     */         {
/* 134 */           tIMESTAMP = getTIMESTAMP(paramInt);
/*     */         }
/*     */       
/*     */       } else {
/*     */         
/* 139 */         switch (this.externalType) {
/*     */           
/*     */           case 93:
/* 142 */             return getTimestamp(paramInt);
/*     */         } 
/*     */         
/* 145 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*     */         
/* 147 */         sQLException.fillInStackTrace();
/* 148 */         throw sQLException;
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 154 */     return tIMESTAMP;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum getOracleObject(int paramInt) throws SQLException {
/* 162 */     return (Datum)getTIMESTAMP(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt, Map paramMap) throws SQLException {
/* 170 */     return getObject(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 175 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/TimestampAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */