/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.sql.SQLException;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CRowidAccessor
/*      */   extends RowidAccessor
/*      */ {
/*      */   T4CMAREngine mare;
/*      */   static final int maxLength = 128;
/*      */   final int[] meta;
/*      */   static final int KGRD_EXTENDED_OBJECT = 6;
/*      */   static final int KGRD_EXTENDED_BLOCK = 6;
/*      */   static final int KGRD_EXTENDED_FILE = 3;
/*      */   static final int KGRD_EXTENDED_SLOT = 3;
/*      */   static final int kd4_ubridtype_physical = 1;
/*      */   static final int kd4_ubridtype_logical = 2;
/*      */   static final int kd4_ubridtype_remote = 3;
/*      */   static final int kd4_ubridtype_exttab = 4;
/*      */   static final int kd4_ubridtype_future2 = 5;
/*      */   static final int kd4_ubridtype_max = 5;
/*      */   static final int kd4_ubridlen_typeind = 1;
/*      */   
/*      */   T4CRowidAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*   40 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*   95 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; this.defineType = 104; } T4CRowidAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, paramInt1, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*      */     this.mare = paramT4CMAREngine;
/*      */     this.definedColumnType = paramInt7;
/*      */     this.definedColumnSize = paramInt8;
/*      */     this.defineType = 104; }
/*      */   void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*      */       this.mare.unmarshalUB2();
/*      */       this.mare.unmarshalUB2();
/*      */     } else if (this.statement.connection.versionNumber < 9200) {
/*      */       this.mare.unmarshalSB2();
/*      */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*      */         this.mare.unmarshalSB2(); 
/*      */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*      */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*      */     }  } boolean unmarshalOneRow() throws SQLException, IOException {
/*  110 */     if (this.isUseLess) {
/*      */       
/*  112 */       this.lastRowProcessed++;
/*      */       
/*  114 */       return false;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  119 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  121 */       short s = this.mare.unmarshalUB1();
/*  122 */       long l1 = 0L;
/*  123 */       int m = 0;
/*  124 */       short s1 = 0;
/*  125 */       long l2 = 0L;
/*  126 */       int n = 0;
/*      */ 
/*      */ 
/*      */       
/*  130 */       if (s > 0) {
/*      */         
/*  132 */         l1 = this.mare.unmarshalUB4();
/*  133 */         m = this.mare.unmarshalUB2();
/*  134 */         s1 = this.mare.unmarshalUB1();
/*  135 */         l2 = this.mare.unmarshalUB4();
/*  136 */         n = this.mare.unmarshalUB2();
/*      */       } 
/*      */       
/*  139 */       processIndicator(this.meta[0]);
/*      */       
/*  141 */       this.lastRowProcessed++;
/*      */       
/*  143 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*  147 */     int i = this.indicatorIndex + this.lastRowProcessed;
/*  148 */     int j = this.lengthIndex + this.lastRowProcessed;
/*      */     
/*  150 */     if (this.isNullByDescribe) {
/*      */       
/*  152 */       this.rowSpaceIndicator[i] = -1;
/*  153 */       this.rowSpaceIndicator[j] = 0;
/*  154 */       this.lastRowProcessed++;
/*      */       
/*  156 */       if (this.statement.connection.versionNumber < 9200) {
/*  157 */         processIndicator(0);
/*      */       }
/*  159 */       return false;
/*      */     } 
/*      */     
/*  162 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  167 */     if (this.describeType != 208) {
/*      */       
/*  169 */       short s = this.mare.unmarshalUB1();
/*  170 */       long l1 = 0L;
/*  171 */       int m = 0;
/*  172 */       short s1 = 0;
/*  173 */       long l2 = 0L;
/*  174 */       int n = 0;
/*      */ 
/*      */ 
/*      */       
/*  178 */       if (s > 0) {
/*      */         
/*  180 */         l1 = this.mare.unmarshalUB4();
/*  181 */         m = this.mare.unmarshalUB2();
/*  182 */         s1 = this.mare.unmarshalUB1();
/*  183 */         l2 = this.mare.unmarshalUB4();
/*  184 */         n = this.mare.unmarshalUB2();
/*      */       } 
/*      */ 
/*      */       
/*  188 */       if (l1 == 0L && m == 0 && s1 == 0 && l2 == 0L && n == 0) {
/*      */         
/*  190 */         this.meta[0] = 0;
/*      */       } else {
/*      */         
/*  193 */         long[] arrayOfLong = { l1, m, l2, n };
/*      */ 
/*      */ 
/*      */         
/*  197 */         byte[] arrayOfByte = rowidToString(arrayOfLong);
/*  198 */         int i1 = 18;
/*      */         
/*  200 */         if (this.byteLength - 2 < 18) {
/*  201 */           i1 = this.byteLength - 2;
/*      */         }
/*  203 */         System.arraycopy(arrayOfByte, 0, this.rowSpaceByte, k + 2, i1);
/*      */ 
/*      */         
/*  206 */         this.meta[0] = i1;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  211 */       this.meta[0] = (int)this.mare.unmarshalUB4(); if ((int)this.mare.unmarshalUB4() > 0) {
/*      */         
/*  213 */         byte[] arrayOfByte = new byte[this.meta[0]];
/*  214 */         this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/*  215 */         this.meta[0] = kgrdub2c(arrayOfByte, this.meta[0], 0, this.rowSpaceByte, k + 2);
/*      */       } 
/*      */     } 
/*      */     
/*  219 */     this.rowSpaceByte[k] = (byte)((this.meta[0] & 0xFF00) >> 8);
/*  220 */     this.rowSpaceByte[k + 1] = (byte)(this.meta[0] & 0xFF);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  228 */     processIndicator(this.meta[0]);
/*      */     
/*  230 */     if (this.meta[0] == 0) {
/*      */ 
/*      */ 
/*      */       
/*  234 */       this.rowSpaceIndicator[i] = -1;
/*  235 */       this.rowSpaceIndicator[j] = 0;
/*      */     }
/*      */     else {
/*      */       
/*  239 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  244 */       this.rowSpaceIndicator[i] = 0;
/*      */     } 
/*      */     
/*  247 */     this.lastRowProcessed++;
/*      */     
/*  249 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   String getString(int paramInt) throws SQLException {
/*  260 */     String str = null;
/*      */     
/*  262 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  264 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  265 */       sQLException.fillInStackTrace();
/*  266 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  271 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/*  273 */       int i = this.columnIndex + this.byteLength * paramInt;
/*      */ 
/*      */ 
/*      */       
/*  277 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/*      */       
/*  279 */       if (this.describeType != 208 || this.rowSpaceByte[i] == 1) {
/*      */ 
/*      */         
/*  282 */         str = new String(this.rowSpaceByte, i + 2, s);
/*      */         
/*  284 */         long[] arrayOfLong = stringToRowid(str.getBytes(), 0, str.length());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  290 */         str = new String(rowidToString(arrayOfLong));
/*      */       }
/*      */       else {
/*      */         
/*  294 */         str = new String(this.rowSpaceByte, i + 2, s);
/*      */       } 
/*      */     } 
/*      */     
/*  298 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Object getObject(int paramInt) throws SQLException {
/*  306 */     if (this.definedColumnType == 0) {
/*  307 */       return super.getObject(paramInt);
/*      */     }
/*      */     
/*  310 */     Object object = null;
/*      */     
/*  312 */     if (this.rowSpaceIndicator == null) {
/*      */       
/*  314 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/*  315 */       sQLException.fillInStackTrace();
/*  316 */       throw sQLException;
/*      */     } 
/*      */     
/*  319 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*      */       
/*  321 */       switch (this.definedColumnType) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -1:
/*      */         case 1:
/*      */         case 12:
/*  332 */           return getString(paramInt);
/*      */         
/*      */         case -8:
/*  335 */           return getROWID(paramInt);
/*      */       } 
/*      */ 
/*      */       
/*  339 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/*  340 */       sQLException.fillInStackTrace();
/*  341 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  346 */     return object;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void copyRow() throws SQLException, IOException {
/*      */     int i;
/*  359 */     if (this.lastRowProcessed == 0) {
/*  360 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*      */     } else {
/*  362 */       i = this.lastRowProcessed - 1;
/*      */     } 
/*      */     
/*  365 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*  366 */     int k = this.columnIndex + i * this.byteLength;
/*  367 */     int m = this.indicatorIndex + this.lastRowProcessed;
/*  368 */     int n = this.indicatorIndex + i;
/*  369 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/*  370 */     int i2 = this.lengthIndex + i;
/*  371 */     short s = this.rowSpaceIndicator[i2];
/*  372 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*      */     
/*  374 */     int i4 = this.metaDataIndex + i * 1;
/*      */ 
/*      */ 
/*      */     
/*  378 */     this.rowSpaceIndicator[i1] = (short)s;
/*  379 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*      */ 
/*      */ 
/*      */     
/*  383 */     System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s + 2);
/*      */ 
/*      */ 
/*      */     
/*  387 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*      */ 
/*      */ 
/*      */     
/*  391 */     this.lastRowProcessed++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/*  404 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*      */     
/*  406 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*      */     
/*  408 */     int k = this.indicatorIndex + paramInt2 - 1;
/*  409 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/*  410 */     int n = this.lengthIndex + paramInt2 - 1;
/*  411 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/*  412 */     short s = paramArrayOfshort[i1];
/*      */     
/*  414 */     this.rowSpaceIndicator[n] = (short)s;
/*  415 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*      */ 
/*      */     
/*  418 */     if (s != 0)
/*      */     {
/*  420 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s + 2);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte[] rowidToString(long[] paramArrayOflong) {
/*  434 */     long l1 = paramArrayOflong[0];
/*      */ 
/*      */     
/*  437 */     long l2 = paramArrayOflong[1];
/*      */ 
/*      */     
/*  440 */     long l3 = paramArrayOflong[2];
/*      */ 
/*      */     
/*  443 */     long l4 = paramArrayOflong[3];
/*      */     
/*  445 */     byte b = 18;
/*      */ 
/*      */ 
/*      */     
/*  449 */     byte[] arrayOfByte = new byte[b];
/*  450 */     int i = 0;
/*      */     
/*  452 */     i = kgrd42b(arrayOfByte, l1, 6, i);
/*      */ 
/*      */     
/*  455 */     i = kgrd42b(arrayOfByte, l2, 3, i);
/*      */ 
/*      */     
/*  458 */     i = kgrd42b(arrayOfByte, l3, 6, i);
/*      */ 
/*      */     
/*  461 */     i = kgrd42b(arrayOfByte, l4, 3, i);
/*      */ 
/*      */ 
/*      */     
/*  465 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long[] rcToRowid(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  481 */     byte b = 18;
/*      */     
/*  483 */     if (paramInt2 != b)
/*      */     {
/*  485 */       throw new SQLException("Rowid size incorrect.");
/*      */     }
/*      */     
/*  488 */     long[] arrayOfLong = new long[3];
/*  489 */     String str = new String(paramArrayOfbyte, paramInt1, paramInt2);
/*      */ 
/*      */     
/*  492 */     long l1 = Long.parseLong(str.substring(0, 8), 16);
/*  493 */     long l2 = Long.parseLong(str.substring(9, 13), 16);
/*  494 */     long l3 = Long.parseLong(str.substring(14, 8), 16);
/*      */     
/*  496 */     arrayOfLong[0] = l3;
/*  497 */     arrayOfLong[1] = l1;
/*  498 */     arrayOfLong[2] = l2;
/*      */     
/*  500 */     return arrayOfLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final void kgrdr2rc(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfbyte, int paramInt6) throws SQLException {
/*  520 */     paramInt6 = lmx42h(paramArrayOfbyte, paramInt4, 8, paramInt6);
/*  521 */     paramArrayOfbyte[paramInt6++] = 46;
/*      */     
/*  523 */     paramInt6 = lmx42h(paramArrayOfbyte, paramInt5, 4, paramInt6);
/*  524 */     paramArrayOfbyte[paramInt6++] = 46;
/*      */     
/*  526 */     paramInt6 = lmx42h(paramArrayOfbyte, paramInt2, 4, paramInt6);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int lmx42h(byte[] paramArrayOfbyte, long paramLong, int paramInt1, int paramInt2) {
/*  541 */     String str = Long.toHexString(paramLong).toUpperCase();
/*      */ 
/*      */     
/*  544 */     int i = paramInt1;
/*  545 */     byte b = 0;
/*      */ 
/*      */     
/*      */     do {
/*  549 */       if (b < str.length())
/*      */       {
/*  551 */         paramArrayOfbyte[paramInt2 + paramInt1 - 1] = (byte)str.charAt(str.length() - b - 1);
/*      */         
/*  553 */         b++;
/*      */       }
/*      */       else
/*      */       {
/*  557 */         paramArrayOfbyte[paramInt2 + paramInt1 - 1] = 48;
/*      */       }
/*      */     
/*  560 */     } while (--paramInt1 > 0);
/*      */     
/*  562 */     return i + paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrdc2ub(byte[] paramArrayOfbyte1, int paramInt1, byte[] paramArrayOfbyte2, int paramInt2, int paramInt3) throws SQLException {
/*  579 */     byte b = getRowidType(paramArrayOfbyte1, paramInt1);
/*  580 */     byte[] arrayOfByte1 = paramArrayOfbyte2;
/*  581 */     int i = paramInt3 - 1;
/*  582 */     int j = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  587 */     byte[] arrayOfByte2 = kgrd_index_64;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  594 */     int k = 1 + 3 * (paramInt3 - 1) / 4 + (((paramInt3 - 1) % 4 != 0) ? ((paramInt3 - 1) % 4 - 1) : 0);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  600 */     if (i == 0) {
/*      */ 
/*      */       
/*  603 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  604 */       sQLException.fillInStackTrace();
/*  605 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  610 */     arrayOfByte1[paramInt2 + 0] = b;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  618 */     j = paramInt1 + 1;
/*  619 */     byte b1 = 1;
/*      */     
/*  621 */     while (i > 0) {
/*      */ 
/*      */       
/*  624 */       if (i == 1) {
/*      */ 
/*      */         
/*  627 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  628 */         sQLException.fillInStackTrace();
/*  629 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  634 */       byte b2 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  635 */       if (b2 == -1) {
/*      */ 
/*      */         
/*  638 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  639 */         sQLException.fillInStackTrace();
/*  640 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  644 */       j++;
/*  645 */       byte b3 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  646 */       if (b3 == -1) {
/*      */ 
/*      */         
/*  649 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  650 */         sQLException.fillInStackTrace();
/*  651 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  659 */       arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0xFF) << 2 | (b3 & 0x30) >> 4);
/*      */ 
/*      */       
/*  662 */       if (i == 2) {
/*      */         break;
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  669 */       b1++;
/*  670 */       b2 = b3;
/*  671 */       j++;
/*  672 */       b3 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  673 */       if (b3 == -1) {
/*      */ 
/*      */         
/*  676 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  677 */         sQLException.fillInStackTrace();
/*  678 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/*  682 */       arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0xFF) << 4 | (b3 & 0x3C) >> 2);
/*      */ 
/*      */       
/*  685 */       if (i == 3) {
/*      */         break;
/*      */       }
/*      */ 
/*      */       
/*  690 */       b1++;
/*  691 */       b2 = b3;
/*  692 */       j++;
/*  693 */       b3 = arrayOfByte2[paramArrayOfbyte1[j]];
/*  694 */       if (b3 == -1) {
/*      */ 
/*      */         
/*  697 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 132);
/*  698 */         sQLException.fillInStackTrace();
/*  699 */         throw sQLException;
/*      */       } 
/*      */       
/*  702 */       arrayOfByte1[paramInt2 + b1] = (byte)((b2 & 0x3) << 6 | b3);
/*      */ 
/*      */ 
/*      */       
/*  706 */       i -= 4;
/*  707 */       j++;
/*  708 */       b1++;
/*      */     } 
/*      */     
/*  711 */     return k;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long[] stringToRowid(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  721 */     byte b = 18;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  726 */     if (paramInt2 != b)
/*      */     {
/*  728 */       throw new SQLException("Rowid size incorrect.");
/*      */     }
/*      */     
/*  731 */     long[] arrayOfLong = new long[4];
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  737 */       arrayOfLong[0] = kgrdb42(paramArrayOfbyte, 6, paramInt1);
/*      */ 
/*      */       
/*  740 */       paramInt1 += 6;
/*      */ 
/*      */       
/*  743 */       arrayOfLong[1] = kgrdb42(paramArrayOfbyte, 3, paramInt1);
/*      */ 
/*      */       
/*  746 */       paramInt1 += 3;
/*      */ 
/*      */       
/*  749 */       arrayOfLong[2] = kgrdb42(paramArrayOfbyte, 6, paramInt1);
/*      */ 
/*      */       
/*  752 */       paramInt1 += 6;
/*      */ 
/*      */       
/*  755 */       arrayOfLong[3] = kgrdb42(paramArrayOfbyte, 3, paramInt1);
/*      */ 
/*      */       
/*  758 */       paramInt1 += 3;
/*      */     }
/*  760 */     catch (Exception exception) {
/*      */       
/*  762 */       arrayOfLong[0] = 0L;
/*  763 */       arrayOfLong[1] = 0L;
/*  764 */       arrayOfLong[2] = 0L;
/*  765 */       arrayOfLong[3] = 0L;
/*      */     } 
/*      */     
/*  768 */     return arrayOfLong;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrd42b(byte[] paramArrayOfbyte, long paramLong, int paramInt1, int paramInt2) {
/*  780 */     int i = paramInt1;
/*  781 */     long l = paramLong;
/*      */     
/*  783 */     for (; paramInt1 > 0; paramInt1--) {
/*      */       
/*  785 */       paramArrayOfbyte[paramInt2 + paramInt1 - 1] = kgrd_basis_64[(int)l & 0x3F];
/*  786 */       l = l >>> 6L & 0x3FFFFFFL;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  792 */     return i + paramInt2;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final long kgrdb42(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException {
/*  803 */     long l = 0L;
/*      */     
/*  805 */     for (byte b = 0; b < paramInt1; b++) {
/*      */       
/*  807 */       byte b1 = paramArrayOfbyte[paramInt2 + b];
/*      */       
/*  809 */       b1 = kgrd_index_64[b1];
/*      */       
/*  811 */       if (b1 == -1) {
/*  812 */         throw new SQLException("Char data to rowid conversion failed.");
/*      */       }
/*  814 */       l <<= 6L;
/*  815 */       l |= b1;
/*      */     } 
/*      */     
/*  818 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final void kgrdr2ec(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, byte[] paramArrayOfbyte, int paramInt6) throws SQLException {
/*  831 */     paramInt6 = kgrd42b(paramInt1, paramArrayOfbyte, paramInt6, 6);
/*  832 */     paramInt6 = kgrd42b(paramInt2, paramArrayOfbyte, paramInt6, 3);
/*  833 */     paramInt6 = kgrd42b(paramInt4, paramArrayOfbyte, paramInt6, 6);
/*  834 */     paramInt6 = kgrd42b(paramInt5, paramArrayOfbyte, paramInt6, 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrd42b(int paramInt1, byte[] paramArrayOfbyte, int paramInt2, int paramInt3) throws SQLException {
/*  845 */     int i = paramInt3;
/*  846 */     while (paramInt3 > 0) {
/*      */       
/*  848 */       paramInt3--;
/*  849 */       paramArrayOfbyte[paramInt2 + paramInt3] = kgrd_basis_64[paramInt1 & 0x3F];
/*      */       
/*  851 */       paramInt1 >>= 6;
/*      */     } 
/*      */     
/*  854 */     return paramInt2 + i;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   static final int kgrdub2c(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3) throws SQLException {
/*  867 */     byte b = -1;
/*  868 */     byte b1 = paramArrayOfbyte1[paramInt2];
/*      */     
/*  870 */     if (b1 == 1) {
/*      */ 
/*      */ 
/*      */       
/*  874 */       int[] arrayOfInt = new int[paramArrayOfbyte1.length]; int i;
/*  875 */       for (i = 0; i < paramArrayOfbyte1.length; ) { arrayOfInt[i] = paramArrayOfbyte1[i] & 0xFF; i++; }
/*      */       
/*  877 */       i = paramInt2 + 1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  885 */       int j = (((arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1] << 8) + arrayOfInt[i + 2] << 8) + arrayOfInt[i + 3];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  890 */       i = paramInt2 + 5;
/*      */       
/*  892 */       int k = (arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1];
/*  893 */       boolean bool = false;
/*      */ 
/*      */       
/*  896 */       i = paramInt2 + 7;
/*  897 */       int m = (((arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1] << 8) + arrayOfInt[i + 2] << 8) + arrayOfInt[i + 3];
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  902 */       i = paramInt2 + 11;
/*      */       
/*  904 */       int n = (arrayOfInt[i + 0] << 8) + arrayOfInt[i + 1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  913 */       if (j == 0) {
/*  914 */         kgrdr2rc(j, k, bool, m, n, paramArrayOfbyte2, paramInt3);
/*      */ 
/*      */       
/*      */       }
/*      */       else {
/*      */ 
/*      */ 
/*      */         
/*  922 */         kgrdr2ec(j, k, bool, m, n, paramArrayOfbyte2, paramInt3);
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  930 */       b = 18;
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/*  936 */       byte b2 = 0;
/*  937 */       int i = paramInt1 - 1;
/*  938 */       int j = 4 * paramInt1 / 3 + ((paramInt1 % 3 == 0) ? (paramInt1 % 3 + 1) : 0);
/*      */       
/*  940 */       int k = 1 + j - 1;
/*      */       
/*  942 */       if (k != 0) {
/*      */         
/*  944 */         paramArrayOfbyte2[paramInt3 + 0] = kgrd_indbyte_char[b1 - 1];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  958 */         int m = paramInt2 + 1;
/*      */         
/*  960 */         b2 = 1;
/*      */         
/*  962 */         byte b3 = 0;
/*      */         
/*  964 */         while (i > 0) {
/*      */           
/*  966 */           paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0xFF) >> 2];
/*      */ 
/*      */ 
/*      */           
/*  970 */           if (i == 1) {
/*      */ 
/*      */ 
/*      */             
/*  974 */             paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0x3) << 4];
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */ 
/*      */           
/*  981 */           b3 = (byte)(paramArrayOfbyte1[m + 1] & 0xFF);
/*      */           
/*  983 */           paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(paramArrayOfbyte1[m] & 0x3) << 4 | (b3 & 0xF0) >> 4];
/*      */ 
/*      */ 
/*      */           
/*  987 */           if (i == 2) {
/*      */             
/*  989 */             paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(b3 & 0xF) << 2];
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*      */             break;
/*      */           } 
/*      */ 
/*      */ 
/*      */           
/*  999 */           m += 2;
/* 1000 */           paramArrayOfbyte2[paramInt3 + b2++] = kgrd_basis_64[(b3 & 0xF) << 2 | (paramArrayOfbyte1[m] & 0xC0) >> 6];
/*      */ 
/*      */ 
/*      */           
/* 1004 */           paramArrayOfbyte2[paramInt3 + b2] = kgrd_basis_64[paramArrayOfbyte1[m] & 0x3F];
/*      */ 
/*      */ 
/*      */           
/* 1008 */           i -= 3;
/* 1009 */           m++;
/* 1010 */           b2++;
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1016 */       b = b2;
/*      */     } 
/*      */     
/* 1019 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final boolean isUROWID(byte[] paramArrayOfbyte, int paramInt) {
/* 1025 */     return (getRowidType(paramArrayOfbyte, paramInt) == 2);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   static final byte getRowidType(byte[] paramArrayOfbyte, int paramInt) {
/* 1031 */     byte b = 5;
/* 1032 */     switch (paramArrayOfbyte[paramInt]) {
/*      */       
/*      */       case 65:
/* 1035 */         b = 1;
/*      */         break;
/*      */       
/*      */       case 42:
/* 1039 */         b = 2;
/*      */         break;
/*      */       
/*      */       case 45:
/* 1043 */         b = 3;
/*      */         break;
/*      */       
/*      */       case 40:
/* 1047 */         b = 4;
/*      */         break;
/*      */       
/*      */       case 41:
/* 1051 */         b = 5;
/*      */         break;
/*      */     } 
/*      */     
/* 1055 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1083 */   static final byte[] kgrd_indbyte_char = new byte[] { 65, 42, 45, 40, 41 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1090 */   static final byte[] kgrd_basis_64 = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1105 */   static final byte[] kgrd_index_64 = new byte[] { -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -1, -1, -1, -1, -1 };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/* 1131 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/T4CRowidAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */