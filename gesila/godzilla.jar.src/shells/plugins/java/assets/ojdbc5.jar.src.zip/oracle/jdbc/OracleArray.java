package oracle.jdbc;

import java.sql.Array;
import java.sql.SQLException;

public interface OracleArray extends Array {
  OracleTypeMetaData getOracleMetaData() throws SQLException;
  
  int length() throws SQLException;
  
  String getSQLTypeName() throws SQLException;
  
  Object toJdbc() throws SQLException;
  
  int[] getIntArray() throws SQLException;
  
  int[] getIntArray(long paramLong, int paramInt) throws SQLException;
  
  double[] getDoubleArray() throws SQLException;
  
  double[] getDoubleArray(long paramLong, int paramInt) throws SQLException;
  
  short[] getShortArray() throws SQLException;
  
  short[] getShortArray(long paramLong, int paramInt) throws SQLException;
  
  long[] getLongArray() throws SQLException;
  
  long[] getLongArray(long paramLong, int paramInt) throws SQLException;
  
  float[] getFloatArray() throws SQLException;
  
  float[] getFloatArray(long paramLong, int paramInt) throws SQLException;
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/OracleArray.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */