/*    */ package oracle.jdbc.pool;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class OracleGravitateConnectionCacheThread
/*    */   extends Thread
/*    */ {
/* 23 */   protected OracleImplicitConnectionCache implicitCache = null;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   OracleGravitateConnectionCacheThread(OracleImplicitConnectionCache paramOracleImplicitConnectionCache) throws SQLException {
/* 30 */     this.implicitCache = paramOracleImplicitConnectionCache;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void run() {
/* 38 */     this.implicitCache.gravitateCache();
/*    */   }
/*    */ 
/*    */ 
/*    */   
/* 43 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*    */   public static final boolean TRACE = false;
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/pool/OracleGravitateConnectionCacheThread.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */