/*     */ package oracle.jdbc.connector;
/*     */ 
/*     */ import java.io.PrintWriter;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.ConnectionManager;
/*     */ import javax.resource.spi.ConnectionRequestInfo;
/*     */ import javax.resource.spi.EISSystemException;
/*     */ import javax.resource.spi.ManagedConnection;
/*     */ import javax.resource.spi.ManagedConnectionFactory;
/*     */ import javax.resource.spi.ResourceAdapterInternalException;
/*     */ import javax.resource.spi.SecurityException;
/*     */ import javax.resource.spi.security.PasswordCredential;
/*     */ import javax.security.auth.Subject;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.sql.XADataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleManagedConnectionFactory
/*     */   implements ManagedConnectionFactory
/*     */ {
/*  44 */   private XADataSource xaDataSource = null;
/*  45 */   private String xaDataSourceName = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String RAERR_MCF_SET_XADS = "invalid xads";
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String RAERR_MCF_GET_PCRED = "no password credential";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleManagedConnectionFactory() throws ResourceException {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleManagedConnectionFactory(XADataSource paramXADataSource) throws ResourceException {
/*  65 */     this.xaDataSource = paramXADataSource;
/*  66 */     this.xaDataSourceName = "XADataSource";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXADataSourceName(String paramString) {
/*  75 */     this.xaDataSourceName = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getXADataSourceName() {
/*  84 */     return this.xaDataSourceName;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createConnectionFactory(ConnectionManager paramConnectionManager) throws ResourceException {
/* 104 */     if (this.xaDataSource == null)
/*     */     {
/* 106 */       setupXADataSource();
/*     */     }
/*     */     
/* 109 */     return this.xaDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Object createConnectionFactory() throws ResourceException {
/* 127 */     return createConnectionFactory(null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ManagedConnection createManagedConnection(Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
/*     */     try {
/* 152 */       if (this.xaDataSource == null)
/*     */       {
/* 154 */         setupXADataSource();
/*     */       }
/*     */       
/* 157 */       XAConnection xAConnection = null;
/* 158 */       PasswordCredential passwordCredential = getPasswordCredential(paramSubject, paramConnectionRequestInfo);
/*     */       
/* 160 */       if (passwordCredential == null) {
/*     */         
/* 162 */         xAConnection = this.xaDataSource.getXAConnection();
/*     */       }
/*     */       else {
/*     */         
/* 166 */         xAConnection = this.xaDataSource.getXAConnection(passwordCredential.getUserName(), new String(passwordCredential.getPassword()));
/*     */       } 
/*     */ 
/*     */       
/* 170 */       OracleManagedConnection oracleManagedConnection = new OracleManagedConnection(xAConnection);
/*     */       
/* 172 */       oracleManagedConnection.setPasswordCredential(passwordCredential);
/*     */ 
/*     */       
/* 175 */       oracleManagedConnection.setLogWriter(getLogWriter());
/*     */       
/* 177 */       return oracleManagedConnection;
/*     */     }
/* 179 */     catch (SQLException sQLException) {
/*     */       
/* 181 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 184 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 186 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ManagedConnection matchManagedConnections(Set paramSet, Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
/* 214 */     PasswordCredential passwordCredential = getPasswordCredential(paramSubject, paramConnectionRequestInfo);
/* 215 */     Iterator<Object> iterator = paramSet.iterator();
/*     */     
/* 217 */     while (iterator.hasNext()) {
/*     */       
/* 219 */       OracleManagedConnection oracleManagedConnection = (OracleManagedConnection)iterator.next();
/*     */       
/* 221 */       if (oracleManagedConnection instanceof OracleManagedConnection) {
/*     */         
/* 223 */         OracleManagedConnection oracleManagedConnection1 = oracleManagedConnection;
/*     */ 
/*     */         
/* 226 */         if (oracleManagedConnection1.getPasswordCredential().equals(passwordCredential))
/*     */         {
/* 228 */           return oracleManagedConnection1;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 233 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLogWriter(PrintWriter paramPrintWriter) throws ResourceException {
/*     */     try {
/* 253 */       if (this.xaDataSource == null)
/*     */       {
/* 255 */         setupXADataSource();
/*     */       }
/*     */       
/* 258 */       this.xaDataSource.setLogWriter(paramPrintWriter);
/*     */     }
/* 260 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 264 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 267 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 269 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PrintWriter getLogWriter() throws ResourceException {
/*     */     try {
/* 289 */       if (this.xaDataSource == null)
/*     */       {
/* 291 */         setupXADataSource();
/*     */       }
/*     */       
/* 294 */       return this.xaDataSource.getLogWriter();
/*     */     }
/* 296 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 300 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 303 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 305 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setupXADataSource() throws ResourceException {
/*     */     try {
/* 352 */       InitialContext initialContext = null;
/*     */ 
/*     */       
/*     */       try {
/* 356 */         Properties properties = System.getProperties();
/*     */         
/* 358 */         initialContext = new InitialContext(properties);
/*     */       }
/* 360 */       catch (SecurityException securityException) {}
/*     */ 
/*     */ 
/*     */       
/* 364 */       if (initialContext == null)
/*     */       {
/* 366 */         initialContext = new InitialContext();
/*     */       }
/*     */       
/* 369 */       XADataSource xADataSource = (XADataSource)initialContext.lookup(this.xaDataSourceName);
/*     */       
/* 371 */       if (xADataSource == null)
/*     */       {
/* 373 */         throw new ResourceAdapterInternalException("Invalid XADataSource object");
/*     */       }
/*     */       
/* 376 */       this.xaDataSource = xADataSource;
/*     */     }
/* 378 */     catch (NamingException namingException) {
/*     */       
/* 380 */       ResourceException resourceException = new ResourceException("NamingException: " + namingException.getMessage());
/*     */ 
/*     */       
/* 383 */       resourceException.setLinkedException(namingException);
/*     */       
/* 385 */       throw resourceException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PasswordCredential getPasswordCredential(Subject paramSubject, ConnectionRequestInfo paramConnectionRequestInfo) throws ResourceException {
/* 398 */     if (paramSubject != null) {
/*     */ 
/*     */ 
/*     */       
/* 402 */       Set<PasswordCredential> set = paramSubject.getPrivateCredentials(PasswordCredential.class);
/* 403 */       Iterator<PasswordCredential> iterator = set.iterator();
/*     */       
/* 405 */       while (iterator.hasNext()) {
/*     */         
/* 407 */         PasswordCredential passwordCredential1 = iterator.next();
/*     */         
/* 409 */         if (passwordCredential1.getManagedConnectionFactory().equals(this))
/*     */         {
/* 411 */           return passwordCredential1;
/*     */         }
/*     */       } 
/*     */       
/* 415 */       throw new SecurityException("Can not find user/password information", "no password credential");
/*     */     } 
/*     */ 
/*     */     
/* 419 */     if (paramConnectionRequestInfo == null)
/*     */     {
/* 421 */       return null;
/*     */     }
/*     */ 
/*     */     
/* 425 */     OracleConnectionRequestInfo oracleConnectionRequestInfo = (OracleConnectionRequestInfo)paramConnectionRequestInfo;
/*     */     
/* 427 */     PasswordCredential passwordCredential = new PasswordCredential(oracleConnectionRequestInfo.getUser(), oracleConnectionRequestInfo.getPassword().toCharArray());
/*     */ 
/*     */     
/* 430 */     passwordCredential.setManagedConnectionFactory(this);
/*     */     
/* 432 */     return passwordCredential;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 441 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/connector/OracleManagedConnectionFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */