package oracle.jdbc.internal;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.driver.OracleConnection;

public interface OracleDatumWithConnection {
  byte[] shareBytes();
  
  long getLength();
  
  void setBytes(byte[] paramArrayOfbyte);
  
  void setShareBytes(byte[] paramArrayOfbyte);
  
  byte[] getBytes();
  
  InputStream getStream() throws SQLException;
  
  String stringValue() throws SQLException;
  
  String stringValue(Connection paramConnection) throws SQLException;
  
  boolean booleanValue() throws SQLException;
  
  int intValue() throws SQLException;
  
  long longValue() throws SQLException;
  
  float floatValue() throws SQLException;
  
  double doubleValue() throws SQLException;
  
  byte byteValue() throws SQLException;
  
  BigDecimal bigDecimalValue() throws SQLException;
  
  Date dateValue() throws SQLException;
  
  Time timeValue() throws SQLException;
  
  Time timeValue(Calendar paramCalendar) throws SQLException;
  
  Timestamp timestampValue() throws SQLException;
  
  Timestamp timestampValue(Calendar paramCalendar) throws SQLException;
  
  Reader characterStreamValue() throws SQLException;
  
  InputStream asciiStreamValue() throws SQLException;
  
  InputStream binaryStreamValue() throws SQLException;
  
  boolean isConvertibleTo(Class paramClass);
  
  Object toJdbc() throws SQLException;
  
  Object makeJdbcArray(int paramInt);
  
  Connection getJavaSqlConnection() throws SQLException;
  
  OracleConnection getOracleConnection() throws SQLException;
  
  OracleConnection getInternalConnection() throws SQLException;
  
  OracleConnection getConnection() throws SQLException;
  
  void setPhysicalConnectionOf(Connection paramConnection);
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/internal/OracleDatumWithConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */