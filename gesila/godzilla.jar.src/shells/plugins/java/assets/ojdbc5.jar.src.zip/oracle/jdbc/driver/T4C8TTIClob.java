/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.sql.CLOB;
/*     */ import oracle.sql.CharacterSet;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.NCLOB;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ final class T4C8TTIClob
/*     */   extends T4C8TTILob
/*     */ {
/*     */   int[] nBytes;
/*     */   
/*     */   T4C8TTIClob(T4CConnection paramT4CConnection) {
/* 148 */     super(paramT4CConnection);
/*     */     
/* 150 */     this.nBytes = new int[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long read(byte[] paramArrayOfbyte, long paramLong1, long paramLong2, boolean paramBoolean, char[] paramArrayOfchar, int paramInt) throws SQLException, IOException {
/* 185 */     long l1 = 0L;
/* 186 */     long l2 = paramLong2;
/* 187 */     boolean bool = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 199 */     byte[] arrayOfByte = null;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 204 */       initializeLobdef();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 212 */       if ((paramArrayOfbyte[6] & 0x80) == 128) {
/* 213 */         bool = true;
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 220 */       int i = 0;
/* 221 */       if (bool == true) {
/* 222 */         i = (int)paramLong2 * 2;
/*     */       } else {
/* 224 */         i = (int)paramLong2 * 3;
/*     */       } 
/*     */       
/* 227 */       arrayOfByte = this.connection.getByteBuffer(i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 235 */       if ((paramArrayOfbyte[7] & 0x40) > 0) {
/* 236 */         this.littleEndianClob = true;
/*     */       }
/*     */ 
/*     */       
/* 240 */       this.lobops = 2L;
/* 241 */       this.sourceLobLocator = paramArrayOfbyte;
/* 242 */       this.sourceOffset = paramLong1;
/* 243 */       this.lobamt = paramLong2;
/* 244 */       this.sendLobamt = true;
/* 245 */       this.outBuffer = arrayOfByte;
/*     */       
/* 247 */       doRPC();
/*     */       
/* 249 */       l2 = this.lobamt;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 255 */       long l = 0L;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 260 */       if (bool == true)
/*     */       {
/* 262 */         if (this.connection.versionNumber < 10101)
/*     */         {
/*     */ 
/*     */           
/* 266 */           DBConversion.ucs2BytesToJavaChars(this.outBuffer, (int)this.lobBytesRead, paramArrayOfchar);
/*     */         
/*     */         }
/* 269 */         else if (this.littleEndianClob)
/*     */         {
/* 271 */           CharacterSet.convertAL16UTF16LEBytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, (int)this.lobBytesRead, true);
/*     */         
/*     */         }
/*     */         else
/*     */         {
/* 276 */           CharacterSet.convertAL16UTF16BytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, (int)this.lobBytesRead, true);
/*     */ 
/*     */         
/*     */         }
/*     */ 
/*     */ 
/*     */       
/*     */       }
/* 284 */       else if (!paramBoolean)
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 289 */         this.nBytes[0] = (int)this.lobBytesRead;
/*     */         
/* 291 */         this.meg.conv.CHARBytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, this.nBytes, paramArrayOfchar.length);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       else
/*     */       {
/*     */ 
/*     */ 
/*     */         
/* 302 */         this.nBytes[0] = (int)this.lobBytesRead;
/*     */         
/* 304 */         this.meg.conv.NCHARBytesToJavaChars(this.outBuffer, 0, paramArrayOfchar, paramInt, this.nBytes, paramArrayOfchar.length);
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     finally {
/*     */       
/* 311 */       this.outBuffer = null;
/* 312 */       this.connection.cacheBuffer(arrayOfByte);
/*     */     } 
/*     */     
/* 315 */     return l2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   long write(byte[] paramArrayOfbyte, long paramLong1, boolean paramBoolean, char[] paramArrayOfchar, long paramLong2, long paramLong3) throws SQLException, IOException {
/* 357 */     boolean bool = false;
/* 358 */     if ((paramArrayOfbyte[6] & 0x80) == 128) {
/* 359 */       bool = true;
/*     */     }
/* 361 */     if ((paramArrayOfbyte[7] & 0x40) == 64) {
/* 362 */       this.littleEndianClob = true;
/*     */     }
/*     */ 
/*     */     
/* 366 */     long l = 0L;
/* 367 */     byte[] arrayOfByte = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 373 */     if (bool == true) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 378 */       arrayOfByte = new byte[(int)paramLong3 * 2];
/*     */       
/* 380 */       if (this.connection.versionNumber < 10101)
/*     */       {
/* 382 */         DBConversion.javaCharsToUcs2Bytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       }
/* 384 */       else if (this.littleEndianClob)
/*     */       {
/* 386 */         CharacterSet.convertJavaCharsToAL16UTF16LEBytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       }
/*     */       else
/*     */       {
/* 390 */         CharacterSet.convertJavaCharsToAL16UTF16Bytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       
/*     */       }
/*     */ 
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 398 */       arrayOfByte = new byte[(int)paramLong3 * 3];
/*     */       
/* 400 */       if (!paramBoolean) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 405 */         l = this.meg.conv.javaCharsToCHARBytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */ 
/*     */       
/*     */       }
/*     */       else {
/*     */ 
/*     */ 
/*     */         
/* 413 */         l = this.meg.conv.javaCharsToNCHARBytes(paramArrayOfchar, (int)paramLong2, arrayOfByte, 0, (int)paramLong3);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 420 */     initializeLobdef();
/*     */ 
/*     */     
/* 423 */     this.lobops = 64L;
/* 424 */     this.sourceLobLocator = paramArrayOfbyte;
/* 425 */     this.sourceOffset = paramLong1;
/* 426 */     this.lobamt = paramLong3;
/* 427 */     this.sendLobamt = true;
/* 428 */     this.inBuffer = arrayOfByte;
/* 429 */     this.inBufferOffset = 0L;
/*     */ 
/*     */ 
/*     */     
/* 433 */     if (bool == true) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 438 */       if (this.connection.versionNumber < 10101) {
/* 439 */         this.inBufferNumBytes = paramLong3;
/*     */       } else {
/* 441 */         this.inBufferNumBytes = paramLong3 * 2L;
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 448 */       this.inBufferNumBytes = l;
/*     */     } 
/* 450 */     doRPC();
/*     */     
/* 452 */     return this.lobamt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException, IOException {
/* 474 */     return createTemporaryLob(paramConnection, paramBoolean, paramInt, (short)1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Datum createTemporaryLob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException, IOException {
/*     */     NCLOB nCLOB;
/* 489 */     if (paramInt == 12) {
/*     */       
/* 491 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 158);
/* 492 */       sQLException.fillInStackTrace();
/* 493 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 498 */     CLOB cLOB = null;
/*     */ 
/*     */     
/* 501 */     initializeLobdef();
/*     */ 
/*     */     
/* 504 */     this.lobops = 272L;
/* 505 */     this.sourceLobLocator = new byte[40];
/* 506 */     this.sourceLobLocator[1] = 84;
/*     */ 
/*     */     
/* 509 */     if (paramShort == 1) {
/* 510 */       this.sourceOffset = 1L;
/*     */     } else {
/* 512 */       this.sourceOffset = 2L;
/*     */     } 
/*     */ 
/*     */     
/* 516 */     this.destinationOffset = 112L;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 525 */     this.destinationLength = paramInt;
/*     */     
/* 527 */     this.lobamt = paramInt;
/* 528 */     this.sendLobamt = true;
/*     */ 
/*     */     
/* 531 */     this.nullO2U = true;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 536 */     this.characterSet = (paramShort == 2) ? this.meg.conv.getNCharSetId() : this.meg.conv.getServerCharSetId();
/*     */     
/* 538 */     if (this.connection.versionNumber >= 9000) {
/*     */       
/* 540 */       this.lobscn = new int[1];
/* 541 */       this.lobscn[0] = paramBoolean ? 1 : 0;
/* 542 */       this.lobscnl = 1;
/*     */     } 
/*     */     
/* 545 */     doRPC();
/*     */ 
/*     */ 
/*     */     
/* 549 */     if (this.sourceLobLocator != null)
/*     */     {
/* 551 */       if (paramShort == 1) {
/* 552 */         cLOB = new CLOB((OracleConnection)paramConnection, this.sourceLobLocator);
/*     */       }
/*     */       else {
/*     */         
/* 556 */         nCLOB = new NCLOB((OracleConnection)paramConnection, this.sourceLobLocator);
/*     */       } 
/*     */     }
/*     */     
/* 560 */     return (Datum)nCLOB;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean open(byte[] paramArrayOfbyte, int paramInt) throws SQLException, IOException {
/* 579 */     boolean bool = false;
/*     */ 
/*     */ 
/*     */     
/* 583 */     byte b = 2;
/*     */     
/* 585 */     if (paramInt == 0) {
/* 586 */       b = 1;
/*     */     }
/* 588 */     bool = _open(paramArrayOfbyte, b, 32768);
/*     */     
/* 590 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean close(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 608 */     boolean bool = false;
/*     */     
/* 610 */     bool = _close(paramArrayOfbyte, 65536);
/*     */     
/* 612 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean isOpen(byte[] paramArrayOfbyte) throws SQLException, IOException {
/* 631 */     boolean bool = false;
/*     */     
/* 633 */     bool = _isOpen(paramArrayOfbyte, 69632);
/*     */     
/* 635 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 640 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/T4C8TTIClob.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */