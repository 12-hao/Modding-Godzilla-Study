/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4CIntervaldsAccessor
/*     */   extends IntervaldsAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*  24 */   static int maxLength = 11;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   final int[] meta;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   T4CIntervaldsAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, boolean paramBoolean, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  46 */     super(paramOracleStatement, maxLength, paramShort, paramInt2, paramBoolean);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 116 */     this.meta = new int[1]; this.mare = paramT4CMAREngine; } T4CIntervaldsAccessor(OracleStatement paramOracleStatement, int paramInt1, boolean paramBoolean, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, short paramShort, int paramInt7, int paramInt8, T4CMAREngine paramT4CMAREngine) throws SQLException { super(paramOracleStatement, maxLength, paramBoolean, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, paramShort); this.meta = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */     this.definedColumnType = paramInt7;
/*     */     this.definedColumnSize = paramInt8; } void processIndicator(int paramInt) throws IOException, SQLException {
/*     */     if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2();
/*     */       this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     } 
/*     */   } boolean unmarshalOneRow() throws SQLException, IOException {
/* 131 */     if (this.isUseLess) {
/*     */       
/* 133 */       this.lastRowProcessed++;
/*     */       
/* 135 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 140 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 144 */       byte[] arrayOfByte = new byte[16000];
/*     */       
/* 146 */       this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/* 147 */       processIndicator(this.meta[0]);
/*     */       
/* 149 */       this.lastRowProcessed++;
/*     */       
/* 151 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 155 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 156 */     int j = this.lengthIndex + this.lastRowProcessed;
/*     */ 
/*     */ 
/*     */     
/* 160 */     if (this.isNullByDescribe) {
/*     */       
/* 162 */       this.rowSpaceIndicator[i] = -1;
/* 163 */       this.rowSpaceIndicator[j] = 0;
/* 164 */       this.lastRowProcessed++;
/*     */       
/* 166 */       if (this.statement.connection.versionNumber < 9200) {
/* 167 */         processIndicator(0);
/*     */       }
/* 169 */       return false;
/*     */     } 
/*     */     
/* 172 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*     */ 
/*     */ 
/*     */     
/* 176 */     this.mare.unmarshalCLR(this.rowSpaceByte, k, this.meta, this.byteLength);
/*     */     
/* 178 */     processIndicator(this.meta[0]);
/*     */     
/* 180 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 184 */       this.rowSpaceIndicator[i] = -1;
/* 185 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 189 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/* 190 */       this.rowSpaceIndicator[i] = 0;
/*     */     } 
/*     */     
/* 193 */     this.lastRowProcessed++;
/*     */     
/* 195 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void copyRow() throws SQLException, IOException {
/*     */     int i;
/* 205 */     if (this.lastRowProcessed == 0) {
/* 206 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 208 */       i = this.lastRowProcessed - 1;
/*     */     } 
/*     */     
/* 211 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/* 212 */     int k = this.columnIndex + i * this.byteLength;
/* 213 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 214 */     int n = this.indicatorIndex + i;
/* 215 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 216 */     int i2 = this.lengthIndex + i;
/* 217 */     short s = this.rowSpaceIndicator[i2];
/* 218 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 220 */     int i4 = this.metaDataIndex + i * 1;
/*     */ 
/*     */ 
/*     */     
/* 224 */     this.rowSpaceIndicator[i1] = (short)s;
/* 225 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */ 
/*     */     
/* 228 */     if (!this.isNullByDescribe)
/*     */     {
/* 230 */       System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 235 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*     */ 
/*     */     
/* 238 */     this.lastRowProcessed++;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/* 250 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*     */     
/* 252 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*     */     
/* 254 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 255 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 256 */     int n = this.lengthIndex + paramInt2 - 1;
/* 257 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 258 */     short s = paramArrayOfshort[i1];
/*     */     
/* 260 */     this.rowSpaceIndicator[n] = (short)s;
/* 261 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*     */ 
/*     */     
/* 264 */     if (s != 0)
/*     */     {
/* 266 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 284 */     String str = super.getString(paramInt);
/*     */     
/* 286 */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/*     */     {
/* 288 */       str = str.substring(0, this.definedColumnSize);
/*     */     }
/* 290 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 299 */     if (this.definedColumnType == 0) {
/* 300 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 303 */     Object object = null;
/*     */     
/* 305 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 307 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 308 */       sQLException.fillInStackTrace();
/* 309 */       throw sQLException;
/*     */     } 
/*     */     
/* 312 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 314 */       switch (this.definedColumnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case -1:
/*     */         case 1:
/*     */         case 12:
/* 325 */           return getString(paramInt);
/*     */         
/*     */         case -104:
/* 328 */           return getINTERVALDS(paramInt);
/*     */ 
/*     */ 
/*     */         
/*     */         case -4:
/*     */         case -3:
/*     */         case -2:
/* 335 */           return getBytes(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 339 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 340 */       sQLException.fillInStackTrace();
/* 341 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 347 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 353 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/T4CIntervaldsAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */