/*     */ package oracle.jdbc.pool;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.StringRefAddr;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.xa.client.OracleXADataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleDataSourceFactory
/*     */   implements ObjectFactory
/*     */ {
/*     */   private static final String CONNECTION_CACHING_ENABLED = "connectionCachingEnabled";
/*     */   private static final String CONNECTION_CACHE_NAME = "connectionCacheName";
/*     */   private static final String CONNECTION_CACHE_PROPERTIES = "connectionCacheProperties";
/*     */   private static final String CONNECTION_PROPERTIES = "connectionProperties";
/*     */   private static final String FAST_CONNECTION_FAILOVER_ENABLED = "fastConnectionFailoverEnabled";
/*     */   private static final String ONS_CONFIG_STR = "onsConfigStr";
/*     */   private static final String ORACLE_CONN_DATA_POOL_SOURCE = "oracle.jdbc.pool.OracleConnectionPoolDataSource";
/*     */   private static final String ORACLE_OCI_CONN_POOL = "oracle.jdbc.pool.OracleOCIConnectionPool";
/*     */   private static final String ORACLE_DATA_SOURCE = "oracle.jdbc.pool.OracleDataSource";
/*     */   private static final String ORACLE_XA_DATA_SOURCE = "oracle.jdbc.xa.client.OracleXADataSource";
/*     */   
/*     */   public Object getObjectInstance(Object paramObject, Name paramName, Context paramContext, Hashtable paramHashtable) throws Exception {
/*  63 */     Reference reference = (Reference)paramObject;
/*  64 */     OracleDataSource oracleDataSource = null;
/*  65 */     String str = reference.getClassName();
/*  66 */     Properties properties = new Properties();
/*     */     
/*  68 */     if (str.equals("oracle.jdbc.pool.OracleDataSource") || str.equals("oracle.jdbc.xa.client.OracleXADataSource")) {
/*     */       OracleXADataSource oracleXADataSource;
/*     */       
/*  71 */       if (str.equals("oracle.jdbc.pool.OracleDataSource")) {
/*  72 */         oracleDataSource = new OracleDataSource();
/*     */       } else {
/*     */         
/*  75 */         oracleXADataSource = new OracleXADataSource();
/*     */       } 
/*     */       
/*  78 */       StringRefAddr stringRefAddr = null;
/*     */ 
/*     */       
/*  81 */       if ((stringRefAddr = (StringRefAddr)reference.get("connectionCachingEnabled")) != null) {
/*  82 */         String str1 = (String)stringRefAddr.getContent();
/*     */         
/*  84 */         if (str1.equals(String.valueOf("true"))) {
/*  85 */           oracleXADataSource.setConnectionCachingEnabled(true);
/*     */         }
/*     */       } 
/*     */       
/*  89 */       if ((stringRefAddr = (StringRefAddr)reference.get("connectionCacheName")) != null) {
/*  90 */         oracleXADataSource.setConnectionCacheName((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/*  93 */       if ((stringRefAddr = (StringRefAddr)reference.get("connectionCacheProperties")) != null) {
/*  94 */         String str1 = (String)stringRefAddr.getContent();
/*  95 */         Properties properties1 = extractConnectionCacheProperties(str1);
/*  96 */         oracleXADataSource.setConnectionCacheProperties(properties1);
/*     */       } 
/*     */       
/*  99 */       if ((stringRefAddr = (StringRefAddr)reference.get("connectionProperties")) != null) {
/* 100 */         String str1 = (String)stringRefAddr.getContent();
/* 101 */         Properties properties1 = extractConnectionProperties(str1);
/* 102 */         oracleXADataSource.setConnectionProperties(properties1);
/*     */       } 
/*     */       
/* 105 */       if ((stringRefAddr = (StringRefAddr)reference.get("fastConnectionFailoverEnabled")) != null) {
/*     */         
/* 107 */         String str1 = (String)stringRefAddr.getContent();
/*     */         
/* 109 */         if (str1.equals(String.valueOf("true"))) {
/* 110 */           oracleXADataSource.setFastConnectionFailoverEnabled(true);
/*     */         }
/*     */       } 
/*     */       
/* 114 */       if ((stringRefAddr = (StringRefAddr)reference.get("onsConfigStr")) != null) {
/* 115 */         oracleXADataSource.setONSConfiguration((String)stringRefAddr.getContent());
/*     */       }
/*     */     }
/* 118 */     else if (str.equals("oracle.jdbc.pool.OracleConnectionPoolDataSource")) {
/* 119 */       oracleDataSource = new OracleConnectionPoolDataSource();
/*     */     }
/* 121 */     else if (str.equals("oracle.jdbc.pool.OracleOCIConnectionPool")) {
/* 122 */       oracleDataSource = new OracleOCIConnectionPool();
/*     */       
/* 124 */       String str1 = null;
/* 125 */       String str2 = null;
/* 126 */       String str3 = null;
/* 127 */       String str4 = null;
/* 128 */       String str5 = null;
/* 129 */       String str6 = null;
/* 130 */       String str7 = null;
/* 131 */       StringRefAddr stringRefAddr = null;
/*     */       
/* 133 */       Object object = null;
/* 134 */       String str8 = null;
/*     */ 
/*     */ 
/*     */       
/* 138 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_min_limit")) != null)
/*     */       {
/* 140 */         str1 = (String)stringRefAddr.getContent();
/*     */       }
/*     */       
/* 143 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_max_limit")) != null)
/*     */       {
/* 145 */         str2 = (String)stringRefAddr.getContent();
/*     */       }
/*     */       
/* 148 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_increment")) != null)
/*     */       {
/* 150 */         str3 = (String)stringRefAddr.getContent();
/*     */       }
/*     */       
/* 153 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_active_size")) != null)
/*     */       {
/* 155 */         str4 = (String)stringRefAddr.getContent();
/*     */       }
/*     */       
/* 158 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_pool_size")) != null)
/*     */       {
/* 160 */         str5 = (String)stringRefAddr.getContent();
/*     */       }
/*     */       
/* 163 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_timeout")) != null)
/*     */       {
/* 165 */         str6 = (String)stringRefAddr.getContent();
/*     */       }
/*     */       
/* 168 */       if ((stringRefAddr = (StringRefAddr)reference.get("connpool_nowait")) != null)
/*     */       {
/* 170 */         str7 = (String)stringRefAddr.getContent();
/*     */       }
/*     */       
/* 173 */       if ((stringRefAddr = (StringRefAddr)reference.get("transactions_distributed")) != null)
/*     */       {
/* 175 */         str8 = (String)stringRefAddr.getContent();
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 180 */       properties.put("connpool_min_limit", str1);
/* 181 */       properties.put("connpool_max_limit", str2);
/* 182 */       properties.put("connpool_increment", str3);
/* 183 */       properties.put("connpool_active_size", str4);
/*     */       
/* 185 */       properties.put("connpool_pool_size", str5);
/* 186 */       properties.put("connpool_timeout", str6);
/*     */       
/* 188 */       if (str7 == "true") {
/* 189 */         properties.put("connpool_nowait", str7);
/*     */       }
/*     */       
/* 192 */       if (str8 == "true") {
/* 193 */         properties.put("transactions_distributed", str8);
/*     */       
/*     */       }
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 200 */       return null;
/*     */     } 
/*     */     
/* 203 */     if (oracleDataSource != null) {
/*     */       
/* 205 */       StringRefAddr stringRefAddr = null;
/*     */       
/* 207 */       if ((stringRefAddr = (StringRefAddr)reference.get("url")) != null)
/*     */       {
/* 209 */         oracleDataSource.setURL((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 212 */       if ((stringRefAddr = (StringRefAddr)reference.get("userName")) != null || (stringRefAddr = (StringRefAddr)reference.get("u")) != null || (stringRefAddr = (StringRefAddr)reference.get("user")) != null)
/*     */       {
/*     */         
/* 215 */         oracleDataSource.setUser((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 218 */       if ((stringRefAddr = (StringRefAddr)reference.get("passWord")) != null || (stringRefAddr = (StringRefAddr)reference.get("password")) != null)
/*     */       {
/* 220 */         oracleDataSource.setPassword((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 223 */       if ((stringRefAddr = (StringRefAddr)reference.get("description")) != null || (stringRefAddr = (StringRefAddr)reference.get("describe")) != null)
/*     */       {
/* 225 */         oracleDataSource.setDescription((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 228 */       if ((stringRefAddr = (StringRefAddr)reference.get("driverType")) != null || (stringRefAddr = (StringRefAddr)reference.get("driver")) != null)
/*     */       {
/* 230 */         oracleDataSource.setDriverType((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 233 */       if ((stringRefAddr = (StringRefAddr)reference.get("serverName")) != null || (stringRefAddr = (StringRefAddr)reference.get("host")) != null)
/*     */       {
/* 235 */         oracleDataSource.setServerName((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 238 */       if ((stringRefAddr = (StringRefAddr)reference.get("databaseName")) != null || (stringRefAddr = (StringRefAddr)reference.get("sid")) != null)
/*     */       {
/* 240 */         oracleDataSource.setDatabaseName((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 243 */       if ((stringRefAddr = (StringRefAddr)reference.get("serviceName")) != null) {
/* 244 */         oracleDataSource.setServiceName((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 247 */       if ((stringRefAddr = (StringRefAddr)reference.get("networkProtocol")) != null || (stringRefAddr = (StringRefAddr)reference.get("protocol")) != null)
/*     */       {
/* 249 */         oracleDataSource.setNetworkProtocol((String)stringRefAddr.getContent());
/*     */       }
/*     */       
/* 252 */       if ((stringRefAddr = (StringRefAddr)reference.get("portNumber")) != null || (stringRefAddr = (StringRefAddr)reference.get("port")) != null) {
/*     */         
/* 254 */         String str1 = (String)stringRefAddr.getContent();
/*     */         
/* 256 */         oracleDataSource.setPortNumber(Integer.parseInt(str1));
/*     */       } 
/*     */       
/* 259 */       if ((stringRefAddr = (StringRefAddr)reference.get("tnsentryname")) != null || (stringRefAddr = (StringRefAddr)reference.get("tns")) != null) {
/*     */         
/* 261 */         oracleDataSource.setTNSEntryName((String)stringRefAddr.getContent());
/*     */       }
/* 263 */       else if (str.equals("oracle.jdbc.pool.OracleOCIConnectionPool")) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 278 */         String str1 = null;
/*     */         
/* 280 */         if ((stringRefAddr = (StringRefAddr)reference.get("connpool_is_poolcreated")) != null)
/*     */         {
/* 282 */           str1 = (String)stringRefAddr.getContent();
/*     */         }
/*     */         
/* 285 */         if (str1.equals(String.valueOf("true"))) {
/* 286 */           ((OracleOCIConnectionPool)oracleDataSource).setPoolConfig(properties);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 291 */     return oracleDataSource;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Properties extractConnectionCacheProperties(String paramString) throws SQLException {
/* 312 */     Properties properties = new Properties();
/*     */ 
/*     */     
/* 315 */     paramString = paramString.substring(1, paramString.length() - 1);
/*     */ 
/*     */     
/* 318 */     int i = paramString.indexOf("AttributeWeights", 0);
/*     */     
/* 320 */     if (i >= 0) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 329 */       if (paramString.charAt(i + 16) != '=' || (i > 0 && paramString.charAt(i - 1) != ' ')) {
/*     */ 
/*     */ 
/*     */         
/* 333 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 139);
/*     */         
/* 335 */         sQLException.fillInStackTrace();
/* 336 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */       
/* 340 */       Properties properties1 = new Properties();
/* 341 */       int j = paramString.indexOf("}", i);
/* 342 */       String str1 = paramString.substring(i, j);
/*     */ 
/*     */       
/* 345 */       String str2 = str1.substring(18);
/*     */       
/* 347 */       StringTokenizer stringTokenizer1 = new StringTokenizer(str2, ", ");
/*     */ 
/*     */       
/* 350 */       synchronized (stringTokenizer1) {
/*     */         
/* 352 */         while (stringTokenizer1.hasMoreTokens()) {
/*     */           
/* 354 */           String str3 = stringTokenizer1.nextToken();
/* 355 */           int k = str3.length();
/* 356 */           int m = str3.indexOf("=");
/*     */           
/* 358 */           String str4 = str3.substring(0, m);
/* 359 */           String str5 = str3.substring(m + 1, k);
/*     */           
/* 361 */           properties1.setProperty(str4, str5);
/*     */         } 
/*     */       } 
/*     */       
/* 365 */       properties.put("AttributeWeights", properties1);
/*     */ 
/*     */       
/* 368 */       if (i > 0 && j + 1 == paramString.length()) {
/*     */         
/* 370 */         paramString = paramString.substring(0, i - 2);
/*     */       }
/* 372 */       else if (i > 0 && j + 1 < paramString.length()) {
/*     */         
/* 374 */         String str3 = paramString.substring(0, i - 2);
/* 375 */         String str4 = paramString.substring(j + 1, paramString.length());
/*     */         
/* 377 */         paramString = str3.concat(str4);
/*     */       }
/*     */       else {
/*     */         
/* 381 */         paramString = paramString.substring(j + 2, paramString.length());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 386 */     StringTokenizer stringTokenizer = new StringTokenizer(paramString, ", ");
/*     */     
/* 388 */     synchronized (stringTokenizer) {
/*     */       
/* 390 */       while (stringTokenizer.hasMoreTokens()) {
/*     */         
/* 392 */         String str1 = stringTokenizer.nextToken();
/* 393 */         int j = str1.length();
/* 394 */         int k = str1.indexOf("=");
/*     */         
/* 396 */         String str2 = str1.substring(0, k);
/* 397 */         String str3 = str1.substring(k + 1, j);
/*     */         
/* 399 */         properties.setProperty(str2, str3);
/*     */       } 
/*     */     } 
/* 402 */     return properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Properties extractConnectionProperties(String paramString) throws SQLException {
/* 411 */     Properties properties = new Properties();
/*     */ 
/*     */     
/* 414 */     paramString = paramString.substring(1, paramString.length() - 1);
/*     */     
/* 416 */     String[] arrayOfString = paramString.split(";");
/*     */     
/* 418 */     for (String str1 : arrayOfString) {
/* 419 */       int i = str1.length();
/* 420 */       int j = str1.indexOf("=");
/*     */       
/* 422 */       if (i == 0 || j <= 0) {
/*     */         
/* 424 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190);
/*     */         
/* 426 */         sQLException.fillInStackTrace();
/* 427 */         throw sQLException;
/*     */       } 
/*     */ 
/*     */       
/* 431 */       String str2 = str1.substring(0, j);
/* 432 */       String str3 = str1.substring(j + 1, i);
/*     */       
/* 434 */       properties.setProperty(str2.trim(), str3.trim());
/*     */     } 
/* 436 */     return properties;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 451 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 456 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/pool/OracleDataSourceFactory.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */