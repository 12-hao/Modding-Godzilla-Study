/*     */ package oracle.jdbc.xa;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.sql.XADataSource;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.pool.OracleConnectionPoolDataSource;
/*     */ import oracle.jdbc.pool.OracleDataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class OracleXADataSource
/*     */   extends OracleConnectionPoolDataSource
/*     */   implements XADataSource
/*     */ {
/*     */   protected boolean useNativeXA = false;
/*     */   protected boolean thinUseNativeXA = true;
/*     */   
/*     */   public OracleXADataSource() throws SQLException {
/*  49 */     this.dataSourceName = "OracleXADataSource";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract XAConnection getXAConnection() throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract XAConnection getXAConnection(String paramString1, String paramString2) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract XAConnection getXAConnection(Properties paramProperties) throws SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void setNativeXA(boolean paramBoolean) {
/*  92 */     this.useNativeXA = paramBoolean;
/*  93 */     this.thinUseNativeXA = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized boolean getNativeXA() {
/* 108 */     return this.useNativeXA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void copy(OracleDataSource paramOracleDataSource) throws SQLException {
/* 117 */     super.copy(paramOracleDataSource);
/*     */     
/* 119 */     ((OracleXADataSource)paramOracleDataSource).useNativeXA = this.useNativeXA;
/* 120 */     ((OracleXADataSource)paramOracleDataSource).thinUseNativeXA = this.thinUseNativeXA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 136 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 141 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/xa/OracleXADataSource.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */