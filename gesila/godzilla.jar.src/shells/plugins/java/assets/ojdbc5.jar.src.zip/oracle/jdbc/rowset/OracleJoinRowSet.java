/*     */ package oracle.jdbc.rowset;
/*     */ 
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Collection;
/*     */ import java.util.Vector;
/*     */ import javax.sql.RowSet;
/*     */ import javax.sql.RowSetMetaData;
/*     */ import javax.sql.rowset.CachedRowSet;
/*     */ import javax.sql.rowset.JoinRowSet;
/*     */ import javax.sql.rowset.Joinable;
/*     */ import oracle.jdbc.driver.DatabaseError;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleJoinRowSet
/*     */   extends OracleWebRowSet
/*     */   implements JoinRowSet
/*     */ {
/*     */   private static final String MATCH_COLUMN_SUFFIX = "#MATCH_COLUMN";
/*  41 */   private static boolean[] supportedJoins = new boolean[] { false, true, false, false, false };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private int joinType = 1;
/*  61 */   private Vector addedRowSets = new Vector();
/*  62 */   private Vector addedRowSetNames = new Vector();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private Object lockForJoinActions;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addRowSet(Joinable paramJoinable) throws SQLException {
/*  98 */     if (paramJoinable == null) {
/*     */       
/* 100 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 350);
/* 101 */       sQLException1.fillInStackTrace();
/* 102 */       throw sQLException1;
/*     */     } 
/*     */     
/* 105 */     if (!(paramJoinable instanceof RowSet)) {
/*     */       
/* 107 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 351);
/* 108 */       sQLException1.fillInStackTrace();
/* 109 */       throw sQLException1;
/*     */     } 
/*     */     
/* 112 */     OracleCachedRowSet oracleCachedRowSet = checkAndWrapRowSet((RowSet)paramJoinable);
/* 113 */     String str = getMatchColumnTableName((RowSet)paramJoinable);
/*     */     
/* 115 */     switch (this.joinType) {
/*     */       
/*     */       case 1:
/* 118 */         doInnerJoin(oracleCachedRowSet);
/*     */         
/* 120 */         this.addedRowSets.add(paramJoinable);
/* 121 */         this.addedRowSetNames.add(str);
/*     */         return;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 130 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 352);
/* 131 */     sQLException.fillInStackTrace();
/* 132 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addRowSet(RowSet paramRowSet, int paramInt) throws SQLException {
/* 160 */     ((OracleRowSet)paramRowSet).setMatchColumn(paramInt);
/* 161 */     addRowSet((Joinable)paramRowSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addRowSet(RowSet paramRowSet, String paramString) throws SQLException {
/* 187 */     ((OracleRowSet)paramRowSet).setMatchColumn(paramString);
/* 188 */     addRowSet((Joinable)paramRowSet);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addRowSet(RowSet[] paramArrayOfRowSet, int[] paramArrayOfint) throws SQLException {
/* 223 */     if (paramArrayOfRowSet.length != paramArrayOfint.length) {
/*     */       
/* 225 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 353);
/* 226 */       sQLException.fillInStackTrace();
/* 227 */       throw sQLException;
/*     */     } 
/*     */     
/* 230 */     for (byte b = 0; b < paramArrayOfRowSet.length; b++) {
/*     */       
/* 232 */       ((OracleRowSet)paramArrayOfRowSet[b]).setMatchColumn(paramArrayOfint[b]);
/* 233 */       addRowSet((Joinable)paramArrayOfRowSet[b]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized void addRowSet(RowSet[] paramArrayOfRowSet, String[] paramArrayOfString) throws SQLException {
/* 270 */     if (paramArrayOfRowSet.length != paramArrayOfString.length) {
/*     */       
/* 272 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 353);
/* 273 */       sQLException.fillInStackTrace();
/* 274 */       throw sQLException;
/*     */     } 
/*     */     
/* 277 */     for (byte b = 0; b < paramArrayOfRowSet.length; b++) {
/*     */       
/* 279 */       ((OracleRowSet)paramArrayOfRowSet[b]).setMatchColumn(paramArrayOfString[b]);
/* 280 */       addRowSet((Joinable)paramArrayOfRowSet[b]);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Collection getRowSets() throws SQLException {
/* 302 */     return this.addedRowSets;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String[] getRowSetNames() throws SQLException {
/* 320 */     Object[] arrayOfObject = this.addedRowSetNames.toArray();
/* 321 */     String[] arrayOfString = new String[arrayOfObject.length];
/* 322 */     for (byte b = 0; b < arrayOfObject.length; b++)
/*     */     {
/* 324 */       arrayOfString[b] = (String)arrayOfObject[b];
/*     */     }
/* 326 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CachedRowSet toCachedRowSet() throws SQLException {
/* 356 */     OracleCachedRowSet oracleCachedRowSet = (OracleCachedRowSet)createCopy();
/*     */ 
/*     */     
/* 359 */     oracleCachedRowSet.setCommand("");
/*     */     
/* 361 */     return oracleCachedRowSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getJoinType() {
/* 379 */     return this.joinType;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsCrossJoin() {
/* 392 */     return supportedJoins[0];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsInnerJoin() {
/* 405 */     return supportedJoins[1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsLeftOuterJoin() {
/* 418 */     return supportedJoins[2];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsRightOuterJoin() {
/* 431 */     return supportedJoins[3];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean supportsFullJoin() {
/* 444 */     return supportedJoins[4];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setJoinType(int paramInt) throws SQLException {
/* 462 */     if (paramInt != 1) {
/*     */       
/* 464 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 352);
/* 465 */       sQLException.fillInStackTrace();
/* 466 */       throw sQLException;
/*     */     } 
/*     */     
/* 469 */     this.joinType = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized String getWhereClause() throws SQLException {
/* 488 */     if (this.addedRowSets.size() < 2) {
/* 489 */       return "WHERE";
/*     */     }
/* 491 */     StringBuffer stringBuffer = new StringBuffer();
/* 492 */     stringBuffer.append("WHERE\n");
/*     */     
/* 494 */     OracleRowSet oracleRowSet = this.addedRowSets.get(0);
/* 495 */     int[] arrayOfInt = oracleRowSet.getMatchColumnIndexes();
/* 496 */     ResultSetMetaData resultSetMetaData = oracleRowSet.getMetaData();
/* 497 */     String str = oracleRowSet.getTableName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 504 */     for (byte b = 1; b < this.addedRowSets.size(); b++) {
/*     */       
/* 506 */       if (b > 1)
/*     */       {
/* 508 */         stringBuffer.append("\nAND\n");
/*     */       }
/*     */       
/* 511 */       OracleRowSet oracleRowSet1 = this.addedRowSets.get(b);
/* 512 */       int[] arrayOfInt1 = oracleRowSet1.getMatchColumnIndexes();
/* 513 */       ResultSetMetaData resultSetMetaData1 = oracleRowSet1.getMetaData();
/* 514 */       String str1 = oracleRowSet1.getTableName();
/*     */       
/* 516 */       for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
/*     */         
/* 518 */         if (b1 > 0)
/*     */         {
/* 520 */           stringBuffer.append("\nAND\n");
/*     */         }
/*     */         
/* 523 */         stringBuffer.append("(" + str + "." + resultSetMetaData.getColumnName(arrayOfInt[b1]) + " = " + str1 + "." + resultSetMetaData1.getColumnName(arrayOfInt1[b1]) + ")");
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 530 */       oracleRowSet = oracleRowSet1;
/* 531 */       arrayOfInt = arrayOfInt1;
/* 532 */       resultSetMetaData = resultSetMetaData1;
/* 533 */       str = str1;
/*     */     } 
/*     */     
/* 536 */     stringBuffer.append(";");
/*     */     
/* 538 */     return stringBuffer.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void doInnerJoin(OracleCachedRowSet paramOracleCachedRowSet) throws SQLException {
/* 564 */     if (this.addedRowSets.isEmpty()) {
/*     */ 
/*     */       
/* 567 */       setMetaData((RowSetMetaData)paramOracleCachedRowSet.getMetaData());
/* 568 */       populate(paramOracleCachedRowSet);
/*     */       
/* 570 */       setMatchColumn(paramOracleCachedRowSet.getMatchColumnIndexes());
/*     */     }
/*     */     else {
/*     */       
/* 574 */       Vector<OracleRow> vector = new Vector(100);
/* 575 */       OracleRowSetMetaData oracleRowSetMetaData = new OracleRowSetMetaData(10);
/*     */       
/* 577 */       int[] arrayOfInt1 = getMatchColumnIndexes();
/* 578 */       int[] arrayOfInt2 = paramOracleCachedRowSet.getMatchColumnIndexes();
/*     */ 
/*     */       
/* 581 */       int i = getMetaData().getColumnCount() + paramOracleCachedRowSet.getMetaData().getColumnCount() - arrayOfInt2.length;
/*     */ 
/*     */       
/* 584 */       oracleRowSetMetaData.setColumnCount(i);
/*     */ 
/*     */       
/* 587 */       String str = getTableName() + "#" + paramOracleCachedRowSet.getTableName();
/*     */ 
/*     */       
/* 590 */       for (byte b1 = 1; b1 <= this.colCount; b1++) {
/*     */         
/* 592 */         boolean bool1 = false;
/* 593 */         for (byte b = 0; b < arrayOfInt1.length; b++) {
/*     */           
/* 595 */           if (b1 == arrayOfInt1[b]) {
/*     */             
/* 597 */             bool1 = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 602 */         setNewColumnMetaData(b1, oracleRowSetMetaData, b1, (RowSetMetaData)this.rowsetMetaData, bool1, str);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 607 */       RowSetMetaData rowSetMetaData = (RowSetMetaData)paramOracleCachedRowSet.getMetaData();
/*     */       
/* 609 */       int j = rowSetMetaData.getColumnCount();
/*     */ 
/*     */       
/* 612 */       int k = this.colCount + 1;
/* 613 */       int[] arrayOfInt3 = new int[j];
/*     */       int m;
/* 615 */       for (m = 1; m <= j; m++) {
/*     */         
/* 617 */         boolean bool1 = false;
/* 618 */         for (byte b = 0; b < arrayOfInt2.length; b++) {
/*     */           
/* 620 */           if (m == arrayOfInt1[b]) {
/*     */             
/* 622 */             bool1 = true;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 627 */         if (!bool1) {
/*     */           
/* 629 */           setNewColumnMetaData(k, oracleRowSetMetaData, m, rowSetMetaData, bool1, str);
/*     */ 
/*     */ 
/*     */           
/* 633 */           arrayOfInt3[m - 1] = k;
/* 634 */           k++;
/*     */         
/*     */         }
/*     */         else {
/*     */           
/* 639 */           arrayOfInt3[m - 1] = -1;
/*     */         } 
/*     */       } 
/*     */       
/* 643 */       beforeFirst();
/*     */ 
/*     */       
/* 646 */       m = paramOracleCachedRowSet.size();
/* 647 */       boolean bool = false;
/*     */       
/* 649 */       for (byte b2 = 1; b2 <= this.rowCount; b2++) {
/*     */         
/* 651 */         next();
/* 652 */         paramOracleCachedRowSet.beforeFirst();
/*     */         
/* 654 */         for (byte b = 1; b <= m; b++) {
/*     */           
/* 656 */           paramOracleCachedRowSet.next();
/*     */           
/* 658 */           bool = true;
/* 659 */           for (byte b3 = 0; b3 < arrayOfInt1.length; b3++) {
/*     */             
/* 661 */             Object object1 = getObject(arrayOfInt1[b3]);
/* 662 */             Object object2 = paramOracleCachedRowSet.getObject(arrayOfInt2[b3]);
/* 663 */             if (!object1.equals(object2)) {
/*     */               
/* 665 */               bool = false;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/* 670 */           if (bool) {
/*     */             
/* 672 */             OracleRow oracleRow = new OracleRow(i, true);
/*     */             
/*     */             byte b4;
/* 675 */             for (b4 = 1; b4 <= this.colCount; b4++)
/*     */             {
/* 677 */               oracleRow.updateObject(b4, getObject(b4));
/*     */             }
/*     */             
/* 680 */             for (b4 = 1; b4 <= j; b4++) {
/*     */               
/* 682 */               if (arrayOfInt3[b4 - 1] != -1)
/*     */               {
/* 684 */                 oracleRow.updateObject(arrayOfInt3[b4 - 1], paramOracleCachedRowSet.getObject(b4));
/*     */               }
/*     */             } 
/*     */ 
/*     */             
/* 689 */             vector.add(oracleRow);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 694 */       this.rows = vector;
/* 695 */       this.presentRow = 0;
/* 696 */       this.rowCount = this.rows.size();
/* 697 */       setMetaData(oracleRowSetMetaData);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void setNewColumnMetaData(int paramInt1, RowSetMetaData paramRowSetMetaData1, int paramInt2, RowSetMetaData paramRowSetMetaData2, boolean paramBoolean, String paramString) throws SQLException {
/* 733 */     paramRowSetMetaData1.setAutoIncrement(paramInt1, paramRowSetMetaData2.isAutoIncrement(paramInt2));
/* 734 */     paramRowSetMetaData1.setCaseSensitive(paramInt1, paramRowSetMetaData2.isCaseSensitive(paramInt2));
/* 735 */     paramRowSetMetaData1.setCatalogName(paramInt1, paramRowSetMetaData2.getCatalogName(paramInt2));
/* 736 */     paramRowSetMetaData1.setColumnDisplaySize(paramInt1, paramRowSetMetaData2.getColumnDisplaySize(paramInt2));
/*     */ 
/*     */     
/* 739 */     if (paramBoolean) {
/*     */       
/* 741 */       paramRowSetMetaData1.setColumnName(paramInt1, paramRowSetMetaData2.getColumnName(paramInt1) + "#MATCH_COLUMN");
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 746 */       paramRowSetMetaData1.setColumnName(paramInt1, paramRowSetMetaData2.getColumnName(paramInt2));
/*     */     } 
/*     */     
/* 749 */     paramRowSetMetaData1.setColumnLabel(paramInt1, paramRowSetMetaData1.getColumnName(paramInt2));
/*     */     
/* 751 */     paramRowSetMetaData1.setColumnType(paramInt1, paramRowSetMetaData2.getColumnType(paramInt2));
/* 752 */     paramRowSetMetaData1.setColumnTypeName(paramInt1, paramRowSetMetaData2.getColumnTypeName(paramInt2));
/* 753 */     paramRowSetMetaData1.setCurrency(paramInt1, paramRowSetMetaData2.isCurrency(paramInt2));
/* 754 */     paramRowSetMetaData1.setNullable(paramInt1, paramRowSetMetaData2.isNullable(paramInt2));
/* 755 */     paramRowSetMetaData1.setPrecision(paramInt1, paramRowSetMetaData2.getPrecision(paramInt2));
/* 756 */     paramRowSetMetaData1.setScale(paramInt1, paramRowSetMetaData2.getScale(paramInt2));
/* 757 */     paramRowSetMetaData1.setSchemaName(paramInt1, paramRowSetMetaData2.getSchemaName(paramInt2));
/* 758 */     paramRowSetMetaData1.setSearchable(paramInt1, paramRowSetMetaData2.isSearchable(paramInt2));
/* 759 */     paramRowSetMetaData1.setSigned(paramInt1, paramRowSetMetaData2.isSigned(paramInt2));
/*     */     
/* 761 */     if (paramBoolean) {
/*     */       
/* 763 */       paramRowSetMetaData1.setTableName(paramInt1, paramString);
/*     */     }
/*     */     else {
/*     */       
/* 767 */       paramRowSetMetaData1.setTableName(paramInt1, paramRowSetMetaData2.getTableName(paramInt2));
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private OracleCachedRowSet checkAndWrapRowSet(RowSet paramRowSet) throws SQLException {
/* 790 */     OracleCachedRowSet oracleCachedRowSet = null;
/*     */ 
/*     */ 
/*     */     
/* 794 */     if (paramRowSet instanceof OracleCachedRowSet) {
/*     */       
/* 796 */       oracleCachedRowSet = (OracleCachedRowSet)paramRowSet;
/*     */     }
/* 798 */     else if (paramRowSet instanceof OracleJDBCRowSet) {
/*     */       
/* 800 */       oracleCachedRowSet = new OracleCachedRowSet();
/* 801 */       oracleCachedRowSet.populate(paramRowSet);
/*     */       
/* 803 */       int[] arrayOfInt = ((OracleJDBCRowSet)paramRowSet).getMatchColumnIndexes();
/* 804 */       oracleCachedRowSet.setMatchColumn(arrayOfInt);
/*     */     }
/*     */     else {
/*     */       
/* 808 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 354);
/* 809 */       sQLException.fillInStackTrace();
/* 810 */       throw sQLException;
/*     */     } 
/*     */     
/* 813 */     return oracleCachedRowSet;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getMatchColumnTableName(RowSet paramRowSet) throws SQLException {
/* 823 */     String str = null;
/* 824 */     if (paramRowSet instanceof OracleRowSet)
/*     */     {
/* 826 */       str = ((OracleRowSet)paramRowSet).getTableName();
/*     */     }
/*     */     
/* 829 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 834 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/rowset/OracleJoinRowSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */