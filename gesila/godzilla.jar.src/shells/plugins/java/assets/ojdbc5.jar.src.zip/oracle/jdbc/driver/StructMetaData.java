/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.OracleArray;
/*     */ import oracle.jdbc.OracleBfile;
/*     */ import oracle.jdbc.OracleBlob;
/*     */ import oracle.jdbc.OracleClob;
/*     */ import oracle.jdbc.OracleOpaque;
/*     */ import oracle.jdbc.OracleRef;
/*     */ import oracle.jdbc.OracleResultSetMetaData;
/*     */ import oracle.jdbc.OracleStruct;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ import oracle.jdbc.internal.StructMetaData;
/*     */ import oracle.jdbc.oracore.OracleType;
/*     */ import oracle.jdbc.oracore.OracleTypeADT;
/*     */ import oracle.jdbc.oracore.OracleTypeCHAR;
/*     */ import oracle.jdbc.oracore.OracleTypeRAW;
/*     */ import oracle.jdbc.oracore.OracleTypeREF;
/*     */ import oracle.sql.StructDescriptor;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StructMetaData
/*     */   implements StructMetaData
/*     */ {
/*     */   StructDescriptor descriptor;
/*     */   OracleTypeADT otype;
/*     */   OracleType[] types;
/*     */   
/*     */   public StructMetaData(StructDescriptor paramStructDescriptor) throws SQLException {
/*  40 */     if (paramStructDescriptor == null) {
/*     */       
/*  42 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "illegal operation: descriptor is null");
/*  43 */       sQLException.fillInStackTrace();
/*  44 */       throw sQLException;
/*     */     } 
/*     */     
/*  47 */     this.descriptor = paramStructDescriptor;
/*  48 */     this.otype = paramStructDescriptor.getOracleTypeADT();
/*  49 */     this.types = this.otype.getAttrTypes();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnCount() throws SQLException {
/*  62 */     return this.types.length;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isAutoIncrement(int paramInt) throws SQLException {
/*  70 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSearchable(int paramInt) throws SQLException {
/*  80 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleResultSetMetaData.SecurityAttribute getSecurityAttribute(int paramInt) throws SQLException {
/*  87 */     return OracleResultSetMetaData.SecurityAttribute.NONE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCurrency(int paramInt) throws SQLException {
/*  95 */     int i = getValidColumnIndex(paramInt);
/*     */     
/*  97 */     return (this.types[i] instanceof oracle.jdbc.oracore.OracleTypeNUMBER || this.types[i] instanceof oracle.jdbc.oracore.OracleTypeFLOAT);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isCaseSensitive(int paramInt) throws SQLException {
/* 107 */     int i = getValidColumnIndex(paramInt);
/*     */     
/* 109 */     return this.types[i] instanceof OracleTypeCHAR;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int isNullable(int paramInt) throws SQLException {
/* 117 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isSigned(int paramInt) throws SQLException {
/* 125 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnDisplaySize(int paramInt) throws SQLException {
/* 137 */     int i = getValidColumnIndex(paramInt);
/*     */     
/* 139 */     if (this.types[i] instanceof OracleTypeCHAR)
/* 140 */       return ((OracleTypeCHAR)this.types[i]).getLength(); 
/* 141 */     if (this.types[i] instanceof OracleTypeRAW) {
/* 142 */       return ((OracleTypeRAW)this.types[i]).getLength();
/*     */     }
/* 144 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnLabel(int paramInt) throws SQLException {
/* 152 */     return getColumnName(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnName(int paramInt) throws SQLException {
/* 167 */     return this.otype.getAttributeName(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getSchemaName(int paramInt) throws SQLException {
/* 182 */     int i = getValidColumnIndex(paramInt);
/*     */     
/* 184 */     if (this.types[i] instanceof OracleTypeADT) {
/* 185 */       return ((OracleTypeADT)this.types[i]).getSchemaName();
/*     */     }
/* 187 */     return "";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getPrecision(int paramInt) throws SQLException {
/* 195 */     int i = getValidColumnIndex(paramInt);
/*     */ 
/*     */     
/* 198 */     return this.types[i].getPrecision();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getScale(int paramInt) throws SQLException {
/* 206 */     int i = getValidColumnIndex(paramInt);
/*     */ 
/*     */     
/* 209 */     return this.types[i].getScale();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getTableName(int paramInt) throws SQLException {
/* 217 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getCatalogName(int paramInt) throws SQLException {
/* 225 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getColumnType(int paramInt) throws SQLException {
/* 233 */     int i = getValidColumnIndex(paramInt);
/*     */     
/* 235 */     return this.types[i].getTypeCode();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnTypeName(int paramInt) throws SQLException {
/* 251 */     int i = getColumnType(paramInt);
/* 252 */     int j = getValidColumnIndex(paramInt);
/*     */     
/* 254 */     switch (i) {
/*     */ 
/*     */       
/*     */       case 12:
/* 258 */         return "VARCHAR";
/*     */       
/*     */       case 1:
/* 261 */         return "CHAR";
/*     */       
/*     */       case -2:
/* 264 */         return "RAW";
/*     */       
/*     */       case 6:
/* 267 */         return "FLOAT";
/*     */       
/*     */       case 2:
/* 270 */         return "NUMBER";
/*     */       
/*     */       case 8:
/* 273 */         return "DOUBLE";
/*     */       
/*     */       case 3:
/* 276 */         return "DECIMAL";
/*     */       
/*     */       case 100:
/* 279 */         return "BINARY_FLOAT";
/*     */       
/*     */       case 101:
/* 282 */         return "BINARY_DOUBLE";
/*     */       
/*     */       case 91:
/* 285 */         return "DATE";
/*     */       
/*     */       case -104:
/* 288 */         return "INTERVALDS";
/*     */       
/*     */       case -103:
/* 291 */         return "INTERVALYM";
/*     */       
/*     */       case 93:
/* 294 */         return "TIMESTAMP";
/*     */       
/*     */       case -101:
/* 297 */         return "TIMESTAMP WITH TIME ZONE";
/*     */       
/*     */       case -102:
/* 300 */         return "TIMESTAMP WITH LOCAL TIME ZONE";
/*     */       
/*     */       case 2004:
/* 303 */         return "BLOB";
/*     */       
/*     */       case 2005:
/* 306 */         return "CLOB";
/*     */       
/*     */       case -13:
/* 309 */         return "BFILE";
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2002:
/*     */       case 2003:
/*     */       case 2007:
/*     */       case 2008:
/* 318 */         return ((OracleTypeADT)this.types[j]).getFullName();
/*     */       
/*     */       case 2006:
/* 321 */         return "REF " + ((OracleTypeREF)this.types[j]).getFullName();
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 329 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isReadOnly(int paramInt) throws SQLException {
/* 338 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isWritable(int paramInt) throws SQLException {
/* 346 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isDefinitelyWritable(int paramInt) throws SQLException {
/* 354 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getColumnClassName(int paramInt) throws SQLException {
/* 362 */     int i = getColumnType(paramInt);
/*     */     
/* 364 */     switch (i) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 12:
/* 373 */         return "java.lang.String";
/*     */       
/*     */       case -2:
/* 376 */         return "byte[]";
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/*     */       case 3:
/*     */       case 6:
/*     */       case 8:
/* 385 */         return "java.math.BigDecimal";
/*     */       
/*     */       case 91:
/* 388 */         return "java.sql.Timestamp";
/*     */       
/*     */       case -103:
/* 391 */         return "oracle.sql.INTERVALYM";
/*     */       
/*     */       case -104:
/* 394 */         return "oracle.sql.INTERVALDS";
/*     */       
/*     */       case 93:
/* 397 */         return "oracle.sql.TIMESTAMP";
/*     */       
/*     */       case -101:
/* 400 */         return "oracle.sql.TIMESTAMPTZ";
/*     */       
/*     */       case -102:
/* 403 */         return "oracle.sql.TIMESTAMPLTZ";
/*     */       
/*     */       case 2004:
/* 406 */         return OracleBlob.class.getName();
/*     */       
/*     */       case 2005:
/* 409 */         return OracleClob.class.getName();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case -13:
/* 416 */         return OracleBfile.class.getName();
/*     */ 
/*     */       
/*     */       case 2002:
/*     */       case 2008:
/* 421 */         return OracleStruct.class.getName();
/*     */       
/*     */       case 2007:
/* 424 */         return OracleOpaque.class.getName();
/*     */       
/*     */       case 2003:
/* 427 */         return OracleArray.class.getName();
/*     */       
/*     */       case 2006:
/* 430 */         return OracleRef.class.getName();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 435 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getOracleColumnClassName(int paramInt) throws SQLException {
/* 449 */     int i = getColumnType(paramInt);
/*     */     
/* 451 */     switch (i) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*     */       case 12:
/* 460 */         return "CHAR";
/*     */       
/*     */       case -2:
/* 463 */         return "RAW";
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 2:
/*     */       case 3:
/*     */       case 6:
/*     */       case 8:
/* 472 */         return "NUMBER";
/*     */       
/*     */       case 91:
/* 475 */         return "DATE";
/*     */       
/*     */       case -103:
/* 478 */         return "INTERVALYM";
/*     */       
/*     */       case -104:
/* 481 */         return "INTERVALDS";
/*     */       
/*     */       case 93:
/* 484 */         return "TIMESTAMP";
/*     */       
/*     */       case -101:
/* 487 */         return "TIMESTAMPTZ";
/*     */       
/*     */       case -102:
/* 490 */         return "TIMESTAMPLTZ";
/*     */       
/*     */       case 2004:
/* 493 */         return "BLOB";
/*     */       
/*     */       case 2005:
/* 496 */         return "CLOB";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case -13:
/* 503 */         return "BFILE";
/*     */       
/*     */       case 2002:
/* 506 */         return "STRUCT";
/*     */       
/*     */       case 2008:
/* 509 */         return "JAVA_STRUCT";
/*     */       
/*     */       case 2007:
/* 512 */         return "OPAQUE";
/*     */       
/*     */       case 2003:
/* 515 */         return "ARRAY";
/*     */       
/*     */       case 2006:
/* 518 */         return "REF";
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 523 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLocalColumnCount() throws SQLException {
/* 538 */     return this.descriptor.getLocalAttributeCount();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isInherited(int paramInt) throws SQLException {
/* 554 */     return (paramInt <= getColumnCount() - getLocalColumnCount());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getAttributeJavaName(int paramInt) throws SQLException {
/* 571 */     int i = getValidColumnIndex(paramInt);
/*     */     
/* 573 */     return this.descriptor.getAttributeJavaName(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int getValidColumnIndex(int paramInt) throws SQLException {
/* 590 */     int i = paramInt - 1;
/*     */     
/* 592 */     if (i < 0 || i >= this.types.length) {
/*     */       
/* 594 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 3, "getValidColumnIndex");
/* 595 */       sQLException.fillInStackTrace();
/* 596 */       throw sQLException;
/*     */     } 
/*     */     
/* 599 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isNCHAR(int paramInt) throws SQLException {
/* 607 */     int i = getValidColumnIndex(paramInt);
/*     */     
/* 609 */     return this.types[i].isNCHAR();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 629 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/* 634 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/StructMetaData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */