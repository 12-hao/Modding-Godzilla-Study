/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class SQLStateMapping
/*     */ {
/*     */   public static final int SQLEXCEPTION = 0;
/*     */   public static final int SQLNONTRANSIENTEXCEPTION = 1;
/*     */   public static final int SQLTRANSIENTEXCEPTION = 2;
/*     */   public static final int SQLDATAEXCEPTION = 3;
/*     */   public static final int SQLFEATURENOTSUPPORTEDEXCEPTION = 4;
/*     */   public static final int SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION = 5;
/*     */   public static final int SQLINVALIDAUTHORIZATIONSPECEXCEPTION = 6;
/*     */   public static final int SQLNONTRANSIENTCONNECTIONEXCEPTION = 7;
/*     */   public static final int SQLSYNTAXERROREXCEPTION = 8;
/*     */   public static final int SQLTIMEOUTEXCEPTION = 9;
/*     */   public static final int SQLTRANSACTIONROLLBACKEXCEPTION = 10;
/*     */   public static final int SQLTRANSIENTCONNECTIONEXCEPTION = 11;
/*     */   public static final int SQLCLIENTINFOEXCEPTION = 12;
/*     */   public static final int SQLRECOVERABLEEXCEPTION = 13;
/*     */   int low;
/*     */   int high;
/*     */   public String sqlState;
/*     */   public int exception;
/*     */   static final String mappingResource = "errorMap.xml";
/*     */   static SQLStateMapping[] all;
/*     */   private static final int NUMEBER_OF_MAPPINGS_IN_ERRORMAP_XML = 128;
/*     */   
/*     */   public SQLStateMapping(int paramInt1, int paramInt2, String paramString, int paramInt3) {
/*  54 */     this.low = paramInt1;
/*  55 */     this.sqlState = paramString;
/*  56 */     this.exception = paramInt3;
/*  57 */     this.high = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean isIncluded(int paramInt) {
/*  63 */     return (this.low <= paramInt && paramInt <= this.high);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLException newSQLException(String paramString, int paramInt) {
/*  69 */     switch (this.exception) {
/*     */       case 0:
/*  71 */         return new SQLException(paramString, this.sqlState, paramInt);
/*     */     } 
/*     */ 
/*     */     
/*  75 */     return new SQLException(paramString, this.sqlState, paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   boolean lessThan(SQLStateMapping paramSQLStateMapping) {
/*  81 */     if (this.low < paramSQLStateMapping.low) {
/*  82 */       return (this.high < paramSQLStateMapping.high);
/*     */     }
/*     */     
/*  85 */     return (this.high <= paramSQLStateMapping.high);
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  90 */     return super.toString() + "(" + this.low + ", " + this.high + ", " + this.sqlState + ", " + this.exception + ")";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] paramArrayOfString) throws IOException {
/*  97 */     SQLStateMapping[] arrayOfSQLStateMapping = doGetMappings();
/*  98 */     System.out.println("a\t" + arrayOfSQLStateMapping);
/*  99 */     for (byte b = 0; b < arrayOfSQLStateMapping.length; b++) {
/* 100 */       System.out.println("low:\t" + (arrayOfSQLStateMapping[b]).low + "\thigh:\t" + (arrayOfSQLStateMapping[b]).high + "\tsqlState:\t" + (arrayOfSQLStateMapping[b]).sqlState + "\tsqlException:\t" + (arrayOfSQLStateMapping[b]).exception);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SQLStateMapping[] getMappings() {
/* 110 */     if (all == null) {
/*     */       try {
/* 112 */         all = doGetMappings();
/*     */       }
/* 114 */       catch (Throwable throwable) {
/*     */         
/* 116 */         all = new SQLStateMapping[0];
/*     */       } 
/*     */     }
/* 119 */     return all;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SQLStateMapping[] doGetMappings() throws IOException {
/* 127 */     InputStream inputStream = SQLStateMapping.class.getResourceAsStream("errorMap.xml");
/* 128 */     ArrayList arrayList = new ArrayList(128);
/* 129 */     load(inputStream, arrayList);
/* 130 */     return (SQLStateMapping[])arrayList.toArray((Object[])new SQLStateMapping[0]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static void load(InputStream paramInputStream, List paramList) throws IOException {
/* 152 */     BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(paramInputStream));
/* 153 */     Tokenizer tokenizer = new Tokenizer(bufferedReader);
/* 154 */     int i = -1;
/* 155 */     int j = -1;
/* 156 */     String str1 = null;
/* 157 */     int k = -1;
/* 158 */     String str2 = null;
/* 159 */     byte b = 0;
/*     */     String str3;
/* 161 */     while ((str3 = tokenizer.next()) != null) {
/* 162 */       switch (b) {
/*     */         case false:
/* 164 */           if (str3.equals("<")) b = 1; 
/*     */           continue;
/*     */         case true:
/* 167 */           if (str3.equals("!")) { b = 2; continue; }
/* 168 */            if (str3.equals("oraErrorSqlStateSqlExceptionMapping")) { b = 6; continue; }
/* 169 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");
/*     */ 
/*     */         
/*     */         case true:
/* 173 */           if (str3.equals("-")) { b = 3; continue; }
/* 174 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */ 
/*     */         
/*     */         case true:
/* 178 */           if (str3.equals("-")) b = 4; 
/*     */           continue;
/*     */         case true:
/* 181 */           if (str3.equals("-")) { b = 5; continue; }
/* 182 */            b = 3;
/*     */           continue;
/*     */         case true:
/* 185 */           if (str3.equals(">")) { b = 1; continue; }
/* 186 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 190 */           if (str3.equals(">")) { b = 7; continue; }
/* 191 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 195 */           if (str3.equals("<")) { b = 8; continue; }
/* 196 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"<\".");
/*     */ 
/*     */         
/*     */         case true:
/* 200 */           if (str3.equals("!")) { b = 9; continue; }
/* 201 */            if (str3.equals("error")) { b = 14; continue; }
/* 202 */            if (str3.equals("/")) { b = 16; continue; }
/* 203 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected one of \"!--\", \"error\", \"/\".");
/*     */ 
/*     */         
/*     */         case true:
/* 207 */           if (str3.equals("-")) { b = 10; continue; }
/* 208 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */ 
/*     */         
/*     */         case true:
/* 212 */           if (str3.equals("-")) { b = 11; continue; }
/* 213 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"-\".");
/*     */ 
/*     */         
/*     */         case true:
/* 217 */           if (str3.equals("-")) b = 12; 
/*     */           continue;
/*     */         case true:
/* 220 */           if (str3.equals("-")) { b = 13; continue; }
/* 221 */            b = 11;
/*     */           continue;
/*     */         case true:
/* 224 */           if (str3.equals(">")) { b = 7; continue; }
/* 225 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 229 */           if (str3.equals("/")) { b = 15; continue; }
/* 230 */            if (str3.equals("oraErrorFrom")) { b = 19; continue; }
/* 231 */            if (str3.equals("oraErrorTo")) { b = 21; continue; }
/* 232 */            if (str3.equals("sqlState")) { b = 23; continue; }
/* 233 */            if (str3.equals("sqlException")) { b = 25; continue; }
/* 234 */            if (str3.equals("comment")) { b = 27; continue; }
/* 235 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected one of " + "\"oraErrorFrom\", \"oraErrorTo\", \"sqlState\", " + "\"sqlException\", \"comment\", \"/\".");
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case true:
/* 241 */           if (str3.equals(">")) {
/*     */             try {
/* 243 */               createOne(paramList, i, j, str1, k, str2);
/*     */             }
/* 245 */             catch (IOException iOException) {
/* 246 */               throw new IOException("Invalid error element at line " + tokenizer.lineno + " of errorMap.xml. " + iOException.getMessage());
/*     */             } 
/*     */             
/* 249 */             i = -1;
/* 250 */             j = -1;
/* 251 */             str1 = null;
/* 252 */             k = -1;
/* 253 */             str2 = null;
/* 254 */             b = 7; continue;
/*     */           } 
/* 256 */           throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */ 
/*     */         
/*     */         case true:
/* 260 */           if (str3.equals("oraErrorSqlStateSqlExceptionMapping")) { b = 17; continue; }
/* 261 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"oraErrorSqlStateSqlExceptionMapping\".");
/*     */ 
/*     */         
/*     */         case true:
/* 265 */           if (str3.equals(">")) { b = 18; continue; }
/* 266 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \">\".");
/*     */         
/*     */         case true:
/*     */           continue;
/*     */         
/*     */         case true:
/* 272 */           if (str3.equals("=")) { b = 20; continue; }
/* 273 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/*     */           try {
/* 278 */             i = Integer.parseInt(str3);
/*     */           }
/* 280 */           catch (NumberFormatException numberFormatException) {
/* 281 */             throw new IOException("Unexpected value \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected an integer.");
/*     */           } 
/*     */           
/* 284 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 287 */           if (str3.equals("=")) { b = 22; continue; }
/* 288 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/*     */           try {
/* 293 */             j = Integer.parseInt(str3);
/*     */           }
/* 295 */           catch (NumberFormatException numberFormatException) {
/* 296 */             throw new IOException("Unexpected value \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected an integer.");
/*     */           } 
/*     */           
/* 299 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 302 */           if (str3.equals("=")) { b = 24; continue; }
/* 303 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/* 307 */           str1 = str3;
/* 308 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 311 */           if (str3.equals("=")) { b = 26; continue; }
/* 312 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/*     */           try {
/* 317 */             k = valueOf(str3);
/*     */           }
/* 319 */           catch (Exception exception) {
/* 320 */             throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected SQLException" + " subclass name.");
/*     */           } 
/*     */ 
/*     */           
/* 324 */           b = 14;
/*     */           continue;
/*     */         case true:
/* 327 */           if (str3.equals("=")) { b = 28; continue; }
/* 328 */            throw new IOException("Unexpected token \"" + str3 + "\" at line " + tokenizer.lineno + " of errorMap.xml. Expected \"=\".");
/*     */ 
/*     */         
/*     */         case true:
/* 332 */           str2 = str3;
/* 333 */           b = 14;
/*     */           continue;
/*     */       } 
/* 336 */       throw new IOException("Unknown parser state " + b + " at line " + tokenizer.lineno + " of errorMap.xml.");
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final class Tokenizer
/*     */   {
/* 354 */     int lineno = 1;
/*     */     Reader r;
/*     */     int c;
/*     */     
/*     */     Tokenizer(Reader param1Reader) throws IOException {
/* 359 */       this.r = param1Reader;
/* 360 */       this.c = param1Reader.read();
/*     */     }
/*     */     
/*     */     String next() throws IOException {
/* 364 */       StringBuffer stringBuffer = new StringBuffer(16);
/* 365 */       boolean bool = true;
/*     */       
/* 367 */       while (this.c != -1) {
/* 368 */         if (this.c == 10) this.lineno++; 
/* 369 */         if (this.c <= 32 && bool) {
/* 370 */           this.c = this.r.read();
/*     */           continue;
/*     */         } 
/* 373 */         if (this.c <= 32 && !bool) {
/* 374 */           this.c = this.r.read();
/*     */           break;
/*     */         } 
/* 377 */         if (this.c == 34) {
/* 378 */           for (; (this.c = this.r.read()) != 34; stringBuffer.append((char)this.c));
/* 379 */           this.c = this.r.read();
/*     */           break;
/*     */         } 
/* 382 */         if ((48 <= this.c && this.c <= 57) || (65 <= this.c && this.c <= 90) || (97 <= this.c && this.c <= 122) || this.c == 95) {
/*     */           
/*     */           do
/*     */           {
/*     */             
/* 387 */             stringBuffer.append((char)this.c);
/*     */ 
/*     */           
/*     */           }
/* 391 */           while ((48 <= (this.c = this.r.read()) && this.c <= 57) || (65 <= this.c && this.c <= 90) || (97 <= this.c && this.c <= 122) || this.c == 95);
/*     */           break;
/*     */         } 
/* 394 */         stringBuffer.append((char)this.c);
/* 395 */         this.c = this.r.read();
/*     */         break;
/*     */       } 
/* 398 */       if (stringBuffer.length() > 0) return stringBuffer.toString(); 
/* 399 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private static void createOne(List paramList, int paramInt1, int paramInt2, String paramString1, int paramInt3, String paramString2) throws IOException {
/* 405 */     if (paramInt1 == -1) throw new IOException("oraErrorFrom is a required attribute"); 
/* 406 */     if (paramInt2 == -1) paramInt2 = paramInt1; 
/* 407 */     if (paramString1 == null || paramString1.length() == 0) throw new IOException("sqlState is a required attribute"); 
/* 408 */     if (paramInt3 == -1) throw new IOException("sqlException is a required attribute"); 
/* 409 */     if (paramString2 == null || paramString2.length() < 8) throw new IOException("a lengthy comment in required"); 
/* 410 */     SQLStateMapping sQLStateMapping = new SQLStateMapping(paramInt1, paramInt2, paramString1, paramInt3);
/* 411 */     add(paramList, sQLStateMapping);
/*     */   }
/*     */   
/*     */   static void add(List<SQLStateMapping> paramList, SQLStateMapping paramSQLStateMapping) {
/* 415 */     int i = paramList.size();
/* 416 */     for (; i > 0 && 
/* 417 */       !((SQLStateMapping)paramList.get(i - 1)).lessThan(paramSQLStateMapping); i--);
/*     */ 
/*     */ 
/*     */     
/* 421 */     paramList.add(i, paramSQLStateMapping);
/*     */   }
/*     */ 
/*     */   
/*     */   static int valueOf(String paramString) throws Exception {
/* 426 */     if (paramString.equalsIgnoreCase("SQLEXCEPTION")) return 0; 
/* 427 */     if (paramString.equalsIgnoreCase("SQLNONTRANSIENTEXCEPTION")) return 1; 
/* 428 */     if (paramString.equalsIgnoreCase("SQLTRANSIENTEXCEPTION")) return 2; 
/* 429 */     if (paramString.equalsIgnoreCase("SQLDATAEXCEPTION")) return 3; 
/* 430 */     if (paramString.equalsIgnoreCase("SQLFEATURENOTSUPPORTEDEXCEPTION")) return 4; 
/* 431 */     if (paramString.equalsIgnoreCase("SQLINTEGRITYCONSTRAINTVIOLATIONEXCEPTION")) return 5; 
/* 432 */     if (paramString.equalsIgnoreCase("SQLINVALIDAUTHORIZATIONSPECEXCEPTION")) return 6; 
/* 433 */     if (paramString.equalsIgnoreCase("SQLNONTRANSIENTCONNECTIONEXCEPTION")) return 7; 
/* 434 */     if (paramString.equalsIgnoreCase("SQLSYNTAXERROREXCEPTION")) return 8; 
/* 435 */     if (paramString.equalsIgnoreCase("SQLTIMEOUTEXCEPTION")) return 9; 
/* 436 */     if (paramString.equalsIgnoreCase("SQLTRANSACTIONROLLBACKEXCEPTION")) return 10; 
/* 437 */     if (paramString.equalsIgnoreCase("SQLTRANSIENTCONNECTIONEXCEPTION")) return 11; 
/* 438 */     if (paramString.equalsIgnoreCase("SQLCLIENTINFOEXCEPTION")) return 12; 
/* 439 */     if (paramString.equalsIgnoreCase("SQLRECOVERABLEEXCEPTION")) return 13; 
/* 440 */     throw new Exception("unexpected exception name: " + paramString);
/*     */   }
/*     */ 
/*     */   
/* 444 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/SQLStateMapping.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */