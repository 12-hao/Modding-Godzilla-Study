/*       */ package oracle.jdbc.driver;
/*       */ import java.lang.reflect.Field;
/*       */ import java.math.BigDecimal;
/*       */ import java.math.BigInteger;
/*       */ import java.net.InetAddress;
/*       */ import java.net.UnknownHostException;
/*       */ import java.security.Permission;
/*       */ import java.security.PrivilegedAction;
/*       */ import java.sql.Array;
/*       */ import java.sql.CallableStatement;
/*       */ import java.sql.Connection;
/*       */ import java.sql.DatabaseMetaData;
/*       */ import java.sql.Date;
/*       */ import java.sql.DriverManager;
/*       */ import java.sql.PreparedStatement;
/*       */ import java.sql.ResultSet;
/*       */ import java.sql.ResultSetMetaData;
/*       */ import java.sql.SQLException;
/*       */ import java.sql.SQLWarning;
/*       */ import java.sql.Savepoint;
/*       */ import java.sql.Statement;
/*       */ import java.sql.Struct;
/*       */ import java.sql.Time;
/*       */ import java.sql.Timestamp;
/*       */ import java.util.ArrayList;
/*       */ import java.util.Calendar;
/*       */ import java.util.EnumSet;
/*       */ import java.util.Enumeration;
/*       */ import java.util.GregorianCalendar;
/*       */ import java.util.Hashtable;
/*       */ import java.util.Map;
/*       */ import java.util.Properties;
/*       */ import java.util.TimeZone;
/*       */ import java.util.Vector;
/*       */ import java.util.regex.Pattern;
/*       */ import oracle.jdbc.OracleCallableStatement;
/*       */ import oracle.jdbc.OracleConnection;
/*       */ import oracle.jdbc.OraclePreparedStatement;
/*       */ import oracle.jdbc.OracleSQLPermission;
/*       */ import oracle.jdbc.OracleSavepoint;
/*       */ import oracle.jdbc.OracleStatement;
/*       */ import oracle.jdbc.aq.AQDequeueOptions;
/*       */ import oracle.jdbc.aq.AQEnqueueOptions;
/*       */ import oracle.jdbc.aq.AQMessage;
/*       */ import oracle.jdbc.aq.AQNotificationRegistration;
/*       */ import oracle.jdbc.dcn.DatabaseChangeRegistration;
/*       */ import oracle.jdbc.internal.KeywordValueLong;
/*       */ import oracle.jdbc.internal.OracleConnection;
/*       */ import oracle.jdbc.internal.OracleStatement;
/*       */ import oracle.jdbc.internal.XSEventListener;
/*       */ import oracle.jdbc.internal.XSNamespace;
/*       */ import oracle.jdbc.oracore.OracleTypeADT;
/*       */ import oracle.jdbc.pool.OracleConnectionCacheCallback;
/*       */ import oracle.jdbc.pool.OraclePooledConnection;
/*       */ import oracle.net.nt.CustomSSLSocketFactory;
/*       */ import oracle.security.pki.OracleSecretStore;
/*       */ import oracle.security.pki.OracleWallet;
/*       */ import oracle.sql.ARRAY;
/*       */ import oracle.sql.ArrayDescriptor;
/*       */ import oracle.sql.BFILE;
/*       */ import oracle.sql.BINARY_DOUBLE;
/*       */ import oracle.sql.BINARY_FLOAT;
/*       */ import oracle.sql.BLOB;
/*       */ import oracle.sql.BfileDBAccess;
/*       */ import oracle.sql.BlobDBAccess;
/*       */ import oracle.sql.CLOB;
/*       */ import oracle.sql.CharacterSet;
/*       */ import oracle.sql.CustomDatum;
/*       */ import oracle.sql.DATE;
/*       */ import oracle.sql.Datum;
/*       */ import oracle.sql.INTERVALDS;
/*       */ import oracle.sql.INTERVALYM;
/*       */ import oracle.sql.NCLOB;
/*       */ import oracle.sql.NUMBER;
/*       */ import oracle.sql.SQLName;
/*       */ import oracle.sql.StructDescriptor;
/*       */ import oracle.sql.TIMESTAMP;
/*       */ import oracle.sql.TIMESTAMPLTZ;
/*       */ import oracle.sql.TIMESTAMPTZ;
/*       */ import oracle.sql.TIMEZONETAB;
/*       */ import oracle.sql.TypeDescriptor;
/*       */ 
/*       */ abstract class PhysicalConnection extends OracleConnection {
/*       */   public static final String SECRET_STORE_CONNECT = "oracle.security.client.connect_string";
/*       */   public static final String SECRET_STORE_USERNAME = "oracle.security.client.username";
/*       */   public static final String SECRET_STORE_PASSWORD = "oracle.security.client.password";
/*       */   public static final String SECRET_STORE_DEFAULT_USERNAME = "oracle.security.client.default_username";
/*       */   public static final String SECRET_STORE_DEFAULT_PASSWORD = "oracle.security.client.default_password";
/*    89 */   static final CRC64 CHECKSUM = new CRC64();
/*       */   public static final char slash_character = '/';
/*       */   public static final char at_sign_character = '@';
/*       */   public static final char left_square_bracket_character = '[';
/*       */   public static final char right_square_bracket_character = ']';
/*    94 */   static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*    99 */   long outScn = 0L;
/*       */   
/*   101 */   char[][] charOutput = new char[1][];
/*   102 */   byte[][] byteOutput = new byte[1][];
/*   103 */   short[][] shortOutput = new short[1][];
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   109 */   Properties sessionProperties = null;
/*       */   
/*       */   boolean retainV9BindBehavior;
/*       */   
/*       */   String userName;
/*       */   
/*       */   String database;
/*       */   
/*       */   boolean autocommit;
/*       */   
/*       */   String protocol;
/*       */   
/*       */   int streamChunkSize;
/*       */   
/*       */   boolean setFloatAndDoubleUseBinary;
/*       */   String thinVsessionTerminal;
/*       */   String thinVsessionMachine;
/*       */   String thinVsessionOsuser;
/*       */   String thinVsessionProgram;
/*       */   String thinVsessionProcess;
/*       */   String thinVsessionIname;
/*       */   String thinVsessionEname;
/*       */   String thinNetProfile;
/*       */   String thinNetAuthenticationServices;
/*       */   String thinNetAuthenticationKrb5Mutual;
/*       */   String thinNetAuthenticationKrb5CcName;
/*       */   String thinNetEncryptionLevel;
/*       */   String thinNetEncryptionTypes;
/*       */   String thinNetChecksumLevel;
/*       */   String thinNetChecksumTypes;
/*       */   String thinNetCryptoSeed;
/*       */   boolean thinTcpNoDelay;
/*       */   String thinReadTimeout;
/*       */   String thinNetConnectTimeout;
/*       */   boolean thinNetDisableOutOfBandBreak;
/*       */   boolean thinNetUseZeroCopyIO;
/*       */   boolean thinNetEnableSDP;
/*       */   boolean use1900AsYearForTime;
/*       */   boolean timestamptzInGmt;
/*       */   boolean timezoneAsRegion;
/*       */   String thinSslServerDnMatch;
/*       */   String thinSslVersion;
/*       */   String thinSslCipherSuites;
/*       */   String thinJavaxNetSslKeystore;
/*       */   String thinJavaxNetSslKeystoretype;
/*       */   String thinJavaxNetSslKeystorepassword;
/*       */   String thinJavaxNetSslTruststore;
/*       */   String thinJavaxNetSslTruststoretype;
/*       */   String thinJavaxNetSslTruststorepassword;
/*       */   String thinSslKeymanagerfactoryAlgorithm;
/*       */   String thinSslTrustmanagerfactoryAlgorithm;
/*       */   String thinNetOldsyntax;
/*       */   String thinNamingContextInitial;
/*       */   String thinNamingProviderUrl;
/*       */   String thinNamingSecurityAuthentication;
/*       */   String thinNamingSecurityPrincipal;
/*       */   String thinNamingSecurityCredentials;
/*       */   String walletLocation;
/*       */   String walletPassword;
/*       */   String proxyClientName;
/*       */   boolean useNio;
/*       */   String ociDriverCharset;
/*       */   String editionName;
/*       */   String logonCap;
/*       */   String internalLogon;
/*       */   boolean createDescriptorUseCurrentSchemaForSchemaName;
/*       */   long ociSvcCtxHandle;
/*       */   long ociEnvHandle;
/*       */   long ociErrHandle;
/*       */   boolean prelimAuth;
/*       */   boolean nlsLangBackdoor;
/*       */   String setNewPassword;
/*       */   boolean spawnNewThreadToCancel;
/*       */   int defaultExecuteBatch;
/*       */   int defaultRowPrefetch;
/*       */   int defaultLobPrefetchSize;
/*       */   boolean enableDataInLocator;
/*       */   boolean enableReadDataInLocator;
/*       */   boolean overrideEnableReadDataInLocator;
/*       */   boolean reportRemarks;
/*       */   boolean includeSynonyms;
/*       */   boolean restrictGettables;
/*       */   boolean accumulateBatchResult;
/*       */   boolean useFetchSizeWithLongColumn;
/*       */   boolean processEscapes;
/*       */   boolean fixedString;
/*       */   boolean defaultnchar;
/*       */   boolean permitTimestampDateMismatch;
/*       */   String resourceManagerId;
/*       */   boolean disableDefinecolumntype;
/*       */   boolean convertNcharLiterals;
/*       */   boolean j2ee13Compliant;
/*       */   boolean mapDateToTimestamp;
/*       */   boolean useThreadLocalBufferCache;
/*       */   String driverNameAttribute;
/*       */   int maxCachedBufferSize;
/*       */   int implicitStatementCacheSize;
/*       */   boolean lobStreamPosStandardCompliant;
/*       */   boolean isStrictAsciiConversion;
/*       */   boolean isQuickAsciiConversion;
/*       */   boolean thinForceDnsLoadBalancing;
/*       */   boolean enableJavaNetFastPath;
/*       */   boolean enableTempLobRefCnt;
/*       */   boolean plsqlVarcharParameter4KOnly;
/*       */   boolean keepAlive;
/*       */   public boolean calculateChecksum;
/*       */   String url;
/*       */   String savedUser;
/*       */   int commitOption;
/*   218 */   int ociConnectionPoolMinLimit = 0;
/*   219 */   int ociConnectionPoolMaxLimit = 0;
/*   220 */   int ociConnectionPoolIncrement = 0;
/*   221 */   int ociConnectionPoolTimeout = 0;
/*       */   boolean ociConnectionPoolNoWait = false;
/*       */   boolean ociConnectionPoolTransactionDistributed = false;
/*   224 */   String ociConnectionPoolLogonMode = null;
/*       */   boolean ociConnectionPoolIsPooling = false;
/*   226 */   Object ociConnectionPoolObject = null;
/*   227 */   Object ociConnectionPoolConnID = null;
/*   228 */   String ociConnectionPoolProxyType = null;
/*   229 */   Integer ociConnectionPoolProxyNumRoles = Integer.valueOf(0);
/*   230 */   Object ociConnectionPoolProxyRoles = null;
/*   231 */   String ociConnectionPoolProxyUserName = null;
/*   232 */   String ociConnectionPoolProxyPassword = null;
/*   233 */   String ociConnectionPoolProxyDistinguishedName = null;
/*   234 */   Object ociConnectionPoolProxyCertificate = null;
/*       */   
/*   236 */   static NTFManager ntfManager = new NTFManager();
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   247 */   public int protocolId = -3;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTimeout timeout;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   DBConversion conversion;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean xaWantsError;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean usingXA;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   272 */   int txnMode = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] fdo;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   Boolean bigEndian;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleStatement statements;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int lifecycle;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int OPEN = 1;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static final int CLOSING = 2;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int CLOSED = 4;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int ABORTED = 8;
/*       */ 
/*       */ 
/*       */   
/*       */   static final int BLOCKED = 16;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean clientIdSet = false;
/*       */ 
/*       */ 
/*       */   
/*   322 */   String clientId = null;
/*       */ 
/*       */ 
/*       */   
/*       */   int txnLevel;
/*       */ 
/*       */ 
/*       */   
/*       */   Map map;
/*       */ 
/*       */ 
/*       */   
/*       */   Map javaObjectMap;
/*       */ 
/*       */ 
/*       */   
/*   338 */   final Hashtable[] descriptorCacheStack = new Hashtable[2];
/*       */   
/*   340 */   int dci = 0;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleStatement statementHoldingLine;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   352 */   OracleDatabaseMetaData databaseMetaData = null;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   LogicalConnection logicalConnectionAttached;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean isProxy = false;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   367 */   OracleSql sqlObj = null;
/*       */ 
/*       */   
/*   370 */   SQLWarning sqlWarning = null;
/*       */ 
/*       */ 
/*       */   
/*       */   boolean readOnly = false;
/*       */ 
/*       */ 
/*       */   
/*   378 */   LRUStatementCache statementCache = null;
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean clearStatementMetaData = false;
/*       */ 
/*       */ 
/*       */   
/*   387 */   OracleCloseCallback closeCallback = null;
/*   388 */   Object privateData = null;
/*       */ 
/*       */   
/*   391 */   Statement savepointStatement = null;
/*       */ 
/*       */   
/*       */   boolean isUsable = true;
/*       */   
/*   396 */   TimeZone defaultTimeZone = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   421 */   final int[] endToEndMaxLength = new int[4];
/*       */   
/*       */   boolean endToEndAnyChanged = false;
/*   424 */   final boolean[] endToEndHasChanged = new boolean[4];
/*   425 */   short endToEndECIDSequenceNumber = Short.MIN_VALUE;
/*       */ 
/*       */   
/*       */   static final int DMS_NONE = 0;
/*       */ 
/*       */   
/*       */   static final int DMS_10G = 1;
/*       */   
/*       */   static final int DMS_11 = 2;
/*       */   
/*   435 */   String[] endToEndValues = null;
/*   436 */   final int whichDMS = 0;
/*       */ 
/*       */ 
/*       */   
/*   440 */   OracleConnection wrapper = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int minVcsBindSize;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxRawBytesPlsql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsCharsSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsNCharsSql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxVcsBytesPlsql;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int maxIbtVarcharElementLength;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*   493 */   String instanceName = null;
/*       */   OracleDriverExtension driverExtension;
/*       */   static final String uninitializedMarker = "";
/*   496 */   String databaseProductVersion = "";
/*   497 */   short versionNumber = -1;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int namedTypeAccessorByteLen;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int refTypeAccessorByteLen;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   CharacterSet setCHARCharSetObj;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   CharacterSet setCHARNCharSetObj;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected final Object cancelInProgressLockForThin;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   boolean plsqlCompilerWarnings = false;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final String propertyVariableName(String paramString) {
/*   687 */     char[] arrayOfChar = new char[paramString.length()];
/*   688 */     paramString.getChars(0, paramString.length(), arrayOfChar, 0);
/*   689 */     String str = "";
/*   690 */     for (byte b = 0; b < arrayOfChar.length; b++) {
/*       */       
/*   692 */       if (Character.isUpperCase(arrayOfChar[b]))
/*   693 */         str = str + "_"; 
/*   694 */       str = str + Character.toUpperCase(arrayOfChar[b]);
/*       */     } 
/*   696 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private void readConnectionProperties(String paramString, Properties paramProperties) throws SQLException {
/*   731 */     String str1 = null;
/*       */ 
/*       */     
/*   734 */     str1 = null;
/*   735 */     if (paramProperties != null)
/*       */     {
/*   737 */       str1 = paramProperties.getProperty("oracle.jdbc.RetainV9LongBindBehavior");
/*       */     }
/*   739 */     if (str1 == null)
/*   740 */       str1 = getSystemProperty("oracle.jdbc.RetainV9LongBindBehavior", (String)null); 
/*   741 */     if (str1 == null) {
/*   742 */       str1 = "false";
/*       */     }
/*       */     
/*   745 */     this.retainV9BindBehavior = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*   748 */     str1 = null;
/*   749 */     if (paramProperties != null) {
/*       */       
/*   751 */       str1 = paramProperties.getProperty("user");
/*   752 */       if (str1 == null)
/*   753 */         str1 = paramProperties.getProperty("oracle.jdbc.user"); 
/*       */     } 
/*   755 */     if (str1 == null)
/*   756 */       str1 = getSystemProperty("oracle.jdbc.user", (String)null); 
/*   757 */     if (str1 == null) {
/*   758 */       str1 = null;
/*       */     }
/*       */     
/*   761 */     this.userName = str1;
/*       */ 
/*       */     
/*   764 */     str1 = null;
/*   765 */     if (paramProperties != null) {
/*       */       
/*   767 */       str1 = paramProperties.getProperty("database");
/*   768 */       if (str1 == null)
/*   769 */         str1 = paramProperties.getProperty("oracle.jdbc.database"); 
/*       */     } 
/*   771 */     if (str1 == null)
/*   772 */       str1 = getSystemProperty("oracle.jdbc.database", (String)null); 
/*   773 */     if (str1 == null) {
/*   774 */       str1 = null;
/*       */     }
/*       */     
/*   777 */     this.database = str1;
/*       */ 
/*       */     
/*   780 */     str1 = null;
/*   781 */     if (paramProperties != null) {
/*       */       
/*   783 */       str1 = paramProperties.getProperty("autoCommit");
/*   784 */       if (str1 == null)
/*   785 */         str1 = paramProperties.getProperty("oracle.jdbc.autoCommit"); 
/*       */     } 
/*   787 */     if (str1 == null)
/*   788 */       str1 = getSystemProperty("oracle.jdbc.autoCommit", (String)null); 
/*   789 */     if (str1 == null) {
/*   790 */       str1 = "true";
/*       */     }
/*       */     
/*   793 */     this.autocommit = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*   796 */     str1 = null;
/*   797 */     if (paramProperties != null) {
/*       */       
/*   799 */       str1 = paramProperties.getProperty("protocol");
/*   800 */       if (str1 == null)
/*   801 */         str1 = paramProperties.getProperty("oracle.jdbc.protocol"); 
/*       */     } 
/*   803 */     if (str1 == null)
/*   804 */       str1 = getSystemProperty("oracle.jdbc.protocol", (String)null); 
/*   805 */     if (str1 == null) {
/*   806 */       str1 = null;
/*       */     }
/*       */     
/*   809 */     this.protocol = str1;
/*       */ 
/*       */     
/*   812 */     str1 = null;
/*   813 */     if (paramProperties != null)
/*       */     {
/*   815 */       str1 = paramProperties.getProperty("oracle.jdbc.StreamChunkSize");
/*       */     }
/*   817 */     if (str1 == null)
/*   818 */       str1 = getSystemProperty("oracle.jdbc.StreamChunkSize", (String)null); 
/*   819 */     if (str1 == null) {
/*   820 */       str1 = "16384";
/*       */     }
/*       */     try {
/*   823 */       this.streamChunkSize = Integer.parseInt(str1);
/*   824 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*   828 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'streamChunkSize'");
/*   829 */       sQLException.fillInStackTrace();
/*   830 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*   836 */     str1 = null;
/*   837 */     if (paramProperties != null) {
/*       */       
/*   839 */       str1 = paramProperties.getProperty("SetFloatAndDoubleUseBinary");
/*   840 */       if (str1 == null)
/*   841 */         str1 = paramProperties.getProperty("oracle.jdbc.SetFloatAndDoubleUseBinary"); 
/*       */     } 
/*   843 */     if (str1 == null)
/*   844 */       str1 = getSystemProperty("oracle.jdbc.SetFloatAndDoubleUseBinary", (String)null); 
/*   845 */     if (str1 == null) {
/*   846 */       str1 = "false";
/*       */     }
/*       */     
/*   849 */     this.setFloatAndDoubleUseBinary = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*   852 */     str1 = null;
/*   853 */     if (paramProperties != null) {
/*       */       
/*   855 */       str1 = paramProperties.getProperty("v$session.terminal");
/*   856 */       if (str1 == null)
/*   857 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.terminal"); 
/*       */     } 
/*   859 */     if (str1 == null)
/*   860 */       str1 = getSystemProperty("oracle.jdbc.v$session.terminal", (String)null); 
/*   861 */     if (str1 == null) {
/*   862 */       str1 = "unknown";
/*       */     }
/*       */     
/*   865 */     this.thinVsessionTerminal = str1;
/*       */ 
/*       */     
/*   868 */     str1 = null;
/*   869 */     if (paramProperties != null) {
/*       */       
/*   871 */       str1 = paramProperties.getProperty("v$session.machine");
/*   872 */       if (str1 == null)
/*   873 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.machine"); 
/*       */     } 
/*   875 */     if (str1 == null)
/*   876 */       str1 = getSystemProperty("oracle.jdbc.v$session.machine", (String)null); 
/*   877 */     if (str1 == null) {
/*   878 */       str1 = null;
/*       */     }
/*       */     
/*   881 */     this.thinVsessionMachine = str1;
/*       */ 
/*       */     
/*   884 */     str1 = null;
/*   885 */     if (paramProperties != null) {
/*       */       
/*   887 */       str1 = paramProperties.getProperty("v$session.osuser");
/*   888 */       if (str1 == null)
/*   889 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.osuser"); 
/*       */     } 
/*   891 */     if (str1 == null)
/*   892 */       str1 = getSystemProperty("oracle.jdbc.v$session.osuser", (String)null); 
/*   893 */     if (str1 == null) {
/*   894 */       str1 = null;
/*       */     }
/*       */     
/*   897 */     this.thinVsessionOsuser = str1;
/*       */ 
/*       */     
/*   900 */     str1 = null;
/*   901 */     if (paramProperties != null) {
/*       */       
/*   903 */       str1 = paramProperties.getProperty("v$session.program");
/*   904 */       if (str1 == null)
/*   905 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.program"); 
/*       */     } 
/*   907 */     if (str1 == null)
/*   908 */       str1 = getSystemProperty("oracle.jdbc.v$session.program", (String)null); 
/*   909 */     if (str1 == null) {
/*   910 */       str1 = "JDBC Thin Client";
/*       */     }
/*       */     
/*   913 */     this.thinVsessionProgram = str1;
/*       */ 
/*       */     
/*   916 */     str1 = null;
/*   917 */     if (paramProperties != null) {
/*       */       
/*   919 */       str1 = paramProperties.getProperty("v$session.process");
/*   920 */       if (str1 == null)
/*   921 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.process"); 
/*       */     } 
/*   923 */     if (str1 == null)
/*   924 */       str1 = getSystemProperty("oracle.jdbc.v$session.process", (String)null); 
/*   925 */     if (str1 == null) {
/*   926 */       str1 = "1234";
/*       */     }
/*       */     
/*   929 */     this.thinVsessionProcess = str1;
/*       */ 
/*       */     
/*   932 */     str1 = null;
/*   933 */     if (paramProperties != null) {
/*       */       
/*   935 */       str1 = paramProperties.getProperty("v$session.iname");
/*   936 */       if (str1 == null)
/*   937 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.iname"); 
/*       */     } 
/*   939 */     if (str1 == null)
/*   940 */       str1 = getSystemProperty("oracle.jdbc.v$session.iname", (String)null); 
/*   941 */     if (str1 == null) {
/*   942 */       str1 = "jdbc_ttc_impl";
/*       */     }
/*       */     
/*   945 */     this.thinVsessionIname = str1;
/*       */ 
/*       */     
/*   948 */     str1 = null;
/*   949 */     if (paramProperties != null) {
/*       */       
/*   951 */       str1 = paramProperties.getProperty("v$session.ename");
/*   952 */       if (str1 == null)
/*   953 */         str1 = paramProperties.getProperty("oracle.jdbc.v$session.ename"); 
/*       */     } 
/*   955 */     if (str1 == null)
/*   956 */       str1 = getSystemProperty("oracle.jdbc.v$session.ename", (String)null); 
/*   957 */     if (str1 == null) {
/*   958 */       str1 = null;
/*       */     }
/*       */     
/*   961 */     this.thinVsessionEname = str1;
/*       */ 
/*       */     
/*   964 */     str1 = null;
/*   965 */     if (paramProperties != null)
/*       */     {
/*   967 */       str1 = paramProperties.getProperty("oracle.net.profile");
/*       */     }
/*   969 */     if (str1 == null)
/*   970 */       str1 = getSystemProperty("oracle.net.profile", (String)null); 
/*   971 */     if (str1 == null) {
/*   972 */       str1 = null;
/*       */     }
/*       */     
/*   975 */     this.thinNetProfile = str1;
/*       */ 
/*       */     
/*   978 */     str1 = null;
/*   979 */     if (paramProperties != null)
/*       */     {
/*   981 */       str1 = paramProperties.getProperty("oracle.net.authentication_services");
/*       */     }
/*   983 */     if (str1 == null)
/*   984 */       str1 = getSystemProperty("oracle.net.authentication_services", (String)null); 
/*   985 */     if (str1 == null) {
/*   986 */       str1 = null;
/*       */     }
/*       */     
/*   989 */     this.thinNetAuthenticationServices = str1;
/*       */ 
/*       */     
/*   992 */     str1 = null;
/*   993 */     if (paramProperties != null)
/*       */     {
/*   995 */       str1 = paramProperties.getProperty("oracle.net.kerberos5_mutual_authentication");
/*       */     }
/*   997 */     if (str1 == null)
/*   998 */       str1 = getSystemProperty("oracle.net.kerberos5_mutual_authentication", (String)null); 
/*   999 */     if (str1 == null) {
/*  1000 */       str1 = null;
/*       */     }
/*       */     
/*  1003 */     this.thinNetAuthenticationKrb5Mutual = str1;
/*       */ 
/*       */     
/*  1006 */     str1 = null;
/*  1007 */     if (paramProperties != null)
/*       */     {
/*  1009 */       str1 = paramProperties.getProperty("oracle.net.kerberos5_cc_name");
/*       */     }
/*  1011 */     if (str1 == null)
/*  1012 */       str1 = getSystemProperty("oracle.net.kerberos5_cc_name", (String)null); 
/*  1013 */     if (str1 == null) {
/*  1014 */       str1 = null;
/*       */     }
/*       */     
/*  1017 */     this.thinNetAuthenticationKrb5CcName = str1;
/*       */ 
/*       */     
/*  1020 */     str1 = null;
/*  1021 */     if (paramProperties != null)
/*       */     {
/*  1023 */       str1 = paramProperties.getProperty("oracle.net.encryption_client");
/*       */     }
/*  1025 */     if (str1 == null)
/*  1026 */       str1 = getSystemProperty("oracle.net.encryption_client", (String)null); 
/*  1027 */     if (str1 == null) {
/*  1028 */       str1 = null;
/*       */     }
/*       */     
/*  1031 */     this.thinNetEncryptionLevel = str1;
/*       */ 
/*       */     
/*  1034 */     str1 = null;
/*  1035 */     if (paramProperties != null)
/*       */     {
/*  1037 */       str1 = paramProperties.getProperty("oracle.net.encryption_types_client");
/*       */     }
/*  1039 */     if (str1 == null)
/*  1040 */       str1 = getSystemProperty("oracle.net.encryption_types_client", (String)null); 
/*  1041 */     if (str1 == null) {
/*  1042 */       str1 = null;
/*       */     }
/*       */     
/*  1045 */     this.thinNetEncryptionTypes = str1;
/*       */ 
/*       */     
/*  1048 */     str1 = null;
/*  1049 */     if (paramProperties != null)
/*       */     {
/*  1051 */       str1 = paramProperties.getProperty("oracle.net.crypto_checksum_client");
/*       */     }
/*  1053 */     if (str1 == null)
/*  1054 */       str1 = getSystemProperty("oracle.net.crypto_checksum_client", (String)null); 
/*  1055 */     if (str1 == null) {
/*  1056 */       str1 = null;
/*       */     }
/*       */     
/*  1059 */     this.thinNetChecksumLevel = str1;
/*       */ 
/*       */     
/*  1062 */     str1 = null;
/*  1063 */     if (paramProperties != null)
/*       */     {
/*  1065 */       str1 = paramProperties.getProperty("oracle.net.crypto_checksum_types_client");
/*       */     }
/*  1067 */     if (str1 == null)
/*  1068 */       str1 = getSystemProperty("oracle.net.crypto_checksum_types_client", (String)null); 
/*  1069 */     if (str1 == null) {
/*  1070 */       str1 = null;
/*       */     }
/*       */     
/*  1073 */     this.thinNetChecksumTypes = str1;
/*       */ 
/*       */     
/*  1076 */     str1 = null;
/*  1077 */     if (paramProperties != null)
/*       */     {
/*  1079 */       str1 = paramProperties.getProperty("oracle.net.crypto_seed");
/*       */     }
/*  1081 */     if (str1 == null)
/*  1082 */       str1 = getSystemProperty("oracle.net.crypto_seed", (String)null); 
/*  1083 */     if (str1 == null) {
/*  1084 */       str1 = null;
/*       */     }
/*       */     
/*  1087 */     this.thinNetCryptoSeed = str1;
/*       */ 
/*       */     
/*  1090 */     str1 = null;
/*  1091 */     if (paramProperties != null)
/*       */     {
/*  1093 */       str1 = paramProperties.getProperty("oracle.jdbc.TcpNoDelay");
/*       */     }
/*  1095 */     if (str1 == null)
/*  1096 */       str1 = getSystemProperty("oracle.jdbc.TcpNoDelay", (String)null); 
/*  1097 */     if (str1 == null) {
/*  1098 */       str1 = "false";
/*       */     }
/*       */     
/*  1101 */     this.thinTcpNoDelay = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1104 */     str1 = null;
/*  1105 */     if (paramProperties != null)
/*       */     {
/*  1107 */       str1 = paramProperties.getProperty("oracle.jdbc.ReadTimeout");
/*       */     }
/*  1109 */     if (str1 == null)
/*  1110 */       str1 = getSystemProperty("oracle.jdbc.ReadTimeout", (String)null); 
/*  1111 */     if (str1 == null) {
/*  1112 */       str1 = null;
/*       */     }
/*       */     
/*  1115 */     this.thinReadTimeout = str1;
/*       */ 
/*       */     
/*  1118 */     str1 = null;
/*  1119 */     if (paramProperties != null)
/*       */     {
/*  1121 */       str1 = paramProperties.getProperty("oracle.net.CONNECT_TIMEOUT");
/*       */     }
/*  1123 */     if (str1 == null)
/*  1124 */       str1 = getSystemProperty("oracle.net.CONNECT_TIMEOUT", (String)null); 
/*  1125 */     if (str1 == null) {
/*  1126 */       str1 = null;
/*       */     }
/*       */     
/*  1129 */     this.thinNetConnectTimeout = str1;
/*       */ 
/*       */     
/*  1132 */     str1 = null;
/*  1133 */     if (paramProperties != null)
/*       */     {
/*  1135 */       str1 = paramProperties.getProperty("oracle.net.disableOob");
/*       */     }
/*  1137 */     if (str1 == null)
/*  1138 */       str1 = getSystemProperty("oracle.net.disableOob", (String)null); 
/*  1139 */     if (str1 == null) {
/*  1140 */       str1 = "false";
/*       */     }
/*       */     
/*  1143 */     this.thinNetDisableOutOfBandBreak = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1146 */     str1 = null;
/*  1147 */     if (paramProperties != null)
/*       */     {
/*  1149 */       str1 = paramProperties.getProperty("oracle.net.useZeroCopyIO");
/*       */     }
/*  1151 */     if (str1 == null)
/*  1152 */       str1 = getSystemProperty("oracle.net.useZeroCopyIO", (String)null); 
/*  1153 */     if (str1 == null) {
/*  1154 */       str1 = "true";
/*       */     }
/*       */     
/*  1157 */     this.thinNetUseZeroCopyIO = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1160 */     str1 = null;
/*  1161 */     if (paramProperties != null)
/*       */     {
/*  1163 */       str1 = paramProperties.getProperty("oracle.net.SDP");
/*       */     }
/*  1165 */     if (str1 == null)
/*  1166 */       str1 = getSystemProperty("oracle.net.SDP", (String)null); 
/*  1167 */     if (str1 == null) {
/*  1168 */       str1 = "false";
/*       */     }
/*       */     
/*  1171 */     this.thinNetEnableSDP = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1174 */     str1 = null;
/*  1175 */     if (paramProperties != null)
/*       */     {
/*  1177 */       str1 = paramProperties.getProperty("oracle.jdbc.use1900AsYearForTime");
/*       */     }
/*  1179 */     if (str1 == null)
/*  1180 */       str1 = getSystemProperty("oracle.jdbc.use1900AsYearForTime", (String)null); 
/*  1181 */     if (str1 == null) {
/*  1182 */       str1 = "false";
/*       */     }
/*       */     
/*  1185 */     this.use1900AsYearForTime = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1188 */     str1 = null;
/*  1189 */     if (paramProperties != null)
/*       */     {
/*  1191 */       str1 = paramProperties.getProperty("oracle.jdbc.timestampTzInGmt");
/*       */     }
/*  1193 */     if (str1 == null)
/*  1194 */       str1 = getSystemProperty("oracle.jdbc.timestampTzInGmt", (String)null); 
/*  1195 */     if (str1 == null) {
/*  1196 */       str1 = "true";
/*       */     }
/*       */     
/*  1199 */     this.timestamptzInGmt = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1202 */     str1 = null;
/*  1203 */     if (paramProperties != null)
/*       */     {
/*  1205 */       str1 = paramProperties.getProperty("oracle.jdbc.timezoneAsRegion");
/*       */     }
/*  1207 */     if (str1 == null)
/*  1208 */       str1 = getSystemProperty("oracle.jdbc.timezoneAsRegion", (String)null); 
/*  1209 */     if (str1 == null) {
/*  1210 */       str1 = "true";
/*       */     }
/*       */     
/*  1213 */     this.timezoneAsRegion = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1216 */     str1 = null;
/*  1217 */     if (paramProperties != null)
/*       */     {
/*  1219 */       str1 = paramProperties.getProperty("oracle.net.ssl_server_dn_match");
/*       */     }
/*  1221 */     if (str1 == null)
/*  1222 */       str1 = getSystemProperty("oracle.net.ssl_server_dn_match", (String)null); 
/*  1223 */     if (str1 == null) {
/*  1224 */       str1 = null;
/*       */     }
/*       */     
/*  1227 */     this.thinSslServerDnMatch = str1;
/*       */ 
/*       */     
/*  1230 */     str1 = null;
/*  1231 */     if (paramProperties != null)
/*       */     {
/*  1233 */       str1 = paramProperties.getProperty("oracle.net.ssl_version");
/*       */     }
/*  1235 */     if (str1 == null)
/*  1236 */       str1 = getSystemProperty("oracle.net.ssl_version", (String)null); 
/*  1237 */     if (str1 == null) {
/*  1238 */       str1 = null;
/*       */     }
/*       */     
/*  1241 */     this.thinSslVersion = str1;
/*       */ 
/*       */     
/*  1244 */     str1 = null;
/*  1245 */     if (paramProperties != null)
/*       */     {
/*  1247 */       str1 = paramProperties.getProperty("oracle.net.ssl_cipher_suites");
/*       */     }
/*  1249 */     if (str1 == null)
/*  1250 */       str1 = getSystemProperty("oracle.net.ssl_cipher_suites", (String)null); 
/*  1251 */     if (str1 == null) {
/*  1252 */       str1 = null;
/*       */     }
/*       */     
/*  1255 */     this.thinSslCipherSuites = str1;
/*       */ 
/*       */     
/*  1258 */     str1 = null;
/*  1259 */     if (paramProperties != null)
/*       */     {
/*  1261 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStore");
/*       */     }
/*  1263 */     if (str1 == null)
/*  1264 */       str1 = getSystemProperty("javax.net.ssl.keyStore", (String)null); 
/*  1265 */     if (str1 == null) {
/*  1266 */       str1 = null;
/*       */     }
/*       */     
/*  1269 */     this.thinJavaxNetSslKeystore = str1;
/*       */ 
/*       */     
/*  1272 */     str1 = null;
/*  1273 */     if (paramProperties != null)
/*       */     {
/*  1275 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStoreType");
/*       */     }
/*  1277 */     if (str1 == null)
/*  1278 */       str1 = getSystemProperty("javax.net.ssl.keyStoreType", (String)null); 
/*  1279 */     if (str1 == null) {
/*  1280 */       str1 = null;
/*       */     }
/*       */     
/*  1283 */     this.thinJavaxNetSslKeystoretype = str1;
/*       */ 
/*       */     
/*  1286 */     str1 = null;
/*  1287 */     if (paramProperties != null)
/*       */     {
/*  1289 */       str1 = paramProperties.getProperty("javax.net.ssl.keyStorePassword");
/*       */     }
/*  1291 */     if (str1 == null)
/*  1292 */       str1 = getSystemProperty("javax.net.ssl.keyStorePassword", (String)null); 
/*  1293 */     if (str1 == null) {
/*  1294 */       str1 = null;
/*       */     }
/*       */     
/*  1297 */     this.thinJavaxNetSslKeystorepassword = str1;
/*       */ 
/*       */     
/*  1300 */     str1 = null;
/*  1301 */     if (paramProperties != null)
/*       */     {
/*  1303 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStore");
/*       */     }
/*  1305 */     if (str1 == null)
/*  1306 */       str1 = getSystemProperty("javax.net.ssl.trustStore", (String)null); 
/*  1307 */     if (str1 == null) {
/*  1308 */       str1 = null;
/*       */     }
/*       */     
/*  1311 */     this.thinJavaxNetSslTruststore = str1;
/*       */ 
/*       */     
/*  1314 */     str1 = null;
/*  1315 */     if (paramProperties != null)
/*       */     {
/*  1317 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStoreType");
/*       */     }
/*  1319 */     if (str1 == null)
/*  1320 */       str1 = getSystemProperty("javax.net.ssl.trustStoreType", (String)null); 
/*  1321 */     if (str1 == null) {
/*  1322 */       str1 = null;
/*       */     }
/*       */     
/*  1325 */     this.thinJavaxNetSslTruststoretype = str1;
/*       */ 
/*       */     
/*  1328 */     str1 = null;
/*  1329 */     if (paramProperties != null)
/*       */     {
/*  1331 */       str1 = paramProperties.getProperty("javax.net.ssl.trustStorePassword");
/*       */     }
/*  1333 */     if (str1 == null)
/*  1334 */       str1 = getSystemProperty("javax.net.ssl.trustStorePassword", (String)null); 
/*  1335 */     if (str1 == null) {
/*  1336 */       str1 = null;
/*       */     }
/*       */     
/*  1339 */     this.thinJavaxNetSslTruststorepassword = str1;
/*       */ 
/*       */     
/*  1342 */     str1 = null;
/*  1343 */     if (paramProperties != null) {
/*       */       
/*  1345 */       str1 = paramProperties.getProperty("ssl.keyManagerFactory.algorithm");
/*  1346 */       if (str1 == null)
/*  1347 */         str1 = paramProperties.getProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm"); 
/*       */     } 
/*  1349 */     if (str1 == null)
/*  1350 */       str1 = getSystemProperty("oracle.jdbc.ssl.keyManagerFactory.algorithm", (String)null); 
/*  1351 */     if (str1 == null) {
/*  1352 */       str1 = null;
/*       */     }
/*       */     
/*  1355 */     this.thinSslKeymanagerfactoryAlgorithm = str1;
/*       */ 
/*       */     
/*  1358 */     str1 = null;
/*  1359 */     if (paramProperties != null) {
/*       */       
/*  1361 */       str1 = paramProperties.getProperty("ssl.trustManagerFactory.algorithm");
/*  1362 */       if (str1 == null)
/*  1363 */         str1 = paramProperties.getProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm"); 
/*       */     } 
/*  1365 */     if (str1 == null)
/*  1366 */       str1 = getSystemProperty("oracle.jdbc.ssl.trustManagerFactory.algorithm", (String)null); 
/*  1367 */     if (str1 == null) {
/*  1368 */       str1 = null;
/*       */     }
/*       */     
/*  1371 */     this.thinSslTrustmanagerfactoryAlgorithm = str1;
/*       */ 
/*       */     
/*  1374 */     str1 = null;
/*  1375 */     if (paramProperties != null)
/*       */     {
/*  1377 */       str1 = paramProperties.getProperty("oracle.net.oldSyntax");
/*       */     }
/*  1379 */     if (str1 == null)
/*  1380 */       str1 = getSystemProperty("oracle.net.oldSyntax", (String)null); 
/*  1381 */     if (str1 == null) {
/*  1382 */       str1 = null;
/*       */     }
/*       */     
/*  1385 */     this.thinNetOldsyntax = str1;
/*       */ 
/*       */     
/*  1388 */     str1 = null;
/*  1389 */     if (paramProperties != null)
/*       */     {
/*  1391 */       str1 = paramProperties.getProperty("java.naming.factory.initial");
/*       */     }
/*  1393 */     if (str1 == null) {
/*  1394 */       str1 = null;
/*       */     }
/*       */     
/*  1397 */     this.thinNamingContextInitial = str1;
/*       */ 
/*       */     
/*  1400 */     str1 = null;
/*  1401 */     if (paramProperties != null)
/*       */     {
/*  1403 */       str1 = paramProperties.getProperty("java.naming.provider.url");
/*       */     }
/*  1405 */     if (str1 == null) {
/*  1406 */       str1 = null;
/*       */     }
/*       */     
/*  1409 */     this.thinNamingProviderUrl = str1;
/*       */ 
/*       */     
/*  1412 */     str1 = null;
/*  1413 */     if (paramProperties != null)
/*       */     {
/*  1415 */       str1 = paramProperties.getProperty("java.naming.security.authentication");
/*       */     }
/*  1417 */     if (str1 == null) {
/*  1418 */       str1 = null;
/*       */     }
/*       */     
/*  1421 */     this.thinNamingSecurityAuthentication = str1;
/*       */ 
/*       */     
/*  1424 */     str1 = null;
/*  1425 */     if (paramProperties != null)
/*       */     {
/*  1427 */       str1 = paramProperties.getProperty("java.naming.security.principal");
/*       */     }
/*  1429 */     if (str1 == null) {
/*  1430 */       str1 = null;
/*       */     }
/*       */     
/*  1433 */     this.thinNamingSecurityPrincipal = str1;
/*       */ 
/*       */     
/*  1436 */     str1 = null;
/*  1437 */     if (paramProperties != null)
/*       */     {
/*  1439 */       str1 = paramProperties.getProperty("java.naming.security.credentials");
/*       */     }
/*  1441 */     if (str1 == null) {
/*  1442 */       str1 = null;
/*       */     }
/*       */     
/*  1445 */     this.thinNamingSecurityCredentials = str1;
/*       */ 
/*       */     
/*  1448 */     str1 = null;
/*  1449 */     if (paramProperties != null)
/*       */     {
/*  1451 */       str1 = paramProperties.getProperty("oracle.net.wallet_location");
/*       */     }
/*  1453 */     if (str1 == null)
/*  1454 */       str1 = getSystemProperty("oracle.net.wallet_location", (String)null); 
/*  1455 */     if (str1 == null) {
/*  1456 */       str1 = null;
/*       */     }
/*       */     
/*  1459 */     this.walletLocation = str1;
/*       */ 
/*       */     
/*  1462 */     str1 = null;
/*  1463 */     if (paramProperties != null)
/*       */     {
/*  1465 */       str1 = paramProperties.getProperty("oracle.net.wallet_password");
/*       */     }
/*  1467 */     if (str1 == null)
/*  1468 */       str1 = getSystemProperty("oracle.net.wallet_password", (String)null); 
/*  1469 */     if (str1 == null) {
/*  1470 */       str1 = null;
/*       */     }
/*       */     
/*  1473 */     this.walletPassword = str1;
/*       */ 
/*       */     
/*  1476 */     str1 = null;
/*  1477 */     if (paramProperties != null)
/*       */     {
/*  1479 */       str1 = paramProperties.getProperty("oracle.jdbc.proxyClientName");
/*       */     }
/*  1481 */     if (str1 == null)
/*  1482 */       str1 = getSystemProperty("oracle.jdbc.proxyClientName", (String)null); 
/*  1483 */     if (str1 == null) {
/*  1484 */       str1 = null;
/*       */     }
/*       */     
/*  1487 */     this.proxyClientName = str1;
/*       */ 
/*       */     
/*  1490 */     str1 = null;
/*  1491 */     if (paramProperties != null)
/*       */     {
/*  1493 */       str1 = paramProperties.getProperty("oracle.jdbc.useNio");
/*       */     }
/*  1495 */     if (str1 == null)
/*  1496 */       str1 = getSystemProperty("oracle.jdbc.useNio", (String)null); 
/*  1497 */     if (str1 == null) {
/*  1498 */       str1 = "false";
/*       */     }
/*       */     
/*  1501 */     this.useNio = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1504 */     str1 = null;
/*  1505 */     if (paramProperties != null) {
/*       */       
/*  1507 */       str1 = paramProperties.getProperty("JDBCDriverCharSetId");
/*  1508 */       if (str1 == null)
/*  1509 */         str1 = paramProperties.getProperty("oracle.jdbc.JDBCDriverCharSetId"); 
/*       */     } 
/*  1511 */     if (str1 == null)
/*  1512 */       str1 = getSystemProperty("oracle.jdbc.JDBCDriverCharSetId", (String)null); 
/*  1513 */     if (str1 == null) {
/*  1514 */       str1 = null;
/*       */     }
/*       */     
/*  1517 */     this.ociDriverCharset = str1;
/*       */ 
/*       */     
/*  1520 */     str1 = null;
/*  1521 */     if (paramProperties != null)
/*       */     {
/*  1523 */       str1 = paramProperties.getProperty("oracle.jdbc.editionName");
/*       */     }
/*  1525 */     if (str1 == null)
/*  1526 */       str1 = getSystemProperty("oracle.jdbc.editionName", (String)null); 
/*  1527 */     if (str1 == null) {
/*  1528 */       str1 = null;
/*       */     }
/*       */     
/*  1531 */     this.editionName = str1;
/*       */ 
/*       */     
/*  1534 */     str1 = null;
/*  1535 */     if (paramProperties != null)
/*       */     {
/*  1537 */       str1 = paramProperties.getProperty("oracle.jdbc.thinLogonCapability");
/*       */     }
/*  1539 */     if (str1 == null)
/*  1540 */       str1 = getSystemProperty("oracle.jdbc.thinLogonCapability", (String)null); 
/*  1541 */     if (str1 == null) {
/*  1542 */       str1 = "o5";
/*       */     }
/*       */     
/*  1545 */     this.logonCap = str1;
/*       */ 
/*       */     
/*  1548 */     str1 = null;
/*  1549 */     if (paramProperties != null) {
/*       */       
/*  1551 */       str1 = paramProperties.getProperty("internal_logon");
/*  1552 */       if (str1 == null)
/*  1553 */         str1 = paramProperties.getProperty("oracle.jdbc.internal_logon"); 
/*       */     } 
/*  1555 */     if (str1 == null)
/*  1556 */       str1 = getSystemProperty("oracle.jdbc.internal_logon", (String)null); 
/*  1557 */     if (str1 == null) {
/*  1558 */       str1 = null;
/*       */     }
/*       */     
/*  1561 */     this.internalLogon = str1;
/*       */ 
/*       */     
/*  1564 */     str1 = null;
/*  1565 */     if (paramProperties != null)
/*       */     {
/*  1567 */       str1 = paramProperties.getProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName");
/*       */     }
/*  1569 */     if (str1 == null)
/*  1570 */       str1 = getSystemProperty("oracle.jdbc.createDescriptorUseCurrentSchemaForSchemaName", (String)null); 
/*  1571 */     if (str1 == null) {
/*  1572 */       str1 = "false";
/*       */     }
/*       */     
/*  1575 */     this.createDescriptorUseCurrentSchemaForSchemaName = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1578 */     str1 = null;
/*  1579 */     if (paramProperties != null) {
/*       */       
/*  1581 */       str1 = paramProperties.getProperty("OCISvcCtxHandle");
/*  1582 */       if (str1 == null)
/*  1583 */         str1 = paramProperties.getProperty("oracle.jdbc.OCISvcCtxHandle"); 
/*       */     } 
/*  1585 */     if (str1 == null)
/*  1586 */       str1 = getSystemProperty("oracle.jdbc.OCISvcCtxHandle", (String)null); 
/*  1587 */     if (str1 == null) {
/*  1588 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1591 */       this.ociSvcCtxHandle = Long.parseLong(str1);
/*  1592 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1596 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociSvcCtxHandle'");
/*  1597 */       sQLException.fillInStackTrace();
/*  1598 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1604 */     str1 = null;
/*  1605 */     if (paramProperties != null) {
/*       */       
/*  1607 */       str1 = paramProperties.getProperty("OCIEnvHandle");
/*  1608 */       if (str1 == null)
/*  1609 */         str1 = paramProperties.getProperty("oracle.jdbc.OCIEnvHandle"); 
/*       */     } 
/*  1611 */     if (str1 == null)
/*  1612 */       str1 = getSystemProperty("oracle.jdbc.OCIEnvHandle", (String)null); 
/*  1613 */     if (str1 == null) {
/*  1614 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1617 */       this.ociEnvHandle = Long.parseLong(str1);
/*  1618 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1622 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociEnvHandle'");
/*  1623 */       sQLException.fillInStackTrace();
/*  1624 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1630 */     str1 = null;
/*  1631 */     if (paramProperties != null) {
/*       */       
/*  1633 */       str1 = paramProperties.getProperty("OCIErrHandle");
/*  1634 */       if (str1 == null)
/*  1635 */         str1 = paramProperties.getProperty("oracle.jdbc.OCIErrHandle"); 
/*       */     } 
/*  1637 */     if (str1 == null)
/*  1638 */       str1 = getSystemProperty("oracle.jdbc.OCIErrHandle", (String)null); 
/*  1639 */     if (str1 == null) {
/*  1640 */       str1 = "0";
/*       */     }
/*       */     try {
/*  1643 */       this.ociErrHandle = Long.parseLong(str1);
/*  1644 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1648 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'ociErrHandle'");
/*  1649 */       sQLException.fillInStackTrace();
/*  1650 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1656 */     str1 = null;
/*  1657 */     if (paramProperties != null) {
/*       */       
/*  1659 */       str1 = paramProperties.getProperty("prelim_auth");
/*  1660 */       if (str1 == null)
/*  1661 */         str1 = paramProperties.getProperty("oracle.jdbc.prelim_auth"); 
/*       */     } 
/*  1663 */     if (str1 == null)
/*  1664 */       str1 = getSystemProperty("oracle.jdbc.prelim_auth", (String)null); 
/*  1665 */     if (str1 == null) {
/*  1666 */       str1 = "false";
/*       */     }
/*       */     
/*  1669 */     this.prelimAuth = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1672 */     str1 = null;
/*  1673 */     if (paramProperties != null)
/*       */     {
/*  1675 */       str1 = paramProperties.getProperty("oracle.jdbc.ociNlsLangBackwardCompatible");
/*       */     }
/*  1677 */     if (str1 == null)
/*  1678 */       str1 = getSystemProperty("oracle.jdbc.ociNlsLangBackwardCompatible", (String)null); 
/*  1679 */     if (str1 == null) {
/*  1680 */       str1 = "false";
/*       */     }
/*       */     
/*  1683 */     this.nlsLangBackdoor = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1686 */     str1 = null;
/*  1687 */     if (paramProperties != null) {
/*       */       
/*  1689 */       str1 = paramProperties.getProperty("OCINewPassword");
/*  1690 */       if (str1 == null)
/*  1691 */         str1 = paramProperties.getProperty("oracle.jdbc.OCINewPassword"); 
/*       */     } 
/*  1693 */     if (str1 == null)
/*  1694 */       str1 = getSystemProperty("oracle.jdbc.OCINewPassword", (String)null); 
/*  1695 */     if (str1 == null) {
/*  1696 */       str1 = null;
/*       */     }
/*       */     
/*  1699 */     this.setNewPassword = str1;
/*       */ 
/*       */     
/*  1702 */     str1 = null;
/*  1703 */     if (paramProperties != null)
/*       */     {
/*  1705 */       str1 = paramProperties.getProperty("oracle.jdbc.spawnNewThreadToCancel");
/*       */     }
/*  1707 */     if (str1 == null)
/*  1708 */       str1 = getSystemProperty("oracle.jdbc.spawnNewThreadToCancel", (String)null); 
/*  1709 */     if (str1 == null) {
/*  1710 */       str1 = "false";
/*       */     }
/*       */     
/*  1713 */     this.spawnNewThreadToCancel = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1716 */     str1 = null;
/*  1717 */     if (paramProperties != null) {
/*       */       
/*  1719 */       str1 = paramProperties.getProperty("defaultExecuteBatch");
/*  1720 */       if (str1 == null)
/*  1721 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultExecuteBatch"); 
/*       */     } 
/*  1723 */     if (str1 == null)
/*  1724 */       str1 = getSystemProperty("oracle.jdbc.defaultExecuteBatch", (String)null); 
/*  1725 */     if (str1 == null) {
/*  1726 */       str1 = "1";
/*       */     }
/*       */     try {
/*  1729 */       this.defaultExecuteBatch = Integer.parseInt(str1);
/*  1730 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1734 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultExecuteBatch'");
/*  1735 */       sQLException.fillInStackTrace();
/*  1736 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1742 */     str1 = null;
/*  1743 */     if (paramProperties != null) {
/*       */       
/*  1745 */       str1 = paramProperties.getProperty("defaultRowPrefetch");
/*  1746 */       if (str1 == null)
/*  1747 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultRowPrefetch"); 
/*       */     } 
/*  1749 */     if (str1 == null)
/*  1750 */       str1 = getSystemProperty("oracle.jdbc.defaultRowPrefetch", (String)null); 
/*  1751 */     if (str1 == null) {
/*  1752 */       str1 = "10";
/*       */     }
/*       */     try {
/*  1755 */       this.defaultRowPrefetch = Integer.parseInt(str1);
/*  1756 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1760 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultRowPrefetch'");
/*  1761 */       sQLException.fillInStackTrace();
/*  1762 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1768 */     str1 = null;
/*  1769 */     if (paramProperties != null)
/*       */     {
/*  1771 */       str1 = paramProperties.getProperty("oracle.jdbc.defaultLobPrefetchSize");
/*       */     }
/*  1773 */     if (str1 == null)
/*  1774 */       str1 = getSystemProperty("oracle.jdbc.defaultLobPrefetchSize", (String)null); 
/*  1775 */     if (str1 == null) {
/*  1776 */       str1 = "4000";
/*       */     }
/*       */     try {
/*  1779 */       this.defaultLobPrefetchSize = Integer.parseInt(str1);
/*  1780 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  1784 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'defaultLobPrefetchSize'");
/*  1785 */       sQLException.fillInStackTrace();
/*  1786 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  1792 */     str1 = null;
/*  1793 */     if (paramProperties != null)
/*       */     {
/*  1795 */       str1 = paramProperties.getProperty("oracle.jdbc.enableDataInLocator");
/*       */     }
/*  1797 */     if (str1 == null)
/*  1798 */       str1 = getSystemProperty("oracle.jdbc.enableDataInLocator", (String)null); 
/*  1799 */     if (str1 == null) {
/*  1800 */       str1 = "true";
/*       */     }
/*       */     
/*  1803 */     this.enableDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1806 */     str1 = null;
/*  1807 */     if (paramProperties != null)
/*       */     {
/*  1809 */       str1 = paramProperties.getProperty("oracle.jdbc.enableReadDataInLocator");
/*       */     }
/*  1811 */     if (str1 == null)
/*  1812 */       str1 = getSystemProperty("oracle.jdbc.enableReadDataInLocator", (String)null); 
/*  1813 */     if (str1 == null) {
/*  1814 */       str1 = "true";
/*       */     }
/*       */     
/*  1817 */     this.enableReadDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1820 */     str1 = null;
/*  1821 */     if (paramProperties != null)
/*       */     {
/*  1823 */       str1 = paramProperties.getProperty("oracle.jdbc.overrideEnableReadDataInLocator");
/*       */     }
/*  1825 */     if (str1 == null)
/*  1826 */       str1 = getSystemProperty("oracle.jdbc.overrideEnableReadDataInLocator", (String)null); 
/*  1827 */     if (str1 == null) {
/*  1828 */       str1 = "false";
/*       */     }
/*       */     
/*  1831 */     this.overrideEnableReadDataInLocator = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1834 */     str1 = null;
/*  1835 */     if (paramProperties != null) {
/*       */       
/*  1837 */       str1 = paramProperties.getProperty("remarksReporting");
/*  1838 */       if (str1 == null)
/*  1839 */         str1 = paramProperties.getProperty("oracle.jdbc.remarksReporting"); 
/*       */     } 
/*  1841 */     if (str1 == null)
/*  1842 */       str1 = getSystemProperty("oracle.jdbc.remarksReporting", (String)null); 
/*  1843 */     if (str1 == null) {
/*  1844 */       str1 = "false";
/*       */     }
/*       */     
/*  1847 */     this.reportRemarks = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1850 */     str1 = null;
/*  1851 */     if (paramProperties != null) {
/*       */       
/*  1853 */       str1 = paramProperties.getProperty("includeSynonyms");
/*  1854 */       if (str1 == null)
/*  1855 */         str1 = paramProperties.getProperty("oracle.jdbc.includeSynonyms"); 
/*       */     } 
/*  1857 */     if (str1 == null)
/*  1858 */       str1 = getSystemProperty("oracle.jdbc.includeSynonyms", (String)null); 
/*  1859 */     if (str1 == null) {
/*  1860 */       str1 = "false";
/*       */     }
/*       */     
/*  1863 */     this.includeSynonyms = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1866 */     str1 = null;
/*  1867 */     if (paramProperties != null) {
/*       */       
/*  1869 */       str1 = paramProperties.getProperty("restrictGetTables");
/*  1870 */       if (str1 == null)
/*  1871 */         str1 = paramProperties.getProperty("oracle.jdbc.restrictGetTables"); 
/*       */     } 
/*  1873 */     if (str1 == null)
/*  1874 */       str1 = getSystemProperty("oracle.jdbc.restrictGetTables", (String)null); 
/*  1875 */     if (str1 == null) {
/*  1876 */       str1 = "false";
/*       */     }
/*       */     
/*  1879 */     this.restrictGettables = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1882 */     str1 = null;
/*  1883 */     if (paramProperties != null) {
/*       */       
/*  1885 */       str1 = paramProperties.getProperty("AccumulateBatchResult");
/*  1886 */       if (str1 == null)
/*  1887 */         str1 = paramProperties.getProperty("oracle.jdbc.AccumulateBatchResult"); 
/*       */     } 
/*  1889 */     if (str1 == null)
/*  1890 */       str1 = getSystemProperty("oracle.jdbc.AccumulateBatchResult", (String)null); 
/*  1891 */     if (str1 == null) {
/*  1892 */       str1 = "true";
/*       */     }
/*       */     
/*  1895 */     this.accumulateBatchResult = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1898 */     str1 = null;
/*  1899 */     if (paramProperties != null) {
/*       */       
/*  1901 */       str1 = paramProperties.getProperty("useFetchSizeWithLongColumn");
/*  1902 */       if (str1 == null)
/*  1903 */         str1 = paramProperties.getProperty("oracle.jdbc.useFetchSizeWithLongColumn"); 
/*       */     } 
/*  1905 */     if (str1 == null)
/*  1906 */       str1 = getSystemProperty("oracle.jdbc.useFetchSizeWithLongColumn", (String)null); 
/*  1907 */     if (str1 == null) {
/*  1908 */       str1 = "false";
/*       */     }
/*       */     
/*  1911 */     this.useFetchSizeWithLongColumn = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1914 */     str1 = null;
/*  1915 */     if (paramProperties != null) {
/*       */       
/*  1917 */       str1 = paramProperties.getProperty("processEscapes");
/*  1918 */       if (str1 == null)
/*  1919 */         str1 = paramProperties.getProperty("oracle.jdbc.processEscapes"); 
/*       */     } 
/*  1921 */     if (str1 == null)
/*  1922 */       str1 = getSystemProperty("oracle.jdbc.processEscapes", (String)null); 
/*  1923 */     if (str1 == null) {
/*  1924 */       str1 = "true";
/*       */     }
/*       */     
/*  1927 */     this.processEscapes = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1930 */     str1 = null;
/*  1931 */     if (paramProperties != null) {
/*       */       
/*  1933 */       str1 = paramProperties.getProperty("fixedString");
/*  1934 */       if (str1 == null)
/*  1935 */         str1 = paramProperties.getProperty("oracle.jdbc.fixedString"); 
/*       */     } 
/*  1937 */     if (str1 == null)
/*  1938 */       str1 = getSystemProperty("oracle.jdbc.fixedString", (String)null); 
/*  1939 */     if (str1 == null) {
/*  1940 */       str1 = "false";
/*       */     }
/*       */     
/*  1943 */     this.fixedString = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1946 */     str1 = null;
/*  1947 */     if (paramProperties != null) {
/*       */       
/*  1949 */       str1 = paramProperties.getProperty("defaultNChar");
/*  1950 */       if (str1 == null)
/*  1951 */         str1 = paramProperties.getProperty("oracle.jdbc.defaultNChar"); 
/*       */     } 
/*  1953 */     if (str1 == null)
/*  1954 */       str1 = getSystemProperty("oracle.jdbc.defaultNChar", (String)null); 
/*  1955 */     if (str1 == null) {
/*  1956 */       str1 = "false";
/*       */     }
/*       */     
/*  1959 */     this.defaultnchar = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1962 */     str1 = null;
/*  1963 */     if (paramProperties != null)
/*       */     {
/*  1965 */       str1 = paramProperties.getProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch");
/*       */     }
/*  1967 */     if (str1 == null)
/*  1968 */       str1 = getSystemProperty("oracle.jdbc.internal.permitBindDateDefineTimestampMismatch", (String)null); 
/*  1969 */     if (str1 == null) {
/*  1970 */       str1 = "false";
/*       */     }
/*       */     
/*  1973 */     this.permitTimestampDateMismatch = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  1976 */     str1 = null;
/*  1977 */     if (paramProperties != null) {
/*       */       
/*  1979 */       str1 = paramProperties.getProperty("RessourceManagerId");
/*  1980 */       if (str1 == null)
/*  1981 */         str1 = paramProperties.getProperty("oracle.jdbc.RessourceManagerId"); 
/*       */     } 
/*  1983 */     if (str1 == null)
/*  1984 */       str1 = getSystemProperty("oracle.jdbc.RessourceManagerId", (String)null); 
/*  1985 */     if (str1 == null) {
/*  1986 */       str1 = "0000";
/*       */     }
/*       */     
/*  1989 */     this.resourceManagerId = str1;
/*       */ 
/*       */     
/*  1992 */     str1 = null;
/*  1993 */     if (paramProperties != null) {
/*       */       
/*  1995 */       str1 = paramProperties.getProperty("disableDefineColumnType");
/*  1996 */       if (str1 == null)
/*  1997 */         str1 = paramProperties.getProperty("oracle.jdbc.disableDefineColumnType"); 
/*       */     } 
/*  1999 */     if (str1 == null)
/*  2000 */       str1 = getSystemProperty("oracle.jdbc.disableDefineColumnType", (String)null); 
/*  2001 */     if (str1 == null) {
/*  2002 */       str1 = "false";
/*       */     }
/*       */     
/*  2005 */     this.disableDefinecolumntype = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2008 */     str1 = null;
/*  2009 */     if (paramProperties != null)
/*       */     {
/*  2011 */       str1 = paramProperties.getProperty("oracle.jdbc.convertNcharLiterals");
/*       */     }
/*  2013 */     if (str1 == null)
/*  2014 */       str1 = getSystemProperty("oracle.jdbc.convertNcharLiterals", (String)null); 
/*  2015 */     if (str1 == null) {
/*  2016 */       str1 = "false";
/*       */     }
/*       */     
/*  2019 */     this.convertNcharLiterals = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2022 */     str1 = null;
/*  2023 */     if (paramProperties != null)
/*       */     {
/*  2025 */       str1 = paramProperties.getProperty("oracle.jdbc.J2EE13Compliant");
/*       */     }
/*  2027 */     if (str1 == null)
/*  2028 */       str1 = getSystemProperty("oracle.jdbc.J2EE13Compliant", (String)null); 
/*  2029 */     if (str1 == null) {
/*  2030 */       str1 = "false";
/*       */     }
/*       */     
/*  2033 */     this.j2ee13Compliant = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2036 */     str1 = null;
/*  2037 */     if (paramProperties != null)
/*       */     {
/*  2039 */       str1 = paramProperties.getProperty("oracle.jdbc.mapDateToTimestamp");
/*       */     }
/*  2041 */     if (str1 == null)
/*  2042 */       str1 = getSystemProperty("oracle.jdbc.mapDateToTimestamp", (String)null); 
/*  2043 */     if (str1 == null) {
/*  2044 */       str1 = "true";
/*       */     }
/*       */     
/*  2047 */     this.mapDateToTimestamp = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2050 */     str1 = null;
/*  2051 */     if (paramProperties != null)
/*       */     {
/*  2053 */       str1 = paramProperties.getProperty("oracle.jdbc.useThreadLocalBufferCache");
/*       */     }
/*  2055 */     if (str1 == null)
/*  2056 */       str1 = getSystemProperty("oracle.jdbc.useThreadLocalBufferCache", (String)null); 
/*  2057 */     if (str1 == null) {
/*  2058 */       str1 = "false";
/*       */     }
/*       */     
/*  2061 */     this.useThreadLocalBufferCache = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2064 */     str1 = null;
/*  2065 */     if (paramProperties != null)
/*       */     {
/*  2067 */       str1 = paramProperties.getProperty("oracle.jdbc.driverNameAttribute");
/*       */     }
/*  2069 */     if (str1 == null)
/*  2070 */       str1 = getSystemProperty("oracle.jdbc.driverNameAttribute", (String)null); 
/*  2071 */     if (str1 == null) {
/*  2072 */       str1 = null;
/*       */     }
/*       */     
/*  2075 */     this.driverNameAttribute = str1;
/*       */ 
/*       */     
/*  2078 */     str1 = null;
/*  2079 */     if (paramProperties != null)
/*       */     {
/*  2081 */       str1 = paramProperties.getProperty("oracle.jdbc.maxCachedBufferSize");
/*       */     }
/*  2083 */     if (str1 == null)
/*  2084 */       str1 = getSystemProperty("oracle.jdbc.maxCachedBufferSize", (String)null); 
/*  2085 */     if (str1 == null) {
/*  2086 */       str1 = "30";
/*       */     }
/*       */     try {
/*  2089 */       this.maxCachedBufferSize = Integer.parseInt(str1);
/*  2090 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  2094 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'maxCachedBufferSize'");
/*  2095 */       sQLException.fillInStackTrace();
/*  2096 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2102 */     str1 = null;
/*  2103 */     if (paramProperties != null)
/*       */     {
/*  2105 */       str1 = paramProperties.getProperty("oracle.jdbc.implicitStatementCacheSize");
/*       */     }
/*  2107 */     if (str1 == null)
/*  2108 */       str1 = getSystemProperty("oracle.jdbc.implicitStatementCacheSize", (String)null); 
/*  2109 */     if (str1 == null) {
/*  2110 */       str1 = "0";
/*       */     }
/*       */     try {
/*  2113 */       this.implicitStatementCacheSize = Integer.parseInt(str1);
/*  2114 */     } catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */       
/*  2118 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 190, "Property is 'implicitStatementCacheSize'");
/*  2119 */       sQLException.fillInStackTrace();
/*  2120 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2126 */     str1 = null;
/*  2127 */     if (paramProperties != null)
/*       */     {
/*  2129 */       str1 = paramProperties.getProperty("oracle.jdbc.LobStreamPosStandardCompliant");
/*       */     }
/*  2131 */     if (str1 == null)
/*  2132 */       str1 = getSystemProperty("oracle.jdbc.LobStreamPosStandardCompliant", (String)null); 
/*  2133 */     if (str1 == null) {
/*  2134 */       str1 = "false";
/*       */     }
/*       */     
/*  2137 */     this.lobStreamPosStandardCompliant = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2140 */     str1 = null;
/*  2141 */     if (paramProperties != null)
/*       */     {
/*  2143 */       str1 = paramProperties.getProperty("oracle.jdbc.strictASCIIConversion");
/*       */     }
/*  2145 */     if (str1 == null)
/*  2146 */       str1 = getSystemProperty("oracle.jdbc.strictASCIIConversion", (String)null); 
/*  2147 */     if (str1 == null) {
/*  2148 */       str1 = "false";
/*       */     }
/*       */     
/*  2151 */     this.isStrictAsciiConversion = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2154 */     str1 = null;
/*  2155 */     if (paramProperties != null)
/*       */     {
/*  2157 */       str1 = paramProperties.getProperty("oracle.jdbc.quickASCIIConversion");
/*       */     }
/*  2159 */     if (str1 == null)
/*  2160 */       str1 = getSystemProperty("oracle.jdbc.quickASCIIConversion", (String)null); 
/*  2161 */     if (str1 == null) {
/*  2162 */       str1 = "false";
/*       */     }
/*       */     
/*  2165 */     this.isQuickAsciiConversion = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2168 */     str1 = null;
/*  2169 */     if (paramProperties != null)
/*       */     {
/*  2171 */       str1 = paramProperties.getProperty("oracle.jdbc.thinForceDNSLoadBalancing");
/*       */     }
/*  2173 */     if (str1 == null)
/*  2174 */       str1 = getSystemProperty("oracle.jdbc.thinForceDNSLoadBalancing", (String)null); 
/*  2175 */     if (str1 == null) {
/*  2176 */       str1 = "false";
/*       */     }
/*       */     
/*  2179 */     this.thinForceDnsLoadBalancing = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2182 */     str1 = null;
/*  2183 */     if (paramProperties != null)
/*       */     {
/*  2185 */       str1 = paramProperties.getProperty("oracle.jdbc.enableJavaNetFastPath");
/*       */     }
/*  2187 */     if (str1 == null)
/*  2188 */       str1 = getSystemProperty("oracle.jdbc.enableJavaNetFastPath", (String)null); 
/*  2189 */     if (str1 == null) {
/*  2190 */       str1 = "false";
/*       */     }
/*       */     
/*  2193 */     this.enableJavaNetFastPath = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2196 */     str1 = null;
/*  2197 */     if (paramProperties != null)
/*       */     {
/*  2199 */       str1 = paramProperties.getProperty("oracle.jdbc.enableTempLobRefCnt");
/*       */     }
/*  2201 */     if (str1 == null)
/*  2202 */       str1 = getSystemProperty("oracle.jdbc.enableTempLobRefCnt", (String)null); 
/*  2203 */     if (str1 == null) {
/*  2204 */       str1 = "true";
/*       */     }
/*       */     
/*  2207 */     this.enableTempLobRefCnt = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2210 */     str1 = null;
/*  2211 */     if (paramProperties != null)
/*       */     {
/*  2213 */       str1 = paramProperties.getProperty("oracle.jdbc.plsqlVarcharParameter4KOnly");
/*       */     }
/*  2215 */     if (str1 == null)
/*  2216 */       str1 = getSystemProperty("oracle.jdbc.plsqlVarcharParameter4KOnly", (String)null); 
/*  2217 */     if (str1 == null) {
/*  2218 */       str1 = "false";
/*       */     }
/*       */     
/*  2221 */     this.plsqlVarcharParameter4KOnly = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */     
/*  2224 */     str1 = null;
/*  2225 */     if (paramProperties != null)
/*       */     {
/*  2227 */       str1 = paramProperties.getProperty("oracle.net.keepAlive");
/*       */     }
/*  2229 */     if (str1 == null)
/*  2230 */       str1 = getSystemProperty("oracle.net.keepAlive", (String)null); 
/*  2231 */     if (str1 == null) {
/*  2232 */       str1 = "false";
/*       */     }
/*       */     
/*  2235 */     this.keepAlive = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */ 
/*       */     
/*  2239 */     str1 = null;
/*  2240 */     if (paramProperties != null)
/*  2241 */       str1 = paramProperties.getProperty("oracle.jdbc.commitOption"); 
/*  2242 */     if (str1 == null)
/*  2243 */       str1 = getSystemProperty("oracle.jdbc.commitOption", (String)null); 
/*  2244 */     if (str1 != null) {
/*       */       
/*  2246 */       this.commitOption = 0;
/*  2247 */       String[] arrayOfString = str1.split(",");
/*  2248 */       if (arrayOfString != null && arrayOfString.length > 0)
/*       */       {
/*  2250 */         for (String str : arrayOfString) {
/*  2251 */           if (str.trim() != "") {
/*  2252 */             this.commitOption |= OracleConnection.CommitOption.valueOf(str.trim()).getCode();
/*       */           }
/*       */         } 
/*       */       }
/*       */     } 
/*  2257 */     str1 = null;
/*  2258 */     if (paramProperties != null)
/*       */     {
/*  2260 */       str1 = paramProperties.getProperty("oracle.jdbc.calculateChecksum");
/*       */     }
/*  2262 */     if (str1 == null)
/*  2263 */       str1 = getSystemProperty("oracle.jdbc.calculateChecksum", (String)null); 
/*  2264 */     if (str1 == null) {
/*  2265 */       str1 = "false";
/*       */     }
/*       */     
/*  2268 */     this.calculateChecksum = (str1 != null && str1.equalsIgnoreCase("true"));
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2273 */     this.includeSynonyms = parseConnectionProperty_boolean(paramProperties, "synonyms", (byte)3, this.includeSynonyms);
/*       */ 
/*       */     
/*  2276 */     this.reportRemarks = parseConnectionProperty_boolean(paramProperties, "remarks", (byte)3, this.reportRemarks);
/*       */ 
/*       */     
/*  2279 */     this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "prefetch", (byte)3, this.defaultRowPrefetch);
/*       */ 
/*       */     
/*  2282 */     this.defaultRowPrefetch = parseConnectionProperty_int(paramProperties, "rowPrefetch", (byte)3, this.defaultRowPrefetch);
/*       */ 
/*       */     
/*  2285 */     this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "batch", (byte)3, this.defaultExecuteBatch);
/*       */ 
/*       */     
/*  2288 */     this.defaultExecuteBatch = parseConnectionProperty_int(paramProperties, "executeBatch", (byte)3, this.defaultExecuteBatch);
/*       */ 
/*       */     
/*  2291 */     this.proxyClientName = parseConnectionProperty_String(paramProperties, "PROXY_CLIENT_NAME", (byte)1, this.proxyClientName);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2297 */     if (this.defaultRowPrefetch <= 0) {
/*  2298 */       this.defaultRowPrefetch = Integer.parseInt("10");
/*       */     }
/*  2300 */     if (this.defaultExecuteBatch <= 0) {
/*  2301 */       this.defaultExecuteBatch = Integer.parseInt("1");
/*       */     }
/*  2303 */     if (this.defaultLobPrefetchSize < -1) {
/*       */       
/*  2305 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 267);
/*  2306 */       sQLException.fillInStackTrace();
/*  2307 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2314 */     if (this.streamChunkSize > 0) {
/*  2315 */       this.streamChunkSize = Math.max(4096, this.streamChunkSize);
/*       */     } else {
/*  2317 */       this.streamChunkSize = Integer.parseInt("16384");
/*       */     } 
/*       */ 
/*       */     
/*  2321 */     if (this.thinVsessionOsuser == null) {
/*       */       
/*  2323 */       this.thinVsessionOsuser = getSystemProperty("user.name", (String)null);
/*  2324 */       if (this.thinVsessionOsuser == null) {
/*  2325 */         this.thinVsessionOsuser = "jdbcuser";
/*       */       }
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2332 */     if (this.thinNetConnectTimeout == CONNECTION_PROPERTY_THIN_NET_CONNECT_TIMEOUT_DEFAULT) {
/*       */       
/*  2334 */       int i = DriverManager.getLoginTimeout();
/*  2335 */       if (i != 0) {
/*  2336 */         this.thinNetConnectTimeout = "" + (i * 1000);
/*       */       }
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2344 */     this.url = paramString;
/*  2345 */     Hashtable hashtable = parseUrl(this.url, this.walletLocation, this.walletPassword);
/*       */     
/*  2347 */     if (this.userName == CONNECTION_PROPERTY_USER_NAME_DEFAULT)
/*  2348 */       this.userName = (String)hashtable.get("user"); 
/*  2349 */     String[] arrayOfString1 = new String[1];
/*  2350 */     String[] arrayOfString2 = new String[1];
/*  2351 */     this.userName = parseLoginOption(this.userName, paramProperties, arrayOfString1, arrayOfString2);
/*  2352 */     if (arrayOfString1[0] != null)
/*  2353 */       this.internalLogon = arrayOfString1[0]; 
/*  2354 */     if (arrayOfString2[0] != null) {
/*  2355 */       this.proxyClientName = arrayOfString2[0];
/*       */     }
/*  2357 */     String str2 = paramProperties.getProperty("password", CONNECTION_PROPERTY_PASSWORD_DEFAULT);
/*       */     
/*  2359 */     if (str2 == CONNECTION_PROPERTY_PASSWORD_DEFAULT)
/*  2360 */       str2 = (String)hashtable.get("password"); 
/*  2361 */     initializePassword(str2);
/*       */     
/*  2363 */     if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
/*  2364 */       this.database = paramProperties.getProperty("server", CONNECTION_PROPERTY_DATABASE_DEFAULT);
/*       */     }
/*  2366 */     if (this.database == CONNECTION_PROPERTY_DATABASE_DEFAULT) {
/*  2367 */       this.database = (String)hashtable.get("database");
/*       */     }
/*  2369 */     this.protocol = (String)hashtable.get("protocol");
/*       */ 
/*       */     
/*  2372 */     if (this.protocol == null) {
/*       */ 
/*       */       
/*  2375 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 40, "Protocol is not specified in URL");
/*  2376 */       sQLException.fillInStackTrace();
/*  2377 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  2382 */     if (this.protocol.equals("oci8") || this.protocol.equals("oci")) {
/*  2383 */       this.database = translateConnStr(this.database);
/*       */     }
/*       */     
/*  2386 */     if (paramProperties.getProperty("is_connection_pooling") == "true")
/*       */     {
/*       */       
/*  2389 */       if (this.database == null) {
/*  2390 */         this.database = "";
/*       */       }
/*       */     }
/*  2393 */     if (this.userName != null && !this.userName.startsWith("\"")) {
/*       */ 
/*       */       
/*  2396 */       char[] arrayOfChar = this.userName.toCharArray();
/*  2397 */       for (byte b = 0; b < arrayOfChar.length; b++)
/*  2398 */         arrayOfChar[b] = Character.toUpperCase(arrayOfChar[b]); 
/*  2399 */       this.userName = String.copyValueOf(arrayOfChar);
/*       */     } 
/*       */ 
/*       */     
/*  2403 */     this.xaWantsError = false;
/*  2404 */     this.usingXA = false;
/*       */     
/*  2406 */     readOCIConnectionPoolProperties(paramProperties);
/*  2407 */     validateConnectionProperties();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private void readOCIConnectionPoolProperties(Properties paramProperties) throws SQLException {
/*  2416 */     this.ociConnectionPoolMinLimit = parseConnectionProperty_int(paramProperties, "connpool_min_limit", (byte)1, 0);
/*       */ 
/*       */     
/*  2419 */     this.ociConnectionPoolMaxLimit = parseConnectionProperty_int(paramProperties, "connpool_max_limit", (byte)1, 0);
/*       */ 
/*       */     
/*  2422 */     this.ociConnectionPoolIncrement = parseConnectionProperty_int(paramProperties, "connpool_increment", (byte)1, 0);
/*       */ 
/*       */     
/*  2425 */     this.ociConnectionPoolTimeout = parseConnectionProperty_int(paramProperties, "connpool_timeout", (byte)1, 0);
/*       */ 
/*       */     
/*  2428 */     this.ociConnectionPoolNoWait = parseConnectionProperty_boolean(paramProperties, "connpool_nowait", (byte)1, false);
/*       */ 
/*       */     
/*  2431 */     this.ociConnectionPoolTransactionDistributed = parseConnectionProperty_boolean(paramProperties, "transactions_distributed", (byte)1, false);
/*       */ 
/*       */     
/*  2434 */     this.ociConnectionPoolLogonMode = parseConnectionProperty_String(paramProperties, "connection_pool", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2437 */     this.ociConnectionPoolIsPooling = parseConnectionProperty_boolean(paramProperties, "is_connection_pooling", (byte)1, false);
/*       */ 
/*       */     
/*  2440 */     this.ociConnectionPoolObject = parseConnectionProperty_Object(paramProperties, "connpool_object", (Object)null);
/*       */     
/*  2442 */     this.ociConnectionPoolConnID = parseConnectionProperty_Object(paramProperties, "connection_id", (Object)null);
/*       */     
/*  2444 */     this.ociConnectionPoolProxyType = parseConnectionProperty_String(paramProperties, "proxytype", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2447 */     this.ociConnectionPoolProxyNumRoles = (Integer)parseConnectionProperty_Object(paramProperties, "proxy_num_roles", Integer.valueOf(0));
/*       */     
/*  2449 */     this.ociConnectionPoolProxyRoles = parseConnectionProperty_Object(paramProperties, "proxy_roles", (Object)null);
/*       */     
/*  2451 */     this.ociConnectionPoolProxyUserName = parseConnectionProperty_String(paramProperties, "proxy_user_name", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2454 */     this.ociConnectionPoolProxyPassword = parseConnectionProperty_String(paramProperties, "proxy_password", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2457 */     this.ociConnectionPoolProxyDistinguishedName = parseConnectionProperty_String(paramProperties, "proxy_distinguished_name", (byte)1, (String)null);
/*       */ 
/*       */     
/*  2460 */     this.ociConnectionPoolProxyCertificate = parseConnectionProperty_Object(paramProperties, "proxy_certificate", (Object)null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  2467 */   private static final Pattern driverNameAttributePattern = Pattern.compile("[\\x20-\\x7e]{0,8}");
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void validateConnectionProperties() throws SQLException {
/*  2477 */     if (this.driverNameAttribute != null && !driverNameAttributePattern.matcher(this.driverNameAttribute).matches()) {
/*       */ 
/*       */       
/*  2480 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 257);
/*  2481 */       sQLException.fillInStackTrace();
/*  2482 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final Object parseConnectionProperty_Object(Properties paramProperties, String paramString, Object paramObject) throws SQLException {
/*  2499 */     Object object = paramObject;
/*  2500 */     if (paramProperties != null) {
/*       */       
/*  2502 */       Object object1 = paramProperties.get(paramString);
/*  2503 */       if (object1 != null)
/*  2504 */         object = object1; 
/*       */     } 
/*  2506 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final String parseConnectionProperty_String(Properties paramProperties, String paramString1, byte paramByte, String paramString2) throws SQLException {
/*  2535 */     String str = null;
/*  2536 */     if ((paramByte == 1 || paramByte == 3) && paramProperties != null) {
/*       */ 
/*       */       
/*  2539 */       str = paramProperties.getProperty(paramString1);
/*  2540 */       if (str == null && !paramString1.startsWith("oracle.") && !paramString1.startsWith("java.") && !paramString1.startsWith("javax."))
/*  2541 */         str = paramProperties.getProperty("oracle.jdbc." + paramString1); 
/*       */     } 
/*  2543 */     if (str == null && (paramByte == 2 || paramByte == 3))
/*       */     {
/*       */       
/*  2546 */       if (paramString1.startsWith("oracle.") || paramString1.startsWith("java.") || paramString1.startsWith("javax.")) {
/*  2547 */         str = getSystemProperty(paramString1, (String)null);
/*       */       } else {
/*  2549 */         str = getSystemProperty("oracle.jdbc." + paramString1, (String)null);
/*       */       }  } 
/*  2551 */     if (str == null)
/*  2552 */       str = paramString2; 
/*  2553 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final int parseConnectionProperty_int(Properties paramProperties, String paramString, byte paramByte, int paramInt) throws SQLException {
/*  2564 */     int i = paramInt;
/*  2565 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2570 */     if (str != null) {
/*       */       
/*       */       try {
/*       */         
/*  2574 */         i = Integer.parseInt(str);
/*       */       }
/*  2576 */       catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */         
/*  2580 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
/*  2581 */         sQLException.fillInStackTrace();
/*  2582 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  2587 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final long parseConnectionProperty_long(Properties paramProperties, String paramString, byte paramByte, long paramLong) throws SQLException {
/*  2598 */     long l = paramLong;
/*  2599 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2604 */     if (str != null) {
/*       */       
/*       */       try {
/*       */         
/*  2608 */         l = Long.parseLong(str);
/*       */       }
/*  2610 */       catch (NumberFormatException numberFormatException) {
/*       */ 
/*       */ 
/*       */         
/*  2614 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is '" + paramString + "' and value is '" + str + "'");
/*  2615 */         sQLException.fillInStackTrace();
/*  2616 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  2621 */     return l;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final boolean parseConnectionProperty_boolean(Properties paramProperties, String paramString, byte paramByte, boolean paramBoolean) throws SQLException {
/*  2632 */     boolean bool = paramBoolean;
/*  2633 */     String str = parseConnectionProperty_String(paramProperties, paramString, paramByte, (String)null);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2638 */     if (str != null)
/*       */     {
/*  2640 */       if (str.equalsIgnoreCase("false")) {
/*  2641 */         bool = false;
/*  2642 */       } else if (str.equalsIgnoreCase("true")) {
/*  2643 */         bool = true;
/*       */       }  } 
/*  2645 */     return bool;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static String parseLoginOption(String paramString, Properties paramProperties, String[] paramArrayOfString1, String[] paramArrayOfString2) {
/*  2665 */     int j = 0;
/*  2666 */     String str1 = null;
/*  2667 */     String str2 = null;
/*       */ 
/*       */     
/*  2670 */     if (paramString == null) {
/*  2671 */       return null;
/*       */     }
/*  2673 */     int k = paramString.length();
/*       */     
/*  2675 */     if (k == 0) {
/*  2676 */       return null;
/*       */     }
/*       */     
/*  2679 */     int i = paramString.indexOf('[');
/*  2680 */     if (i > 0) {
/*  2681 */       j = paramString.indexOf(']');
/*  2682 */       str2 = paramString.substring(i + 1, j);
/*  2683 */       str2 = str2.trim();
/*       */       
/*  2685 */       if (str2.length() > 0) {
/*  2686 */         paramArrayOfString2[0] = str2;
/*       */       }
/*       */       
/*  2689 */       paramString = paramString.substring(0, i) + paramString.substring(j + 1, k);
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  2694 */     String str3 = paramString.toLowerCase();
/*       */ 
/*       */     
/*  2697 */     i = str3.lastIndexOf(" as ");
/*       */     
/*  2699 */     if (i == -1 || i < str3.lastIndexOf("\"")) {
/*  2700 */       return paramString;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  2705 */     str1 = paramString.substring(0, i);
/*       */     
/*  2707 */     i += 4;
/*       */ 
/*       */     
/*  2710 */     while (i < k && str3.charAt(i) == ' ') {
/*  2711 */       i++;
/*       */     }
/*  2713 */     if (i == k) {
/*  2714 */       return paramString;
/*       */     }
/*  2716 */     String str4 = str3.substring(i).trim();
/*       */     
/*  2718 */     if (str4.length() > 0) {
/*  2719 */       paramArrayOfString1[0] = str4;
/*       */     }
/*  2721 */     return str1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final Hashtable parseUrl(String paramString1, String paramString2, String paramString3) throws SQLException {
/*  2742 */     Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>(5);
/*  2743 */     int i = paramString1.indexOf(':', paramString1.indexOf(':') + 1) + 1;
/*  2744 */     int j = paramString1.length();
/*       */ 
/*       */     
/*  2747 */     if (i == j) {
/*  2748 */       return hashtable;
/*       */     }
/*  2750 */     int k = paramString1.indexOf(':', i);
/*       */ 
/*       */     
/*  2753 */     if (k == -1)
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2759 */       return hashtable;
/*       */     }
/*       */ 
/*       */     
/*  2763 */     hashtable.put("protocol", paramString1.substring(i, k));
/*       */     
/*  2765 */     int m = k + 1;
/*  2766 */     int n = paramString1.indexOf('/', m);
/*       */     
/*  2768 */     int i1 = paramString1.indexOf('@', m);
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2773 */     if (i1 > m && m > i && n == -1) {
/*       */ 
/*       */       
/*  2776 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 67);
/*  2777 */       sQLException.fillInStackTrace();
/*  2778 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  2782 */     if (i1 == -1) {
/*  2783 */       i1 = j;
/*       */     }
/*  2785 */     if (n == -1) {
/*  2786 */       n = i1;
/*       */     }
/*  2788 */     if (n < i1 && n != m && i1 != m) {
/*       */       
/*  2790 */       hashtable.put("user", paramString1.substring(m, n));
/*  2791 */       hashtable.put("password", paramString1.substring(n + 1, i1));
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  2797 */     if (n <= i1 && (n == m || i1 == m))
/*       */     {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  2804 */       if (i1 < j) {
/*       */         
/*  2806 */         String str = paramString1.substring(i1 + 1);
/*  2807 */         String[] arrayOfString = getSecretStoreCredentials(str, paramString2, paramString3);
/*  2808 */         if (arrayOfString[0] != null || arrayOfString[1] != null) {
/*       */           
/*  2810 */           hashtable.put("user", arrayOfString[0]);
/*  2811 */           hashtable.put("password", arrayOfString[1]);
/*       */         } 
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  2817 */     if (i1 < j) {
/*  2818 */       hashtable.put("database", paramString1.substring(i1 + 1));
/*       */     }
/*  2820 */     return hashtable;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final synchronized String[] getSecretStoreCredentials(String paramString1, String paramString2, String paramString3) throws SQLException {
/*  2982 */     String[] arrayOfString = new String[2];
/*  2983 */     arrayOfString[0] = null;
/*  2984 */     arrayOfString[1] = null;
/*       */     
/*  2986 */     if (paramString2 != null) {
/*       */       
/*       */       try {
/*       */         
/*  2990 */         if (paramString2.startsWith("(")) {
/*  2991 */           paramString2 = "file:" + CustomSSLSocketFactory.processWalletLocation(paramString2);
/*       */         }
/*  2993 */         OracleWallet oracleWallet = new OracleWallet();
/*  2994 */         if (oracleWallet.exists(paramString2)) {
/*       */ 
/*       */ 
/*       */           
/*  2998 */           char[] arrayOfChar = null;
/*  2999 */           if (paramString3 != null) {
/*  3000 */             arrayOfChar = paramString3.toCharArray();
/*       */           }
/*       */ 
/*       */           
/*  3004 */           oracleWallet.open(paramString2, arrayOfChar);
/*  3005 */           OracleSecretStore oracleSecretStore = oracleWallet.getSecretStore();
/*       */ 
/*       */ 
/*       */           
/*  3009 */           if (oracleSecretStore.containsAlias("oracle.security.client.default_username")) {
/*  3010 */             arrayOfString[0] = new String(oracleSecretStore.getSecret("oracle.security.client.default_username"));
/*       */           }
/*  3012 */           if (oracleSecretStore.containsAlias("oracle.security.client.default_password")) {
/*  3013 */             arrayOfString[1] = new String(oracleSecretStore.getSecret("oracle.security.client.default_password"));
/*       */           }
/*       */           
/*  3016 */           Enumeration<String> enumeration = oracleWallet.getSecretStore().internalAliases();
/*       */           
/*  3018 */           String str = null;
/*  3019 */           while (enumeration.hasMoreElements()) {
/*       */             
/*  3021 */             str = enumeration.nextElement();
/*  3022 */             if (str.startsWith("oracle.security.client.connect_string"))
/*       */             {
/*  3024 */               if (paramString1.equalsIgnoreCase(new String(oracleSecretStore.getSecret(str)))) {
/*       */ 
/*       */                 
/*  3027 */                 String str1 = str.substring("oracle.security.client.connect_string".length());
/*  3028 */                 arrayOfString[0] = new String(oracleSecretStore.getSecret("oracle.security.client.username" + str1));
/*       */                 
/*  3030 */                 arrayOfString[1] = new String(oracleSecretStore.getSecret("oracle.security.client.password" + str1));
/*       */ 
/*       */                 
/*       */                 break;
/*       */               } 
/*       */             }
/*       */           } 
/*       */         } 
/*  3038 */       } catch (NoClassDefFoundError noClassDefFoundError) {
/*       */ 
/*       */         
/*  3041 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 167, noClassDefFoundError);
/*  3042 */         sQLException.fillInStackTrace();
/*  3043 */         throw sQLException;
/*       */       
/*       */       }
/*  3046 */       catch (Exception exception) {
/*       */         
/*  3048 */         if (exception instanceof RuntimeException) throw (RuntimeException)exception;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3058 */         SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 168, exception);
/*  3059 */         sQLException.fillInStackTrace();
/*  3060 */         throw sQLException;
/*       */       } 
/*       */     }
/*       */ 
/*       */     
/*  3065 */     return arrayOfString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private String translateConnStr(String paramString) throws SQLException {
/*  3084 */     int i = 0;
/*  3085 */     int j = 0;
/*       */     
/*  3087 */     if (paramString == null || paramString.equals("")) {
/*  3088 */       return paramString;
/*       */     }
/*       */     
/*  3091 */     if (paramString.indexOf(')') != -1) {
/*  3092 */       return paramString;
/*       */     }
/*  3094 */     boolean bool = false;
/*  3095 */     if (paramString.indexOf('[') != -1) {
/*       */ 
/*       */       
/*  3098 */       i = paramString.indexOf(']');
/*  3099 */       if (i == -1) {
/*       */         
/*  3101 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
/*  3102 */         sQLException.fillInStackTrace();
/*  3103 */         throw sQLException;
/*       */       } 
/*  3105 */       bool = true;
/*       */     } 
/*       */     
/*  3108 */     i = paramString.indexOf(':', i);
/*  3109 */     if (i == -1)
/*  3110 */       return paramString; 
/*  3111 */     j = paramString.indexOf(':', i + 1);
/*  3112 */     if (j == -1) {
/*  3113 */       return paramString;
/*       */     }
/*       */     
/*  3116 */     if (paramString.indexOf(':', j + 1) != -1) {
/*       */ 
/*       */       
/*  3119 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 67, paramString);
/*  3120 */       sQLException.fillInStackTrace();
/*  3121 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3125 */     String str1 = null;
/*  3126 */     if (bool) {
/*  3127 */       str1 = paramString.substring(1, i - 1);
/*       */     } else {
/*  3129 */       str1 = paramString.substring(0, i);
/*       */     } 
/*  3131 */     String str2 = paramString.substring(i + 1, j);
/*  3132 */     String str3 = paramString.substring(j + 1, paramString.length());
/*       */     
/*  3134 */     return "(DESCRIPTION=(ADDRESS=(PROTOCOL=tcp)(HOST=" + str1 + ")(PORT=" + str2 + "))(CONNECT_DATA=(SID=" + str3 + ")))";
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected static String getSystemPropertyPollInterval() {
/*  3147 */     return getSystemProperty("oracle.jdbc.TimeoutPollInterval", "1000");
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static String getSystemPropertyFastConnectionFailover(String paramString) {
/*  3156 */     return getSystemProperty("oracle.jdbc.FastConnectionFailover", paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   static String getSystemPropertyJserverVersion() {
/*  3164 */     return getSystemProperty("oracle.jserver.version", (String)null);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static String getSystemProperty(String paramString1, String paramString2) {
/*  3171 */     if (paramString1 != null) {
/*       */       
/*  3173 */       final String fstr = paramString1;
/*  3174 */       final String fdefaultValue = paramString2;
/*  3175 */       final String[] rets = { paramString2 };
/*  3176 */       AccessController.doPrivileged(new PrivilegedAction()
/*       */           {
/*       */             public Object run()
/*       */             {
/*  3180 */               rets[0] = System.getProperty(fstr, fdefaultValue);
/*  3181 */               return null;
/*       */             }
/*       */           });
/*  3184 */       return arrayOfString[0];
/*       */     } 
/*       */     
/*  3187 */     return paramString2;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Properties getProperties() {
/*  3198 */     Properties properties = new Properties();
/*       */     
/*       */     try {
/*  3201 */       Class clazz1 = null;
/*  3202 */       Class clazz2 = null;
/*       */       
/*       */       try {
/*  3205 */         clazz1 = ClassRef.newInstance("oracle.jdbc.OracleConnection").get();
/*  3206 */         clazz2 = ClassRef.newInstance("oracle.jdbc.driver.PhysicalConnection").get();
/*       */       }
/*  3208 */       catch (ClassNotFoundException classNotFoundException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3215 */       Field[] arrayOfField = clazz2.getDeclaredFields();
/*  3216 */       for (byte b = 0; b < arrayOfField.length; b++) {
/*       */         
/*  3218 */         int i = arrayOfField[b].getModifiers();
/*  3219 */         if (!Modifier.isStatic(i)) {
/*       */ 
/*       */           
/*  3222 */           String str1 = arrayOfField[b].getName();
/*       */ 
/*       */           
/*  3225 */           String str2 = "CONNECTION_PROPERTY_" + propertyVariableName(str1);
/*       */ 
/*       */ 
/*       */           
/*  3229 */           Field field = null;
/*       */ 
/*       */           
/*       */           try {
/*  3233 */             field = clazz1.getField(str2);
/*       */           }
/*  3235 */           catch (NoSuchFieldException noSuchFieldException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */           
/*  3241 */           if (!str2.matches(".*PASSWORD.*")) {
/*       */ 
/*       */             
/*  3244 */             String str3 = (String)field.get(null);
/*  3245 */             String str4 = arrayOfField[b].getType().getName();
/*  3246 */             if (str4.equals("boolean"))
/*       */             
/*  3248 */             { boolean bool = arrayOfField[b].getBoolean(this);
/*  3249 */               if (bool) {
/*  3250 */                 properties.setProperty(str3, "true");
/*       */               } else {
/*  3252 */                 properties.setProperty(str3, "false");
/*       */               }  }
/*  3254 */             else if (str4.equals("int"))
/*       */             
/*  3256 */             { int j = arrayOfField[b].getInt(this);
/*  3257 */               properties.setProperty(str3, Integer.toString(j)); }
/*       */             
/*  3259 */             else if (str4.equals("long"))
/*       */             
/*  3261 */             { long l = arrayOfField[b].getLong(this);
/*  3262 */               properties.setProperty(str3, Long.toString(l)); }
/*       */             
/*  3264 */             else if (str4.equals("java.lang.String"))
/*       */             
/*  3266 */             { String str = (String)arrayOfField[b].get(this);
/*  3267 */               if (str != null)
/*  3268 */                 properties.setProperty(str3, str);  } 
/*       */           } 
/*       */         } 
/*       */       } 
/*  3272 */     } catch (IllegalAccessException illegalAccessException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3277 */     return properties;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Connection _getPC() {
/*  3298 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleConnection getPhysicalConnection() {
/*  3314 */     return this;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isLogicalConnection() {
/*  3327 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void initialize(Hashtable paramHashtable, Map paramMap1, Map paramMap2) throws SQLException {
/*  3340 */     this.clearStatementMetaData = false;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3346 */     if (paramHashtable != null) {
/*  3347 */       this.descriptorCacheStack[this.dci] = paramHashtable;
/*       */     } else {
/*  3349 */       this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
/*       */     } 
/*  3351 */     this.map = paramMap1;
/*       */     
/*  3353 */     if (paramMap2 != null) {
/*  3354 */       this.javaObjectMap = paramMap2;
/*       */     } else {
/*  3356 */       this.javaObjectMap = new Hashtable<Object, Object>(10);
/*       */     } 
/*  3358 */     this.lifecycle = 1;
/*  3359 */     this.txnLevel = 2;
/*       */ 
/*       */     
/*  3362 */     this.clientIdSet = false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void initializeSetCHARCharSetObjs() {
/*  3370 */     this.setCHARNCharSetObj = this.conversion.getDriverNCharSetObj();
/*  3371 */     this.setCHARCharSetObj = this.conversion.getDriverCharSetObj();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   OracleTimeout getTimeout() throws SQLException {
/*  3385 */     if (this.timeout == null)
/*       */     {
/*  3387 */       this.timeout = OracleTimeout.newTimeout(this.url);
/*       */     }
/*       */     
/*  3390 */     return this.timeout;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Statement createStatement() throws SQLException {
/*  3409 */     return createStatement(-1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Statement createStatement(int paramInt1, int paramInt2) throws SQLException {
/*  3431 */     if (this.lifecycle != 1) {
/*       */       
/*  3433 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3434 */       sQLException.fillInStackTrace();
/*  3435 */       throw sQLException;
/*       */     } 
/*       */     
/*  3438 */     OracleStatement oracleStatement = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3444 */     oracleStatement = this.driverExtension.allocateStatement(this, paramInt1, paramInt2);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3451 */     return (Statement)new OracleStatementWrapper((OracleStatement)oracleStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatement(String paramString) throws SQLException {
/*  3472 */     return prepareStatement(paramString, -1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatementWithKey(String paramString) throws SQLException {
/*       */     OraclePreparedStatementWrapper oraclePreparedStatementWrapper;
/*  3493 */     if (this.lifecycle != 1) {
/*       */       
/*  3495 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3496 */       sQLException.fillInStackTrace();
/*  3497 */       throw sQLException;
/*       */     } 
/*       */     
/*  3500 */     if (paramString == null) {
/*  3501 */       return null;
/*       */     }
/*  3503 */     if (!isStatementCacheInitialized()) {
/*       */       
/*  3505 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  3506 */       sQLException.fillInStackTrace();
/*  3507 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3514 */     OraclePreparedStatement oraclePreparedStatement = null;
/*       */     
/*  3516 */     oraclePreparedStatement = (OraclePreparedStatement)this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3527 */     if (oraclePreparedStatement != null) {
/*  3528 */       oraclePreparedStatementWrapper = new OraclePreparedStatementWrapper((OraclePreparedStatement)oraclePreparedStatement);
/*       */     }
/*  3530 */     return (PreparedStatement)oraclePreparedStatementWrapper;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  3561 */     if (paramString == null || paramString.length() == 0) {
/*       */       
/*  3563 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  3564 */       sQLException.fillInStackTrace();
/*  3565 */       throw sQLException;
/*       */     } 
/*       */     
/*  3568 */     if (this.lifecycle != 1) {
/*       */       
/*  3570 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3571 */       sQLException.fillInStackTrace();
/*  3572 */       throw sQLException;
/*       */     } 
/*       */     
/*  3575 */     OraclePreparedStatement oraclePreparedStatement = null;
/*       */ 
/*       */     
/*  3578 */     if (this.statementCache != null) {
/*  3579 */       oraclePreparedStatement = (OraclePreparedStatement)this.statementCache.searchImplicitCache(paramString, 1, (paramInt1 != -1 || paramInt2 != -1) ? ResultSetUtil.getRsetTypeCode(paramInt1, paramInt2) : 1);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3585 */     if (oraclePreparedStatement == null) {
/*  3586 */       oraclePreparedStatement = this.driverExtension.allocatePreparedStatement(this, paramString, paramInt1, paramInt2);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3598 */     return (PreparedStatement)new OraclePreparedStatementWrapper((OraclePreparedStatement)oraclePreparedStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCall(String paramString) throws SQLException {
/*  3617 */     return prepareCall(paramString, -1, -1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  3646 */     if (paramString == null || paramString.length() == 0) {
/*       */       
/*  3648 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 104);
/*  3649 */       sQLException.fillInStackTrace();
/*  3650 */       throw sQLException;
/*       */     } 
/*       */     
/*  3653 */     if (this.lifecycle != 1) {
/*       */       
/*  3655 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3656 */       sQLException.fillInStackTrace();
/*  3657 */       throw sQLException;
/*       */     } 
/*       */     
/*  3660 */     OracleCallableStatement oracleCallableStatement = null;
/*       */     
/*  3662 */     if (this.statementCache != null) {
/*  3663 */       oracleCallableStatement = (OracleCallableStatement)this.statementCache.searchImplicitCache(paramString, 2, (paramInt1 != -1 || paramInt2 != -1) ? ResultSetUtil.getRsetTypeCode(paramInt1, paramInt2) : 1);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3669 */     if (oracleCallableStatement == null) {
/*  3670 */       oracleCallableStatement = this.driverExtension.allocateCallableStatement(this, paramString, paramInt1, paramInt2);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3681 */     return (CallableStatement)new OracleCallableStatementWrapper((OracleCallableStatement)oracleCallableStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement prepareCallWithKey(String paramString) throws SQLException {
/*       */     OracleCallableStatementWrapper oracleCallableStatementWrapper;
/*  3701 */     if (this.lifecycle != 1) {
/*       */       
/*  3703 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3704 */       sQLException.fillInStackTrace();
/*  3705 */       throw sQLException;
/*       */     } 
/*       */     
/*  3708 */     if (paramString == null) {
/*  3709 */       return null;
/*       */     }
/*  3711 */     if (!isStatementCacheInitialized()) {
/*       */       
/*  3713 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  3714 */       sQLException.fillInStackTrace();
/*  3715 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3722 */     OracleCallableStatement oracleCallableStatement = null;
/*       */     
/*  3724 */     oracleCallableStatement = (OracleCallableStatement)this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3734 */     if (oracleCallableStatement != null) {
/*  3735 */       oracleCallableStatementWrapper = new OracleCallableStatementWrapper((OracleCallableStatement)oracleCallableStatement);
/*       */     }
/*  3737 */     return (CallableStatement)oracleCallableStatementWrapper;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String nativeSQL(String paramString) throws SQLException {
/*  3749 */     if (this.sqlObj == null)
/*       */     {
/*  3751 */       this.sqlObj = new OracleSql(this.conversion);
/*       */     }
/*       */     
/*  3754 */     this.sqlObj.initialize(paramString);
/*       */     
/*  3756 */     return this.sqlObj.getSql(this.processEscapes, this.convertNcharLiterals);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAutoCommit(boolean paramBoolean) throws SQLException {
/*  3768 */     if (paramBoolean) {
/*  3769 */       disallowGlobalTxnMode(116);
/*       */     }
/*  3771 */     if (this.lifecycle != 1) {
/*       */       
/*  3773 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3774 */       sQLException.fillInStackTrace();
/*  3775 */       throw sQLException;
/*       */     } 
/*       */     
/*  3778 */     needLine();
/*  3779 */     doSetAutoCommit(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getAutoCommit() throws SQLException {
/*  3787 */     return this.autocommit;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void cancel() throws SQLException {
/*  3806 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  3808 */     if (this.lifecycle != 1 && this.lifecycle != 16) {
/*       */       
/*  3810 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3811 */       sQLException.fillInStackTrace();
/*  3812 */       throw sQLException;
/*       */     } 
/*       */     
/*  3815 */     boolean bool = false;
/*       */     
/*  3817 */     while (oracleStatement != null) {
/*       */ 
/*       */       
/*       */       try {
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3825 */         if (oracleStatement.doCancel()) {
/*  3826 */           bool = true;
/*       */         }
/*  3828 */       } catch (SQLException sQLException) {}
/*       */ 
/*       */ 
/*       */       
/*  3832 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*       */ 
/*       */     
/*  3836 */     if (!bool) {
/*  3837 */       cancelOperationOnServer(false);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public void commit(EnumSet<OracleConnection.CommitOption> paramEnumSet) throws SQLException {
/*  3844 */     int i = 0;
/*  3845 */     if (paramEnumSet != null) {
/*       */       
/*  3847 */       if ((paramEnumSet.contains(OracleConnection.CommitOption.WRITEBATCH) && paramEnumSet.contains(OracleConnection.CommitOption.WRITEIMMED)) || (paramEnumSet.contains(OracleConnection.CommitOption.WAIT) && paramEnumSet.contains(OracleConnection.CommitOption.NOWAIT))) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  3853 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
/*  3854 */         sQLException.fillInStackTrace();
/*  3855 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */       
/*  3859 */       for (OracleConnection.CommitOption commitOption : paramEnumSet)
/*  3860 */         i |= commitOption.getCode(); 
/*       */     } 
/*  3862 */     commit(i);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void commit(int paramInt) throws SQLException {
/*  3873 */     disallowGlobalTxnMode(114);
/*       */     
/*  3875 */     if (this.lifecycle != 1) {
/*       */       
/*  3877 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3878 */       sQLException.fillInStackTrace();
/*  3879 */       throw sQLException;
/*       */     } 
/*       */     
/*  3882 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  3884 */     while (oracleStatement != null) {
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3889 */       if (!oracleStatement.closed) {
/*  3890 */         oracleStatement.sendBatch();
/*       */       }
/*  3892 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*  3894 */     if (((paramInt & OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0 && (paramInt & OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0) || ((paramInt & OracleConnection.CommitOption.WAIT.getCode()) != 0 && (paramInt & OracleConnection.CommitOption.NOWAIT.getCode()) != 0)) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  3900 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 191);
/*  3901 */       sQLException.fillInStackTrace();
/*  3902 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3909 */     registerHeartbeat();
/*       */     
/*  3911 */     needLine();
/*  3912 */     doCommit(paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public void commit() throws SQLException {
/*  3918 */     commit(this.commitOption);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void rollback() throws SQLException {
/*  3927 */     disallowGlobalTxnMode(115);
/*       */     
/*  3929 */     if (this.lifecycle != 1) {
/*       */       
/*  3931 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  3932 */       sQLException.fillInStackTrace();
/*  3933 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  3937 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  3939 */     while (oracleStatement != null) {
/*       */       
/*  3941 */       if (oracleStatement.isOracleBatchStyle()) {
/*  3942 */         oracleStatement.clearBatch();
/*       */       }
/*  3944 */       oracleStatement = oracleStatement.next;
/*       */     } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  3951 */     registerHeartbeat();
/*       */     
/*  3953 */     needLine();
/*  3954 */     doRollback();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close() throws SQLException {
/*  3968 */     if (this.lifecycle == 2 || this.lifecycle == 4) {
/*       */       return;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  3974 */     needLineUnchecked();
/*       */ 
/*       */     
/*       */     try {
/*  3978 */       if (this.closeCallback != null) {
/*  3979 */         this.closeCallback.beforeClose(this, this.privateData);
/*       */       }
/*  3981 */       closeStatementCache();
/*  3982 */       closeStatements(false);
/*       */       
/*  3984 */       if (this.lifecycle == 1) this.lifecycle = 2;
/*       */ 
/*       */       
/*  3987 */       if (this.isProxy)
/*       */       {
/*  3989 */         close(1);
/*       */       }
/*       */       
/*  3992 */       if (this.timeZoneTab != null) {
/*  3993 */         this.timeZoneTab.freeInstance();
/*       */       }
/*  3995 */       logoff();
/*  3996 */       cleanup();
/*       */       
/*  3998 */       if (this.timeout != null) {
/*  3999 */         this.timeout.close();
/*       */       }
/*  4001 */       if (this.closeCallback != null) {
/*  4002 */         this.closeCallback.afterClose(this.privateData);
/*       */       }
/*       */     } finally {
/*       */       
/*  4006 */       this.lifecycle = 4;
/*  4007 */       this.isUsable = false;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDataIntegrityAlgorithmName() throws SQLException {
/*  4018 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4019 */     sQLException.fillInStackTrace();
/*  4020 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getEncryptionAlgorithmName() throws SQLException {
/*  4027 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4028 */     sQLException.fillInStackTrace();
/*  4029 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getAuthenticationAdaptorName() throws SQLException {
/*  4036 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4037 */     sQLException.fillInStackTrace();
/*  4038 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void closeInternal(boolean paramBoolean) throws SQLException {
/*  4048 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4049 */     sQLException.fillInStackTrace();
/*  4050 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void cleanupAndClose(boolean paramBoolean) throws SQLException {
/*  4061 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4062 */     sQLException.fillInStackTrace();
/*  4063 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanupAndClose() throws SQLException {
/*  4074 */     if (this.lifecycle != 1) {
/*       */       return;
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  4080 */     this.lifecycle = 16;
/*       */ 
/*       */     
/*  4083 */     cancel();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void closeLogicalConnection() throws SQLException {
/*  4090 */     if (this.lifecycle == 1 || this.lifecycle == 16 || this.lifecycle == 2) {
/*       */ 
/*       */ 
/*       */       
/*  4094 */       this.savepointStatement = null;
/*  4095 */       closeStatements(true);
/*       */       
/*  4097 */       if (this.clientIdSet) {
/*  4098 */         clearClientIdentifier(this.clientId);
/*       */       }
/*  4100 */       this.logicalConnectionAttached = null;
/*  4101 */       this.lifecycle = 1;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close(Properties paramProperties) throws SQLException {
/*  4121 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4122 */     sQLException.fillInStackTrace();
/*  4123 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void close(int paramInt) throws SQLException {
/*  4139 */     if ((paramInt & 0x1000) != 0) {
/*       */       
/*  4141 */       close();
/*       */       
/*       */       return;
/*       */     } 
/*       */     
/*  4146 */     if ((paramInt & 0x1) != 0 && this.isProxy) {
/*       */       
/*  4148 */       purgeStatementCache();
/*  4149 */       closeStatements(false);
/*  4150 */       this.descriptorCacheStack[this.dci--] = null;
/*       */       
/*  4152 */       closeProxySession();
/*       */       
/*  4154 */       this.isProxy = false;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*  4161 */   private static final OracleSQLPermission CALL_ABORT_PERMISSION = new OracleSQLPermission("callAbort"); static final String DATABASE_NAME = "DATABASE_NAME"; static final String SERVER_HOST = "SERVER_HOST"; static final String INSTANCE_NAME = "INSTANCE_NAME"; static final String SERVICE_NAME = "SERVICE_NAME"; Hashtable clientData; private BufferCacheStore connectionBufferCacheStore; private static ThreadLocal<BufferCacheStore> threadLocalBufferCacheStore; private int pingResult; String sessionTimeZone; String databaseTimeZone; Calendar dbTzCalendar; static final String RAW_STR = "RAW"; static final String SYS_RAW_STR = "SYS.RAW"; static final String SYS_ANYDATA_STR = "SYS.ANYDATA"; static final String SYS_XMLTYPE_STR = "SYS.XMLTYPE";
/*       */   int timeZoneVersionNumber;
/*       */   TIMEZONETAB timeZoneTab;
/*       */   
/*       */   public void abort() throws SQLException {
/*  4166 */     SecurityManager securityManager = System.getSecurityManager();
/*  4167 */     if (securityManager != null) {
/*  4168 */       securityManager.checkPermission((Permission)CALL_ABORT_PERMISSION);
/*       */     }
/*       */ 
/*       */ 
/*       */     
/*  4173 */     if (this.lifecycle == 4 || this.lifecycle == 8) {
/*       */       return;
/*       */     }
/*       */     
/*  4177 */     this.lifecycle = 8;
/*       */ 
/*       */     
/*  4180 */     doAbort();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void closeProxySession() throws SQLException {
/*  4193 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4194 */     sQLException.fillInStackTrace();
/*  4195 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Properties getServerSessionInfo() throws SQLException {
/*  4212 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4213 */     sQLException.fillInStackTrace();
/*  4214 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void applyConnectionAttributes(Properties paramProperties) throws SQLException {
/*  4227 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4228 */     sQLException.fillInStackTrace();
/*  4229 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Properties getConnectionAttributes() throws SQLException {
/*  4242 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4243 */     sQLException.fillInStackTrace();
/*  4244 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Properties getUnMatchedConnectionAttributes() throws SQLException {
/*  4257 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4258 */     sQLException.fillInStackTrace();
/*  4259 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAbandonedTimeoutEnabled(boolean paramBoolean) throws SQLException {
/*  4273 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4274 */     sQLException.fillInStackTrace();
/*  4275 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerConnectionCacheCallback(OracleConnectionCacheCallback paramOracleConnectionCacheCallback, Object paramObject, int paramInt) throws SQLException {
/*  4288 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4289 */     sQLException.fillInStackTrace();
/*  4290 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnectionCacheCallback getConnectionCacheCallbackObj() throws SQLException {
/*  4303 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4304 */     sQLException.fillInStackTrace();
/*  4305 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Object getConnectionCacheCallbackPrivObj() throws SQLException {
/*  4317 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4318 */     sQLException.fillInStackTrace();
/*  4319 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getConnectionCacheCallbackFlag() throws SQLException {
/*  4331 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4332 */     sQLException.fillInStackTrace();
/*  4333 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setConnectionReleasePriority(int paramInt) throws SQLException {
/*  4346 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4347 */     sQLException.fillInStackTrace();
/*  4348 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getConnectionReleasePriority() throws SQLException {
/*  4360 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  4361 */     sQLException.fillInStackTrace();
/*  4362 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isClosed() throws SQLException {
/*  4375 */     return (this.lifecycle != 1);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isProxySession() {
/*  4382 */     return this.isProxy;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void openProxySession(int paramInt, Properties paramProperties) throws SQLException {
/*  4391 */     boolean bool = true;
/*       */     
/*  4393 */     if (this.isProxy) {
/*       */       
/*  4395 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 149);
/*  4396 */       sQLException.fillInStackTrace();
/*  4397 */       throw sQLException;
/*       */     } 
/*       */     
/*  4400 */     String str1 = paramProperties.getProperty("PROXY_USER_NAME");
/*  4401 */     String str2 = paramProperties.getProperty("PROXY_USER_PASSWORD");
/*  4402 */     String str3 = paramProperties.getProperty("PROXY_DISTINGUISHED_NAME");
/*       */     
/*  4404 */     Object object = paramProperties.get("PROXY_CERTIFICATE");
/*       */     
/*  4406 */     if (paramInt == 1) {
/*       */       
/*  4408 */       if (str1 == null && str2 == null)
/*       */       {
/*  4410 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4411 */         sQLException.fillInStackTrace();
/*  4412 */         throw sQLException;
/*       */       }
/*       */     
/*  4415 */     } else if (paramInt == 2) {
/*       */       
/*  4417 */       if (str3 == null)
/*       */       {
/*  4419 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4420 */         sQLException.fillInStackTrace();
/*  4421 */         throw sQLException;
/*       */       }
/*       */     
/*  4424 */     } else if (paramInt == 3) {
/*       */       
/*  4426 */       if (object == null) {
/*       */         
/*  4428 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4429 */         sQLException.fillInStackTrace();
/*  4430 */         throw sQLException;
/*       */       } 
/*       */ 
/*       */       
/*       */       try {
/*  4435 */         byte[] arrayOfByte = (byte[])object;
/*       */       }
/*  4437 */       catch (ClassCastException classCastException) {
/*       */ 
/*       */         
/*  4440 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4441 */         sQLException.fillInStackTrace();
/*  4442 */         throw sQLException;
/*       */       }
/*       */     
/*       */     }
/*       */     else {
/*       */       
/*  4448 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 150);
/*  4449 */       sQLException.fillInStackTrace();
/*  4450 */       throw sQLException;
/*       */     } 
/*       */     
/*  4453 */     purgeStatementCache();
/*  4454 */     closeStatements(false);
/*       */ 
/*       */ 
/*       */     
/*       */     try {
/*  4459 */       doProxySession(paramInt, paramProperties);
/*  4460 */       this.dci++;
/*       */       
/*  4462 */       bool = false;
/*       */     
/*       */     }
/*       */     finally {
/*       */       
/*  4467 */       if (bool == true) {
/*  4468 */         closeProxySession();
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doProxySession(int paramInt, Properties paramProperties) throws SQLException {
/*  4479 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  4480 */     sQLException.fillInStackTrace();
/*  4481 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cleanup() {
/*  4491 */     this.fdo = null;
/*  4492 */     this.conversion = null;
/*  4493 */     this.statements = null;
/*  4494 */     this.descriptorCacheStack[this.dci] = null;
/*  4495 */     this.map = null;
/*  4496 */     this.javaObjectMap = null;
/*  4497 */     this.statementHoldingLine = null;
/*  4498 */     this.sqlObj = null;
/*  4499 */     this.isProxy = false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized DatabaseMetaData getMetaData() throws SQLException {
/*  4516 */     if (this.lifecycle != 1) {
/*       */       
/*  4518 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  4519 */       sQLException.fillInStackTrace();
/*  4520 */       throw sQLException;
/*       */     } 
/*       */     
/*  4523 */     if (this.databaseMetaData == null) {
/*  4524 */       this.databaseMetaData = new OracleDatabaseMetaData(this);
/*       */     }
/*  4526 */     return (DatabaseMetaData)this.databaseMetaData;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setReadOnly(boolean paramBoolean) throws SQLException {
/*  4543 */     this.readOnly = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean isReadOnly() throws SQLException {
/*  4559 */     return this.readOnly;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCatalog(String paramString) throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getCatalog() throws SQLException {
/*  4581 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setTransactionIsolation(int paramInt) throws SQLException {
/*  4591 */     if (this.txnLevel == paramInt) {
/*       */       return;
/*       */     }
/*  4594 */     Statement statement = createStatement();
/*       */     
/*       */     try {
/*       */       SQLException sQLException;
/*  4598 */       switch (paramInt) {
/*       */ 
/*       */ 
/*       */         
/*       */         case 2:
/*  4603 */           statement.execute("ALTER SESSION SET ISOLATION_LEVEL = READ COMMITTED");
/*       */           
/*  4605 */           this.txnLevel = 2;
/*       */           break;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         case 8:
/*  4612 */           statement.execute("ALTER SESSION SET ISOLATION_LEVEL = SERIALIZABLE");
/*       */           
/*  4614 */           this.txnLevel = 8;
/*       */           break;
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*       */         default:
/*  4621 */           sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 30);
/*  4622 */           sQLException.fillInStackTrace();
/*  4623 */           throw sQLException;
/*       */       } 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*       */     } finally {
/*  4631 */       statement.close();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getTransactionIsolation() throws SQLException {
/*  4640 */     return this.txnLevel;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setAutoClose(boolean paramBoolean) throws SQLException {
/*  4653 */     if (!paramBoolean) {
/*       */       
/*  4655 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 31);
/*  4656 */       sQLException.fillInStackTrace();
/*  4657 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getAutoClose() throws SQLException {
/*  4669 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public SQLWarning getWarnings() throws SQLException {
/*  4679 */     return this.sqlWarning;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearWarnings() throws SQLException {
/*  4686 */     this.sqlWarning = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setWarnings(SQLWarning paramSQLWarning) {
/*  4693 */     this.sqlWarning = paramSQLWarning;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDefaultRowPrefetch(int paramInt) throws SQLException {
/*  4737 */     if (paramInt <= 0) {
/*       */       
/*  4739 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 20);
/*  4740 */       sQLException.fillInStackTrace();
/*  4741 */       throw sQLException;
/*       */     } 
/*       */     
/*  4744 */     this.defaultRowPrefetch = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getDefaultRowPrefetch() {
/*  4771 */     return this.defaultRowPrefetch;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getTimestamptzInGmt() {
/*  4778 */     return this.timestamptzInGmt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getUse1900AsYearForTime() {
/*  4785 */     return this.use1900AsYearForTime;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setDefaultExecuteBatch(int paramInt) throws SQLException {
/*  4827 */     if (paramInt <= 0) {
/*       */       
/*  4829 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 42);
/*  4830 */       sQLException.fillInStackTrace();
/*  4831 */       throw sQLException;
/*       */     } 
/*       */     
/*  4834 */     this.defaultExecuteBatch = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getDefaultExecuteBatch() {
/*  4862 */     return this.defaultExecuteBatch;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setRemarksReporting(boolean paramBoolean) {
/*  4885 */     this.reportRemarks = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getRemarksReporting() {
/*  4898 */     return this.reportRemarks;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setIncludeSynonyms(boolean paramBoolean) {
/*  4919 */     this.includeSynonyms = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String[] getEndToEndMetrics() throws SQLException {
/*       */     String[] arrayOfString;
/*  4933 */     if (this.endToEndValues == null) {
/*       */       
/*  4935 */       arrayOfString = null;
/*       */     }
/*       */     else {
/*       */       
/*  4939 */       arrayOfString = new String[this.endToEndValues.length];
/*       */       
/*  4941 */       System.arraycopy(this.endToEndValues, 0, arrayOfString, 0, this.endToEndValues.length);
/*       */     } 
/*  4943 */     return arrayOfString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getEndToEndECIDSequenceNumber() throws SQLException {
/*  4961 */     return this.endToEndECIDSequenceNumber;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setEndToEndMetrics(String[] paramArrayOfString, short paramShort) throws SQLException {
/*  4976 */     String[] arrayOfString = new String[paramArrayOfString.length];
/*       */     
/*  4978 */     System.arraycopy(paramArrayOfString, 0, arrayOfString, 0, paramArrayOfString.length);
/*  4979 */     setEndToEndMetricsInternal(arrayOfString, paramShort);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void setEndToEndMetricsInternal(String[] paramArrayOfString, short paramShort) throws SQLException {
/*  4994 */     if (paramArrayOfString != this.endToEndValues) {
/*       */       
/*  4996 */       if (paramArrayOfString.length != 4) {
/*       */ 
/*       */ 
/*       */         
/*  5000 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 156);
/*  5001 */         sQLException.fillInStackTrace();
/*  5002 */         throw sQLException;
/*       */       } 
/*       */       
/*       */       byte b;
/*  5006 */       for (b = 0; b < 4; b++) {
/*       */         
/*  5008 */         String str = paramArrayOfString[b];
/*       */         
/*  5010 */         if (str != null && str.length() > this.endToEndMaxLength[b]) {
/*       */ 
/*       */           
/*  5013 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 159, str);
/*  5014 */           sQLException.fillInStackTrace();
/*  5015 */           throw sQLException;
/*       */         } 
/*       */       } 
/*       */ 
/*       */       
/*  5020 */       if (this.endToEndValues != null) {
/*       */         
/*  5022 */         for (b = 0; b < 4; b++) {
/*       */           
/*  5024 */           String str = paramArrayOfString[b];
/*       */           
/*  5026 */           if ((str == null && this.endToEndValues[b] != null) || (str != null && !str.equals(this.endToEndValues[b]))) {
/*       */ 
/*       */             
/*  5029 */             this.endToEndHasChanged[b] = true;
/*  5030 */             this.endToEndAnyChanged = true;
/*       */           } 
/*       */         } 
/*       */ 
/*       */         
/*  5035 */         this.endToEndHasChanged[0] = this.endToEndHasChanged[0] | this.endToEndHasChanged[3];
/*       */       
/*       */       }
/*       */       else {
/*       */         
/*  5040 */         for (b = 0; b < 4; b++)
/*       */         {
/*  5042 */           this.endToEndHasChanged[b] = true;
/*       */         }
/*       */         
/*  5045 */         this.endToEndAnyChanged = true;
/*       */       } 
/*       */ 
/*       */       
/*  5049 */       this.endToEndValues = paramArrayOfString;
/*       */     } 
/*       */     
/*  5052 */     this.endToEndECIDSequenceNumber = paramShort;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void updateSystemContext() throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void resetSystemContext() {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void updateSystemContext11() throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getIncludeSynonyms() {
/*  5111 */     return this.includeSynonyms;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setRestrictGetTables(boolean paramBoolean) {
/*  5152 */     this.restrictGettables = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getRestrictGetTables() {
/*  5168 */     return this.restrictGettables;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDefaultFixedString(boolean paramBoolean) {
/*  5197 */     this.fixedString = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setDefaultNChar(boolean paramBoolean) {
/*  5206 */     this.defaultnchar = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getDefaultFixedString() {
/*  5234 */     return this.fixedString;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getNlsRatio() {
/*  5247 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getC2SNlsRatio() {
/*  5254 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void addStatement(OracleStatement paramOracleStatement) {
/*  5263 */     if (paramOracleStatement.next != null) {
/*  5264 */       throw new Error("add_statement called twice on " + paramOracleStatement);
/*       */     }
/*  5266 */     paramOracleStatement.next = this.statements;
/*       */     
/*  5268 */     if (this.statements != null) {
/*  5269 */       this.statements.prev = paramOracleStatement;
/*       */     }
/*  5271 */     this.statements = paramOracleStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void removeStatement(OracleStatement paramOracleStatement) {
/*  5290 */     OracleStatement oracleStatement1 = paramOracleStatement.prev;
/*  5291 */     OracleStatement oracleStatement2 = paramOracleStatement.next;
/*       */     
/*  5293 */     if (oracleStatement1 == null) {
/*       */       
/*  5295 */       if (this.statements != paramOracleStatement) {
/*       */         return;
/*       */       }
/*  5298 */       this.statements = oracleStatement2;
/*       */     } else {
/*       */       
/*  5301 */       oracleStatement1.next = oracleStatement2;
/*       */     } 
/*  5303 */     if (oracleStatement2 != null) {
/*  5304 */       oracleStatement2.prev = oracleStatement1;
/*       */     }
/*  5306 */     paramOracleStatement.next = null;
/*  5307 */     paramOracleStatement.prev = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void closeStatements(boolean paramBoolean) throws SQLException {
/*  5329 */     OracleStatement oracleStatement = this.statements;
/*       */     
/*  5331 */     while (oracleStatement != null) {
/*       */       
/*  5333 */       OracleStatement oracleStatement1 = oracleStatement.nextChild;
/*       */       
/*  5335 */       if (oracleStatement.serverCursor) {
/*       */         
/*  5337 */         oracleStatement.close();
/*  5338 */         removeStatement(oracleStatement);
/*       */       } 
/*       */       
/*  5341 */       oracleStatement = oracleStatement1;
/*       */     } 
/*       */ 
/*       */     
/*  5345 */     oracleStatement = this.statements;
/*       */     
/*  5347 */     while (oracleStatement != null) {
/*       */       
/*  5349 */       OracleStatement oracleStatement1 = oracleStatement.next;
/*       */       
/*  5351 */       if (paramBoolean) {
/*  5352 */         oracleStatement.close();
/*       */       } else {
/*  5354 */         oracleStatement.hardClose();
/*  5355 */       }  removeStatement(oracleStatement);
/*       */       
/*  5357 */       oracleStatement = oracleStatement1;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   final void purgeStatementCache() throws SQLException {
/*  5368 */     if (isStatementCacheInitialized()) {
/*       */       
/*  5370 */       this.statementCache.purgeImplicitCache();
/*  5371 */       this.statementCache.purgeExplicitCache();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   final void closeStatementCache() throws SQLException {
/*  5381 */     if (isStatementCacheInitialized()) {
/*       */ 
/*       */ 
/*       */       
/*  5385 */       this.statementCache.close();
/*       */       
/*  5387 */       this.statementCache = null;
/*  5388 */       this.clearStatementMetaData = true;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void needLine() throws SQLException {
/*  5397 */     if (this.lifecycle != 1) {
/*       */       
/*  5399 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5400 */       sQLException.fillInStackTrace();
/*  5401 */       throw sQLException;
/*       */     } 
/*       */     
/*  5404 */     needLineUnchecked();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void needLineUnchecked() throws SQLException {
/*  5414 */     if (this.statementHoldingLine != null)
/*       */     {
/*  5416 */       this.statementHoldingLine.freeLine();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void holdLine(OracleStatement paramOracleStatement) {
/*  5424 */     holdLine((OracleStatement)paramOracleStatement);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void holdLine(OracleStatement paramOracleStatement) {
/*  5433 */     this.statementHoldingLine = paramOracleStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   synchronized void releaseLine() {
/*  5441 */     releaseLineForCancel();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void releaseLineForCancel() {
/*  5450 */     this.statementHoldingLine = null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void startup(String paramString, int paramInt) throws SQLException {
/*  5458 */     if (this.lifecycle != 1) {
/*       */       
/*  5460 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5461 */       sQLException1.fillInStackTrace();
/*  5462 */       throw sQLException1;
/*       */     } 
/*       */ 
/*       */     
/*  5466 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5467 */     sQLException.fillInStackTrace();
/*  5468 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void startup(OracleConnection.DatabaseStartupMode paramDatabaseStartupMode) throws SQLException {
/*  5476 */     if (this.lifecycle != 1) {
/*       */       
/*  5478 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5479 */       sQLException.fillInStackTrace();
/*  5480 */       throw sQLException;
/*       */     } 
/*  5482 */     if (paramDatabaseStartupMode == null) {
/*       */       
/*  5484 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5485 */       sQLException.fillInStackTrace();
/*  5486 */       throw sQLException;
/*       */     } 
/*       */     
/*  5489 */     needLine();
/*  5490 */     doStartup(paramDatabaseStartupMode.getMode());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doStartup(int paramInt) throws SQLException {
/*  5499 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5500 */     sQLException.fillInStackTrace();
/*  5501 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void shutdown(OracleConnection.DatabaseShutdownMode paramDatabaseShutdownMode) throws SQLException {
/*  5510 */     if (this.lifecycle != 1) {
/*       */       
/*  5512 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5513 */       sQLException.fillInStackTrace();
/*  5514 */       throw sQLException;
/*       */     } 
/*  5516 */     if (paramDatabaseShutdownMode == null) {
/*       */       
/*  5518 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5519 */       sQLException.fillInStackTrace();
/*  5520 */       throw sQLException;
/*       */     } 
/*       */     
/*  5523 */     needLine();
/*  5524 */     doShutdown(paramDatabaseShutdownMode.getMode());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doShutdown(int paramInt) throws SQLException {
/*  5533 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5534 */     sQLException.fillInStackTrace();
/*  5535 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void archive(int paramInt1, int paramInt2, String paramString) throws SQLException {
/*  5546 */     if (this.lifecycle != 1) {
/*       */       
/*  5548 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/*  5549 */       sQLException1.fillInStackTrace();
/*  5550 */       throw sQLException1;
/*       */     } 
/*       */ 
/*       */     
/*  5554 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  5555 */     sQLException.fillInStackTrace();
/*  5556 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerSQLType(String paramString1, String paramString2) throws SQLException {
/*  5570 */     if (paramString1 == null || paramString2 == null) {
/*       */       
/*  5572 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5573 */       sQLException.fillInStackTrace();
/*  5574 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*       */     try {
/*  5579 */       registerSQLType(paramString1, Class.forName(paramString2));
/*       */     }
/*  5581 */     catch (ClassNotFoundException classNotFoundException) {
/*       */ 
/*       */       
/*  5584 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 1, "Class not found: " + paramString2);
/*  5585 */       sQLException.fillInStackTrace();
/*  5586 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerSQLType(String paramString, Class<?> paramClass) throws SQLException {
/*  5597 */     if (paramString == null || paramClass == null) {
/*       */       
/*  5599 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5600 */       sQLException.fillInStackTrace();
/*  5601 */       throw sQLException;
/*       */     } 
/*       */     
/*  5604 */     if (this.map == null) this.map = new Hashtable<Object, Object>(10);
/*       */     
/*  5606 */     this.map.put(paramString, paramClass);
/*  5607 */     this.map.put(paramClass.getName(), paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String getSQLType(Object paramObject) throws SQLException {
/*  5615 */     if (paramObject != null && this.map != null) {
/*       */       
/*  5617 */       String str = paramObject.getClass().getName();
/*       */       
/*  5619 */       return (String)this.map.get(str);
/*       */     } 
/*       */     
/*  5622 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getJavaObject(String paramString) throws SQLException {
/*  5630 */     Object object = null;
/*       */ 
/*       */     
/*       */     try {
/*  5634 */       if (paramString != null && this.map != null)
/*       */       {
/*  5636 */         Class<Object> clazz = (Class)this.map.get(paramString);
/*       */         
/*  5638 */         object = clazz.newInstance();
/*       */       }
/*       */     
/*  5641 */     } catch (IllegalAccessException illegalAccessException) {
/*       */       
/*  5643 */       illegalAccessException.printStackTrace();
/*       */     }
/*  5645 */     catch (InstantiationException instantiationException) {
/*       */       
/*  5647 */       instantiationException.printStackTrace();
/*       */     } 
/*       */     
/*  5650 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void putDescriptor(String paramString, Object paramObject) throws SQLException {
/*  5663 */     if (paramString != null && paramObject != null) {
/*       */       
/*  5665 */       if (this.descriptorCacheStack[this.dci] == null) {
/*  5666 */         this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
/*       */       }
/*  5668 */       ((TypeDescriptor)paramObject).fixupConnection(this);
/*  5669 */       this.descriptorCacheStack[this.dci].put(paramString, paramObject);
/*       */     }
/*       */     else {
/*       */       
/*  5673 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5674 */       sQLException.fillInStackTrace();
/*  5675 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getDescriptor(String paramString) {
/*  5687 */     Object object = null;
/*       */     
/*  5689 */     if (paramString != null) {
/*  5690 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5691 */         object = this.descriptorCacheStack[this.dci].get(paramString); 
/*  5692 */       if (object == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5693 */         object = this.descriptorCacheStack[0].get(paramString);
/*       */       }
/*       */     } 
/*  5696 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeDecriptor(String paramString) {
/*  5708 */     removeDescriptor(paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeDescriptor(String paramString) {
/*  5722 */     if (paramString != null && this.descriptorCacheStack[this.dci] != null)
/*  5723 */       this.descriptorCacheStack[this.dci].remove(paramString); 
/*  5724 */     if (paramString != null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5725 */       this.descriptorCacheStack[0].remove(paramString);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeAllDescriptor() {
/*  5736 */     for (byte b = 0; b <= this.dci; b++) {
/*  5737 */       if (this.descriptorCacheStack[b] != null) {
/*  5738 */         this.descriptorCacheStack[b].clear();
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int numberOfDescriptorCacheEntries() {
/*  5755 */     int i = 0;
/*  5756 */     for (byte b = 0; b <= this.dci; b++) {
/*  5757 */       if (this.descriptorCacheStack[b] != null)
/*  5758 */         i += this.descriptorCacheStack[b].size(); 
/*       */     } 
/*  5760 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Enumeration descriptorCacheKeys() {
/*  5773 */     if (this.dci == 0) {
/*  5774 */       if (this.descriptorCacheStack[this.dci] != null) {
/*  5775 */         return this.descriptorCacheStack[this.dci].keys();
/*       */       }
/*  5777 */       return null;
/*       */     } 
/*  5779 */     if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] != null)
/*  5780 */       return this.descriptorCacheStack[1].keys(); 
/*  5781 */     if (this.descriptorCacheStack[1] == null && this.descriptorCacheStack[0] != null)
/*  5782 */       return this.descriptorCacheStack[0].keys(); 
/*  5783 */     if (this.descriptorCacheStack[0] == null && this.descriptorCacheStack[1] == null) {
/*  5784 */       return null;
/*       */     }
/*  5786 */     Vector vector = new Vector(this.descriptorCacheStack[1].keySet());
/*  5787 */     vector.addAll(this.descriptorCacheStack[0].keySet());
/*  5788 */     return vector.elements();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void putDescriptor(byte[] paramArrayOfbyte, Object paramObject) throws SQLException {
/*  5802 */     if (paramArrayOfbyte != null && paramObject != null) {
/*       */       
/*  5804 */       if (this.descriptorCacheStack[this.dci] == null) {
/*  5805 */         this.descriptorCacheStack[this.dci] = new Hashtable<Object, Object>(10);
/*       */       }
/*  5807 */       this.descriptorCacheStack[this.dci].put(new ByteArrayKey(paramArrayOfbyte), paramObject);
/*       */     }
/*       */     else {
/*       */       
/*  5811 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  5812 */       sQLException.fillInStackTrace();
/*  5813 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getDescriptor(byte[] paramArrayOfbyte) {
/*  5825 */     Object object = null;
/*       */     
/*  5827 */     if (paramArrayOfbyte != null) {
/*  5828 */       ByteArrayKey byteArrayKey = new ByteArrayKey(paramArrayOfbyte);
/*  5829 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5830 */         object = this.descriptorCacheStack[this.dci].get(byteArrayKey); 
/*  5831 */       if (object == null && this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5832 */         object = this.descriptorCacheStack[0].get(byteArrayKey);
/*       */       }
/*       */     } 
/*  5835 */     return object;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void removeDecriptor(byte[] paramArrayOfbyte) {
/*  5847 */     if (paramArrayOfbyte != null) {
/*  5848 */       ByteArrayKey byteArrayKey = new ByteArrayKey(paramArrayOfbyte);
/*  5849 */       if (this.descriptorCacheStack[this.dci] != null)
/*  5850 */         this.descriptorCacheStack[this.dci].remove(byteArrayKey); 
/*  5851 */       if (this.dci == 1 && this.descriptorCacheStack[0] != null) {
/*  5852 */         this.descriptorCacheStack[0].remove(byteArrayKey);
/*       */       }
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getJdbcCsId() throws SQLException {
/*  5875 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  5878 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5879 */       sQLException.fillInStackTrace();
/*  5880 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5884 */     return this.conversion.getClientCharSet();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getDbCsId() throws SQLException {
/*  5899 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  5902 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5903 */       sQLException.fillInStackTrace();
/*  5904 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5908 */     return this.conversion.getServerCharSetId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getNCsId() throws SQLException {
/*  5915 */     if (this.conversion == null) {
/*       */ 
/*       */       
/*  5918 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 65);
/*  5919 */       sQLException.fillInStackTrace();
/*  5920 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  5924 */     return this.conversion.getNCharSetId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getStructAttrCsId() throws SQLException {
/*  5940 */     return getDbCsId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getStructAttrNCsId() throws SQLException {
/*  5947 */     return getNCsId();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Map getTypeMap() {
/*  5957 */     if (this.map == null) this.map = new Hashtable<Object, Object>(10); 
/*  5958 */     return this.map;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setTypeMap(Map paramMap) {
/*  5965 */     this.map = paramMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setUsingXAFlag(boolean paramBoolean) {
/*  5973 */     this.usingXA = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getUsingXAFlag() {
/*  5980 */     return this.usingXA;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setXAErrorFlag(boolean paramBoolean) {
/*  5988 */     this.xaWantsError = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getXAErrorFlag() {
/*  5995 */     return this.xaWantsError;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   String getPropertyFromDatabase(String paramString) throws SQLException {
/*  6003 */     String str = null;
/*  6004 */     Statement statement = null;
/*  6005 */     ResultSet resultSet = null;
/*       */     
/*       */     try {
/*  6008 */       statement = createStatement();
/*  6009 */       statement.setFetchSize(1);
/*  6010 */       resultSet = statement.executeQuery(paramString);
/*  6011 */       if (resultSet.next()) {
/*  6012 */         str = resultSet.getString(1);
/*       */       }
/*       */     } finally {
/*       */       
/*  6016 */       if (resultSet != null)
/*  6017 */         resultSet.close(); 
/*  6018 */       if (statement != null)
/*  6019 */         statement.close(); 
/*       */     } 
/*  6021 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized String getUserName() throws SQLException {
/*  6029 */     if (this.userName == null) {
/*  6030 */       this.userName = getPropertyFromDatabase("SELECT USER FROM DUAL");
/*       */     }
/*  6032 */     return this.userName;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getCurrentSchema() throws SQLException {
/*  6047 */     return getPropertyFromDatabase("SELECT SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA') FROM DUAL");
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDefaultSchemaNameForNamedTypes() throws SQLException {
/*  6065 */     String str = null;
/*       */     
/*  6067 */     if (this.createDescriptorUseCurrentSchemaForSchemaName) {
/*  6068 */       str = getCurrentSchema();
/*       */     } else {
/*  6070 */       str = getUserName();
/*       */     } 
/*  6072 */     return str;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStartTime(long paramLong) throws SQLException {
/*  6090 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6091 */     sQLException.fillInStackTrace();
/*  6092 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized long getStartTime() throws SQLException {
/*  6108 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6109 */     sQLException.fillInStackTrace();
/*  6110 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void registerHeartbeat() throws SQLException {
/*  6123 */     if (this.logicalConnectionAttached != null) {
/*  6124 */       this.logicalConnectionAttached.registerHeartbeat();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getHeartbeatNoChangeCount() throws SQLException {
/*  6136 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 152);
/*  6137 */     sQLException.fillInStackTrace();
/*  6138 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized byte[] getFDO(boolean paramBoolean) throws SQLException {
/*  6150 */     if (this.fdo == null && paramBoolean) {
/*       */       
/*  6152 */       CallableStatement callableStatement = null;
/*       */ 
/*       */       
/*       */       try {
/*  6156 */         callableStatement = prepareCall("begin :1 := dbms_pickler.get_format (:2); end;");
/*       */ 
/*       */         
/*  6159 */         callableStatement.registerOutParameter(1, 2);
/*  6160 */         callableStatement.registerOutParameter(2, -4);
/*  6161 */         callableStatement.execute();
/*       */         
/*  6163 */         this.fdo = callableStatement.getBytes(2);
/*       */       }
/*       */       finally {
/*       */         
/*  6167 */         if (callableStatement != null) {
/*  6168 */           callableStatement.close();
/*       */         }
/*  6170 */         callableStatement = null;
/*       */       } 
/*       */     } 
/*       */     
/*  6174 */     return this.fdo;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setFDO(byte[] paramArrayOfbyte) throws SQLException {
/*  6185 */     this.fdo = paramArrayOfbyte;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getBigEndian() throws SQLException {
/*  6196 */     if (this.bigEndian == null) {
/*       */       
/*  6198 */       int[] arrayOfInt = Util.toJavaUnsignedBytes(getFDO(true));
/*       */ 
/*       */ 
/*       */       
/*  6202 */       int i = arrayOfInt[6 + arrayOfInt[5] + arrayOfInt[6] + 5];
/*       */ 
/*       */ 
/*       */ 
/*       */       
/*  6207 */       int j = (byte)(i & 0x10);
/*       */       
/*  6209 */       if (j < 0) {
/*  6210 */         j = j + 256;
/*       */       }
/*  6212 */       if (j > 0) {
/*  6213 */         this.bigEndian = Boolean.TRUE;
/*       */       } else {
/*  6215 */         this.bigEndian = Boolean.FALSE;
/*       */       } 
/*       */     } 
/*  6218 */     return this.bigEndian.booleanValue();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setHoldability(int paramInt) throws SQLException {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getHoldability() throws SQLException {
/*  6271 */     return 1;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Savepoint setSavepoint() throws SQLException {
/*  6280 */     return (Savepoint)oracleSetSavepoint();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Savepoint setSavepoint(String paramString) throws SQLException {
/*  6290 */     return (Savepoint)oracleSetSavepoint(paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void rollback(Savepoint paramSavepoint) throws SQLException {
/*  6301 */     disallowGlobalTxnMode(122);
/*       */ 
/*       */     
/*  6304 */     if (this.autocommit) {
/*       */       
/*  6306 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
/*  6307 */       sQLException.fillInStackTrace();
/*  6308 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6313 */     if (this.savepointStatement == null)
/*       */     {
/*  6315 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6318 */     String str = null;
/*       */ 
/*       */     
/*       */     try {
/*  6322 */       str = paramSavepoint.getSavepointName();
/*       */     }
/*  6324 */     catch (SQLException sQLException) {
/*       */       
/*  6326 */       str = "ORACLE_SVPT_" + paramSavepoint.getSavepointId();
/*       */     } 
/*       */     
/*  6329 */     this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void releaseSavepoint(Savepoint paramSavepoint) throws SQLException {
/*  6339 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6340 */     sQLException.fillInStackTrace();
/*  6341 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public Statement createStatement(int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  6387 */     return createStatement(paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  6438 */     return prepareStatement(paramString, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public CallableStatement prepareCall(String paramString, int paramInt1, int paramInt2, int paramInt3) throws SQLException {
/*  6486 */     return prepareCall(paramString, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int paramInt) throws SQLException {
/*  6536 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString);
/*  6537 */     if (paramInt == 2 || !autoKeyInfo.isInsertSqlStmt())
/*       */     {
/*  6539 */       return prepareStatement(paramString);
/*       */     }
/*  6541 */     if (paramInt != 1) {
/*       */       
/*  6543 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6544 */       sQLException.fillInStackTrace();
/*  6545 */       throw sQLException;
/*       */     } 
/*       */     
/*  6548 */     String str = autoKeyInfo.getNewSql();
/*  6549 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  6550 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  6552 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6553 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  6554 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6555 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, int[] paramArrayOfint) throws SQLException {
/*  6604 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfint);
/*       */     
/*  6606 */     if (!autoKeyInfo.isInsertSqlStmt()) return prepareStatement(paramString);
/*       */     
/*  6608 */     if (paramArrayOfint == null || paramArrayOfint.length == 0) {
/*       */       
/*  6610 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6611 */       sQLException.fillInStackTrace();
/*  6612 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6617 */     doDescribeTable(autoKeyInfo);
/*       */     
/*  6619 */     String str = autoKeyInfo.getNewSql();
/*  6620 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  6621 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  6623 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6624 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  6625 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6626 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public PreparedStatement prepareStatement(String paramString, String[] paramArrayOfString) throws SQLException {
/*  6676 */     AutoKeyInfo autoKeyInfo = new AutoKeyInfo(paramString, paramArrayOfString);
/*  6677 */     if (!autoKeyInfo.isInsertSqlStmt()) return prepareStatement(paramString);
/*       */     
/*  6679 */     if (paramArrayOfString == null || paramArrayOfString.length == 0) {
/*       */       
/*  6681 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/*  6682 */       sQLException.fillInStackTrace();
/*  6683 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */     
/*  6687 */     doDescribeTable(autoKeyInfo);
/*       */     
/*  6689 */     String str = autoKeyInfo.getNewSql();
/*  6690 */     OraclePreparedStatement oraclePreparedStatement = (OraclePreparedStatement)prepareStatement(str);
/*  6691 */     OraclePreparedStatement oraclePreparedStatement1 = (OraclePreparedStatement)((OraclePreparedStatementWrapper)oraclePreparedStatement).preparedStatement;
/*       */     
/*  6693 */     oraclePreparedStatement1.isAutoGeneratedKey = true;
/*  6694 */     oraclePreparedStatement1.autoKeyInfo = autoKeyInfo;
/*  6695 */     oraclePreparedStatement1.registerReturnParamsForAutoKey();
/*  6696 */     return (PreparedStatement)oraclePreparedStatement;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleSavepoint oracleSetSavepoint() throws SQLException {
/*  6722 */     disallowGlobalTxnMode(117);
/*       */ 
/*       */     
/*  6725 */     if (this.autocommit) {
/*       */       
/*  6727 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
/*  6728 */       sQLException.fillInStackTrace();
/*  6729 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6734 */     if (this.savepointStatement == null)
/*       */     {
/*  6736 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6739 */     OracleSavepoint oracleSavepoint = new OracleSavepoint();
/*       */     
/*  6741 */     String str = "SAVEPOINT ORACLE_SVPT_" + oracleSavepoint.getSavepointId();
/*       */     
/*  6743 */     this.savepointStatement.executeUpdate(str);
/*       */ 
/*       */     
/*  6746 */     return oracleSavepoint;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized OracleSavepoint oracleSetSavepoint(String paramString) throws SQLException {
/*  6773 */     disallowGlobalTxnMode(117);
/*       */ 
/*       */     
/*  6776 */     if (this.autocommit) {
/*       */       
/*  6778 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 120);
/*  6779 */       sQLException.fillInStackTrace();
/*  6780 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6785 */     if (this.savepointStatement == null)
/*       */     {
/*  6787 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6790 */     OracleSavepoint oracleSavepoint = new OracleSavepoint(paramString);
/*       */     
/*  6792 */     String str = "SAVEPOINT " + oracleSavepoint.getSavepointName();
/*       */     
/*  6794 */     this.savepointStatement.executeUpdate(str);
/*       */ 
/*       */     
/*  6797 */     return oracleSavepoint;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void oracleRollback(OracleSavepoint paramOracleSavepoint) throws SQLException {
/*  6825 */     disallowGlobalTxnMode(115);
/*       */ 
/*       */     
/*  6828 */     if (this.autocommit) {
/*       */       
/*  6830 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 121);
/*  6831 */       sQLException.fillInStackTrace();
/*  6832 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  6837 */     if (this.savepointStatement == null)
/*       */     {
/*  6839 */       this.savepointStatement = createStatement();
/*       */     }
/*       */     
/*  6842 */     String str = null;
/*       */ 
/*       */     
/*       */     try {
/*  6846 */       str = paramOracleSavepoint.getSavepointName();
/*       */     }
/*  6848 */     catch (SQLException sQLException) {
/*       */       
/*  6850 */       str = "ORACLE_SVPT_" + paramOracleSavepoint.getSavepointId();
/*       */     } 
/*       */     
/*  6853 */     this.savepointStatement.executeUpdate("ROLLBACK TO " + str);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void oracleReleaseSavepoint(OracleSavepoint paramOracleSavepoint) throws SQLException {
/*  6881 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  6882 */     sQLException.fillInStackTrace();
/*  6883 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void disallowGlobalTxnMode(int paramInt) throws SQLException {
/*  6904 */     if (this.txnMode == 1) {
/*       */       
/*  6906 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), paramInt);
/*  6907 */       sQLException.fillInStackTrace();
/*  6908 */       throw sQLException;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setTxnMode(int paramInt) {
/*  6922 */     this.txnMode = paramInt;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int getTxnMode() {
/*  6929 */     return this.txnMode;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object getClientData(Object paramObject) {
/*  6958 */     if (this.clientData == null)
/*       */     {
/*  6960 */       return null;
/*       */     }
/*       */     
/*  6963 */     return this.clientData.get(paramObject);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object setClientData(Object paramObject1, Object paramObject2) {
/*  6990 */     if (this.clientData == null)
/*       */     {
/*  6992 */       this.clientData = new Hashtable<Object, Object>();
/*       */     }
/*       */     
/*  6995 */     return this.clientData.put(paramObject1, paramObject2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Object removeClientData(Object paramObject) {
/*  7016 */     if (this.clientData == null)
/*       */     {
/*  7018 */       return null;
/*       */     }
/*       */     
/*  7021 */     return this.clientData.remove(paramObject);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BlobDBAccess createBlobDBAccess() throws SQLException {
/*  7029 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7030 */     sQLException.fillInStackTrace();
/*  7031 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public ClobDBAccess createClobDBAccess() throws SQLException {
/*  7040 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7041 */     sQLException.fillInStackTrace();
/*  7042 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public BfileDBAccess createBfileDBAccess() throws SQLException {
/*  7051 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7052 */     sQLException.fillInStackTrace();
/*  7053 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void printState() {
/*       */     try {
/*  7079 */       short s1 = getJdbcCsId();
/*       */ 
/*       */       
/*  7082 */       short s2 = getDbCsId();
/*       */ 
/*       */       
/*  7085 */       short s3 = getStructAttrCsId();
/*       */     
/*       */     }
/*  7088 */     catch (SQLException sQLException) {
/*       */       
/*  7090 */       sQLException.printStackTrace();
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getProtocolType() {
/*  7102 */     return this.protocol;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getURL() {
/*  7113 */     return this.url;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStmtCacheSize(int paramInt) throws SQLException {
/*  7127 */     setStatementCacheSize(paramInt);
/*  7128 */     setImplicitCachingEnabled(true);
/*  7129 */     setExplicitCachingEnabled(true);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStmtCacheSize(int paramInt, boolean paramBoolean) throws SQLException {
/*  7144 */     setStatementCacheSize(paramInt);
/*  7145 */     setImplicitCachingEnabled(true);
/*       */ 
/*       */     
/*  7148 */     setExplicitCachingEnabled(true);
/*       */     
/*  7150 */     this.clearStatementMetaData = paramBoolean;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getStmtCacheSize() {
/*  7164 */     int i = 0;
/*       */ 
/*       */     
/*       */     try {
/*  7168 */       i = getStatementCacheSize();
/*       */     }
/*  7170 */     catch (SQLException sQLException) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7176 */     if (i == -1)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  7181 */       i = 0;
/*       */     }
/*       */     
/*  7184 */     return i;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setStatementCacheSize(int paramInt) throws SQLException {
/*  7205 */     if (this.statementCache == null) {
/*       */       
/*  7207 */       this.statementCache = new LRUStatementCache(paramInt);
/*       */ 
/*       */     
/*       */     }
/*       */     else {
/*       */ 
/*       */       
/*  7214 */       this.statementCache.resize(paramInt);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized int getStatementCacheSize() throws SQLException {
/*  7233 */     if (this.statementCache == null) {
/*  7234 */       return -1;
/*       */     }
/*  7236 */     return this.statementCache.getCacheSize();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setImplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/*  7259 */     if (this.statementCache == null)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  7264 */       this.statementCache = new LRUStatementCache(0);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7271 */     this.statementCache.setImplicitCachingEnabled(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getImplicitCachingEnabled() throws SQLException {
/*  7290 */     if (this.statementCache == null) {
/*  7291 */       return false;
/*       */     }
/*  7293 */     return this.statementCache.getImplicitCachingEnabled();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setExplicitCachingEnabled(boolean paramBoolean) throws SQLException {
/*  7316 */     if (this.statementCache == null)
/*       */     {
/*       */ 
/*       */ 
/*       */       
/*  7321 */       this.statementCache = new LRUStatementCache(0);
/*       */     }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/*  7328 */     this.statementCache.setExplicitCachingEnabled(paramBoolean);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getExplicitCachingEnabled() throws SQLException {
/*  7347 */     if (this.statementCache == null) {
/*  7348 */       return false;
/*       */     }
/*  7350 */     return this.statementCache.getExplicitCachingEnabled();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void purgeImplicitCache() throws SQLException {
/*  7369 */     if (this.statementCache != null) {
/*  7370 */       this.statementCache.purgeImplicitCache();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void purgeExplicitCache() throws SQLException {
/*  7389 */     if (this.statementCache != null) {
/*  7390 */       this.statementCache.purgeExplicitCache();
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized PreparedStatement getStatementWithKey(String paramString) throws SQLException {
/*  7412 */     if (this.statementCache != null) {
/*       */       
/*  7414 */       OracleStatement oracleStatement = this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */       
/*  7417 */       if (oracleStatement == null || oracleStatement.statementType == 1) {
/*  7418 */         return (PreparedStatement)oracleStatement;
/*       */       }
/*       */ 
/*       */       
/*  7422 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
/*  7423 */       sQLException.fillInStackTrace();
/*  7424 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  7429 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized CallableStatement getCallWithKey(String paramString) throws SQLException {
/*  7451 */     if (this.statementCache != null) {
/*       */       
/*  7453 */       OracleStatement oracleStatement = this.statementCache.searchExplicitCache(paramString);
/*       */ 
/*       */       
/*  7456 */       if (oracleStatement == null || oracleStatement.statementType == 2) {
/*  7457 */         return (CallableStatement)oracleStatement;
/*       */       }
/*       */ 
/*       */       
/*  7461 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 125);
/*  7462 */       sQLException.fillInStackTrace();
/*  7463 */       throw sQLException;
/*       */     } 
/*       */ 
/*       */ 
/*       */     
/*  7468 */     return null;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void cacheImplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString, int paramInt1, int paramInt2) throws SQLException {
/*  7484 */     if (this.statementCache == null) {
/*       */       
/*  7486 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  7487 */       sQLException.fillInStackTrace();
/*  7488 */       throw sQLException;
/*       */     } 
/*       */     
/*  7491 */     this.statementCache.addToImplicitCache(paramOraclePreparedStatement, paramString, paramInt1, paramInt2);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void cacheExplicitStatement(OraclePreparedStatement paramOraclePreparedStatement, String paramString) throws SQLException {
/*  7508 */     if (this.statementCache == null) {
/*       */       
/*  7510 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 95);
/*  7511 */       sQLException.fillInStackTrace();
/*  7512 */       throw sQLException;
/*       */     } 
/*       */     
/*  7515 */     this.statementCache.addToExplicitCache(paramOraclePreparedStatement, paramString);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean isStatementCacheInitialized() {
/*  7530 */     if (this.statementCache == null)
/*  7531 */       return false; 
/*  7532 */     if (this.statementCache.getCacheSize() == 0) {
/*  7533 */       return false;
/*       */     }
/*  7535 */     return true;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private static final class BufferCacheStore
/*       */   {
/*  7571 */     static int MAX_CACHED_BUFFER_SIZE = Integer.MAX_VALUE;
/*       */     final BufferCache<byte[]> byteBufferCache;
/*       */     final BufferCache<char[]> charBufferCache;
/*       */     
/*       */     BufferCacheStore() {
/*  7576 */       this(MAX_CACHED_BUFFER_SIZE);
/*       */     }
/*       */     
/*       */     BufferCacheStore(int param1Int) {
/*  7580 */       this.byteBufferCache = (BufferCache)new BufferCache<byte>(param1Int);
/*  7581 */       this.charBufferCache = (BufferCache)new BufferCache<char>(param1Int);
/*       */     }
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   private BufferCacheStore getBufferCacheStore() {
/*  7592 */     if (this.useThreadLocalBufferCache) {
/*  7593 */       if (threadLocalBufferCacheStore == null) {
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */         
/*  7606 */         BufferCacheStore.MAX_CACHED_BUFFER_SIZE = this.maxCachedBufferSize;
/*  7607 */         threadLocalBufferCacheStore = new ThreadLocal<BufferCacheStore>()
/*       */           {
/*       */             protected PhysicalConnection.BufferCacheStore initialValue()
/*       */             {
/*  7611 */               return new PhysicalConnection.BufferCacheStore();
/*       */             }
/*       */           };
/*       */       } 
/*  7615 */       return threadLocalBufferCacheStore.get();
/*       */     } 
/*       */     
/*  7618 */     if (this.connectionBufferCacheStore == null)
/*       */     {
/*  7620 */       this.connectionBufferCacheStore = new BufferCacheStore(this.maxCachedBufferSize);
/*       */     }
/*  7622 */     return this.connectionBufferCacheStore;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cacheBuffer(byte[] paramArrayOfbyte) {
/*  7633 */     if (paramArrayOfbyte != null) {
/*  7634 */       BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7635 */       bufferCacheStore.byteBufferCache.put(paramArrayOfbyte);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void cacheBuffer(char[] paramArrayOfchar) {
/*  7647 */     if (paramArrayOfchar != null) {
/*  7648 */       BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7649 */       bufferCacheStore.charBufferCache.put(paramArrayOfchar);
/*       */     } 
/*       */   }
/*       */ 
/*       */   
/*       */   public void cacheBufferSync(char[] paramArrayOfchar) {
/*  7655 */     synchronized (this) {
/*  7656 */       cacheBuffer(paramArrayOfchar);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   byte[] getByteBuffer(int paramInt) {
/*  7668 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7669 */     return bufferCacheStore.byteBufferCache.get(byte.class, paramInt);
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   char[] getCharBuffer(int paramInt) {
/*  7681 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7682 */     return bufferCacheStore.charBufferCache.get(char.class, paramInt);
/*       */   }
/*       */ 
/*       */   
/*       */   public char[] getCharBufferSync(int paramInt) {
/*  7687 */     synchronized (this) {
/*  7688 */       return getCharBuffer(paramInt);
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnection.BufferCacheStatistics getByteBufferCacheStatistics() {
/*  7699 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7700 */     return bufferCacheStore.byteBufferCache.getStatistics();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public OracleConnection.BufferCacheStatistics getCharBufferCacheStatistics() {
/*  7711 */     BufferCacheStore bufferCacheStore = getBufferCacheStore();
/*  7712 */     return bufferCacheStore.charBufferCache.getStatistics();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerTAFCallback(OracleOCIFailover paramOracleOCIFailover, Object paramObject) throws SQLException {
/*  7735 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/*  7736 */     sQLException.fillInStackTrace();
/*  7737 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public String getDatabaseProductVersion() throws SQLException {
/*  7750 */     if (this.databaseProductVersion == "") {
/*       */       
/*  7752 */       needLine();
/*       */       
/*  7754 */       this.databaseProductVersion = doGetDatabaseProductVersion();
/*       */     } 
/*       */     
/*  7757 */     return this.databaseProductVersion;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized boolean getReportRemarks() {
/*  7764 */     return this.reportRemarks;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public short getVersionNumber() throws SQLException {
/*  7771 */     if (this.versionNumber == -1)
/*       */     {
/*  7773 */       synchronized (this) {
/*       */         
/*  7775 */         if (this.versionNumber == -1) {
/*       */           
/*  7777 */           needLine();
/*       */           
/*  7779 */           this.versionNumber = doGetVersionNumber();
/*       */         } 
/*       */       } 
/*       */     }
/*       */     
/*  7784 */     return this.versionNumber;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void registerCloseCallback(OracleCloseCallback paramOracleCloseCallback, Object paramObject) {
/*  7792 */     this.closeCallback = paramOracleCloseCallback;
/*  7793 */     this.privateData = paramObject;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setCreateStatementAsRefCursor(boolean paramBoolean) {}
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean getCreateStatementAsRefCursor() {
/*  7841 */     return false;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int pingDatabase() throws SQLException {
/*  7852 */     if (this.lifecycle != 1)
/*  7853 */       return -1; 
/*  7854 */     return doPingDatabase();
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public int pingDatabase(int paramInt) throws SQLException {
/*  7867 */     if (this.lifecycle != 1)
/*  7868 */       return -1; 
/*  7869 */     if (paramInt == 0) {
/*  7870 */       return pingDatabase();
/*       */     }
/*       */     
/*       */     try {
/*  7874 */       this.pingResult = -2;
/*  7875 */       Thread thread = new Thread(new Runnable() {
/*       */             public void run() {
/*       */               try {
/*  7878 */                 PhysicalConnection.this.pingResult = PhysicalConnection.this.doPingDatabase();
/*       */               }
/*  7880 */               catch (Throwable throwable) {}
/*       */             }
/*       */           });
/*  7883 */       thread.start();
/*  7884 */       thread.join((paramInt * 1000));
/*  7885 */       return this.pingResult;
/*       */     }
/*  7887 */     catch (InterruptedException interruptedException) {
/*  7888 */       return -3;
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   int doPingDatabase() throws SQLException {
/*  7897 */     Statement statement = null;
/*       */ 
/*       */     
/*       */     try {
/*  7901 */       statement = createStatement();
/*       */       
/*  7903 */       ((OracleStatement)statement).defineColumnType(1, 12, 1);
/*  7904 */       statement.executeQuery("SELECT 'x' FROM DUAL");
/*       */     }
/*  7906 */     catch (SQLException sQLException) {
/*       */       
/*  7908 */       return -1;
/*       */     }
/*       */     finally {
/*       */       
/*  7912 */       if (statement != null) {
/*  7913 */         statement.close();
/*       */       }
/*       */     } 
/*  7916 */     return 0;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized Map getJavaObjectTypeMap() {
/*  7932 */     return this.javaObjectMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public synchronized void setJavaObjectTypeMap(Map paramMap) {
/*  7942 */     this.javaObjectMap = paramMap;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void clearClientIdentifier(String paramString) throws SQLException {
/*  7957 */     if (paramString != null && paramString.length() != 0) {
/*       */ 
/*       */ 
/*       */       
/*  7961 */       String[] arrayOfString = getEndToEndMetrics();
/*       */       
/*  7963 */       if (arrayOfString != null && paramString.equals(arrayOfString[1])) {
/*       */ 
/*       */         
/*  7966 */         arrayOfString[1] = null;
/*       */         
/*  7968 */         setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
/*       */       } 
/*       */     } 
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public void setClientIdentifier(String paramString) throws SQLException {
/*  7990 */     String[] arrayOfString = getEndToEndMetrics();
/*       */     
/*  7992 */     if (arrayOfString == null)
/*       */     {
/*  7994 */       arrayOfString = new String[4];
/*       */     }
/*       */ 
/*       */     
/*  7998 */     arrayOfString[1] = paramString;
/*       */     
/*  8000 */     setEndToEndMetrics(arrayOfString, getEndToEndECIDSequenceNumber());
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   protected PhysicalConnection()
/*       */   {
/*  8012 */     this.sessionTimeZone = null;
/*  8013 */     this.databaseTimeZone = null;
/*  8014 */     this.dbTzCalendar = null;
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */     
/* 10964 */     this.timeZoneVersionNumber = -1;
/* 10965 */     this.timeZoneTab = null; this.cancelInProgressLockForThin = new Object(); } public void setSessionTimeZone(String paramString) throws SQLException { Statement statement = null; Object object = null; try { statement = createStatement(); statement.executeUpdate("ALTER SESSION SET TIME_ZONE = '" + paramString + "'"); if (this.dbTzCalendar == null) setDbTzCalendar(getDatabaseTimeZone());  } catch (SQLException sQLException) { throw sQLException; } finally { if (statement != null) statement.close();  }  this.sessionTimeZone = paramString; } public String getDatabaseTimeZone() throws SQLException { if (this.databaseTimeZone == null) this.databaseTimeZone = getPropertyFromDatabase("SELECT DBTIMEZONE FROM DUAL");  return this.databaseTimeZone; } public String getSessionTimeZone() { return this.sessionTimeZone; } private static String to2DigitString(int paramInt) { String str; if (paramInt < 10) { str = "0" + paramInt; } else { str = "" + paramInt; }  return str; } public String tzToOffset(String paramString) { if (paramString == null) return paramString;  char c = paramString.charAt(0); if (c != '-' && c != '+') { TimeZone timeZone = TimeZone.getTimeZone(paramString); int i = timeZone.getOffset(System.currentTimeMillis()); if (i != 0) { int j = i / 60000; int k = j / 60; j -= k * 60; if (i > 0) { paramString = "+" + to2DigitString(k) + ":" + to2DigitString(j); } else { paramString = "-" + to2DigitString(-k) + ":" + to2DigitString(-j); }  } else { paramString = "+00:00"; }  }  return paramString; } public String getSessionTimeZoneOffset() throws SQLException { String str = getPropertyFromDatabase("SELECT SESSIONTIMEZONE FROM DUAL"); if (str != null) str = tzToOffset(str.trim());  return str; } private void setDbTzCalendar(String paramString) { char c = paramString.charAt(0); if (c == '-' || c == '+') paramString = "GMT" + paramString;  TimeZone timeZone = TimeZone.getTimeZone(paramString); this.dbTzCalendar = new GregorianCalendar(timeZone); } public Calendar getDbTzCalendar() throws SQLException { if (this.dbTzCalendar == null) setDbTzCalendar(getDatabaseTimeZone());  return this.dbTzCalendar; } public void setAccumulateBatchResult(boolean paramBoolean) { this.accumulateBatchResult = paramBoolean; } public boolean isAccumulateBatchResult() { return this.accumulateBatchResult; } public void setJ2EE13Compliant(boolean paramBoolean) { this.j2ee13Compliant = paramBoolean; } public boolean getJ2EE13Compliant() { return this.j2ee13Compliant; } public Class classForNameAndSchema(String paramString1, String paramString2) throws ClassNotFoundException { return Class.forName(paramString1); } public Class safelyGetClassForName(String paramString) throws ClassNotFoundException { return Class.forName(paramString); } public int getHeapAllocSize() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException1.fillInStackTrace(); throw sQLException1; }  SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public int getOCIEnvHeapAllocSize() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException1.fillInStackTrace(); throw sQLException1; }  SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public static OracleConnection unwrapCompletely(OracleConnection paramOracleConnection) { OracleConnection oracleConnection1 = paramOracleConnection; OracleConnection oracleConnection2 = oracleConnection1; while (true) { if (oracleConnection2 == null) return (OracleConnection)oracleConnection1;  oracleConnection1 = oracleConnection2; oracleConnection2 = oracleConnection1.unwrap(); }  } public void setWrapper(OracleConnection paramOracleConnection) { this.wrapper = paramOracleConnection; } public OracleConnection unwrap() { return null; } public OracleConnection getWrapper() { if (this.wrapper != null) return this.wrapper;  return (OracleConnection)this; } static OracleConnection _physicalConnectionWithin(Connection paramConnection) { OracleConnection oracleConnection = null; if (paramConnection != null) oracleConnection = unwrapCompletely((OracleConnection)paramConnection);  return oracleConnection; } public OracleConnection physicalConnectionWithin() { return this; } public long getTdoCState(String paramString1, String paramString2) throws SQLException { return 0L; } public void getOracleTypeADT(OracleTypeADT paramOracleTypeADT) throws SQLException {} public Datum toDatum(CustomDatum paramCustomDatum) throws SQLException { return paramCustomDatum.toDatum(this); } public short getNCharSet() { return this.conversion.getNCharSetId(); } public ResultSet newArrayDataResultSet(Datum[] paramArrayOfDatum, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayDataResultSet(this, paramArrayOfDatum, paramLong, paramInt, paramMap); } public ResultSet newArrayDataResultSet(ARRAY paramARRAY, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayDataResultSet(this, paramARRAY, paramLong, paramInt, paramMap); } public ResultSet newArrayLocatorResultSet(ArrayDescriptor paramArrayDescriptor, byte[] paramArrayOfbyte, long paramLong, int paramInt, Map paramMap) throws SQLException { return (ResultSet)new ArrayLocatorResultSet(this, paramArrayDescriptor, paramArrayOfbyte, paramLong, paramInt, paramMap); } public ResultSetMetaData newStructMetaData(StructDescriptor paramStructDescriptor) throws SQLException { return (ResultSetMetaData)new StructMetaData(paramStructDescriptor); } public int CHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException { int[] arrayOfInt = new int[1]; arrayOfInt[0] = paramInt; return this.conversion.CHARBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, arrayOfInt, paramArrayOfchar.length); } public int NCHARBytesToJavaChars(byte[] paramArrayOfbyte, int paramInt, char[] paramArrayOfchar) throws SQLException { int[] arrayOfInt = new int[1]; return this.conversion.NCHARBytesToJavaChars(paramArrayOfbyte, 0, paramArrayOfchar, 0, arrayOfInt, paramArrayOfchar.length); } public boolean IsNCharFixedWith() { return this.conversion.IsNCharFixedWith(); } public short getDriverCharSet() { return this.conversion.getClientCharSet(); } public int getMaxCharSize() throws SQLException { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 58); sQLException.fillInStackTrace(); throw sQLException; } public int getMaxCharbyteSize() { return this.conversion.getMaxCharbyteSize(); } public int getMaxNCharbyteSize() { return this.conversion.getMaxNCharbyteSize(); } PhysicalConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException { this.sessionTimeZone = null; this.databaseTimeZone = null; this.dbTzCalendar = null; this.timeZoneVersionNumber = -1; this.timeZoneTab = null; this.cancelInProgressLockForThin = new Object(); readConnectionProperties(paramString, paramProperties); this.driverExtension = paramOracleDriverExtension; initialize((Hashtable)null, (Map)null, (Map)null); this.logicalConnectionAttached = null; try { needLine(); logon(); setAutoCommit(this.autocommit); if (getVersionNumber() >= 11202) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 4000; this.maxRawBytesPlsql = 32766; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32766; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 64; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 64; } else if (getVersionNumber() >= 11000) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 4000; this.maxRawBytesPlsql = 32766; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32766; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else if (getVersionNumber() >= 10000) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 32512; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32512; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else if (getVersionNumber() >= 9200) { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 32512; this.maxVcsCharsSql = 32766; this.maxVcsNCharsSql = 32766; this.maxVcsBytesPlsql = 32512; this.maxIbtVarcharElementLength = 32766; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; } else { this.minVcsBindSize = 4001; this.maxRawBytesSql = 2000; this.maxRawBytesPlsql = 2000; this.maxVcsCharsSql = 4000; this.maxVcsNCharsSql = 4000; this.maxVcsBytesPlsql = 4000; this.maxIbtVarcharElementLength = 4000; this.endToEndMaxLength[0] = 32; this.endToEndMaxLength[1] = 64; this.endToEndMaxLength[2] = 64; this.endToEndMaxLength[3] = 48; }  if (getVersionNumber() >= 10000) this.retainV9BindBehavior = false;  initializeSetCHARCharSetObjs(); if (this.implicitStatementCacheSize > 0) { setStatementCacheSize(this.implicitStatementCacheSize); setImplicitCachingEnabled(true); }  } catch (SQLException sQLException) { this.lifecycle = 2; try { logoff(); } catch (SQLException sQLException1) {} this.lifecycle = 4; throw sQLException; }  this.txnMode = 0; }
/*       */   public boolean isCharSetMultibyte(short paramShort) { return DBConversion.isCharSetMultibyte(paramShort); }
/*       */   public int javaCharsToCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException { return this.conversion.javaCharsToCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte); }
/*       */   public int javaCharsToNCHARBytes(char[] paramArrayOfchar, int paramInt, byte[] paramArrayOfbyte) throws SQLException { return this.conversion.javaCharsToNCHARBytes(paramArrayOfchar, paramInt, paramArrayOfbyte); }
/* 10969 */   final void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection, String paramString) throws SQLException { Hashtable<Object, Object> hashtable = new Hashtable<Object, Object>(); hashtable.put("obj_type_map", this.javaObjectMap); Properties properties = new Properties(); properties.put("user", this.userName); properties.put("password", paramString); properties.put("connection_url", this.url); properties.put("connect_auto_commit", "" + this.autocommit); properties.put("trans_isolation", "" + this.txnLevel); if (getStatementCacheSize() != -1) { properties.put("stmt_cache_size", "" + getStatementCacheSize()); properties.put("implicit_cache_enabled", "" + getImplicitCachingEnabled()); properties.put("explict_cache_enabled", "" + getExplicitCachingEnabled()); }  properties.put("defaultExecuteBatch", "" + this.defaultExecuteBatch); properties.put("defaultRowPrefetch", "" + this.defaultRowPrefetch); properties.put("remarksReporting", "" + this.reportRemarks); properties.put("AccumulateBatchResult", "" + this.accumulateBatchResult); properties.put("oracle.jdbc.J2EE13Compliant", "" + this.j2ee13Compliant); properties.put("processEscapes", "" + this.processEscapes); properties.put("restrictGetTables", "" + this.restrictGettables); properties.put("includeSynonyms", "" + this.includeSynonyms); properties.put("fixedString", "" + this.fixedString); hashtable.put("connection_properties", properties); paramOraclePooledConnection.setProperties(hashtable); } public Properties getDBAccessProperties() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Properties getOCIHandles() throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } void logoff() throws SQLException {} int getDefaultStreamChunkSize() { return this.streamChunkSize; } public OracleStatement refCursorCursorToStatement(int paramInt) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Connection getLogicalConnection(OraclePooledConnection paramOraclePooledConnection, boolean paramBoolean) throws SQLException { if (this.logicalConnectionAttached != null || paramOraclePooledConnection.getPhysicalHandle() != this) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 143); sQLException.fillInStackTrace(); throw sQLException; }  LogicalConnection logicalConnection = new LogicalConnection(paramOraclePooledConnection, this, paramBoolean); this.logicalConnectionAttached = logicalConnection; return (Connection)logicalConnection; } public void getForm(OracleTypeADT paramOracleTypeADT, OracleTypeCLOB paramOracleTypeCLOB, int paramInt) throws SQLException {} public CLOB createClob(byte[] paramArrayOfbyte) throws SQLException { NCLOB nCLOB; CLOB cLOB = new CLOB((OracleConnection)this, paramArrayOfbyte); if (cLOB.isNCLOB()) nCLOB = new NCLOB(cLOB);  return (CLOB)nCLOB; } public CLOB createClobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException { NCLOB nCLOB; CLOB cLOB = new CLOB((OracleConnection)this, paramArrayOfbyte, true); if (cLOB.isNCLOB()) nCLOB = new NCLOB(cLOB);  return (CLOB)nCLOB; } public CLOB createClob(byte[] paramArrayOfbyte, short paramShort) throws SQLException { return new CLOB((OracleConnection)this, paramArrayOfbyte, paramShort); } public BLOB createBlob(byte[] paramArrayOfbyte) throws SQLException { return new BLOB((OracleConnection)this, paramArrayOfbyte); } public BLOB createBlobWithUnpickledBytes(byte[] paramArrayOfbyte) throws SQLException { return new BLOB((OracleConnection)this, paramArrayOfbyte, true); } public BFILE createBfile(byte[] paramArrayOfbyte) throws SQLException { return new BFILE((OracleConnection)this, paramArrayOfbyte); } public ARRAY createARRAY(String paramString, Object paramObject) throws SQLException { ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor(paramString, (Connection)this); return new ARRAY(arrayDescriptor, (Connection)this, paramObject); } public Array createOracleArray(String paramString, Object paramObject) throws SQLException { return (Array)createARRAY(paramString, paramObject); } public BINARY_DOUBLE createBINARY_DOUBLE(double paramDouble) throws SQLException { return new BINARY_DOUBLE(paramDouble); } public BINARY_FLOAT createBINARY_FLOAT(float paramFloat) throws SQLException { return new BINARY_FLOAT(paramFloat); } public DATE createDATE(Date paramDate) throws SQLException { return new DATE(paramDate); } public DATE createDATE(Time paramTime) throws SQLException { return new DATE(paramTime); } public DATE createDATE(Timestamp paramTimestamp) throws SQLException { return new DATE(paramTimestamp); } public DATE createDATE(Date paramDate, Calendar paramCalendar) throws SQLException { return new DATE(paramDate); } public DATE createDATE(Time paramTime, Calendar paramCalendar) throws SQLException { return new DATE(paramTime); } public DATE createDATE(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new DATE(paramTimestamp); } public DATE createDATE(String paramString) throws SQLException { return new DATE(paramString); } public INTERVALDS createINTERVALDS(String paramString) throws SQLException { return new INTERVALDS(paramString); } public INTERVALYM createINTERVALYM(String paramString) throws SQLException { return new INTERVALYM(paramString); } public NUMBER createNUMBER(boolean paramBoolean) throws SQLException { return new NUMBER(paramBoolean); } public NUMBER createNUMBER(byte paramByte) throws SQLException { return new NUMBER(paramByte); } public NUMBER createNUMBER(short paramShort) throws SQLException { return new NUMBER(paramShort); } public NUMBER createNUMBER(int paramInt) throws SQLException { return new NUMBER(paramInt); } public NUMBER createNUMBER(long paramLong) throws SQLException { return new NUMBER(paramLong); } public NUMBER createNUMBER(float paramFloat) throws SQLException { return new NUMBER(paramFloat); } public NUMBER createNUMBER(double paramDouble) throws SQLException { return new NUMBER(paramDouble); } public int getTimezoneVersionNumber() throws SQLException { return this.timeZoneVersionNumber; } public NUMBER createNUMBER(BigDecimal paramBigDecimal) throws SQLException { return new NUMBER(paramBigDecimal); } public NUMBER createNUMBER(BigInteger paramBigInteger) throws SQLException { return new NUMBER(paramBigInteger); } public NUMBER createNUMBER(String paramString, int paramInt) throws SQLException { return new NUMBER(paramString, paramInt); } public Array createArrayOf(String paramString, Object[] paramArrayOfObject) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public Struct createStruct(String paramString, Object[] paramArrayOfObject) throws SQLException { try { StructDescriptor structDescriptor = StructDescriptor.createDescriptor(paramString, (Connection)this); return (Struct)new STRUCT(structDescriptor, (Connection)this, paramArrayOfObject); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 17049) removeAllDescriptor();  throw sQLException; }  } public TIMESTAMP createTIMESTAMP(Date paramDate) throws SQLException { return new TIMESTAMP(paramDate); } public TIMESTAMP createTIMESTAMP(DATE paramDATE) throws SQLException { return new TIMESTAMP(paramDATE); } public TIMESTAMP createTIMESTAMP(Time paramTime) throws SQLException { return new TIMESTAMP(paramTime); } public TIMESTAMP createTIMESTAMP(Timestamp paramTimestamp) throws SQLException { return new TIMESTAMP(paramTimestamp); } public TIMESTAMP createTIMESTAMP(String paramString) throws SQLException { return new TIMESTAMP(paramString); } public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDate); } public TIMESTAMPTZ createTIMESTAMPTZ(Date paramDate, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDate, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTime); } public TIMESTAMPTZ createTIMESTAMPTZ(Time paramTime, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTime, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTimestamp); } public TIMESTAMPTZ createTIMESTAMPTZ(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramTimestamp, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(String paramString) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramString); } public TIMESTAMPTZ createTIMESTAMPTZ(String paramString, Calendar paramCalendar) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramString, paramCalendar); } public TIMESTAMPTZ createTIMESTAMPTZ(DATE paramDATE) throws SQLException { return new TIMESTAMPTZ((Connection)this, paramDATE); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Date paramDate, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramDate); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Time paramTime, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramTime); } public TIMESTAMPLTZ createTIMESTAMPLTZ(Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramTimestamp); } public TIMESTAMPLTZ createTIMESTAMPLTZ(String paramString, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramString); } public TIMESTAMPLTZ createTIMESTAMPLTZ(DATE paramDATE, Calendar paramCalendar) throws SQLException { return new TIMESTAMPLTZ((Connection)this, paramCalendar, paramDATE); } public boolean isDescriptorSharable(OracleConnection paramOracleConnection) throws SQLException { PhysicalConnection physicalConnection1 = this; PhysicalConnection physicalConnection2 = (PhysicalConnection)paramOracleConnection.getPhysicalConnection(); return (physicalConnection1 == physicalConnection2 || physicalConnection1.url.equals(physicalConnection2.url) || (physicalConnection2.protocol != null && physicalConnection2.protocol.equals("kprb"))); } boolean useLittleEndianSetCHARBinder() throws SQLException { return false; } public void setPlsqlWarnings(String paramString) throws SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString != null && (paramString = paramString.trim()).length() > 0 && !OracleSql.isValidPlsqlWarning(paramString)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  String str1 = "ALTER SESSION SET PLSQL_WARNINGS=" + paramString; String str2 = "ALTER SESSION SET EVENTS='10933 TRACE NAME CONTEXT LEVEL 32768'"; Statement statement = null; try { statement = createStatement(-1, -1); statement.execute(str1); if (paramString.equals("'DISABLE:ALL'")) { this.plsqlCompilerWarnings = false; } else { statement.execute(str2); this.plsqlCompilerWarnings = true; }  } finally { if (statement != null) statement.close();  }  } void internalClose() throws SQLException { this.lifecycle = 4; OracleStatement oracleStatement = this.statements; while (oracleStatement != null) { OracleStatement oracleStatement1 = oracleStatement.nextChild; if (oracleStatement.serverCursor) { oracleStatement.internalClose(); removeStatement(oracleStatement); }  oracleStatement = oracleStatement1; }  oracleStatement = this.statements; while (oracleStatement != null) { OracleStatement oracleStatement1 = oracleStatement.next; oracleStatement.internalClose(); oracleStatement = oracleStatement1; }  this.statements = null; }
/*       */   public XAResource getXAResource() throws SQLException { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 164); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void setApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException { if (paramString1 == null || paramString2 == null || paramString3 == null) throw new NullPointerException();  if (paramString1.equals("")) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString1.compareToIgnoreCase("CLIENTCONTEXT") != 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 174); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString2.length() > 30) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 171); sQLException.fillInStackTrace(); throw sQLException; }  if (paramString3.length() > 4000) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 172); sQLException.fillInStackTrace(); throw sQLException; }  doSetApplicationContext(paramString1, paramString2, paramString3); }
/*       */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void clearAllApplicationContext(String paramString) throws SQLException { if (paramString == null) throw new NullPointerException();  if (paramString.equals("")) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 170); sQLException.fillInStackTrace(); throw sQLException; }  doClearAllApplicationContext(paramString); }
/*       */   void doClearAllApplicationContext(String paramString) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/* 10979 */   public TIMEZONETAB getTIMEZONETAB() throws SQLException { if (this.timeZoneTab == null) {
/* 10980 */       this.timeZoneTab = TIMEZONETAB.getInstance(getTimezoneVersionNumber());
/*       */     }
/* 10982 */     return this.timeZoneTab; } public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void enqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessage paramAQMessage) throws SQLException { AQMessageI aQMessageI = (AQMessageI)paramAQMessage; byte[][] arrayOfByte = new byte[1][]; doEnqueue(paramString, paramAQEnqueueOptions, aQMessageI.getMessagePropertiesI(), aQMessageI.getPayloadTOID(), aQMessageI.getPayload(), arrayOfByte, aQMessageI.isRAWPayload()); if (arrayOfByte[0] != null) aQMessageI.setMessageId(arrayOfByte[0]);  } public AQMessage dequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, byte[] paramArrayOfbyte) throws SQLException { byte[][] arrayOfByte1 = new byte[1][]; AQMessagePropertiesI aQMessagePropertiesI = new AQMessagePropertiesI(); byte[][] arrayOfByte2 = new byte[1][]; boolean bool = false; bool = doDequeue(paramString, paramAQDequeueOptions, aQMessagePropertiesI, paramArrayOfbyte, arrayOfByte2, arrayOfByte1, AQMessageI.compareToid(paramArrayOfbyte, TypeDescriptor.RAWTOID)); AQMessageI aQMessageI = null; if (bool) { aQMessageI = new AQMessageI(aQMessagePropertiesI, (Connection)this); aQMessageI.setPayload(arrayOfByte2[0], paramArrayOfbyte); aQMessageI.setMessageId(arrayOfByte1[0]); }  return aQMessageI; } public AQMessage dequeue(String paramString1, AQDequeueOptions paramAQDequeueOptions, String paramString2) throws SQLException { byte[] arrayOfByte = null; TypeDescriptor typeDescriptor = null; if ("RAW".equals(paramString2) || "SYS.RAW".equals(paramString2)) { arrayOfByte = TypeDescriptor.RAWTOID; } else if ("SYS.ANYDATA".equals(paramString2)) { arrayOfByte = TypeDescriptor.ANYDATATOID; } else if ("SYS.XMLTYPE".equals(paramString2)) { arrayOfByte = TypeDescriptor.XMLTYPETOID; } else { typeDescriptor = TypeDescriptor.getTypeDescriptor(paramString2, (OracleConnection)this); arrayOfByte = ((OracleTypeADT)typeDescriptor.getPickler()).getTOID(); }  AQMessageI aQMessageI = (AQMessageI)dequeue(paramString1, paramAQDequeueOptions, arrayOfByte); if (aQMessageI != null) { aQMessageI.setTypeName(paramString2); aQMessageI.setTypeDescriptor(typeDescriptor); }  return aQMessageI; } synchronized void doEnqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } synchronized boolean doDequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, boolean paramBoolean) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public boolean isV8Compatible() throws SQLException { return this.mapDateToTimestamp; } public boolean getMapDateToTimestamp() { return this.mapDateToTimestamp; } public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public AQNotificationRegistration[] registerAQNotification(String[] paramArrayOfString, Properties[] paramArrayOfProperties, Properties paramProperties) throws SQLException { String str = readNTFlocalhost(paramProperties); int i = readNTFtcpport(paramProperties); NTFAQRegistration[] arrayOfNTFAQRegistration = doRegisterAQNotification(paramArrayOfString, str, i, paramArrayOfProperties); return (AQNotificationRegistration[])arrayOfNTFAQRegistration; } NTFAQRegistration[] doRegisterAQNotification(String[] paramArrayOfString, String paramString, int paramInt, Properties[] paramArrayOfProperties) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void unregisterAQNotification(AQNotificationRegistration paramAQNotificationRegistration) throws SQLException { NTFAQRegistration nTFAQRegistration = (NTFAQRegistration)paramAQNotificationRegistration; doUnregisterAQNotification(nTFAQRegistration); } void doUnregisterAQNotification(NTFAQRegistration paramNTFAQRegistration) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } private String readNTFlocalhost(Properties paramProperties) throws SQLException { String str = null; try { str = paramProperties.getProperty("NTF_LOCAL_HOST", InetAddress.getLocalHost().getHostAddress()); } catch (UnknownHostException unknownHostException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 240); sQLException.fillInStackTrace(); throw sQLException; } catch (SecurityException securityException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 241); sQLException.fillInStackTrace(); throw sQLException; }  return str; } private int readNTFtcpport(Properties paramProperties) throws SQLException { int i = 0; try { i = Integer.parseInt(paramProperties.getProperty("NTF_LOCAL_TCP_PORT", "0")); if (i < 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242); sQLException.fillInStackTrace(); throw sQLException; }  } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 242); sQLException.fillInStackTrace(); throw sQLException; }  return i; } int readNTFtimeout(Properties paramProperties) throws SQLException { int i = 0; try { i = Integer.parseInt(paramProperties.getProperty("NTF_TIMEOUT", "0")); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 243); sQLException.fillInStackTrace(); throw sQLException; }  return i; } public DatabaseChangeRegistration registerDatabaseChangeNotification(Properties paramProperties) throws SQLException { String str = readNTFlocalhost(paramProperties); int i = readNTFtcpport(paramProperties); int j = readNTFtimeout(paramProperties); int k = 0; try { k = Integer.parseInt(paramProperties.getProperty("DCN_NOTIFY_CHANGELAG", "0")); } catch (NumberFormatException numberFormatException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 244); sQLException.fillInStackTrace(); throw sQLException; }  NTFDCNRegistration nTFDCNRegistration = doRegisterDatabaseChangeNotification(str, i, paramProperties, j, k); ntfManager.addRegistration(nTFDCNRegistration); return nTFDCNRegistration; } NTFDCNRegistration doRegisterDatabaseChangeNotification(String paramString, int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public DatabaseChangeRegistration getDatabaseChangeRegistration(int paramInt) throws SQLException { return new NTFDCNRegistration(this.instanceName, paramInt, this.userName, this.versionNumber); } public void unregisterDatabaseChangeNotification(DatabaseChangeRegistration paramDatabaseChangeRegistration) throws SQLException { NTFDCNRegistration nTFDCNRegistration = (NTFDCNRegistration)paramDatabaseChangeRegistration; if (nTFDCNRegistration.getDatabaseName().compareToIgnoreCase(this.instanceName) != 0) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 245); sQLException.fillInStackTrace(); throw sQLException; }  doUnregisterDatabaseChangeNotification(nTFDCNRegistration); } void doUnregisterDatabaseChangeNotification(NTFDCNRegistration paramNTFDCNRegistration) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; } public void unregisterDatabaseChangeNotification(int paramInt) throws SQLException { String str = null; try { str = InetAddress.getLocalHost().getHostAddress(); } catch (Exception exception) {} unregisterDatabaseChangeNotification(paramInt, str, 47632); } public void unregisterDatabaseChangeNotification(int paramInt1, String paramString, int paramInt2) throws SQLException { String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt2 + "))?PR=0"; unregisterDatabaseChangeNotification(paramInt1, str); } public void unregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException { doUnregisterDatabaseChangeNotification(paramLong, paramString); }
/*       */   void doUnregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }
/*       */   public TypeDescriptor[] getAllTypeDescriptorsInCurrentSchema() throws SQLException { TypeDescriptor[] arrayOfTypeDescriptor = null; Statement statement = null; try { statement = createStatement(); ResultSet resultSet = statement.executeQuery("SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info())"); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (statement != null) statement.close();  }  return arrayOfTypeDescriptor; }
/*       */   public TypeDescriptor[] getTypeDescriptorsFromListInCurrentSchema(String[] paramArrayOfString) throws SQLException { String str = "SELECT schema_name, typename, typoid, typecode, version, tds  FROM TABLE(private_jdbc.Get_Type_Shape_Info(?))"; TypeDescriptor[] arrayOfTypeDescriptor = null; PreparedStatement preparedStatement = null; try { preparedStatement = prepareStatement(str); int i = paramArrayOfString.length; StringBuffer stringBuffer = new StringBuffer(i * 8); for (byte b = 0; b < i; b++) { stringBuffer.append(paramArrayOfString[b]); if (b < i - 1) stringBuffer.append(',');  }  preparedStatement.setString(1, stringBuffer.toString()); ResultSet resultSet = preparedStatement.executeQuery(); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (preparedStatement != null) preparedStatement.close();  }  return arrayOfTypeDescriptor; }
/*       */   public TypeDescriptor[] getTypeDescriptorsFromList(String[][] paramArrayOfString) throws SQLException { TypeDescriptor[] arrayOfTypeDescriptor = null; PreparedStatement preparedStatement = null; int i = paramArrayOfString.length; StringBuffer stringBuffer1 = new StringBuffer(i * 8); StringBuffer stringBuffer2 = new StringBuffer(i * 8); for (byte b = 0; b < i; b++) { stringBuffer1.append(paramArrayOfString[b][0]); stringBuffer2.append(paramArrayOfString[b][1]); if (b < i - 1) { stringBuffer1.append(','); stringBuffer2.append(','); }  }  try { String str = "SELECT schema_name, typename, typoid, typecode, version, tds FROM TABLE(private_jdbc.Get_All_Type_Shape_Info(?,?))"; preparedStatement = prepareStatement(str); preparedStatement.setString(1, stringBuffer1.toString()); preparedStatement.setString(2, stringBuffer2.toString()); ResultSet resultSet = preparedStatement.executeQuery(); arrayOfTypeDescriptor = getTypeDescriptorsFromResultSet(resultSet); resultSet.close(); } catch (SQLException sQLException) { if (sQLException.getErrorCode() == 904) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 165); sQLException1.fillInStackTrace(); throw sQLException1; }  throw sQLException; } finally { if (preparedStatement != null) preparedStatement.close();  }  return arrayOfTypeDescriptor; }
/*       */   TypeDescriptor[] getTypeDescriptorsFromResultSet(ResultSet paramResultSet) throws SQLException { ArrayList<StructDescriptor> arrayList = new ArrayList(); while (paramResultSet.next()) { String str1 = paramResultSet.getString(1); String str2 = paramResultSet.getString(2); byte[] arrayOfByte1 = paramResultSet.getBytes(3); String str3 = paramResultSet.getString(4); int i = paramResultSet.getInt(5); byte[] arrayOfByte2 = paramResultSet.getBytes(6); SQLName sQLName = new SQLName(str1, str2, (OracleConnection)this); if (str3.equals("OBJECT")) { StructDescriptor structDescriptor = StructDescriptor.createDescriptor(sQLName, arrayOfByte1, i, arrayOfByte2, this); putDescriptor(arrayOfByte1, structDescriptor); putDescriptor(structDescriptor.getName(), structDescriptor); arrayList.add(structDescriptor); continue; }  if (str3.equals("COLLECTION")) { ArrayDescriptor arrayDescriptor = ArrayDescriptor.createDescriptor(sQLName, arrayOfByte1, i, arrayOfByte2, this); putDescriptor(arrayOfByte1, arrayDescriptor); putDescriptor(arrayDescriptor.getName(), arrayDescriptor); arrayList.add(arrayDescriptor); }  }  TypeDescriptor[] arrayOfTypeDescriptor = new TypeDescriptor[arrayList.size()]; for (byte b = 0; b < arrayList.size(); b++) { TypeDescriptor typeDescriptor = (TypeDescriptor)arrayList.get(b); arrayOfTypeDescriptor[b] = typeDescriptor; }  return arrayOfTypeDescriptor; }
/*       */   public synchronized boolean isUsable() { return this.isUsable; }
/*       */   public void setUsable(boolean paramBoolean) { this.isUsable = paramBoolean; }
/*       */   void queryFCFProperties(Properties paramProperties) throws SQLException { Statement statement = null; ResultSet resultSet = null; String str = "select sys_context('userenv', 'instance_name'),sys_context('userenv', 'server_host'),sys_context('userenv', 'service_name'),sys_context('userenv', 'db_unique_name') from dual"; try { statement = createStatement(); statement.setFetchSize(1); resultSet = statement.executeQuery(str); while (resultSet.next()) { String str1 = null; str1 = resultSet.getString(1); if (str1 != null) paramProperties.put("INSTANCE_NAME", str1.trim());  str1 = resultSet.getString(2); if (str1 != null) paramProperties.put("SERVER_HOST", str1.trim());  str1 = resultSet.getString(3); if (str1 != null) paramProperties.put("SERVICE_NAME", str1.trim());  str1 = resultSet.getString(4); if (str1 != null) paramProperties.put("DATABASE_NAME", str1.trim());  }  } finally { if (resultSet != null) resultSet.close();  if (statement != null) statement.close();  }  }
/*       */   public void setDefaultTimeZone(TimeZone paramTimeZone) throws SQLException { this.defaultTimeZone = paramTimeZone; }
/*       */   public TimeZone getDefaultTimeZone() throws SQLException { return this.defaultTimeZone; }
/* 10996 */   public boolean isDataInLocatorEnabled() throws SQLException { return ((getVersionNumber() >= 10200)) & ((getVersionNumber() < 11000)) & this.enableReadDataInLocator | this.overrideEnableReadDataInLocator; }
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean isLobStreamPosStandardCompliant() throws SQLException {
/* 11005 */     return this.lobStreamPosStandardCompliant;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public long getCurrentSCN() throws SQLException {
/* 11012 */     return doGetCurrentSCN();
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   long doGetCurrentSCN() throws SQLException {
/* 11018 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11019 */     sQLException.fillInStackTrace();
/* 11020 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   void doSetSnapshotSCN(long paramLong) throws SQLException {
/* 11027 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11028 */     sQLException.fillInStackTrace();
/* 11029 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   public EnumSet<OracleConnection.TransactionState> getTransactionState() throws SQLException {
/* 11035 */     return doGetTransactionState();
/*       */   }
/*       */ 
/*       */ 
/*       */   
/*       */   EnumSet<OracleConnection.TransactionState> doGetTransactionState() throws SQLException {
/* 11041 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11042 */     sQLException.fillInStackTrace();
/* 11043 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */ 
/*       */   
/*       */   public boolean isConnectionSocketKeepAlive() throws SocketException, SQLException {
/* 11050 */     SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException();
/* 11051 */     sQLException.fillInStackTrace();
/* 11052 */     throw sQLException;
/*       */   }
/*       */ 
/*       */ 
/*       */   
/* 11057 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*       */   public static final boolean TRACE = false;
/*       */   
/*       */   abstract void initializePassword(String paramString) throws SQLException;
/*       */   
/*       */   abstract void doAbort() throws SQLException;
/*       */   
/*       */   public abstract void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException;
/*       */   
/*       */   abstract void logon() throws SQLException;
/*       */   
/*       */   abstract void open(OracleStatement paramOracleStatement) throws SQLException;
/*       */   
/*       */   abstract void cancelOperationOnServer(boolean paramBoolean) throws SQLException;
/*       */   
/*       */   abstract void doSetAutoCommit(boolean paramBoolean) throws SQLException;
/*       */   
/*       */   abstract void doCommit(int paramInt) throws SQLException;
/*       */   
/*       */   abstract void doRollback() throws SQLException;
/*       */   
/*       */   abstract String doGetDatabaseProductVersion() throws SQLException;
/*       */   
/*       */   abstract short doGetVersionNumber() throws SQLException;
/*       */   
/*       */   abstract OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException;
/*       */   
/*       */   public abstract BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException;
/*       */   
/*       */   public abstract CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException;
/*       */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/PhysicalConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */