package oracle.jdbc.driver;

import oracle.jdbc.internal.OracleConnection;

public interface OracleCloseCallback {
  void beforeClose(OracleConnection paramOracleConnection, Object paramObject);
  
  void afterClose(Object paramObject);
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/OracleCloseCallback.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */