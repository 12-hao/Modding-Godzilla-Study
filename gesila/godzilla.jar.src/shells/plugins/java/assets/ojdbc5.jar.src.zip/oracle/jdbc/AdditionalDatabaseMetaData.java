package oracle.jdbc;

import java.sql.DatabaseMetaData;
import java.sql.SQLException;

public interface AdditionalDatabaseMetaData extends DatabaseMetaData {
  OracleTypeMetaData getOracleTypeMetaData(String paramString) throws SQLException;
  
  long getLobMaxLength() throws SQLException;
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/AdditionalDatabaseMetaData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */