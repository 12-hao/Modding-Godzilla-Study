/*     */ package oracle.jdbc.driver;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Date;
/*     */ import java.sql.Ref;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import oracle.sql.ARRAY;
/*     */ import oracle.sql.BFILE;
/*     */ import oracle.sql.BINARY_FLOAT;
/*     */ import oracle.sql.BLOB;
/*     */ import oracle.sql.CLOB;
/*     */ import oracle.sql.DATE;
/*     */ import oracle.sql.Datum;
/*     */ import oracle.sql.INTERVALDS;
/*     */ import oracle.sql.NUMBER;
/*     */ import oracle.sql.OPAQUE;
/*     */ import oracle.sql.ORAData;
/*     */ import oracle.sql.REF;
/*     */ import oracle.sql.STRUCT;
/*     */ import oracle.sql.TIMESTAMP;
/*     */ import oracle.sql.TIMESTAMPTZ;
/*     */ 
/*     */ abstract class BaseResultSet extends OracleResultSet {
/*  33 */   SQLWarning sqlWarning = null;
/*     */ 
/*     */ 
/*     */   
/*     */   boolean autoRefetch = true;
/*     */ 
/*     */   
/*     */   boolean closed = false;
/*     */ 
/*     */   
/*     */   boolean close_statement_on_close = false;
/*     */ 
/*     */ 
/*     */   
/*     */   public void closeStatementOnClose() {
/*  48 */     this.close_statement_on_close = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void beforeFirst() throws SQLException {
/*  64 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "beforeFirst");
/*  65 */     sQLException.fillInStackTrace();
/*  66 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void afterLast() throws SQLException {
/*  75 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "afterLast");
/*  76 */     sQLException.fillInStackTrace();
/*  77 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean first() throws SQLException {
/*  86 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "first");
/*  87 */     sQLException.fillInStackTrace();
/*  88 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean last() throws SQLException {
/*  97 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "last");
/*  98 */     sQLException.fillInStackTrace();
/*  99 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean absolute(int paramInt) throws SQLException {
/* 108 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "absolute");
/* 109 */     sQLException.fillInStackTrace();
/* 110 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean relative(int paramInt) throws SQLException {
/* 119 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "relative");
/* 120 */     sQLException.fillInStackTrace();
/* 121 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean previous() throws SQLException {
/* 130 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "previous");
/* 131 */     sQLException.fillInStackTrace();
/* 132 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFetchDirection(int paramInt) throws SQLException {
/* 146 */     if (paramInt == 1000)
/*     */       return; 
/* 148 */     if (paramInt == 1001 || paramInt == 1002) {
/*     */       
/* 150 */       SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 75, "setFetchDirection(FETCH_REVERSE, FETCH_UNKNOWN)");
/* 151 */       sQLException1.fillInStackTrace();
/* 152 */       throw sQLException1;
/*     */     } 
/*     */ 
/*     */     
/* 156 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setFetchDirection");
/* 157 */     sQLException.fillInStackTrace();
/* 158 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getFetchDirection() throws SQLException {
/* 166 */     return 1000;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getType() throws SQLException {
/* 173 */     return 1003;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getConcurrency() throws SQLException {
/* 180 */     return 1007;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SQLWarning getWarnings() throws SQLException {
/* 187 */     return this.sqlWarning;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void clearWarnings() throws SQLException {
/* 194 */     this.sqlWarning = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateArray(int paramInt, Array paramArray) throws SQLException {
/* 208 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateArray");
/* 209 */     sQLException.fillInStackTrace();
/* 210 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/* 218 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBigDecimal");
/* 219 */     sQLException.fillInStackTrace();
/* 220 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBlob(int paramInt, Blob paramBlob) throws SQLException {
/* 228 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBlob");
/* 229 */     sQLException.fillInStackTrace();
/* 230 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/* 238 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBoolean");
/* 239 */     sQLException.fillInStackTrace();
/* 240 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateByte(int paramInt, byte paramByte) throws SQLException {
/* 248 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateByte");
/* 249 */     sQLException.fillInStackTrace();
/* 250 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 258 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBytes");
/* 259 */     sQLException.fillInStackTrace();
/* 260 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateClob(int paramInt, Clob paramClob) throws SQLException {
/* 268 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateClob");
/* 269 */     sQLException.fillInStackTrace();
/* 270 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateDate(int paramInt, Date paramDate) throws SQLException {
/* 278 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDate");
/* 279 */     sQLException.fillInStackTrace();
/* 280 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateDate(int paramInt, Date paramDate, Calendar paramCalendar) throws SQLException {
/* 288 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDate");
/* 289 */     sQLException.fillInStackTrace();
/* 290 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateDouble(int paramInt, double paramDouble) throws SQLException {
/* 298 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDouble");
/* 299 */     sQLException.fillInStackTrace();
/* 300 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateFloat(int paramInt, float paramFloat) throws SQLException {
/* 308 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateFloat");
/* 309 */     sQLException.fillInStackTrace();
/* 310 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateInt(int paramInt1, int paramInt2) throws SQLException {
/* 318 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateInt");
/* 319 */     sQLException.fillInStackTrace();
/* 320 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateLong(int paramInt, long paramLong) throws SQLException {
/* 328 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateLong");
/* 329 */     sQLException.fillInStackTrace();
/* 330 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateObject(int paramInt, Object paramObject) throws SQLException {
/* 338 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateObject");
/* 339 */     sQLException.fillInStackTrace();
/* 340 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/* 348 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateObject");
/* 349 */     sQLException.fillInStackTrace();
/* 350 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateRef(int paramInt, Ref paramRef) throws SQLException {
/* 358 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRef");
/* 359 */     sQLException.fillInStackTrace();
/* 360 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateShort(int paramInt, short paramShort) throws SQLException {
/* 368 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateShort");
/* 369 */     sQLException.fillInStackTrace();
/* 370 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateString(int paramInt, String paramString) throws SQLException {
/* 378 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateString");
/* 379 */     sQLException.fillInStackTrace();
/* 380 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTime(int paramInt, Time paramTime) throws SQLException {
/* 388 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTime");
/* 389 */     sQLException.fillInStackTrace();
/* 390 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTime(int paramInt, Time paramTime, Calendar paramCalendar) throws SQLException {
/* 398 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTime");
/* 399 */     sQLException.fillInStackTrace();
/* 400 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/* 408 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTimestamp");
/* 409 */     sQLException.fillInStackTrace();
/* 410 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar) throws SQLException {
/* 418 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTimestamp");
/* 419 */     sQLException.fillInStackTrace();
/* 420 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateURL(int paramInt, URL paramURL) throws SQLException {
/* 428 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateURL");
/* 429 */     sQLException.fillInStackTrace();
/* 430 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
/* 438 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateARRAY");
/* 439 */     sQLException.fillInStackTrace();
/* 440 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
/* 448 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBFILE");
/* 449 */     sQLException.fillInStackTrace();
/* 450 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBfile(int paramInt, BFILE paramBFILE) throws SQLException {
/* 458 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBfile");
/* 459 */     sQLException.fillInStackTrace();
/* 460 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBinaryFloat(int paramInt, float paramFloat) throws SQLException {
/* 468 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryFloat");
/* 469 */     sQLException.fillInStackTrace();
/* 470 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBinaryFloat(int paramInt, BINARY_FLOAT paramBINARY_FLOAT) throws SQLException {
/* 478 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryFloat");
/* 479 */     sQLException.fillInStackTrace();
/* 480 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBinaryDouble(int paramInt, double paramDouble) throws SQLException {
/* 488 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryDouble");
/* 489 */     sQLException.fillInStackTrace();
/* 490 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBinaryDouble(int paramInt, BINARY_DOUBLE paramBINARY_DOUBLE) throws SQLException {
/* 498 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryDouble");
/* 499 */     sQLException.fillInStackTrace();
/* 500 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
/* 508 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBLOB");
/* 509 */     sQLException.fillInStackTrace();
/* 510 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
/* 518 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCHAR");
/* 519 */     sQLException.fillInStackTrace();
/* 520 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
/* 528 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCLOB");
/* 529 */     sQLException.fillInStackTrace();
/* 530 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateCursor(int paramInt, ResultSet paramResultSet) throws SQLException {
/* 538 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCursor");
/* 539 */     sQLException.fillInStackTrace();
/* 540 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
/* 548 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCustomDatum");
/* 549 */     sQLException.fillInStackTrace();
/* 550 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateDATE(int paramInt, DATE paramDATE) throws SQLException {
/* 558 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateDATE");
/* 559 */     sQLException.fillInStackTrace();
/* 560 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateFixedCHAR(int paramInt, String paramString) throws SQLException {
/* 568 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateFixedCHAR");
/* 569 */     sQLException.fillInStackTrace();
/* 570 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
/* 578 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateINTERVALDS");
/* 579 */     sQLException.fillInStackTrace();
/* 580 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
/* 588 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateINTERVALYM");
/* 589 */     sQLException.fillInStackTrace();
/* 590 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
/* 598 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNUMBER");
/* 599 */     sQLException.fillInStackTrace();
/* 600 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
/* 608 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateOPAQUE");
/* 609 */     sQLException.fillInStackTrace();
/* 610 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateOracleObject(int paramInt, Datum paramDatum) throws SQLException {
/* 618 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateOracleObject");
/* 619 */     sQLException.fillInStackTrace();
/* 620 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateORAData(int paramInt, ORAData paramORAData) throws SQLException {
/* 628 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateORAData");
/* 629 */     sQLException.fillInStackTrace();
/* 630 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateRAW(int paramInt, RAW paramRAW) throws SQLException {
/* 638 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRAW");
/* 639 */     sQLException.fillInStackTrace();
/* 640 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateREF(int paramInt, REF paramREF) throws SQLException {
/* 648 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateREF");
/* 649 */     sQLException.fillInStackTrace();
/* 650 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateRefType(int paramInt, REF paramREF) throws SQLException {
/* 658 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRefType");
/* 659 */     sQLException.fillInStackTrace();
/* 660 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateROWID(int paramInt, ROWID paramROWID) throws SQLException {
/* 668 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateROWID");
/* 669 */     sQLException.fillInStackTrace();
/* 670 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
/* 678 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateSTRUCT");
/* 679 */     sQLException.fillInStackTrace();
/* 680 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 688 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMPLTZ");
/* 689 */     sQLException.fillInStackTrace();
/* 690 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 698 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMPTZ");
/* 699 */     sQLException.fillInStackTrace();
/* 700 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 708 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateTIMESTAMP");
/* 709 */     sQLException.fillInStackTrace();
/* 710 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 718 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateAsciiStream");
/* 719 */     sQLException.fillInStackTrace();
/* 720 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 728 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateBinaryStream");
/* 729 */     sQLException.fillInStackTrace();
/* 730 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/* 738 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateCharacterStream");
/* 739 */     sQLException.fillInStackTrace();
/* 740 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateUnicodeStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 748 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateUnicodeStream");
/* 749 */     sQLException.fillInStackTrace();
/* 750 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateNull(int paramInt) throws SQLException {
/* 763 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateNull");
/* 764 */     sQLException.fillInStackTrace();
/* 765 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rowUpdated() throws SQLException {
/* 774 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rowInserted() throws SQLException {
/* 781 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean rowDeleted() throws SQLException {
/* 788 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void insertRow() throws SQLException {
/* 796 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "insertRow");
/* 797 */     sQLException.fillInStackTrace();
/* 798 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateRow() throws SQLException {
/* 807 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "updateRow");
/* 808 */     sQLException.fillInStackTrace();
/* 809 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void deleteRow() throws SQLException {
/* 818 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "deleteRow");
/* 819 */     sQLException.fillInStackTrace();
/* 820 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void refreshRow() throws SQLException {
/* 829 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, (Object)null);
/* 830 */     sQLException.fillInStackTrace();
/* 831 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cancelRowUpdates() throws SQLException {
/* 840 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "cancelRowUpdates");
/* 841 */     sQLException.fillInStackTrace();
/* 842 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void moveToInsertRow() throws SQLException {
/* 851 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "moveToInsertRow");
/* 852 */     sQLException.fillInStackTrace();
/* 853 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void moveToCurrentRow() throws SQLException {
/* 862 */     SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 76, "moveToCurrentRow");
/* 863 */     sQLException.fillInStackTrace();
/* 864 */     throw sQLException;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAutoRefetch(boolean paramBoolean) throws SQLException {
/* 893 */     this.autoRefetch = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean getAutoRefetch() throws SQLException {
/* 910 */     return this.autoRefetch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() throws SQLException {
/* 917 */     this.closed = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleStatement getOracleStatement() throws SQLException {
/* 928 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 941 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/BaseResultSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */