/*     */ package oracle.jdbc.xa;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleMultiPhaseArgs
/*     */ {
/*  28 */   int action = 0;
/*  29 */   int nsites = 0;
/*  30 */   Vector dbLinks = null;
/*  31 */   Vector xids = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleMultiPhaseArgs() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleMultiPhaseArgs(int paramInt1, int paramInt2, Vector paramVector1, Vector paramVector2) {
/*  45 */     if (paramInt2 <= 1) {
/*     */       
/*  47 */       this.action = 0;
/*  48 */       this.nsites = 0;
/*  49 */       this.dbLinks = null;
/*  50 */       this.xids = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*  56 */     else if (!paramVector1.isEmpty() && !paramVector2.isEmpty() && paramVector2.size() == paramInt2 && paramVector1.size() == 3 * paramInt2) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  63 */       this.action = paramInt1;
/*  64 */       this.nsites = paramInt2;
/*  65 */       this.xids = paramVector1;
/*  66 */       this.dbLinks = paramVector2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OracleMultiPhaseArgs(byte[] paramArrayOfbyte) {
/*  79 */     ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(paramArrayOfbyte);
/*  80 */     DataInputStream dataInputStream = new DataInputStream(byteArrayInputStream);
/*     */     
/*  82 */     this.xids = new Vector();
/*  83 */     this.dbLinks = new Vector();
/*     */ 
/*     */     
/*     */     try {
/*  87 */       this.action = dataInputStream.readInt();
/*  88 */       this.nsites = dataInputStream.readInt();
/*     */       
/*  90 */       int i = dataInputStream.readInt();
/*  91 */       int j = dataInputStream.readInt();
/*  92 */       byte[] arrayOfByte = new byte[j];
/*  93 */       int k = dataInputStream.read(arrayOfByte, 0, j);
/*     */       
/*  95 */       for (byte b = 0; b < this.nsites; b++)
/*     */       {
/*  97 */         int m = dataInputStream.readInt();
/*  98 */         byte[] arrayOfByte1 = new byte[m];
/*  99 */         int n = dataInputStream.read(arrayOfByte1, 0, m);
/*     */ 
/*     */         
/* 102 */         this.xids.addElement(Integer.valueOf(i));
/* 103 */         this.xids.addElement(arrayOfByte);
/* 104 */         this.xids.addElement(arrayOfByte1);
/*     */         
/* 106 */         String str = dataInputStream.readUTF();
/*     */ 
/*     */         
/* 109 */         this.dbLinks.addElement(str);
/*     */       }
/*     */     
/* 112 */     } catch (IOException iOException) {
/*     */       
/* 114 */       iOException.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] toByteArray() {
/* 126 */     return toByteArrayOS().toByteArray();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ByteArrayOutputStream toByteArrayOS() {
/* 132 */     byte[] arrayOfByte = null;
/* 133 */     int i = 0;
/*     */ 
/*     */ 
/*     */     
/* 137 */     ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
/* 138 */     DataOutputStream dataOutputStream = new DataOutputStream(byteArrayOutputStream);
/*     */ 
/*     */     
/*     */     try {
/* 142 */       dataOutputStream.writeInt(this.action);
/* 143 */       dataOutputStream.writeInt(this.nsites);
/*     */       
/* 145 */       for (byte b = 0; b < this.nsites; b++)
/*     */       {
/* 147 */         String str = this.dbLinks.elementAt(b);
/* 148 */         int j = ((Integer)this.xids.elementAt(b * 3)).intValue();
/* 149 */         byte[] arrayOfByte1 = this.xids.elementAt(b * 3 + 1);
/* 150 */         byte[] arrayOfByte2 = this.xids.elementAt(b * 3 + 2);
/*     */         
/* 152 */         if (b == 0) {
/*     */           
/* 154 */           i = j;
/* 155 */           arrayOfByte = arrayOfByte1;
/*     */           
/* 157 */           dataOutputStream.writeInt(j);
/* 158 */           dataOutputStream.writeInt(arrayOfByte1.length);
/* 159 */           dataOutputStream.write(arrayOfByte1, 0, arrayOfByte1.length);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 170 */         dataOutputStream.writeInt(arrayOfByte2.length);
/* 171 */         dataOutputStream.write(arrayOfByte2, 0, arrayOfByte2.length);
/* 172 */         dataOutputStream.writeUTF(str);
/*     */       }
/*     */     
/* 175 */     } catch (IOException iOException) {
/*     */       
/* 177 */       iOException.printStackTrace();
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 182 */     return byteArrayOutputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getAction() {
/* 190 */     return this.action;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getnsite() {
/* 198 */     return this.nsites;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getdbLinks() {
/* 206 */     return this.dbLinks;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Vector getXids() {
/* 214 */     return this.xids;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void printMPArgs() {
/* 227 */     for (byte b = 0; b < this.nsites; b++) {
/*     */       
/* 229 */       String str = this.dbLinks.elementAt(b);
/* 230 */       int i = ((Integer)this.xids.elementAt(b * 3)).intValue();
/* 231 */       byte[] arrayOfByte1 = this.xids.elementAt(b * 3 + 1);
/* 232 */       byte[] arrayOfByte2 = this.xids.elementAt(b * 3 + 2);
/*     */ 
/*     */ 
/*     */       
/* 236 */       printByteArray(arrayOfByte1);
/*     */ 
/*     */       
/* 239 */       printByteArray(arrayOfByte2);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void printByteArray(byte[] paramArrayOfbyte) {
/* 251 */     StringBuffer stringBuffer = new StringBuffer();
/*     */     
/* 253 */     for (byte b = 0; b < paramArrayOfbyte.length; b++) {
/* 254 */       stringBuffer.append(paramArrayOfbyte[b] + " ");
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 262 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/xa/OracleMultiPhaseArgs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */