/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.io.Writer;
/*      */ import java.net.SocketException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.SQLException;
/*      */ import java.util.EnumSet;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.concurrent.Executor;
/*      */ import java.util.zip.CRC32;
/*      */ import oracle.jdbc.NotificationRegistration;
/*      */ import oracle.jdbc.OracleConnection;
/*      */ import oracle.jdbc.aq.AQDequeueOptions;
/*      */ import oracle.jdbc.aq.AQEnqueueOptions;
/*      */ import oracle.jdbc.internal.KeywordValue;
/*      */ import oracle.jdbc.internal.KeywordValueLong;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.jdbc.internal.XSEventListener;
/*      */ import oracle.jdbc.internal.XSNamespace;
/*      */ import oracle.jdbc.pool.OraclePooledConnection;
/*      */ import oracle.net.ns.Communication;
/*      */ import oracle.net.ns.NSProtocol;
/*      */ import oracle.net.ns.NetException;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.BfileDBAccess;
/*      */ import oracle.sql.BlobDBAccess;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.ClobDBAccess;
/*      */ import oracle.sql.LobPlsqlUtil;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class T4CConnection
/*      */   extends PhysicalConnection
/*      */   implements BfileDBAccess, BlobDBAccess, ClobDBAccess
/*      */ {
/*      */   static final short MIN_TTCVER_SUPPORTED = 4;
/*      */   static final short V8_TTCVER_SUPPORTED = 5;
/*      */   static final short MAX_TTCVER_SUPPORTED = 6;
/*      */   static final int DEFAULT_LONG_PREFETCH_SIZE = 4080;
/*      */   static final String DEFAULT_CONNECT_STRING = "localhost:1521:orcl";
/*      */   static final int STREAM_CHUNK_SIZE = 255;
/*      */   static final int REFCURSOR_SIZE = 5;
/*   94 */   long LOGON_MODE = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isLoggedOn;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean useZeroCopyIO;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean useLobPrefetch;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String password;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   Communication net;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int eocs;
/*      */ 
/*      */ 
/*      */   
/*  128 */   private NTFEventListener[] xsListeners = new NTFEventListener[0];
/*      */   
/*      */   boolean readAsNonStream;
/*      */   
/*      */   T4CTTIoer oer;
/*      */   
/*      */   T4CMAREngine mare;
/*      */   
/*      */   T4C8TTIpro pro;
/*      */   
/*      */   T4CTTIrxd rxd;
/*      */   
/*      */   T4CTTIsto sto;
/*      */   
/*      */   T4CTTIspfp spfp;
/*      */   
/*      */   T4CTTIoauthenticate auth;
/*      */   
/*      */   T4C8Odscrarr describe;
/*      */   
/*      */   T4C8Oall all8;
/*      */   
/*      */   T4C8Oclose close8;
/*      */   T4C7Ocommoncall commoncall;
/*      */   T4Caqe aqe;
/*      */   T4Caqdq aqdq;
/*      */   T4C8TTIBfile bfileMsg;
/*      */   T4C8TTIBlob blobMsg;
/*      */   T4C8TTIClob clobMsg;
/*      */   T4CTTIoses oses;
/*      */   T4CTTIoping oping;
/*      */   T4CTTIokpn okpn;
/*  160 */   byte[] EMPTY_BYTE = new byte[0];
/*      */   
/*      */   T4CTTIOtxen otxen;
/*      */   
/*      */   T4CTTIOtxse otxse;
/*      */   
/*      */   T4CTTIk2rpc k2rpc;
/*      */   
/*      */   T4CTTIoscid oscid;
/*      */   
/*      */   T4CTTIokeyval okeyval;
/*      */   
/*      */   T4CTTIoxsscs oxsscs;
/*      */   
/*      */   T4CTTIoxssro oxssro;
/*      */   
/*      */   T4CTTIoxsspo oxsspo;
/*      */   
/*      */   T4CTTIxsnsop xsnsop;
/*      */   
/*      */   int[] cursorToClose;
/*      */   
/*      */   int cursorToCloseOffset;
/*      */   
/*      */   int lastCursorToCloseOffset;
/*      */   
/*      */   int[] queryToClose;
/*      */   
/*      */   int queryToCloseOffset;
/*      */   
/*      */   int[] lusFunctionId2;
/*      */   
/*      */   byte[][] lusSessionId2;
/*      */   
/*      */   KeywordValueLong[][] lusInKeyVal2;
/*      */   
/*      */   int[] lusInFlags2;
/*      */   
/*      */   int lusOffset2;
/*      */   
/*      */   int sessionId;
/*      */   
/*      */   int serialNumber;
/*      */   
/*      */   byte negotiatedTTCversion;
/*      */   
/*      */   byte[] serverRuntimeCapabilities;
/*      */   
/*      */   byte[] serverCompileTimeCapabilities;
/*      */   
/*      */   Hashtable namespaces;
/*      */   
/*      */   byte[] internalName;
/*      */   
/*      */   byte[] externalName;
/*      */   static final int FREE = -1;
/*      */   static final int SEND = 1;
/*      */   static final int RECEIVE = 2;
/*  218 */   int pipeState = -1;
/*      */   boolean sentCancel = false;
/*      */   String currentSchema;
/*      */   boolean cancelInProgressFlag = false;
/*      */   boolean statementCancel = true;
/*      */   private final CRC32 checksumEngine;
/*      */   private final Hashtable<Long, Integer> tempLobRefCount;
/*      */   static final int MAX_SIZE_VSESSION_OSUSER = 30;
/*      */   static final int MAX_SIZE_VSESSION_PROCESS = 24;
/*      */   static final int MAX_SIZE_VSESSION_MACHINE = 64;
/*      */   static final int MAX_SIZE_VSESSION_TERMINAL = 30; static final int MAX_SIZE_VSESSION_PROGRAM = 48; final void initializePassword(String paramString) throws SQLException { this.password = paramString; } void logon() throws SQLException { SQLException sQLException = null; try { if (this.isLoggedOn) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 428); sQLException1.fillInStackTrace(); throw sQLException1; }  if (this.database == null)
/*      */         this.database = "localhost:1521:orcl";  connect(this.database); this.all8 = new T4C8Oall(this); this.okpn = new T4CTTIokpn(this); this.close8 = new T4C8Oclose(this); this.sto = new T4CTTIsto(this); this.spfp = new T4CTTIspfp(this); this.commoncall = new T4C7Ocommoncall(this); this.describe = new T4C8Odscrarr(this); this.bfileMsg = new T4C8TTIBfile(this); this.blobMsg = new T4C8TTIBlob(this); this.clobMsg = new T4C8TTIClob(this); this.otxen = new T4CTTIOtxen(this); this.otxse = new T4CTTIOtxse(this); this.oping = new T4CTTIoping(this); this.k2rpc = new T4CTTIk2rpc(this); this.oses = new T4CTTIoses(this); this.okeyval = new T4CTTIokeyval(this); this.oxssro = new T4CTTIoxssro(this); this.oxsspo = new T4CTTIoxsspo(this); this.oxsscs = new T4CTTIoxsscs(this); this.xsnsop = new T4CTTIxsnsop(this); this.aqe = new T4Caqe(this); this.aqdq = new T4Caqdq(this); this.oscid = new T4CTTIoscid(this); this.LOGON_MODE = 0L; if (this.internalLogon != null)
/*      */         if (this.internalLogon.equalsIgnoreCase("sysoper")) { this.LOGON_MODE = 64L; } else if (this.internalLogon.equalsIgnoreCase("sysdba")) { this.LOGON_MODE = 32L; } else if (this.internalLogon.equalsIgnoreCase("sysasm")) { this.LOGON_MODE = 4194304L; } else if (this.internalLogon.equalsIgnoreCase("sysbackup")) { this.LOGON_MODE = 16777216L; } else if (this.internalLogon.equalsIgnoreCase("sysdg")) { this.LOGON_MODE = 33554432L; } else if (this.internalLogon.equalsIgnoreCase("syskm")) { this.LOGON_MODE = 67108864L; }   if (this.prelimAuth)
/*      */         this.LOGON_MODE |= 0x80L;  this.auth = new T4CTTIoauthenticate(this, this.resourceManagerId, this.serverCompileTimeCapabilities); if (this.userName != null && this.userName.length() != 0)
/*      */         try { this.auth.doOSESSKEY(this.userName, this.LOGON_MODE); } catch (SQLException sQLException1) { if (sQLException1.getErrorCode() == 1017) { sQLException = sQLException1; this.userName = null; } else { throw sQLException1; }  }   this.auth.doOAUTH(this.userName, this.password, this.LOGON_MODE); this.sessionId = getSessionId(); this.serialNumber = getSerialNumber(); this.internalName = this.auth.internalName; this.externalName = this.auth.externalName; this.instanceName = this.sessionProperties.getProperty("AUTH_INSTANCENAME"); if (!this.prelimAuth) { T4C7Oversion t4C7Oversion = new T4C7Oversion(this); t4C7Oversion.doOVERSION(); byte[] arrayOfByte = t4C7Oversion.getVersion(); try { this.databaseProductVersion = new String(arrayOfByte, "UTF8"); } catch (UnsupportedEncodingException unsupportedEncodingException) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), unsupportedEncodingException); sQLException1.fillInStackTrace(); throw sQLException1; }  this.versionNumber = t4C7Oversion.getVersionNumber(); } else { this.versionNumber = 0; }  this.isLoggedOn = true; if (getVersionNumber() < 11000)
/*      */         this.enableTempLobRefCnt = false;  } catch (NetException netException) { SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException); sQLException1.fillInStackTrace(); throw sQLException1; } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException1 = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException1.fillInStackTrace(); throw sQLException1; } catch (SQLException sQLException1) { if (sQLException != null)
/*      */         sQLException1.initCause(sQLException);  try { this.net.disconnect(); } catch (Exception exception) {} this.isLoggedOn = false; throw sQLException1; }  } void handleIOException(IOException paramIOException) throws SQLException { try { this.pipeState = -1; this.net.disconnect(); this.net = null; } catch (Exception exception) {} this.isLoggedOn = false; this.lifecycle = 4; } synchronized void logoff() throws SQLException { try { assertLoggedOn("T4CConnection.logoff"); if (this.lifecycle == 8)
/*      */         return;  sendPiggyBackedMessages(); this.commoncall.doOLOGOFF(); this.net.disconnect(); this.net = null; } catch (IOException iOException) { handleIOException(iOException); if (this.lifecycle != 8) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } finally { try { if (this.net != null)
/*      */           this.net.disconnect();  } catch (Exception exception) {} this.isLoggedOn = false; }  } T4CMAREngine getMarshalEngine() { return this.mare; } synchronized void doCommit(int paramInt) throws SQLException { assertLoggedOn("T4CConnection.do_commit"); try { sendPiggyBackedMessages(); if (paramInt == 0) { this.commoncall.doOCOMMIT(); } else { int i = 0; if ((paramInt & OracleConnection.CommitOption.WRITEBATCH.getCode()) != 0) { i = i | 0x2 | 0x1; } else if ((paramInt & OracleConnection.CommitOption.WRITEIMMED.getCode()) != 0) { i |= 0x2; }  if ((paramInt & OracleConnection.CommitOption.NOWAIT.getCode()) != 0) { i = i | 0x8 | 0x4; } else if ((paramInt & OracleConnection.CommitOption.WAIT.getCode()) != 0) { i |= 0x8; }  this.otxen.doOTXEN(1, null, null, 0, 0, 0, 0, 4, i); int j = this.otxen.getOutStateFromServer(); if (j == 2 || j != 4); }  } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } synchronized void doRollback() throws SQLException { try { assertLoggedOn("T4CConnection.do_rollback"); sendPiggyBackedMessages(); this.commoncall.doOROLLBACK(); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } synchronized void doSetAutoCommit(boolean paramBoolean) throws SQLException { this.autocommit = paramBoolean; } public synchronized void open(OracleStatement paramOracleStatement) throws SQLException { assertLoggedOn("T4CConnection.open"); paramOracleStatement.setCursorId(0); } synchronized String doGetDatabaseProductVersion() throws SQLException { assertLoggedOn("T4CConnection.do_getDatabaseProductVersion"); T4C7Oversion t4C7Oversion = new T4C7Oversion(this); try { t4C7Oversion.doOVERSION(); }
/*      */     catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }
/*      */      String str = null; byte[] arrayOfByte = t4C7Oversion.getVersion(); try { str = new String(arrayOfByte, "UTF8"); }
/*      */     catch (UnsupportedEncodingException unsupportedEncodingException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), unsupportedEncodingException); sQLException.fillInStackTrace(); throw sQLException; }
/*  240 */      return str; } byte currentTTCSeqNumber = 0;
/*      */   synchronized short doGetVersionNumber() throws SQLException { assertLoggedOn("T4CConnection.do_getVersionNumber"); T4C7Oversion t4C7Oversion = new T4C7Oversion(this); try { t4C7Oversion.doOVERSION(); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return t4C7Oversion.getVersionNumber(); }
/*      */   OracleStatement RefCursorBytesToStatement(byte[] paramArrayOfbyte, OracleStatement paramOracleStatement) throws SQLException { T4CStatement t4CStatement = new T4CStatement(this, -1, -1); try { int i = this.mare.unmarshalRefCursor(paramArrayOfbyte); t4CStatement.setCursorId(i); t4CStatement.isOpen = true; t4CStatement.sqlObject = paramOracleStatement.sqlObject; t4CStatement.serverCursor = true; paramOracleStatement.addChild(t4CStatement); t4CStatement.prepareForNewResults(true, false); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  t4CStatement.sqlStringChanged = false; t4CStatement.needToParse = false; return t4CStatement; }
/*      */   void cancelOperationOnServer(boolean paramBoolean) throws SQLException { synchronized (this.cancelInProgressLockForThin) { if (!this.cancelInProgressFlag) { try { switch (this.pipeState) { case -1: return;case 1: this.net.sendBreak(); break;case 2: this.net.sendInterrupt(); break; }  this.sentCancel = true; } catch (NetException netException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException); sQLException.fillInStackTrace(); throw sQLException; } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  this.cancelInProgressFlag = true; this.statementCancel = paramBoolean; }  }  }
/*      */   void connect(String paramString) throws IOException, SQLException { if (paramString == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 433); sQLException.fillInStackTrace(); throw sQLException; }  Properties properties = new Properties(); if (this.thinNetProfile != null) properties.setProperty("oracle.net.profile", this.thinNetProfile);  if (this.thinNetAuthenticationServices != null) properties.setProperty("oracle.net.authentication_services", this.thinNetAuthenticationServices);  if (this.thinNetAuthenticationKrb5Mutual != null) properties.setProperty("oracle.net.kerberos5_mutual_authentication", this.thinNetAuthenticationKrb5Mutual);  if (this.thinNetAuthenticationKrb5CcName != null) properties.setProperty("oracle.net.kerberos5_cc_name", this.thinNetAuthenticationKrb5CcName);  if (this.thinNetEncryptionLevel != null) properties.setProperty("oracle.net.encryption_client", this.thinNetEncryptionLevel);  if (this.thinNetEncryptionTypes != null) properties.setProperty("oracle.net.encryption_types_client", this.thinNetEncryptionTypes);  if (this.thinNetChecksumLevel != null) properties.setProperty("oracle.net.crypto_checksum_client", this.thinNetChecksumLevel);  if (this.thinNetChecksumTypes != null) properties.setProperty("oracle.net.crypto_checksum_types_client", this.thinNetChecksumTypes);  if (this.thinNetCryptoSeed != null) properties.setProperty("oracle.net.crypto_seed", this.thinNetCryptoSeed);  if (this.thinTcpNoDelay) properties.setProperty("TCP.NODELAY", "YES");  if (this.thinReadTimeout != null) properties.setProperty("oracle.net.READ_TIMEOUT", this.thinReadTimeout);  if (this.thinNetConnectTimeout != null) properties.setProperty("oracle.net.CONNECT_TIMEOUT", this.thinNetConnectTimeout);  if (this.thinSslServerDnMatch != null) properties.setProperty("oracle.net.ssl_server_dn_match", this.thinSslServerDnMatch);  if (this.walletLocation != null) properties.setProperty("oracle.net.wallet_location", this.walletLocation);  if (this.walletPassword != null) properties.setProperty("oracle.net.wallet_password", this.walletPassword);  if (this.thinSslVersion != null) properties.setProperty("oracle.net.ssl_version", this.thinSslVersion);  if (this.thinSslCipherSuites != null) properties.setProperty("oracle.net.ssl_cipher_suites", this.thinSslCipherSuites);  if (this.thinJavaxNetSslKeystore != null) properties.setProperty("javax.net.ssl.keyStore", this.thinJavaxNetSslKeystore);  if (this.thinJavaxNetSslKeystoretype != null) properties.setProperty("javax.net.ssl.keyStoreType", this.thinJavaxNetSslKeystoretype);  if (this.thinJavaxNetSslKeystorepassword != null) properties.setProperty("javax.net.ssl.keyStorePassword", this.thinJavaxNetSslKeystorepassword);  if (this.thinJavaxNetSslTruststore != null) properties.setProperty("javax.net.ssl.trustStore", this.thinJavaxNetSslTruststore);  if (this.thinJavaxNetSslTruststoretype != null) properties.setProperty("javax.net.ssl.trustStoreType", this.thinJavaxNetSslTruststoretype);  if (this.thinJavaxNetSslTruststorepassword != null) properties.setProperty("javax.net.ssl.trustStorePassword", this.thinJavaxNetSslTruststorepassword);  if (this.thinSslKeymanagerfactoryAlgorithm != null) properties.setProperty("ssl.keyManagerFactory.algorithm", this.thinSslKeymanagerfactoryAlgorithm);  if (this.thinSslTrustmanagerfactoryAlgorithm != null) properties.setProperty("ssl.trustManagerFactory.algorithm", this.thinSslTrustmanagerfactoryAlgorithm);  if (this.thinNetOldsyntax != null)
/*      */       properties.setProperty("oracle.net.oldSyntax", this.thinNetOldsyntax);  if (this.thinNamingContextInitial != null)
/*      */       properties.setProperty("java.naming.factory.initial", this.thinNamingContextInitial);  if (this.thinNamingProviderUrl != null)
/*      */       properties.setProperty("java.naming.provider.url", this.thinNamingProviderUrl);  if (this.thinNamingSecurityAuthentication != null)
/*      */       properties.setProperty("java.naming.security.authentication", this.thinNamingSecurityAuthentication);  if (this.thinNamingSecurityPrincipal != null)
/*      */       properties.setProperty("java.naming.security.principal", this.thinNamingSecurityPrincipal);  if (this.thinNamingSecurityCredentials != null)
/*      */       properties.setProperty("java.naming.security.credentials", this.thinNamingSecurityCredentials);  if (this.thinNetDisableOutOfBandBreak)
/*      */       properties.setProperty("DISABLE_OOB", "" + this.thinNetDisableOutOfBandBreak);  if (this.thinNetEnableSDP)
/*      */       properties.setProperty("oracle.net.SDP", "" + this.thinNetEnableSDP);  properties.setProperty("USE_ZERO_COPY_IO", "" + this.thinNetUseZeroCopyIO); properties.setProperty("FORCE_DNS_LOAD_BALANCING", "" + this.thinForceDnsLoadBalancing); properties.setProperty("ENABLE_JAVANET_FASTPATH", "" + this.enableJavaNetFastPath); properties.setProperty("oracle.jdbc.v$session.osuser", this.thinVsessionOsuser); properties.setProperty("oracle.jdbc.v$session.program", this.thinVsessionProgram); properties.setProperty("T4CConnection.hashCode", Integer.toHexString(hashCode()).toUpperCase()); properties.setProperty("oracle.net.keepAlive", Boolean.toString(this.keepAlive)); this.net = (Communication)new NSProtocol(); this.net.connect(paramString, properties); this.mare = new T4CMAREngine(this.net, this.enableJavaNetFastPath); this.oer = new T4CTTIoer(this); this.mare.setConnectionDuringExceptionHandling(this); this.pro = new T4C8TTIpro(this); this.pro.marshal(); this.serverCompileTimeCapabilities = this.pro.receive(); this.serverRuntimeCapabilities = this.pro.getServerRuntimeCapabilities(); short s1 = this.pro.getOracleVersion(); short s2 = this.pro.getCharacterSet(); short s3 = DBConversion.findDriverCharSet(s2, s1); this.conversion = new DBConversion(s2, s3, this.pro.getncharCHARSET(), this.isStrictAsciiConversion, this.isQuickAsciiConversion); this.mare.types.setServerConversion(!(s3 == s2)); if (DBConversion.isCharSetMultibyte(s3)) { if (DBConversion.isCharSetMultibyte(this.pro.getCharacterSet())) { this.mare.types.setFlags((byte)1); } else { this.mare.types.setFlags((byte)2); }  } else { this.mare.types.setFlags(this.pro.getFlags()); }  this.mare.conv = this.conversion; T4C8TTIdty t4C8TTIdty = new T4C8TTIdty(this, this.serverCompileTimeCapabilities, this.serverRuntimeCapabilities, (this.logonCap != null && this.logonCap.trim().equals("o3")), this.thinNetUseZeroCopyIO); t4C8TTIdty.doRPC(); this.negotiatedTTCversion = this.serverCompileTimeCapabilities[7]; if (t4C8TTIdty.jdbcThinCompileTimeCapabilities[7] < this.serverCompileTimeCapabilities[7])
/*      */       this.negotiatedTTCversion = t4C8TTIdty.jdbcThinCompileTimeCapabilities[7];  if (this.serverRuntimeCapabilities != null && this.serverRuntimeCapabilities.length > 6 && (this.serverRuntimeCapabilities[6] & T4C8TTIdty.KPCCAP_RTB_TTC_ZCPY) != 0 && this.thinNetUseZeroCopyIO && (this.net.getSessionAttributes().getNegotiatedOptions() & 0x40) != 0 && getDataIntegrityAlgorithmName().equals("") && getEncryptionAlgorithmName().equals("")) { this.useZeroCopyIO = true; } else { this.useZeroCopyIO = false; }  if (this.serverCompileTimeCapabilities.length > 23 && (this.serverCompileTimeCapabilities[23] & 0x40) != 0 && (t4C8TTIdty.jdbcThinCompileTimeCapabilities[23] & 0x40) != 0) { this.useLobPrefetch = true; } else { this.useLobPrefetch = false; }  }
/*  254 */   boolean isZeroCopyIOEnabled() { return this.useZeroCopyIO; } T4CConnection(String paramString, Properties paramProperties, OracleDriverExtension paramOracleDriverExtension) throws SQLException { super(paramString, paramProperties, paramOracleDriverExtension);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2679 */     this.checksumEngine = new CRC32();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2696 */     this.tempLobRefCount = new Hashtable<Long, Integer>(); this.cursorToClose = new int[4]; this.cursorToCloseOffset = 0; this.queryToClose = new int[10]; this.queryToCloseOffset = 0; this.lusFunctionId2 = new int[10]; this.lusSessionId2 = new byte[10][]; this.lusInKeyVal2 = new KeywordValueLong[10][]; this.lusInFlags2 = new int[10]; this.lusOffset2 = 0; this.minVcsBindSize = 0; this.streamChunkSize = 255; this.namespaces = new Hashtable<Object, Object>(5); this.currentSchema = null; } final T4CTTIoer getT4CTTIoer() { return this.oer; } final byte getTTCVersion() { return this.negotiatedTTCversion; } void doStartup(int paramInt) throws SQLException { try { byte b = 0; if (paramInt == OracleConnection.DatabaseStartupMode.FORCE.getMode()) { b = 16; } else if (paramInt == OracleConnection.DatabaseStartupMode.RESTRICT.getMode()) { b = 1; }  this.spfp.doOSPFPPUT(); this.sto.doOV6STRT(b); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void doShutdown(int paramInt) throws SQLException { try { char c = '\004'; if (paramInt == OracleConnection.DatabaseShutdownMode.TRANSACTIONAL.getMode()) { c = ''; } else if (paramInt == OracleConnection.DatabaseShutdownMode.TRANSACTIONAL_LOCAL.getMode()) { c = 'Ā'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.IMMEDIATE.getMode()) { c = '\002'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.FINAL.getMode()) { c = '\b'; } else if (paramInt == OracleConnection.DatabaseShutdownMode.ABORT.getMode()) { c = '@'; }  sendPiggyBackedMessages(); this.sto.doOV6STOP(c); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void sendPiggyBackedMessages() throws SQLException, IOException { sendPiggyBackedClose(); if (this.endToEndAnyChanged && getTTCVersion() >= 3) { this.oscid.doOSCID(this.endToEndHasChanged, this.endToEndValues, this.endToEndECIDSequenceNumber); for (byte b = 0; b < 4; b++) { if (this.endToEndHasChanged[b]) this.endToEndHasChanged[b] = false;  }  }  this.endToEndAnyChanged = false; if (!this.namespaces.isEmpty()) { if (getTTCVersion() >= 4) { Object[] arrayOfObject = this.namespaces.values().toArray(); for (byte b = 0; b < arrayOfObject.length; b++) this.okeyval.doOKEYVAL((Namespace)arrayOfObject[b]);  }  this.namespaces.clear(); }  if (this.lusOffset2 > 0) { for (byte b = 0; b < this.lusOffset2; b++) this.oxsspo.doOXSSPO(this.lusFunctionId2[b], this.lusSessionId2[b], this.lusInKeyVal2[b], this.lusInFlags2[b]);  this.lusOffset2 = 0; }  } private void sendPiggyBackedClose() throws SQLException, IOException { if (this.queryToCloseOffset > 0) { this.close8.doOCANA(this.queryToClose, this.queryToCloseOffset); this.queryToCloseOffset = 0; }  if (this.cursorToCloseOffset > 0) { this.close8.doOCCA(this.cursorToClose, this.cursorToCloseOffset); this.lastCursorToCloseOffset = this.cursorToCloseOffset; this.cursorToCloseOffset = 0; }  } void redoCursorClose() { if (this.cursorToCloseOffset == 0 && this.lastCursorToCloseOffset != 0) { this.cursorToCloseOffset = this.lastCursorToCloseOffset; this.lastCursorToCloseOffset = 0; }  } synchronized void closeCursor(int paramInt) throws SQLException { if (this.cursorToCloseOffset == this.cursorToClose.length) { int[] arrayOfInt = new int[this.cursorToClose.length * 2]; System.arraycopy(this.cursorToClose, 0, arrayOfInt, 0, this.cursorToClose.length); this.cursorToClose = arrayOfInt; }  this.cursorToClose[this.cursorToCloseOffset++] = paramInt; } void doProxySession(int paramInt, Properties paramProperties) throws SQLException { try { sendPiggyBackedMessages(); this.auth.doOAUTH(paramInt, paramProperties, this.sessionId, this.serialNumber); int i = getSessionId(); int j = getSerialNumber(); this.oses.doO80SES(i, j, 1); this.savedUser = this.userName; if (paramInt == 1) { this.userName = paramProperties.getProperty("PROXY_USER_NAME"); } else { this.userName = null; }  this.isProxy = true; } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } void closeProxySession() throws SQLException { try { sendPiggyBackedMessages(); this.commoncall.doOLOGOFF(); this.oses.doO80SES(this.sessionId, this.serialNumber, 1); this.userName = this.savedUser; } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   void updateSessionProperties(KeywordValue[] paramArrayOfKeywordValue) throws SQLException { for (byte b = 0; b < paramArrayOfKeywordValue.length; b++) { int i = paramArrayOfKeywordValue[b].getKeyword(); byte[] arrayOfByte = paramArrayOfKeywordValue[b].getBinaryValue(); if (i < T4C8Oall.NLS_KEYS.length) { String str = T4C8Oall.NLS_KEYS[i]; if (str != null) if (arrayOfByte != null) { this.sessionProperties.setProperty(str, this.mare.conv.CharBytesToString(arrayOfByte, arrayOfByte.length)); } else if (paramArrayOfKeywordValue[b].getTextValue() != null) { this.sessionProperties.setProperty(str, paramArrayOfKeywordValue[b].getTextValue().trim()); }   } else if (i == 163) { if (arrayOfByte != null) { int j = arrayOfByte[4]; int k = arrayOfByte[5]; if ((arrayOfByte[4] & 0xFF) > 120) { int m = (arrayOfByte[4] & 0xFF) - 181; int n = (arrayOfByte[5] & 0xFF) - 60; } else { j = (arrayOfByte[4] & 0xFF) - 60; k = (arrayOfByte[5] & 0xFF) - 60; }  String str = ((j > 0) ? "+" : "") + j + ((k <= 9) ? ":0" : ":") + k; this.sessionProperties.setProperty("SESSION_TIME_ZONE", str); }  } else if (i != 165) { if (i != 166) if (i != 167) if (i == 168) { String str = paramArrayOfKeywordValue[b].getTextValue(); if (str != null) this.currentSchema = str.trim();  } else if (i != 169) { if (i != 170) if (i == 171);  }    }  }  }
/*      */   public String getCurrentSchema() throws SQLException { if (this.lifecycle != 1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8); sQLException.fillInStackTrace(); throw sQLException; }  if (this.currentSchema == null || getVersionNumber() < 11100) this.currentSchema = super.getCurrentSchema();  return this.currentSchema; }
/*      */   public Properties getServerSessionInfo() throws SQLException { if (getVersionNumber() >= 10000 && getVersionNumber() < 10200) queryFCFProperties(this.sessionProperties);  return this.sessionProperties; }
/*      */   public String getSessionTimeZoneOffset() throws SQLException { String str = getServerSessionInfo().getProperty("SESSION_TIME_ZONE"); if (str == null) { str = super.getSessionTimeZoneOffset(); } else { str = tzToOffset(str); }  return str; }
/* 2701 */   private final synchronized Long getLocatorHash(byte[] paramArrayOfbyte) { this.checksumEngine.reset();
/*      */     
/* 2703 */     this.checksumEngine.update(paramArrayOfbyte, 10, 10);
/* 2704 */     long l = this.checksumEngine.getValue();
/* 2705 */     return Long.valueOf(l); } int getSessionId() { int i = -1; String str = this.sessionProperties.getProperty("AUTH_SESSION_ID"); try { i = Integer.parseInt(str); } catch (NumberFormatException numberFormatException) {} return i; } int getSerialNumber() { int i = -1; String str = this.sessionProperties.getProperty("AUTH_SERIAL_NUM"); try { i = Integer.parseInt(str); } catch (NumberFormatException numberFormatException) {} return i; } public byte getInstanceProperty(OracleConnection.InstanceProperty paramInstanceProperty) throws SQLException { byte b = 0; if (paramInstanceProperty == OracleConnection.InstanceProperty.ASM_VOLUME_SUPPORTED) { if (this.serverRuntimeCapabilities == null || this.serverRuntimeCapabilities.length < 6) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256); sQLException.fillInStackTrace(); throw sQLException; }  b = this.serverRuntimeCapabilities[5]; } else if (paramInstanceProperty == OracleConnection.InstanceProperty.INSTANCE_TYPE) { if (this.serverRuntimeCapabilities == null || this.serverRuntimeCapabilities.length < 4) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 256); sQLException.fillInStackTrace(); throw sQLException; }  b = this.serverRuntimeCapabilities[3]; }  return b; } public synchronized BlobDBAccess createBlobDBAccess() throws SQLException { return this; }
/*      */   public synchronized ClobDBAccess createClobDBAccess() throws SQLException { return this; }
/*      */   public synchronized BfileDBAccess createBfileDBAccess() throws SQLException { return this; }
/*      */   public synchronized long length(BFILE paramBFILE) throws SQLException { assertLoggedOn("length"); assertNotNull(paramBFILE.shareBytes(), "length"); needLine(); long l = 0L; try { l = this.bfileMsg.getLength(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return l; }
/*      */   public synchronized long position(BFILE paramBFILE, byte[] paramArrayOfbyte, long paramLong) throws SQLException { assertNotNull(paramBFILE.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.hasPattern(paramBFILE, paramArrayOfbyte, paramLong); l = (l == 0L) ? -1L : l; return l; }
/*      */   public long position(BFILE paramBFILE1, BFILE paramBFILE2, long paramLong) throws SQLException { assertNotNull(paramBFILE1.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.isSubLob(paramBFILE1, paramBFILE2, paramLong); l = (l == 0L) ? -1L : l; return l; }
/*      */   public synchronized int getBytes(BFILE paramBFILE, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException { assertLoggedOn("getBytes"); assertNotNull(paramBFILE.shareBytes(), "getBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt <= 0 || paramArrayOfbyte == null) return 0;  if (this.pipeState != -1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  needLine(); long l = 0L; if (paramInt != 0) try { l = this.bfileMsg.read(paramBFILE.shareBytes(), paramLong, paramInt, paramArrayOfbyte, 0); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }   return (int)l; }
/*      */   public String getName(BFILE paramBFILE) throws SQLException { assertLoggedOn("getName"); assertNotNull(paramBFILE.shareBytes(), "getName"); return LobPlsqlUtil.fileGetName(paramBFILE); }
/*      */   public String getDirAlias(BFILE paramBFILE) throws SQLException { assertLoggedOn("getDirAlias"); assertNotNull(paramBFILE.shareBytes(), "getDirAlias"); return LobPlsqlUtil.fileGetDirAlias(paramBFILE); }
/*      */   public synchronized void openFile(BFILE paramBFILE) throws SQLException { assertLoggedOn("openFile"); assertNotNull(paramBFILE.shareBytes(), "openFile"); needLine(); try { this.bfileMsg.open(paramBFILE.shareBytes(), 11); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   public synchronized boolean isFileOpen(BFILE paramBFILE) throws SQLException { assertLoggedOn("openFile"); assertNotNull(paramBFILE.shareBytes(), "openFile"); needLine(); boolean bool = false; try { bool = this.bfileMsg.isOpen(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; }
/*      */   public synchronized boolean fileExists(BFILE paramBFILE) throws SQLException { assertLoggedOn("fileExists"); assertNotNull(paramBFILE.shareBytes(), "fileExists"); needLine(); boolean bool = false; try { bool = this.bfileMsg.doesExist(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; }
/* 2717 */   public final synchronized int decrementTempLobReferenceCount(byte[] paramArrayOfbyte) { int i = 0;
/* 2718 */     if (this.enableTempLobRefCnt && paramArrayOfbyte != null && paramArrayOfbyte.length == 40 && ((paramArrayOfbyte[7] & 0x1) > 0 || (paramArrayOfbyte[4] & 0x40) > 0)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2724 */       Long long_ = getLocatorHash(paramArrayOfbyte);
/* 2725 */       Integer integer = this.tempLobRefCount.get(long_);
/* 2726 */       if (integer != null) {
/*      */         
/* 2728 */         i = integer.intValue() - 1;
/* 2729 */         if (i == 0) {
/* 2730 */           this.tempLobRefCount.remove(long_);
/*      */         } else {
/* 2732 */           this.tempLobRefCount.put(long_, Integer.valueOf(i));
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2743 */     return i; } public synchronized void closeFile(BFILE paramBFILE) throws SQLException { assertLoggedOn("closeFile"); assertNotNull(paramBFILE.shareBytes(), "closeFile"); needLine(); try { this.bfileMsg.close(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized void open(BFILE paramBFILE, int paramInt) throws SQLException { assertLoggedOn("open"); assertNotNull(paramBFILE.shareBytes(), "open"); needLine(); try { this.bfileMsg.open(paramBFILE.shareBytes(), paramInt); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized void close(BFILE paramBFILE) throws SQLException { assertLoggedOn("close"); assertNotNull(paramBFILE.shareBytes(), "close"); needLine(); try { this.bfileMsg.close(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  } public synchronized boolean isOpen(BFILE paramBFILE) throws SQLException { assertLoggedOn("isOpen"); assertNotNull(paramBFILE.shareBytes(), "isOpen"); needLine(); boolean bool = false; try { bool = this.bfileMsg.isOpen(paramBFILE.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bool; } public InputStream newInputStream(BFILE paramBFILE, int paramInt, long paramLong) throws SQLException { if (paramLong == 0L) return new OracleBlobInputStream(paramBFILE, paramInt);  return new OracleBlobInputStream(paramBFILE, paramInt, paramLong); } public InputStream newConversionInputStream(BFILE paramBFILE, int paramInt) throws SQLException { assertNotNull(paramBFILE.shareBytes(), "newConversionInputStream"); return new OracleConversionInputStream(this.conversion, paramBFILE.getBinaryStream(), paramInt); } public Reader newConversionReader(BFILE paramBFILE, int paramInt) throws SQLException { assertNotNull(paramBFILE.shareBytes(), "newConversionReader"); return new OracleConversionReader(this.conversion, paramBFILE.getBinaryStream(), paramInt); } public synchronized long length(BLOB paramBLOB) throws SQLException { assertLoggedOn("length"); assertNotNull(paramBLOB.shareBytes(), "length"); needLine(); long l = 0L; try { l = this.blobMsg.getLength(paramBLOB.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return l; } public long position(BLOB paramBLOB, byte[] paramArrayOfbyte, long paramLong) throws SQLException { assertLoggedOn("position"); assertNotNull(paramBLOB.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.hasPattern(paramBLOB, paramArrayOfbyte, paramLong); l = (l == 0L) ? -1L : l; return l; } public long position(BLOB paramBLOB1, BLOB paramBLOB2, long paramLong) throws SQLException { assertLoggedOn("position"); assertNotNull(paramBLOB1.shareBytes(), "position"); assertNotNull(paramBLOB2.shareBytes(), "position"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()"); sQLException.fillInStackTrace(); throw sQLException; }  long l = LobPlsqlUtil.isSubLob(paramBLOB1, paramBLOB2, paramLong); l = (l == 0L) ? -1L : l; return l; }
/*      */   public synchronized int getBytes(BLOB paramBLOB, long paramLong, int paramInt, byte[] paramArrayOfbyte) throws SQLException { assertLoggedOn("getBytes"); assertNotNull(paramBLOB.shareBytes(), "getBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (this.pipeState != -1) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramInt <= 0 || paramArrayOfbyte == null) return 0;  long l1 = 0L; long l2 = -1L; if (paramBLOB.isActivePrefetch()) { byte[] arrayOfByte = paramBLOB.getPrefetchedData(); int i = paramBLOB.getPrefetchedDataSize(); l2 = paramBLOB.length(); int j = 0; if (arrayOfByte != null) j = Math.min(i, arrayOfByte.length);  if (j > 0 && paramLong <= j) { int k = Math.min(j - (int)paramLong + 1, paramInt); System.arraycopy(arrayOfByte, (int)paramLong - 1, paramArrayOfbyte, 0, k); l1 += k; }  }  if (l1 < paramInt && (l2 == -1L || paramLong - 1L + l1 < l2)) { needLine(); try { l1 += this.blobMsg.read(paramBLOB.shareBytes(), paramLong + l1, paramInt - l1, paramArrayOfbyte, (int)l1); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }  return (int)l1; }
/*      */   public synchronized int putBytes(BLOB paramBLOB, long paramLong, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws SQLException { assertLoggedOn("putBytes"); assertNotNull(paramBLOB.shareBytes(), "putBytes"); if (paramLong < 1L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putBytes()"); sQLException.fillInStackTrace(); throw sQLException; }  if (paramArrayOfbyte == null || paramInt2 <= 0) return 0;  needLine(); long l = 0L; if (paramInt2 != 0) try { paramBLOB.setActivePrefetch(false); paramBLOB.clearCachedData(); l = this.blobMsg.write(paramBLOB.shareBytes(), paramLong, paramArrayOfbyte, paramInt1, paramInt2); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }   return (int)l; }
/*      */   public synchronized int getChunkSize(BLOB paramBLOB) throws SQLException { assertLoggedOn("getChunkSize"); assertNotNull(paramBLOB.shareBytes(), "getChunkSize"); needLine(); long l = 0L; try { l = this.blobMsg.getChunkSize(paramBLOB.shareBytes()); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return (int)l; }
/*      */   public synchronized void trim(BLOB paramBLOB, long paramLong) throws SQLException { assertLoggedOn("trim"); assertNotNull(paramBLOB.shareBytes(), "trim"); if (paramLong < 0L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()"); sQLException.fillInStackTrace(); throw sQLException; }  needLine(); try { paramBLOB.setActivePrefetch(false); paramBLOB.clearCachedData(); this.blobMsg.trim(paramBLOB.shareBytes(), paramLong); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   public synchronized BLOB createTemporaryBlob(Connection paramConnection, boolean paramBoolean, int paramInt) throws SQLException { assertLoggedOn("createTemporaryBlob"); needLine(); BLOB bLOB = null; try { bLOB = (BLOB)this.blobMsg.createTemporaryLob((Connection)this, paramBoolean, paramInt); } catch (IOException iOException) { handleIOException(iOException); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  return bLOB; }
/* 2749 */   public final synchronized void incrementTempLobReferenceCount(byte[] paramArrayOfbyte) { if (this.enableTempLobRefCnt && paramArrayOfbyte != null && paramArrayOfbyte.length == 40 && ((paramArrayOfbyte[7] & 0x1) > 0 || (paramArrayOfbyte[4] & 0x40) > 0)) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2755 */       Long long_ = getLocatorHash(paramArrayOfbyte);
/* 2756 */       Integer integer = this.tempLobRefCount.get(long_);
/*      */       
/* 2758 */       if (integer != null) {
/*      */         
/* 2760 */         int i = integer.intValue();
/*      */         
/* 2762 */         this.tempLobRefCount.put(long_, Integer.valueOf(i + 1));
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 2767 */         this.tempLobRefCount.put(long_, Integer.valueOf(1));
/*      */       } 
/*      */     }  }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(BLOB paramBLOB, boolean paramBoolean) throws SQLException {
/* 2784 */     assertLoggedOn("freeTemporary");
/* 2785 */     assertNotNull(paramBLOB.shareBytes(), "freeTemporary");
/*      */     
/* 2787 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 2791 */       this.blobMsg.freeTemporaryLob(paramBLOB.shareBytes());
/*      */     }
/* 2793 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2796 */       handleIOException(iOException);
/*      */       
/* 2798 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2799 */       sQLException.fillInStackTrace();
/* 2800 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTemporary(BLOB paramBLOB) throws SQLException {
/* 2819 */     assertNotNull(paramBLOB.shareBytes(), "isTemporary");
/*      */ 
/*      */ 
/*      */     
/* 2823 */     boolean bool = false;
/* 2824 */     byte[] arrayOfByte = paramBLOB.shareBytes();
/*      */     
/* 2826 */     if ((arrayOfByte[7] & 0x1) > 0 || (arrayOfByte[4] & 0x40) > 0) {
/* 2827 */       bool = true;
/*      */     }
/* 2829 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(BLOB paramBLOB, int paramInt) throws SQLException {
/* 2842 */     assertLoggedOn("open");
/* 2843 */     assertNotNull(paramBLOB.shareBytes(), "open");
/*      */     
/* 2845 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 2849 */       this.blobMsg.open(paramBLOB.shareBytes(), paramInt);
/*      */     }
/* 2851 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2854 */       handleIOException(iOException);
/*      */       
/* 2856 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2857 */       sQLException.fillInStackTrace();
/* 2858 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(BLOB paramBLOB) throws SQLException {
/* 2873 */     assertLoggedOn("close");
/* 2874 */     assertNotNull(paramBLOB.shareBytes(), "close");
/*      */     
/* 2876 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 2880 */       this.blobMsg.close(paramBLOB.shareBytes());
/*      */     }
/* 2882 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2885 */       handleIOException(iOException);
/*      */       
/* 2887 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2888 */       sQLException.fillInStackTrace();
/* 2889 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(BLOB paramBLOB) throws SQLException {
/* 2905 */     assertLoggedOn("isOpen");
/* 2906 */     assertNotNull(paramBLOB.shareBytes(), "isOpen");
/*      */     
/* 2908 */     needLine();
/*      */     
/* 2910 */     boolean bool = false;
/*      */ 
/*      */     
/*      */     try {
/* 2914 */       bool = this.blobMsg.isOpen(paramBLOB.shareBytes());
/*      */     }
/* 2916 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 2919 */       handleIOException(iOException);
/*      */       
/* 2921 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2922 */       sQLException.fillInStackTrace();
/* 2923 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2928 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(BLOB paramBLOB, int paramInt, long paramLong) throws SQLException {
/* 2947 */     if (paramLong == 0L)
/*      */     {
/* 2949 */       return new OracleBlobInputStream(paramBLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 2953 */     return new OracleBlobInputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(BLOB paramBLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 2977 */     if (paramLong == 0L) {
/*      */       
/* 2979 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 2982 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 2983 */         sQLException.fillInStackTrace();
/* 2984 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2989 */       return new OracleBlobOutputStream(paramBLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 2994 */     return new OracleBlobOutputStream(paramBLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newConversionInputStream(BLOB paramBLOB, int paramInt) throws SQLException {
/* 3013 */     assertNotNull(paramBLOB.shareBytes(), "newConversionInputStream");
/*      */     
/* 3015 */     return new OracleConversionInputStream(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newConversionReader(BLOB paramBLOB, int paramInt) throws SQLException {
/* 3036 */     assertNotNull(paramBLOB.shareBytes(), "newConversionReader");
/*      */     
/* 3038 */     return new OracleConversionReader(this.conversion, paramBLOB.getBinaryStream(), paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized long length(CLOB paramCLOB) throws SQLException {
/* 3066 */     assertLoggedOn("length");
/* 3067 */     assertNotNull(paramCLOB.shareBytes(), "length");
/*      */     
/* 3069 */     needLine();
/*      */     
/* 3071 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/* 3075 */       l = this.clobMsg.getLength(paramCLOB.shareBytes());
/*      */     }
/* 3077 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3080 */       handleIOException(iOException);
/*      */       
/* 3082 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3083 */       sQLException.fillInStackTrace();
/* 3084 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3089 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long position(CLOB paramCLOB, String paramString, long paramLong) throws SQLException {
/* 3106 */     if (paramString == null) {
/*      */       
/* 3108 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3109 */       sQLException.fillInStackTrace();
/* 3110 */       throw sQLException;
/*      */     } 
/*      */     
/* 3113 */     assertLoggedOn("position");
/* 3114 */     assertNotNull(paramCLOB.shareBytes(), "position");
/*      */ 
/*      */     
/* 3117 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3120 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3121 */       sQLException.fillInStackTrace();
/* 3122 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3127 */     char[] arrayOfChar = new char[paramString.length()];
/*      */     
/* 3129 */     paramString.getChars(0, arrayOfChar.length, arrayOfChar, 0);
/*      */     
/* 3131 */     long l = LobPlsqlUtil.hasPattern(paramCLOB, arrayOfChar, paramLong);
/*      */     
/* 3133 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 3135 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long position(CLOB paramCLOB1, CLOB paramCLOB2, long paramLong) throws SQLException {
/* 3151 */     if (paramCLOB2 == null) {
/*      */       
/* 3153 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3154 */       sQLException.fillInStackTrace();
/* 3155 */       throw sQLException;
/*      */     } 
/*      */     
/* 3158 */     assertLoggedOn("position");
/* 3159 */     assertNotNull(paramCLOB1.shareBytes(), "position");
/* 3160 */     assertNotNull(paramCLOB2.shareBytes(), "position");
/*      */     
/* 3162 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3165 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "position()");
/* 3166 */       sQLException.fillInStackTrace();
/* 3167 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3171 */     long l = LobPlsqlUtil.isSubLob(paramCLOB1, paramCLOB2, paramLong);
/*      */     
/* 3173 */     l = (l == 0L) ? -1L : l;
/*      */     
/* 3175 */     return l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChars(CLOB paramCLOB, long paramLong, int paramInt, char[] paramArrayOfchar) throws SQLException {
/* 3192 */     assertLoggedOn("getChars");
/* 3193 */     assertNotNull(paramCLOB.shareBytes(), "getChars");
/*      */     
/* 3195 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3198 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getChars()");
/* 3199 */       sQLException.fillInStackTrace();
/* 3200 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3206 */     if (this.pipeState != -1) {
/*      */ 
/*      */       
/* 3209 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 453, "getChars()");
/* 3210 */       sQLException.fillInStackTrace();
/* 3211 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3216 */     if (paramInt <= 0 || paramArrayOfchar == null) {
/* 3217 */       return 0;
/*      */     }
/*      */     
/* 3220 */     long l1 = 0L;
/*      */ 
/*      */     
/* 3223 */     long l2 = -1L;
/*      */ 
/*      */     
/* 3226 */     if (paramCLOB.isActivePrefetch()) {
/*      */       
/* 3228 */       l2 = paramCLOB.length();
/* 3229 */       char[] arrayOfChar = paramCLOB.getPrefetchedData();
/* 3230 */       int i = paramCLOB.getPrefetchedDataSize();
/*      */       
/* 3232 */       int j = 0;
/* 3233 */       if (arrayOfChar != null) {
/* 3234 */         j = Math.min(i, arrayOfChar.length);
/*      */       }
/* 3236 */       if (j > 0 && paramLong <= j) {
/*      */ 
/*      */ 
/*      */         
/* 3240 */         int k = Math.min(j - (int)paramLong + 1, paramInt);
/*      */ 
/*      */ 
/*      */         
/* 3244 */         System.arraycopy(arrayOfChar, (int)paramLong - 1, paramArrayOfchar, 0, k);
/* 3245 */         l1 += k;
/*      */       } 
/*      */     } 
/*      */     
/* 3249 */     if (l1 < paramInt && (l2 == -1L || paramLong - 1L + l1 < l2)) {
/*      */ 
/*      */       
/* 3252 */       needLine();
/*      */       
/*      */       try {
/* 3255 */         boolean bool = paramCLOB.isNCLOB();
/*      */         
/* 3257 */         l1 += this.clobMsg.read(paramCLOB.shareBytes(), paramLong + l1, paramInt - l1, bool, paramArrayOfchar, (int)l1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 3264 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3267 */         handleIOException(iOException);
/*      */         
/* 3269 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3270 */         sQLException.fillInStackTrace();
/* 3271 */         throw sQLException;
/*      */       } 
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3278 */     return (int)l1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int putChars(CLOB paramCLOB, long paramLong, char[] paramArrayOfchar, int paramInt1, int paramInt2) throws SQLException {
/* 3298 */     assertLoggedOn("putChars");
/* 3299 */     assertNotNull(paramCLOB.shareBytes(), "putChars");
/*      */     
/* 3301 */     if (paramLong < 1L) {
/*      */ 
/*      */       
/* 3304 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "putChars()");
/* 3305 */       sQLException.fillInStackTrace();
/* 3306 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3310 */     if (paramArrayOfchar == null || paramInt2 <= 0) {
/* 3311 */       return 0;
/*      */     }
/* 3313 */     needLine();
/*      */     
/* 3315 */     long l = 0L;
/*      */     
/* 3317 */     if (paramInt2 != 0) {
/*      */       
/*      */       try {
/*      */         
/* 3321 */         boolean bool = paramCLOB.isNCLOB();
/*      */         
/* 3323 */         paramCLOB.setActivePrefetch(false);
/* 3324 */         paramCLOB.clearCachedData();
/* 3325 */         l = this.clobMsg.write(paramCLOB.shareBytes(), paramLong, bool, paramArrayOfchar, paramInt1, paramInt2);
/*      */       
/*      */       }
/* 3328 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3331 */         handleIOException(iOException);
/*      */         
/* 3333 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3334 */         sQLException.fillInStackTrace();
/* 3335 */         throw sQLException;
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 3341 */     return (int)l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized int getChunkSize(CLOB paramCLOB) throws SQLException {
/* 3353 */     assertLoggedOn("getChunkSize");
/* 3354 */     assertNotNull(paramCLOB.shareBytes(), "getChunkSize");
/*      */     
/* 3356 */     needLine();
/*      */     
/* 3358 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/* 3362 */       l = this.clobMsg.getChunkSize(paramCLOB.shareBytes());
/*      */     }
/* 3364 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3367 */       handleIOException(iOException);
/*      */       
/* 3369 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3370 */       sQLException.fillInStackTrace();
/* 3371 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3376 */     return (int)l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void trim(CLOB paramCLOB, long paramLong) throws SQLException {
/* 3390 */     assertLoggedOn("trim");
/* 3391 */     assertNotNull(paramCLOB.shareBytes(), "trim");
/*      */ 
/*      */     
/* 3394 */     if (paramLong < 0L) {
/*      */ 
/*      */       
/* 3397 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "trim()");
/* 3398 */       sQLException.fillInStackTrace();
/* 3399 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3404 */     needLine();
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 3409 */       paramCLOB.setActivePrefetch(false);
/* 3410 */       paramCLOB.clearCachedData();
/* 3411 */       this.clobMsg.trim(paramCLOB.shareBytes(), paramLong);
/*      */     }
/* 3413 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3416 */       handleIOException(iOException);
/*      */       
/* 3418 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3419 */       sQLException.fillInStackTrace();
/* 3420 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized CLOB createTemporaryClob(Connection paramConnection, boolean paramBoolean, int paramInt, short paramShort) throws SQLException {
/* 3443 */     assertLoggedOn("createTemporaryClob");
/*      */ 
/*      */     
/* 3446 */     if (paramShort != 2 && paramShort != 1) {
/*      */ 
/*      */ 
/*      */       
/* 3450 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 184);
/* 3451 */       sQLException.fillInStackTrace();
/* 3452 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3456 */     needLine();
/*      */     
/* 3458 */     CLOB cLOB = null;
/*      */ 
/*      */     
/*      */     try {
/* 3462 */       cLOB = (CLOB)this.clobMsg.createTemporaryLob((Connection)this, paramBoolean, paramInt, paramShort);
/*      */     
/*      */     }
/* 3465 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3468 */       handleIOException(iOException);
/*      */       
/* 3470 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3471 */       sQLException.fillInStackTrace();
/* 3472 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3477 */     return cLOB;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void freeTemporary(CLOB paramCLOB, boolean paramBoolean) throws SQLException {
/* 3492 */     assertLoggedOn("freeTemporary");
/* 3493 */     assertNotNull(paramCLOB.shareBytes(), "freeTemporary");
/*      */     
/* 3495 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3499 */       this.clobMsg.freeTemporaryLob(paramCLOB.shareBytes());
/*      */     }
/* 3501 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3504 */       handleIOException(iOException);
/*      */       
/* 3506 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3507 */       sQLException.fillInStackTrace();
/* 3508 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isTemporary(CLOB paramCLOB) throws SQLException {
/* 3529 */     boolean bool = false;
/* 3530 */     byte[] arrayOfByte = paramCLOB.shareBytes();
/*      */     
/* 3532 */     if ((arrayOfByte[7] & 0x1) > 0 || (arrayOfByte[4] & 0x40) > 0) {
/* 3533 */       bool = true;
/*      */     }
/* 3535 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void open(CLOB paramCLOB, int paramInt) throws SQLException {
/* 3548 */     assertLoggedOn("open");
/* 3549 */     assertNotNull(paramCLOB.shareBytes(), "open");
/*      */     
/* 3551 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3555 */       this.clobMsg.open(paramCLOB.shareBytes(), paramInt);
/*      */     }
/* 3557 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3560 */       handleIOException(iOException);
/*      */       
/* 3562 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3563 */       sQLException.fillInStackTrace();
/* 3564 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void close(CLOB paramCLOB) throws SQLException {
/* 3579 */     assertLoggedOn("close");
/* 3580 */     assertNotNull(paramCLOB.shareBytes(), "close");
/*      */     
/* 3582 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3586 */       this.clobMsg.close(paramCLOB.shareBytes());
/*      */     }
/* 3588 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3591 */       handleIOException(iOException);
/*      */       
/* 3593 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3594 */       sQLException.fillInStackTrace();
/* 3595 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized boolean isOpen(CLOB paramCLOB) throws SQLException {
/* 3611 */     assertLoggedOn("isOpen");
/* 3612 */     assertNotNull(paramCLOB.shareBytes(), "isOpen");
/*      */     
/* 3614 */     boolean bool = false;
/*      */     
/* 3616 */     needLine();
/*      */ 
/*      */     
/*      */     try {
/* 3620 */       bool = this.clobMsg.isOpen(paramCLOB.shareBytes());
/*      */     }
/* 3622 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3625 */       handleIOException(iOException);
/*      */       
/* 3627 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3628 */       sQLException.fillInStackTrace();
/* 3629 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3634 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream newInputStream(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 3653 */     if (paramLong == 0L)
/*      */     {
/* 3655 */       return new OracleClobInputStream(paramCLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3659 */     return new OracleClobInputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public OutputStream newOutputStream(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3680 */     if (paramLong == 0L) {
/*      */       
/* 3682 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3685 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3686 */         sQLException.fillInStackTrace();
/* 3687 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3692 */       return new OracleClobOutputStream(paramCLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3697 */     return new OracleClobOutputStream(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong) throws SQLException {
/* 3717 */     if (paramLong == 0L)
/*      */     {
/* 3719 */       return new OracleClobReader(paramCLOB, paramInt);
/*      */     }
/*      */ 
/*      */     
/* 3723 */     return new OracleClobReader(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Reader newReader(CLOB paramCLOB, int paramInt, long paramLong1, long paramLong2) throws SQLException {
/* 3744 */     return new OracleClobReader(paramCLOB, paramInt, paramLong1, paramLong2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Writer newWriter(CLOB paramCLOB, int paramInt, long paramLong, boolean paramBoolean) throws SQLException {
/* 3763 */     if (paramLong == 0L) {
/*      */       
/* 3765 */       if (paramBoolean & this.lobStreamPosStandardCompliant) {
/*      */ 
/*      */         
/* 3768 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 3769 */         sQLException.fillInStackTrace();
/* 3770 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3775 */       return new OracleClobWriter(paramCLOB, paramInt);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3780 */     return new OracleClobWriter(paramCLOB, paramInt, paramLong);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void assertLoggedOn(String paramString) throws SQLException {
/* 3806 */     if (!this.isLoggedOn) {
/*      */ 
/*      */       
/* 3809 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 430);
/* 3810 */       sQLException.fillInStackTrace();
/* 3811 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isLoggedOn() {
/* 3825 */     return this.isLoggedOn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void assertNotNull(byte[] paramArrayOfbyte, String paramString) throws NullPointerException {
/* 3841 */     if (paramArrayOfbyte == null)
/*      */     {
/* 3843 */       throw new NullPointerException("bytes are null");
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void internalClose() throws SQLException {
/* 3852 */     super.internalClose();
/*      */     
/* 3854 */     this.isLoggedOn = false;
/*      */     
/*      */     try {
/* 3857 */       if (this.net != null) {
/* 3858 */         this.net.disconnect();
/*      */       }
/* 3860 */     } catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doAbort() throws SQLException {
/*      */     try {
/* 3872 */       this.net.abort();
/*      */     }
/* 3874 */     catch (NetException netException) {
/*      */ 
/*      */ 
/*      */       
/* 3878 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), (IOException)netException);
/* 3879 */       sQLException.fillInStackTrace();
/* 3880 */       throw sQLException;
/*      */ 
/*      */     
/*      */     }
/* 3884 */     catch (IOException iOException) {
/*      */ 
/*      */       
/* 3887 */       handleIOException(iOException);
/*      */       
/* 3889 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3890 */       sQLException.fillInStackTrace();
/* 3891 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void doDescribeTable(AutoKeyInfo paramAutoKeyInfo) throws SQLException {
/* 3902 */     T4CStatement t4CStatement = new T4CStatement(this, -1, -1);
/* 3903 */     t4CStatement.open();
/*      */     
/* 3905 */     String str1 = paramAutoKeyInfo.getTableName();
/* 3906 */     String str2 = "SELECT * FROM " + str1;
/*      */     
/* 3908 */     t4CStatement.sqlObject.initialize(str2);
/*      */     
/* 3910 */     Accessor[] arrayOfAccessor = null;
/*      */ 
/*      */     
/*      */     try {
/* 3914 */       this.describe.doODNY(t4CStatement, 0, arrayOfAccessor, t4CStatement.sqlObject.getSqlBytes(false, false));
/* 3915 */       arrayOfAccessor = this.describe.getAccessors();
/*      */     }
/* 3917 */     catch (IOException iOException) {
/*      */       
/* 3919 */       handleIOException(iOException);
/*      */       
/* 3921 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3922 */       sQLException.fillInStackTrace();
/* 3923 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */     
/* 3927 */     int i = this.describe.numuds;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3938 */     paramAutoKeyInfo.allocateSpaceForDescribedData(i);
/*      */     
/* 3940 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 3942 */       Accessor accessor = arrayOfAccessor[b];
/* 3943 */       String str3 = accessor.columnName;
/* 3944 */       int j = accessor.describeType;
/* 3945 */       int k = accessor.describeMaxLength;
/* 3946 */       boolean bool = accessor.nullable;
/* 3947 */       short s = accessor.formOfUse;
/* 3948 */       int m = accessor.precision;
/* 3949 */       int n = accessor.scale;
/* 3950 */       String str4 = accessor.describeTypeName;
/*      */       
/* 3952 */       paramAutoKeyInfo.fillDescribedData(b, str3, j, k, bool, s, m, n, str4);
/*      */     } 
/*      */ 
/*      */     
/* 3956 */     t4CStatement.close();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doSetApplicationContext(String paramString1, String paramString2, String paramString3) throws SQLException {
/* 3967 */     Namespace namespace = (Namespace)this.namespaces.get(paramString1);
/* 3968 */     if (namespace == null) {
/*      */       
/* 3970 */       namespace = new Namespace(paramString1);
/* 3971 */       this.namespaces.put(paramString1, namespace);
/*      */     } 
/* 3973 */     namespace.setAttribute(paramString2, paramString3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void doClearAllApplicationContext(String paramString) throws SQLException {
/* 3982 */     Namespace namespace = new Namespace(paramString);
/* 3983 */     namespace.clear();
/* 3984 */     this.namespaces.put(paramString, namespace);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void getPropertyForPooledConnection(OraclePooledConnection paramOraclePooledConnection) throws SQLException {
/* 3992 */     getPropertyForPooledConnection(paramOraclePooledConnection, this.password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final void getPasswordInternal(T4CXAResource paramT4CXAResource) throws SQLException {
/* 4000 */     paramT4CXAResource.setPasswordInternal(this.password);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doEnqueue(String paramString, AQEnqueueOptions paramAQEnqueueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[][] paramArrayOfbyte, boolean paramBoolean) throws SQLException {
/*      */     try {
/* 4018 */       needLine();
/* 4019 */       sendPiggyBackedMessages();
/* 4020 */       this.aqe.doOAQEQ(paramString, paramAQEnqueueOptions, paramAQMessagePropertiesI, paramArrayOfbyte2, paramArrayOfbyte1, paramBoolean);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4027 */       if (paramAQEnqueueOptions.getRetrieveMessageId()) {
/* 4028 */         paramArrayOfbyte[0] = this.aqe.getMessageId();
/*      */       }
/* 4030 */     } catch (IOException iOException) {
/*      */       
/* 4032 */       handleIOException(iOException);
/*      */       
/* 4034 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4035 */       sQLException.fillInStackTrace();
/* 4036 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized boolean doDequeue(String paramString, AQDequeueOptions paramAQDequeueOptions, AQMessagePropertiesI paramAQMessagePropertiesI, byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1, byte[][] paramArrayOfbyte2, boolean paramBoolean) throws SQLException {
/* 4053 */     boolean bool = false;
/*      */     
/*      */     try {
/* 4056 */       needLine();
/* 4057 */       sendPiggyBackedMessages();
/* 4058 */       this.aqdq.doOAQDQ(paramString, paramAQDequeueOptions, paramArrayOfbyte, paramBoolean, paramAQMessagePropertiesI);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4064 */       paramArrayOfbyte1[0] = this.aqdq.getPayload();
/* 4065 */       paramArrayOfbyte2[0] = this.aqdq.getDequeuedMessageId();
/* 4066 */       bool = this.aqdq.hasAMessageBeenDequeued();
/*      */     }
/* 4068 */     catch (IOException iOException) {
/*      */       
/* 4070 */       handleIOException(iOException);
/*      */       
/* 4072 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4073 */       sQLException.fillInStackTrace();
/* 4074 */       throw sQLException;
/*      */     } 
/*      */     
/* 4077 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized int doPingDatabase() throws SQLException {
/* 4084 */     if (this.versionNumber >= 10102) {
/*      */ 
/*      */       
/*      */       try {
/* 4088 */         needLine();
/* 4089 */         sendPiggyBackedMessages();
/* 4090 */         this.oping.doOPING();
/*      */       }
/* 4092 */       catch (IOException iOException) {
/*      */         
/* 4094 */         return -1;
/*      */       }
/* 4096 */       catch (SQLException sQLException) {
/*      */         
/* 4098 */         return -1;
/*      */       } 
/* 4100 */       return 0;
/*      */     } 
/*      */ 
/*      */     
/* 4104 */     return super.doPingDatabase();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized NTFAQRegistration[] doRegisterAQNotification(String[] paramArrayOfString, String paramString, int paramInt, Properties[] paramArrayOfProperties) throws SQLException {
/* 4117 */     int i = paramArrayOfString.length;
/* 4118 */     int[] arrayOfInt1 = new int[i];
/* 4119 */     byte[][] arrayOfByte = new byte[i][];
/* 4120 */     int[] arrayOfInt2 = new int[i];
/* 4121 */     int[] arrayOfInt3 = new int[i];
/* 4122 */     int[] arrayOfInt4 = new int[i];
/* 4123 */     int[] arrayOfInt5 = new int[i];
/* 4124 */     int[] arrayOfInt6 = new int[i];
/* 4125 */     int[] arrayOfInt7 = new int[i];
/* 4126 */     long[] arrayOfLong = new long[i];
/* 4127 */     byte[] arrayOfByte1 = new byte[i];
/* 4128 */     int[] arrayOfInt8 = new int[i];
/* 4129 */     byte[] arrayOfByte2 = new byte[i];
/* 4130 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = new TIMESTAMPTZ[i];
/* 4131 */     int[] arrayOfInt9 = new int[i];
/*      */     
/* 4133 */     boolean bool = false;
/* 4134 */     if (paramInt == 0) {
/*      */ 
/*      */       
/* 4137 */       bool = true;
/* 4138 */       paramInt = 47632;
/*      */     } 
/*      */     
/* 4141 */     for (byte b1 = 0; b1 < i; b1++) {
/*      */       
/* 4143 */       arrayOfInt1[b1] = PhysicalConnection.ntfManager.getNextJdbcRegId();
/* 4144 */       arrayOfByte[b1] = new byte[4];
/* 4145 */       arrayOfByte[b1][0] = (byte)((arrayOfInt1[b1] & 0xFF000000) >> 24);
/* 4146 */       arrayOfByte[b1][1] = (byte)((arrayOfInt1[b1] & 0xFF0000) >> 16);
/* 4147 */       arrayOfByte[b1][2] = (byte)((arrayOfInt1[b1] & 0xFF00) >> 8);
/* 4148 */       arrayOfByte[b1][3] = (byte)(arrayOfInt1[b1] & 0xFF);
/* 4149 */       arrayOfInt2[b1] = 1;
/* 4150 */       arrayOfInt3[b1] = 23;
/*      */ 
/*      */       
/* 4153 */       if (paramArrayOfProperties.length > b1 && paramArrayOfProperties[b1] != null) {
/*      */         
/* 4155 */         if (paramArrayOfProperties[b1].getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4157 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x1; } 
/* 4158 */         if (paramArrayOfProperties[b1].getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4160 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x10; } 
/* 4161 */         if (paramArrayOfProperties[b1].getProperty("NTF_AQ_PAYLOAD", "false").compareToIgnoreCase("true") == 0)
/*      */         {
/* 4163 */           arrayOfInt4[b1] = arrayOfInt4[b1] | 0x2; } 
/* 4164 */         arrayOfInt5[b1] = readNTFtimeout(paramArrayOfProperties[b1]);
/*      */       } 
/*      */     } 
/*      */     
/* 4168 */     setNtfGroupingOptions(arrayOfByte1, arrayOfInt8, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt9, paramArrayOfProperties);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4175 */     int[] arrayOfInt10 = new int[1];
/* 4176 */     arrayOfInt10[0] = paramInt;
/*      */ 
/*      */ 
/*      */     
/* 4180 */     boolean bool1 = PhysicalConnection.ntfManager.listenOnPortT4C(arrayOfInt10, bool);
/* 4181 */     paramInt = arrayOfInt10[0];
/*      */     
/* 4183 */     String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt + "))?PR=0";
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*      */       try {
/* 4190 */         boolean bool2 = bool1 ? true : false;
/* 4191 */         sendPiggyBackedMessages();
/* 4192 */         this.okpn.doOKPN(1, bool2, this.userName, str, i, arrayOfInt2, paramArrayOfString, arrayOfByte, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfInt7, arrayOfLong, arrayOfByte1, arrayOfInt8, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt9);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*      */       }
/* 4214 */       catch (IOException iOException) {
/*      */         
/* 4216 */         handleIOException(iOException);
/*      */         
/* 4218 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4219 */         sQLException.fillInStackTrace();
/* 4220 */         throw sQLException;
/*      */       }
/*      */     
/*      */     }
/* 4224 */     catch (SQLException sQLException) {
/*      */       
/* 4226 */       if (bool1) {
/* 4227 */         PhysicalConnection.ntfManager.cleanListenersT4C(paramInt);
/*      */       }
/* 4229 */       throw sQLException;
/*      */     } 
/* 4231 */     NTFAQRegistration[] arrayOfNTFAQRegistration = new NTFAQRegistration[i];
/*      */     byte b2;
/* 4233 */     for (b2 = 0; b2 < i; b2++) {
/* 4234 */       arrayOfNTFAQRegistration[b2] = new NTFAQRegistration(arrayOfInt1[b2], true, this.instanceName, this.userName, paramString, paramInt, paramArrayOfProperties[b2], paramArrayOfString[b2], this.versionNumber);
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4244 */     for (b2 = 0; b2 < arrayOfNTFAQRegistration.length; b2++)
/* 4245 */       PhysicalConnection.ntfManager.addRegistration(arrayOfNTFAQRegistration[b2]); 
/* 4246 */     return arrayOfNTFAQRegistration;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setNtfGroupingOptions(byte[] paramArrayOfbyte1, int[] paramArrayOfint1, byte[] paramArrayOfbyte2, TIMESTAMPTZ[] paramArrayOfTIMESTAMPTZ, int[] paramArrayOfint2, Properties[] paramArrayOfProperties) throws SQLException {
/* 4265 */     for (byte b = 0; b < paramArrayOfProperties.length; b++) {
/*      */       
/* 4267 */       String str1 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_CLASS", "NTF_GROUPING_CLASS_NONE");
/* 4268 */       String str2 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_VALUE");
/* 4269 */       String str3 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_TYPE");
/* 4270 */       TIMESTAMPTZ tIMESTAMPTZ = null;
/* 4271 */       if (paramArrayOfProperties[b].get("NTF_GROUPING_START_TIME") != null)
/* 4272 */         tIMESTAMPTZ = (TIMESTAMPTZ)paramArrayOfProperties[b].get("NTF_GROUPING_START_TIME"); 
/* 4273 */       String str4 = paramArrayOfProperties[b].getProperty("NTF_GROUPING_REPEAT_TIME", "NTF_GROUPING_REPEAT_FOREVER");
/*      */ 
/*      */       
/* 4276 */       if (str1.compareTo("NTF_GROUPING_CLASS_TIME") != 0 && str1.compareTo("NTF_GROUPING_CLASS_NONE") != 0) {
/*      */ 
/*      */ 
/*      */         
/* 4280 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4281 */         sQLException.fillInStackTrace();
/* 4282 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 4287 */       if (str1.compareTo("NTF_GROUPING_CLASS_NONE") != 0 && getTTCVersion() < 5) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4292 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23);
/* 4293 */         sQLException.fillInStackTrace();
/* 4294 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 4300 */       if (str1.compareTo("NTF_GROUPING_CLASS_TIME") == 0) {
/*      */         
/* 4302 */         paramArrayOfbyte1[b] = 1;
/*      */         
/* 4304 */         paramArrayOfint1[b] = 600;
/* 4305 */         if (str2 != null) {
/* 4306 */           paramArrayOfint1[b] = Integer.parseInt(str2);
/*      */         }
/* 4308 */         paramArrayOfbyte2[b] = 1;
/* 4309 */         if (str3 != null)
/*      */         {
/* 4311 */           if (str3.compareTo("NTF_GROUPING_TYPE_SUMMARY") == 0) {
/* 4312 */             paramArrayOfbyte2[b] = 1;
/* 4313 */           } else if (str3.compareTo("NTF_GROUPING_TYPE_LAST") == 0) {
/* 4314 */             paramArrayOfbyte2[b] = 2;
/*      */           
/*      */           }
/*      */           else {
/*      */ 
/*      */             
/* 4320 */             SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4321 */             sQLException.fillInStackTrace();
/* 4322 */             throw sQLException;
/*      */           } 
/*      */         }
/*      */ 
/*      */         
/* 4327 */         paramArrayOfTIMESTAMPTZ[b] = tIMESTAMPTZ;
/* 4328 */         if (str4.compareTo("NTF_GROUPING_REPEAT_FOREVER") == 0) {
/* 4329 */           paramArrayOfint2[b] = 0;
/*      */         } else {
/* 4331 */           paramArrayOfint2[b] = Integer.parseInt(str4);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterAQNotification(NTFAQRegistration paramNTFAQRegistration) throws SQLException {
/* 4343 */     String str1 = paramNTFAQRegistration.getClientHost();
/* 4344 */     int i = paramNTFAQRegistration.getClientTCPPort();
/* 4345 */     if (str1 == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4356 */     PhysicalConnection.ntfManager.removeRegistration(paramNTFAQRegistration);
/* 4357 */     PhysicalConnection.ntfManager.freeJdbcRegId(paramNTFAQRegistration.getJdbcRegId());
/* 4358 */     PhysicalConnection.ntfManager.cleanListenersT4C(paramNTFAQRegistration.getClientTCPPort());
/* 4359 */     paramNTFAQRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
/*      */     
/* 4361 */     String str2 = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + str1 + ")(PORT=" + i + "))?PR=0";
/*      */ 
/*      */     
/* 4364 */     int[] arrayOfInt1 = { 1 };
/* 4365 */     String[] arrayOfString = new String[1];
/* 4366 */     arrayOfString[0] = paramNTFAQRegistration.getQueueName();
/* 4367 */     int[] arrayOfInt2 = { 0 };
/* 4368 */     int[] arrayOfInt3 = { 0 };
/* 4369 */     int[] arrayOfInt4 = { 0 };
/* 4370 */     int[] arrayOfInt5 = { 0 };
/* 4371 */     int[] arrayOfInt6 = { 0 };
/* 4372 */     long[] arrayOfLong = { 0L };
/* 4373 */     byte[] arrayOfByte1 = { 0 };
/* 4374 */     int[] arrayOfInt7 = { 0 };
/* 4375 */     byte[] arrayOfByte2 = { 0 };
/* 4376 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = { null };
/* 4377 */     int[] arrayOfInt8 = { 0 };
/* 4378 */     byte[][] arrayOfByte = new byte[1][];
/* 4379 */     int j = paramNTFAQRegistration.getJdbcRegId();
/* 4380 */     arrayOfByte[0] = new byte[4];
/* 4381 */     arrayOfByte[0][0] = (byte)((j & 0xFF000000) >> 24);
/* 4382 */     arrayOfByte[0][1] = (byte)((j & 0xFF0000) >> 16);
/* 4383 */     arrayOfByte[0][2] = (byte)((j & 0xFF00) >> 8);
/* 4384 */     arrayOfByte[0][3] = (byte)(j & 0xFF);
/*      */     
/*      */     try {
/* 4387 */       sendPiggyBackedMessages();
/* 4388 */       this.okpn.doOKPN(2, 0, this.userName, str2, 1, arrayOfInt1, arrayOfString, arrayOfByte, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfLong, arrayOfByte1, arrayOfInt7, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 4410 */     catch (IOException iOException) {
/*      */       
/* 4412 */       handleIOException(iOException);
/*      */       
/* 4414 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4415 */       sQLException.fillInStackTrace();
/* 4416 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized NTFDCNRegistration doRegisterDatabaseChangeNotification(String paramString, int paramInt1, Properties paramProperties, int paramInt2, int paramInt3) throws SQLException {
/* 4432 */     int i = 0;
/* 4433 */     int j = 0;
/* 4434 */     boolean bool1 = false;
/* 4435 */     boolean bool2 = false;
/* 4436 */     boolean bool3 = false;
/* 4437 */     Object object = null;
/* 4438 */     boolean bool4 = false;
/* 4439 */     boolean bool5 = false;
/* 4440 */     if (paramInt1 == 0) {
/*      */ 
/*      */       
/* 4443 */       bool5 = true;
/* 4444 */       paramInt1 = 47632;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4449 */     if (paramProperties.getProperty("NTF_QOS_RELIABLE", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4451 */       j |= 0x1; } 
/* 4452 */     if (paramProperties.getProperty("NTF_QOS_PURGE_ON_NTFN", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4454 */       j |= 0x10;
/*      */     }
/*      */ 
/*      */     
/* 4458 */     if (paramProperties.getProperty("DCN_NOTIFY_ROWIDS", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4460 */       i |= 0x10;
/*      */     }
/*      */     
/* 4463 */     if (paramProperties.getProperty("DCN_QUERY_CHANGE_NOTIFICATION", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4465 */       i |= 0x20;
/*      */     }
/*      */     
/* 4468 */     if (paramProperties.getProperty("DCN_BEST_EFFORT", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4470 */       i |= 0x40;
/*      */     }
/* 4472 */     boolean bool6 = false;
/* 4473 */     boolean bool7 = false;
/* 4474 */     boolean bool8 = false;
/* 4475 */     if (paramProperties.getProperty("DCN_IGNORE_INSERTOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4477 */       bool6 = true; } 
/* 4478 */     if (paramProperties.getProperty("DCN_IGNORE_UPDATEOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4480 */       bool7 = true; } 
/* 4481 */     if (paramProperties.getProperty("DCN_IGNORE_DELETEOP", "false").compareToIgnoreCase("true") == 0)
/*      */     {
/* 4483 */       bool8 = true;
/*      */     }
/* 4485 */     if (bool6 || bool7 || bool8) {
/*      */       
/* 4487 */       i |= 0xF;
/*      */ 
/*      */ 
/*      */       
/* 4491 */       if (bool6)
/* 4492 */         i -= 2; 
/* 4493 */       if (bool7)
/* 4494 */         i -= 4; 
/* 4495 */       if (bool8) {
/* 4496 */         i -= 8;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 4502 */     byte[] arrayOfByte1 = new byte[1];
/* 4503 */     int[] arrayOfInt1 = new int[1];
/* 4504 */     byte[] arrayOfByte2 = new byte[1];
/* 4505 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = new TIMESTAMPTZ[1];
/* 4506 */     int[] arrayOfInt2 = new int[1];
/* 4507 */     Properties[] arrayOfProperties = { paramProperties };
/* 4508 */     setNtfGroupingOptions(arrayOfByte1, arrayOfInt1, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt2, arrayOfProperties);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4524 */     int[] arrayOfInt3 = new int[1];
/* 4525 */     arrayOfInt3[0] = paramInt1;
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 4530 */     boolean bool = PhysicalConnection.ntfManager.listenOnPortT4C(arrayOfInt3, bool5);
/* 4531 */     paramInt1 = arrayOfInt3[0];
/*      */     
/* 4533 */     String str = "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramString + ")(PORT=" + paramInt1 + "))?PR=0";
/*      */ 
/*      */ 
/*      */     
/* 4537 */     int[] arrayOfInt4 = { 2 };
/* 4538 */     String[] arrayOfString = new String[1];
/* 4539 */     int[] arrayOfInt5 = { 23 };
/*      */ 
/*      */     
/* 4542 */     int[] arrayOfInt6 = { j };
/* 4543 */     int[] arrayOfInt7 = { paramInt2 };
/* 4544 */     int[] arrayOfInt8 = { i };
/* 4545 */     int[] arrayOfInt9 = { paramInt3 };
/* 4546 */     long[] arrayOfLong = { 0L };
/* 4547 */     int k = PhysicalConnection.ntfManager.getNextJdbcRegId();
/* 4548 */     byte[][] arrayOfByte = new byte[1][];
/* 4549 */     arrayOfByte[0] = new byte[4];
/* 4550 */     arrayOfByte[0][0] = (byte)((k & 0xFF000000) >> 24);
/* 4551 */     arrayOfByte[0][1] = (byte)((k & 0xFF0000) >> 16);
/* 4552 */     arrayOfByte[0][2] = (byte)((k & 0xFF00) >> 8);
/* 4553 */     arrayOfByte[0][3] = (byte)(k & 0xFF);
/* 4554 */     long l = 0L;
/*      */ 
/*      */     
/*      */     try {
/*      */       try {
/* 4559 */         boolean bool9 = bool ? true : false;
/* 4560 */         sendPiggyBackedMessages();
/* 4561 */         this.okpn.doOKPN(1, bool9, this.userName, str, 1, arrayOfInt4, arrayOfString, arrayOfByte, arrayOfInt5, arrayOfInt6, arrayOfInt7, arrayOfInt8, arrayOfInt9, arrayOfLong, arrayOfByte1, arrayOfInt1, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt2);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 4582 */         l = this.okpn.getRegistrationId();
/*      */       }
/* 4584 */       catch (IOException iOException) {
/*      */         
/* 4586 */         handleIOException(iOException);
/*      */         
/* 4588 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4589 */         sQLException.fillInStackTrace();
/* 4590 */         throw sQLException;
/*      */       }
/*      */     
/*      */     }
/* 4594 */     catch (SQLException sQLException) {
/*      */       
/* 4596 */       if (bool) {
/* 4597 */         PhysicalConnection.ntfManager.cleanListenersT4C(paramInt1);
/*      */       }
/* 4599 */       throw sQLException;
/*      */     } 
/* 4601 */     return new NTFDCNRegistration(k, true, this.instanceName, l, this.userName, paramString, paramInt1, paramProperties, this.versionNumber);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterDatabaseChangeNotification(long paramLong, String paramString) throws SQLException {
/* 4625 */     int[] arrayOfInt1 = { 2 };
/* 4626 */     String[] arrayOfString = new String[1];
/* 4627 */     int[] arrayOfInt2 = { 0 };
/* 4628 */     int[] arrayOfInt3 = { 0 };
/* 4629 */     int[] arrayOfInt4 = { 0 };
/* 4630 */     int[] arrayOfInt5 = { 0 };
/* 4631 */     int[] arrayOfInt6 = { 0 };
/* 4632 */     byte[] arrayOfByte1 = { 0 };
/* 4633 */     int[] arrayOfInt7 = { 0 };
/* 4634 */     byte[] arrayOfByte2 = { 0 };
/* 4635 */     TIMESTAMPTZ[] arrayOfTIMESTAMPTZ = { null };
/* 4636 */     int[] arrayOfInt8 = { 0 };
/* 4637 */     long[] arrayOfLong = { paramLong };
/* 4638 */     byte[][] arrayOfByte = new byte[1][];
/*      */     
/*      */     try {
/* 4641 */       sendPiggyBackedMessages();
/* 4642 */       this.okpn.doOKPN(2, 0, null, paramString, 1, arrayOfInt1, arrayOfString, arrayOfByte, arrayOfInt2, arrayOfInt3, arrayOfInt4, arrayOfInt5, arrayOfInt6, arrayOfLong, arrayOfByte1, arrayOfInt7, arrayOfByte2, arrayOfTIMESTAMPTZ, arrayOfInt8);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     }
/* 4664 */     catch (IOException iOException) {
/*      */       
/* 4666 */       handleIOException(iOException);
/*      */       
/* 4668 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4669 */       sQLException.fillInStackTrace();
/* 4670 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   synchronized void doUnregisterDatabaseChangeNotification(NTFDCNRegistration paramNTFDCNRegistration) throws SQLException {
/* 4683 */     PhysicalConnection.ntfManager.removeRegistration(paramNTFDCNRegistration);
/* 4684 */     PhysicalConnection.ntfManager.freeJdbcRegId(paramNTFDCNRegistration.getJdbcRegId());
/* 4685 */     PhysicalConnection.ntfManager.cleanListenersT4C(paramNTFDCNRegistration.getClientTCPPort());
/* 4686 */     paramNTFDCNRegistration.setState(NotificationRegistration.RegistrationState.CLOSED);
/*      */     
/* 4688 */     doUnregisterDatabaseChangeNotification(paramNTFDCNRegistration.getRegId(), "(ADDRESS=(PROTOCOL=tcp)(HOST=" + paramNTFDCNRegistration.getClientHost() + ")(PORT=" + paramNTFDCNRegistration.getClientTCPPort() + "))?PR=0");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getDataIntegrityAlgorithmName() throws SQLException {
/* 4698 */     return this.net.getDataIntegrityName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getEncryptionAlgorithmName() throws SQLException {
/* 4705 */     return this.net.getEncryptionName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getAuthenticationAdaptorName() throws SQLException {
/* 4712 */     return this.net.getAuthenticationAdaptorName();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void validateConnectionProperties() throws SQLException {
/* 4727 */     super.validateConnectionProperties();
/*      */     
/* 4729 */     String str = ".*[\\00\\(\\)].*";
/* 4730 */     if (this.thinVsessionOsuser != null && (this.thinVsessionOsuser.matches(str) || this.thinVsessionOsuser.length() > 30)) {
/*      */ 
/*      */ 
/*      */       
/* 4734 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.osuser' and value is '" + this.thinVsessionOsuser + "'");
/* 4735 */       sQLException.fillInStackTrace();
/* 4736 */       throw sQLException;
/*      */     } 
/*      */     
/* 4739 */     if (this.thinVsessionTerminal != null && (this.thinVsessionTerminal.matches(str) || this.thinVsessionTerminal.length() > 30)) {
/*      */ 
/*      */ 
/*      */       
/* 4743 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.terminal' and value is '" + this.thinVsessionTerminal + "'");
/* 4744 */       sQLException.fillInStackTrace();
/* 4745 */       throw sQLException;
/*      */     } 
/*      */     
/* 4748 */     if (this.thinVsessionMachine != null && (this.thinVsessionMachine.matches(str) || this.thinVsessionMachine.length() > 64)) {
/*      */ 
/*      */ 
/*      */       
/* 4752 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.machine' and value is '" + this.thinVsessionMachine + "'");
/* 4753 */       sQLException.fillInStackTrace();
/* 4754 */       throw sQLException;
/*      */     } 
/*      */     
/* 4757 */     if (this.thinVsessionProgram != null && (this.thinVsessionProgram.matches(str) || this.thinVsessionProgram.length() > 48)) {
/*      */ 
/*      */ 
/*      */       
/* 4761 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.program' and value is '" + this.thinVsessionProgram + "'");
/* 4762 */       sQLException.fillInStackTrace();
/* 4763 */       throw sQLException;
/*      */     } 
/*      */     
/* 4766 */     if (this.thinVsessionProcess != null && (this.thinVsessionProcess.matches(str) || this.thinVsessionProcess.length() > 24)) {
/*      */ 
/*      */ 
/*      */       
/* 4770 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.process' and value is '" + this.thinVsessionProcess + "'");
/* 4771 */       sQLException.fillInStackTrace();
/* 4772 */       throw sQLException;
/*      */     } 
/*      */     
/* 4775 */     if (this.thinVsessionIname != null && this.thinVsessionIname.matches(str)) {
/*      */       
/* 4777 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.iname' and value is '" + this.thinVsessionIname + "'");
/* 4778 */       sQLException.fillInStackTrace();
/* 4779 */       throw sQLException;
/*      */     } 
/*      */     
/* 4782 */     if (this.thinVsessionEname != null && this.thinVsessionEname.matches(str)) {
/*      */       
/* 4784 */       SQLException sQLException = DatabaseError.createSqlException((OracleConnection)null, 190, "Property is 'v$session.ename' and value is '" + this.thinVsessionEname + "'");
/* 4785 */       sQLException.fillInStackTrace();
/* 4786 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 4792 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static final boolean TRACE = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized byte[] createLightweightSession(String paramString, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException {
/* 4806 */     if (paramArrayOfKeywordValueLong1.length != 1 || paramArrayOfint.length != 1) {
/*      */       
/* 4808 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4809 */       sQLException.fillInStackTrace();
/* 4810 */       throw sQLException;
/*      */     } 
/*      */     
/* 4813 */     byte[] arrayOfByte = null;
/*      */     
/*      */     try {
/* 4816 */       sendPiggyBackedMessages();
/* 4817 */       this.oxsscs.doOXSSCS(paramString, paramArrayOfKeywordValueLong, paramInt);
/* 4818 */       arrayOfByte = this.oxsscs.getSessionId();
/* 4819 */       paramArrayOfKeywordValueLong1[0] = this.oxsscs.getOutKV();
/* 4820 */       paramArrayOfint[0] = this.oxsscs.getOutFlags();
/*      */     }
/* 4822 */     catch (IOException iOException) {
/*      */       
/* 4824 */       handleIOException(iOException);
/*      */       
/* 4826 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4827 */       sQLException.fillInStackTrace();
/* 4828 */       throw sQLException;
/*      */     } 
/*      */     
/* 4831 */     return arrayOfByte;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1, boolean paramBoolean) throws SQLException {
/* 4847 */     XSNamespace[] arrayOfXSNamespace = null;
/*      */     
/*      */     try {
/* 4850 */       if (paramBoolean)
/* 4851 */         sendPiggyBackedMessages(); 
/* 4852 */       this.xsnsop.doOXSNS(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, paramBoolean);
/* 4853 */       if (paramBoolean) {
/* 4854 */         arrayOfXSNamespace = this.xsnsop.getNamespaces();
/*      */       }
/* 4856 */     } catch (IOException iOException) {
/*      */       
/* 4858 */       handleIOException(iOException);
/*      */       
/* 4860 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4861 */       sQLException.fillInStackTrace();
/* 4862 */       throw sQLException;
/*      */     } 
/*      */     
/* 4865 */     if (paramArrayOfXSNamespace1 != null && paramArrayOfXSNamespace1.length > 0) {
/* 4866 */       paramArrayOfXSNamespace1[0] = arrayOfXSNamespace;
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace, XSNamespace[][] paramArrayOfXSNamespace1) throws SQLException {
/* 4880 */     doXSNamespaceOp(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, paramArrayOfXSNamespace1, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void doXSNamespaceOp(OracleConnection.XSOperationCode paramXSOperationCode, byte[] paramArrayOfbyte, XSNamespace[] paramArrayOfXSNamespace) throws SQLException {
/* 4892 */     doXSNamespaceOp(paramXSOperationCode, paramArrayOfbyte, paramArrayOfXSNamespace, (XSNamespace[][])null, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void executeLightweightSessionRoundtrip(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2, KeywordValueLong[][] paramArrayOfKeywordValueLong1, int[] paramArrayOfint) throws SQLException {
/* 4904 */     if (paramArrayOfKeywordValueLong1.length != 1 || paramArrayOfint.length != 1) {
/*      */       
/* 4906 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68);
/* 4907 */       sQLException.fillInStackTrace();
/* 4908 */       throw sQLException;
/*      */     } 
/*      */     
/*      */     try {
/* 4912 */       sendPiggyBackedMessages();
/* 4913 */       this.oxssro.doOXSSRO(paramInt1, paramArrayOfbyte, paramArrayOfKeywordValueLong, paramInt2);
/* 4914 */       paramArrayOfKeywordValueLong1[0] = this.oxssro.getOutKV();
/* 4915 */       paramArrayOfint[0] = this.oxssro.getOutFlags();
/*      */     }
/* 4917 */     catch (IOException iOException) {
/*      */       
/* 4919 */       handleIOException(iOException);
/*      */       
/* 4921 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 4922 */       sQLException.fillInStackTrace();
/* 4923 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public synchronized void executeLightweightSessionPiggyback(int paramInt1, byte[] paramArrayOfbyte, KeywordValueLong[] paramArrayOfKeywordValueLong, int paramInt2) throws SQLException {
/* 4936 */     if (this.lusOffset2 == this.lusFunctionId2.length) {
/*      */       
/* 4938 */       int i = this.lusFunctionId2.length;
/* 4939 */       int[] arrayOfInt1 = new int[i * 2];
/* 4940 */       System.arraycopy(this.lusFunctionId2, 0, arrayOfInt1, 0, i);
/* 4941 */       byte[][] arrayOfByte = new byte[i * 2][];
/* 4942 */       System.arraycopy(this.lusSessionId2, 0, arrayOfByte, 0, i);
/* 4943 */       KeywordValueLong[][] arrayOfKeywordValueLong = new KeywordValueLong[i * 2][];
/* 4944 */       System.arraycopy(this.lusInKeyVal2, 0, arrayOfKeywordValueLong, 0, i);
/* 4945 */       int[] arrayOfInt2 = new int[i * 2];
/* 4946 */       System.arraycopy(this.lusInFlags2, 0, arrayOfInt2, 0, i);
/* 4947 */       this.lusFunctionId2 = arrayOfInt1;
/* 4948 */       this.lusSessionId2 = arrayOfByte;
/* 4949 */       this.lusInKeyVal2 = arrayOfKeywordValueLong;
/* 4950 */       this.lusInFlags2 = arrayOfInt2;
/*      */     } 
/* 4952 */     this.lusFunctionId2[this.lusOffset2] = paramInt1;
/* 4953 */     this.lusSessionId2[this.lusOffset2] = paramArrayOfbyte;
/* 4954 */     this.lusInKeyVal2[this.lusOffset2] = paramArrayOfKeywordValueLong;
/* 4955 */     this.lusInFlags2[this.lusOffset2] = paramInt2;
/* 4956 */     this.lusOffset2++;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener, Executor paramExecutor) throws SQLException {
/* 4967 */     if (this.lifecycle != 1) {
/*      */       
/* 4969 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 8);
/* 4970 */       sQLException.fillInStackTrace();
/* 4971 */       throw sQLException;
/*      */     } 
/*      */     
/* 4974 */     NTFEventListener nTFEventListener = new NTFEventListener(paramXSEventListener);
/* 4975 */     nTFEventListener.setExecutor(paramExecutor);
/* 4976 */     synchronized (this.xsListeners) {
/*      */       
/* 4978 */       int i = this.xsListeners.length;
/* 4979 */       for (byte b = 0; b < i; b++) {
/* 4980 */         if (this.xsListeners[b].getXSEventListener() == paramXSEventListener) {
/*      */ 
/*      */ 
/*      */           
/* 4984 */           SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 248);
/* 4985 */           sQLException.fillInStackTrace();
/* 4986 */           throw sQLException;
/*      */         } 
/*      */       } 
/*      */       
/* 4990 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i + 1];
/* 4991 */       System.arraycopy(this.xsListeners, 0, arrayOfNTFEventListener, 0, i);
/*      */       
/* 4993 */       arrayOfNTFEventListener[i] = nTFEventListener;
/*      */       
/* 4995 */       this.xsListeners = arrayOfNTFEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void addXSEventListener(XSEventListener paramXSEventListener) throws SQLException {
/* 5006 */     addXSEventListener(paramXSEventListener, (Executor)null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeXSEventListener(XSEventListener paramXSEventListener) throws SQLException {
/* 5014 */     synchronized (this.xsListeners) {
/*      */ 
/*      */       
/* 5017 */       byte b1 = 0;
/* 5018 */       int i = this.xsListeners.length;
/*      */       
/* 5020 */       for (b1 = 0; b1 < i && 
/* 5021 */         this.xsListeners[b1].getXSEventListener() != paramXSEventListener; b1++);
/*      */       
/* 5023 */       if (b1 == i) {
/*      */ 
/*      */ 
/*      */         
/* 5027 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 249);
/* 5028 */         sQLException.fillInStackTrace();
/* 5029 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */       
/* 5033 */       NTFEventListener[] arrayOfNTFEventListener = new NTFEventListener[i - 1];
/* 5034 */       byte b2 = 0;
/* 5035 */       for (b1 = 0; b1 < i; b1++) {
/* 5036 */         if (this.xsListeners[b1].getXSEventListener() != paramXSEventListener) {
/* 5037 */           arrayOfNTFEventListener[b2++] = this.xsListeners[b1];
/*      */         }
/*      */       } 
/* 5040 */       this.xsListeners = arrayOfNTFEventListener;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void notify(final NTFXSEvent event) {
/* 5053 */     NTFEventListener[] arrayOfNTFEventListener = this.xsListeners;
/*      */ 
/*      */ 
/*      */     
/* 5057 */     int i = arrayOfNTFEventListener.length;
/* 5058 */     for (byte b = 0; b < i; b++) {
/*      */       
/* 5060 */       Executor executor = arrayOfNTFEventListener[b].getExecutor();
/* 5061 */       if (executor != null) {
/*      */         
/* 5063 */         final XSEventListener l = arrayOfNTFEventListener[b].getXSEventListener();
/*      */         
/* 5065 */         executor.execute(new Runnable() {
/*      */               public void run() {
/* 5067 */                 l.onXSEvent(event);
/*      */               }
/*      */             });
/*      */       }
/*      */       else {
/*      */         
/* 5073 */         arrayOfNTFEventListener[b].getXSEventListener().onXSEvent(event);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   final boolean hasServerCompileTimeCapability(int paramInt1, int paramInt2) {
/* 5096 */     boolean bool = false;
/* 5097 */     if (this.serverCompileTimeCapabilities != null && this.serverCompileTimeCapabilities.length > paramInt1 && (this.serverCompileTimeCapabilities[paramInt1] & paramInt2) != 0)
/*      */     {
/*      */ 
/*      */ 
/*      */       
/* 5102 */       bool = true;
/*      */     }
/* 5104 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   long doGetCurrentSCN() throws SQLException {
/* 5112 */     return this.outScn;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   EnumSet<OracleConnection.TransactionState> doGetTransactionState() throws SQLException {
/* 5119 */     EnumSet<OracleConnection.TransactionState> enumSet = EnumSet.noneOf(OracleConnection.TransactionState.class);
/* 5120 */     if ((this.eocs & 0x1) != 0)
/*      */     {
/* 5122 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_READONLY);
/*      */     }
/* 5124 */     if ((this.eocs & 0x2) != 0)
/*      */     {
/* 5126 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_STARTED);
/*      */     }
/* 5128 */     if ((this.eocs & 0x4) != 0)
/*      */     {
/* 5130 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_ENDED);
/*      */     }
/* 5132 */     if ((this.eocs & 0x400) != 0)
/*      */     {
/* 5134 */       enumSet.add(OracleConnection.TransactionState.TRANSACTION_INTENTION);
/*      */     }
/* 5136 */     return enumSet;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean isConnectionSocketKeepAlive() throws SocketException {
/* 5143 */     return this.net.isConnectionSocketKeepAlive();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   byte getNextSeqNumber() {
/* 5149 */     if (this.currentTTCSeqNumber == Byte.MAX_VALUE) {
/*      */       
/* 5151 */       this.currentTTCSeqNumber = 1;
/* 5152 */       return this.currentTTCSeqNumber;
/*      */     } 
/*      */     
/* 5155 */     return this.currentTTCSeqNumber = (byte)(this.currentTTCSeqNumber + 1);
/*      */   }
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/T4CConnection.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */