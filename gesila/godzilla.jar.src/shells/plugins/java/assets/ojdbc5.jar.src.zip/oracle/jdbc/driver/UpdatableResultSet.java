/*      */ package oracle.jdbc.driver;
/*      */ 
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.Writer;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Connection;
/*      */ import java.sql.Date;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import oracle.jdbc.OracleData;
/*      */ import oracle.jdbc.OracleDataFactory;
/*      */ import oracle.jdbc.OracleResultSet;
/*      */ import oracle.jdbc.internal.OracleConnection;
/*      */ import oracle.sql.ARRAY;
/*      */ import oracle.sql.BFILE;
/*      */ import oracle.sql.BLOB;
/*      */ import oracle.sql.CHAR;
/*      */ import oracle.sql.CLOB;
/*      */ import oracle.sql.CustomDatum;
/*      */ import oracle.sql.CustomDatumFactory;
/*      */ import oracle.sql.DATE;
/*      */ import oracle.sql.Datum;
/*      */ import oracle.sql.INTERVALDS;
/*      */ import oracle.sql.INTERVALYM;
/*      */ import oracle.sql.NUMBER;
/*      */ import oracle.sql.OPAQUE;
/*      */ import oracle.sql.ORAData;
/*      */ import oracle.sql.ORADataFactory;
/*      */ import oracle.sql.RAW;
/*      */ import oracle.sql.REF;
/*      */ import oracle.sql.ROWID;
/*      */ import oracle.sql.STRUCT;
/*      */ import oracle.sql.TIMESTAMP;
/*      */ import oracle.sql.TIMESTAMPLTZ;
/*      */ import oracle.sql.TIMESTAMPTZ;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ class UpdatableResultSet
/*      */   extends BaseResultSet
/*      */ {
/*      */   static final int concurrencyType = 1008;
/*      */   static final int BEGIN_COLUMN_INDEX = 1;
/*      */   static final int MAX_CHAR_BUFFER_SIZE = 1024;
/*      */   static final int MAX_BYTE_BUFFER_SIZE = 1024;
/*      */   PhysicalConnection connection;
/*      */   OracleResultSet resultSet;
/*      */   boolean isCachedRset;
/*      */   ScrollRsetStatement scrollStmt;
/*      */   ResultSetMetaData rsetMetaData;
/*      */   private int rsetType;
/*      */   private int columnCount;
/*      */   private OraclePreparedStatement deleteStmt;
/*      */   private OraclePreparedStatement insertStmt;
/*      */   private OraclePreparedStatement updateStmt;
/*      */   private int[] indexColsChanged;
/*      */   private Object[] rowBuffer;
/*      */   private boolean[] m_nullIndicator;
/*      */   private int[][] typeInfo;
/*      */   private boolean isInserting;
/*      */   private boolean isUpdating;
/*      */   private int wasNull;
/*      */   private static final int VALUE_NULL = 1;
/*      */   private static final int VALUE_NOT_NULL = 2;
/*      */   private static final int VALUE_UNKNOWN = 3;
/*      */   private static final int VALUE_IN_RSET = 4;
/*      */   private static final int ASCII_STREAM = 1;
/*      */   private static final int BINARY_STREAM = 2;
/*      */   private static final int UNICODE_STREAM = 3;
/*   99 */   private static int _MIN_STREAM_SIZE = 4000;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList tempClobsToFree;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ArrayList tempBlobsToFree;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   UpdatableResultSet(ScrollRsetStatement paramScrollRsetStatement, ScrollableResultSet paramScrollableResultSet, int paramInt1, int paramInt2) throws SQLException
/*      */   {
/* 2384 */     this.tempClobsToFree = null;
/* 2385 */     this.tempBlobsToFree = null; init(paramScrollRsetStatement, paramScrollableResultSet, paramInt1, paramInt2); paramScrollableResultSet.resetBeginColumnIndex(); getInternalMetadata(); this.isCachedRset = true; } private void init(ScrollRsetStatement paramScrollRsetStatement, OracleResultSet paramOracleResultSet, int paramInt1, int paramInt2) throws SQLException { if (paramScrollRsetStatement == null || paramOracleResultSet == null || paramInt2 != 1008) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  this.connection = ((OracleStatement)paramScrollRsetStatement).connection; this.resultSet = paramOracleResultSet; this.scrollStmt = paramScrollRsetStatement; this.rsetType = paramInt1; this.deleteStmt = null; this.insertStmt = null; this.updateStmt = null; this.indexColsChanged = null; this.rowBuffer = null; this.m_nullIndicator = null; this.typeInfo = (int[][])null; this.isInserting = false; this.isUpdating = false; this.wasNull = -1; this.rsetMetaData = null; this.columnCount = 0; } void ensureOpen() throws SQLException { if (this.closed) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 10); sQLException.fillInStackTrace(); throw sQLException; }  if (this.resultSet == null || this.scrollStmt == null || ((OracleStatement)this.scrollStmt).closed) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9); sQLException.fillInStackTrace(); throw sQLException; }  } public void close() throws SQLException { if (this.closed) return;  synchronized (this.connection) { super.close(); if (this.resultSet != null) this.resultSet.close();  if (this.insertStmt != null) this.insertStmt.close();  if (this.updateStmt != null) this.updateStmt.close();  if (this.deleteStmt != null) this.deleteStmt.close();  if (this.scrollStmt != null) this.scrollStmt.notifyCloseRset();  cancelRowInserts(); this.connection = LogicalConnection.closedConnection; this.resultSet = null; this.scrollStmt = null; this.rsetMetaData = null; this.scrollStmt = null; this.deleteStmt = null; this.insertStmt = null; this.updateStmt = null; this.indexColsChanged = null; this.rowBuffer = null; this.m_nullIndicator = null; this.typeInfo = (int[][])null; }  } public boolean wasNull() throws SQLException { synchronized (this.connection) { ensureOpen(); switch (this.wasNull) { case 1: return true;case 2: return false;case 4: return this.resultSet.wasNull(); }  SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 24); sQLException.fillInStackTrace(); throw sQLException; }  } int getFirstUserColumnIndex() { return 1; } public Statement getStatement() throws SQLException { synchronized (this.connection) { return (Statement)this.scrollStmt; }  } public SQLWarning getWarnings() throws SQLException { SQLWarning sQLWarning1 = this.resultSet.getWarnings(); if (this.sqlWarning == null) return sQLWarning1;  SQLWarning sQLWarning2 = this.sqlWarning; while (sQLWarning2.getNextWarning() != null) sQLWarning2 = sQLWarning2.getNextWarning();  sQLWarning2.setNextWarning(sQLWarning1); return this.sqlWarning; } public void clearWarnings() throws SQLException { this.sqlWarning = null; this.resultSet.clearWarnings(); } public boolean next() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); return this.resultSet.next(); }  } public boolean isBeforeFirst() throws SQLException { synchronized (this.connection) { ensureOpen(); return this.resultSet.isBeforeFirst(); }  } public boolean isAfterLast() throws SQLException { synchronized (this.connection) { ensureOpen(); return this.resultSet.isAfterLast(); }  } public boolean isFirst() throws SQLException { synchronized (this.connection) { ensureOpen(); return this.resultSet.isFirst(); }  } public boolean isLast() throws SQLException { synchronized (this.connection) { ensureOpen(); return this.resultSet.isLast(); }  } public void beforeFirst() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); this.resultSet.beforeFirst(); }  } public void afterLast() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); this.resultSet.afterLast(); }  } public boolean first() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); return this.resultSet.first(); }  } public boolean last() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); return this.resultSet.last(); }  } public int getRow() throws SQLException { synchronized (this.connection) { ensureOpen(); return this.resultSet.getRow(); }  } public boolean absolute(int paramInt) throws SQLException { synchronized (this.connection) { cancelRowChanges(); return this.resultSet.absolute(paramInt); }  } public boolean relative(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); return this.resultSet.relative(paramInt); }  } UpdatableResultSet(ScrollRsetStatement paramScrollRsetStatement, OracleResultSetImpl paramOracleResultSetImpl, int paramInt1, int paramInt2) throws SQLException { this.tempClobsToFree = null; this.tempBlobsToFree = null; init(paramScrollRsetStatement, paramOracleResultSetImpl, paramInt1, paramInt2); getInternalMetadata(); this.isCachedRset = false; }
/*      */   public boolean previous() throws SQLException { synchronized (this.connection) { ensureOpen(); cancelRowChanges(); return this.resultSet.previous(); }  }
/*      */   public Datum getOracleObject(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); Datum datum = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { setIsNull((datum == null)); datum = getRowBufferDatumAt(paramInt); } else { setIsNull(4); datum = this.resultSet.getOracleObject(paramInt + 1); }  return datum; }  }
/*      */   public String getString(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); String str = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) str = datum.stringValue((Connection)this.connection);  } else { setIsNull(4); str = this.resultSet.getString(paramInt + 1); }  return str; }  }
/*      */   public boolean getBoolean(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); boolean bool = false; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) bool = datum.booleanValue();  } else { setIsNull(4); bool = this.resultSet.getBoolean(paramInt + 1); }  return bool; }  }
/* 2390 */   public OracleResultSet.AuthorizationIndicator getAuthorizationIndicator(int paramInt) throws SQLException { return this.resultSet.getAuthorizationIndicator(paramInt + 1); } public byte getByte(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); byte b = 0; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) b = datum.byteValue();  } else { setIsNull(4); b = this.resultSet.getByte(paramInt + 1); }  return b; }  } public short getShort(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); short s = 0; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { long l = getLong(paramInt); if (l > 65537L || l < -65538L) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 26, "getShort"); sQLException.fillInStackTrace(); throw sQLException; }  s = (short)(int)l; } else { setIsNull(4); s = this.resultSet.getShort(paramInt + 1); }  return s; }  } public int getInt(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); int i = 0; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) i = datum.intValue();  } else { setIsNull(4); i = this.resultSet.getInt(paramInt + 1); }  return i; }  } public long getLong(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); long l = 0L; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) l = datum.longValue();  } else { setIsNull(4); l = this.resultSet.getLong(paramInt + 1); }  return l; }  } public float getFloat(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); float f = 0.0F; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) f = datum.floatValue();  } else { setIsNull(4); f = this.resultSet.getFloat(paramInt + 1); }  return f; }  } public double getDouble(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); double d = 0.0D; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) d = datum.doubleValue();  } else { setIsNull(4); d = this.resultSet.getDouble(paramInt + 1); }  return d; }  } public BigDecimal getBigDecimal(int paramInt1, int paramInt2) throws SQLException { synchronized (this.connection) { ensureOpen(); BigDecimal bigDecimal = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt1))) { Datum datum = getRowBufferDatumAt(paramInt1); setIsNull((datum == null)); if (datum != null) bigDecimal = datum.bigDecimalValue();  } else { setIsNull(4); bigDecimal = this.resultSet.getBigDecimal(paramInt1 + 1); }  return bigDecimal; }  } public byte[] getBytes(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); byte[] arrayOfByte = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) arrayOfByte = datum.getBytes();  } else { setIsNull(4); arrayOfByte = this.resultSet.getBytes(paramInt + 1); }  return arrayOfByte; }  } public Date getDate(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); Date date = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) date = datum.dateValue();  } else { setIsNull(4); date = this.resultSet.getDate(paramInt + 1); }  return date; }  } public Time getTime(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); Time time = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) time = datum.timeValue();  } else { setIsNull(4); time = this.resultSet.getTime(paramInt + 1); }  return time; }  } public Timestamp getTimestamp(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); Timestamp timestamp = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) timestamp = datum.timestampValue();  } else { setIsNull(4); timestamp = this.resultSet.getTimestamp(paramInt + 1); }  return timestamp; }  } public InputStream getAsciiStream(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); InputStream inputStream = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Object object = getRowBufferAt(paramInt); setIsNull((object == null)); if (object != null) if (object instanceof InputStream) { inputStream = (InputStream)object; } else { Datum datum = getRowBufferDatumAt(paramInt); inputStream = datum.asciiStreamValue(); }   } else { setIsNull(4); inputStream = this.resultSet.getAsciiStream(paramInt + 1); }  return inputStream; }  } public InputStream getUnicodeStream(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); InputStream inputStream = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Object object = getRowBufferAt(paramInt); setIsNull((object == null)); if (object != null) if (object instanceof InputStream) { inputStream = (InputStream)object; } else { Datum datum = getRowBufferDatumAt(paramInt); DBConversion dBConversion = this.connection.conversion; byte[] arrayOfByte = datum.shareBytes(); if (datum instanceof RAW) { inputStream = dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 3); } else if (datum instanceof CHAR) { inputStream = dBConversion.ConvertStream(new ByteArrayInputStream(arrayOfByte), 1); } else { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getUnicodeStream"); sQLException.fillInStackTrace(); throw sQLException; }  }   } else { setIsNull(4); inputStream = this.resultSet.getUnicodeStream(paramInt + 1); }  return inputStream; }  } public InputStream getBinaryStream(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); InputStream inputStream = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Object object = getRowBufferAt(paramInt); setIsNull((object == null)); if (object != null) if (object instanceof InputStream) { inputStream = (InputStream)object; } else { Datum datum = getRowBufferDatumAt(paramInt); inputStream = datum.binaryStreamValue(); }   } else { setIsNull(4); inputStream = this.resultSet.getBinaryStream(paramInt + 1); }  return inputStream; }  } void addToTempLobsToFree(Clob paramClob) { if (this.tempClobsToFree == null)
/* 2391 */       this.tempClobsToFree = new ArrayList(); 
/* 2392 */     this.tempClobsToFree.add(paramClob); } public Object getObject(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); Object object = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getOracleObject(paramInt); setIsNull((datum == null)); if (datum != null) object = datum.toJdbc();  } else { setIsNull(4); object = this.resultSet.getObject(paramInt + 1); }  return object; }  } public Object getObject(int paramInt, OracleDataFactory paramOracleDataFactory) throws SQLException { synchronized (this.connection) { return paramOracleDataFactory.create(getObject(paramInt), 0); }  } public Reader getCharacterStream(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); Reader reader = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Object object = getRowBufferAt(paramInt); setIsNull((object == null)); if (object != null) if (object instanceof Reader) { reader = (Reader)object; } else { Datum datum = getRowBufferDatumAt(paramInt); reader = datum.characterStreamValue(); }   } else { setIsNull(4); reader = this.resultSet.getCharacterStream(paramInt + 1); }  return reader; }  } public BigDecimal getBigDecimal(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); BigDecimal bigDecimal = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null) bigDecimal = datum.bigDecimalValue();  } else { setIsNull(4); bigDecimal = this.resultSet.getBigDecimal(paramInt + 1); }  return bigDecimal; }  } public Object getObject(int paramInt, Map paramMap) throws SQLException { synchronized (this.connection) { ensureOpen(); Object object = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getOracleObject(paramInt); setIsNull((datum == null)); if (datum != null) if (datum instanceof STRUCT) { object = ((STRUCT)datum).toJdbc(paramMap); } else { object = datum.toJdbc(); }   } else { setIsNull(4); object = this.resultSet.getObject(paramInt + 1, paramMap); }  return object; }  } public Ref getRef(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); return (Ref)getREF(paramInt); }  } public Blob getBlob(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); return (Blob)getBLOB(paramInt); }  } public Clob getClob(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); return (Clob)getCLOB(paramInt); }  } public Array getArray(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); return (Array)getARRAY(paramInt); }  } public Date getDate(int paramInt, Calendar paramCalendar) throws SQLException { synchronized (this.connection) { ensureOpen(); Date date = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getOracleObject(paramInt); setIsNull((datum == null)); if (datum != null) if (datum instanceof DATE) { date = ((DATE)datum).dateValue(paramCalendar); } else if (datum instanceof TIMESTAMP) { Timestamp timestamp = ((TIMESTAMP)datum).timestampValue(paramCalendar); long l = timestamp.getTime(); date = new Date(l); } else { DATE dATE = new DATE(datum.stringValue((Connection)this.connection)); if (dATE != null) date = dATE.dateValue(paramCalendar);  }   } else { setIsNull(4); date = this.resultSet.getDate(paramInt + 1, paramCalendar); }  return date; }  } public Time getTime(int paramInt, Calendar paramCalendar) throws SQLException { synchronized (this.connection) { ensureOpen(); Time time = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getOracleObject(paramInt); setIsNull((datum == null)); if (datum != null) if (datum instanceof DATE) { time = ((DATE)datum).timeValue(paramCalendar); } else if (datum instanceof TIMESTAMP) { Timestamp timestamp = ((TIMESTAMP)datum).timestampValue(paramCalendar); long l = timestamp.getTime(); time = new Time(l); } else { DATE dATE = new DATE(datum.stringValue((Connection)this.connection)); if (dATE != null) time = dATE.timeValue(paramCalendar);  }   } else { setIsNull(4); time = this.resultSet.getTime(paramInt + 1, paramCalendar); }  return time; }  } public Timestamp getTimestamp(int paramInt, Calendar paramCalendar) throws SQLException { synchronized (this.connection) { ensureOpen(); Timestamp timestamp = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getOracleObject(paramInt); setIsNull((datum == null)); if (datum != null) if (datum instanceof DATE) { timestamp = ((DATE)datum).timestampValue(paramCalendar); } else if (datum instanceof TIMESTAMP) { timestamp = ((TIMESTAMP)datum).timestampValue(paramCalendar); } else { DATE dATE = new DATE(datum.stringValue((Connection)this.connection)); if (dATE != null) timestamp = dATE.timestampValue(paramCalendar);  }   } else { setIsNull(4); timestamp = this.resultSet.getTimestamp(paramInt + 1, paramCalendar); }  return timestamp; }  } public URL getURL(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); URL uRL = null; int i = getInternalMetadata().getColumnType(paramInt + 1); int j = SQLUtil.getInternalType(i); if (j == 96 || j == 1 || j == 8) { try { String str = getString(paramInt); if (str == null) { uRL = null; } else { uRL = new URL(str); }  } catch (MalformedURLException malformedURLException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 136); sQLException.fillInStackTrace(); throw sQLException; }  } else { SQLException sQLException = DatabaseError.createUnsupportedFeatureSqlException(); sQLException.fillInStackTrace(); throw sQLException; }  return uRL; }  }
/*      */   public ResultSet getCursor(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); ResultSet resultSet = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getOracleObject(paramInt); setIsNull((datum == null)); SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCursor"); sQLException.fillInStackTrace(); throw sQLException; }  setIsNull(4); resultSet = this.resultSet.getCursor(paramInt + 1); return resultSet; }  }
/*      */   public ROWID getROWID(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); ROWID rOWID = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof ROWID)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getROWID"); sQLException.fillInStackTrace(); throw sQLException; }  rOWID = (ROWID)datum; } else { setIsNull(4); rOWID = this.resultSet.getROWID(paramInt + 1); }  return rOWID; }  }
/*      */   public NUMBER getNUMBER(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); NUMBER nUMBER = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof NUMBER)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getNUMBER"); sQLException.fillInStackTrace(); throw sQLException; }  nUMBER = (NUMBER)datum; } else { setIsNull(4); nUMBER = this.resultSet.getNUMBER(paramInt + 1); }  return nUMBER; }  }
/*      */   public DATE getDATE(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); DATE dATE = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); if (datum != null) { if (datum instanceof DATE) { dATE = (DATE)datum; } else if (datum instanceof TIMESTAMP) { Timestamp timestamp = ((TIMESTAMP)datum).timestampValue(); dATE = new DATE(timestamp); } else { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getDATE"); sQLException.fillInStackTrace(); throw sQLException; }  } else { setIsNull((datum == null)); }  } else { setIsNull(4); dATE = this.resultSet.getDATE(paramInt + 1); }  return dATE; }  }
/*      */   public TIMESTAMP getTIMESTAMP(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); TIMESTAMP tIMESTAMP = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof TIMESTAMP)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMP"); sQLException.fillInStackTrace(); throw sQLException; }  tIMESTAMP = (TIMESTAMP)datum; } else { setIsNull(4); tIMESTAMP = this.resultSet.getTIMESTAMP(paramInt + 1); }  return tIMESTAMP; }  }
/*      */   public TIMESTAMPTZ getTIMESTAMPTZ(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); TIMESTAMPTZ tIMESTAMPTZ = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof TIMESTAMPTZ)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPTZ"); sQLException.fillInStackTrace(); throw sQLException; }  tIMESTAMPTZ = (TIMESTAMPTZ)datum; } else { setIsNull(4); tIMESTAMPTZ = this.resultSet.getTIMESTAMPTZ(paramInt + 1); }  return tIMESTAMPTZ; }  }
/* 2399 */   void addToTempLobsToFree(Blob paramBlob) { if (this.tempBlobsToFree == null)
/* 2400 */       this.tempBlobsToFree = new ArrayList(); 
/* 2401 */     this.tempBlobsToFree.add(paramBlob); } public TIMESTAMPLTZ getTIMESTAMPLTZ(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); TIMESTAMPLTZ tIMESTAMPLTZ = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof TIMESTAMPLTZ)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getTIMESTAMPLTZ"); sQLException.fillInStackTrace(); throw sQLException; }  tIMESTAMPLTZ = (TIMESTAMPLTZ)datum; } else { setIsNull(4); tIMESTAMPLTZ = this.resultSet.getTIMESTAMPLTZ(paramInt + 1); }  return tIMESTAMPLTZ; }  } public INTERVALDS getINTERVALDS(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); INTERVALDS iNTERVALDS = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof INTERVALDS)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALDS"); sQLException.fillInStackTrace(); throw sQLException; }  iNTERVALDS = (INTERVALDS)datum; } else { setIsNull(4); iNTERVALDS = this.resultSet.getINTERVALDS(paramInt + 1); }  return iNTERVALDS; }  } public INTERVALYM getINTERVALYM(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); INTERVALYM iNTERVALYM = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof INTERVALYM)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getINTERVALYM"); sQLException.fillInStackTrace(); throw sQLException; }  iNTERVALYM = (INTERVALYM)datum; } else { setIsNull(4); iNTERVALYM = this.resultSet.getINTERVALYM(paramInt + 1); }  return iNTERVALYM; }  } public ARRAY getARRAY(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); ARRAY aRRAY = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof ARRAY)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getARRAY"); sQLException.fillInStackTrace(); throw sQLException; }  aRRAY = (ARRAY)datum; } else { setIsNull(4); aRRAY = this.resultSet.getARRAY(paramInt + 1); }  return aRRAY; }  } public STRUCT getSTRUCT(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); STRUCT sTRUCT = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof STRUCT)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getSTRUCT"); sQLException.fillInStackTrace(); throw sQLException; }  sTRUCT = (STRUCT)datum; } else { setIsNull(4); sTRUCT = this.resultSet.getSTRUCT(paramInt + 1); }  return sTRUCT; }  } public OPAQUE getOPAQUE(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); OPAQUE oPAQUE = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof OPAQUE)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getOPAQUE"); sQLException.fillInStackTrace(); throw sQLException; }  oPAQUE = (OPAQUE)datum; } else { setIsNull(4); oPAQUE = this.resultSet.getOPAQUE(paramInt + 1); }  return oPAQUE; }  } public REF getREF(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); REF rEF = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof REF)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getREF"); sQLException.fillInStackTrace(); throw sQLException; }  rEF = (REF)datum; } else { setIsNull(4); rEF = this.resultSet.getREF(paramInt + 1); }  return rEF; }  } public CHAR getCHAR(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); CHAR cHAR = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof CHAR)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCHAR"); sQLException.fillInStackTrace(); throw sQLException; }  cHAR = (CHAR)datum; } else { setIsNull(4); cHAR = this.resultSet.getCHAR(paramInt + 1); }  return cHAR; }  } public RAW getRAW(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); RAW rAW = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof RAW)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getRAW"); sQLException.fillInStackTrace(); throw sQLException; }  rAW = (RAW)datum; } else { setIsNull(4); rAW = this.resultSet.getRAW(paramInt + 1); }  return rAW; }  } public BLOB getBLOB(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); BLOB bLOB = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof BLOB)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBLOB"); sQLException.fillInStackTrace(); throw sQLException; }  bLOB = (BLOB)datum; } else { setIsNull(4); bLOB = this.resultSet.getBLOB(paramInt + 1); }  return bLOB; }  } public CLOB getCLOB(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); CLOB cLOB = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof CLOB)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getCLOB"); sQLException.fillInStackTrace(); throw sQLException; }  cLOB = (CLOB)datum; } else { setIsNull(4); cLOB = this.resultSet.getCLOB(paramInt + 1); }  return cLOB; }  } public BFILE getBFILE(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); BFILE bFILE = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); if (datum != null && !(datum instanceof BFILE)) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4, "getBFILE"); sQLException.fillInStackTrace(); throw sQLException; }  bFILE = (BFILE)datum; } else { setIsNull(4); bFILE = this.resultSet.getBFILE(paramInt + 1); }  return bFILE; }  } public BFILE getBfile(int paramInt) throws SQLException { synchronized (this.connection) { ensureOpen(); return getBFILE(paramInt); }  } public CustomDatum getCustomDatum(int paramInt, CustomDatumFactory paramCustomDatumFactory) throws SQLException { synchronized (this.connection) { ensureOpen(); if (paramCustomDatumFactory == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  CustomDatum customDatum = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); customDatum = paramCustomDatumFactory.create(datum, 0); } else { setIsNull(4); customDatum = this.resultSet.getCustomDatum(paramInt + 1, paramCustomDatumFactory); }  return customDatum; }  }
/*      */   public ORAData getORAData(int paramInt, ORADataFactory paramORADataFactory) throws SQLException { synchronized (this.connection) { ensureOpen(); if (paramORADataFactory == null) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68); sQLException.fillInStackTrace(); throw sQLException; }  ORAData oRAData = null; setIsNull(3); if (isOnInsertRow() || (isUpdatingRow() && isRowBufferUpdatedAt(paramInt))) { Datum datum = getRowBufferDatumAt(paramInt); setIsNull((datum == null)); oRAData = paramORADataFactory.create(datum, 0); } else { setIsNull(4); oRAData = this.resultSet.getORAData(paramInt + 1, paramORADataFactory); }  return oRAData; }  }
/*      */   void updateBlob(int paramInt, InputStream paramInputStream, long paramLong) throws SQLException { BLOB bLOB = BLOB.createTemporary((Connection)this.connection, true, 10); addToTempLobsToFree((Blob)bLOB); int i = bLOB.getBufferSize(); OutputStream outputStream = bLOB.setBinaryStream(1L); byte[] arrayOfByte = new byte[i]; long l = paramLong; try { while (l > 0L) { int j = paramInputStream.read(arrayOfByte, 0, Math.min(i, (int)l)); if (j == -1) break;  outputStream.write(arrayOfByte, 0, j); l -= j; }  outputStream.close(); updateBlob(paramInt, (Blob)bLOB); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   void updateClob(int paramInt, Reader paramReader, long paramLong) throws SQLException { updateClob(paramInt, paramReader, paramLong, (short)1); }
/*      */   void updateClob(int paramInt, Reader paramReader, long paramLong, short paramShort) throws SQLException { CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, paramShort); addToTempLobsToFree((Clob)cLOB); int i = cLOB.getBufferSize(); Writer writer = cLOB.setCharacterStream(1L); char[] arrayOfChar = new char[i]; long l = paramLong; try { while (l > 0L) { int j = paramReader.read(arrayOfChar, 0, Math.min(i, (int)l)); if (j == -1) break;  writer.write(arrayOfChar, 0, j); l -= j; }  writer.close(); updateClob(paramInt, (Clob)cLOB); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/*      */   void updateClob(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException { updateClob(paramInt1, paramInputStream, paramInt2, (short)1); }
/*      */   void updateClob(int paramInt1, InputStream paramInputStream, int paramInt2, short paramShort) throws SQLException { CLOB cLOB = CLOB.createTemporary((Connection)this.connection, true, 10, paramShort); addToTempLobsToFree((Clob)cLOB); int i = cLOB.getBufferSize(); OutputStream outputStream = cLOB.setAsciiStream(1L); byte[] arrayOfByte = new byte[i]; long l = paramInt2; try { while (l > 0L) { int j = paramInputStream.read(arrayOfByte, 0, Math.min(i, (int)l)); if (j == -1) break;  outputStream.write(arrayOfByte, 0, j); l -= j; }  outputStream.close(); updateClob(paramInt1, (Clob)cLOB); } catch (IOException iOException) { SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException); sQLException.fillInStackTrace(); throw sQLException; }  }
/* 2408 */   void cleanTempLobs() { cleanTempClobs(this.tempClobsToFree);
/* 2409 */     cleanTempBlobs(this.tempBlobsToFree);
/* 2410 */     this.tempClobsToFree = null;
/* 2411 */     this.tempBlobsToFree = null; }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cleanTempBlobs(ArrayList paramArrayList) {
/* 2418 */     if (paramArrayList != null) {
/*      */       
/* 2420 */       Iterator<BLOB> iterator = paramArrayList.iterator();
/*      */       
/* 2422 */       while (iterator.hasNext()) {
/*      */ 
/*      */         
/*      */         try {
/* 2426 */           ((BLOB)iterator.next()).freeTemporary();
/*      */         }
/* 2428 */         catch (SQLException sQLException) {}
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void cleanTempClobs(ArrayList paramArrayList) {
/* 2440 */     if (paramArrayList != null) {
/*      */       
/* 2442 */       Iterator<CLOB> iterator = paramArrayList.iterator();
/*      */       
/* 2444 */       while (iterator.hasNext()) {
/*      */ 
/*      */         
/*      */         try {
/* 2448 */           ((CLOB)iterator.next()).freeTemporary();
/*      */         }
/* 2450 */         catch (SQLException sQLException) {}
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/* 2466 */     if (((OracleStatement)this.scrollStmt).closed) {
/*      */       
/* 2468 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 9, "getMetaData");
/* 2469 */       sQLException.fillInStackTrace();
/* 2470 */       throw sQLException;
/*      */     } 
/*      */     
/* 2473 */     synchronized (this.connection) {
/* 2474 */       return (ResultSetMetaData)new OracleResultSetMetaData(this.connection, (OracleStatement)this.scrollStmt, 1);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int findColumn(String paramString) throws SQLException {
/* 2483 */     synchronized (this.connection) {
/*      */       
/* 2485 */       ensureOpen();
/* 2486 */       return this.resultSet.findColumn(paramString) - 1;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchDirection(int paramInt) throws SQLException {
/* 2497 */     synchronized (this.connection) {
/*      */       
/* 2499 */       ensureOpen();
/* 2500 */       this.resultSet.setFetchDirection(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchDirection() throws SQLException {
/* 2507 */     synchronized (this.connection) {
/*      */       
/* 2509 */       ensureOpen();
/* 2510 */       return this.resultSet.getFetchDirection();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void setFetchSize(int paramInt) throws SQLException {
/* 2517 */     synchronized (this.connection) {
/*      */       
/* 2519 */       ensureOpen();
/* 2520 */       this.resultSet.setFetchSize(paramInt);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int getFetchSize() throws SQLException {
/* 2527 */     synchronized (this.connection) {
/*      */       
/* 2529 */       ensureOpen();
/* 2530 */       return this.resultSet.getFetchSize();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getType() throws SQLException {
/* 2538 */     return this.rsetType;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getConcurrency() throws SQLException {
/* 2545 */     return 1008;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowUpdated() throws SQLException {
/* 2556 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowInserted() throws SQLException {
/* 2563 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rowDeleted() throws SQLException {
/* 2570 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void insertRow() throws SQLException {
/* 2576 */     synchronized (this.connection) {
/*      */       
/* 2578 */       ensureOpen();
/* 2579 */       if (!isOnInsertRow()) {
/*      */         
/* 2581 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 83);
/* 2582 */         sQLException.fillInStackTrace();
/* 2583 */         throw sQLException;
/*      */       } 
/*      */       
/* 2586 */       prepareInsertRowStatement();
/* 2587 */       prepareInsertRowBinds();
/* 2588 */       executeInsertRow();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRow() throws SQLException {
/* 2595 */     synchronized (this.connection) {
/*      */       
/* 2597 */       ensureOpen();
/*      */ 
/*      */       
/* 2600 */       if (isOnInsertRow()) {
/*      */         
/* 2602 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/* 2603 */         sQLException.fillInStackTrace();
/* 2604 */         throw sQLException;
/*      */       } 
/*      */       
/* 2607 */       int i = getNumColumnsChanged();
/*      */       
/* 2609 */       if (i > 0) {
/*      */         
/* 2611 */         prepareUpdateRowStatement(i);
/* 2612 */         prepareUpdateRowBinds(i);
/* 2613 */         executeUpdateRow();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void deleteRow() throws SQLException {
/* 2621 */     synchronized (this.connection) {
/*      */       
/* 2623 */       ensureOpen();
/*      */ 
/*      */       
/* 2626 */       if (isOnInsertRow()) {
/*      */         
/* 2628 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/* 2629 */         sQLException.fillInStackTrace();
/* 2630 */         throw sQLException;
/*      */       } 
/*      */       
/* 2633 */       prepareDeleteRowStatement();
/* 2634 */       prepareDeleteRowBinds();
/* 2635 */       executeDeleteRow();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void refreshRow() throws SQLException {
/* 2642 */     synchronized (this.connection) {
/*      */       
/* 2644 */       ensureOpen();
/*      */       
/* 2646 */       if (isOnInsertRow()) {
/*      */         
/* 2648 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 84);
/* 2649 */         sQLException.fillInStackTrace();
/* 2650 */         throw sQLException;
/*      */       } 
/*      */       
/* 2653 */       this.resultSet.refreshRow();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void cancelRowUpdates() throws SQLException {
/* 2660 */     synchronized (this.connection) {
/*      */       
/* 2662 */       ensureOpen();
/* 2663 */       if (this.isUpdating) {
/*      */         
/* 2665 */         this.isUpdating = false;
/*      */         
/* 2667 */         clearRowBuffer();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToInsertRow() throws SQLException {
/* 2675 */     synchronized (this.connection) {
/*      */       
/* 2677 */       ensureOpen();
/* 2678 */       if (isOnInsertRow()) {
/*      */         return;
/*      */       }
/* 2681 */       this.isInserting = true;
/*      */ 
/*      */       
/* 2684 */       if (this.rowBuffer == null) {
/* 2685 */         this.rowBuffer = new Object[getColumnCount()];
/*      */       }
/* 2687 */       if (this.m_nullIndicator == null) {
/* 2688 */         this.m_nullIndicator = new boolean[getColumnCount()];
/*      */       }
/* 2690 */       clearRowBuffer();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveToCurrentRow() throws SQLException {
/* 2697 */     synchronized (this.connection) {
/*      */       
/* 2699 */       ensureOpen();
/* 2700 */       cancelRowInserts();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateString(int paramInt, String paramString) throws SQLException {
/* 2708 */     synchronized (this.connection) {
/*      */       
/* 2710 */       if (paramString == null || paramString.length() == 0) {
/* 2711 */         updateNull(paramInt);
/*      */       } else {
/* 2713 */         updateObject(paramInt, paramString);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void updateNull(int paramInt) throws SQLException {
/* 2720 */     synchronized (this.connection) {
/*      */       
/* 2722 */       setRowBufferAt(paramInt, (Datum)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBoolean(int paramInt, boolean paramBoolean) throws SQLException {
/* 2730 */     updateObject(paramInt, Boolean.valueOf(paramBoolean));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateByte(int paramInt, byte paramByte) throws SQLException {
/* 2737 */     updateObject(paramInt, Integer.valueOf(paramByte));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateShort(int paramInt, short paramShort) throws SQLException {
/* 2744 */     updateObject(paramInt, Integer.valueOf(paramShort));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateInt(int paramInt1, int paramInt2) throws SQLException {
/* 2751 */     updateObject(paramInt1, Integer.valueOf(paramInt2));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateLong(int paramInt, long paramLong) throws SQLException {
/* 2758 */     updateObject(paramInt, Long.valueOf(paramLong));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateFloat(int paramInt, float paramFloat) throws SQLException {
/* 2765 */     updateObject(paramInt, Float.valueOf(paramFloat));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDouble(int paramInt, double paramDouble) throws SQLException {
/* 2772 */     updateObject(paramInt, Double.valueOf(paramDouble));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBigDecimal(int paramInt, BigDecimal paramBigDecimal) throws SQLException {
/* 2780 */     updateObject(paramInt, paramBigDecimal);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBytes(int paramInt, byte[] paramArrayOfbyte) throws SQLException {
/* 2787 */     updateObject(paramInt, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDate(int paramInt, Date paramDate) throws SQLException {
/* 2794 */     updateObject(paramInt, paramDate);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTime(int paramInt, Time paramTime) throws SQLException {
/* 2801 */     updateObject(paramInt, paramTime);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTimestamp(int paramInt, Timestamp paramTimestamp) throws SQLException {
/* 2809 */     updateObject(paramInt, paramTimestamp);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 2818 */     ensureOpen();
/* 2819 */     OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 2820 */     int i = oracleResultSetMetaData.getColumnType(1 + paramInt1);
/*      */     
/* 2822 */     if (paramInputStream != null && paramInt2 > 0) {
/*      */       int[] arrayOfInt;
/* 2824 */       switch (i) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2005:
/* 2830 */           if (oracleResultSetMetaData.isNCHAR(1 + paramInt1)) {
/*      */             
/* 2832 */             updateClob(paramInt1, paramInputStream, paramInt2, (short)2);
/*      */           } else {
/*      */             
/* 2835 */             updateClob(paramInt1, paramInputStream, paramInt2);
/*      */           } 
/*      */           return;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2004:
/* 2843 */           updateBlob(paramInt1, paramInputStream, paramInt2);
/*      */           return;
/*      */         
/*      */         case -1:
/* 2847 */           arrayOfInt = new int[] { paramInt2, 1 };
/*      */ 
/*      */ 
/*      */           
/* 2851 */           setRowBufferAt(paramInt1, paramInputStream, arrayOfInt);
/*      */           return;
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/* 2857 */         int j = 0;
/* 2858 */         int k = paramInt2;
/* 2859 */         byte[] arrayOfByte = new byte[1024];
/* 2860 */         char[] arrayOfChar = new char[1024];
/* 2861 */         StringBuilder stringBuilder = new StringBuilder(1024);
/*      */         
/* 2863 */         while (k > 0) {
/*      */           
/* 2865 */           if (k >= 1024) {
/* 2866 */             j = paramInputStream.read(arrayOfByte);
/*      */           } else {
/* 2868 */             j = paramInputStream.read(arrayOfByte, 0, k);
/*      */           } 
/*      */ 
/*      */           
/* 2872 */           if (j == -1) {
/*      */             break;
/*      */           }
/* 2875 */           DBConversion.asciiBytesToJavaChars(arrayOfByte, j, arrayOfChar);
/*      */           
/* 2877 */           stringBuilder.append(arrayOfChar, 0, j);
/* 2878 */           k -= j;
/*      */         } 
/*      */         
/* 2881 */         paramInputStream.close();
/* 2882 */         if (k == paramInt2) {
/*      */           
/* 2884 */           updateNull(paramInt1);
/*      */           
/*      */           return;
/*      */         } 
/* 2888 */         updateString(paramInt1, stringBuilder.toString());
/*      */       }
/* 2890 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 2893 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2894 */         sQLException.fillInStackTrace();
/* 2895 */         throw sQLException;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 2902 */       setRowBufferAt(paramInt1, (Datum)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2) throws SQLException {
/* 2911 */     ensureOpen();
/* 2912 */     int i = getInternalMetadata().getColumnType(1 + paramInt1);
/*      */     
/* 2914 */     if (paramInputStream != null && paramInt2 > 0) {
/*      */       int[] arrayOfInt;
/* 2916 */       switch (i) {
/*      */         
/*      */         case 2004:
/* 2919 */           updateBlob(paramInt1, paramInputStream, paramInt2);
/*      */           return;
/*      */         
/*      */         case -4:
/* 2923 */           arrayOfInt = new int[] { paramInt2, 2 };
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 2928 */           setRowBufferAt(paramInt1, paramInputStream, arrayOfInt);
/*      */           return;
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/* 2934 */         int j = 0;
/* 2935 */         int k = paramInt2;
/* 2936 */         byte[] arrayOfByte = new byte[1024];
/* 2937 */         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(1024);
/*      */ 
/*      */         
/* 2940 */         while (k > 0) {
/*      */           
/* 2942 */           if (k >= 1024) {
/* 2943 */             j = paramInputStream.read(arrayOfByte);
/*      */           } else {
/* 2945 */             j = paramInputStream.read(arrayOfByte, 0, k);
/*      */           } 
/*      */ 
/*      */           
/* 2949 */           if (j == -1) {
/*      */             break;
/*      */           }
/* 2952 */           byteArrayOutputStream.write(arrayOfByte, 0, j);
/* 2953 */           k -= j;
/*      */         } 
/*      */         
/* 2956 */         paramInputStream.close();
/* 2957 */         if (k == paramInt2) {
/*      */           
/* 2959 */           updateNull(paramInt1);
/*      */           
/*      */           return;
/*      */         } 
/* 2963 */         updateBytes(paramInt1, byteArrayOutputStream.toByteArray());
/*      */       }
/* 2965 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 2968 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 2969 */         sQLException.fillInStackTrace();
/* 2970 */         throw sQLException;
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */ 
/*      */       
/* 2980 */       setRowBufferAt(paramInt1, (Datum)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCharacterStream(int paramInt1, Reader paramReader, int paramInt2) throws SQLException {
/* 2988 */     int i = 0, j = paramInt2;
/*      */ 
/*      */     
/* 2991 */     ensureOpen();
/* 2992 */     OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 2993 */     int k = oracleResultSetMetaData.getColumnType(1 + paramInt1);
/*      */     
/* 2995 */     if (paramReader != null && paramInt2 > 0) {
/*      */       int[] arrayOfInt;
/* 2997 */       switch (k) {
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case 2005:
/* 3003 */           if (oracleResultSetMetaData.isNCHAR(1 + paramInt1)) {
/*      */             
/* 3005 */             updateClob(paramInt1, paramReader, paramInt2, (short)2);
/*      */           } else {
/*      */             
/* 3008 */             updateClob(paramInt1, paramReader, paramInt2);
/*      */           } 
/*      */           return;
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         case -1:
/* 3016 */           arrayOfInt = new int[] { paramInt2 };
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3021 */           setRowBufferAt(paramInt1, paramReader, arrayOfInt);
/*      */           return;
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/* 3027 */         char[] arrayOfChar = new char[1024];
/* 3028 */         StringBuilder stringBuilder = new StringBuilder(1024);
/*      */         
/* 3030 */         while (j > 0) {
/*      */           
/* 3032 */           if (j >= 1024) {
/* 3033 */             i = paramReader.read(arrayOfChar);
/*      */           } else {
/* 3035 */             i = paramReader.read(arrayOfChar, 0, j);
/*      */           } 
/*      */ 
/*      */           
/* 3039 */           if (i == -1) {
/*      */             break;
/*      */           }
/* 3042 */           stringBuilder.append(arrayOfChar, 0, i);
/* 3043 */           j -= i;
/*      */         } 
/*      */         
/* 3046 */         paramReader.close();
/* 3047 */         if (j == paramInt2) {
/*      */           
/* 3049 */           updateNull(paramInt1);
/*      */           
/*      */           return;
/*      */         } 
/* 3053 */         updateString(paramInt1, stringBuilder.toString());
/*      */       }
/* 3055 */       catch (IOException iOException) {
/*      */ 
/*      */         
/* 3058 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), iOException);
/* 3059 */         sQLException.fillInStackTrace();
/* 3060 */         throw sQLException;
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 3068 */       setRowBufferAt(paramInt1, (Datum)null);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt1, Object paramObject, int paramInt2) throws SQLException {
/* 3077 */     updateObject(paramInt1, paramObject);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateObject(int paramInt, Object paramObject) throws SQLException {
/* 3084 */     synchronized (this.connection) {
/*      */       
/* 3086 */       ensureOpen();
/* 3087 */       Datum datum = null;
/* 3088 */       if (paramObject != null) {
/*      */         
/* 3090 */         if (paramObject instanceof OracleData) {
/*      */           
/* 3092 */           Object object = ((OracleData)paramObject).toJDBCObject((Connection)this.connection);
/*      */ 
/*      */ 
/*      */           
/* 3096 */           paramObject = object;
/*      */         } 
/* 3098 */         if (paramObject instanceof Datum) {
/*      */           
/* 3100 */           datum = (Datum)paramObject;
/*      */         }
/*      */         else {
/*      */           
/* 3104 */           OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 3105 */           int i = paramInt + 1;
/* 3106 */           if (oracleResultSetMetaData.getColumnType(i) == 96) {
/* 3107 */             int j = oracleResultSetMetaData.getColumnDisplaySize(i);
/* 3108 */             String str = (String)paramObject;
/* 3109 */             for (int k = str.length(); k < j; ) { str = str + " "; k++; }
/*      */           
/* 3111 */           }  datum = SQLUtil.makeOracleDatum(this.connection, paramObject, oracleResultSetMetaData.getColumnType(i), null, oracleResultSetMetaData.isNCHAR(i));
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 3116 */       setRowBufferAt(paramInt, datum);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateOracleObject(int paramInt, Datum paramDatum) throws SQLException {
/* 3124 */     synchronized (this.connection) {
/*      */       
/* 3126 */       setRowBufferAt(paramInt, paramDatum);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateROWID(int paramInt, ROWID paramROWID) throws SQLException {
/* 3134 */     updateOracleObject(paramInt, (Datum)paramROWID);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateNUMBER(int paramInt, NUMBER paramNUMBER) throws SQLException {
/* 3141 */     updateOracleObject(paramInt, (Datum)paramNUMBER);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateDATE(int paramInt, DATE paramDATE) throws SQLException {
/* 3148 */     updateOracleObject(paramInt, (Datum)paramDATE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateINTERVALYM(int paramInt, INTERVALYM paramINTERVALYM) throws SQLException {
/* 3156 */     updateOracleObject(paramInt, (Datum)paramINTERVALYM);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateINTERVALDS(int paramInt, INTERVALDS paramINTERVALDS) throws SQLException {
/* 3164 */     updateOracleObject(paramInt, (Datum)paramINTERVALDS);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMP(int paramInt, TIMESTAMP paramTIMESTAMP) throws SQLException {
/* 3171 */     updateOracleObject(paramInt, (Datum)paramTIMESTAMP);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMPTZ(int paramInt, TIMESTAMPTZ paramTIMESTAMPTZ) throws SQLException {
/* 3179 */     updateOracleObject(paramInt, (Datum)paramTIMESTAMPTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateTIMESTAMPLTZ(int paramInt, TIMESTAMPLTZ paramTIMESTAMPLTZ) throws SQLException {
/* 3187 */     updateOracleObject(paramInt, (Datum)paramTIMESTAMPLTZ);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateARRAY(int paramInt, ARRAY paramARRAY) throws SQLException {
/* 3194 */     updateOracleObject(paramInt, (Datum)paramARRAY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateSTRUCT(int paramInt, STRUCT paramSTRUCT) throws SQLException {
/* 3201 */     updateOracleObject(paramInt, (Datum)paramSTRUCT);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateOPAQUE(int paramInt, OPAQUE paramOPAQUE) throws SQLException {
/* 3208 */     updateOracleObject(paramInt, (Datum)paramOPAQUE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateREF(int paramInt, REF paramREF) throws SQLException {
/* 3215 */     updateOracleObject(paramInt, (Datum)paramREF);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCHAR(int paramInt, CHAR paramCHAR) throws SQLException {
/* 3222 */     updateOracleObject(paramInt, (Datum)paramCHAR);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRAW(int paramInt, RAW paramRAW) throws SQLException {
/* 3229 */     updateOracleObject(paramInt, (Datum)paramRAW);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBLOB(int paramInt, BLOB paramBLOB) throws SQLException {
/* 3236 */     updateOracleObject(paramInt, (Datum)paramBLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCLOB(int paramInt, CLOB paramCLOB) throws SQLException {
/* 3243 */     updateOracleObject(paramInt, (Datum)paramCLOB);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBFILE(int paramInt, BFILE paramBFILE) throws SQLException {
/* 3250 */     updateOracleObject(paramInt, (Datum)paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBfile(int paramInt, BFILE paramBFILE) throws SQLException {
/* 3257 */     updateOracleObject(paramInt, (Datum)paramBFILE);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateCustomDatum(int paramInt, CustomDatum paramCustomDatum) throws SQLException {
/* 3265 */     throw new Error("wanna do datum = ((CustomDatum) x).toDatum(m_comm)");
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateORAData(int paramInt, ORAData paramORAData) throws SQLException {
/* 3275 */     Datum datum = paramORAData.toDatum((Connection)this.connection);
/*      */     
/* 3277 */     updateOracleObject(paramInt, datum);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateRef(int paramInt, Ref paramRef) throws SQLException {
/* 3284 */     updateREF(paramInt, (REF)paramRef);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateBlob(int paramInt, Blob paramBlob) throws SQLException {
/* 3291 */     updateBLOB(paramInt, (BLOB)paramBlob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateClob(int paramInt, Clob paramClob) throws SQLException {
/* 3298 */     updateCLOB(paramInt, (CLOB)paramClob);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void updateArray(int paramInt, Array paramArray) throws SQLException {
/* 3305 */     updateARRAY(paramInt, (ARRAY)paramArray);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int getColumnCount() throws SQLException {
/* 3319 */     if (this.columnCount == 0)
/*      */     {
/* 3321 */       if (this.resultSet instanceof OracleResultSetImpl) {
/*      */         
/* 3323 */         if (((OracleResultSetImpl)this.resultSet).statement.accessors != null) {
/* 3324 */           this.columnCount = ((OracleResultSetImpl)this.resultSet).statement.numberOfDefinePositions;
/*      */         } else {
/*      */           
/* 3327 */           this.columnCount = getInternalMetadata().getColumnCount();
/*      */         } 
/*      */       } else {
/* 3330 */         this.columnCount = ((ScrollableResultSet)this.resultSet).getColumnCount();
/*      */       } 
/*      */     }
/* 3333 */     return this.columnCount;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   ResultSetMetaData getInternalMetadata() throws SQLException {
/* 3343 */     if (this.rsetMetaData == null) {
/* 3344 */       this.rsetMetaData = this.resultSet.getMetaData();
/*      */     }
/* 3346 */     return this.rsetMetaData;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void cancelRowChanges() throws SQLException {
/* 3352 */     synchronized (this.connection) {
/*      */       
/* 3354 */       if (this.isInserting) {
/* 3355 */         cancelRowInserts();
/*      */       }
/* 3357 */       if (this.isUpdating) {
/* 3358 */         cancelRowUpdates();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isOnInsertRow() {
/* 3369 */     return this.isInserting;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cancelRowInserts() {
/* 3379 */     if (this.isInserting) {
/*      */       
/* 3381 */       this.isInserting = false;
/*      */       
/* 3383 */       clearRowBuffer();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   boolean isUpdatingRow() {
/* 3394 */     return this.isUpdating;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void clearRowBuffer() {
/* 3404 */     if (this.rowBuffer != null)
/*      */     {
/* 3406 */       for (byte b = 0; b < this.rowBuffer.length; b++) {
/* 3407 */         this.rowBuffer[b] = null;
/*      */       }
/*      */     }
/* 3410 */     if (this.m_nullIndicator != null)
/*      */     {
/* 3412 */       for (byte b = 0; b < this.m_nullIndicator.length; b++) {
/* 3413 */         this.m_nullIndicator[b] = false;
/*      */       }
/*      */     }
/* 3416 */     if (this.typeInfo != null)
/*      */     {
/* 3418 */       for (byte b = 0; b < this.typeInfo.length; b++) {
/* 3419 */         if (this.typeInfo[b] != null) {
/* 3420 */           for (byte b1 = 0; b1 < (this.typeInfo[b]).length; b1++) {
/* 3421 */             this.typeInfo[b][b1] = 0;
/*      */           }
/*      */         }
/*      */       } 
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setRowBufferAt(int paramInt, Datum paramDatum) throws SQLException {
/* 3436 */     setRowBufferAt(paramInt, paramDatum, (int[])null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setRowBufferAt(int paramInt, Object paramObject, int[] paramArrayOfint) throws SQLException {
/* 3447 */     if (!this.isInserting) {
/*      */       
/* 3449 */       if (isBeforeFirst() || isAfterLast() || getRow() == 0) {
/*      */         
/* 3451 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 82);
/* 3452 */         sQLException.fillInStackTrace();
/* 3453 */         throw sQLException;
/*      */       } 
/*      */       
/* 3456 */       this.isUpdating = true;
/*      */     } 
/*      */     
/* 3459 */     if (paramInt < 1 || paramInt > getColumnCount() - 1) {
/*      */       
/* 3461 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "setRowBufferAt");
/* 3462 */       sQLException.fillInStackTrace();
/* 3463 */       throw sQLException;
/*      */     } 
/*      */     
/* 3466 */     if (this.rowBuffer == null) {
/* 3467 */       this.rowBuffer = new Object[getColumnCount()];
/*      */     }
/* 3469 */     if (this.m_nullIndicator == null) {
/*      */       
/* 3471 */       this.m_nullIndicator = new boolean[getColumnCount()];
/*      */       
/* 3473 */       for (byte b = 0; b < getColumnCount(); b++) {
/* 3474 */         this.m_nullIndicator[b] = false;
/*      */       }
/*      */     } 
/* 3477 */     if (paramArrayOfint != null) {
/*      */       
/* 3479 */       if (this.typeInfo == null)
/*      */       {
/* 3481 */         this.typeInfo = new int[getColumnCount()][];
/*      */       }
/*      */       
/* 3484 */       this.typeInfo[paramInt] = paramArrayOfint;
/*      */     } 
/*      */     
/* 3487 */     this.rowBuffer[paramInt] = paramObject;
/* 3488 */     this.m_nullIndicator[paramInt] = (paramObject == null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Datum getRowBufferDatumAt(int paramInt) throws SQLException {
/* 3498 */     if (paramInt < 1 || paramInt > getColumnCount() - 1) {
/*      */       
/* 3500 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
/* 3501 */       sQLException.fillInStackTrace();
/* 3502 */       throw sQLException;
/*      */     } 
/*      */     
/* 3505 */     Datum datum = null;
/*      */     
/* 3507 */     if (this.rowBuffer != null) {
/*      */       
/* 3509 */       Object object = this.rowBuffer[paramInt];
/*      */       
/* 3511 */       if (object != null)
/*      */       {
/* 3513 */         if (object instanceof Datum) {
/*      */           
/* 3515 */           datum = (Datum)object;
/*      */         }
/*      */         else {
/*      */           
/* 3519 */           OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/* 3520 */           int i = paramInt + 1;
/* 3521 */           datum = SQLUtil.makeOracleDatum(this.connection, object, oracleResultSetMetaData.getColumnType(i), null, oracleResultSetMetaData.isNCHAR(i));
/*      */ 
/*      */ 
/*      */           
/* 3525 */           this.rowBuffer[paramInt] = datum;
/*      */         } 
/*      */       }
/*      */     } 
/*      */     
/* 3530 */     return datum;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Object getRowBufferAt(int paramInt) throws SQLException {
/* 3540 */     if (paramInt < 1 || paramInt > getColumnCount() - 1) {
/*      */       
/* 3542 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 68, "getRowBufferDatumAt");
/* 3543 */       sQLException.fillInStackTrace();
/* 3544 */       throw sQLException;
/*      */     } 
/*      */     
/* 3547 */     if (this.rowBuffer != null)
/*      */     {
/* 3549 */       return this.rowBuffer[paramInt];
/*      */     }
/*      */     
/* 3552 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean isRowBufferUpdatedAt(int paramInt) {
/* 3559 */     if (this.rowBuffer == null) {
/* 3560 */       return false;
/*      */     }
/* 3562 */     return (this.rowBuffer[paramInt] != null || this.m_nullIndicator[paramInt]);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareInsertRowStatement() throws SQLException {
/* 3572 */     if (this.insertStmt == null) {
/*      */ 
/*      */       
/* 3575 */       PreparedStatement preparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getInsertSqlForUpdatableResultSet(this));
/*      */ 
/*      */ 
/*      */       
/* 3579 */       this.insertStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedStatement).preparedStatement;
/* 3580 */       this.insertStmt.setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
/* 3581 */       if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 3582 */         this.insertStmt.setEscapeProcessing(true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareInsertRowBinds() throws SQLException {
/* 3594 */     int i = 1;
/*      */ 
/*      */     
/* 3597 */     i = prepareSubqueryBinds(this.insertStmt, i);
/*      */     
/* 3599 */     OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/*      */     
/* 3601 */     for (byte b = 1; b < getColumnCount(); b++) {
/*      */       
/* 3603 */       Object object = getRowBufferAt(b);
/*      */       
/* 3605 */       if (object != null) {
/*      */         
/* 3607 */         if (object instanceof Reader)
/*      */         {
/* 3609 */           if (oracleResultSetMetaData.isNCHAR(b + 1))
/* 3610 */             this.insertStmt.setFormOfUse(i, (short)2); 
/* 3611 */           this.insertStmt.setCharacterStream(i + b - 1, (Reader)object, this.typeInfo[b][0]);
/*      */         
/*      */         }
/* 3614 */         else if (object instanceof InputStream)
/*      */         {
/* 3616 */           if (this.typeInfo[b][1] == 2) {
/* 3617 */             this.insertStmt.setBinaryStream(i + b - 1, (InputStream)object, this.typeInfo[b][0]);
/*      */           
/*      */           }
/* 3620 */           else if (this.typeInfo[b][1] == 1) {
/* 3621 */             this.insertStmt.setAsciiStream(i + b - 1, (InputStream)object, this.typeInfo[b][0]);
/*      */           }
/*      */         
/*      */         }
/*      */         else
/*      */         {
/* 3627 */           Datum datum = getRowBufferDatumAt(b);
/*      */           
/* 3629 */           if (oracleResultSetMetaData.isNCHAR(b + 1))
/* 3630 */             this.insertStmt.setFormOfUse(i + b - 1, (short)2); 
/* 3631 */           this.insertStmt.setOracleObject(i + b - 1, datum);
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 3637 */         int j = getInternalMetadata().getColumnType(b + 1);
/*      */         
/* 3639 */         if (j == 2006 || j == 2002 || j == 2008 || j == 2007 || j == 2003) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3647 */           this.insertStmt.setNull(i + b - 1, j, getInternalMetadata().getColumnTypeName(b + 1));
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 3652 */           this.insertStmt.setNull(i + b - 1, j);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void executeInsertRow() throws SQLException {
/* 3665 */     if (this.insertStmt.executeUpdate() != 1) {
/*      */       
/* 3667 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 3668 */       sQLException.fillInStackTrace();
/* 3669 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getNumColumnsChanged() throws SQLException {
/* 3682 */     byte b = 0;
/*      */     
/* 3684 */     if (this.indexColsChanged == null) {
/* 3685 */       this.indexColsChanged = new int[getColumnCount()];
/*      */     }
/* 3687 */     if (this.rowBuffer != null)
/*      */     {
/* 3689 */       for (byte b1 = 1; b1 < getColumnCount(); b1++) {
/*      */         
/* 3691 */         if (this.rowBuffer[b1] != null || (this.rowBuffer[b1] == null && this.m_nullIndicator[b1]))
/*      */         {
/*      */           
/* 3694 */           this.indexColsChanged[b++] = b1;
/*      */         }
/*      */       } 
/*      */     }
/*      */     
/* 3699 */     return b;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareUpdateRowStatement(int paramInt) throws SQLException {
/* 3713 */     if (this.updateStmt != null) {
/* 3714 */       this.updateStmt.close();
/*      */     }
/* 3716 */     PreparedStatement preparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getUpdateSqlForUpdatableResultSet(this, paramInt, this.rowBuffer, this.indexColsChanged));
/*      */ 
/*      */ 
/*      */     
/* 3720 */     this.updateStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedStatement).preparedStatement;
/* 3721 */     this.updateStmt.setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
/* 3722 */     if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 3723 */       this.updateStmt.setEscapeProcessing(true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareUpdateRowBinds(int paramInt) throws SQLException {
/* 3733 */     int i = 1;
/*      */ 
/*      */     
/* 3736 */     i = prepareSubqueryBinds(this.updateStmt, i);
/*      */     
/* 3738 */     OracleResultSetMetaData oracleResultSetMetaData = (OracleResultSetMetaData)getInternalMetadata();
/*      */     
/* 3740 */     for (byte b = 0; b < paramInt; b++) {
/*      */       
/* 3742 */       int j = this.indexColsChanged[b];
/* 3743 */       Object object = getRowBufferAt(j);
/*      */       
/* 3745 */       if (object != null) {
/*      */         
/* 3747 */         if (object instanceof Reader) {
/*      */           
/* 3749 */           if (oracleResultSetMetaData.isNCHAR(j + 1))
/* 3750 */             this.updateStmt.setFormOfUse(i, (short)2); 
/* 3751 */           this.updateStmt.setCharacterStream(i++, (Reader)object, this.typeInfo[j][0]);
/*      */         
/*      */         }
/* 3754 */         else if (object instanceof InputStream) {
/*      */           
/* 3756 */           if (this.typeInfo[j][1] == 2)
/*      */           {
/*      */             
/* 3759 */             this.updateStmt.setBinaryStream(i++, (InputStream)object, this.typeInfo[j][0]);
/*      */           }
/* 3761 */           else if (this.typeInfo[j][1] == 1)
/*      */           {
/* 3763 */             this.updateStmt.setAsciiStream(i++, (InputStream)object, this.typeInfo[j][0]);
/*      */           }
/*      */         
/*      */         } else {
/*      */           
/* 3768 */           Datum datum = getRowBufferDatumAt(j);
/*      */           
/* 3770 */           if (oracleResultSetMetaData.isNCHAR(j + 1))
/* 3771 */             this.updateStmt.setFormOfUse(i, (short)2); 
/* 3772 */           this.updateStmt.setOracleObject(i++, datum);
/*      */         }
/*      */       
/*      */       }
/*      */       else {
/*      */         
/* 3778 */         int k = getInternalMetadata().getColumnType(j + 1);
/*      */         
/* 3780 */         if (k == 2006 || k == 2002 || k == 2008 || k == 2007 || k == 2003) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 3787 */           this.updateStmt.setNull(i++, k, getInternalMetadata().getColumnTypeName(j + 1));
/*      */         
/*      */         }
/*      */         else {
/*      */           
/* 3792 */           if (oracleResultSetMetaData.isNCHAR(j + 1))
/* 3793 */             this.updateStmt.setFormOfUse(i, (short)2); 
/* 3794 */           this.updateStmt.setNull(i++, k);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 3800 */     prepareCompareSelfBinds(this.updateStmt, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void executeUpdateRow() throws SQLException {
/*      */     try {
/* 3812 */       if (this.updateStmt.executeUpdate() == 0) {
/*      */         
/* 3814 */         SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 3815 */         sQLException.fillInStackTrace();
/* 3816 */         throw sQLException;
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 3821 */       if (this.isCachedRset)
/*      */       {
/*      */         
/* 3824 */         ((ScrollableResultSet)this.resultSet).refreshRowsInCache(getRow(), 1, 1000);
/*      */         
/* 3826 */         cancelRowUpdates();
/*      */ 
/*      */       
/*      */       }
/*      */ 
/*      */     
/*      */     }
/*      */     finally {
/*      */ 
/*      */       
/* 3836 */       if (this.updateStmt != null) {
/*      */         
/* 3838 */         this.updateStmt.close();
/*      */         
/* 3840 */         this.updateStmt = null;
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareDeleteRowStatement() throws SQLException {
/* 3852 */     if (this.deleteStmt == null) {
/*      */       
/* 3854 */       PreparedStatement preparedStatement = this.connection.prepareStatement(((OracleStatement)this.scrollStmt).sqlObject.getDeleteSqlForUpdatableResultSet(this));
/*      */ 
/*      */       
/* 3857 */       this.deleteStmt = (OraclePreparedStatement)((OraclePreparedStatementWrapper)preparedStatement).preparedStatement;
/* 3858 */       this.deleteStmt.setQueryTimeout(((Statement)this.scrollStmt).getQueryTimeout());
/* 3859 */       if (((OracleStatement)this.scrollStmt).sqlObject.generatedSqlNeedEscapeProcessing()) {
/* 3860 */         this.deleteStmt.setEscapeProcessing(true);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void prepareDeleteRowBinds() throws SQLException {
/* 3871 */     int i = 1;
/*      */ 
/*      */     
/* 3874 */     i = prepareSubqueryBinds(this.deleteStmt, i);
/*      */ 
/*      */     
/* 3877 */     prepareCompareSelfBinds(this.deleteStmt, i);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void executeDeleteRow() throws SQLException {
/* 3889 */     if (this.deleteStmt.executeUpdate() == 0) {
/*      */       
/* 3891 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 85);
/* 3892 */       sQLException.fillInStackTrace();
/* 3893 */       throw sQLException;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 3898 */     if (this.isCachedRset) {
/* 3899 */       ((ScrollableResultSet)this.resultSet).removeRowInCache(getRow());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int prepareCompareSelfBinds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt) throws SQLException {
/* 3908 */     paramOraclePreparedStatement.setOracleObject(paramInt, this.resultSet.getOracleObject(1));
/*      */     
/* 3910 */     return paramInt + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int prepareSubqueryBinds(OraclePreparedStatement paramOraclePreparedStatement, int paramInt) throws SQLException {
/* 3918 */     int i = this.scrollStmt.copyBinds((Statement)paramOraclePreparedStatement, paramInt - 1);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 3933 */     return i + 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setIsNull(int paramInt) {
/* 3940 */     this.wasNull = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void setIsNull(boolean paramBoolean) {
/* 3947 */     if (paramBoolean) {
/* 3948 */       this.wasNull = 1;
/*      */     } else {
/* 3950 */       this.wasNull = 2;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public String getCursorName() throws SQLException {
/* 3956 */     synchronized (this.connection) {
/*      */ 
/*      */       
/* 3959 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 23, "getCursorName");
/* 3960 */       sQLException.fillInStackTrace();
/* 3961 */       throw sQLException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 3978 */     return this.connection;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   OracleStatement getOracleStatement() throws SQLException {
/* 3989 */     return (this.resultSet == null) ? null : this.resultSet.getOracleStatement();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/* 3994 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*      */   public static final boolean TRACE = false;
/*      */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/UpdatableResultSet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */