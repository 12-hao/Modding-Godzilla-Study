/*    */ package oracle.jdbc.internal;
/*    */ 
/*    */ import java.util.EventObject;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class XSEvent
/*    */   extends EventObject
/*    */ {
/*    */   protected XSEvent(Object paramObject) {
/* 39 */     super(paramObject);
/*    */   }
/*    */   
/*    */   public abstract byte[] getSessionId();
/*    */   
/*    */   public abstract KeywordValueLong[] getDetails();
/*    */   
/*    */   public abstract int getFlags();
/*    */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/internal/XSEvent.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */