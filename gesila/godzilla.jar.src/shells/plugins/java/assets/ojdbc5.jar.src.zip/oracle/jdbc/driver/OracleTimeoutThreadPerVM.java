/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import oracle.jdbc.internal.OracleConnection;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class OracleTimeoutThreadPerVM
/*     */   extends OracleTimeout
/*     */ {
/*  29 */   private static final OracleTimeoutPollingThread watchdog = new OracleTimeoutPollingThread();
/*     */ 
/*     */ 
/*     */   
/*     */   private OracleStatement statement;
/*     */ 
/*     */ 
/*     */   
/*     */   private long interruptAfter;
/*     */ 
/*     */ 
/*     */   
/*     */   private String name;
/*     */ 
/*     */ 
/*     */   
/*     */   OracleTimeoutThreadPerVM(String paramString) {
/*  46 */     this.name = paramString;
/*  47 */     this.interruptAfter = Long.MAX_VALUE;
/*  48 */     watchdog.addTimeout(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void close() {
/*  62 */     watchdog.removeTimeout(this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void setTimeout(long paramLong, OracleStatement paramOracleStatement) throws SQLException {
/*  81 */     if (this.interruptAfter != Long.MAX_VALUE) {
/*     */ 
/*     */ 
/*     */       
/*  85 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 131);
/*  86 */       sQLException.fillInStackTrace();
/*  87 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */     
/*  91 */     this.statement = paramOracleStatement;
/*  92 */     this.interruptAfter = System.currentTimeMillis() + paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized void cancelTimeout() throws SQLException {
/* 116 */     this.statement = null;
/* 117 */     this.interruptAfter = Long.MAX_VALUE;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void interruptIfAppropriate(long paramLong) {
/* 144 */     if (paramLong > this.interruptAfter)
/*     */     {
/* 146 */       synchronized (this) {
/*     */         
/* 148 */         if (paramLong > this.interruptAfter) {
/*     */ 
/*     */           
/* 151 */           if (this.statement.connection.spawnNewThreadToCancel) {
/* 152 */             final OracleStatement s = this.statement;
/* 153 */             Thread thread = new Thread(new Runnable() {
/*     */                   public void run() {
/*     */                     try {
/* 156 */                       s.cancel();
/*     */                     }
/* 158 */                     catch (Throwable throwable) {}
/*     */                   }
/*     */                 });
/*     */ 
/*     */             
/* 163 */             thread.setName("interruptIfAppropriate_" + this);
/* 164 */             thread.setDaemon(true);
/* 165 */             thread.setPriority(10);
/* 166 */             thread.start();
/*     */           } else {
/*     */             
/*     */             try {
/* 170 */               this.statement.cancel();
/*     */             }
/* 172 */             catch (Throwable throwable) {}
/*     */           } 
/*     */ 
/*     */ 
/*     */           
/* 177 */           this.statement = null;
/* 178 */           this.interruptAfter = Long.MAX_VALUE;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected OracleConnection getConnectionDuringExceptionHandling() {
/* 197 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/OracleTimeoutThreadPerVM.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */