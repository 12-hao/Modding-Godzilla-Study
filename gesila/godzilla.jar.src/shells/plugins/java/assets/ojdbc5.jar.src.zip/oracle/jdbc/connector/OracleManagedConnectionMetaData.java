/*     */ package oracle.jdbc.connector;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import javax.resource.ResourceException;
/*     */ import javax.resource.spi.EISSystemException;
/*     */ import javax.resource.spi.ManagedConnectionMetaData;
/*     */ import oracle.jdbc.OracleConnection;
/*     */ import oracle.jdbc.OracleDatabaseMetaData;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class OracleManagedConnectionMetaData
/*     */   implements ManagedConnectionMetaData
/*     */ {
/*  30 */   private OracleManagedConnection managedConnection = null;
/*  31 */   private OracleDatabaseMetaData databaseMetaData = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   OracleManagedConnectionMetaData(OracleManagedConnection paramOracleManagedConnection) throws ResourceException {
/*     */     try {
/*  42 */       this.managedConnection = paramOracleManagedConnection;
/*     */       
/*  44 */       OracleConnection oracleConnection = (OracleConnection)paramOracleManagedConnection.getPhysicalConnection();
/*     */       
/*  46 */       this.databaseMetaData = (OracleDatabaseMetaData)oracleConnection.getMetaData();
/*     */     }
/*  48 */     catch (Exception exception) {
/*     */       
/*  50 */       EISSystemException eISSystemException = new EISSystemException("Exception: " + exception.getMessage());
/*     */ 
/*     */       
/*  53 */       eISSystemException.setLinkedException(exception);
/*     */       
/*  55 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEISProductName() throws ResourceException {
/*     */     try {
/*  76 */       return this.databaseMetaData.getDatabaseProductName();
/*     */     }
/*  78 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/*  82 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/*  85 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/*  87 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getEISProductVersion() throws ResourceException {
/*     */     try {
/* 108 */       return this.databaseMetaData.getDatabaseProductVersion();
/*     */     
/*     */     }
/* 111 */     catch (Exception exception) {
/*     */       
/* 113 */       EISSystemException eISSystemException = new EISSystemException("Exception: " + exception.getMessage());
/*     */ 
/*     */       
/* 116 */       eISSystemException.setLinkedException(exception);
/*     */       
/* 118 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getMaxConnections() throws ResourceException {
/*     */     try {
/* 141 */       return this.databaseMetaData.getMaxConnections();
/*     */     }
/* 143 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 147 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 150 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 152 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getUserName() throws ResourceException {
/*     */     try {
/* 175 */       return this.databaseMetaData.getUserName();
/*     */     }
/* 177 */     catch (SQLException sQLException) {
/*     */ 
/*     */ 
/*     */       
/* 181 */       EISSystemException eISSystemException = new EISSystemException("SQLException: " + sQLException.getMessage());
/*     */ 
/*     */       
/* 184 */       eISSystemException.setLinkedException(sQLException);
/*     */       
/* 186 */       throw eISSystemException;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 195 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/connector/OracleManagedConnectionMetaData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */