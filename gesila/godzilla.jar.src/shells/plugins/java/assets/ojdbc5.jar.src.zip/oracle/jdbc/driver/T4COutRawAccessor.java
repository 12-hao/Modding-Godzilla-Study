/*     */ package oracle.jdbc.driver;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class T4COutRawAccessor
/*     */   extends OutRawAccessor
/*     */ {
/*     */   T4CMAREngine mare;
/*     */   final int[] meta;
/*     */   
/*     */   T4COutRawAccessor(OracleStatement paramOracleStatement, int paramInt1, short paramShort, int paramInt2, T4CMAREngine paramT4CMAREngine) throws SQLException {
/*  41 */     super(paramOracleStatement, paramInt1, paramShort, paramInt2);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  79 */     this.meta = new int[1];
/*     */     this.mare = paramT4CMAREngine;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean unmarshalOneRow() throws SQLException, IOException {
/*  94 */     if (this.isUseLess) {
/*     */       
/*  96 */       this.lastRowProcessed++;
/*     */       
/*  98 */       return false;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 103 */     if (this.rowSpaceIndicator == null) {
/*     */ 
/*     */ 
/*     */       
/* 107 */       byte[] arrayOfByte = new byte[16000];
/*     */       
/* 109 */       this.mare.unmarshalCLR(arrayOfByte, 0, this.meta);
/* 110 */       processIndicator(this.meta[0]);
/*     */       
/* 112 */       this.lastRowProcessed++;
/*     */       
/* 114 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 118 */     int i = this.indicatorIndex + this.lastRowProcessed;
/* 119 */     int j = this.lengthIndex + this.lastRowProcessed;
/*     */ 
/*     */ 
/*     */     
/* 123 */     if (this.isNullByDescribe) {
/*     */       
/* 125 */       this.rowSpaceIndicator[i] = -1;
/* 126 */       this.rowSpaceIndicator[j] = 0;
/* 127 */       this.lastRowProcessed++;
/*     */       
/* 129 */       if (this.statement.connection.versionNumber < 9200) {
/* 130 */         processIndicator(0);
/*     */       }
/* 132 */       return false;
/*     */     } 
/*     */     
/* 135 */     int k = this.columnIndex + this.lastRowProcessed * this.byteLength;
/*     */ 
/*     */ 
/*     */     
/* 139 */     this.mare.unmarshalCLR(this.rowSpaceByte, k, this.meta, this.byteLength);
/*     */     
/* 141 */     processIndicator(this.meta[0]);
/*     */     
/* 143 */     if (this.meta[0] == 0) {
/*     */ 
/*     */ 
/*     */       
/* 147 */       this.rowSpaceIndicator[i] = -1;
/* 148 */       this.rowSpaceIndicator[j] = 0;
/*     */     }
/*     */     else {
/*     */       
/* 152 */       this.rowSpaceIndicator[j] = (short)this.meta[0];
/* 153 */       this.rowSpaceIndicator[i] = 0;
/*     */     } 
/*     */     
/* 156 */     this.lastRowProcessed++;
/*     */     
/* 158 */     return false;
/*     */   } void processIndicator(int paramInt) throws IOException, SQLException { if ((this.internalType == 1 && this.describeType == 112) || (this.internalType == 23 && this.describeType == 113)) {
/*     */       this.mare.unmarshalUB2(); this.mare.unmarshalUB2();
/*     */     } else if (this.statement.connection.versionNumber < 9200) {
/*     */       this.mare.unmarshalSB2();
/*     */       if (!this.statement.sqlKind.isPlsqlOrCall())
/*     */         this.mare.unmarshalSB2(); 
/*     */     } else if (this.statement.sqlKind.isPlsqlOrCall() || this.isDMLReturnedParam) {
/*     */       this.mare.processIndicator((paramInt <= 0), paramInt);
/*     */     }  } void copyRow() throws SQLException, IOException { int i;
/* 168 */     if (this.lastRowProcessed == 0) {
/* 169 */       i = this.statement.rowPrefetchInLastFetch - 1;
/*     */     } else {
/* 171 */       i = this.lastRowProcessed - 1;
/*     */     } 
/*     */     
/* 174 */     int j = this.columnIndex + this.lastRowProcessed * this.byteLength;
/* 175 */     int k = this.columnIndex + i * this.byteLength;
/* 176 */     int m = this.indicatorIndex + this.lastRowProcessed;
/* 177 */     int n = this.indicatorIndex + i;
/* 178 */     int i1 = this.lengthIndex + this.lastRowProcessed;
/* 179 */     int i2 = this.lengthIndex + i;
/* 180 */     short s = this.rowSpaceIndicator[i2];
/* 181 */     int i3 = this.metaDataIndex + this.lastRowProcessed * 1;
/*     */     
/* 183 */     int i4 = this.metaDataIndex + i * 1;
/*     */ 
/*     */ 
/*     */     
/* 187 */     this.rowSpaceIndicator[i1] = (short)s;
/* 188 */     this.rowSpaceIndicator[m] = this.rowSpaceIndicator[n];
/*     */ 
/*     */     
/* 191 */     if (!this.isNullByDescribe)
/*     */     {
/* 193 */       System.arraycopy(this.rowSpaceByte, k, this.rowSpaceByte, j, s);
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 198 */     System.arraycopy(this.rowSpaceMetaData, i4, this.rowSpaceMetaData, i3, 1);
/*     */ 
/*     */     
/* 201 */     this.lastRowProcessed++; }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void saveDataFromOldDefineBuffers(byte[] paramArrayOfbyte, char[] paramArrayOfchar, short[] paramArrayOfshort, int paramInt1, int paramInt2) throws SQLException {
/* 213 */     int i = this.columnIndex + (paramInt2 - 1) * this.byteLength;
/*     */     
/* 215 */     int j = this.columnIndexLastRow + (paramInt1 - 1) * this.byteLength;
/*     */     
/* 217 */     int k = this.indicatorIndex + paramInt2 - 1;
/* 218 */     int m = this.indicatorIndexLastRow + paramInt1 - 1;
/* 219 */     int n = this.lengthIndex + paramInt2 - 1;
/* 220 */     int i1 = this.lengthIndexLastRow + paramInt1 - 1;
/* 221 */     short s = paramArrayOfshort[i1];
/*     */     
/* 223 */     this.rowSpaceIndicator[n] = (short)s;
/* 224 */     this.rowSpaceIndicator[k] = paramArrayOfshort[m];
/*     */ 
/*     */     
/* 227 */     if (s != 0)
/*     */     {
/* 229 */       System.arraycopy(paramArrayOfbyte, j, this.rowSpaceByte, i, s);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   String getString(int paramInt) throws SQLException {
/* 247 */     String str = super.getString(paramInt);
/*     */     
/* 249 */     if (str != null && this.definedColumnSize > 0 && str.length() > this.definedColumnSize)
/*     */     {
/* 251 */       str = str.substring(0, this.definedColumnSize);
/*     */     }
/* 253 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getBytes(int paramInt) throws SQLException {
/* 262 */     byte[] arrayOfByte = null;
/*     */     
/* 264 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 266 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 267 */       sQLException.fillInStackTrace();
/* 268 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 273 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 275 */       short s = this.rowSpaceIndicator[this.lengthIndex + paramInt];
/* 276 */       int i = this.columnIndex + this.byteLength * paramInt;
/*     */       
/* 278 */       arrayOfByte = new byte[s];
/*     */       
/* 280 */       System.arraycopy(this.rowSpaceByte, i, arrayOfByte, 0, s);
/*     */     } 
/*     */     
/* 283 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   Object getObject(int paramInt) throws SQLException {
/* 291 */     if (this.definedColumnType == 0) {
/* 292 */       return super.getObject(paramInt);
/*     */     }
/*     */     
/* 295 */     Object object = null;
/*     */     
/* 297 */     if (this.rowSpaceIndicator == null) {
/*     */       
/* 299 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 21);
/* 300 */       sQLException.fillInStackTrace();
/* 301 */       throw sQLException;
/*     */     } 
/*     */     
/* 304 */     if (this.rowSpaceIndicator[this.indicatorIndex + paramInt] != -1) {
/*     */       
/* 306 */       switch (this.definedColumnType) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case -1:
/*     */         case 1:
/*     */         case 12:
/* 314 */           return getString(paramInt);
/*     */         
/*     */         case -2:
/* 317 */           return getRAW(paramInt);
/*     */ 
/*     */         
/*     */         case -4:
/*     */         case -3:
/* 322 */           return getBytes(paramInt);
/*     */       } 
/*     */ 
/*     */       
/* 326 */       SQLException sQLException = DatabaseError.createSqlException(getConnectionDuringExceptionHandling(), 4);
/* 327 */       sQLException.fillInStackTrace();
/* 328 */       throw sQLException;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 334 */     return object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 341 */   private static final String _Copyright_2007_Oracle_All_Rights_Reserved_ = null;
/*     */   public static final boolean TRACE = false;
/*     */ }


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/driver/T4COutRawAccessor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */