package oracle.jdbc.internal;

import java.util.EventListener;

public interface XSEventListener extends EventListener {
  void onXSEvent(XSEvent paramXSEvent);
}


/* Location:              /Users/h12/Documents/网安工具/gesila/godzilla.jar!/shells/plugins/java/assets/ojdbc5.jar!/oracle/jdbc/internal/XSEventListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */